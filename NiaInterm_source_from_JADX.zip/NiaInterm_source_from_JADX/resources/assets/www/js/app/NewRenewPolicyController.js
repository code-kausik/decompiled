agentApp.controller('NewRenewPolicyCtrl', ['$scope', 'RestServices', '$rootScope', 'CommonServices', function ($scope, RestServices, $rootScope, CommonServices) {
    
    $rootScope.showDiscountNote = false; //CR_3868
    $rootScope.isDiscountAvail = CommonServices.getCommonData("additionalDisc");//CR_3868
    $scope.policyData = {};

    $scope.logOut = function () {
        RestServices.logOut();
    };

    $scope.home = function () {
        RestServices.goHome();
    };
    var collectionNotDone = false;
    var productCode = "";
    var coverageType = '';
    var response = {};
    CommonServices.setCommonData("partyCode", "");

    /*Changed by for CR_NP_3621*/
    var getDomainValuesData = {
        "lngCode": "EN", "keys": ["GENDER", "TITLE", "YES_NO", "ORGANIZATION_TYPE", "OCCUPATION",
            "PARTY_RELATIONSHIP", "FINANCING_AGREEMENT_TYPE", "NCB_PERCENT", "VEHICLE_ZONE", "BENEFIT_COVERAGE_TYPE", "DEPENDENT_TYPE",
            "RELATIONSHIP_WITH_PROPOSER", "RELATIONSHIP_WITH_THE_NOMINEE", "RELATIONSHIP_WITH_THE_NOMINEE_HEALTH", "OCCUPATION_HEALTH",
            "NATURE_OF_WORK", "YEAR_OF_MAKE_EPRODUCT", "BMB_BRANCH", "BMB_RELATIONSHIP_WITH_THE_NOMINEE", "GST_REG_TYPE", "PREVIOUS_INSURER_NAME", "PREVIOUS_INSURER_NAME_BUNDLE"]
    };
    var getDomainValuesResponse = RestServices.postService(RestServices.urlPathsNewPortal.getDomainValues, getDomainValuesData);
    getDomainValuesResponse.then(
        function (response) { // success 		
            CommonServices.showLoading(false);

            if (response.data !== undefined && response.data !== "") {
                if (response.data.hasOwnProperty('errorMessage')) {
                    CommonServices.showAlert(response.data.errorMessage);
                } else {
                    CommonServices.showLoading(false);
                    CommonServices.domainValues = response.data;
                    getPreviousInsurersListBundle();
                }
            }
            else {
                CommonServices.showAlert("Please try after some time");
            }

        },
        function (error) { // failure
            CommonServices.showLoading(false);
            RestServices.handleWebServiceError(error);
        });

    function getPreviousInsurersListBundle() {
        var listOfInsurers = [];
        $rootScope.previousInsurersList = [];
        listOfInsurers = CommonServices.domainValues.domainValues;
        if (listOfInsurers !== undefined && listOfInsurers !== "") {
            for (var i = 0; i < listOfInsurers.length; i++) {
                if (listOfInsurers[i].codeId !== undefined && listOfInsurers[i].codeId !== "" && listOfInsurers[i].codeId === "PREVIOUS_INSURER_NAME" || listOfInsurers[i].codeId === "PREVIOUS_INSURER_NAME_BUNDLE") {
                    $rootScope.previousInsurersList.push(listOfInsurers[i]);
                }
            }
        } else {
            CommonServices.showAlert("No Domain Values available");
        }
    }
    /*Changed by for CR_NP_3621*/
}]);

agentApp.controller('NationalityCaptureCtrl', ['$scope', '$location', '$rootScope', 'RestServices', 'CommonServices', '$state', function ($scope, $location, $rootScope, RestServices, CommonServices, $state) {
    $scope.x=[1,5,9,7,4];
}]);
agentApp.controller('GetNewRenewPolicyCtrl', ['$scope', '$location', '$rootScope', 'RestServices', 'CommonServices', '$state', 'CartServices', function ($scope, $location, $rootScope, RestServices, CommonServices, $state, CartServices) {

    $scope.agruserName = CommonServices.getCommonData("userCode").toUpperCase();
    var postIssuePolicyData = "";
    var quoteNo = "";
    /*$scope.nationalityInfo="";//3712*/
    $scope.quotePolicyNum = "";
    $scope.isSet1 = true;
    $scope.numberLengthInvalid = true;
    $scope.buyNow.twoWheeler.addCovers.ownerDriveVehOrNotTW = false;//3444
    /*Added for CR_NP_0744*/
    $rootScope.isQrFlow = false;
    /*CR_NP_0744 ends*/
    /*Added for CR_NP_3621*/
    $rootScope.isSQ = false;
    $rootScope.isSS = false;
    /*CR_NP_3621 ends*/
    var regexAge = /^(?=.*[1-9])\d*$/;//3444
    var regexName = /^[a-zA-Z][a-zA-Z ]*$/;//3444
    if (CommonServices.renewQuoteNo !== "") {
        $scope.quotePolicyNum = CommonServices.renewQuoteNo;
        checkValidQuotePolicyNum();
        CommonServices.renewQuoteNo = "";
        if (CommonServices.managePolBreakIn) {
            CommonServices.managePolBreakIn = false;
            quotePolSubmit();
        }
    }
    /*//////3712 starts //
    $scope.showMemberDetails = function(){
            $scope.nationalityInfo = !($scope.nationalityInfo);
        }
    //////// 3712 ends  //*/
    $scope.quotePolicyNumChange = function () {
        checkValidQuotePolicyNum();
    }

    function checkValidQuotePolicyNum() {
        if ($scope.quotePolicyNum === undefined) {

        } else {
            var numberLength = $scope.quotePolicyNum.toString().length;
            if (numberLength === 20) {
                $scope.numberLengthInvalid = false;
                angular.element(document.querySelector("#quotePolicyNumBtn")).removeClass("disableBtn");
            } else if (numberLength === 16) {
                $scope.numberLengthInvalid = false;
                angular.element(document.querySelector("#quotePolicyNumBtn")).removeClass("disableBtn");
            } else {
                $scope.numberLengthInvalid = true;
                angular.element(document.querySelector("#quotePolicyNumBtn")).addClass("disableBtn");
            }
        }
    }

    $scope.QuoteDetailsSubmit = function () {
        CommonServices.qrScannerData = "";
        quotePolSubmit();
    }

    /*-------- code for QR scanner starts -----------------------*/

    CommonServices.qrScannerData = '';
    CommonServices.partyCode = '';
    $scope.showQRscanButtonQRPage = $rootScope.showQRscanButton;


    $scope.scanQRcode = function () {
        //modal.style.display = "none";

        if (CommonServices.deviceType == "NA") {
            var result = { "text": "{\"policyholderCode\" : \"PO04946970\",\n\"expiringPolicyNumber\" : \"13010031170200000575\",\n\"renewalQuoteNumber\" : \" \",\n\"coverageCode\" : \"Liability\"}", "format": "QR_CODE", "cancelled": false };

            //var result = {"text":"Policyholder Code : PO04933985_Expiring Policy Number : 13010031170200000408_Renewal Quote Number :  _Coverage Code : Liability","format":"QR_CODE","cancelled":false};
            var value = "";

            try {
                value = JSON.parse(result.text);
            } catch (err) {
                CommonServices.showAlert("Renewal notices generated till 5th July can be renewed with Customer ID/Old Policy No./Fresh Renewal Quote No.");
                return;
            }

            CommonServices.qrScannerData = {
                oldPolicyNumberFromScanner: value.expiringPolicyNumber,
                partyCodeFromScanner: value.policyholderCode
            };

            //modal.style.display = "none";

            if (value.coverageCode === "Liability") {
                quotePolSubmit();
            } else {
                CommonServices.showLoading("The 'Scan QR code' feature is only for third party motor policies. For other policies kindly use 'Renewed Quote No. / Old Policy No.' to renew the policy.");

            }

        }
        else {

            cordova.plugins.barcodeScanner.scan(
                function (result) {

                    if (!result.cancelled) {

                        if (result.format == "QR_CODE") {

                            console.log("result : " + JSON.stringify(result));
                            var value;

                            try {
                                value = JSON.parse(result.text);
                            }
                            catch (err) {
                                CommonServices.showAlert("Couldn't able to fetch proper data from QR code. Kindly use 'Renewed Quote No. / Old Policy No.' to renew the policy. ");
                                return;
                            }

                            CommonServices.qrScannerData = {
                                oldPolicyNumberFromScanner: value.expiringPolicyNumber,
                                partyCodeFromScanner: value.policyholderCode
                            };

                            if (value.coverageCode === "Liability") {

                                quotePolSubmit();

                            } else {
                                CommonServices.showLoading("The 'Scan QR code' feature is only for third party motor policies. For other policies kindly use ‘Renewed Quote No. / Old Policy No.’ to renew the policy.");
                            }
                        } else {
                            CommonServices.showAlert("Sorry, only qr codes this time");
                        }

                    } else {
                        CommonServices.showAlert("Scanner is dismissed");
                    }
                },
                function (error) {
                    CommonServices.showAlert("Scanning failed: " + error);
                }
            );

        }
    };

    /*-------- code for QR scanner ends -----------------------*/

    function quotePolSubmit() {

        if (CommonServices.qrScannerData.partyCodeFromScanner != undefined) {
            $scope.quotePolicyNum = CommonServices.qrScannerData.oldPolicyNumberFromScanner;
            CommonServices.partyCode = CommonServices.qrScannerData.partyCodeFromScanner;
        }

        //New portal
        var RenewalPolData;
        CommonServices.editQuoteInsured = "";
        if ($scope.quotePolicyNum.toString().length === 20) {
            RenewalPolData = {
                "quote": {
                    "policyNumber": $scope.quotePolicyNum.toString()
                },
                "userProfile": {
                    "userId": CommonServices.getCommonData("userCode").toUpperCase(),
                    "loggedInRole": CommonServices.getCommonData("loggedInRole")
                }
            };
        } else if ($scope.quotePolicyNum.toString().length === 16) {
            RenewalPolData = {
                "quote": {
                    "quoteNumber": $scope.quotePolicyNum.toString()
                },
                "userProfile": {
                    "userId": CommonServices.getCommonData("userCode").toUpperCase(),
                    "loggedInRole": CommonServices.getCommonData("loggedInRole").toUpperCase()
                }
            };
        }
        $scope.alertArr = [];
        var RenewalPolResponse = RestServices.postService(RestServices.urlPathsNewPortal.getPolDetails, RenewalPolData);
        if (RenewalPolResponse === undefined) {

        } else {
            RenewalPolResponse.then(function (response) {
                CommonServices.showLoading(false);

                if (response.data === "") {
                    CommonServices.showAlert("Something went wrong! Please try after some time");
                } else if (response.data.errorCode !== undefined) {
                    CommonServices.showAlert(response.data.errorMessage);
                    if (CommonServices.qrScannerData.oldPolicyNumberFromScanner != undefined) {
                        $scope.quotePolicyNum = "";
                    }
                } else if (response.data.userProfile.footer.errorCode === "1") {
                    if (response.data.userProfile.footer.errorDescription === undefined) {
                        /* CR 3712 Starts: Nationality Capture */
                        
                        //Check the response here to iterate through the risks available
                        //whether nationality is avaiable for all or not 
                        //if nationality is needed for any of the memners,
                        //we should redirect to NationalityCapture screen first.
                        //after taking input for all the memners, for whome nationality is not available,
                        //call this service again 
                        //if(true){
                        //    $state.go('newRenewPolicy.nationalityCapture');
                        //}else{
                        /* 3712 Ends */
                            /*Changed by for CR_NP_3621*/
                            if (response.data.quote.productCode === "SQ") {
                                $rootScope.isSQ = true;
                            } else {
                                $rootScope.isSQ = false;
                            }
                            if (response.data.quote.productCode === "SS") {
                                $rootScope.isSS = true;
                            } else {
                                $rootScope.isSS = false;
                            }
                             //CR_3868
                             if($rootScope.isDiscountAvail === 'Y' && (response.data.quote.productCode === "TW" || response.data.quote.productCode === "CV" || response.data.quote.productCode === "PC" || response.data.quote.productCode === "SQ" || response.data.quote.productCode === "SS")) {
                                $rootScope.showDiscountNote = true;
                            }

                            //CR_3868
                            
                            /*Changed by for CR_NP_3621*/
                            CommonServices.breakInOccured = "N";
                            CommonServices.QRrenewalData = response.data;
                            $scope.policyData = response.data;
                            CommonServices.RenewalPolData = response.data;
                            CommonServices.setCommonData("productCode", response.data.quote.productCode);
                            CommonServices.setCommonData("currentStatus", response.data.quote.currentStatus);
                            var msg;
                            /*CR_NP_3621 Start*/
                            if (response.data.quote.productCode === "SQ" || response.data.quote.productCode === "SS") {
                                var prevInsurer = $scope.policyData.quote.standaloneODdetails.bundInsName;
                                for (var i = 0; i < $rootScope.previousInsurersList.length; i++) {
                                    if ($rootScope.previousInsurersList[i].codeValue == prevInsurer) {
                                        $scope.policyData.quote.standaloneODdetails.bundInsName = $rootScope.previousInsurersList[i].mnemonic;
                                        break;
                                    } else {
                                        $scope.policyData.quote.standaloneODdetails.bundInsName = "";
                                    }
                                }
                            }
                            /*CR_NP_3621 Ends*/
                            if (response.data.quote.genNewQuoteMsg !== undefined) {
                                var genNewQuoteMsg = response.data.quote.genNewQuoteMsg;
                                var newQuoteNum = genNewQuoteMsg.match(/[0-9]+/g);
                                $scope.policyData.quote.quoteNumber = newQuoteNum[0];
                                CommonServices.QRrenewalData.quote.quoteNumber = newQuoteNum[0];
                                CommonServices.showAlert(genNewQuoteMsg);
                                $scope.continueRenewalProcess(response);
                                $scope.getDetailsGVW(response); //CR_3460
                                //  Aishwarya code merge
                                if (response.data.quote.breakInOccured === 'Y') {
                                    CommonServices.setCommonData("coverageType", response.data.quote.cover);
                                    if (response.data.quote.breakInStatus === 'BREAKCRNWL' || response.data.quote.breakInStatus === 'BREAKCQ' ||
                                        response.data.quote.breakInStatus === undefined) {
                                        CommonServices.breakInOccured = response.data.quote.breakInOccured;
                                        coverageType = response.data.quote.cover;
                                        if (response.data.quote.genNewQuoteMsg === undefined) { } else {
                                            if (CommonServices.deviceType !== "NA") {
                                                navigator.notification.alert(response.data.quote.genNewQuoteMsg, null, "Alert", 'ok');
                                            } else {
                                                CommonServices.showAlert(response.data.quote.genNewQuoteMsg);
                                            }
                                        }
                                        $scope.continueRenewalProcess(response);
                                        $scope.getDetailsGVW(response); //CR_3460
                                    } else if (response.data.quote.breakInStatus === 'BREAKPUP') {
                                        if (CommonServices.deviceType !== "NA") {
                                            navigator.notification.alert("Vehicle's Photo uploads are pending. Please upload the same using mobile app.", null, "Alert", 'ok');
                                        } else {
                                            CommonServices.showAlert("Vehicle's Photo uploads are pending. Please upload the same using mobile app.");
                                        }
                                    } else if (response.data.quote.breakInStatus === 'BREAKPU') {
                                        if (CommonServices.deviceType !== "NA") {
                                            navigator.notification.alert('Break In approval is pending with NIA office user', null, "Alert", 'ok');
                                        } else {
                                            CommonServices.showAlert("Break In approval is pending with NIA office user.");
                                        }
                                    } else if (response.data.quote.breakInStatus === 'BREAKREJ') {
                                        if (CommonServices.deviceType !== "NA") {
                                            navigator.notification.alert('Quote has been rejected', null, "Alert", 'ok');
                                        } else {
                                            CommonServices.showAlert("Quote has been rejected");
                                        }
                                    } else if (response.data.quote.breakInStatus === 'BREAKAPP') {
                                        proceedToQP(CommonServices.QRrenewalData);
                                    } else {
                                        $scope.continueRenewalProcess(response);
                                        $scope.getDetailsGVW(response); //CR_3460
                                    }
                                } else {
                                    $scope.continueRenewalProcess(response);
                                    $scope.getDetailsGVW(response); //CR_3460
                                }
                            } else {
                                if (response.data.quote.breakInOccured === 'Y') {
                                    CommonServices.setCommonData("coverageType", response.data.quote.cover);
                                    if (response.data.quote.breakInStatus === 'BREAKCRNWL' || response.data.quote.breakInStatus === 'BREAKCQ' ||
                                        response.data.quote.breakInStatus === undefined) {
                                        CommonServices.breakInOccured = response.data.quote.breakInOccured;
                                        coverageType = response.data.quote.cover;
                                        if (response.data.quote.genNewQuoteMsg === undefined) { } else {
                                            // if (CommonServices.deviceType !== "NA") {
                                            //     navigator.notification.alert(response.data.quote.genNewQuoteMsg, null, "Alert", 'ok');
                                            // } else {
                                            //     CommonServices.showAlert(response.data.quote.genNewQuoteMsg);
                                            // }
                                            CommonServices.showAlert(response.data.quote.genNewQuoteMsg);
                                        }
                                        $scope.continueRenewalProcess(response);
                                        $scope.getDetailsGVW(response); //CR_3460
                                    } else if (response.data.quote.breakInStatus === 'BREAKPUP') {
                                        // if (CommonServices.deviceType !== "NA") {
                                        //     navigator.notification.alert("Vehicle's Photo uploads are pending. Please upload the same using mobile app.", null, "Alert", 'ok');
                                        // } else {
                                        //     CommonServices.showAlert("Vehicle's Photo uploads are pending. Please upload the same using mobile app.");
                                        // }
                                        CommonServices.showAlert("Vehicle's Photo uploads are pending. Please upload the same using mobile app.");
                                    } else if (response.data.quote.breakInStatus === 'BREAKPU') {
                                        // if (CommonServices.deviceType !== "NA") {
                                        //     navigator.notification.alert('Break In approval is pending with NIA office user', null, "Alert", 'ok');
                                        // } else {
                                        //     CommonServices.showAlert("Break In approval is pending with NIA office user.");
                                        // }
                                        CommonServices.showAlert("Break In approval is pending with NIA office user.");
                                    } else if (response.data.quote.breakInStatus === 'BREAKREJ') {
                                        // if (CommonServices.deviceType !== "NA") {
                                        //     navigator.notification.alert('Quote has been rejected', null, "Alert", 'ok');
                                        // } else {
                                        //     CommonServices.showAlert("Quote has been rejected");
                                        // }
                                        CommonServices.showAlert("Quote has been rejected");
                                    } else if (response.data.quote.breakInStatus === 'BREAKAPP') {
                                        proceedToQP(CommonServices.QRrenewalData);
                                    } else {
                                        $scope.continueRenewalProcess(response);
                                        $scope.getDetailsGVW(response); //CR_3460
                                    }
                                } else {
                                    $scope.continueRenewalProcess(response);
                                    $scope.getDetailsGVW(response); //CR_3460
                                }
                            }
                        //} // 3712 bracket opens when above if loop opens
                    } else {

                        if (CommonServices.qrScannerData.oldPolicyNumberFromScanner != undefined) {
                            $scope.quotePolicyNum = "";
                        }

                        CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
                    }
                } else {

                    if (CommonServices.qrScannerData.oldPolicyNumberFromScanner != undefined) {
                        $scope.quotePolicyNum = "";
                    }
                    CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
                }
            },
                function (error) { // failure 
                    CommonServices.showLoading(false);
                    RestServices.handleWebServiceError(error);
                });
        }
    };
    /* Start changes for CR_3460*/
    $scope.getDetailsGVW = function (response = '') {
        if (response != '' && response.data.quote.productCode === "CV") {
            if (response.data.quote.vehicles[0].vehicleDetails.typeOfCommercialVehicles === "C") {  //CR_3633
                //  CommonServices.showAlert("If there is a change in Gross vehicle weight as per RC then please proceed with Normal renewal or connect with New India Assurance branch");
                //  CommonServices.showAlert("if the vehicle insured is a School Bus,then Please contact nearest NIA Branch Office to make changes else proceed further."); //CR_3633
                $scope.alertArr = [ "If there is a change in Gross vehicle weight as per RC then please proceed with Normal renewal or connect with New India Assurance branch",
                "If the vehicle insured is a School Bus,then Please contact nearest NIA Branch Office to make changes else proceed further."];
                return alertArr ; //CR_3633
            } else {
                // CommonServices.showAlert("If there is a change in Gross vehicle weight as per RC then please proceed with Normal renewal or connect with New India Assurance branch"); 
                $scope.alertArr = ["If there is a change in Gross vehicle weight as per RC then please proceed with Normal renewal or connect with New India Assurance branch"] ;
                return alertArr;
            }
        }
    }
    /* End changes for CR_3460*/
    $scope.continueRenewalProcess = function (response) {

        //addedd as part of CR_NP_646E

        // if(response.data.quote.breakInOccured ==="Y"){
        //             if (response.data.quote.prevPolProductCode === "UK" && response.data.quote.productCode === "UK"){
        //                                     CommonServices.showLoading(false);
        //                                     CommonServices.showAlert('We find there is a break in insurance and you will not be able to avail policy online. Contact nearest NIA office for more information.');
        //                                     return;
        //                             }
        // } 



        if (response.data.quote.prevPolProductCode != undefined) {
            if (response.data.quote.prevPolProductCode === "UK") {
                if (response.data.quote.productCode === "NF" || response.data.quote.productCode === "NP" || response.data.quote.productCode === "SC" || response.data.quote.productCode === "HN" || response.data.quote.productCode === "AK") {
                    CommonServices.showLoading(false);
                    CommonServices.showAlert("This is a migrated policy. Migration of New India Mediclaim to any other health product is not allowed online. Please visit nearest New India office.");
                    return;
                }
            }
        }


        if (response.data.quote.currentStatus === "RENEWAL IN PROGRESS") {
            CommonServices.processType = "QR";
            if (response.data.quote.payment.paymentDetailsList[0].collectionAllowedStatus === "Yes") {
                proceedToRenewal(response);
            } else {
                if (response.data.quote.breakInOccured === 'Y') {
                    proceedToRenewal(response);
                } else {
                    CommonServices.showAlert("Dear Customer, As the quote you tried to purchase has a risk coverage from a date prior to today, you need to contact the nearest NIA branch to prepare a fresh quote.");
                }
            }
        } else if ((response.data.quote.currentStatus === "APPROVED APPLICATION" || response.data.quote.currentStatus === "RENEWED POLICY") && response.data.quote.payment.paymentDetailsList[0].collectionStatus === "Collection is not done for this quote number") {
            if (response.data.quote.breakInOccured === 'Y') {
                /*Added during CR_NP_0546C*/
                // if (response.data.quote.productCode === "AK" || response.data.quote.productCode === "NP" || response.data.quote.productCode === "TU" || response.data.quote.productCode === "UK" || response.data.quote.productCode === "RK" || (response.data.quote.productCode === "PC" || response.data.quote.productCode === "CV" || response.data.quote.productCode === "TW" || response.data.quote.productCode === "SS" || response.data.quote.productCode === "SQ" && CommonServices.getCommonData("coverageType") !== "LIABILITY")) { /* CR_NP_3621 */
                    proceedToQP(CommonServices.QRrenewalData);
                // } else {
                //     proceedToRenewal(response);
                // } //Removed as part of CR 3705_B
                /*CR_NP_0546C changes ends*/
            } else {
                if (response.data.quote.productCode === 'NM' || response.data.quote.productCode === 'MC') {
                    $scope.continueRenew(CommonServices.QRrenewalData);
                } else {
                    proceedToQP(CommonServices.QRrenewalData);
                }
            }
        } else if (response.data.quote.currentStatus === "REJECTED APPLICATION") {
            CommonServices.showAlert("Quote/Policy number is rejected");
        } else if (response.data.quote.currentStatus === "EXPIRED/MATURED") {
            CommonServices.showAlert("Your quote/policy no. is not applicable for quick renewal/payment. Please contact your nearest NIA office !");
        } else {
            CommonServices.showAlert("Could not connect to the server.\nPlease check after sometime");
        }
    }

    function proceedToRenewal(response) {
        collectionNotDone = false;
        if (response.data.quote.productCode === "TW" || response.data.quote.productCode === "PC" || response.data.quote.productCode === "CV" || response.data.quote.productCode === "SQ" || response.data.quote.productCode === "SS") { /* CR_NP_3621 */
            CommonServices.isMotor = true;
            CommonServices.NmMcProduct = false;
            if (response.data.quote.vehicles[0].vehicleDetails.registrationNo1 === undefined) {
                CommonServices.setCommonData("vehicleRegNo1", "NEW");
            } else {
                CommonServices.setCommonData("vehicleRegNo1", response.data.quote.vehicles[0].vehicleDetails.registrationNo1.toUpperCase());
            }
            if (CommonServices.getCommonData("vehicleRegNo1") !== "NEW") {
                if (response.data.quote.vehicles[0].vehicleDetails.registrationNo2 === undefined) {
                    CommonServices.setCommonData("vehicleRegNo2", "");
                } else {
                    CommonServices.setCommonData("vehicleRegNo2", response.data.quote.vehicles[0].vehicleDetails.registrationNo2.toUpperCase());
                }
                if (response.data.quote.vehicles[0].vehicleDetails.registrationNo3 === undefined) {
                    CommonServices.setCommonData("vehicleRegNo3", "");
                } else {
                    CommonServices.setCommonData("vehicleRegNo3", response.data.quote.vehicles[0].vehicleDetails.registrationNo3.toUpperCase());
                }
                if (response.data.quote.vehicles[0].vehicleDetails.registrationNo4 === undefined) {
                    CommonServices.setCommonData("vehicleRegNo4", "");
                } else {
                    CommonServices.setCommonData("vehicleRegNo4", response.data.quote.vehicles[0].vehicleDetails.registrationNo4);
                }
                if (response.data.quote.vehicles[0].vehicleDetails.dateOfRegistration === undefined) {
                    CommonServices.setCommonData("regDate", "");
                } else {
                    CommonServices.setCommonData("regDate", response.data.quote.vehicles[0].vehicleDetails.dateOfRegistration);
                }
                if (response.data.quote.vehicles[0].vehicleDetails.registrationExpiryDate === undefined) {
                    CommonServices.setCommonData("regValidityDate", "");
                } else {
                    CommonServices.setCommonData("regValidityDate", response.data.quote.vehicles[0].vehicleDetails.registrationExpiryDate);
                }
                if (response.data.quote.vehicles[0].vehicleDetails.engineNo === undefined) {
                    CommonServices.setCommonData("engineNo", "");
                } else {
                    CommonServices.setCommonData("engineNo", response.data.quote.vehicles[0].vehicleDetails.engineNo.toUpperCase());
                }
                if (response.data.quote.vehicles[0].vehicleDetails.chassisNo === undefined) {
                    CommonServices.setCommonData("chassisNo", "");
                } else {
                    CommonServices.setCommonData("chassisNo", response.data.quote.vehicles[0].vehicleDetails.chassisNo.toUpperCase());
                }
                if (response.data.quote.vehicles[0].vehicleDetails.colorAsPerRCbook === undefined) {
                    CommonServices.setCommonData("colorAsPerRCbook", "");
                } else {
                    CommonServices.setCommonData("colorAsPerRCbook", response.data.quote.vehicles[0].vehicleDetails.colorAsPerRCbook.toUpperCase());
                }
                if (CommonServices.isVehRegFieldsValid()) {
                    var reg1 = CommonServices.getCommonData("vehicleRegNo1");
                    var statecode = reg1.substring(0, 2).toUpperCase();
                    var stateCodeData = {
                        "stateCode": statecode
                    };
                    var stateCodeResponse = RestServices.postService(RestServices.urlPathsNewPortal.stateCode, stateCodeData);
                    stateCodeResponse.then(
                        function (response) { // success
                            CommonServices.showLoading(false);
                            if (response.data.footer.status === "State code is valid") {
                                if (CommonServices.getCommonData("regDate") === '01/01/0001' || CommonServices.getCommonData("regValidityDate") === '01/01/0001') {
                                    $location.path('/newRenewPolicy/vehicleReg');
                                } else {
                                    $location.path('/newRenewPolicy/policyDetails');
                                }
                            } else {
                                CommonServices.stateCodeValid = false;
                                $location.path('/newRenewPolicy/vehicleReg');
                            }
                        },
                        function (error) { // failure
                            CommonServices.showLoading(false);
                            RestServices.handleWebServiceError(error);
                            return false;
                        });
                } else {
                    $location.path('/newRenewPolicy/vehicleReg');
                }
            } else {
                if (response.data.quote.vehicles[0].vehicleDetails.dateOfRegistration === undefined || response.data.quote.vehicles[0].vehicleDetails.dateOfRegistration === '01/01/0001') {
                    CommonServices.setCommonData("regDate", "");
                } else {
                    CommonServices.setCommonData("regDate", response.data.quote.vehicles[0].vehicleDetails.dateOfRegistration);
                }
                if (response.data.quote.vehicles[0].vehicleDetails.registrationExpiryDate === undefined || response.data.quote.vehicles[0].vehicleDetails.registrationExpiryDate === '01/01/0001') {
                    CommonServices.setCommonData("regValidityDate", "");
                } else {
                    CommonServices.setCommonData("regValidityDate", response.data.quote.vehicles[0].vehicleDetails.registrationExpiryDate);
                }
                if (response.data.quote.vehicles[0].vehicleDetails.engineNo === undefined) {
                    CommonServices.setCommonData("engineNo", "");
                } else {
                    CommonServices.setCommonData("engineNo", response.data.quote.vehicles[0].vehicleDetails.engineNo.toUpperCase());
                }
                if (response.data.quote.vehicles[0].vehicleDetails.chassisNo === undefined) {
                    CommonServices.setCommonData("chassisNo", "");
                } else {
                    CommonServices.setCommonData("chassisNo", response.data.quote.vehicles[0].vehicleDetails.chassisNo.toUpperCase());
                }
                if (response.data.quote.vehicles[0].vehicleDetails.colorAsPerRCbook === undefined) {
                    CommonServices.setCommonData("colorAsPerRCbook", "");
                } else {
                    CommonServices.setCommonData("colorAsPerRCbook", response.data.quote.vehicles[0].vehicleDetails.colorAsPerRCbook.toUpperCase());
                }
                $location.path('/newRenewPolicy/vehicleReg');
            }
        } else {
            CommonServices.isMotor = false;
            CommonServices.optRoomRentRiderOption = false;
            if (response.data.quote.prevPolProductCode !== undefined) {
                /*******cr 885 Changes starst **********/

                if ((response.data.quote.prevPolProductCode === "HN" && response.data.quote.productCode !== "HN") || (response.data.quote.prevPolProductCode !== "HN" && response.data.quote.productCode === "HN")) {
                    if (response.data.quote.prevPolProductCode === "HN" && response.data.quote.productCode !== "HN") {
                        CommonServices.showAlert("This is a migrated policy. Migration of New India Premier Mediclaim to any other health product is not allowed online. Please visit nearest New India office for assistance.");
                    } else {
                        CommonServices.showAlert("This is a migrated policy. Migration of New India Premier Mediclaim to/from any other health product is not allowed online. Please visit nearest New India office for assistance.");
                    }


                } else {

                    if (response.data.quote.breakInOccured === "Y") {
                        /*Added during CR_NP_0546C*/
                        if (response.data.quote.productCode === "AK" || response.data.quote.productCode === "NP" || response.data.quote.productCode === "TU"
                            /****changes of CR_859  starts ****/
                            || response.data.quote.productCode === "RK") {

                            if (response.data.quote.productCode === "RK") {
                                CommonServices.showBreakInDisclaimerInDetails = false;
                            } else {
                                CommonServices.showBreakInDisclaimerInDetails = true;
                            }


                            $scope.continueRenew(CommonServices.QRrenewalData);

                            /****changes of CR_859  ends ****/
                        } else {
                            /*Below line Added during CR_NP_0546C*/

                            CommonServices.showBreakInDisclaimerInDetails = false;
                            /********CR 885 starst**********/
                            if (response.data.quote.productCode === "UK" || response.data.quote.productCode === "HN" || response.data.quote.productCode === 'CJ') { //CR_3725 - sudip
                                CommonServices.showBreakInDisclaimerInDetails = true;
                            }
                            /********CR 885 ends**********/
                            var alertMsg = "There is a break-in -insurance in your policy. We will accept the renewal of the policy if it is within 30 days of the expiry of Period of Insurance. We however shall not be liable for any claim arising out of Illness contracted or Injury sustained or Hospitalization commencing in the interim period after expiry of the earlier Policy and prior to date of commencement of subsequent Policy";
                            CommonServices.messageModal('info', alertMsg, false, 'Cancel', 'Ok', function () {
                                CommonServices.showAlert("Please contact the nearest New India Office for assistance");
                                $scope.home();
                            }, function () {
                                $scope.continueRenew(CommonServices.QRrenewalData);
                            }, 'Confirm');

                            // if (CommonServices.deviceType != "NA") {
                            //     navigator.notification.confirm(alertMsg, $scope.confirmBreakIn, "Confirm", ["OK", "Cancel"]);
                            // } else {
                            //     var NMtoUKMigrationConfirm = confirm(alertMsg);
                            //     if (NMtoUKMigrationConfirm == true) {
                            //         $scope.continueRenew(CommonServices.QRrenewalData);
                            //     } else {
                            //         CommonServices.showAlert("Please contact the nearest New India Office for assistance");
                            //         $scope.home();
                            //     }
                            // }
                        }
                        /*CR_NP_0546C changes Ends */

                    } else {
                        /*Below line Added during CR_NP_0546C*/
                        CommonServices.showBreakInDisclaimerInDetails = false;
                        $scope.continueRenew(CommonServices.QRrenewalData);
                    }

                }
                /*******cr 885 Changes ends **********/

            } else {
                $scope.continueRenew(CommonServices.QRrenewalData);
            }
        }
    }

    $scope.collectionNotDoneFunction = function (button) {
        if (button === 1) {
            var domainData = {
                "lngCode": "EN",
                "keys": ["CHEQUE_PO_DRAFT_TYPE"]
            };
            var getDomainResponse = "";
            getDomainResponse = RestServices.postService(RestServices.urlPathsNewPortal.getDomainValues, domainData);
            getDomainResponse.then(
                function (response) {
                    CommonServices.showLoading(false);
                    for (var i = 0; i < response.data.domainValues.length; i++) {
                        var chequeTypes = {
                            'name': response.data.domainValues[i].mnemonic
                        };
                        CommonServices.chequeList.push(chequeTypes);
                    }
                    CommonServices.managePolicyCollection = false;
                    $state.go('newRenewPolicy.collectionForm');
                },
                function (error) {
                    CommonServices.showLoading(false);
                    RestServices.handleWebServiceError(error);
                });
        }
    };

    function proceedToQP(response) {
        CommonServices.saveQuoteDetailsData = response;
        CommonServices.processType = "QP";
        if (response.quote.payment.paymentDetailsList[0].collectionAllowedStatus === "Yes") {
            if (response.quote.policyNumber === "" || response.quote.policyNumber === undefined) {
                msg = "Dear User,\nThe proposal having quote no." + CommonServices.RenewalPolData.quote.quoteNumber + " is already approved. Please proceed to make a payment.";
            } else {
                msg = "Dear User,\nThe proposal for policy no " + CommonServices.RenewalPolData.quote.policyNumber + " having quote no " + CommonServices.RenewalPolData.quote.quoteNumber + " is already approved. Please proceed to make a payment.";
                collectionNotDone = true;
            }

            $scope.collectionNotDoneFunction(1); // Comment for 3546

            // // Uncomment for CR_3546
            // CommonServices.messageModal('info', msg, false, 'Add to Cart', 'Continue to Pay', function () { 
            //     CartServices.saveToCart(response.quote.quoteNumber);
            // }, function () { $scope.collectionNotDoneFunction(1); }, 'Alert', true, true);
            
        } else {
            msg = "Dear Customer, As the quote you tried to purchase has a risk coverage from a date prior to today, you need to contact the nearest NIA branch to prepare a fresh quote.";
            CommonServices.showAlert(msg);
        }
    }

    $scope.confirmBreakIn = function (button) {
        if (button === 1) {
            $scope.continueRenew(CommonServices.QRrenewalData);
        } else {
            CommonServices.showAlert("Please contact the nearest New India Office for assistance");
            $scope.home();
        }
    }

    $scope.continueRenew = function (response) {
        if (response.quote.prevPolProductCode === "NM" || response.quote.prevPolProductCode === "MC") {
            CommonServices.NmMcProduct = true;
            CommonServices.RenewalPolData.quote.productName = "New India Mediclaim";
            var alertMsg;
            if (response.quote.prevPolProductCode === "NM") {
                alertMsg = "Mediclaim 2012 Policy has been discontinued. If you wish to renew your Policy, you can migrate to New India Mediclaim Policy";
            } else if (response.quote.prevPolProductCode === "MC") {
                alertMsg = "Mediclaim 2007 Policy has been discontinued. If you wish to renew your Policy, you can migrate to New India Mediclaim Policy";
            } else {
                alertMsg = "Please contact the nearest New India Office for assistance";
            }
            if (CommonServices.deviceType != "NA") {
                navigator.notification.confirm(alertMsg, $scope.getRenQuoteDetailsServiceCall, "Confirm", ["OK", "Cancel"]);
            } else {
                var NMtoUKMigrationConfirm = confirm(alertMsg);
                if (NMtoUKMigrationConfirm == true) {
                    $scope.getRenQuoteDetailsServiceCall(1);
                } else {
                    CommonServices.showAlert("Please contact the nearest New India Office for assistance");
                    $scope.home();
                }
            }
        } else {
            CommonServices.NmMcProduct = false;
            //$location.path('/newRenewPolicy/policyDetails');
            //CR3845 changes
            if(response.quote.prevPolProductCode=='UK' || response.quote.prevPolProductCode=='HN' || response.quote.prevPolProductCode=='TU' || response.quote.prevPolProductCode=='NP' || response.quote.prevPolProductCode=='AK' || response.quote.prevPolProductCode=='CJ'){
                $scope.getTPAList(response.quote.quoteNumber);
            }else{

                $state.go("newRenewPolicy.policyDetails");
            }
        }
    }

        //CR3845 changes
        $scope.getTPAList = function(quoteNo){
        
            let tpaDetails = null;
            CommonServices.setCommonData("tpaDetails",tpaDetails);
            let reqData = {
                "userCode": CommonServices.getCommonData("userId"),
                "stakeCode": CommonServices.getCommonData("stakeCode").toUpperCase(),
                // "stateCode" : CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.state,
                branchCode: CommonServices.getCommonData("LoginData").branchCode,
                "quoteNumber" : quoteNo
            }
    
            let getTPAListResponse = RestServices.postService(RestServices.urlPathsNewPortal.getTPAList, reqData);
            getTPAListResponse.then(
                function (response) { //success
                    
                    CommonServices.showLoading(false);
                    if (response.data.hasOwnProperty('errorMessage')) {
                        CommonServices.showLoading(false);
                        CommonServices.showAlert(response.data.errorMessage);
                    } else {
                       
                       let tpaList = (response.data && response.data.tpaList.length)?response.data.tpaList:[];
                       tpaList.forEach(item=>{
                            if(item.indicator==='D') tpaDetails = item;
                            else if(item.indicator==='Y') tpaDetails = item;
                       });
    
                       if(tpaDetails && tpaDetails!=null){
                           CommonServices.setCommonData("tpaDetails",tpaDetails);
                           $state.go("newRenewPolicy.policyDetails");
                       }else{
                           CommonServices.showAlert("No TPA found");
                       } 
                    }
    
                }, function (error) { //failure
                    CommonServices.showLoading(false);
                    RestServices.handleWebServiceError(error);
                }
            );
    
        }  
    
    $scope.getRenQuoteDetailsServiceCall = function (button) {
        if (button === 1) {
            var productCodeGetReneQuote;
            if (CommonServices.RenewalPolData.quote.productCode === 'NM') {
                productCodeGetReneQuote = "UK";
            } else if (CommonServices.RenewalPolData.quote.productCode === 'MC') {
                productCodeGetReneQuote = "UK";
            } else {
                productCodeGetReneQuote = CommonServices.RenewalPolData.quote.productCode
            }
            var getRenQuoteInput = {
                "userProfile": {
                    "userId": CommonServices.getCommonData("userCode").toUpperCase(),
                    "loggedInRole": CommonServices.getCommonData("loggedInRole").toUpperCase()
                },
                "quote": {
                    "policyNumber": CommonServices.RenewalPolData.quote.policyNumber,
                    "productCode": productCodeGetReneQuote
                },
                //3444
                "vehicles": [{
                    "vehicleDetails":
                    {
                        "doYouHoldValidDrivingLicense": $rootScope.buyNow.twoWheeler.addCovers.ownerDriveVehOrNotTW !== undefined ? $rootScope.buyNow.twoWheeler.addCovers.ownerDriveVehOrNotTW : "", "newVehicle": $rootScope.buyNow.twoWheeler.newVehicle !== undefined ? $rootScope.buyNow.twoWheeler.newVehicle : "",

                    }
                }]
            };

            var getRenQuoteDetailsResponse = RestServices.postService(RestServices.urlPathsNewPortal.getQRRenQuoteDetails, getRenQuoteInput);
            if (getRenQuoteDetailsResponse === undefined) {

            } else {
                getRenQuoteDetailsResponse.then(function (response) { // success
                    CommonServices.showLoading(false);
                    if (response.data.userProfile.footer.errorCode === '0') {
                        CommonServices.getRenQuotDataObj = response.data;
                        if (response.data.quote.genNewQuoteMsg !== undefined) {
                            var alertMsg = "A new Quote Number " + response.data.quote.quoteNumber + " will be used for renewing the policy";

                            if (CommonServices.deviceType != "NA") {
                                navigator.notification.confirm(alertMsg, $scope.newQuoteNoCall, "Alert", ["OK"]);
                            } else {
                                var NMtoUKMigrationConfirm = confirm(alertMsg);
                                if (NMtoUKMigrationConfirm == true) {
                                    geteditQuoteServiceCall();
                                } else {
                                    CommonServices.showAlert("Please contact the nearest New India Office for assistance");
                                    $scope.home();
                                }
                            }
                            // CommonServices.showAlert("A new Quote Number "+ response.data.quote.quoteNumber+ " will be used for renewing the policy");

                            //CommonServices.showAlert(response.data.quote.genNewQuoteMsg);
                        } else {
                            geteditQuoteServiceCall();
                        }


                    } else {
                        CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
                    }
                }, function (error) { // failure
                    CommonServices.showLoading(false);
                    RestServices.handleWebServiceError(error);
                });
            }

        } else {
            CommonServices.showAlert("Please contact the nearest New India Office for assistance");
            $scope.home();
        }
    }

    $scope.newQuoteNoCall = function (button) {
        geteditQuoteServiceCall();
    }

    function geteditQuoteServiceCall() {
        var editQuoteData;

        editQuoteData = {
            "userProfile": {
                "userId": CommonServices.getCommonData("userCode").toUpperCase(),
                "loggedInRole": CommonServices.getCommonData("loggedInRole")
            },
            "quote": {
                "quoteNumber": CommonServices.getRenQuotDataObj.quote.quoteNumber,
                "policyNumber": "",
                "processType": "NB",
                "productCode": CommonServices.getRenQuotDataObj.quote.productCode
            }
        };

        var getEditQuoteResponse = "";
        getEditQuoteResponse = RestServices.postService(RestServices.urlPathsNewPortal.editQuote, editQuoteData);
        if (getEditQuoteResponse === undefined) { } else {
            getEditQuoteResponse.then(
                function (response) {
                    console.log("getEditQuoteResponse" + response);
                    CommonServices.showLoading(false);
                    if (response.data.userProfile.footer.errorCode === '0') {
                        CommonServices.editQuoteInsured = response.data.quote;
                        CommonServices.editQuoteResponse = response.data;
                        $scope.policyData = response.data;
                        CommonServices.showAlert("Please keep Member's Identity card ready for smooth transition");
                        //angular.extend($scope.policyData,response.data);
                        CommonServices.setCommonData("productCode", response.data.quote.productCode);

                        if (response.data.quote.relationDeletionFlag === "Y") {
                            relationDeletedNmMc();
                        } else {
                            $state.go("newRenewPolicy.NmMcToUkMigration");
                        }
                    } else {
                        CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
                    }
                },
                function (error) {
                    CommonServices.showLoading(false);
                    RestServices.handleWebServiceError(error);
                });
        }
    };

    function relationDeletedNmMc() {
        var relationDeletedMsg = "The expiring policy has relationship " + CommonServices.editQuoteInsured.relationToBeDeleated + " Through online channels coverage in New India Mediclaim is offered for Proposer, Spouse, Parents and Children only. If you wish to proceed without this relation please click ‘Ok’ to proceed. Policy will be issued without this relation. If you do not wish to proceed please click ‘Cancel’ and visit our nearest office for policy issuance";
        if (CommonServices.deviceType != "NA") {
            navigator.notification.confirm(relationDeletedMsg, $scope.relationDeleteConfirm, "Confirm", ["OK", "Cancel"]);
        } else {
            var NMtoUKMigrationConfirm = confirm(relationDeletedMsg);
            if (NMtoUKMigrationConfirm == true) {
                $scope.relationDeleteConfirm(1);
            } else {
                $scope.home();
            }
        }
    };

    $scope.relationDeleteConfirm = function (button) {
        if (button === 1) {
            $state.go("newRenewPolicy.NmMcToUkMigration");
        } else {
            $scope.home();
        }
    }
}]);

agentApp.controller('NmMcToUkMigrationCtrl', ['$scope', '$location', 'RestServices', 'CommonServices', '$state', function ($scope, $location, RestServices, CommonServices, $state) {

    $scope.maternityExpSI = false;

    function setOccupation(occupationCode) {
        switch (occupationCode) {
            case "PAM":
            case "PROFESSION":
                return "Professional/Administrative/Managerial";
            case "BT":
            case "BUSINESS":
                return "Business /Traders";
            case "CS":
            case "CLERK":
                return "Clerical, Supervisory and related workers";
            case "HS":
            case "SUPPORT":
            case "HOSPITAL":
                return "Hospitality and Support Workers";
            case "PW":
            case "LABOUR":
            case "PRODUCTION":
                return "Production Workers, Skilled and non-Agricultural Laborers";
            case "FA":
            case "AGRICULTUR":
            case "FARMERS":
                return "Farmers and Agricultural Workers";
            case "PPMD":
            case "SERVICE":
            case "POLICE":
                return "Police/Para Military/Defense";
            case "Housewives":
            case "HOUSEWIFE":
            case "WIFE":
                return "Housewives";
            case "RP":
            case "RETIRED":
                return "Retired Persons";
            case "Students":
            case "STUDENT":
            case "STUDENTS":
                return "Students – School and College";
            case "Any Other":
            case "OTHERS":
                return "Any Other";
            default:
                return "";
        }
    }

    function setUKOccupation(pOccupation) {
        switch (pOccupation) {
            case "Professional/Administrative/Managerial":
                return "PAM";
            case "Business /Traders":
                return "BT";
            case "Clerical, Supervisory and related workers":
                return "CS";
            case "Hospitality and Support Workers":
                return "HS";
            case "Production Workers, Skilled and non-Agricultural Laborers":
                return "PW";
            case "Farmers and Agricultural Workers":
                return "FA";
            case "Police/Para Military/Defense":
                return "PPMD";
            case "Housewives":
                return "Housewives";
            case "Retired Persons":
                return "RP";
            case "Students – School and College":
                return "Students";
            case "Any Other":
                return "Any Other";
            default:
                return "";
        }
    }

    function getGender(gender) {
        if (gender === "M") {
            return "Male";
        } else if (gender === "F") {
            return "Female";
        } else if (gender === "T"){
            return "Third Gender";
        }
    }

    function getSumInsured(SumInsured) {
        switch (SumInsured) {
            case "125000":
            case "150000":
            case "175000":
                return "200000";
            case "225000":
            case "250000":
            case "275000":
                return "300000";
            case "350000":
                return "400000";
            case "450000":
                return "500000";
            default:
                return SumInsured;
        }
    }
    var members = [];
    for (var i = 0; i < CommonServices.editQuoteInsured.risks.length; i++) {
        if (CommonServices.editQuoteInsured.risks[i].riskDetails.relationWithPolicyHolder === undefined) {

        } else {
            members.push(CommonServices.editQuoteInsured.risks[i]);
        }
    }
    console.log(members);
    var memberDetails = members;
    CommonServices.editQuoteInsured.risks = members;

    var memberDetails = CommonServices.editQuoteInsured.risks;
    for (var i = 0; i < memberDetails.length; i++) {
        memberDetails[i].riskDetails.occupation = setOccupation(memberDetails[i].riskDetails.occupation);
        memberDetails[i].riskDetails.sex = getGender(memberDetails[i].riskDetails.sex);
        memberDetails[i].riskSumInsured = parseInt(getSumInsured(memberDetails[i].riskSumInsured));
        memberDetails[i].riskDetails.maternityExpense = CommonServices.editQuoteInsured.risks[i].riskDetails.maternityExpense;
        if (memberDetails[i].riskDetails.natureOfId === undefined || memberDetails[i].riskDetails.natureOfId === "") {
            memberDetails[i].selectNatureIdErr = true;
            /*CR_NP_0744E starts*/
            memberDetails[i].aadhaarChangeMessage = "";
        } else if (memberDetails[i].riskDetails.natureOfId === "AD") { // This else-if condition added for CR_NP_0744E
            memberDetails[i].selectNatureIdErr = true;
            memberDetails[i].riskDetails.natureOfId = "";
            CommonServices.editQuoteInsured.risks[i].riskDetails.iDDocNo = undefined;
            memberDetails[i].aadhaarChangeMessage = "Due to regulatory constraint Aadhaar document cannot be taken online. Please select other available ID";
        } else {
            memberDetails[i].aadhaarChangeMessage = "";
            /*CR_NP_0744E ends*/
            memberDetails[i].selectNatureIdErr = false;
        }
        if (CommonServices.editQuoteInsured.risks[i].riskDetails.anyOtherId === undefined) {
            memberDetails[i].anyOtherIdErr = false;
        } else {
            if (patternCheck(CommonServices.editQuoteInsured.risks[i].riskDetails.anyOtherId)) {
                memberDetails[i].anyOtherIdErr = false;
            } else {
                memberDetails[i].anyOtherIdErr = true;
            }
        }
        if (CommonServices.editQuoteInsured.risks[i].riskDetails.iDDocNo === undefined) {
            memberDetails[i].IdDocNo = true;
        } else {
            if (patternCheck(CommonServices.editQuoteInsured.risks[i].riskDetails.iDDocNo)) {
                memberDetails[i].iDDocNo = false;
            } else {
                memberDetails[i].iDDocNo = true;
            }
        }

    }
    $scope.insuredMembers = memberDetails;

    if (CommonServices.editQuoteInsured.optionalCoverINoProportionateDeduction === "Y") {
        document.getElementById("propotionateChoiceYes").checked = true;
    } else {
        document.getElementById("propotionateChoiceNo").checked = true;
    }
    if (CommonServices.editQuoteInsured.optionalCoverIIIRevisioninCataractLimit === "Y") {
        document.getElementById("cataractChoiceYes").checked = true;
    } else {
        document.getElementById("cataractChoiceNo").checked = true;
    }
    if (CommonServices.editQuoteInsured.optionalCoverIVVoluntaryCopay === "Y") {
        document.getElementById("coPayChoiceYes").checked = true;
    } else {
        document.getElementById("coPayChoiceNo").checked = true;
    }

    function patternCheck(value) {
        var regExp = /^[a-zA-Z0-9@#$%^&*()_+\-=\[\]{};':\\|,.<>\/? ]*$/;
        if (regExp.test(value)) {
            return true;
        } else {
            return false;
        }
    }

    $scope.idValueChanged = function (index) {
        var value = $("#anyOtherID_" + index).context.activeElement.value;
        if (patternCheck(value)) {
            $scope.insuredMembers[index].anyOtherIdErr = false;
        } else {
            $scope.insuredMembers[index].anyOtherIdErr = true;
        }
    }

    $scope.idDocValueChanged = function (index) {
        var value = $("#IdDocNo_" + index).context.activeElement.value;
        if (patternCheck(value)) {
            $scope.insuredMembers[index].IdDocNo = false;
        } else {
            $scope.insuredMembers[index].IdDocNo = true;
        }
    }

    $scope.idChanged = function (idValue, index) {
        // Below line added for CR_NP_0744E
        $scope.insuredMembers[index].showAnyOtherMessage = "";

        $scope.insuredMembers[index].selectNatureIdErr = false;
        if (idValue !== "AO") {
            $scope.insuredMembers[index].anyOtherIdErr = true;
            $scope.insuredMembers[index].riskDetails.anyOtherId = "none";
        } else {
            // Below line added for CR_NP_0744E
            $scope.insuredMembers[index].showAnyOtherMessage = "Please upload ID  other than Aadhaar";
            $scope.insuredMembers[index].anyOtherIdErr = false;
            $scope.insuredMembers[index].riskDetails.anyOtherId = "";
        }
    }

    var porpotionateCheck = 0;
    $scope.propotionateSelected = function () {
        if ($("input:radio[name=proportionateDeduction]:checked").val() === 'Y') {
            if (porpotionateCheck === 0) {
                CommonServices.showAlert("The cover shall be available only for those persons with Sum Insured of 2 lakhs and above.");
                porpotionateCheck++;
            } else {
                porpotionateCheck++;
            }
        } else if ($("input:radio[name=proportionateDeduction]:checked").val() === 'N') {
            porpotionateCheck = 0;
        }
    }
    var cataractCheck = 0;
    $scope.cataractSelected = function () {
        if ($("input:radio[name=cataractLimit]:checked").val() === 'Y') {
            if (cataractCheck === 0) {
                CommonServices.showAlert("The cover shall be available only for those persons whose age is 46 years & above with Sum Insured of 8 lakhs and above.");
                cataractCheck++;
            } else {
                cataractCheck++;
            }
        } else if ($("input:radio[name=cataractLimit]:checked").val() === 'N') {
            cataractCheck = 0;
        }
    }

    $scope.migrationDetailSubmit = function () {

        CommonServices.NmMCMandatoryCheck = true;
        //var natureOfID = true;
        for (var i = 0; i < $scope.insuredMembers.length; i++) {
            if (($scope.insuredMembers[i].riskDetails.nameOfInsuredPerson === undefined || $scope.insuredMembers[i].riskDetails.nameOfInsuredPerson === '') || ($scope.insuredMembers[i].riskDetails.occupation === undefined || $scope.insuredMembers[i].riskDetails.occupation === '') || ($scope.insuredMembers[i].riskDetails.sex === undefined || $scope.insuredMembers[i].riskDetails.sex === '')) {
                CommonServices.showAlert("In case any mandatory parameters are incomplete, renewal will be allowed through post login comprehensive renewal from NIA portal or you may visit New India office");
                CommonServices.NmMCMandatoryCheck = false;
                return;
            }

        }
        if (CommonServices.NmMCMandatoryCheck) {
            CommonServices.editQuoteInsured.optionalCoverINoProportionateDeduction = $("input:radio[name=proportionateDeduction]:checked").val();
            CommonServices.editQuoteInsured.optionalCoverIIIRevisioninCataractLimit = $("input:radio[name=cataractLimit]:checked").val();
            CommonServices.editQuoteInsured.optionalCoverIVVoluntaryCopay = $("input:radio[name=coPay]:checked").val();
            for (var i = 0; i < $scope.insuredMembers.length; i++) {
                CommonServices.editQuoteInsured.risks[i].riskDetails.natureOfId = $scope.insuredMembers[i].riskDetails.natureOfId;
                CommonServices.editQuoteInsured.risks[i].riskDetails.anyOtherId = $scope.insuredMembers[i].riskDetails.anyOtherId;
                CommonServices.editQuoteInsured.risks[i].riskDetails.iDDocNo = $scope.insuredMembers[i].riskDetails.iDDocNo;
                if ($scope.insuredMembers[i].riskDetails.sex === "Female") {
                    CommonServices.editQuoteInsured.risks[i].riskDetails.sex = "F";
                } else if ($scope.insuredMembers[i].riskDetails.sex === "Male") {
                    CommonServices.editQuoteInsured.risks[i].riskDetails.sex = "M";
                }
                CommonServices.editQuoteInsured.risks[i].riskDetails.occupation = setUKOccupation($scope.insuredMembers[i].riskDetails.occupation);
                CommonServices.editQuoteInsured.risks[i].riskDetails.maternityExpense = $scope.insuredMembers[i].riskDetails.maternityExpense;
            }
            $state.go('newRenewPolicy.policyDetails');
        }
    }
}]);

agentApp.controller('VehicleRegCtrl', ['$scope', '$location', 'RestServices', 'CommonServices', '$state', function ($scope, $location, RestServices, CommonServices, $state) {

    $scope.policyData = CommonServices.QRrenewalData;
    var regx = /^[a-zA-Z0-9]*$/;
    var regxSpace = /^[a-zA-Z0-9 ]*$/;
    var regxAlpha = /^[a-zA-Z]*$/;
    var regxNum = /^[0-9]*$/;
    var regexAge = /^(?=.*[1-9])\d*$/;//3444
    var regexName = /^[a-zA-Z][a-zA-Z ]*$/;//3444
    $scope.regexNameWithoutSpace = /^[a-zA-Z][a-zA-Z]*$/;//3444
    var veh4 = 0;
    var veh4Value;
    var onBlur = false;
    $scope.veh1Disable = false;
    $scope.veh2Disable = false;
    $scope.veh3Disable = false;
    $scope.veh4Disable = false;
    var disableSubmitBtn = false;
    var checkRegPageValidity = true;
    var regValDate = false;
    var yearRegDate = false;
    var cancelClickRegDate = false;
    var cancelClickRegValidityDate = false;
    var veh1 = true;
    var veh2 = true;
    var veh3 = true;
    var vehicle4 = true;
    $scope.vehicleRegNo1 = CommonServices.getCommonData("vehicleRegNo1");
    $scope.engineNo = CommonServices.getCommonData("engineNo");
    $scope.chassisNo = CommonServices.getCommonData("chassisNo");
    $scope.colorAsPerRCbook = CommonServices.getCommonData("colorAsPerRCbook");

    if ($scope.vehicleRegNo1 == "NEW") {
        $scope.vehicleRegNo1 = "";
        $scope.vehicleRegNo2 = "";
        $scope.vehicleRegNo3 = "";
        $scope.vehicleRegNo4 = "";
        veh1 = false;
        vehicle4 = false;
        $scope.regDate = "";
        $scope.regValidityDate = "";
        cancelClickRegDate = true;
        cancelClickRegValidityDate = true;
        $scope.vehNoError = true;
        $scope.vehicleErrorMsg = "Please enter valid State Code in Reg1";
        CommonServices.stateCodeValid = false;
        $scope.invalidValue = true;
        angular.element(document.querySelector("#submitBtn")).addClass("disableBtn");

    } else {
        $scope.vehicleRegNo2 = CommonServices.getCommonData("vehicleRegNo2");
        $scope.vehicleRegNo3 = CommonServices.getCommonData("vehicleRegNo3");
        $scope.vehicleRegNo4 = parseInt(CommonServices.getCommonData("vehicleRegNo4"));
        veh4Value = CommonServices.getCommonData("vehicleRegNo4");
        if (CommonServices.getCommonData("regDate") === '01/01/0001') {
            $scope.regDate = "";
        } else {
            $scope.regDate = CommonServices.getCommonData("regDate");
        }
        if (CommonServices.getCommonData("regValidityDate") === '01/01/0001') {
            $scope.regValidityDate = "";
        } else {
            $scope.regValidityDate = CommonServices.getCommonData("regValidityDate");
        }
        $scope.vehNoError = true;
        checkDate();
        var errorMsgReg1 = false;
        var errorMsgReg2 = false;
        var errorMsgReg3 = false;
        var errorMsgReg4 = false;

        if (CommonServices.stateCodeValid && regxAlpha.test($scope.vehicleRegNo1)) {
            $scope.veh1Disable = true;
        } else {
            var errorMsgReg1 = true;
        }
        if (validateVehReg2()) {
            $scope.veh2Disable = true;
        } else {
            errorMsgReg2 = true;
        }
        if (validateVehReg3()) {
            $scope.veh3Disable = true;
        } else {
            errorMsgReg3 = true;
        }
        if (validateVehReg4($scope.vehicleRegNo4)) {
            $scope.veh4Disable = true;
        } else {
            errorMsgReg4 = true;
        }

        if (errorMsgReg1) {
            veh1 = false;
            $scope.vehNoError = true;
            if (CommonServices.stateCodeValid == false) {
                $scope.vehicleErrorMsg = "Please enter valid State Code in Reg1";
            }
        } else if (errorMsgReg2) {
            $scope.vehNoError = true;
        } else if (errorMsgReg3) {
            $scope.vehNoError = true;
        } else if (errorMsgReg4) {
            $scope.vehNoError = true;
        } else {
            $scope.vehNoError = false;
        }
        if ($scope.vehNoError === true) {
            $scope.veh1Disable = false;
            $scope.veh2Disable = false;
            $scope.veh3Disable = false;
            $scope.veh4Disable = false;
        }
    }

    if ($scope.engineNo == "" || $scope.engineNo == undefined) {
        $scope.engineDisable = false;
        disableSubmitBtn = true;
    } else {
        if (regx.test($scope.engineNo) == false) {
            $scope.engineDisable = false;
            disableSubmitBtn = true;
        } else {
            if ($scope.engineNo.length < 5) {
                $scope.engineDisable = false;
                disableSubmitBtn = true;
            } else {
                $scope.engineDisable = true;
                angular.element(document.querySelector("#engineNo")).addClass("getNewRenewPolicyAgruserName");
                disableSubmitBtn = false;
            }
        }
    }

    if ($scope.chassisNo == "" || $scope.chassisNo == undefined) {
        disableSubmitBtn = true;
        $scope.chassisDisable = false;
    } else {
        if (regx.test($scope.chassisNo) == false) {
            $scope.chassisDisable = false;
            disableSubmitBtn = true;
        } else {
            if ($scope.chassisNo.length < 5) {
                $scope.chassisDisable = false;
                disableSubmitBtn = true;
            } else {
                $scope.chassisDisable = true;
                angular.element(document.querySelector("#colorAsPerRCbook")).addClass("getNewRenewPolicyAgruserName");
                disableSubmitBtn = false;
            }
        }
    }

    if ($scope.colorAsPerRCbook == "" || $scope.colorAsPerRCbook == undefined) {
        $scope.colorAsPerRCbookDisable = false;
        disableSubmitBtn = true;
    } else {
        if (regxSpace.test($scope.colorAsPerRCbook) == false) {
            $scope.colorAsPerRCbookDisable = false;
            disableSubmitBtn = true;
        } else {
            $scope.colorAsPerRCbookDisable = true;
            angular.element(document.querySelector("#colorAsPerRCbook")).addClass("getNewRenewPolicyAgruserName");
            disableSubmitBtn = false;
        }
    }

    disableSubmitButton();

    $scope.checkValidation = function ($event) {

        if (event.type == "blur") {
            onBlur = true;
        } else {
            onBlur = false;
        }

        if (event.currentTarget.id == "vehReg1") {
            veh1 = validateVehReg1();
        } else if (event.currentTarget.id == "vehReg2") {
            veh2 = validateVehReg2();
        } else if (event.currentTarget.id == "vehReg3") {
            veh3 = validateVehReg3();
        } else if (event.currentTarget.id == "vehReg4") {
            vehicle4 = validateVehReg4($scope.vehicleRegNo4);
        }
        disableSubmitButton();
    }

    function checkDate() {
        var dateField = true;
        if ($scope.regDate === "") {
            $scope.calcDisable1 = false;
            dateField = false;
            cancelClickRegDate = true;
        } else {
            dateField = true;
        }
        if ($scope.regValidityDate === "") {
            $scope.calcDisable2 = false;
            dateField = false;
            cancelClickRegValidityDate = true;
        } else {
            dateField = true;
        }
        if (dateField) {
            var regdatePart = $scope.regDate.split(/[^0-9]+/);
            var regYear = regdatePart[2];
            var regMon = regdatePart[1];
            var regDay = regdatePart[0];
            var regDateFormat = regMon + "/" + regDay + "/" + regYear;

            var regValiditydatePart = $scope.regValidityDate.split(/[^0-9]+/);
            var regValidityYear = regValiditydatePart[2];
            var regValidityMon = regValiditydatePart[1];
            var regValidityDay = regValiditydatePart[0];
            var regValidityDateFormat = regValidityMon + "/" + regValidityDay + "/" + regValidityYear;

            var regDate = new Date(regDateFormat);
            var regValidityDate = new Date(regValidityDateFormat);

            if (regDate >= regValidityDate) {
                $("#submitInfo").html("");
                $("#submitInfo").html("Registration Validity date should be greater than Registration date");
                $scope.calcDisable1 = false;
                $scope.calcDisable2 = false;
                regValDate = true;
                yearRegDate = false;
            } else if (regYear < $scope.policyData.quote.vehicles[0].vehicleDetails.yearOfManufacture) {
                $("#submitInfo").html("");
                $("#submitInfo").html("Year of Registration should be greater than or equal to Year of Manufacture");
                $scope.calcDisable1 = false;
                $scope.calcDisable2 = false;
                regValDate = false;
                yearRegDate = true;
            } else {
                regValDate = false;
                yearRegDate = false;
                $scope.calcDisable1 = true;
                $scope.calcDisable2 = true;
            }
        }
    }
    $scope.checkVeh1 = function () {
        if ($scope.vehicleRegNo1.length == 3 || $scope.vehicleRegNo1 == "") {

            $scope.veh2Disable = true;
            $scope.veh3Disable = true;
            veh2 = true;
            veh3 = true;
        } else {
            $scope.veh2Disable = false;
            $scope.veh3Disable = false;
        }
    }

    function validateVehReg1() {
        if ($scope.vehicleRegNo1 == "" || $scope.vehicleRegNo1 == undefined) {
            veh1 = false;
            $scope.vehNoError = true;
            $scope.vehicleErrorMsg = "Please enter valid State Code in Reg1";
            CommonServices.stateCodeValid = false;
            $scope.invalidValue = true;
            angular.element(document.querySelector("#submitBtn")).addClass("disableBtn");
            return false;
        } else {

            CommonServices.setCommonData("vehicleRegNo1", $scope.vehicleRegNo1.toUpperCase());
            var reg1 = CommonServices.getCommonData("vehicleRegNo1");
            if ($scope.vehicleRegNo1.length == 3) {
                $scope.veh2Disable = true;
                $scope.veh3Disable = true;
                $scope.vehicleRegNo2 = "";
                $scope.vehicleRegNo3 = "";
            }
            if (regxAlpha.test(reg1) == false) {
                veh1 = false;
                $scope.veh1Disable = false;
                $scope.vehNoError = true;
                $scope.vehicleErrorMsg = "Special characters and numbers are not allowed in Reg1";

                return false;
            } else if (onBlur) {
                if (reg1 == undefined || reg1 == "") {
                    validateErrorForVeh1();
                    return true;
                } else {
                    var statecode = reg1.substring(0, 2).toUpperCase();
                    var stateCodeNewPortalData = {
                        "header": null,
                        "stateCode": statecode
                    };
                    var stateCodeResponse = RestServices.postService(RestServices.urlPathsNewPortal.stateCode, stateCodeNewPortalData);
                    stateCodeResponse.then(
                        function (response) { // success
                            CommonServices.showLoading(false);
                            if (response.data.footer.errorDescription !== undefined) {
                                veh1 = false;
                                $scope.veh1Disable = false;
                                $scope.vehNoError = true;
                                $scope.vehicleErrorMsg = "Please enter valid State Code in Reg1";
                                CommonServices.stateCodeValid = false;
                                $scope.invalidValue = true;
                                angular.element(document.querySelector("#submitBtn")).addClass("disableBtn");
                                if (reg1.length == 3) {
                                    $scope.veh2Disable = false;
                                    $scope.veh3Disable = false;
                                    $scope.vehicleRegNo2 = "";
                                    $scope.vehicleRegNo3 = "";
                                }
                                return false;
                            } else if (response.data.footer.status !== undefined) {
                                CommonServices.stateCodeValid = true;
                                validateErrorForVeh1();
                                return true;
                            }

                        },
                        function (error) { // failure 
                            CommonServices.showLoading(false);
                            RestServices.handleWebServiceError(error);
                            veh1 = false;
                            $scope.veh1Disable = false;
                            $scope.vehNoError = true;
                            $scope.vehicleErrorMsg = "Special characters and numbers are not allowed in Reg1";
                            if (CommonServices.stateCodeValid == false) {
                                $scope.vehicleErrorMsg = "Please enter valid State Code in Reg1";
                            }
                            $scope.invalidValue = true;
                            angular.element(document.querySelector("#submitBtn")).addClass("disableBtn");
                            return false;
                        });
                }
            } else {
                if (CommonServices.stateCodeValid == false) {
                    $scope.vehNoError = true;
                    $scope.vehicleErrorMsg = "Please enter valid State Code in Reg1";
                    $scope.invalidValue = true;
                    angular.element(document.querySelector("#submitBtn")).addClass("disableBtn");
                    return false;
                } else {
                    validateErrorForVeh1();
                    return true;
                }
            }
        }
    }

    function validateErrorForVeh1() {
        veh1 = true;
        if (veh2 == false) {
            $scope.vehNoError = true;
            $scope.vehicleErrorMsg = "Special characters are not allowed in Reg2";
            $scope.invalidValue = true;
            angular.element(document.querySelector("#submitBtn")).addClass("disableBtn");
        } else if (veh3 == false) {
            $scope.vehNoError = true;
            $scope.vehicleErrorMsg = "Special characters are not allowed in Reg3";
            $scope.invalidValue = true;
            angular.element(document.querySelector("#submitBtn")).addClass("disableBtn");
        } else if (vehicle4 == false) {
            $scope.vehNoError = true;
            if ($scope.vehicleRegNo4.toString().length < 4) {
                $scope.vehicleErrorMsg = "Please enter 4 digit number in Reg4";
            } else {
                $scope.vehicleErrorMsg = "Special characters and alphabets are not allowed in Reg4";
            }
            $scope.invalidValue = true;
            angular.element(document.querySelector("#submitBtn")).addClass("disableBtn");
        } else {
            $scope.vehNoError = false;
            CommonServices.stateCodeValid = true;
            $scope.invalidValue = false;
            angular.element(document.querySelector("#submitBtn")).removeClass("disableBtn");
        }
    }

    function validateVehReg2() {
        if ($scope.vehicleRegNo2 == "") {
            validateErrorForVeh2();
            return true;
        } else {
            if ($scope.vehicleRegNo2.length > 3) {
                $scope.vehicleRegNo2 = "";
                validateErrorForVeh2();
                return true;
            } else {
                if (regx.test($scope.vehicleRegNo2) == false) {
                    $scope.veh2Disable = false;
                    veh2 = false;
                    $scope.vehNoError = true;
                    if ($scope.vehicleRegNo2.length > 3) {
                        $scope.vehicleErrorMsg = "Please enter valid vehicle Reg2";
                    } else {
                        $scope.vehicleErrorMsg = "Special characters are not allowed in Reg2";
                    }
                    $scope.invalidValue = true;
                    angular.element(document.querySelector("#submitBtn")).addClass("disableBtn");
                    return false;
                } else {
                    validateErrorForVeh2();
                    return true;
                }
            }
        }
    }

    function validateErrorForVeh2() {
        veh2 = true;
        if (veh1 == false) {
            $scope.vehNoError = true;
            $scope.vehicleErrorMsg = "Special characters and numbers are not allowed in Reg1";
            if (CommonServices.stateCodeValid == false) {
                $scope.vehicleErrorMsg = "Please enter valid State Code in Reg1";
            }
            $scope.invalidValue = true;
            angular.element(document.querySelector("#submitBtn")).addClass("disableBtn");
        } else if (veh3 == false) {
            $scope.vehNoError = true;
            $scope.vehicleErrorMsg = "Special characters are not allowed in Reg3";
            $scope.invalidValue = true;
            angular.element(document.querySelector("#submitBtn")).addClass("disableBtn");
        } else if (vehicle4 == false) {
            $scope.vehNoError = true;
            if ($scope.vehicleRegNo4.toString().length < 4) {
                $scope.vehicleErrorMsg = "Please enter 4 digit number in Reg4";
            } else {
                $scope.vehicleErrorMsg = "Special characters and alphabets are not allowed in Reg4";
            }
            $scope.invalidValue = true;
            angular.element(document.querySelector("#submitBtn")).addClass("disableBtn");
        } else {
            $scope.vehNoError = false;
            $scope.invalidValue = false;
            angular.element(document.querySelector("#submitBtn")).removeClass("disableBtn");
        }
    }

    function validateVehReg3() {
        if ($scope.vehicleRegNo3 == "") {
            validateErrorForVeh3();
            return true;
        } else {
            if ($scope.vehicleRegNo3.length > 3) {
                $scope.vehicleRegNo3 = "";
                validateErrorForVeh3();
                return true;
            } else {
                if (regx.test($scope.vehicleRegNo3) == false) {
                    veh3 = false;
                    $scope.veh3Disable = false;
                    $scope.vehNoError = true;
                    if ($scope.vehicleRegNo3.length > 3) {
                        $scope.vehicleErrorMsg = "Please enter valid vehicle Reg3";
                    } else {
                        $scope.vehicleErrorMsg = "Special characters are not allowed in Reg3";
                    }
                    $scope.invalidValue = true;
                    angular.element(document.querySelector("#submitBtn")).addClass("disableBtn");
                    return false;
                } else {
                    validateErrorForVeh3();
                    return true;
                }
            }
        }
    }

    function validateErrorForVeh3() {
        veh3 = true;
        if (veh1 == false) {
            $scope.vehNoError = true;
            $scope.vehicleErrorMsg = "Special characters and numbers are not allowed in Reg1";
            if (CommonServices.stateCodeValid == false) {
                $scope.vehicleErrorMsg = "Please enter valid State Code in Reg1";
            }
            $scope.invalidValue = true;
            angular.element(document.querySelector("#submitBtn")).addClass("disableBtn");
        } else if (veh2 == false) {
            $scope.vehNoError = true;
            $scope.vehicleErrorMsg = "Special characters are not allowed in Reg2";
            $scope.invalidValue = true;
            angular.element(document.querySelector("#submitBtn")).addClass("disableBtn");
        } else if (vehicle4 == false) {
            $scope.vehNoError = true;
            if ($scope.vehicleRegNo4.toString().length < 4) {
                $scope.vehicleErrorMsg = "Please enter 4 digit number in Reg4";
            } else {
                $scope.vehicleErrorMsg = "Special characters and alphabets are not allowed in Reg4";
            }
            $scope.invalidValue = true;
            angular.element(document.querySelector("#submitBtn")).addClass("disableBtn");
        } else {
            $scope.vehNoError = false;
            $scope.invalidValue = false;
            angular.element(document.querySelector("#submitBtn")).removeClass("disableBtn");
        }
    }

    function validateVehReg4(vehReg4Value) {
        if (vehReg4Value === "" || vehReg4Value == undefined) {
            $scope.vehNoError = true;
            vehicle4 = false;
            if ($scope.vehicleRegNo4.toString().length < 4) {
                $scope.vehicleErrorMsg = "Please enter 4 digit number in Reg4";
            } else {
                $scope.vehicleErrorMsg = "Special characters and alphabets are not allowed in Reg4";
            }
            $scope.invalidValue = true;
            angular.element(document.querySelector("#submitBtn")).addClass("disableBtn");
            return false;

        } else {
            if (regxNum.test(vehReg4Value) == false) {
                $scope.veh4Disable = false;
                vehicle4 = false;
                $scope.vehNoError = true;
                $scope.vehicleErrorMsg = "Special characters and alphabets are not allowed in Reg4";
                $scope.invalidValue = true;
                angular.element(document.querySelector("#submitBtn")).addClass("disableBtn");
                return false;
            } else if ($scope.vehicleRegNo4.toString().length < 4) {
                $scope.veh4Disable = false;
                vehicle4 = false;
                $scope.vehNoError = true;
                $scope.vehicleErrorMsg = "Please enter 4 digit number in Reg4";
                $scope.invalidValue = true;
                angular.element(document.querySelector("#submitBtn")).addClass("disableBtn");
                return false;
            } else {
                validateErrorForVeh4();
                return true;
            }
        }
    }

    function validateErrorForVeh4() {
        vehicle4 = true;
        if (veh1 == false) {
            $scope.vehNoError = true;
            $scope.vehicleErrorMsg = "Special characters and numbers are not allowed in Reg1";
            if (CommonServices.stateCodeValid == false) {
                $scope.vehicleErrorMsg = "Please enter valid State Code in Reg1";
            }
            $scope.invalidValue = true;
            angular.element(document.querySelector("#submitBtn")).addClass("disableBtn");
        } else if (veh2 == false) {
            $scope.vehNoError = true;
            $scope.vehicleErrorMsg = "Special characters are not allowed in Reg2";
            $scope.invalidValue = true;
            angular.element(document.querySelector("#submitBtn")).addClass("disableBtn");
        } else if (veh3 == false) {
            $scope.vehNoError = true;
            $scope.vehicleErrorMsg = "Special characters are not allowed in Reg3";
            $scope.invalidValue = true;
            angular.element(document.querySelector("#submitBtn")).addClass("disableBtn");
        } else {
            $scope.vehNoError = false;
            $scope.invalidValue = false;
            angular.element(document.querySelector("#submitBtn")).removeClass("disableBtn");
        }
    }

    $scope.disableSubmitButton = function () {
        disableSubmitButton();
    }

    function disableSubmitButton() {
        if (regxAlpha.test($scope.vehicleRegNo1) == false || regx.test($scope.vehicleRegNo2) == false || regx.test($scope.vehicleRegNo3) == false ||
            regxNum.test($scope.vehicleRegNo4) == false || $scope.vehicleRegNo4.toString().length < 4 || CommonServices.stateCodeValid == false) {

            disableSubmitBtn = true;
            $scope.invalidValue = true;
            angular.element(document.querySelector("#submitBtn")).addClass("disableBtn");
        } else if (regx.test($scope.engineNo) == false || regx.test($scope.chassisNo) == false || regxSpace.test($scope.colorAsPerRCbook) == false) {

            disableSubmitBtn = true;
            $scope.invalidValue = true;
            angular.element(document.querySelector("#submitBtn")).addClass("disableBtn");
        } else {
            disableSubmitBtn = false;
            $scope.invalidValue = false;
            angular.element(document.querySelector("#submitBtn")).removeClass("disableBtn");
        }
    }

    var mydateStr = CommonServices.getCommonData("serverDate");
    var mynewdateFrom = "";
    if (mydateStr != undefined) {
        mynewdateFrom = new Date(mydateStr);
    } else {
        mynewdateFrom = new Date();
    }

    var enableCalendarfrom = getFormattedDate(mynewdateFrom);

    /**RegDate Enable Date past 15 years**/
    var enableRegCalendarfrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 15));
    enableRegCalendarfrom = new Date(enableRegCalendarfrom.setDate(enableRegCalendarfrom.getDate() + 1));
    enableRegCalendarfrom = getFormattedDate(enableRegCalendarfrom);

    /**RegDate Enable Date past 15 years**/

    /**Reg validity Date Enable Date future 15 years**/

    var enableRegValCalendarTo = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() + 15));
    enableRegValCalendarTo = new Date(enableRegValCalendarTo.setDate(enableRegValCalendarTo.getDate() - 1));
    enableRegValCalendarTo = getFormattedDate(enableRegValCalendarTo);

    /**Reg validity Date Enable Date future 15 years**/

    $('#regDate').loadCalendar({
        'enableDateRange': true,
        'enableCalendarFrom': enableRegCalendarfrom,
        'enableCalendarTo': enableCalendarfrom
    });
    $("#regValidityDate").loadCalendar({
        'enableDateRange': true,
        'enableCalendarFrom': enableCalendarfrom,
        'enableCalendarTo': enableRegValCalendarTo
    });
    $scope.calIconClick = function (event) {
        angular.element("#" + event.currentTarget.children[0].id).focus();

    };

    $scope.vehicleRegSubmit = function () {
        checkDate();
        if (regValDate) {

            navigator.notification.alert("Registration Validity date should be greater than Registration date", null, 'Alert', 'ok');
        } else if (yearRegDate) {

            navigator.notification.alert("Year of Registration should be greater than or equal to Year of Manufacture", null, 'Alert', 'ok');
        } else {

            if (CommonServices.deviceType != "NA") {
                navigator.notification.confirm("Vehicle details once registered can not be changed. Are you sure you want to register?", $scope.vehicleSubmit, "Confirm", ["OK", "Cancel"]);
            } else {
                var vehicleDetailConfirm = confirm("Vehicle details once registered can not be changed. Are you sure you want to register?");
                if (vehicleDetailConfirm == true) {
                    $scope.vehicleSubmit(1);
                } else {
                    $scope.vehicleSubmit(2);
                }
            }
        }

    };

    $scope.vehicleSubmit = function (button) {
        if (button == 1) {
            if (disableSubmitBtn) {
                if ($scope.engineDisable == false) {
                    CommonServices.showAlert("Please enter valid engine number");
                } else if ($scope.chassisDisable == false) {
                    CommonServices.showAlert("Please enter valid chassis number");
                } else if ($scope.colorAsPerRCbookDisable == false) {
                    CommonServices.showAlert("Please enter valid color as per RC book");
                }
            } else {
                var regdatePart = $scope.regDate.split(/[^0-9]+/);
                var regYear = regdatePart[2];
                var regMon = regdatePart[1];
                var regDay = regdatePart[0];
                var regDateFormat = regMon + "/" + regDay + "/" + regYear;

                var regValiditydatePart = $scope.regValidityDate.split(/[^0-9]+/);
                var regValidityYear = regValiditydatePart[2];
                var regValidityMon = regValiditydatePart[1];
                var regValidityDay = regValiditydatePart[0];
                var regValidityDateFormat = regValidityMon + "/" + regValidityDay + "/" + regValidityYear;

                var regDate = new Date(regDateFormat);
                var regValidityDate = new Date(regValidityDateFormat);

                if (regDate < regValidityDate && regYear >= $scope.policyData.quote.vehicles[0].vehicleDetails.yearOfManufacture) {

                    if ($scope.vehicleRegNo2 == undefined)
                        $scope.vehicleRegNo2 = "";
                    if ($scope.vehicleRegNo3 == undefined)
                        $scope.vehicleRegNo3 = "";

                    $scope.policyData.quote.vehicles[0].vehicleDetails.registrationNo1 = $scope.vehicleRegNo1.toUpperCase();
                    $scope.policyData.quote.vehicles[0].vehicleDetails.registrationNo2 = $scope.vehicleRegNo2.toUpperCase();
                    $scope.policyData.quote.vehicles[0].vehicleDetails.registrationNo3 = $scope.vehicleRegNo3.toUpperCase();
                    $scope.policyData.quote.vehicles[0].vehicleDetails.registrationNo4 = $scope.vehicleRegNo4;
                    $scope.policyData.quote.vehicles[0].vehicleDetails.engineNo = $scope.engineNo.toUpperCase();
                    $scope.policyData.quote.vehicles[0].vehicleDetails.chassisNo = $scope.chassisNo.toUpperCase();
                    $scope.policyData.quote.vehicles[0].vehicleDetails.colorAsPerRCbook = $scope.colorAsPerRCbook.toUpperCase();
                    CommonServices.setCommonData("vehicleRegNo1", $scope.vehicleRegNo1.toUpperCase());
                    CommonServices.setCommonData("vehicleRegNo2", $scope.vehicleRegNo2.toUpperCase());
                    CommonServices.setCommonData("vehicleRegNo3", $scope.vehicleRegNo3.toUpperCase());
                    CommonServices.setCommonData("vehicleRegNo4", $scope.vehicleRegNo4);
                    CommonServices.setCommonData("engineNo", $scope.engineNo.toUpperCase());
                    CommonServices.setCommonData("chassisNo", $scope.chassisNo.toUpperCase());
                    CommonServices.setCommonData("colorAsPerRCbook", $scope.colorAsPerRCbook.toUpperCase());
                    CommonServices.setCommonData("regDate", $scope.regDate);
                    CommonServices.setCommonData("regValidityDate", $scope.regValidityDate);
                    $state.go('newRenewPolicy.policyDetails');

                } else if (regDate >= regValidityDate) {
                    $("#submitInfo").html("");
                    $("#submitInfo").html("Registration Validity date should be greater than Registration date");
                    $scope.calcDisable1 = false;
                } else if (regYear < $scope.policyData.quote.vehicles[0].vehicleDetails.yearOfManufacture) {
                    $("#submitInfo").html("");
                    $("#submitInfo").html("Year of Registration should be greater than or equal to Year of Manufacture");
                    $scope.calcDisable1 = false;
                }

            }
        } else if (button == 2) {
            if (cancelClickRegValidityDate) {
                $("#regValidityDate").prop("disabled", false);
            } else {
                $("#regValidityDate").prop("disabled", true);
            }
            if (cancelClickRegDate) {
                $("#regDate").prop("disabled", false);
            } else {
                $("#regDate").prop("disabled", true);
            }
        }

    };

    $scope.cancelVehicleReg = function () {
        $location.path('/newRenewPolicy/getNewRenewPolicy');
    };

}]);


agentApp.controller('PolicyDetailsCtrl', ['$scope', '$rootScope', '$location', 'RestServices', 'CommonServices', '$state', '$timeout', '$filter','CartServices', function ($scope, $rootScope, $location, RestServices, CommonServices, $state, $timeout, $filter, CartServices) {

    $scope.stateSelected = false;
    $scope.citySelected = false;
    $scope.gstinMsg = "GSTIN";
    $scope.regexAge = /^(?=.*[1-9])\d*$/;//3444
    $scope.regexName = /^[a-zA-Z][a-zA-Z ]*$/;//3444
    $scope.regexNameWithoutSpace = /^[a-zA-Z][a-zA-Z]*$/;//3444
    /*Added by 851587 for CR_NP_0744, aadhaar commented for CR_NP_0744E starts*/
    $scope.panNumInputDisable = false;
    // $scope.aadhaarInputDisable = false;
    $scope.regexPanNo = regexPanNoGlobal;
    $scope.regexAadhaarInput = /^(?!\1+$)\d{4}$/;
    $scope.regexAadhaarNumber = /^(?!\1+$)\d{12}$/;
    $scope.panRequiredForMiscProducts = false;
    // $scope.removeAadhaarInput = false;
    $scope.aadhaarObj = {};
    /*CR_NP_0880 Starts*/
    $scope.disableCityInput = true;
    $scope.disablePinCodeInput = false;
    $scope.isNIAPAN = false; //3746
    /*CR_NP_0880 Ends */

    //CR3845 
    $scope.tpaDetails = CommonServices.getCommonData("tpaDetails");


    // Below line Added during CR_NP_0546C
    $scope.showBreakInDisclaimer = CommonServices.showBreakInDisclaimerInDetails;

    //Make Pan Number Mandatory for Certain Products
    if (CommonServices.QRrenewalData.quote.productCode == "HH" || CommonServices.QRrenewalData.quote.productCode == "OS" || CommonServices.QRrenewalData.quote.productCode == "SH") {
        $scope.panRequiredForMiscProducts = true;
    }
    //Disable Aadhar if PartyType is Organization
    /*CR_NP_0744E starts */
    // if(CommonServices.QRrenewalData.quote.partyDetailsList !== undefined && CommonServices.QRrenewalData.quote.partyDetailsList !== "" && CommonServices.QRrenewalData.quote.partyDetailsList[0].partyType === "O"){
    // 	$scope.removeAadhaarInput = true;
    // }
    /*CR_NP_0744E ends */

    // To get the Configuration Data
    var configurationData = CommonServices.getCommonData("ConfigurationData");
    if (configurationData != undefined && configurationData != '') {
        if (configurationData[0].value == "Y") {
            $scope.isPanNumberMandatory = true;
        } else {
            $scope.isPanNumberMandatory = false;
        }
        /*Below block Commented by 851587 for CR_NP_0744E */
        // if (configurationData[1].value == "Y") {
        //     $scope.isAadhaarNumberMandatory = true;
        // } else {
        //     $scope.isAadhaarNumberMandatory = false;
        // }
        /*CR_NP_0744E ends*/
    }
    /**CR690 Start**/
    $rootScope.panmodalOpen = false;

    var panCardDetails = {
        "quoteNumber": CommonServices.QRrenewalData.quote.quoteNumber,
        "policyHolderCode": CommonServices.QRrenewalData.quote.policyHolderCode
    }
    CommonServices.setCommonData("panCardData", panCardDetails);
    /**CR690 End**/

    //CR3746
    $scope.onPANNoChange = function () {
        // $scope.isNIAPAN = isNIAPANNo($scope.panNumber.toUpperCase());
        if($scope.panNumber != undefined){
            $scope.panNumber = $scope.panNumber.toUpperCase();
            $scope.isNIAPAN = isNIAPANNo($scope.panNumber);
        }
		else
		$scope.isNIAPAN = false;
    };
    //CR3746

    /*CR_NP_0744E starts */
    //To auto focus the pointer to next input field
    // $(".aadhaarInputs").keyup(function() {
    //     if (this.value.length == 4) {
    //         $(this).next('.aadhaarInputs').focus();
    //     }
    //     if (this.value.length < 1) {
    //         $(this).prev('.aadhaarInputs').focus();
    //     }
    // });

    // // On change of value in aadhaar Input, to make other fields mandatory
    // $scope.aadhaarNoField = function() {
    //     if (($scope.aadhaarObj.aadhaarNumber1 != undefined && $scope.aadhaarObj.aadhaarNumber1 != '') || ($scope.aadhaarObj.aadhaarNumber2 != undefined && $scope.aadhaarObj.aadhaarNumber2 != '') || ($scope.aadhaarObj.aadhaarNumber3 != undefined && $scope.aadhaarObj.aadhaarNumber3 != '')) {
    //         $scope.aadharFieldIsRequired = true;
    //         if (($scope.aadhaarObj.aadhaarNumber1 != undefined && $scope.aadhaarObj.aadhaarNumber1 != '') && ($scope.aadhaarObj.aadhaarNumber2 != undefined && $scope.aadhaarObj.aadhaarNumber2 != '') && ($scope.aadhaarObj.aadhaarNumber3 != undefined && $scope.aadhaarObj.aadhaarNumber3 != '')) {
    //             $scope.aadharFieldIsRequired = false;
    //         }
    //     } else {
    //         $scope.aadharFieldIsRequired = false;
    //     }
    // };

    /*CR_NP_0744 and CR_NP_0744E ends*/

    $scope.policyDetailsCtrl = {
        onload: function () {
            if (CommonServices.NmMcProduct) {
                $scope.policyData = CommonServices.editQuoteResponse;
                $scope.policyData.quote.emailId = CommonServices.QRrenewalData.quote.emailId;
                $scope.policyData.quote.mobileNo = CommonServices.QRrenewalData.quote.mobileNo;
            } else {
                $scope.policyData = CommonServices.QRrenewalData;
            }
            var todayDate = new Date(CommonServices.getCommonData("serverDate"));
            var polStartDate = $scope.policyData.quote.policyStartDate;
            polStartDate = polStartDate.split("/");
            polStartDate = polStartDate[1] + "/" + polStartDate[0] + "/" + polStartDate[2];
            polStartDate = new Date(polStartDate);
            //code Commented CR4051  testing
            // if (polStartDate.setHours(0, 0, 0, 0) < todayDate.setHours(0, 0, 0, 0)) {
            //     CommonServices.showAlert("Policy start date has been reset to current date as backdated policy issuance for Break In is not allowed");
            //     var startDate = CommonServices.getCommonData("serverDate");
            //     startDate = startDate.split("/");
            //     startDate = startDate[1] + "/" + startDate[0] + "/" + startDate[2];
            //     var expiryDate = addYears(todayDate);
            //     $scope.policyData.quote.policyStartDate = startDate;
            //     $scope.policyData.quote.policyExpiryDate = expiryDate;
            // }

            function addYears(todaysDate) {
                var dt = new Date(todaysDate);
                var newDate = new Date(dt.getFullYear() + 1, dt.getMonth(), dt.getDate() - 1);
                var d = new Date(newDate || Date.now()),

                    month = '' + (d.getMonth() + 1),
                    day = '' + d.getDate(),
                    year = d.getFullYear();

                if (month.length < 2) month = '0' + month;
                if (day.length < 2) day = '0' + day;

                return [day, month, year].join('/');
            }
            $scope.gstInPatternErr = true;
            if (CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.hasOwnProperty('gstRegIdType')) {
                if (CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.gstRegIdType === " ") {
                    $scope.gstRegIdType = "";
                } else {
                    $scope.gstRegIdType = CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.gstRegIdType;
                }


            }
            if (CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.hasOwnProperty('gstin')) {
                if (CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.gstin === " ") {
                    $scope.gsTin = "";
                } else {
                    $scope.gsTin = CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.gstin;
                }
            }
            if (CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.hasOwnProperty('uin')) {

                if (CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.uin === " ") {
                    $scope.gstUin = "";
                } else {
                    $scope.gstUin = CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.uin;
                }
            }

            /*CR_NP_0880 Starts */
            if (CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.hasOwnProperty('state')) {

                var getAllStateListInput = {
                    "state": "",
                    "city": ""
                };
                var getStateListResponse = RestServices.postService(RestServices.urlPathsNewPortal.getStateList, getAllStateListInput);

                getStateListResponse.then(function (response) {

                    CommonServices.showLoading(false);
                    if (response.data.hasOwnProperty('states')) {
                        for (i = 0; i < response.data.states.length; i++) {
                            if (response.data.states[i].stateCode == CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.state) {
                                $scope.gstState = response.data.states[i].state;
                                //UC for 3749
                                // angular.forEach(CommonServices.gstIdStateCode,function(value,key){
                                //     if($scope.gstState == value){
                                //         $scope.gstinMsg = "GSTIN should start with "+key;
                                //     }

                                // });
                                CommonServices.setCommonData("gstResponseState", response.data.states[i].state);
                                // callResponseCitiesService();
                                callZipCodeResponseService();
                            }
                        }

                    } else {
                        CommonServices.showLoading(false);
                        CommonServices.showAlert("Sorry! Some error occured please try again later");
                    }
                }, function (error) {
                    CommonServices.showLoading(false);
                    RestServices.handleWebServiceError(error);
                });

            } else {
                // $scope.disableCityInput = true;
                $scope.disablePinCodeInput = true;
                /*CR_NP_0880 Ends */
            }

            function callZipCodeResponseService() {

                var getZipCodeListInput = {
                    "state": CommonServices.getCommonData("gstResponseState")
                }

                var getZipCodeListResponse = RestServices.postService(RestServices.urlPathsNewPortal.getZipCodesbyState, getZipCodeListInput);
                getZipCodeListResponse.then(function (response) {
                    CommonServices.showLoading(false);
                    if (response.data.hasOwnProperty('pincodes')) {
                        $scope.allZipCodeList = response.data.pincodes;
                        for (var i = 0; i < response.data.pincodes.length; i++) {
                            if (response.data.pincodes[i] == CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.pinCode) {
                                $scope.gstPinCode = response.data.pincodes[i];
                                CommonServices.setCommonData("gstResponseZipcode", response.data.pincodes[i]);
                                callResponseCitiesService();
                            }
                        }
                    }

                }, function (error) {
                    CommonServices.showLoading(false);
                    RestServices.handleWebServiceError(error);
                });
            };
            /* start CR 3444*/
            $scope.showAddCoversDiv3_4 = function () {
                if ($scope.buyNow.twoWheeler.addCovers.ownerDriveVehOrNotTW === true) {
                    if (CommonServices.QRrenewalData.quote.productCode === "CV") {
                        $scope.sumInsuredCV = false;

                        // $scope.buyNow.twoWheeler.addCovers.sumInsForOwnerDriver = "";
                    }
                    else {
                        $scope.sumInsuredCV = true;
                        // $scope.buyNow.twoWheeler.addCovers.sumInsForOwnerDriver = 1500000;
                    }
                    $scope.showaddCoversDiv3_4 = true;
                    $scope.showDisclaimerDivTW1 = false;
                    $scope.DurationForPaOwnerDriverCoverTWDiv = false;
                    $scope.buyNow.twoWheeler.addCovers.sumInsForOwnerDriver = null;
                    $scope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner = $("#licenseTypeOfOwnerTW option:first").val();
                    $scope.buyNow.twoWheeler.addCovers.licenseNoOwnerDriver = undefined;
                    $scope.buyNow.twoWheeler.addCovers.nameOfNominee = undefined;
                    $scope.buyNow.twoWheeler.addCovers.ageOfNominee = undefined;
                    $scope.buyNow.twoWheeler.addCovers.relnWithInsured = $("#relnWithInsuredTW option:first").val();
                    $scope.buyNow.twoWheeler.addCovers.compulsoryPACoverPolicy = $("#compulsoryPACoverPolicyTW option:first").val();
                    $scope.buyNow.twoWheeler.addCovers.sumInsuredOfAtleast15lacs = $("#sumInsuredOfAtleast15lacsTW option:first").val();
                    /*$scope.buyNow.twoWheeler.addCovers.paCoverForAnyOtherVehicle = $("#paCoverForAnyOtherVehicleTW option:first").val();*/ //CR_3444B
                    if ($scope.DurationForPaOwnerDriverCoverTWDiv === true) {
                        //$scope.buyNow.twoWheeler.addCovers.DurationForPaOwnerDriverCover = $("#DurationForPaOwnerDriverCoverTW option:first").val();
                    } else {
                        $scope.buyNow.twoWheeler.addCovers.DurationForPaOwnerDriverCover = undefined;
                    }
                } else {
                    $scope.showaddCoversDiv3_4 = false;
                    $scope.buyNow.twoWheeler.addCovers.sumInsForOwnerDriver = undefined;
                    $scope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner = undefined;
                    $scope.buyNow.twoWheeler.addCovers.licenseNoOwnerDriver = undefined;
                    $scope.buyNow.twoWheeler.addCovers.nameOfNominee = undefined;
                    $scope.buyNow.twoWheeler.addCovers.ageOfNominee = undefined;
                    $scope.buyNow.twoWheeler.addCovers.relnWithInsured = undefined;
                    $scope.buyNow.twoWheeler.addCovers.DurationForPaOwnerDriverCover = undefined;
                    $scope.buyNow.twoWheeler.addCovers.compulsoryPACoverPolicy = undefined;
                    $scope.buyNow.twoWheeler.addCovers.sumInsuredOfAtleast15lacs = undefined
                    /*$scope.buyNow.twoWheeler.addCovers.paCoverForAnyOtherVehicle=undefined*/ //CR_3444B
                }
            }

            $scope.showAddCoversDiv9 = function () {
                if ($scope.buyNow.twoWheeler.addCovers.paCoverForUnnamedPersonTW === true) {
                    $scope.showaddCoversDiv9 = true;
                    $scope.buyNow.twoWheeler.addCovers.paCoverForUnnamedPersonRadioTW = 1;
                    $scope.buyNow.twoWheeler.addCovers.indSIforUnnamedPerson = 1500000;
                } else {
                    $scope.showaddCoversDiv9 = false;
                    $scope.buyNow.twoWheeler.addCovers.paCoverForUnnamedPersonRadioTW = undefined;
                    $scope.buyNow.twoWheeler.addCovers.indSIforUnnamedPerson = null;
                }
            }
            /* end CR 3444*/
            function callResponseCitiesService() {

                var getAllCitiesListInput = {
                    "state": CommonServices.getCommonData("gstResponseState"),
                    "zipCode": CommonServices.getCommonData("gstResponseZipcode"),
                    //"additionalParameter":"MOBILE",
                    "city": ""
                };

                var getCitiesListResponse = RestServices.postService(RestServices.urlPathsNewPortal.getCitiesList, getAllCitiesListInput);

                getCitiesListResponse.then(function (response) {
                    CommonServices.showLoading(false);
                    if (response.data.hasOwnProperty('cities')) {
                        $scope.cityList = response.data.cities.sort(CommonServices.sort_by('city', response.data.cities, ''));
                        if (CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.hasOwnProperty('city')) {
                            for (i = 0; i < response.data.cities.length; i++) {
                                if (response.data.cities[i].cityCode == CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.city) {
                                    $scope.gstCityLocation = response.data.cities[i];
                                }
                            }
                        }
                        // else {
                        //     var citiesArr = [];
                        //     for (i = 0; i < response.data.cities.length; i++) {
                        //         citiesArr.push(response.data.cities[i].city);
                        //     }
                        //     $scope.cityList = citiesArr;
                        // }
                    }

                }, function (error) {
                    CommonServices.showLoading(false);
                    RestServices.handleWebServiceError(error);
                });

            };


            if (CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.hasOwnProperty('pinCode')) {
                $scope.gstPinCode = CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.pinCode;
            }
            /*Added for CR_NP_0744*/
            if (CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.panNumber !== undefined && CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.panNumber !== '' && $scope.regexPanNo.test(CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.panNumber)) {
                $scope.panNumber = CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.panNumber;
                $scope.panNumInputDisable = true;
            } else {
                $scope.panNumber = '';
                $scope.panNumInputDisable = false;
            }

            if (CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.aadhaarNo !== undefined && CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.aadhaarNo !== '' && $scope.regexAadhaarNumber.test(CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.aadhaarNo)) {
                $scope.aadhaarObj.aadhaarNumber1 = CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.aadhaarNo.substr(0, 4);
                $scope.aadhaarObj.aadhaarNumber2 = CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.aadhaarNo.substr(4, 4);
                $scope.aadhaarObj.aadhaarNumber3 = CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.aadhaarNo.substr(8, 4);
                $scope.aadhaarInputDisable = true;
            } else {
                $scope.aadhaarObj.aadhaarNumber1 = '';
                $scope.aadhaarObj.aadhaarNumber2 = '';
                $scope.aadhaarObj.aadhaarNumber3 = '';
                $scope.aadhaarInputDisable = false;
            }
            /*CR_NP_0744 and CR_NP_0744E ends*/

            /*CR_NP_0744C starts*/
            setTimeout(function () {

                if (CommonServices.QRrenewalData.quote.policyNumber === undefined) {
                    return;
                }

                /* CR_NP_0744C starts */
                if (CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.aadhaarAuthStatus.toUpperCase() != "SUCCESS") {

                    if (CommonServices.deviceType != 'NA') {
                        CommonServices.showConfirmForAadhaar("We have found that your policy is not linked with your Aadhaar number. Would you like to link your Aadhaar number to your policy now?", function onConfirm(r) {
                            if (r == 1) {
                                linkMyAadhaar();
                            }
                            else if (r == 2) {
                                CommonServices.showLoading(false);
                            }
                        }, "Confirm");
                    } else {
                        var linkMyAadhaarConfirm = confirm("We have found that your policy is not linked with your Aadhaar number. Would you like to link your Aadhaar number to your policy now?");
                        if (linkMyAadhaarConfirm) {
                            linkMyAadhaar();
                        }
                    }

                }

            }, 2000);

            /*CR_NP_0744C ends*/


        }
    };
    /*NP_CR_3444 Start*/
    $scope.showDisclaimerDivTW = function () {
        if ($scope.buyNow.twoWheeler.addCovers.compulsoryPACoverPolicy === "YES" || $scope.buyNow.twoWheeler.addCovers.sumInsuredOfAtleast15lacs === "YES") { /*Remove buyNow.twoWheeler.addCovers.paCoverForAnyOtherVehicle === "YES" for CR_3444B*/
            $scope.showDisclaimerDivTW1 = true;
            $scope.DurationForPaOwnerDriverCoverTWDiv = false;
            $scope.buyNow.twoWheeler.addCovers.sumInsForOwnerDriver = 0;

        } else if (($scope.buyNow.twoWheeler.addCovers.compulsoryPACoverPolicy === "NO" && $scope.buyNow.twoWheeler.addCovers.sumInsuredOfAtleast15lacs === "NO") && ((CommonServices.QRrenewalData.quote.productCode === "TW") || (CommonServices.QRrenewalData.quote.productCode === "PC") || (CommonServices.QRrenewalData.quote.productCode === "SQ") || (CommonServices.QRrenewalData.quote.productCode === "SS"))) {/*Remove buyNow.twoWheeler.addCovers.paCoverForAnyOtherVehicle === "NO" for CR_3444B*/ /* CR_NP_3621 */
            $scope.DurationForPaOwnerDriverCoverTWDiv = true;
            $scope.showDisclaimerDivTW1 = false;
            $scope.buyNow.twoWheeler.addCovers.sumInsForOwnerDriver = 1500000;
        }
        else {
            $scope.showDisclaimerDivTW1 = false;
            $scope.DurationForPaOwnerDriverCoverTWDiv = false;
        }
    }
    /*NP_CR_3444 End */
    $scope.policyDetailsCtrl.onload();

    /* CR_NP_0744C function starts */

    function linkMyAadhaar() {

        CommonServices.showLoading(true);


        var fetchAadharDetails = {
            "quote": {
                "policyHolderCode": CommonServices.QRrenewalData.quote.policyHolderCode,
                "policyNumber": CommonServices.QRrenewalData.quote.policyNumber
            },
            "userProfile": {
                "userId": CommonServices.getCommonData("userCode").toUpperCase()
            }
        };

        var header = {
            'Content-Type': 'application/json',
            'applicationid': 'mobile',
            'customerName': 'CUSTOMER',
            'typeOfCustomer': 'CUSTOMER'
        };

        var fetchAadharDetailsResponse = RestServices.postService(RestServices.urlPathsNewPortal.fetchAadharDetails, fetchAadharDetails);
        fetchAadharDetailsResponse.then(function (response) {

            CommonServices.showLoading(false);

            if (response.data.userProfile != undefined) {
                if (response.data.userProfile.footer.errorCode == "1") {
                    GetSetResponseService.addFetchAadharDetails(response.data);
                    $state.go('linkYourAadharGetUserData');
                } else {
                    CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
                }
            } else {
                CommonServices.showAlert("We regret for the inconvenience, presently our services are not available. Please try after sometime");
            }

        }, function (error) {
            CommonServices.showLoading(false);
            RestServices.handleWebServiceError(error);
        });


    };
    /* CR_NP_0744C function ends */



    if (CommonServices.isMotor) {
        $scope.isMotor = true;
    } else {
        $scope.isMotor = false;
    }
    var roomRentRiderValue = "";
    var custPopUp = true;
    var rrrPopUp = true;
    $scope.roomRentRider = {};
    $scope.roomRentRider.roomRentRiderOptions = [{
        value: "Y",
        label: "YES"
    },
    {
        value: "N",
        label: "NO"
    }
    ];

    if (CommonServices.optRoomRentRiderOption) {
        if ($scope.policyData.quote.isPopup.toUpperCase() === "TRUE" && $scope.policyData.quote.isDropdown.toUpperCase() === "TRUE") {
            custPopUp = true;
            rrrPopUp = true;
        } else if ($scope.policyData.quote.isPopup.toUpperCase() === "FALSE" && $scope.policyData.quote.isDropdown.toUpperCase() === "TRUE") {
            custPopUp = true;
            rrrPopUp = false;
            $("#roomRentRider").removeClass("hide");
            $("#roomRentRiderID").val("YES");
            $(".darkBackground.policyDetailsUl li:nth-last-child(2)").css("border-bottom", "1px solid #5a5d82");
        } else if ($scope.policyData.quote.isPopup.toUpperCase() === "FALSE" && $scope.policyData.quote.isDropdown.toUpperCase() === "FALSE") {
            custPopUp = true;
            rrrPopUp = false;
        }
    } else {
        custPopUp = true;
        rrrPopUp = false;
    }

    $scope.changeType = function () {
        var input = angular.element(document.querySelector(".changeInputType"));
        input.attr('type', 'tel');
    };

    $scope.changeEmailType = function (event) {

        var input = angular.element(document.querySelector("#email_id"));
        input.attr('type', 'email');
    };

    $timeout(function () {
        angular.element('#editContact').triggerHandler('click');
    }, 0);
    $timeout(function () {
        angular.element('#saveContact').triggerHandler('click');
    }, 5);

    $scope.savePolicyDetails = function (forminput) {
        var regex = new RegExp(/\b^[a-zA-Z0-9][a-zA-Z0-9._-]*@[a-zA-Z0-9-]+(\.[a-zA-Z]{2,4}){1,3}\b$/);
        var regexPh = new RegExp(/^([56789])(?!\1+$)\d{9}$/);
        var key = $scope.policyData.quote.emailId;
        var keyPh = $scope.policyData.quote.mobileNo;

        if (regex.test(key) && regexPh.test(keyPh)) {
            $scope.policyDetailsForm.phoneNum.$invalid = false;
            $scope.policyDetailsForm.phoneNum.$dirty = false;
            $scope.policyDetailsForm.emailId.$invalid = false;
            $scope.policyDetailsForm.emailId.$dirty = false;
            $scope.showTextBox = !$scope.showTextBox;
        } else {
            if (regex.test(key) == false) {
                $scope.policyDetailsForm.emailId.$invalid = true;
                $scope.policyDetailsForm.emailId.$dirty = true;
            } else {
                $scope.policyDetailsForm.emailId.$invalid = false;
                $scope.policyDetailsForm.emailId.$dirty = false;
            }
            if (regexPh.test(keyPh) == false) {
                $scope.policyDetailsForm.phoneNum.$invalid = true;
                $scope.policyDetailsForm.phoneNum.$dirty = true;
            } else {
                $scope.policyDetailsForm.phoneNum.$invalid = false;
                $scope.policyDetailsForm.phoneNum.$dirty = false;
            }
            return false;
        }
    };

    $scope.policyDetailSubmit = function (type = '') {
        /*Added by 851587 for CR_NP_0744*/
        $rootScope.partyCode = $scope.policyData.quote.policyHolderCode;
        if ($scope.aadhaarObj.aadhaarNumber1 != undefined && $scope.aadhaarObj.aadhaarNumber1 != '' && $scope.aadhaarObj.aadhaarNumber2 != undefined && $scope.aadhaarObj.aadhaarNumber2 != '' && $scope.aadhaarObj.aadhaarNumber3 != undefined && $scope.aadhaarObj.aadhaarNumber3 != '') {
            $scope.aadhaarObj.aadhaarNumber = $scope.aadhaarObj.aadhaarNumber1 + $scope.aadhaarObj.aadhaarNumber2 + $scope.aadhaarObj.aadhaarNumber3;
        } else {
            $scope.aadhaarObj.aadhaarNumber = "";
        }
        /*CR_NP_0744 ends*/
        if ($scope.showTextBox == true) {
            CommonServices.showAlert("Please Save the Details");
        } else {
            if (custPopUp === true && rrrPopUp === false) {

                // if (CommonServices.deviceType !== "NA") {
                //     navigator.notification.confirm("Customer details once submitted cannot be changed. Are you sure you want to submit details?", $scope.policyDetails, "Confirm", ["OK", "Cancel"]);
                // } else {
                //     var policyDetailConfirm = confirm("Customer details once submitted cannot be changed. Are you sure you want to submit details?");
                //     if (policyDetailConfirm === true) {
                //         $scope.policyDetails(1);
                //     }
                // }
                CommonServices.setCommonData("addToCart", type);
                var msg = "Customer details once submitted cannot be changed. Are you sure you want to submit details?";
                CommonServices.messageModal('info', msg, false, 'Cancel', 'Ok', function () { }, function () { $scope.policyDetails(1); }, 'Confirm');

            } else if (custPopUp === true && rrrPopUp === true) {
                roomRentRider();
            }
        }
    };

    function roomRentRider() {
        if (CommonServices.deviceType != "NA") {
            navigator.notification.confirm("By paying additional premium of Rs " + $scope.policyData.quote.estdPremium + "(exclusive of service tax) you can opt for Room Rent Rider where in existing claim amount limit of 1% of Sum Insured per day for Room Tariff, 2 % of Sum Insured per day for ICU Tariff and 2% of Sum Insured per day for ICCU room tariff will  be increased to 1.5% of Sum Insured for Room Tariff, 3% of sum Insured per day for ICU room tariff and 3% of sum Insured per day for ICCU room Tariff. Do you wish to proceed?", $scope.roomRentRiderConfirm, "Confirm", ["Proceed", "Cancel"]);
        } else {
            var policyDetailConfirm = confirm("By paying additional premium of Rs " + $scope.policyData.quote.estdPremium + "(exclusive of service tax) you can opt for Room Rent Rider where in existing claim amount limit of 1% of Sum Insured per day for Room Tariff, 2% of Sum Insured per day for ICU Tariff and 2% of Sum Insured per day for ICCU room tariff will  be increased to 1.5% of Sum Insured for Room Tariff, 3% of sum Insured per day for ICU room tariff and 3% of sum Insured per day for ICCU room Tariff. Do you wish to proceed?");
            if (policyDetailConfirm) {
                $scope.roomRentRiderConfirm(1);
            } else {
                $scope.roomRentRiderConfirm(2);
            }
        }
    }

    $scope.roomRentRiderConfirm = function (button) {
        if (button === 1) {
            custPopUp = true;
            rrrPopUp = false;
            $("#roomRentRiderID").val("YES");
            $("#roomRentRider").removeClass("hide");
            $(".darkBackground.policyDetailsUl li:nth-last-child(2)").css("border-bottom", "1px solid #5a5d82");
        } else if (button === 2) {
            if (CommonServices.deviceType !== "NA") {
                navigator.notification.confirm("You have clicked Cancel. Rider will not be opted. Do you wish to proceed?", $scope.roomRentRiderConfirmOption, "Confirm", ["Yes", "No"]);
            } else {
                var policyDetailConfirm = confirm("You have clicked Cancel. Rider will not be opted. Do you wish to proceed?");
                if (policyDetailConfirm) {
                    $scope.roomRentRiderConfirmOption(1);
                } else {
                    $scope.roomRentRiderConfirmOption(2);
                }
            }
        }

    }

    $scope.roomRentRiderConfirmOption = function (button) {
        if (button === 1) {
            $("#roomRentRider").removeClass("hide");
            $(".darkBackground.policyDetailsUl li:nth-last-child(2)").css("border-bottom", "1px solid #5a5d82");
            $("#roomRentRiderID").val("NO");
            custPopUp = true;
            rrrPopUp = false;
        } else if (button === 2) {
            roomRentRider();
        }
    }

    //  Gst data form UI
    $('#gstRegId').change(function () {
        if ($scope.selectedIdType == $('#gstRegId').val()) {
            $scope.gsTin = CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.gstin;
        } else {
            $scope.gsTin = "";
        }
    });


    $scope.onGstIdChange = function () {

        var valid = true;
        var regxNRI = /^[0-9]{12}[N]{1}[0-9A-Z]{1}[T]{1}$/;
        var regxUNB = /^[0-9]{12}[U]{1}[0-9A-Z]{1}[N]{1}$/;
        var regxNCC = regexGSTidGlobal;///^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[A-Z0-9]{2}[^\s]$/;

        /*if(!genCustomComponents.conversionService.objectIsEmpty($scope.quickRenewalForm)){
          $scope.quickRenewalForm.gstinInd.$setValidity('gstinExp',true); 
        }*/

        if ($scope.gsTin !== "" && $scope.gsTin !== undefined) {
            $scope.gsTin = $scope.gsTin.toUpperCase();
        }

        if ($scope.gstRegIdType !== '' && $scope.gstRegIdType !== undefined && $scope.gsTin !== "" && $scope.gsTin !== undefined) {
            if ($scope.gstRegIdType === 'NRI') {
                valid = (regxNRI.test($scope.gsTin));
            } else if ($scope.gstRegIdType === 'UNB') {
                valid = (regxUNB.test($scope.gsTin));
            } else if ($scope.gstRegIdType === 'NCC') {
                valid = (regxNCC.test($scope.gsTin));
                //UC for 3749
                // if(valid){
                //     if(CommonServices.gstIdStateCode[$scope.gsTin.slice(0,2)] != undefined){
                //         if(($scope.gstState == CommonServices.gstIdStateCode[$scope.gsTin.slice(0,2)]) || ($scope.gstState.state == CommonServices.gstIdStateCode[$scope.gsTin.slice(0,2)])){
                //             $scope.policyDetailsForm.gsTin.$setValidity("gstStateCode", true);
                //             console.log("state code valid");
                //         }
                //         else{
                //             $scope.policyDetailsForm.gsTin.$setValidity("gstStateCode", false);
                //             $scope.gstErrorMsg = "Please enter valid GSTIN. State code of GSTIN and the state mentioned in address should match.";	
                //         }
                //     }
                //     else{
                //         $scope.policyDetailsForm.gsTin.$setValidity("gstStateCode", false);
                //         $scope.gstErrorMsg = "Please enter GSTIN with a valid state code";
                //     }
                // }
            }
            $scope.gstInPatternErr = valid;
            //$scope.quickRenewalForm.gstinInd.$setValidity('gstinExp',valid);
        } else if ($scope.gsTin === "" || $scope.gsTin === undefined) {
            $scope.gstInPatternErr = true;
        } else if ($scope.gstRegIdType === '' || $scope.gstRegIdType === undefined) {
            if ($scope.gsTin !== "" && $scope.gsTin !== undefined) {
                $scope.gstInPatternErr = false;
            }
        }
        if ($scope.gstInPatternErr === false) {
            $scope.policyDetailsForm.gsTin.$setValidity("gsTin", false);
        } else {
            $scope.policyDetailsForm.gsTin.$setValidity("gsTin", true);
        }

        //below code added by himanshu as part of CR_875
        if ($scope.gstRegIdType !== '' && $scope.gstRegIdType !== undefined) {
            if ($scope.gsTin != undefined) {
                if ($scope.gsTin.includes("AAACN4165C")) {
                    $scope.policyDetailsForm.gsTin.$setValidity("validateNIAPAN", false);
                } else {
                    $scope.policyDetailsForm.gsTin.$setValidity("validateNIAPAN", true);
                }
            }
        } else {
            //$scope.policyDetailsForm.gsTin.$setValidity("gsTin", true);
            $scope.policyDetailsForm.gsTin.$setValidity("validateNIAPAN", true);
        }
    }

    var stateInputMin = 3;
    $scope.gstState = '';
    $scope.result = '';
    /*CR_NP_0880 Starts */
    $scope.stateList = '';
    $scope.cityList = '';
    // $scope.allZipCodeList = '';
    /*CR_NP_0880 Ends */

    $scope.textChanged = function (data) {
        /*CR_NP_0880 Starts */
        $scope.result = 'Please enter valid State by providing at least first 3 characters';
        $scope.showStateError = true;
        if (data != null && data.length >= stateInputMin) {
            // $scope.showStateError = false;
            return gstStateServiceCall(data);
        }
        // else if ($scope.gstState == null) {
        //     $scope.showStateError = false;
        // } 
        // else {
        //     // $scope.showStateError = true;
        //     $scope.result = 'Please enter valid State by providing at least first 3 characters';
        // }

    };

    function gstStateServiceCall(data) {
        /*CR_NP_0880 Starts */
        var getStateListInput = {
            "state": data.toUpperCase()
        }
        var getStateListResponse = RestServices.postService(RestServices.urlPathsNewPortal.getStateList, getStateListInput);

        return getStateListResponse.then(function (response) {

            CommonServices.showLoading(false);
            $scope.showStateError = true;
            if (response.data.hasOwnProperty('states')) {
                return $scope.stateList = response.data.states;
            } else {
                $scope.stateList = "";
                $scope.result = "No search results found";
                if (data == null) {
                    $scope.showStateError = false;
                } else {
                    $scope.showStateError = true;
                }
                return $scope.stateList;
                /*CR_NP_0880 Ends*/
            }

        }, function (error) {
            CommonServices.showLoading(false);
            RestServices.handleWebServiceError(error);
        });

    };

    $scope.onChange = function (data) {
        /*CR_NP_0880 Starts */
        if (data === 'state') {
            $scope.showStateError = true;
            $scope.showPincodeError = false;
            $scope.showCityError = false;
            $scope.gstPinCode = "";
            $scope.gstCityLocation = "";
            $scope.disablePinCodeInput = true; // To disable Pincode Input
            // $scope.disableCityInput = true; // To disable City Input

        } else if (data === 'pinCode') {
            $scope.showPincodeError = true;
            $scope.showCityError = false;
            $scope.gstCityLocation = "";
            // $scope.disableCityInput = true; // To disable City Input

        } else if (data === 'city') {
            $scope.showCityError = true;
        }


        /*CR_NP_0880 Ends*/
    };

    $scope.stateSelect = function () {
        /*CR_NP_0880 start*/
        $scope.showStateError = false;
        $scope.showPincodeError = true;
        $scope.disablePinCodeInput = false;
        $scope.gstPinCode = "";
        // $scope.gstCityLocation = "";

        var getZipCodeListInput = {
            "state": $scope.gstState.state
        };

        var getZipCodeListResponse = RestServices.postService(RestServices.urlPathsNewPortal.getZipCodesbyState, getZipCodeListInput);
        getZipCodeListResponse.then(function (response) {
            CommonServices.showLoading(false);
            if (response.data.hasOwnProperty('pincodes')) {
                $scope.allZipCodeList = response.data.pincodes;
            }

        }, function (error) {
            CommonServices.showLoading(false);
            RestServices.handleWebServiceError(error);
        });
        /*CR_NP_0880 Ends*/
//UC for 3749
        // angular.forEach(CommonServices.gstIdStateCode,function(value,key){
        //     if($scope.gstState.state == value){
        //         $scope.gstinMsg = "GSTIN should start with "+key;
        //     }

        // });
        // $scope.onGstIdChange();

    };

    $scope.pincodeSelect = function () {
        $scope.showPincodeError = false;
        $scope.policyDetailsForm.gstinPinCode.$setValidity("parse", true);
        // $scope.showCityError = true;
        // $scope.disableCityInput = false;
        // $scope.gstCityLocation = '';


        var getCitiesListInput = {
            "state": $scope.gstState.state == undefined ? $scope.gstState : $scope.gstState.state,
            "zipCode": $scope.gstPinCode,
            //"additionalParameter":"MOBILE",
            "city": ""
        };

        var getCitiesListResponse = RestServices.postService(RestServices.urlPathsNewPortal.getCitiesList, getCitiesListInput);

        getCitiesListResponse.then(function (response) {
            CommonServices.showLoading(false);
            if (response.data.hasOwnProperty('cities')) {
                $scope.cityList = response.data.cities.sort(CommonServices.sort_by('city', response.data.cities, ''));
                $scope.gstCityLocation = $scope.cityList[0];
            } else {
                CommonServices.showAlert("Error Occured. Please try again");
                // $scope.showCityError = true;
                // $scope.disableCityInput = false; // To enable City Input
                // $scope.gstCityLocation = "";
            }

        }, function (error) {
            CommonServices.showLoading(false);
            RestServices.handleWebServiceError(error);
        });

    };

    $scope.citySelect = function () {
        $scope.showCityError = false;
    };
    /*CR_NP_0880 Ends */

    $scope.gstFunc = function (obj) {
        return ($filter('filter')($scope.cityList, {
            city: obj
        }));
    };

    $scope.policyDetails = function (button) {
        var stateCodeForUpdate = '';
        var cityCodeForUpdate = '';
        if (button == 1) {
            productCode = CommonServices.getCommonData("productCode");

            var regex = new RegExp(/\b^[a-zA-Z0-9][a-zA-Z0-9._-]*@[a-zA-Z0-9-]+(\.[a-zA-Z]{2,4}){1,3}\b$/);
            var key = $scope.policyData.quote.emailId;

            if (!regex.test(key)) {
                CommonServices.showAlert("Please enter correct email ID");
            } else if ($scope.policyData.quote.mobileNo.length != 10) {
                CommonServices.showAlert("Please enter a valid 10 digit mobile number starting with 5,6,7,8,9");

            } else if ($scope.policyData.quote.mobileNo.length == 10 && regex.test(key)) {

                if (CommonServices.optRoomRentRiderOption) {
                    if ($scope.policyData.quote.isPopup.toUpperCase() === "FALSE" && $scope.policyData.quote.isDropdown.toUpperCase() === "FALSE") {
                        roomRentRiderValue = 'N';
                    } else {
                        var rrrVal = $("#roomRentRiderID :selected").text();
                        if (rrrVal === "YES") {
                            roomRentRiderValue = 'Y';
                        } else {
                            roomRentRiderValue = 'N';
                        }
                    }
                } else {
                    roomRentRiderValue = 'N';
                }

                if ($scope.gstState.stateCode == undefined) {
                    var getStateListInput = {
                        "state": $scope.gstState
                    }

                    var getStateListResponse = RestServices.postService(RestServices.urlPathsNewPortal.getStateList, getStateListInput);
                    getStateListResponse.then(function (response) {

                        CommonServices.showLoading(false);
                        if (response.data.hasOwnProperty('states')) {
                            for (i = 0; i < response.data.states.length; i++) {
                                if (response.data.states[i].state == $scope.gstState) {
                                    stateCodeForUpdate = response.data.states[i].stateCode;
                                    $scope.stateList = response.data.states;
                                    callCityService();
                                }
                            }

                        } else {
                            CommonServices.showLoading(false);
                            CommonServices.showAlert("Sorry! Some error occured please try again later");
                        }

                    }, function (error) {
                        CommonServices.showLoading(false);
                        RestServices.handleWebServiceError(error);
                    });
                } else {
                    callUpdatePolicyHolder();
                }

                function callCityService() {

                    var getAllCitiesListInput = {

                        "state": $scope.gstState,
                        "zipCode": $scope.gstPinCode,
                        //"additionalParameter":"MOBILE",
                        "city": $scope.gstCityLocation.city === undefined ? $scope.gstCityLocation : $scope.gstCityLocation.city
                    };

                    var getCitiesListResponse = RestServices.postService(RestServices.urlPathsNewPortal.getCitiesList, getAllCitiesListInput);

                    getCitiesListResponse.then(function (response) {
                        CommonServices.showLoading(false);
                        if (response.data.hasOwnProperty('cities')) {
                            for (i = 0; i < response.data.cities.length; i++) {
                                if (response.data.cities[i].city == $scope.gstCityLocation || $scope.gstCityLocation.city) {
                                    cityCodeForUpdate = response.data.cities[i].cityCode;
                                    callUpdatePolicyHolder();
                                    break;
                                }
                            }
                        }

                    }, function (error) {
                        CommonServices.showLoading(false);
                        RestServices.handleWebServiceError(error);
                    });

                };

                function callUpdatePolicyHolder() {

                    var uin = "";
                    var gstRegIdType = "";
                    var gsTin = "";
                    var uinVal = $('#gstUinid').val();
                    if (uinVal === "" || uinVal === undefined) {
                        uin = " ";
                    } else {
                        uin = uinVal;
                    }
                    if ($scope.gstRegIdType === "" || $scope.gstRegIdType === undefined) {
                        gstRegIdType = " ";
                    } else {
                        gstRegIdType = $scope.gstRegIdType;
                    }
                    if ($scope.gsTin === "" || $scope.gsTin === undefined) {
                        gsTin = " ";
                    } else {
                        gsTin = $scope.gsTin;
                    }
                    var policyHolderUpdateInput = {
                        "userCode": CommonServices.getCommonData("userCode").toUpperCase(),
                        "rolecode": CommonServices.getCommonData("loggedInRole"),
                        "policyHolderCode": $scope.policyData.quote.policyHolderCode,
                        "mobileNo": $scope.policyData.quote.mobileNo,
                        "emailId": $scope.policyData.quote.emailId,
                        "gstRegIdType": gstRegIdType,
                        "gstin": gsTin,
                        "uin": uin,
                        "city": cityCodeForUpdate === '' ? $scope.gstCityLocation.cityCode : cityCodeForUpdate,
                        "state": stateCodeForUpdate === '' ? $scope.gstState.stateCode : stateCodeForUpdate,
                        "pinCode": $scope.gstPinCode.zipCode === undefined ? $scope.gstPinCode : $scope.gstPinCode.zipCode,
                        /*Added by 851587 for CR_NP_0744*/
                        "panNumber": $scope.panNumber,
                        "aadhaarNo": $scope.aadhaarObj.aadhaarNumber,
                        /*CR_NP_0744 ends*/
                        "addressLine1": "",
                        "addressLine2": ""
                    };


                    if ($rootScope.panCardNum !== undefined && $rootScope.panCardNum !== "") {
                        policyHolderUpdateInput.panNumber = $rootScope.panCardNum;
                        CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.panNumber = $rootScope.panCardNum;
                    }
                    var updatePolicyHolderResponse = RestServices.postService(RestServices.urlPathsNewPortal.updatePolicyHolderContact, policyHolderUpdateInput);

                    updatePolicyHolderResponse.then(function (response) {

                        CommonServices.showLoading(false);
                        if (response.data.pRetCode == 0) {
                            /*Added during CR_NP_0546C*/
                            if (CommonServices.QRrenewalData.quote.productCode === "AK" || CommonServices.QRrenewalData.quote.productCode === "NP" || CommonServices.QRrenewalData.quote.productCode === "TU" || CommonServices.QRrenewalData.quote.productCode === "UK" || CommonServices.QRrenewalData.quote.productCode === "CJ"
                                /*******CR 885 changes starts*********/
                                || CommonServices.QRrenewalData.quote.productCode === "HN") {
                                /*******CR 885 changes ends*********/
                                saveQuoteServiceCall();
                            } else {
                                breakInQuoteCheck();
                            }
                            /*CR_NP_0546C changes Ends*/
                        } else {
                            if (response.data.errorCode != undefined) {
                                CommonServices.showAlert(response.data.errorMessage);
                            } else {
                                CommonServices.showAlert(response.data.pRetErr);
                            }

                        }

                    }, function (error) {
                        CommonServices.showLoading(false);
                        RestServices.handleWebServiceError(error);
                    });
                };


            }
        }
    };

    function breakInQuoteCheck() {
        var coverageType = CommonServices.getCommonData("coverageType");

        if (CommonServices.breakInOccured === 'Y') {
            /**** changes made wile developing 859*/
            if (CommonServices.QRrenewalData.quote.productCode === 'RK') {
                saveQuoteServiceCall();
            } else {
                if (coverageType === "EHMNTCOVER" || coverageType === "ENHANCEMENTCOVER") {
                    coverageType = "ENHANCEMENT";
                }
                if (coverageType === "LIABILITY") {
                    saveQuoteServiceCall();
                } else {
                    var fetchBreakInConfigData = {
                        "coverageType": coverageType,
                        "productCode": productCode,
                        "channelCode": "AGENT",
                        "officeCode": CommonServices.getCommonData("branchCode"),
                        "userId": CommonServices.getCommonData("userCode").toUpperCase(),
                        "uiFlow": "NON_CUSTOMER"
                    };
                    var fetchBreakInConfigResponse = RestServices.postService(RestServices.urlPathsNewPortal.fetchBreakinConfigData, fetchBreakInConfigData);
                    fetchBreakInConfigResponse.then(
                        function (response) {
                            CommonServices.showLoading(false);
                            if (response.data.breakinConfigurations[0].breakInFlag === "Y") {
                                if (response.data.breakinConfigurations[0].breakInFlowType == 'Policy Issuance') {
                                    CommonServices.breakInCanceled = true;
                                    saveQuoteServiceCall();
                                } else {
                                    var date = CommonServices.getCommonData("serverDate");
                                    date = date.split("/");
                                    date = date[1] + "/" + date[0] + "/" + date[2];
                                    if (CommonServices.deviceType !== "NA") {
                                        navigator.notification.confirm("Since there is a break in insurance, you will not be allowed to approve this quote online. To complete the approval, upload the vehicle photos using mobile camera with NIA Mobile App, post verification of the photos and approval of the quote by NIA office , premium collection and policy issuance can be completed. Your quote will remain valid only till " + date + " till 23:29:59. Would you like to proceed 'Confirm' or 'Cancel'.", breakInQuoteSubmission, "Confirm", ["Confirm", "Cancel"]);
                                    } else {
                                        var breakInConfirm = confirm("Since there is a break in insurance, you will not be allowed to approve this quote online. To complete the approval, upload the vehicle photos using mobile camera with NIA Mobile App, post verification of the photos and approval of the quote by NIA office , premium collection and policy issuance can be completed. Your quote will remain valid only till " + date + " till 23:29:59. Would you like to proceed 'Confirm' or 'Cancel'.");
                                        if (breakInConfirm) {
                                            breakInQuoteSubmission(1);
                                        } else {
                                            breakInQuoteSubmission(2);
                                        }
                                    }
                                }
                            } else {
                                CommonServices.showAlert("We find there is a break in insurance and you will not be able to avail policy online. Contact nearest NIA office for more information");
                            }
                        },
                        function (error) { // failure
                            CommonServices.showLoading(false);
                            RestServices.handleWebServiceError(error);
                        });
                }
            }
        } else {
            saveQuoteServiceCall();
        }
    };
    /**** changes made wile developing 859*/

    function breakInQuoteSubmission(button) {
        if (button === 1) {
            CommonServices.breakInCanceled = false;
            saveQuoteServiceCall();
        } else if (button === 2) {
            CommonServices.breakInCanceled = true;
            saveQuoteServiceCall();
        }

    }


    function saveQuoteServiceCall() {
        var savePolicyPostData = {};
        var savePolicyResponse;
        /*Added for NP_CR_3444 Start*/
        if ($scope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner === undefined || $scope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner === "") {
            $rootScope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner = null;
        }
        else {

            if ($scope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner === "Motor Cycle with Gear") {
                $rootScope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner = "MCGEAR";
            } else if ($scope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner === "Motor Cycle without Gear") {
                $rootScope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner = "MCNOGEAR";
            }
            else if ($scope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner === "Auto Rickshaw") {
                $rootScope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner = "AUTORKSW";
            }
            else if ($scope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner === "Heavy Goods Vehicle") {
                $rootScope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner = "HGOODSVEH";
            }
            else if ($scope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner === "Heavy Passenger Motor Vehicle") {
                $rootScope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner = "HPMOTORVEH";
            }
            else if ($scope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner === "Medium Goods Vehicle") {
                $rootScope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner = "MGOODSVEH";
            }
            else if ($scope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner === "Medium Passenger Motor Vehicle") {
                $rootScope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner = "MPMOTORVEH";
            }
            else if ($scope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner === "Transport Vehicle") {
                $rootScope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner = "TRNSPRTVEH";
            }
            else if ($scope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner === "Light Motor Vehicle") {
                $rootScope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner = "LMOTORVEH";
            }
            else if ($scope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner === "Others") {
                $rootScope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner = "OTHERS";
            }

            //$rootScope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner = $scope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner;
        }
        if ($scope.buyNow.twoWheeler.addCovers.ownerDriveVehOrNotTW === undefined || $scope.buyNow.twoWheeler.addCovers.ownerDriveVehOrNotTW === "") {
            $rootScope.buyNow.twoWheeler.addCovers.ownerDriveVehOrNotTW = null;
        }
        else {

            if ($scope.buyNow.twoWheeler.addCovers.ownerDriveVehOrNotTW === true) {
                $rootScope.buyNow.twoWheeler.addCovers.ownerDriveVehOrNotTW = "Y";
            } else if ($scope.buyNow.twoWheeler.addCovers.ownerDriveVehOrNotTW === false) {
                $rootScope.buyNow.twoWheeler.addCovers.ownerDriveVehOrNotTW = "N";
            }

        }



        if ($scope.buyNow.twoWheeler.addCovers.licenseNoOwnerDriver === undefined || $scope.buyNow.twoWheeler.addCovers.licenseNoOwnerDriver === "") {
            $rootScope.buyNow.twoWheeler.addCovers.licenseNoOwnerDriver = null;
        }
        else {
            $rootScope.buyNow.twoWheeler.addCovers.licenseNoOwnerDriver = $scope.buyNow.twoWheeler.addCovers.licenseNoOwnerDriver;
        }
        if ($scope.buyNow.twoWheeler.addCovers.nameOfNominee === undefined || $scope.buyNow.twoWheeler.addCovers.nameOfNominee === "") {
            $rootScope.buyNow.twoWheeler.addCovers.nameOfNominee = null;
        }
        else {
            $rootScope.buyNow.twoWheeler.addCovers.nameOfNominee = $scope.buyNow.twoWheeler.addCovers.nameOfNominee;
        }
        if ($scope.buyNow.twoWheeler.addCovers.ageOfNominee === undefined || $scope.buyNow.twoWheeler.addCovers.ageOfNominee === "") {
            $rootScope.buyNow.twoWheeler.addCovers.ageOfNominee = null;
        }
        else {
            $rootScope.buyNow.twoWheeler.addCovers.ageOfNominee = $scope.buyNow.twoWheeler.addCovers.ageOfNominee;
        }
        if ($scope.buyNow.twoWheeler.addCovers.relnWithInsured === undefined || $scope.buyNow.twoWheeler.addCovers.relnWithInsured === "") {
            $rootScope.buyNow.twoWheeler.addCovers.relnWithInsured = null;
        }
        else {
            $rootScope.buyNow.twoWheeler.addCovers.relnWithInsured = $scope.buyNow.twoWheeler.addCovers.relnWithInsured;
        }
        var durationForPaOwnerDriverCover = "";
        if ($rootScope.buyNow.twoWheeler.addCovers.DurationForPaOwnerDriverCover === "First Year") {
            durationForPaOwnerDriverCover = "OneYear";
        }
        else if ($rootScope.buyNow.twoWheeler.addCovers.DurationForPaOwnerDriverCover === "Full Policy duration") {
            durationForPaOwnerDriverCover = "LongTerm";
        }
        if ($scope.buyNow.twoWheeler.addCovers.compulsoryPACoverPolicy === undefined || $scope.buyNow.twoWheeler.addCovers.compulsoryPACoverPolicy === "") {
            $rootScope.buyNow.twoWheeler.addCovers.compulsoryPACoverPolicy = null;
        }
        else {
            if ($scope.buyNow.twoWheeler.addCovers.compulsoryPACoverPolicy === "YES") {
                $rootScope.buyNow.twoWheeler.addCovers.compulsoryPACoverPolicy = "Y"
            }
            else if ($scope.buyNow.twoWheeler.addCovers.compulsoryPACoverPolicy === "NO") {
                $rootScope.buyNow.twoWheeler.addCovers.compulsoryPACoverPolicy = "N"
            }
        }
        if ($scope.buyNow.twoWheeler.addCovers.sumInsuredOfAtleast15lacs === undefined || $scope.buyNow.twoWheeler.addCovers.sumInsuredOfAtleast15lacs === "") {
            $rootScope.buyNow.twoWheeler.addCovers.sumInsuredOfAtleast15lacs = null;
        }
        else {
            if ($scope.buyNow.twoWheeler.addCovers.sumInsuredOfAtleast15lacs === "YES") {
                $rootScope.buyNow.twoWheeler.addCovers.sumInsuredOfAtleast15lacs = "Y"
            }
            else if ($scope.buyNow.twoWheeler.addCovers.sumInsuredOfAtleast15lacs === "NO") {
                $rootScope.buyNow.twoWheeler.addCovers.sumInsuredOfAtleast15lacs = "N"
            }
        }
        /*Start Remove for CR_3444B
        if ($scope.buyNow.twoWheeler.addCovers.paCoverForAnyOtherVehicle === undefined || $scope.buyNow.twoWheeler.addCovers.paCoverForAnyOtherVehicle === "") {
            $rootScope.buyNow.twoWheeler.addCovers.paCoverForAnyOtherVehicle = null;
        }
        else {
                if($scope.buyNow.twoWheeler.addCovers.paCoverForAnyOtherVehicle==="YES"){
                $rootScope.buyNow.twoWheeler.addCovers.paCoverForAnyOtherVehicle="Y"
                }
                else if($scope.buyNow.twoWheeler.addCovers.paCoverForAnyOtherVehicle==="NO"){
                $rootScope.buyNow.twoWheeler.addCovers.paCoverForAnyOtherVehicle="N"
                }
            }
        End Remove for CR_3444B*/
        /*Added for NP_CR_3444 end*/



        if (productCode == "PC" || productCode == "CV" || productCode == "TW" || productCode == "SQ" || productCode == "SS") { /* CR_NP_3621 */
            if (CommonServices.breakInOccured === 'Y' && CommonServices.breakInCanceled !== undefined && CommonServices.breakInCanceled === false && CommonServices.getCommonData("coverageType") !== "LIABILITY") {
                savePolicyPostData = {
                    "quote": {
                        "quoteNumber": $scope.policyData.quote.quoteNumber,
                        "policyHolderCode": $scope.policyData.quote.policyHolderCode,
                        "productCode": productCode,
                        "vehicles": [{
                            "vehicleDetails": {
                                "registrationExpiryDate": CommonServices.getCommonData("regValidityDate"),
                                "registrationNo1": CommonServices.getCommonData("vehicleRegNo1"),
                                "registrationNo2": CommonServices.getCommonData("vehicleRegNo2"),
                                "registrationNo3": CommonServices.getCommonData("vehicleRegNo3"),
                                "registrationNo4": CommonServices.getCommonData("vehicleRegNo4"),
                                "dateOfRegistration": CommonServices.getCommonData("regDate"),
                                "engineNo": CommonServices.getCommonData("engineNo"),
                                "chassisNo": CommonServices.getCommonData("chassisNo"),
                                "colorAsPerRCbook": CommonServices.getCommonData("colorAsPerRCbook"),
                                "doYouHoldValidDrivingLicense": $rootScope.buyNow.twoWheeler.addCovers.ownerDriveVehOrNotTW,
                                "ownerDetails": {
                                    "standAloneCompulsoryPACover": $rootScope.buyNow.twoWheeler.addCovers.compulsoryPACoverPolicy,//CR 3444
                                    "pAPolicyWithSumInsured": $rootScope.buyNow.twoWheeler.addCovers.sumInsuredOfAtleast15lacs,//CR 3444
                                    /*"compulsoryPACoverOtherVehicle": $rootScope.buyNow.twoWheeler.addCovers.paCoverForAnyOtherVehicle*///CR 3444B
                                    "licenseTypeOwnerDriver": $rootScope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner,//CR 3444
                                    "licenseNoOwnerDriver": $rootScope.buyNow.twoWheeler.addCovers.licenseNoOwnerDriver//CR 3444

                                },
                                "nomineeDetails": {
                                    "name": $rootScope.buyNow.twoWheeler.addCovers.nameOfNominee,//CR 3444
                                    "age": $rootScope.buyNow.twoWheeler.addCovers.ageOfNominee,//CR 3444
                                    "relationshipWithInsured": $rootScope.buyNow.twoWheeler.addCovers.relnWithInsured//CR 3444
                                },

                            },
                            "coverages": [
                                {
                                    "additionalCoverageDetails": {
                                        "sumInsuredForPAToOwnerDriver": $scope.buyNow.twoWheeler.addCovers.sumInsForOwnerDriver//CR 3444
                                    }

                                }],
                        }],
                        "additionalQuoteDetails": {
                            "breakInStatus": "BREAKPUP"
                        },
                        "emailId": $scope.policyData.quote.emailId,
                        "mobileNo": $scope.policyData.quote.mobileNo,
                        "tpa": null,
                        "roomRentRider": null
                    },
                    "userProfile": {
                        "userId": CommonServices.getCommonData("userCode").toUpperCase(),
                        "loggedInRole": CommonServices.getCommonData("loggedInRole")
                    }
                };
            } else {
                savePolicyPostData = {
                    "quote": {
                        "quoteNumber": $scope.policyData.quote.quoteNumber,
                        "policyHolderCode": $scope.policyData.quote.policyHolderCode,
                        "productCode": productCode,
                        "vehicles": [{
                            "vehicleDetails": {
                                "registrationExpiryDate": CommonServices.getCommonData("regValidityDate"),
                                "registrationNo1": CommonServices.getCommonData("vehicleRegNo1"),
                                "registrationNo2": CommonServices.getCommonData("vehicleRegNo2"),
                                "registrationNo3": CommonServices.getCommonData("vehicleRegNo3"),
                                "registrationNo4": CommonServices.getCommonData("vehicleRegNo4"),
                                "dateOfRegistration": CommonServices.getCommonData("regDate"),
                                "engineNo": CommonServices.getCommonData("engineNo"),
                                "chassisNo": CommonServices.getCommonData("chassisNo"),
                                "colorAsPerRCbook": CommonServices.getCommonData("colorAsPerRCbook"),
                                "doYouHoldValidDrivingLicense": $rootScope.buyNow.twoWheeler.addCovers.ownerDriveVehOrNotTW,
                                "ownerDetails": {
                                    "standAloneCompulsoryPACover": $rootScope.buyNow.twoWheeler.addCovers.compulsoryPACoverPolicy,//CR 3444
                                    "pAPolicyWithSumInsured": $rootScope.buyNow.twoWheeler.addCovers.sumInsuredOfAtleast15lacs,//CR 3444
                                    /*"compulsoryPACoverOtherVehicle": $rootScope.buyNow.twoWheeler.addCovers.paCoverForAnyOtherVehicle,*///CR 3444B
                                    "licenseTypeOwnerDriver": $rootScope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner,//CR 3444
                                    "licenseNoOwnerDriver": $rootScope.buyNow.twoWheeler.addCovers.licenseNoOwnerDriver//CR 3444

                                },
                                "nomineeDetails": {
                                    "name": $rootScope.buyNow.twoWheeler.addCovers.nameOfNominee,//CR 3444
                                    "age": $rootScope.buyNow.twoWheeler.addCovers.ageOfNominee,//CR 3444
                                    "relationshipWithInsured": $rootScope.buyNow.twoWheeler.addCovers.relnWithInsured//CR 3444
                                },

                            },
                            "coverages": [
                                {
                                    "additionalCoverageDetails": {
                                        "sumInsuredForPAToOwnerDriver": $scope.buyNow.twoWheeler.addCovers.sumInsForOwnerDriver//CR 3444
                                    }

                                }],
                        }],
                        "emailId": $scope.policyData.quote.emailId,
                        "mobileNo": $scope.policyData.quote.mobileNo,
                        "tpa": null,
                        "roomRentRider": null
                    },
                    "userProfile": {
                        "userId": CommonServices.getCommonData("userCode").toUpperCase(),
                        "loggedInRole": CommonServices.getCommonData("loggedInRole")
                    }
                };
            }
        } else if (CommonServices.NmMcProduct) {
            var risks = CommonServices.editQuoteInsured.risks;
            for (var i = 0; i < risks.length; i++) {
                delete risks[i].$$hashKey;
            }
            var preMedicalCheckUpDetails = "";
            if (CommonServices.editQuoteInsured.preMedicalCheckUpDetails === "" || CommonServices.editQuoteInsured.preMedicalCheckUpDetails === null || CommonServices.editQuoteInsured.preMedicalCheckUpDetails === undefined) {
                preMedicalCheckUpDetails = "none";
            } else {
                preMedicalCheckUpDetails = CommonServices.editQuoteInsured.preMedicalCheckUpDetails;
            }
            savePolicyPostData = {
                "quote": {
                    "quoteNumber": CommonServices.editQuoteInsured.quoteNumber,
                    "productCode": CommonServices.editQuoteInsured.productCode,
                    "policyHolderCode": CommonServices.editQuoteInsured.policyHolderCode,
                    "isTPARequired": "Y",
                    "branchcode": null,
                    "policyHolderName": CommonServices.editQuoteInsured.policyHolderName,
                    "policyStartDate": CommonServices.editQuoteInsured.policyStartDate,
                    "policyExpiryDate": CommonServices.editQuoteInsured.policyExpiryDate,
                    "currentStatus": CommonServices.editQuoteInsured.currentStatus,
                    "policyStatusCode": CommonServices.editQuoteInsured.policyStatusCode,
                    "mobileNo": $scope.policyData.quote.mobileNo,
                    "emailId": $scope.policyData.quote.emailId,
                    "progressLevel": "RS",
                    "optionalCoverINoProportionateDeduction": CommonServices.editQuoteInsured.optionalCoverINoProportionateDeduction,
                    "optionalCoverIIIRevisioninCataractLimit": CommonServices.editQuoteInsured.optionalCoverIIIRevisioninCataractLimit,
                    "optionalCoverIVVoluntaryCopay": CommonServices.editQuoteInsured.optionalCoverIVVoluntaryCopay,
                    "preMedicalCheckUpDetails": preMedicalCheckUpDetails,
                    "premiumDetails": CommonServices.editQuoteInsured.premiumDetails,
                    "nomineeDetails": CommonServices.editQuoteInsured.nomineeDetails,
                    "risks": risks,
                    "partyDetailsList": CommonServices.editQuoteInsured.partyDetailsList,
                    "name": $rootScope.buyNow.twoWheeler.addCovers.nameOfNominee,//CR 3444
                    "age": $rootScope.buyNow.twoWheeler.addCovers.ageOfNominee,//CR 3444
                    "relationshipWithInsured": $rootScope.buyNow.twoWheeler.addCovers.relnWithInsured,//CR 3444
                    "licenseNoOwnerDriver": $rootScope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner,//CR 3444
                    "licenseTypeOwnerDriver": $rootScope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner,//CR 3444
                    "standAloneCompulsoryPACover": $rootScope.buyNow.twoWheeler.addCovers.compulsoryPACoverPolicy,
                    "pAPolicyWithSumInsured": $rootScope.buyNow.twoWheeler.addCovers.sumInsuredOfAtleast15lacs
                    /*"compulsoryPACoverOtherVehicle": $rootScope.buyNow.twoWheeler.addCovers.paCoverForAnyOtherVehicle*/ //CR_3444B
                },
                "userProfile": {
                    "userId": CommonServices.getCommonData("userCode").toUpperCase(),
                    "footer": null,
                    "loggedInRole": CommonServices.getCommonData("loggedInRole"),
                    "uiFlow": null
                }
            };
            console.log(savePolicyPostData);
        } else {
            savePolicyPostData = {
                "quote": {
                    "quoteNumber": $scope.policyData.quote.quoteNumber,
                    "policyHolderCode": $scope.policyData.quote.policyHolderCode,
                    "productCode": productCode,
                    "vehicles": [{
                        "vehicleDetails": {
                            "doYouHoldValidDrivingLicense": $rootScope.buyNow.twoWheeler.addCovers.ownerDriveVehOrNotTW,
                            "ownerDetails": {
                                "standAloneCompulsoryPACover": $rootScope.buyNow.twoWheeler.addCovers.compulsoryPACoverPolicy,//CR 3444
                                "pAPolicyWithSumInsured": $rootScope.buyNow.twoWheeler.addCovers.sumInsuredOfAtleast15lacs,//CR 3444
                                /*"compulsoryPACoverOtherVehicle": $rootScope.buyNow.twoWheeler.addCovers.paCoverForAnyOtherVehicle,*///CR 3444B
                                "licenseTypeOwnerDriver": $rootScope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner,//CR 3444
                                "licenseNoOwnerDriver": $rootScope.buyNow.twoWheeler.addCovers.licenseNoOwnerDriver//CR 3444

                            },
                            "nomineeDetails": {
                                "name": $rootScope.buyNow.twoWheeler.addCovers.nameOfNominee,//CR 3444
                                "age": $rootScope.buyNow.twoWheeler.addCovers.ageOfNominee,//CR 3444
                                "relationshipWithInsured": $rootScope.buyNow.twoWheeler.addCovers.relnWithInsured//CR 3444
                            },

                        },
                        "coverages": [
                            {
                                "additionalCoverageDetails": {
                                    "sumInsuredForPAToOwnerDriver": $scope.buyNow.twoWheeler.addCovers.sumInsForOwnerDriver//CR 3444
                                }

                            }],
                    }],
                    "emailId": $scope.policyData.quote.emailId,
                    "mobileNo": $scope.policyData.quote.mobileNo,
                    "tpa": null,
                    "roomRentRider": roomRentRiderValue
                },
                "userProfile": {
                    "userId": CommonServices.getCommonData("userCode").toUpperCase(),
                    "loggedInRole": CommonServices.getCommonData("loggedInRole")
                }
            };
        }

        if (productCode === 'NF' || productCode === 'NM' || productCode === 'UH' || productCode === 'TU' || productCode === 'AK' || productCode === 'NP') {
            savePolicyResponse = RestServices.postService(RestServices.urlPathsNewPortal.saveRenewedHealthQuote, savePolicyPostData);
        } else if (productCode === 'PC' || productCode === 'CV' || productCode === 'TW' || productCode === 'SQ' || productCode === 'SS') { /* CR_NP_3621 */
            savePolicyResponse = RestServices.postService(RestServices.urlPathsNewPortal.saveRenewedMotorQuote, savePolicyPostData);
        } else if (CommonServices.editQuoteInsured !== undefined && CommonServices.editQuoteInsured !== "") {
            if (CommonServices.editQuoteInsured.productCode === "UK" || CommonServices.editQuoteInsured.productCode === "MC" || CommonServices.editQuoteInsured.productCode === "NM") {
                if (CommonServices.NmMcProduct) {
                    savePolicyResponse = RestServices.postService(RestServices.urlPathsNewPortal.topUpSaveQuote, savePolicyPostData);
                }
            }
        } else {
            savePolicyResponse = RestServices.postService(RestServices.urlPathsNewPortal.saveRenewedNonMotorQuote, savePolicyPostData);
        }
        savePolicyResponse.then(
            function (response) { // success
                CommonServices.setCommonData("partyCode", $scope.policyData.quote.policyHolderCode);

                // added for CR_646E
                /***********CR 885 changes starts*****/
                if ($scope.policyData.quote.prevPolProductCode != undefined) {
                    if ($scope.policyData.quote.prevPolProductCode === "UK" || $scope.policyData.quote.prevPolProductCode == "HN") {
                        /***********CR 885 changes ends*****/
                        CommonServices.setCommonData("prevPolProductCode", null);
                    } else {


                        CommonServices.setCommonData("prevPolProductCode", $scope.policyData.quote.prevPolProductCode);
                    }
                }
                else {
                    CommonServices.setCommonData("prevPolProductCode", null);
                }

                if (response.data.errorCode !== 0 && response.data.errorCode !== undefined) {
                    CommonServices.showLoading(false);
                    CommonServices.showAlert(response.data.errorMessage);
                    $location.path('/newRenewPolicy/getNewRenewPolicy');
                    // $scope.policyDetailsCtrl.onload();
                } else {

                    //angular.extend($scope.policyData,response.data);
                    if (response.data.userProfile.footer != undefined) {
                        CommonServices.showLoading(false);
                        angular.extend($scope.policyData.quote, response.data.quote);
                        if (response.data.userProfile.footer.hasOwnProperty('errorDescription')) {
                            if (response.data.userProfile.footer.errorDescription.trim() === 'Portal Quotation Saved') {
                                CommonServices.saveQuoteDetailsData = response.data;
                                /*Added for CR_NP_0744, added to check if this is from QR flow or not*/
                                $rootScope.isQrFlow = true;
                                /*CR_NP_0744 ends*/
                                if (CommonServices.NmMcProduct) {
                                    $state.go('newRenewPolicy.migrationDocUpload');
                                } else if (CommonServices.breakInOccured === 'Y') {
                                    /*Added during CR_NP_0546C*//****** CR 885 changes starts*******//****** CR 859 changes starts*******/
                                    if (CommonServices.QRrenewalData.quote.productCode === "AK" || CommonServices.QRrenewalData.quote.productCode === "NP" || CommonServices.QRrenewalData.quote.productCode === "TU" || CommonServices.QRrenewalData.quote.productCode === "UK" || CommonServices.QRrenewalData.quote.productCode === "HN" || CommonServices.QRrenewalData.quote.productCode === "RK") {
                                        /****** CR 885 changes ends*******/
                                        /****** CR 859 changes ends*******/
                                        approveQuoteServiceCall(response.data.quote.quoteNumber);
                                    } else {
                                        if ((CommonServices.QRrenewalData.quote.productCode === "PC" || CommonServices.QRrenewalData.quote.productCode === "CV" || CommonServices.QRrenewalData.quote.productCode === "TW" || CommonServices.QRrenewalData.quote.productCode === "SQ" || CommonServices.QRrenewalData.quote.productCode === "SS") && CommonServices.getCommonData("coverageType") !== "LIABILITY") { /* CR_NP_3621 */
                                            if (CommonServices.breakInCanceled === false) {
                                                CommonServices.showAlert('Break in Insurance request has been submitted successfully. Please upload the vehicle photos for NIA office approvals through mobile app only.');
                                            }
                                            CommonServices.showLoading(false);
                                            $state.go('home');
                                        } else {
                                            approveQuoteServiceCall(response.data.quote.quoteNumber);
                                        }
                                    }
                                    /*CR_NP_0546C changes Ends*/
                                } else {
                                    approveQuoteServiceCall(response.data.quote.quoteNumber);
                                }
                            } else {
                                CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
                            }
                        } else {
                            if (response.data.userProfile.footer.status.trim() === 'Portal Quotation Saved') {
                                CommonServices.saveQuoteDetailsData = response.data;
                                if (CommonServices.NmMcProduct) {
                                    $state.go('newRenewPolicy.migrationDocUpload');
                                } else if (CommonServices.breakInOccured === 'Y') {
                                    /*Added during CR_NP_0546C*/
                                    if (CommonServices.QRrenewalData.quote.productCode === "AK" || CommonServices.QRrenewalData.quote.productCode === "NP" || CommonServices.QRrenewalData.quote.productCode === "TU" || CommonServices.QRrenewalData.quote.productCode === "UK") {
                                        approveQuoteServiceCall(response.data.quote.quoteNumber);
                                    } else {
                                        if (CommonServices.breakInCanceled === false) {
                                            CommonServices.showAlert('Break in Insurance request has been submitted successfully. Please upload the vehicle photos for NIA office approvals through mobile app only.');
                                        }
                                        CommonServices.showLoading(false);
                                        $state.go('home');
                                    }
                                    /*CR_NP_0546C changes Ends*/
                                } else {
                                    approveQuoteServiceCall(response.data.quote.quoteNumber);
                                }
                            } else {
                                CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
                            }
                        }
                    } else { // undefined	 
                        CommonServices.showAlert(response.data.errorMessage);
                    }

                } // else
            }, // response
            function (error) { // failure
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);

                // $scope.policyDetailsCtrl.onload();
            }
        );
    }

    function approveQuoteServiceCall(quoteNum) {
        var approvePolicyPostData = {
            "userProfile": {
                "userId": CommonServices.getCommonData("userCode").toUpperCase(),
                "loggedInRole": CommonServices.getCommonData("loggedInRole")
            },
            "quote": {
                "policyStartDate": $scope.policyData.quote.policyStartDate,
                "quoteNumber": quoteNum,
                "policyType": null,
                "productCode": productCode,
                "processType": "QR", // added as part of CR_646E
                "prevPolProductCode": CommonServices.getCommonData("prevPolProductCode") // added as part of CR_646E

            }
        };
        
        if (CommonServices.getCommonData("addToCart")==='cart') { // CR3546
            CartServices.approveAndAddToCart(approvePolicyPostData, productCode);
            return;
        }
        var approvePolicyResponse = RestServices.postService(RestServices.urlPathsNewPortal.approveRenewedQuote, approvePolicyPostData);
        approvePolicyResponse.then(
            function (response) {

                if (response.data === "") {
                    CommonServices.showLoading(false);
                    CommonServices.showAlert("Something went wrong. Please try again after some time");
                    return;
                }

                if (response.data.errorCode !== undefined) {
                    CommonServices.showLoading(false);
                    /**CR690 Start**/
                    if (response.data.userProfile.footer.errorCode === "224541") {
                        $rootScope.panmodalOpen = true;
                        CommonServices.setCommonData("setPanMsg", response.data.userProfile.footer.errorDescription);
                    }
                    /**CR690 End**/
                    else {
                        CommonServices.showAlert(response.data.errorMessage);
                    }
                    //$location.path('/newRenewPolicy/getNewRenewPolicy');
                    //$scope.policyDetailsCtrl.onload();
                } else {
                    if ((response.data.userProfile.footer.errorDescription.indexOf("Proposal Approved") > -1) ||
                        (response.data.userProfile.footer.errorDescription.indexOf("Approving Renewal") > -1) ||
                        (response.data.userProfile.footer.errorDescription.indexOf("Policy already approved") > -1)) {

                        var domainData = {
                            "lngCode": "EN",
                            "keys": ["CHEQUE_PO_DRAFT_TYPE"]
                        };
                        var getDomainResponse = "";
                        getDomainResponse = RestServices.postService(RestServices.urlPathsNewPortal.getDomainValues, domainData);
                        getDomainResponse.then(
                            function (response) {
                                CommonServices.showLoading(false);
                                for (var i = 0; i < response.data.domainValues.length; i++) {
                                    var chequeTypes = {
                                        'name': response.data.domainValues[i].mnemonic
                                    };
                                    CommonServices.chequeList.push(chequeTypes);
                                }
                                CommonServices.managePolicyCollection = false;
                                $rootScope.panCardNum = "";
                                $state.go('newRenewPolicy.collectionForm');
                            },
                            function (error) {
                                CommonServices.showLoading(false);
                                RestServices.handleWebServiceError(error);
                            });

                    } else {

                        CommonServices.showLoading(false);
                        /**CR690 Start**/
                        if (response.data.userProfile.footer.errorCode === "224541") {
                            $rootScope.panmodalOpen = true;
                            CommonServices.setCommonData("setPanMsg", response.data.userProfile.footer.errorDescription);
                        }
                        /**CR690 End**/
                        else {
                            CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
                        }
                        //$location.path('/newRenewPolicy/getNewRenewPolicy');
                    }
                }
            },
            function (error) { // failure
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);

            }
        );
    }

}]);

agentApp.controller('migrationDocUploadCtrl', ['$scope', '$location', 'RestServices', 'CommonServices', '$state', function ($scope, $location, RestServices, CommonServices, $state) {

    function getIDdocName(idDocName) {
        switch (idDocName) {
            case "VoterIden":
                return "Voter Identity Card";
            //Below lines Commented for CR_NP_0744E
            // case "AD":
            //     return "Aadhaar Card";
            case "PANCard":
                return "PAN Card";
            case "DrivingLS":
                return "Driving License";
            case "Passport":
                return "Passport";
            case "AO":
                return "Any Other";
            default:
                return "";
        }
    }

    $scope.insuredMembers = CommonServices.editQuoteInsured.risks;

    for (var i = 0; i < CommonServices.editQuoteInsured.risks.length; i++) {
        CommonServices.editQuoteInsured.risks[i].riskDetails.typeOfDoc = getIDdocName(CommonServices.editQuoteInsured.risks[i].riskDetails.natureOfId);
    }

    $scope.documentsNmMcToUk = {
        uploaddocsmodel: [],
        uploaddocscollection: []
    };

    $("#popup-container").on("click", function () {
        $(this).hide();
    });
    $scope.maxImageCount = 1;

    $scope.chooseImageUploadOption = function (event) {

        $scope.artID = $(event.target).parent().parent().attr("id");
        $scope.imgCount = $('#' + $scope.artID + ' img').length;

        $scope.totalImageCount = $("#" + $scope.artID + " .photo-container img").length;

        if ($scope.totalImageCount < $scope.maxImageCount) {
            $("#upload-options").show();
            $("#popup-container").show();

            $(document).off('click', '#capture-photo-cam');
            $(document).on('click', '#capture-photo-cam', function (e) {
                e.stopPropagation();
                $scope.pictureFromCam($scope.artID);
            });

            $(document).off('click', '#select-photo-gallery');
            $(document).on('click', '#select-photo-gallery', function (e) {
                e.stopPropagation();
                $scope.pictureFromGallery($scope.artID);
            });

            $(document).off('click', '#popup-container');
            $(document).on('click', '#popup-container', function () {
                $scope.closePopUp();
            });
        } else {
            CommonServices.showAlert("Maximum 1 document can be uploaded for one member");
            return false;
        }
    };
    $scope.pictureFromCam = function (event) {
        $("#upload-options").hide();
        $("#popup-container").hide();
        $scope.capturePhoto($scope.artID, true);
    };
    $scope.pictureFromGallery = function (event) {
        $("#upload-options").hide();
        $("#popup-container").hide();
        $scope.capturePhoto($scope.artID, false);
    };

    $scope.capturePhoto = function (event, fromCam) {

        if (CommonServices.deviceType != "NA") {
            if (fromCam) {
                if (CommonServices.deviceType == "A") {
                    navigator.camera.getPicture($scope.onSuccessImageUploadAndroid, $scope.onFailImageUploadAndroid, {
                        quality: 85,
                        destinationType: 0,
                        targetWidth: 2048,
                        targetHeight: 2048
                    });
                } else {
                    navigator.camera.getPicture($scope.onSuccessImageUploadAndroid, $scope.onFailImageUploadAndroid, {
                        quality: 50,
                        destinationType: 0,
                        targetWidth: 2048,
                        targetHeight: 2048
                    });
                }
            } else {
                if (CommonServices.deviceType == "A") {
                    navigator.camera.getPicture($scope.onSuccessImageUploadAndroid, $scope.onFailImageUploadAndroid, {
                        quality: 85,
                        destinationType: 0,
                        sourceType: 0,
                        targetWidth: 2048,
                        targetHeight: 2048,
                        encodingType: Camera.EncodingType.JPEG
                    });
                } else {
                    navigator.camera.getPicture($scope.onSuccessImageUploadAndroid, $scope.onFailImageUploadAndroid, {
                        quality: 50,
                        destinationType: 0,
                        sourceType: 0,
                        targetWidth: 2048,
                        targetHeight: 2048,
                        encodingType: Camera.EncodingType.JPEG
                    });
                }
            }
        } else {
            var fileURI = "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAUDBAQEAwUEBAQFBQUGBwwIBwcHBw8LCwkMEQ8SEhEPERETFhwXExQaFRERGCEYGh0dHx8fExciJCIeJBweHx7/2wBDAQUFBQcGBw4ICA4eFBEUHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh7/wAARCASACAADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD5dRFUbcE+tOUADFAJHB5PtSgHk96x1NEhMAIelInAz1pxBIpEA/OgVhyj5e9C455oOM5OePehcA5x1osINqk7iMkVSkObvNaBPHtVCUYuVB6HihBcnUAn0qYsD8o9OtMABHHGOKVQM5PagBQDt44xTgTnk0Ee/FKoHWmNEiKeOe9XY0OzntVWHG4A85NXhgA5yaVx2CMHOGxnpUqkY5pIxnrj2p4FG4hVJHHJHY0bQWyMcUdcAZ4pFOSenFKwDgRwR16U1uhXjFISd2M8UsgB9KQzP1k7LFgOPWuewPvY61u+JSDbqg4yRWCuMGrRDQ5elOUY+WmhSV9u1SKD1AzjtVoSI7kkAD3pFGQMUsp3cEYpqjAzmkhDsHJxSjI6dKTtzS8CgBVBz0xRkY4Xkd6XBIxk4pVHagAUDHUZpOcmnIuM96cMdMipEMBx1FKMlj2oxjPOaBgnj9aoA5J9qVRgE/pQA2OMcU9AecHNAXAAkHJpU3BcZpQMqfrTckg+lAK4vPqCKaCW+nanKMrSr1IxgjvQLcjlHyFR8vrSxkBMDNJN90Fs8075ABnI4q4lIUAnvgdqBgAjvRgnnHApcAnAqwYIB05oHyggHnvQpAGP1prfeyBSEO/iGKdxzgfWmZOeOKUDPBPNAC9/pQclsnoOtHsaQD5sE/jSsA7Iz1696cOlIMAZHHagEnkcVSAByQeeKeSQcHpTSwAzkelKuTkUBEQrhST2qg27ec1oPkKe/FZ7YycdzQBLaD98D+VdR4MUN4hti5zlyPwOa5i05kJzjjFdX4Hw3iG35PGf5dKhvQEepsMHHUVyPiZDJrrRTCRQ0QKkDj0FdZqQuWsnNkyLN/CWGRXKXer6o159ludOhmlQfdAJ/Ks0UZFiqLNayQzuHEoDpuPBBr0FSdrM2CT1HvXHW1zaf2vH9q0p4biRxgldpB6Z5612ZQc7R06CqkIytJQm1lPA+c+3etKLIiXkZI61m6ZuNpKWbgyNge2TWogyir0GKzKSQ61XNxjI6ZFX+ScelUbXi43Y3HpV6STYhkbAUDmpNEMmKL3BNRlSQcgYPFZmozxSXMIW4AjbqQcc1YhtmWXzIrtvdSQQRTSEy05CKWwTgdqyoRiNgOMHNbLjCkdSBmsePBRmPOSaoRY0lc3zDHVK2FBxkd+1ZWi5N++T/B09K2ABkjFSxoYpDBsnkU5ABz3HApcJsycCjsMCkwSEVCec5pygEkDtTuNvHHHSkydx/SgBGXPC0oUjJ7GlX15zTgMNlsigYwAEcDp3xQBwTinAZJ44NOBGNo7dqAIguTvY4xTs53cnFOKk55P+NBXK454oFYjIA+YD3pwII6fpQo2dyTTsZPB70WAYfvYGeacvy/N3p+McjrRtAODigZHzksO9KmclT360o75NO7//AFqYkRhcMeMYOaCuSSTz34qROBzxikYFu/BpoQ1cjJHU8UqY2sBwaUfKSo60pXAySKYDVXdntilPGcDk0cE9aVQe1KwDAGKcjHH5UpPyYyPanDOTxkZo7YxSAOp/DrQF68jFOwd3bpSKuc9hVIBhOWA6CpAB0pGXsP0pw+U8nk0hIawLN2GKAOtOGQfTvSMegpDEAwcYz9KbsxzjtUgUAZJGfWgZLHnjFNCGqc/LS4xinDuM80jHgnFAIMAjkdqRepA7UDdnPalXIPy1IxMcc9e1ABP3h1FOAwMnAoAYsT2FG4CA5zgdKMe/SnDp05pBgcnrTSEIF79DTSpLcgcU87ipJx+dISxwVGKoQ3gHHfNKBhTS7cAs2KUDjnoRSYIYmSuKdghccc0cZwMgUYznPepSHcRMcg4xS4xgilxx9KGGfuimKw0/e4pQoAwTmjoc0AfNz0pgNUAg46UZwMDrUg28jntSHAHvQkDZHyozjrS4IB560KDltxpR19j6UxCHsBS/dUgd6MYxk5OKcM7ecUmC0G4G3JPtSdXB9BQFIb5TxTj8vTueTRYdxGbA25xxQBgc0qqM5IyaPvE88UARoSWwF4px4+XqBThnHy0AYXPfFADEwATjHHU0R5PJo5Yc0p44HJphcQ5PINKAQD+XFKuNvv3pEPJzxn1pBYaQVXPbNI2HcgnJqQ89BSPwfehAMCqDx1owQaXHy5HpRg4+nWkwSEK8Zx7U0gbSDzT+gIzSBcd8CkUNRdq574poXAyOfan478+1LkHhSeOlNCK+csc9ulPI+XGB044p5X5Cx+9TeTmmK4zaByaawXAA4GamAGAMUhUDjigLXIWyy7RSMoSPk5qVVG7I6fWmkA85NG4iIbd27GSaxfEEiJLGtxatKshCo6MMg4NbhB3Y7fyrJ8QqjWxb94jwOJI2HqBQhFPSLqT+0ks383ymRiqyg5GPQ1ur9zrWJpbS3upwTzurGBCFwuODW4B/LrTGRuuR92mjk5xyDUgGAKB9zOO9QykMbrjNMxxipece4pj9BtBGaAIsDn0pGU/41JsXZk9aRVzyTgCqTFYi2+tAAIxxT2GCSOaaVBPTtQBEw5PFNKhiMjFS45JxSMN3QdOtMViLH3hg5+lJsGM1ISTxjFIVyMcikNEWwbSCMAVGSVY/pU5GOSM5pjAlgMjGKQWIynynNN2j1qUg5wQaaygDO7n2osBFzkjjAoGcUoU8gAkGlAAzwevSmMgHOS/HNAw3JzUhA3HGfpSFAVOKAImJYkc4ppwcj86eBjrjHrTTyGAH/wBegaImGBx0poBGeM1M4+UL7daYBjjP44pgMPHY/WmkZyO9SYypyTUeOpHNAAQQee1RkADOD6CpON24nBxSE5XPoaAIhySSOvWmnGOOtSAHByRmmYBB5xQA3cM9hTTg+oNO2jGcc01xjr1JxQBGSN3FJjPtSuAM4/Sm9RkMaQhhVWyGRWAOOaglsrMqQ9tEc9flBqztwP60wjIJ6ihAZ0ui6PId32RVJ/u8VWl8L6UwJjMqH68flitcjB+U03+v6VSk0KxzsvhK2Kny7t1/3lqm3hO4AJjmibj+I4rrSQ3ykHJHemgEDsfTiqUxcpxE3hrUUJKRK4H91s5qpNpF/ENzWkuM44Gf5V6EGdCSDjFAdtoxxinzgoHmb2lwrcwyAj1UiomSQfwtgV6e7K+Q8Yb6iq8trZSDc9tGSfbFCaDlPNdrE9PzpQzA4Fd/Jo+mSE/6MFJ9+lU5fDdgc7HkU9jwadxcpxoY4PFGa6ebwvwTFe";
            this.onSuccessImageUploadAndroid(fileURI);
        }

    };

    $scope.onSuccessImageUploadAndroid = function (fileURI) {

        var height = $("#document-upload-wrapperMnMc").height();
        var fileURISize = sizeof(fileURI) / (1024 * 2.67);
        if (fileURISize > 1 && fileURISize < 501) { // tobe uncommented

            var that = this;
            var queryString;
            var fileDATAURI = fileURI;
            var rId = Math.floor(Math.random() * (999 - 100 + 1));
            var imageType = $('#' + $scope.artID + ' .doc-label').text();

            var fileNamePrefix = rId;
            var newFileName = imageType + "_" + fileNamePrefix + ".jpg";
            var newFileName1 = imageType.replace(/ /g, "_") + "_" + fileNamePrefix;
            var imageId = fileNamePrefix + "-img";
            var documentType = '';

            if (imageType === "Voter Identity Card") {
                documentType = "Voter Identity Card";
            }
            else if (imageType === "Driving License") {
                documentType = "Driving License";
            } else if (imageType === "PAN Card") {
                documentType = "PAN Card";
            } else if (imageType === "Passport") {
                documentType = "Passport";
            } else {
                documentType = "Any Other";
            }

            var content = {
                documentName: newFileName,
                docByteString: fileDATAURI,
                documentId: fileNamePrefix,
                documentType: documentType,
                toBeUploadedFlag: true,
                duplicateFlag: false

            };

            $scope.documentsNmMcToUk.uploaddocsmodel.push(content);

            $("#" + $scope.artID + " .photo-container").append("<div class='image-conatiner imageContainerNmMc' dataval=" + fileNamePrefix + " id=" + newFileName1 + "><img id =" + imageId + " data=" + newFileName + " dataval=" + fileNamePrefix + " src='data:image/JPEG;base64," + fileDATAURI + "' /><span class='delete-image-icon delete-image-iconNmMC' dataval=" + fileNamePrefix + " datasuccess=" + newFileName + " id=" + fileNamePrefix + " ></span></div>");


            $scope.documentsNmMcToUk.uploaddocscollection.push(content);
        } else {
            CommonServices.showAlert("Document size should be less than 500KB");
            return false;
        }

        $(".photo-container").on("click", '.delete-image-icon', function (e) {
            e.stopPropagation();
            var dataval = parseInt(e.currentTarget.getAttribute("dataval"));
            $scope.loadDeletePopUp(e, dataval);

        });

        $scope.maxImageCount = 1;
        $scope.totalImageCount = $(".photo-container img").length;
        if ($scope.totalImageCount == $scope.maxImageCount) {
            $(".uploadVehPhotoAndr").addClass("disableCamera");
        }
    };


    $("#" + $scope.artID + " .photo-container").on("click", function (e) {

        var eIid = e.currentTarget.getAttribute("id");
        var eSrc = e.currentTarget.getAttribute("src");
        $("#popup-container").show();
        $("#image-preview").show();
        $("#image-preview img").attr("src", eSrc);
        var imgTarget = "#" + eIid;
        $(document).off('click', '#popup-container');
        $(document).on('click', '#popup-container', function () {
            $scope.closePopUp();
        });
    });



    $scope.loadDeletePopUp = function (event, dataval) {

        var id = "#" + $(event.target).parent().attr("id");
        var that = this;
        $("#popup-container").show();
        $("#popup-content").show();
        $("#popup-content").off().on('click', function () {
            $scope.closePopUp();
        });

        $("#btn-yes").off().on('click', function () {
            $scope.closePopUp();
            $(event.target).parent().remove();
            for (var i = 0; i < $scope.documentsNmMcToUk.uploaddocscollection.length; i++) {
                if ($scope.documentsNmMcToUk.uploaddocscollection[i].documentId === dataval) {
                    $scope.documentsNmMcToUk.uploaddocscollection.splice(i, 1);
                    break;

                }
            }

            var totalImageCount = $(".photo-container img").length;
            var maxImageCount = 1;
            if (totalImageCount < maxImageCount) {
                $('.uploadVehPhotoAndr').removeClass("disableCamera");
            }
        });

        $("#btn-no").off().on('click', function () {
            $scope.closePopUp();
        });


    };

    $scope.closePopUp = function () {

        $("#popup-content").hide();
        $("#popup-container").hide();
        $("#image-preview").hide();
        $("#calendar-container").hide();
        $("#timePickerSelectCntr").hide();
        $("#upload-options").hide();
        $("#slide-container").show();
    };

    $scope.migrationDocSubmit = function () {
        if ($(".photo-container img").length === 0) {
            CommonServices.showAlert("No images to submit");
            return false;
        }
        if ($(".photo-container img").length < CommonServices.editQuoteInsured.risks.length) {
            CommonServices.showAlert("Please upload the mandatory documents");
            return false;
        }

        var approvePolicyPostData = {
            "userProfile": {
                "userId": CommonServices.getCommonData("userCode").toUpperCase(),
                "loggedInRole": CommonServices.getCommonData("loggedInRole")
            },
            "quote": {
                "quoteNumber": CommonServices.editQuoteInsured.quoteNumber,
                "policyType": "RE",
                "updatePanFlag": "N",
                "documents": $scope.documentsNmMcToUk.uploaddocscollection,
                "productCode": productCode,
                "policyStartDate": CommonServices.editQuoteInsured.policyStartDate
            }
        };


        var approvePolicyResponse = RestServices.postService(RestServices.urlPathsNewPortal.approveRenewedQuote, approvePolicyPostData);
        approvePolicyResponse.then(
            function (response) {

                if (response.data.errorCode !== undefined) {
                    CommonServices.showLoading(false);
                    CommonServices.showAlert(response.data.errorMessage);
                    $state.go('newRenewPolicy.getNewRenewPolicy');
                } else {
                    if ((response.data.userProfile.footer.errorDescription.indexOf("Proposal Approved") > -1) ||
                        (response.data.userProfile.footer.errorDescription.indexOf("Approving Renewal") > -1) ||
                        (response.data.userProfile.footer.errorDescription.indexOf("Policy already approved") > -1)) {

                        var domainData = {
                            "lngCode": "EN",
                            "keys": ["CHEQUE_PO_DRAFT_TYPE"]
                        };
                        var getDomainResponse = "";
                        getDomainResponse = RestServices.postService(RestServices.urlPathsNewPortal.getDomainValues, domainData);
                        getDomainResponse.then(
                            function (response) {
                                CommonServices.showLoading(false);
                                for (var i = 0; i < response.data.domainValues.length; i++) {
                                    var chequeTypes = {
                                        'name': response.data.domainValues[i].mnemonic
                                    };
                                    CommonServices.chequeList.push(chequeTypes);
                                }
                                CommonServices.managePolicyCollection = false;
                                $state.go('newRenewPolicy.collectionForm');
                            },
                            function (error) {
                                CommonServices.showLoading(false);
                                RestServices.handleWebServiceError(error);
                                $state.go('newRenewPolicy.getNewRenewPolicy');
                            });

                    } else {
                        CommonServices.showLoading(false);
                        CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
                        $state.go('newRenewPolicy.getNewRenewPolicy');
                    }
                }
            },
            function (error) { // failure
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
                $state.go('newRenewPolicy.getNewRenewPolicy');
            }
        );
    }
}]);


agentApp.controller('CollectionCtrl', ['$scope', '$location', 'RestServices', 'CommonServices', 'GetSetResponseService', '$state', '$rootScope', function ($scope, $location, RestServices, CommonServices, GetSetResponseService, $state, $rootScope) {
    var agentStakeCode = CommonServices.getCommonData("stakeCode").toUpperCase();
    //CommonServices.chequeList = [];Change By Nageshwar
    var disableCollectionMob = CommonServices.getCommonData("disableCollectionMob");
    $scope.cashCollection = false;
    $scope.chequeCollection = false;
    $scope.apdCollection = false;
    $scope.collectionMessage = false;
    /*Added for CR_MOBL_0066 start*/
    $scope.excessAmount = 0;
    $scope.multiple = false;
    /*Added for CR_MOBL_0066 end*/
    /***********Added for CR_NP_867 Start**********/
    $scope.ezetapCollection = false;

    /***********Added for CR_NP_867 End**********/
    /***********Added for CR_NP_779 Start**********/
    $scope.splCollection = false;
    $scope.buttonText = "Send Payment Link";
    $scope.CountReSendPaymntLink = 0;
    $scope.SPLtermFlag = false;
    /***********Added for CR_NP_779 End**********/
    var submitCollection = true;
    var regexAge = /^(?=.*[1-9])\d*$/;//3444
    var regexName = /^[a-zA-Z][a-zA-Z ]*$/;//3444
    $scope.regexNameWithoutSpace = /^[a-zA-Z][a-zA-Z]*$/;//3444
    $scope.quoteNumber = CommonServices.saveQuoteDetailsData.quote.quoteNumber;
    $scope.netPremium = CommonServices.saveQuoteDetailsData.quote.premiumDetails.netPremium;
    /*Added for CR_MOBL_0053*/
    $scope.showTotalIDV = false;
    if (CommonServices.saveQuoteDetailsData.quote.productCode == "TW" || CommonServices.saveQuoteDetailsData.quote.productName == "Two Wheeler" || CommonServices.saveQuoteDetailsData.quote.productCode == "PC" || CommonServices.saveQuoteDetailsData.quote.productName === "Private Car" || CommonServices.saveQuoteDetailsData.quote.productCode == "CV" || CommonServices.saveQuoteDetailsData.quote.productName === "Commercial Vehicle" || CommonServices.saveQuoteDetailsData.quote.productCode == "SQ" || CommonServices.saveQuoteDetailsData.quote.productName === "Standalone OD policy for TW" || CommonServices.saveQuoteDetailsData.quote.productCode == "SS" || CommonServices.saveQuoteDetailsData.quote.productName === "Standalone OD policy for PC") { /* CR_NP_3621 */
        if (CommonServices.saveQuoteDetailsData.quote.sumInsured !== undefined) {
            $scope.showTotalIDV = true;
        }
        $scope.totalIDV = CommonServices.saveQuoteDetailsData.quote.sumInsured;
    }
    /*CR_MOBL_0053 Ends*/

    /**CR690 Start**/
    $rootScope.panmodalOpen = false;

    var panCardDetails = {
        "quoteNumber": $scope.quoteNumber,
        "policyHolderCode": CommonServices.saveQuoteDetailsData.quote.policyHolderCode
    }
    if (CommonServices.getCommonData("partyCode") !== undefined && CommonServices.getCommonData("partyCode") !== "") {
        panCardDetails.policyHolderCode = CommonServices.getCommonData("partyCode");
    }
    CommonServices.setCommonData("panCardData", panCardDetails);
    /**CR690 End**/

    /* Added for CR_NP_0744 - To Capture Pan and Aadhaar during QP*/
    if (CommonServices.QRrenewalData !== undefined) {
        if (CommonServices.QRrenewalData.quote.partyDetailsList !== undefined && CommonServices.QRrenewalData.quote.partyDetailsList !== "") {
            $scope.panNumInputDisable = false;
            /*CR_NP_0744E starts */
            // $scope.aadhaarInputDisable = false;
            $scope.regexPanNo = /^[A-Za-z]{5}[0-9]{4}[A-Za-z]{1}$/;
            $scope.regexAadhaarInpt = /^(?!\1+$)\d{4}$/;
            $scope.regexAadhaarNumber = /^(?!\1+$)\d{12}$/;
            $scope.panRequiredForMiscProducts = false;
            // $scope.removeAadhaarInputForOrganization = false;
            $scope.panAadhaarModalOpen = false;
            $scope.aadhaarObj = {};

            //Make Pan Number Mandatory for Certain Products
            if (CommonServices.QRrenewalData.quote.productCode == "HH" || CommonServices.QRrenewalData.quote.productCode == "OS" || CommonServices.QRrenewalData.quote.productCode == "SH") {
                $scope.panRequiredForMiscProducts = true;
            }
            //Disable Aadhar if PartyType is Organization
            // if (CommonServices.QRrenewalData.quote.partyDetailsList[0].partyType !== "I") {
            //     $scope.removeAadhaarInputForOrganization = true;
            // }
            /*CR_NP_0744E ends */

            // To get the Configuration Data
            var configurationData = CommonServices.getCommonData("ConfigurationData");
            if (configurationData != undefined && configurationData != '') {
                if (configurationData[0].value == "Y") {
                    $scope.isPanNumberMandatory = true;
                } else {
                    $scope.isPanNumberMandatory = false;
                }
                /*Below block Commented for CR_NP_0744E */
                // if (configurationData[1].value == "Y") {
                //     $scope.isAadhaarNumberMandatory = true;
                // } else {
                //     $scope.isAadhaarNumberMandatory = false;
                // }
                /*CR_NP_0744E ends*/
            }
            //Bind Pan and Aadhaar Values to Model
            if (CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.panNumber !== undefined && CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.panNumber !== '' && $scope.regexPanNo.test(CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.panNumber)) {
                $scope.panCardNo = CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.panNumber;
                $scope.panNumInputDisable = true;
            } else {
                $scope.panCardNo = '';
                $scope.panNumInputDisable = false;
            }
            /*CR_NP_0744E start */
            if (CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.aadhaarNo !== undefined && CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.aadhaarNo !== '' && $scope.regexAadhaarNumber.test(CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.aadhaarNo)) {
                $scope.aadhaarObj.aadhaarNumb1 = CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.aadhaarNo.substr(0, 4);
                $scope.aadhaarObj.aadhaarNumb2 = CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.aadhaarNo.substr(4, 4);
                $scope.aadhaarObj.aadhaarNumb3 = CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.aadhaarNo.substr(8, 4);
                $scope.aadhaarInputDisable = true;
            } else {
                $scope.aadhaarObj.aadhaarNumb1 = '';
                $scope.aadhaarObj.aadhaarNumb2 = '';
                $scope.aadhaarObj.aadhaarNumb3 = '';
                $scope.aadhaarInputDisable = false;
            }
            //To show or Not the panAadhaar Modal based on their values

            /*modified the following block as below for CR_NP_0744E*/



            if (CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.panNumber !== undefined && CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.panNumber !== '' && $scope.regexPanNo.test(CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.panNumber)) {
                $scope.panAadhaarModalOpen = false;
            } else {
                if ($rootScope.isQrFlow) {
                    $scope.panAadhaarModalOpen = false;
                } else {
                    $scope.panAadhaarModalOpen = true;
                }
            }
        }
    }

    /*To auto focus the pointer to next input field*/
    // $(".aadhaarNoInput").keyup(function() {
    //     if (this.value.length == 4) {
    //         $(this).next('.aadhaarNoInput').focus();
    //     }
    //     if (this.value.length < 1) {
    //         $(this).prev('.aadhaarNoInput').focus();
    //     }
    // });

    // // On change of value in aadhaar Input, to make other fields mandatory

    // $scope.aadhaarField = function() {
    //     if (($scope.aadhaarObj.aadhaarNumb1 != undefined && $scope.aadhaarObj.aadhaarNumb1 != '') || ($scope.aadhaarObj.aadhaarNumb2 != undefined && $scope.aadhaarObj.aadhaarNumb2 != '') || ($scope.aadhaarObj.aadhaarNumb3 != undefined && $scope.aadhaarObj.aadhaarNumb3 != '')) {
    //         $scope.aadharFieldIsrequired = true;
    //         if (($scope.aadhaarObj.aadhaarNumb1 != undefined && $scope.aadhaarObj.aadhaarNumb1 != '') && ($scope.aadhaarObj.aadhaarNumb2 != undefined && $scope.aadhaarObj.aadhaarNumb2 != '') && ($scope.aadhaarObj.aadhaarNumb3 != undefined && $scope.aadhaarObj.aadhaarNumb3 != '')) {
    //             $scope.aadharFieldIsrequired = false;
    //         }
    //     } else {
    //         $scope.aadharFieldIsrequired = false;
    //     }
    // };

    /*CR_NP_0744E ends */

    /*CR_NP_0744C starts*/
    setTimeout(function () {

        if (CommonServices.QRrenewalData.quote.policyNumber === undefined) {
            return;
        }

        /* CR_NP_0744C starts */
        if (CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.aadhaarAuthStatus.toUpperCase() != "SUCCESS") {

            if (CommonServices.deviceType != 'NA') {
                CommonServices.showConfirmForAadhaar("We have found that your policy is not linked with your Aadhaar number. Would you like to link your Aadhaar number to your policy now?", function onConfirm(r) {
                    if (r == 1) {
                        linkMyAadhaar();
                    }
                    else if (r == 2) {
                        CommonServices.showLoading(false);
                    }
                }, "Confirm");
            } else {
                var linkMyAadhaarConfirm = confirm("We have found that your policy is not linked with your Aadhaar number. Would you like to link your Aadhaar number to your policy now?");
                if (linkMyAadhaarConfirm) {
                    linkMyAadhaar();
                }
            }

        }

    }, 1000);

    /*CR_NP_0744C ends*/


    /* CR_NP_0744C function starts */

    function linkMyAadhaar() {

        CommonServices.showLoading(true);


        var fetchAadharDetails = {
            "quote": {
                "policyHolderCode": CommonServices.QRrenewalData.quote.policyHolderCode,
                "policyNumber": CommonServices.QRrenewalData.quote.policyNumber
            },
            "userProfile": {
                "userId": CommonServices.getCommonData("userCode").toUpperCase()
            }
        };

        var header = {
            'Content-Type': 'application/json',
            'applicationid': 'mobile',
            'customerName': 'CUSTOMER',
            'typeOfCustomer': 'CUSTOMER'
        };

        var fetchAadharDetailsResponse = RestServices.postService(RestServices.urlPathsNewPortal.fetchAadharDetails, fetchAadharDetails);
        fetchAadharDetailsResponse.then(function (response) {

            CommonServices.showLoading(false);

            if (response.data.userProfile != undefined) {
                if (response.data.userProfile.footer.errorCode == "1") {
                    GetSetResponseService.addFetchAadharDetails(response.data);
                    $state.go('linkYourAadharGetUserData');
                } else {
                    CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
                }
            } else {
                CommonServices.showAlert("We regret for the inconvenience, presently our services are not available. Please try after sometime");
            }

        }, function (error) {
            CommonServices.showLoading(false);
            RestServices.handleWebServiceError(error);
        });


    };
    /* CR_NP_0744C function ends */



    $scope.updatePanAadhaar = function () {

        $scope.aadhaarObj.aadhaarNumb = $scope.aadhaarObj.aadhaarNumb1 + $scope.aadhaarObj.aadhaarNumb2 + $scope.aadhaarObj.aadhaarNumb3;
        var polHolderUpdateInput = {
            "userCode": CommonServices.getCommonData("userCode").toUpperCase(),
            "rolecode": CommonServices.getCommonData("loggedInRole"),
            "policyHolderCode": CommonServices.QRrenewalData.quote.policyHolderCode,
            "city": CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.city,
            "state": CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.state,
            "pinCode": CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.pinCode,
            "panNumber": $scope.panCardNo.toUpperCase(),
            "aadhaarNo": $scope.aadhaarObj.aadhaarNumb,
            "addressLine1": CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.buildingNoStreet,
            "addressLine2": CommonServices.QRrenewalData.quote.partyDetailsList[0].individualDetails.locality
        };
        /*CR_NP_0744E ends */
        var updatePolHolderResponse = RestServices.postService(RestServices.urlPathsNewPortal.updatePolicyHolderContact, polHolderUpdateInput);

        updatePolHolderResponse.then(function (response) {

            CommonServices.showLoading(false);
            if (response.data.pRetCode == 0) {
                $scope.panAadhaarModalOpen = false;
            } else if (response.data.errorMessage !== undefined) {
                CommonServices.showAlert(response.data.errorMessage);
            } else if (response.data.pRetErr !== undefined) {
                CommonServices.showAlert(response.data.pRetErr);
            }

        }, function (error) {
            CommonServices.showLoading(false);
            RestServices.handleWebServiceError(error);
        });
    };
    $scope.closePanModal = function () {
        $scope.panAadhaarModalOpen = false;
    }
    /*CR_NP_0744 ends*/


    /****** added for CR_MOBL_0061 Start********/
    $scope.init = function () {
        CommonServices.chequeList = [];
        //Get Collection Modes Start
        var collectionModeData = { "userProfile": { "userId": CommonServices.getCommonData("userId"), "channel": "AGENT" } };

        var collectionModeResponse = RestServices.postService(RestServices.urlPathsNewPortal.collectionModes, collectionModeData);
        collectionModeResponse.then(
            function (response) { // success 

                CommonServices.showLoading(false);
                if (response.data.collectionModesList.length > "0") {
                    $scope.collectionModesList = response.data.collectionModesList;
                } else {
                    CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
                }
            },
            function (error) { // failure
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            });
        //Get Collection Modes End

        //Get Domain Values Start
        var domainData = {
            "lngCode": "EN",
            "keys": ["CHEQUE_PO_DRAFT_TYPE"]
        };
        var getDomainResponse = "";
        getDomainResponse = RestServices.postService(RestServices.urlPathsNewPortal.getDomainValues, domainData);
        getDomainResponse.then(
            function (response) {

                CommonServices.showLoading(false);
                for (var i = 0; i < response.data.domainValues.length; i++) {
                    var chequeTypes = {
                        'name': response.data.domainValues[i].mnemonic
                    };

                    CommonServices.chequeList.push(chequeTypes);
                }
                $scope.chequeList = CommonServices.chequeList;
            },
            function (error) {
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            });
        //Get Domain Values End
        //Get Bank Details Start

        var bankSearchResponse = RestServices.getService(RestServices.urlPathsNewPortal.getBHBankDetails);
        //web service call for bank search
        bankSearchResponse.then(
            function (response) {	// success 
                CommonServices.showLoading(false);
                $scope.bankList = response.data.listofBankDetails;

            },
            function (error) {    // failure 
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            });
        //Get Bank Details End
    }

    $scope.init();



    /****** added for CR_MOBL_0061 End********/




    var modes = disableCollectionMob;
    for (var i = 0; i < modes.length; i++) {
        if (modes[i].code === "CSH") {
            $scope.cashCollection = true;
        } else if (modes[i].code === "CHQ") {
            $scope.chequeCollection = true;
        } else if (modes[i].code === "APD") {
            $scope.apdCollection = true;
        }
        /*******added for CR_NP_867 Start**********/
        else if (modes[i].code === "EZE") {
            $scope.ezetapCollection = true;
        }

        /*******added for CR_NP_867 End**********/
        /*******added for CR_NP_779 Start**********/
        else if (modes[i].code === "SPL") {
            $scope.splCollection = true;
        }

        /*******added for CR_NP_779 End**********/
        /*******added for CR_MOBL_0061 Start**********/
        else if (modes[i].code === "NB") {
            $scope.nbCollection = true;
        }
        else if (modes[i].code === "DRF") {//SHOULD BE CORRECTED

            $scope.ddCollection = true;
        }

        /*******dded for CR_MOBL_0061 End**********/
    }
    if ($scope.cashCollection == false && $scope.chequeCollection == false && $scope.apdCollection == false && $scope.ezetapCollection == false && $scope.splCollection == false && $scope.nbCollection == false && $scope.ddCollection == false) {//$scope.ezetapCollection added for CR_NP_867,CR_MOBL_0061,CR_NP_779
        $scope.collectionMessage = true;
        submitCollection = false;
    }


    $scope.show = function (e) {
        if ($scope.cashCollection == false && $scope.chequeCollection == false && $scope.apdCollection == false && $scope.ezetapCollection == false && $scope.splCollection == false && $scope.nbCollection == false && $scope.ddCollection == false) {//$scope.ezetapCollection added for CR_NP_867,CR_MOBL_0061,CR_NP_779
            $scope.showModes = false;
        }
        /*Added for CR_MOBL_0066 start*/

        else if ($scope.excessAmountDraft === true) {
            $scope.showModes = false;
            CommonServices.showAlert("There is already an excess amount in the instrument amount.You are not allowed to add new collection modes.")
        }
        /*Added for CR_MOBL_0066 end*/

        else {
            $scope.showModes = !$scope.showModes;
        }
    }

    $scope.collectionFormData = {
        apdFormData: [],
        chequeFormData: [],
        cashFormData: [],
        ezeTapFormData: [],//added for CR_NP_867
        netBankingFormData: [], //added for CR_MOBL_0061
        demandDraftFormData: [] //added for CR_MOBL_0061
        , SendPaymentLinkFormData: [] /* CR_NP_779 */
    };

    $scope.chequeTypesModal = function ($event, data) {
        $scope.chequeModal = true;
        $scope.clickedsec_id = $event;
        $scope.collectType = data;//added for CR_MOBL_0061
    };

    $scope.chequeList = CommonServices.chequeList;

    $scope.getChequeValue = function (listPassed) {
        var id = $scope.clickedsec_id;
        if ($scope.collectType === "cheque") {
            $scope.collectionFormData.chequeFormData[id].chequeType = listPassed;
        }
        if ($scope.collectType === "dd") {
            $scope.collectionFormData.demandDraftFormData[id].chequeType = listPassed;
        }
        //added for MOBL_CR_0061 End
        $scope.chequeModal = false;
    };

    /***********added for CR_NP_867 Start**********/
    if (CommonServices.deviceType == "A") { //Change in code merge & to handle in ihone
    $scope.ezeTapClick = function () {
            if ($scope.collectionFormData.cashFormData.length > 0) {
                CommonServices.showAlert("Ezetap cannot be combined with cash mode");
                $scope.showModes = false;
            } else if ($scope.collectionFormData.chequeFormData.length > 0) {
                CommonServices.showAlert("Ezetap cannot be combined with cheque mode");
                $scope.showModes = false;
            } else if ($scope.collectionFormData.apdFormData.length > 0) {
                CommonServices.showAlert("Ezetap cannot be combined with APD mode");
                $scope.showModes = false;
            }
            else if ($scope.collectionFormData.ezeTapFormData.length > 0) {
                CommonServices.showAlert("Ezetap mode has already been added");
                $scope.showModes = false;
            }
            else if ($scope.collectionFormData.netBankingFormData.length > 0) {
                CommonServices.showAlert("Ezetap cannot be combined with Net Banking mode");
                $scope.showModes = false;
            }
            else if ($scope.collectionFormData.demandDraftFormData.length > 0) {
                CommonServices.showAlert("Ezetap cannot be combined with Demand Draft mode");
                $scope.showModes = false;
            }
            /* CR_NP_779 Start*/
            else if ($scope.collectionFormData.SendPaymentLinkFormData.length > 0) {
                CommonServices.showAlert("Send Payment Link mode cannot be combined with Ezetap mode");
                $scope.showModes = false;
                $scope.SPLtermFlag = true;
            }
            /* CR_NP_779 Start*/

            else {
                $scope.collectionFormData.ezeTapFormData
                    .unshift({
                        collectionMode: 'EZE',
                        collectionAmount: ''
                    });
                $scope.showModes = false;
                $scope.collectionFormData.ezeTapFormData[0].collectionAmount = $scope.netPremium;
            }

        }
    }
    else if(CommonServices.deviceType == "I") //Change in code merge & to handle in iPhone
    {
        CommonServices.showAlert("Ezetap Payment option is not available for iphone or ipad");
    }
        $scope.removeEzeRow = function (index) {
            $scope.count = 0;
            $scope.showModes = false;
            $scope.collectionFormData.ezeTapFormData.splice(index, 1);
            if ($scope.termFlagEze) {
                $scope.termFlagEze = false;
            }

        }


    /***********added for CR_NP_867 End**********/

    /***********added for CR_NP_779 Start**********/
    $scope.sentpaymentlinkClick = function () {
        $scope.SPLtermFlag = false;
        $scope.FetchEmailIDMobileNoDetails();
        if ($scope.collectionFormData.cashFormData.length > 0) {
            CommonServices.showAlert("Send Payment Link cannot be combined with cash mode");
            $scope.showModes = false;
        } else if ($scope.collectionFormData.chequeFormData.length > 0) {
            CommonServices.showAlert("Send Payment Link cannot be combined with cheque mode");
            $scope.showModes = false;
        } else if ($scope.collectionFormData.apdFormData.length > 0) {
            CommonServices.showAlert("Send Payment Link cannot be combined with APD mode");
            $scope.showModes = false;
        } else if ($scope.collectionFormData.demandDraftFormData.length > 0) {
            CommonServices.showAlert("Send Payment Link cannot be combined with Demand Draft mode");
            $scope.showModes = false;
        } else if ($scope.collectionFormData.netBankingFormData.length > 0) {
            CommonServices.showAlert("Send Payment Link cannot be combined with Net Banking mode");
            $scope.showModes = false;
        } else if ($scope.collectionFormData.ezeTapFormData.length > 0) {
            CommonServices.showAlert("Send Payment Link cannot be combined with Ezetap mode");
            $scope.showModes = false;
        } else if ($scope.collectionFormData.SendPaymentLinkFormData.length > 0) {
            CommonServices.showAlert("Send Payment Link has already been added");
            $scope.SPLtermFlag = true;
            $scope.showModes = false;
        } else if (($scope.SPLAgentEmalid == undefined || $scope.SPLAgentEmalid == "") && ($scope.SPLAgentMobileNo == undefined
            || $scope.SPLAgentMobileNo == "")) {
            CommonServices.showAlert("The email ID and mobile number of the policyholder is not available");
            $scope.SPLtermFlag = true;
            $scope.showModes = false;
        } else {
            $scope.collectionFormData.SendPaymentLinkFormData
                .unshift({
                    collectionMode: 'SPL',
                    collectionAmount: ''
                });
            $scope.showModes = false;
            $scope.collectionFormData.SendPaymentLinkFormData[0].collectionAmount = $scope.netPremium;
            $scope.SPLtermFlag = true;
            $scope.FetchPaymentLinkDeatils();
        }

    }

    $scope.removeSPLRow = function (index) {
        $scope.count = 0;
        $scope.showModes = false;
        $scope.collectionFormData.SendPaymentLinkFormData.splice(index, 1);
        if ($scope.SPLtermFlag) {
            $scope.SPLtermFlag = false;
        }
    }


    /***********added for CR_NP_779 End**********/
    /*********** added for CR_MOBL_0061 Start*******/
    $scope.netBankingClick = function () {
        if ($scope.collectionFormData.cashFormData.length > 0) {
            CommonServices.showAlert("Net Banking cannot be combined with cash mode");
            $scope.showModes = false;
        } else if ($scope.collectionFormData.chequeFormData.length > 0) {
            CommonServices.showAlert("Net Banking cannot be combined with cheque mode");
            $scope.showModes = false;
        } else if ($scope.collectionFormData.apdFormData.length > 0) {
            CommonServices.showAlert("Net Banking cannot be combined with APD mode");
            $scope.showModes = false;
        } else if ($scope.collectionFormData.ezeTapFormData.length > 0) {
            CommonServices.showAlert("Net Banking cannot be combined with Ezetap mode");
            $scope.showModes = false;
        }
        else if ($scope.collectionFormData.netBankingFormData.length > 0) {
            CommonServices.showAlert("Net Banking mode already added");
            $scope.showModes = false;
        }
        else if ($scope.collectionFormData.demandDraftFormData.length > 0) {
            CommonServices.showAlert("Net Banking cannot be combined with Demand Draft mode");
            $scope.showModes = false;
        }
        /* CR_NP_779 Start*/
        else if ($scope.collectionFormData.SendPaymentLinkFormData.length > 0) {
            CommonServices.showAlert("Net Banking cannot be combined with Send Payment Link mode");
            $scope.showModes = false;
            $scope.SPLtermFlag = true;
        }
        /* CR_NP_779 Start*/
        else {
            $scope.collectionFormData.netBankingFormData
                .unshift({
                    collectionMode: 'NB',
                    collectionAmount: ''
                });
            $scope.showModes = false;
            $scope.collectionFormData.netBankingFormData[0].collectionAmount = $scope.netPremium;

            $scope.nBSection = { 'collectionAmount': $scope.netPremium };
        }

    }

    $scope.removeNBRow = function (index) {
        $scope.count = 0;
        $scope.showModes = false;
        $scope.collectionFormData.netBankingFormData.splice(index, 1);
        if ($scope.termFlag) {
            $scope.termFlag = false;
        }

    }



    /*************added for CR_MOBL_0061 End******/

    /*********** added for CR_MOBL_0061 Start*******/
    $scope.demandDraftClick = function () {
        if ($scope.collectionFormData.demandDraftFormData.length > 0) {
            CommonServices.showAlert("Demand Draft mode has already been added");
            $scope.showModes = false;
        } else if ($scope.collectionFormData.apdFormData.length > 0) {
            CommonServices.showAlert("Demand Draft cannot be combined with APD mode");
            $scope.showModes = false;
        } else if ($scope.collectionFormData.netBankingFormData.length > 0) {
            CommonServices.showAlert("Demand Draft cannot be combined with Netbanking mode");
            $scope.showModes = false;
        }
        else if ($scope.collectionFormData.ezeTapFormData.length > 0) {
            CommonServices.showAlert("Demand Draft cannot be combined with Ezetap mode");
            $scope.showModes = false;
        }
        else if ($scope.collectionFormData.cashFormData.length > 0) {
            CommonServices.showAlert("Demand Draft cannot be combined with cash mode");
            $scope.showModes = false;
        } else if ($scope.collectionFormData.chequeFormData.length > 0) {
            CommonServices.showAlert("Demand Draft cannot be combined with cheque mode");
            $scope.showModes = false;
        }
        /* CR_NP_779 Start*/
        else if ($scope.collectionFormData.SendPaymentLinkFormData.length > 0) {
            CommonServices.showAlert("Demand Draft cannot be combined with Send Payment Link  mode");
            $scope.showModes = false;
            $scope.SPLtermFlag = true;
        }
        /* CR_NP_779 Start*/

        else {
            $scope.collectionFormData.demandDraftFormData
                .unshift({
                    draweeBankCode: '',
                    chequeType: '',
                    chequeNo: '',
                    chequeDate: '',
                    draweeBankName: '',
                    draweeBankBranch: '',
                    collectionAmount: '',
                    excessAmount: '',
                    instrumentAmount: ''
                });
            $scope.showModes = false;
            $scope.collectionFormData.demandDraftFormData[0].instrumentAmount = $scope.netPremium;


        }


    }

    $scope.removeDDRow = function (index) {
        $scope.count = 0;
        $scope.showModes = false;
        $scope.excessAmountDraft = false;     /*Added for CR_MOBL_0066 */
        $scope.collectionFormData.demandDraftFormData.splice(index, 1);
        if ($scope.termFlag) {
            $scope.termFlag = false;
        }

    }



    /*************added for CR_MOBL_0061 End******/
    //APD Functionality Start

    $scope.APDClick = function () {
        if ($scope.collectionFormData.cashFormData.length > 0) {
            CommonServices.showAlert("APD cannot be combined with cash mode");
            $scope.showModes = false;
        } else if ($scope.collectionFormData.chequeFormData.length > 0) {
            CommonServices.showAlert("APD cannot be combined with cheque mode");
            $scope.showModes = false;
        }

        else if ($scope.collectionFormData.demandDraftFormData.length > 0) {
            CommonServices.showAlert("APD cannot be combined with Demand Draft mode");
            $scope.showModes = false;
        } else if ($scope.collectionFormData.apdFormData.length > 0) {
            CommonServices.showAlert("APD mode is already added");
            $scope.showModes = false;
        } else if ($scope.collectionFormData.netBankingFormData.length > 0) {
            CommonServices.showAlert("APD cannot be combined with Netbanking mode");
            $scope.showModes = false;
        }
        else if ($scope.collectionFormData.ezeTapFormData.length > 0) {
            CommonServices.showAlert("APD cannot be combined with Ezetap mode");
            $scope.showModes = false;
        }
        /* CR_NP_779 Start*/
        else if ($scope.collectionFormData.SendPaymentLinkFormData.length > 0) {
            CommonServices.showAlert("APD cannot be combined with Send Payment Link mode");
            $scope.showModes = false;
            $scope.SPLtermFlag = true;
        }
        /* CR_NP_779 Start*/

        else {
            $scope.collectionFormData.apdFormData
                .unshift({
                    accountCode: '',
                    quoteNo: '',
                    collectionMode: 'APD',
                    subCode: '',
                    scrollNo: '',
                    collectionAmount: ''
                });
            $scope.showModes = false;

        }
    };
    $scope.removeApdRow = function (index) {
        $scope.showModes = false;
        $scope.collectionFormData.apdFormData.splice(index, 1);
    };

    $scope.getSubCode = function ($event) {
        var stakevalue = CommonServices.getCommonData("stakeCode");
        $scope.clickedsub_id = $event;

        var postSubCode = {
            "userProfile": {
                "userId": CommonServices.getCommonData("userCode").toUpperCase(),
                "loggedInRole": CommonServices.getCommonData("loggedInRole")
            },
            "quote": {
                "payment": {
                    "paymentDetailsList": [{
                        "collectionMode": "APD"
                    }]
                }
            }
        }

        var PolicyResponse = RestServices.postService(RestServices.urlPathsNewPortal.getAPDBalance, postSubCode);

        PolicyResponse.then(
            function (response) { // success 
                // Added by 851587, since if APD balance is not fetched from the service there was error
                if (response.data.quote.payment.paymentDetailsList[0] !== undefined && response.data.quote.payment.paymentDetailsList[0] !== "") {
                    $scope.subCodeModel = true;
                    $scope.subCodeList = response.data.quote.payment.paymentDetailsList;
                    CommonServices.showLoading(false);
                } else {
                    CommonServices.showAlert("No APD Balance available");
                    CommonServices.showLoading(false);
                }
            },
            function (error) { // failure 
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            });
    };

    $scope.getSubCodeValue = function (listPassed) {
        var id = $scope.clickedsub_id;
        $scope.collectionFormData.apdFormData[id].subCode = listPassed;
        $scope.subCodeModel = false;
        $scope.collectionFormData.apdFormData[id].referenceNumber = '';
    };

    $scope.getReferenceNoAPD = function ($event) {
        $scope.clickedrefer_id = $event;
        var subcode = $scope.collectionFormData.apdFormData[$event].subCode;
        if (subcode == '') {
            CommonServices.showAlert("Please Select Subcode");
        } else {
            var postReferenceCode = {
                "userProfile": {
                    "userId": CommonServices.getCommonData("userCode").toUpperCase(),
                    "loggedInRole": CommonServices.getCommonData("loggedInRole")
                },
                "quote": {
                    "payment": {
                        "paymentDetailsList": [{
                            "collectionMode": "APD",
                            "subCode": subcode
                        }]
                    }
                }
            };

            var PolicyResponse = RestServices.postService(RestServices.urlPathsNewPortal.getReferenceNoAPD, postReferenceCode);

            PolicyResponse.then(
                function (response) { // success 
                    $scope.referenceModel = true;
                    $scope.referenceList = response.data.quote.payment.paymentDetailsList;
                    CommonServices.showLoading(false);
                },
                function (error) { // failure 
                    CommonServices.showLoading(false);
                    RestServices.handleWebServiceError(error);
                });
        }
    };

    $scope.getreferenceValue = function (listPassed) {
        var id = $scope.clickedrefer_id;
        $scope.collectionFormData.apdFormData[id].referenceNumber = listPassed;
        $scope.referenceModel = false;
    };
    //APD Functionality End

    //Cheque Functionality Start
    $scope.chequeClick = function () {
        if ($scope.collectionFormData.chequeFormData.length >= 4) {
            CommonServices.showAlert("Maximum 4 cheques can be added.");
            $scope.showModes = false;
        } else if ($scope.collectionFormData.apdFormData.length > 0) {
            CommonServices.showAlert("APD cannot be combined with cheque mode");
            $scope.showModes = false;
        }
        else if ($scope.collectionFormData.demandDraftFormData.length > 0) {
            CommonServices.showAlert("Cheque mode cannot be combined with Demand Draft mode");
            $scope.showModes = false;
        } else if ($scope.collectionFormData.netBankingFormData.length > 0) {
            CommonServices.showAlert("Cheque mode cannot be combined with Netbanking mode");
            $scope.showModes = false;
        }
        else if ($scope.collectionFormData.ezeTapFormData.length > 0) {
            CommonServices.showAlert("Cheque mode cannot be combined with Ezetap mode");
            $scope.showModes = false;
        }
        /* CR_NP_779 Start*/
        else if ($scope.collectionFormData.SendPaymentLinkFormData.length > 0) {
            CommonServices.showAlert("Cheque mode cannot be combined with Send Payment Link mode");
            $scope.showModes = false;
            $scope.SPLtermFlag = true;
        }
        /* CR_NP_779 Start*/


        else {
            /*Added for CR_MOBL_0066 start*/
            if ($scope.collectionFormData.cashFormData.length > 0 || $scope.collectionFormData.chequeFormData.length > 0)
                $scope.multiple = true;
            /*Added for CR_MOBL_0066 end*/
            $scope.collectionFormData.chequeFormData
                .unshift({
                    draweeBankCode: '',
                    chequeType: '',
                    chequeNo: '',
                    chequeDate: '',
                    draweeBankName: '',
                    draweeBankBranch: '',
                    instrumentAmount: ''
                });
            $scope.showModes = false;
        }

    };
    $scope.removeChequeRow = function (index) {
        $scope.showModes = false;
        $scope.excessAmountDraft = false;    /*Added for CR_MOBL_0066 */
        $scope.multiple = false; /*Added for CR_MOBL_0066 */
        $scope.collectionFormData.chequeFormData.splice(index, 1);
    };

    var mydateStr = CommonServices.getCommonData("serverDate");
    var mynewdateFrom = "";
    if (mydateStr != undefined) {
        mynewdateFrom = new Date(mydateStr);
    } else {
        mynewdateFrom = new Date();
    }


    /**Cheque date Enabled from past 6 months upto Policy start date**/


    var enableCalendarfrom = new Date(mynewdateFrom.setMonth(mynewdateFrom.getMonth() - 6));
    enableCalendarfrom = new Date(enableCalendarfrom.setDate(enableCalendarfrom.getDate() + 1));
    enableCalendarfrom = getFormattedDate(enableCalendarfrom);

    //var regDate = $scope.policyData.quote.policyStartDate;

    var regDate = CommonServices.saveQuoteDetailsData.quote.policyStartDate;
    var regDateFormat = "";
    var enableChequeCalTo;
    if (regDate !== undefined) {
        var regdatePart = regDate.split(/[^0-9]+/);
        var regYear = regdatePart[2];
        var regMon = regdatePart[1];
        var regDay = regdatePart[0];
        regDateFormat = regMon + "/" + regDay + "/" + regYear;
    }

    if (regDateFormat === "") {
        enableChequeCalTo = getFormattedDate(new Date());
    } else {
        enableChequeCalTo = getFormattedDate(new Date(regDateFormat));
    }


    $scope.chequeDateValidation = function (index) {


        $("#chequeDate_" + index).loadCalendar({
            'enableDateRange': true,
            'enableCalendarFrom': enableCalendarfrom,
            'enableCalendarTo': enableChequeCalTo
        });
        /**********added for CR_MOBL_0061 Start********/
        $("#ddDate_" + index).loadCalendar({
            'enableDateRange': true,
            'enableCalendarFrom': enableCalendarfrom,
            'enableCalendarTo': enableChequeCalTo
        });
        /**********added for CR_MOBL_0061 End********/
        return true;

    };
    $scope.calIconClick = function (event) {
        angular.element("#" + event.currentTarget.children[0].id).focus();

    };

    $scope.bankKeyPress = function (data) {
        if ($scope.bankSearch.length > 0) {
            $scope.bankSearchError = false;
        }
    };
    //Cheque Functionality End
    //Cash Functionality Start
    $scope.cashClick = function () {
        if ($scope.collectionFormData.apdFormData.length > 0) {
            CommonServices.showAlert('APD cannot be combined with Cash mode');
            $scope.showModes = false;
        } else if ($scope.collectionFormData.cashFormData.length > 0) {
            CommonServices.showAlert("Cash mode has already been added");
            $scope.showModes = false;
        }
        else if ($scope.collectionFormData.demandDraftFormData.length > 0) {
            CommonServices.showAlert("Cash mode cannot be combined with Demand Draft mode");
            $scope.showModes = false;
        } else if ($scope.collectionFormData.netBankingFormData.length > 0) {
            CommonServices.showAlert("Cash mode cannot be combined with Netbanking mode");
            $scope.showModes = false;
        }
        else if ($scope.collectionFormData.ezeTapFormData.length > 0) {
            CommonServices.showAlert("Cash mode cannot be combined with Ezetap mode");
            $scope.showModes = false;
        }
        /* CR_NP_779 Start*/
        else if ($scope.collectionFormData.SendPaymentLinkFormData.length > 0) {
            CommonServices.showAlert("Cash mode cannot be combined with Send Payment Link mode");
            $scope.showModes = false;
            $scope.SPLtermFlag = true;
        }
        /* CR_NP_779 Start*/
        else {
            /*Added for CR_MOBL_0066 start*/
            if ($scope.collectionFormData.chequeFormData.length > 0)
                $scope.multiple = true;
            /*Added for CR_MOBL_0066 end*/
            $scope.collectionFormData.cashFormData
                .push({
                    cashAmount: ''
                });
            $scope.showModes = false;
        }
    };

    $scope.removeCashRow = function (index) {
        $scope.showModes = false;
        $scope.multiple = false;  /*Added for CR_MOBL_0066*/
        $scope.collectionFormData.cashFormData.splice(index, 1);
    };

    //Cash Functionality End
    /***********cr_mob_0061 start ****/
    //Cheque Excess Amount Start
    $scope.checkCollecAmt = function (data) {
        if (data === "cheque") {
            /*changes for CR_MOBL_0066 start*/
            for (var i = 0; i < $scope.collectionFormData.chequeFormData.length; i++) {
                $scope.collectCheck = false;
                if (parseFloat($scope.collectionFormData.chequeFormData[i].collectionAmount) > parseFloat($scope.netPremium)) {
                    $scope.collectCheck = true;
                }
                else if (angular.isUndefined($scope.collectionFormData.chequeFormData[i].collectionAmount)) {
                    $scope.collectionFormData.chequeFormData[i].instrumentAmount = '';
                }

                else if (parseFloat($scope.collectionFormData.chequeFormData[i].collectionAmount) < parseFloat($scope.netPremium) || parseFloat($scope.collectionFormData.chequeFormData[i].collectionAmount) === parseFloat($scope.netPremium)) {
                    $scope.excessAmountDraft = false;
                    $scope.collectionFormData.chequeFormData[i].instrumentAmount = parseFloat($scope.collectionFormData.chequeFormData[i].collectionAmount);
                }
            }
        }
        if (data === "draft") {
            $scope.collectCheck = false;
            if (parseFloat($scope.collectionFormData.demandDraftFormData[0].collectionAmount) > parseFloat($scope.netPremium)) {
                $scope.collectCheck = true;
            }
            else if (angular.isUndefined($scope.collectionFormData.demandDraftFormData[0].collectionAmount)) {
                $scope.collectionFormData.demandDraftFormData[0].instrumentAmount = '';
            }
            else if (parseFloat($scope.collectionFormData.demandDraftFormData[0].collectionAmount) < parseFloat($scope.netPremium) || parseFloat($scope.collectionFormData.demandDraftFormData[0].collectionAmount) === parseFloat($scope.netPremium)) {
                $scope.excessAmountDraft = false;
                $scope.collectionFormData.demandDraftFormData[0].instrumentAmount = parseFloat($scope.collectionFormData.demandDraftFormData[0].collectionAmount);
            }
        }
        /*changes for CR_MOBL_0066 end*/

    };
    $scope.checkInstAmt = function (data) {
        if (data === "cheque") {
            /*changes for CR_MOBL_0066 start*/
            for (var i = 0; i < $scope.collectionFormData.chequeFormData.length; i++) {
                $scope.instcheck = false;

                if (parseFloat($scope.collectionFormData.chequeFormData[i].instrumentAmount) > parseFloat($scope.collectionFormData.chequeFormData[i].collectionAmount) && parseFloat($scope.collectionFormData.chequeFormData[i].collectionAmount) === parseFloat($scope.netPremium)) {
                    if ($scope.multiple == false) {
                        $scope.collectionFormData.chequeFormData[i].excessAmount = 0;
                        $scope.excessAmountDraft = true;
                        $scope.collectionFormData.chequeFormData[i].excessAmount = $scope.collectionFormData.chequeFormData[i].instrumentAmount - $scope.netPremium;
                    }
                    else {
                        $scope.excessAmountDraft = false;
                        $scope.collectionFormData.chequeFormData[i].instrumentAmount = parseFloat($scope.collectionFormData.chequeFormData[i].collectionAmount);

                    }
                }
                else if (parseFloat($scope.collectionFormData.chequeFormData[i].instrumentAmount) < parseFloat($scope.collectionFormData.chequeFormData[i].collectionAmount) && parseFloat($scope.collectionFormData.chequeFormData[i].collectionAmount) === parseFloat($scope.netPremium)) {
                    $scope.instcheck = true;
                }
                else if (parseFloat($scope.collectionFormData.chequeFormData[i].instrumentAmount) === parseFloat($scope.collectionFormData.chequeFormData[i].collectionAmount) || angular.isUndefined($scope.collectionFormData.chequeFormData[i].instrumentAmount)) {
                    $scope.excessAmountDraft = false;
                }
                else if (parseFloat($scope.collectionFormData.chequeFormData[i].collectionAmount) < parseFloat($scope.netPremium) || parseFloat($scope.collectionFormData.chequeFormData[i].collectionAmount) === parseFloat($scope.netPremium)) {
                    $scope.excessAmountDraft = false;
                    $scope.collectionFormData.chequeFormData[i].instrumentAmount = parseFloat($scope.collectionFormData.chequeFormData[i].collectionAmount);
                }
            }
        }
        if (data === "draft") {

            $scope.instcheck = false;
            $scope.collectCheck = false;
            if (parseFloat($scope.collectionFormData.demandDraftFormData[0].instrumentAmount) > parseFloat($scope.collectionFormData.demandDraftFormData[0].collectionAmount) && parseFloat($scope.collectionFormData.demandDraftFormData[0].collectionAmount) === parseFloat($scope.netPremium)) {
                if ($scope.multiple == false) {
                    $scope.collectionFormData.demandDraftFormData[0].excessAmount = 0;
                    $scope.excessAmountDraft = true;
                    $scope.collectionFormData.demandDraftFormData[0].excessAmount = $scope.collectionFormData.demandDraftFormData[0].excessAmount + ($scope.collectionFormData.demandDraftFormData[0].instrumentAmount - $scope.netPremium);
                }
                else {
                    $scope.excessAmountDraft = false;
                    $scope.collectionFormData.demandDraftFormData[0].instrumentAmount = parseFloat($scope.collectionFormData.demandDraftFormData[0].collectionAmount);

                }

            }
            else if (parseFloat($scope.collectionFormData.demandDraftFormData[0].instrumentAmount) < parseFloat($scope.collectionFormData.demandDraftFormData[0].collectionAmount) && parseFloat($scope.collectionFormData.demandDraftFormData[0].collectionAmount) === parseFloat($scope.netPremium)) {
                $scope.instcheck = true;
            }
            else if (parseFloat($scope.collectionFormData.demandDraftFormData[0].instrumentAmount) === parseFloat($scope.collectionFormData.demandDraftFormData[0].collectionAmount) || angular.isUndefined($scope.collectionFormData.demandDraftFormData[0].instrumentAmount)) {
                $scope.excessAmountDraft = false;
            }
            else if (parseFloat($scope.collectionFormData.demandDraftFormData[0].collectionAmount) < parseFloat($scope.netPremium) || parseFloat($scope.collectionFormData.demandDraftFormData[0].collectionAmount) === parseFloat($scope.netPremium)) {
                $scope.excessAmountDraft = false;
                $scope.collectionFormData.demandDraftFormData[0].instrumentAmount = parseFloat($scope.collectionFormData.demandDraftFormData[0].collectionAmount);
            }

        }
        /*changes for CR_MOBL_0066 end*/

    };
    /***********cr_mob_0061 start ****/
    //Cheque Excess Amount End




    var totalPremium = 0;
    var chequeIdDuplicate = false;

    $scope.compareChequeID = function (chequArr) {
        chequeIdDuplicate = false;
        if (chequArr.length > 1) {
            for (var i = 0; i < chequArr.length; i++) {
                for (var j = 0; j < i; j++) {
                    if (chequArr[i].chequeNo == chequArr[j].chequeNo) {
                        chequeIdDuplicate = true;
                    }
                }
            }
        }
    };
    /*Added for CR_MOBL_0066 start*/
    $scope.Confirm = function (msg, $true, $false) {
        var $content = "<div class='excessAmount'>" +
            "<div class='contactModalCont'>" + "<div class='dialog-msg'>" +
            " <p> " + msg + " </p> " +
            "</div>" +
            "<footer>" +
            "<div class='controls'>" +
            " <button class='button button-danger doAction'>" + $true + "</button> " +
            " <button class='button button-default cancelAction'>" + $false + "</button> " +
            "</div>" +
            "</footer>" +
            "</div>" +
            "</div>";
        $('body').prepend($content);
        $('.doAction').click(function () {
            $scope.collectionPostData();
            $(this).parents('.excessAmount').fadeOut(500, function () {
                $(this).remove();
            });
        });
        $('.cancelAction, .fa-close').click(function () {
            $(this).parents('.excessAmount').fadeOut(500, function () {
                $(this).remove();
            });
        });

    };
    /*Added for CR_MOBL_0066 end*/

    $scope.addCollAmount = function () {
        var i = "";
        var chequetotalPremium = 0;
        totalPremium = 0;
        if ($scope.collectionFormData.apdFormData.length > 0) {
            var subCodeArr = $scope.collectionFormData.apdFormData;
            for (i = 0; i < $scope.collectionFormData.apdFormData.length; i++) {
                totalPremium = parseFloat($scope.collectionFormData.apdFormData[i].collectionAmount) + totalPremium;
                delete $scope.collectionFormData.apdFormData[i].$$hashKey;
            }

        } else if ($scope.collectionFormData.cashFormData.length > 0) {

            var cashamt = parseFloat($scope.collectionFormData.cashFormData[0].cashAmount);

            if ($scope.collectionFormData.chequeFormData.length > 0) {
                for (i = 0; i < $scope.collectionFormData.chequeFormData.length; i++) {
                    chequetotalPremium = parseFloat($scope.collectionFormData.chequeFormData[i].instrumentAmount) + chequetotalPremium;
                    delete $scope.collectionFormData.chequeFormData[i].$$hashKey;
                }
            }
            totalPremium = chequetotalPremium + cashamt;
            delete $scope.collectionFormData.cashFormData[0].$$hashKey;
        } else if ($scope.collectionFormData.chequeFormData.length > 0) {
            var chequArr = $scope.collectionFormData.chequeFormData;
            for (i = 0; i < $scope.collectionFormData.chequeFormData.length; i++) {
                totalPremium = parseFloat($scope.collectionFormData.chequeFormData[i].instrumentAmount) + totalPremium;
                chequetotalPremium = parseFloat($scope.collectionFormData.chequeFormData[i].instrumentAmount) + chequetotalPremium;
                delete $scope.collectionFormData.chequeFormData[i].$$hashKey;
            }
            $scope.compareChequeID(chequArr);
        }
        /********Start CR_MOB_0061 **********/

        else if ($scope.collectionFormData.demandDraftFormData.length > 0) {
            for (i = 0; i < $scope.collectionFormData.demandDraftFormData.length; i++) {
                totalPremium = parseFloat($scope.collectionFormData.demandDraftFormData[i].instrumentAmount) + totalPremium;
                delete $scope.collectionFormData.demandDraftFormData[i].$$hashKey;
            }
        }

        /********End CR_MOB_0061 ***********/

        /*start changes for CR867*/
        else if ($scope.collectionFormData.ezeTapFormData.length > 0) {
            for (i = 0; i < $scope.collectionFormData.ezeTapFormData.length; i++) {
                totalPremium = parseFloat($scope.collectionFormData.ezeTapFormData[i].collectionAmount) + totalPremium;
                delete $scope.collectionFormData.ezeTapFormData[i].$$hashKey;
            }

        }
        /*end changes for CR867*/


        /**** added for CR_MOBL_0061 Start***/

        else if ($scope.collectionFormData.netBankingFormData.length > 0) {
            var subCodeArr = $scope.collectionFormData.netBankingFormData;
            for (i = 0; i < $scope.collectionFormData.netBankingFormData.length; i++) {
                totalPremium = parseFloat($scope.collectionFormData.netBankingFormData[i].collectionAmount) + totalPremium;
                delete $scope.collectionFormData.netBankingFormData[i].$$hashKey;
            }

        }
        /**** added for CR_MOBL_0061 End ***/

        /* Amount Calculation for SPL CR_NP_779 Start */
        else if ($scope.collectionFormData.SendPaymentLinkFormData.length > 0) {
            var subCodeArr = $scope.collectionFormData.SendPaymentLinkFormData;
            for (i = 0; i < $scope.collectionFormData.SendPaymentLinkFormData.length; i++) {
                totalPremium = parseFloat($scope.collectionFormData.SendPaymentLinkFormData[i].collectionAmount) + totalPremium;
                delete $scope.collectionFormData.SendPaymentLinkFormData[i].$$hashKey;
            }

        }
        /* Amount Calculation for SPL CR_NP_779 End */
    };
    /*Added for CR_867 Start*/
    $scope.termFlag = false;
    $scope.collectionPaymentFlag = false;
    $scope.termFlagEze = false;/*changes for CR867*/
    $scope.SPLtermFlag = false; /* CR_NP_779 */
    var stakevalue = CommonServices.getCommonData("stakeCode");
    var userID = {
        "stakemode": ""
    };
    var stakevalue = CommonServices.getCommonData("stakeCode");

    if (stakevalue == "AGENT") {
        userID.stakemode = "AG";
    }
    else if (stakevalue == "DEALER") {
        userID.stakemode = "DL";
    }
    else if (stakevalue == "DEVLP-OFF") {
        userID.stakemode = "DO";
    }
    else {
        userID.stakemode = "";
    }
	/*
	if (CommonServices.deviceType == "I") {
		$scope.sourceTransaction = "MOB/AP" + userID.stakemode + "_QR_RENEWAL";
	}
	else {
		$scope.sourceTransaction = "MOB/AN" + userID.stakemode + "_QR_RENEWAL";
	}
    */

    $scope.sourceTransaction = CommonServices.getPolicySource(CommonServices.getCommonData("currentStatus"));

    /**Added for CR_867 End**/


    $scope.collectionPostData = function () {
        $scope.termsConditions = false;//Added for CR_867
        collectionNotDone = false;
        var stakevalue = CommonServices.getCommonData("stakeCode");
        var CollectionData = {
            "userProfile": {
                "userId": CommonServices.getCommonData("userCode").toUpperCase(),
                "loggedInRole": CommonServices.getCommonData("loggedInRole")
            },
            "quote": {
                // "quoteNumber":$scope.policyData.quote.quoteNumber,
                "quoteNumber": CommonServices.saveQuoteDetailsData.quote.quoteNumber,
                "mobPolicySource": CommonServices.getPolicySource(CommonServices.getCommonData("currentStatus")),
                "payment": {
                    //"totalAmount":$scope.policyData.quote.premiumDetails.netPremium,
                    "totalAmount": CommonServices.saveQuoteDetailsData.quote.premiumDetails.netPremium,
                    "paymentDetailsList": []
                },
                "productCode": CommonServices.getCommonData("productCode"),
                "policyType": CommonServices.processType
            }
        };

        //only cheque
        if ($scope.collectionFormData.chequeFormData.length > 0 && $scope.collectionFormData.cashFormData.length == 0) {
            var data = $scope.collectionFormData.chequeFormData;
            for (var i = 0; i < data.length; i++) {
                var collectData = {
                    "collectionAmount": $scope.collectionFormData.chequeFormData[i].collectionAmount,
                    "instrumentAmount": $scope.collectionFormData.chequeFormData[i].instrumentAmount,
                    "chequeOrDraftOrPODate": $scope.collectionFormData.chequeFormData[i].chequeDate,
                    "chequeOrDraftOrPOType": data[i].chequeType.substring(0, 1),
                    "chequeOrDraftOrPONumber": $scope.collectionFormData.chequeFormData[i].chequeNo,
                    "bankName": $scope.collectionFormData.chequeFormData[i].draweeBankName,
                    "bankBranch": $scope.collectionFormData.chequeFormData[i].draweeBankBranch,
                    "excessAmount": $scope.collectionFormData.chequeFormData[i].excessAmount,
                    "collectionMode": "CHQ"
                };
                /*Added for CR_MOBL_0066 start*/

                var excesAmount = {
                    "bankBranch": $scope.collectionFormData.chequeFormData[i].draweeBankBranch,
                    "bankName": $scope.collectionFormData.chequeFormData[i].draweeBankName,
                    "chequeOrDraftOrPODate": $scope.collectionFormData.chequeFormData[i].chequeDate,
                    "chequeOrDraftOrPONumber": $scope.collectionFormData.chequeFormData[i].chequeNo,
                    "chequeOrDraftOrPOType": data[i].chequeType.substring(0, 1),
                    "collectionMode": "EXSC",
                    "excessAmount": $scope.collectionFormData.chequeFormData[i].excessAmount
                };


                if ($scope.excessAmountDraft) {
                    CollectionData.quote.payment.paymentDetailsList.push(collectData);
                    CollectionData.quote.payment.paymentDetailsList.push(excesAmount);
                }

                else {
                    CollectionData.quote.payment.paymentDetailsList.push(collectData);

                }
                /*Added for CR_MOBL_0066 end*/

            }
        } //only cash
        else if ($scope.collectionFormData.chequeFormData.length == 0 && $scope.collectionFormData.cashFormData.length > 0) {
            var collectData = {
                'collectionMode': "CSH",
                'collectionAmount': $scope.collectionFormData.cashFormData[0].cashAmount
            };
            CollectionData.quote.payment.paymentDetailsList.push(collectData);

        } //only apd
        else if ($scope.collectionFormData.apdFormData.length > 0) {
            for (var i = 0; i < $scope.collectionFormData.apdFormData.length; i++) {

                var collectData = {
                    'collectionMode': "APD",
                    'collectionAmount': $scope.collectionFormData.apdFormData[i].collectionAmount,
                    'subCode': $scope.collectionFormData.apdFormData[i].subCode,
                    'referenceNumber': $scope.collectionFormData.apdFormData[i].referenceNumber
                };
                CollectionData.quote.payment.paymentDetailsList.push(collectData);
            }
        } //cheque and cash
        else if ($scope.collectionFormData.chequeFormData.length > 0 && $scope.collectionFormData.cashFormData.length > 0) {
            var data = $scope.collectionFormData.chequeFormData;
            var collectData = {
                'collectionMode': "CSH",
                'collectionAmount': $scope.collectionFormData.cashFormData[0].cashAmount
            };
            CollectionData.quote.payment.paymentDetailsList.push(collectData);
            for (var i = 0; i < data.length; i++) {
                var collectData = {
                    "collectionAmount": $scope.collectionFormData.chequeFormData[i].instrumentAmount,
                    "instrumentAmount": $scope.collectionFormData.chequeFormData[i].instrumentAmount,
                    "chequeOrDraftOrPODate": $scope.collectionFormData.chequeFormData[i].chequeDate,
                    "chequeOrDraftOrPOType": data[i].chequeType.substring(0, 1),
                    "chequeOrDraftOrPONumber": $scope.collectionFormData.chequeFormData[i].chequeNo,
                    "bankName": $scope.collectionFormData.chequeFormData[i].draweeBankName,
                    "bankBranch": $scope.collectionFormData.chequeFormData[i].draweeBankBranch,
                    "excessAmount": $scope.collectionFormData.chequeFormData[i].excessAmount,
                    "collectionMode": "CHQ"
                };
                CollectionData.quote.payment.paymentDetailsList.push(collectData);
            }
        }
        //DD
        else if ($scope.collectionFormData.demandDraftFormData.length > 0) {
            var data = $scope.collectionFormData.demandDraftFormData;
            for (var i = 0; i < data.length; i++) {
                var collectData = {
                    'collectionAmount': data[i].collectionAmount,
                    "instrumentAmount": data[i].instrumentAmount,
                    "chequeOrDraftOrPODate": data[i].ddDate,
                    "chequeOrDraftOrPOType": data[i].chequeType.substring(0, 1),
                    "chequeOrDraftOrPONumber": data[i].chequeNo,
                    "bankName": data[i].draweeBankName.bankName,
                    "bankBranch": data[i].draweeBankBranch,
                    "excessAmount": data[i].excessAmount !== undefined && data[i].excessAmount !== "" ? data[i].excessAmount : 0,
                    "collectionMode": "DRF"
                };
                /*Added for CR_MOBL_0066 start*/

                var excesAmount = {
                    "bankBranch": $scope.collectionFormData.demandDraftFormData[i].draweeBankBranch,
                    "bankName": $scope.collectionFormData.demandDraftFormData[i].draweeBankName.bankName,
                    "chequeOrDraftOrPODate": $scope.collectionFormData.demandDraftFormData[i].chequeDate,
                    "chequeOrDraftOrPONumber": $scope.collectionFormData.demandDraftFormData[i].chequeNo,
                    "chequeOrDraftOrPOType": data[i].chequeType.substring(0, 1),
                    "collectionMode": "EXSC",
                    "excessAmount": $scope.collectionFormData.demandDraftFormData[i].excessAmount
                };
                if ($scope.excessAmountDraft) {
                    CollectionData.quote.payment.paymentDetailsList.push(collectData);
                    CollectionData.quote.payment.paymentDetailsList.push(excesAmount);
                }

                else {
                    CollectionData.quote.payment.paymentDetailsList.push(collectData);

                }
                /*Added for CR_MOBL_0066 end*/

            }
        }


        /*Start changes for CR867*/
        if ($scope.collectionFormData.ezeTapFormData.length > 0) {//chnages for CR867
            $scope.termFlagEze = true;
            //console.log("enabled termFlagEze");
            return false;
        }
        /*end changes for CR867 */

        /*Start changes for CR_MOBL_0061 Start*/
        if ($scope.collectionFormData.netBankingFormData.length > 0) {//chnages for CR867
            $scope.termFlag = true;
            //console.log("enabled netbanking");
            return false;
        }
        /*Start changes for CR_MOBL_0061 End*/

        /* SPL CR_NP_779 Start */
        if ($scope.collectionFormData.SendPaymentLinkFormData.length > 0) {
            $scope.SPLtermFlag = true;
            return false;
        }
        /* SPL CR_NP_779 End */
        var collectionResponse = RestServices.postService(RestServices.urlPathsNewPortal.collection, CollectionData);

        collectionResponse.then(
            function (response) {
                CommonServices.showLoading(false);
                if (response.data.userProfile.footer.errorCode !== "1") {
                    CommonServices.showLoading(false);
                    /**CR690 Start**/
                    if (response.data.userProfile.footer.errorCode === "35145") {
                        $rootScope.panmodalOpen = true;
                        CommonServices.setCommonData("setPanMsg", response.data.userProfile.footer.errorDescription);
                    }
                    /**CR690 End**/
                    else {
                        CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
                    }

                } else {
                    angular.extend($scope.policyData, response.data);

                    var getPolicyData = {
                        "userProfile": {
                            "userId": CommonServices.getCommonData("userCode").toUpperCase(),
                            "loggedInRole": CommonServices.getCommonData("loggedInRole")
                        },
                        "quote": {
                            "policyNumber": $scope.policyData.quote.policyNumber,
                            "processType": "NB",
                            "productCode": CommonServices.getCommonData("productCode")
                        },
                        "productCode": CommonServices.getCommonData("productCode")
                    };

                    var getPolicyDataResponse = RestServices.postService(RestServices.urlPathsNewPortal.getPolicyDetails, getPolicyData);
                    getPolicyDataResponse.then(
                        function (response) {
                            CommonServices.showLoading(false);
                            angular.extend($scope.policyData, response.data);

                            $location.path('/newRenewPolicy/acknowledgement');
                        },
                        function (error) {
                            CommonServices.showLoading(false);
                            RestServices.handleWebServiceError(error);
                        });
                }

            },
            function (error) { // failure 
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            });
    };

    /*start chnages for CR867*/
    //Payment by Ezetap
    $scope.payEze = function () {
            $("#payEze").attr('disabled', 'disabled');
            //$scope.termsConditions= false;

            $scope.fetchPolicyHolderDetails(CommonServices.saveQuoteDetailsData.quote.policyHolderCode);
            //console.log("CollectionPaymentDetails"+JSON.stringify(CommonServices.saveQuoteDetailsData.quote));

            $scope.ezeTap(CommonServices.saveQuoteDetailsData.quote);
            return;
        }
    /*end chnages for CR867*/



    $scope.collectionFormSubmit = function () {

        if ($scope.collectionFormData.chequeFormData.length > 0 || $scope.collectionFormData.cashFormData.length > 0 || $scope.collectionFormData.apdFormData.length > 0 || $scope.collectionFormData.ezeTapFormData.length > 0 || $scope.collectionFormData.netBankingFormData.length > 0 || $scope.collectionFormData.demandDraftFormData.length > 0 || $scope.collectionFormData.SendPaymentLinkFormData.length > 0) {
            //changes for CR867 and CR_MOBL_0061 CR_NP_779
            $scope.addCollAmount();
            var netpremium = parseFloat(CommonServices.saveQuoteDetailsData.quote.premiumDetails.netPremium);
            $scope.excessAmount = totalPremium - netpremium;   /*Added for CR_MOBL_0066*/
            if (totalPremium == netpremium && chequeIdDuplicate != true) {
                $scope.collectionPostData();
            } else if (chequeIdDuplicate == true) {
                CommonServices.showAlert("Cheque number cannot be same for multiple cheques");
            }
            else if (totalPremium > netpremium) {
                /*Added for CR_MOBL_0066 start*/
                if ($scope.excessAmountDraft) {
                    var msg = "There is an excess of <span class='RupeeSymbol'>₹</span><b><strong>" + $scope.excessAmount + "</b></strong> in the instrument amount.Would you like to proceed with Policy issuance?";

                    // $scope.Confirm(msg, 'Yes', 'No');
                    CommonServices.messageModal('info', msg, false, 'No', 'Yes', function () {}, function () { 				$scope.collectionPostData();
                    }, 'Alert');
                    
                    // CommonServices.showAlert("Total collection amount is exceeding quote amount. Please review");
                }
                /*Added for CR_MOBL_0066 end*/
                else {
                    CommonServices.showAlert("Total collection amount is exceeding quote amount. Please review");
                }
            }
            else if (totalPremium < netpremium) {
                CommonServices.showAlert("Total collection amount is less than quote amount. Please review");
            }
        } else {
            if (submitCollection == true) {
                CommonServices.showAlert("Please add collection mode(s)");
            } else {
                CommonServices.showAlert("We are unable to process your request, as there is no collection modes available for this user.");
            }
        }

    };
    /*******added for CR_MOBL_0061 Start*****/
    //Payment by BillDesk
    $scope.payNow = function () {

        $scope.party = "";
        if (CommonServices.saveQuoteDetailsData.quote.policyHolderCode === undefined) {
            $scope.party = $rootScope.partyCode;
        }
        else {
            $scope.party = CommonServices.saveQuoteDetailsData.quote.policyHolderCode;
        }
        console.log("partyCode" + $scope.party);
        $scope.fetchPolicyHolderDetailsNetBank($scope.party);

        return;
    }
    $scope.billDesk = function (fetchQuoteDetails) {

        var refBillDesk = "";
        //var refBillDesk = (CommonServices.getCommonData(refhref) != undefined)? CommonServices.getCommonData(refhref): "";
        /*** added for CR_0061 Start ***/
        $scope.ompextn = "N";
        $scope.oldPolicy = "NA";
        /*** added for CR_0061 End ***/
        var policyType = "";
        if(CommonServices.getCommonData("currentStatus") === 'RENEWAL IN PROGRESS'){
            policyType = "QR";
        }
        else if(CommonServices.getCommonData("currentStatus") === "RENEWED POLICY" || CommonServices.getCommonData("currentStatus") === "APPROVED APPLICATION"){
            policyType = "QP";
        }   
        
        var refhref = (CommonServices.getCommonData(refhref) != undefined)? CommonServices.getCommonData(refhref): "";      // CR_3773
        if(refhref == ""){      // CR_3773
            refhref = RestServices.urlBillDesk + '?quoteNo=' + fetchQuoteDetails.quoteNumber +
                '&productCode=' + CommonServices.getCommonData("productCode") +
                '&netPremium=' + $scope.netPremium +
                '&userCode=' + CommonServices.getCommonData("userCode").toUpperCase() +
                '&partyCode=' + $scope.party +
                '&phoneNo=' + $scope.customerData.mobileNo +
                '&emailId=' + $scope.customerData.emailId +
                '&isOMPExtn=' + $scope.ompextn + '&sourceTransaction=' + $scope.sourceTransaction +
                '&isRenewal=Y&oldPolicyNum=' + $scope.oldPolicy + '&userType=' + stakevalue + '&policyType=' + policyType + '&channel=' + stakevalue + '&language=English';
            
            //CommonServices.setCommonData("refhref", refhref);       // CR_3773
       }

        console.log("url---->" + refhref);
        var billdeskServer = RestServices.urlBillDeskServer;
        var billDeskFingerPrint = RestServices.urlBillDeskFingerPrint;
      //  window.plugins.sslCertificateChecker.check(billdeskSuccessCallback, billdeskErrorCallback, billdeskServer, billDeskFingerPrint);
	if($rootScope.environment == 'p')
		{
			window.plugins.sslCertificateChecker.check(billdeskSuccessCallback, billdeskErrorCallback, billdeskServer, billDeskFingerPrint);
		}
		else 
		{
			billdeskSuccessCallback("CONNECTION_SECURE"); // by passing ssl check - Subhapam
		}



        function billdeskSuccessCallback(message) {

            // Message is always: CONNECTION_SECURE.
            // Now do something with the trusted server.

            CommonServices.showLoading(false);

            refBillDesk = cordova.InAppBrowser.open(refhref, '_blank', 'location=no,hidden=yes,EnableViewPortScale=yes,disallowoverscroll=yes');

            refBillDesk.addEventListener('loadstart', inAppBrowserbLoadStart);
            refBillDesk.addEventListener('loadstop', inAppBrowserbLoadStop);
            refBillDesk.addEventListener('exit', inAppBrowserClose);

        }

        function billdeskErrorCallback(message) {

            if (message == "CONNECTION_NOT_SECURE") {
                CommonServices.showAlert("Could not connect to server. Suspicious connection detected", 'Error');
                //navigator.app.exitApp();

                // There is likely a man in the middle attack going on, be careful!
            } else if (message.indexOf("CONNECTION_FAILED") > -1) {

                // There was no connection (yet). Internet may be down. Try again (a few times) after a little timeout.
                if (!navigator.onLine) {
                    CommonServices.showAlert("Error Message : No internet connection available. Please check your network and try again.", 'No Network');
                    return;
                } else
                    CommonServices.showAlert("Could not connect to server. Please try again later or check your network settings", 'Error');
            }
        }

        /* Bill Desk code opens in inappbrowser */

        function inAppBrowserbLoadStart(event) {

            if ((event.url).indexOf("middleDemo.jsp") > -1) {
                refBillDesk.show();
            }
        }

        function inAppBrowserbLoadStop(event) {

            var getPaymentDetailsInputData = {
                "quote": {
                    "quoteNumber": $scope.quoteNumber
                },
                "paymentGateway": "BILLDESK"
            };

            var storeEvent = event;

            if ((event.url).indexOf("middleDemo.jsp") > -1) {
                refBillDesk.show();
            }

            if ((event.url).indexOf("PaymentResponse") > -1) {
                setTimeout(function () {

                    var getPaymentDetailsResp = RestServices.postService(RestServices.urlPathsNewPortal.getPaymentDetails, getPaymentDetailsInputData);
                    getPaymentDetailsResp.then(function (response) {

                        $scope.collectionPaymentFlag = true;
                        CommonServices.setCommonData("collectionPaymentFlag", $scope.collectionPaymentFlag);
                        if (response.data.errorCode === "0") {
                            CommonServices.setCommonData("billdeskQuote", $scope.quoteNumber);
                            CommonServices.setCommonData("billdeskResponse", response.data);
                            //angular.extend($rootScope.travelData,{"paymentConfirmation":response.data});
                            CommonServices.setCommonData("paymentMode", "billdesk");
                            if (response.data.authId === "0300" && response.data.policyNo === undefined) {

                                // Payment success and Policy Issuance failure
                                refBillDesk.close();
                                CommonServices.showLoading(false);

                                $scope.showViewPolDetailsBtn = false;
                                CommonServices.setCommonData("responseFlag", $scope.showViewPolDetailsBtn);
                                CommonServices.setCommonData("refhref", undefined);     //CR_3773
                                $state.go("acknowledgement");

                            } else if (response.data.authId === "0300" && response.data.policyNo != undefined) {

                                // Payment success and Policy Issuance success
                                refBillDesk.close();
                                CommonServices.showLoading(false);
                                $scope.showViewPolDetailsBtn = true;
                                CommonServices.setCommonData("responseFlag", $scope.showViewPolDetailsBtn);
                                CommonServices.setCommonData("refhref", undefined);     //CR_3773
                                $state.go("acknowledgement");
                            }
                            // else if(response.data.authId === "0002") { /*** CR_3773 Start ***/
							// 	refBillDesk.close();
							// 	CommonServices.showLoading(false);
							// 	let msg = "Your transaction has not been successful. If the amount has been debited, it will be auto-refunded. Do you want to retry the transaction?";
							// 	CommonServices.messageModal('info', msg, false, 'Yes', 'No', function () { 
							// 		$state.go("collectionPage");
							// 	}, function () { 
							// 		CommonServices.setCommonData("refhref", undefined);
							// 		$state.go("home");
							// 	}, 'Alert', true);
							// } /*** CR_3773 End ***/ 
                            else {
                                // Payment failure
                                refBillDesk.close();
                                CommonServices.showLoading(false);
                                $scope.showViewPolDetailsBtn = false;
                                CommonServices.setCommonData("responseFlag", $scope.showViewPolDetailsBtn);
                                CommonServices.setCommonData("refhref", undefined);     //CR_3773
                                $state.go("acknowledgement");
                            }
                        }
                        else {
                            refBillDesk.close();
                            CommonServices.showLoading(false);
                            CommonServices.showAlert("Could not connect to server, please try again after some time");
                            CommonServices.setCommonData("refhref", undefined);     //CR_3773
                            $state.go('home');
                        }

                    }, function (error) { // failure 
                        CommonServices.showLoading(false);
                        RestServices.handleWebServiceError(error);
                        refBillDesk.close();
                        CommonServices.setCommonData("refhref", undefined);         //CR_3773
                        /*$location.href("/buyRenewPolicy/collectData");*/
                        $state.go('home');
                    });

                }, 2000);
            }
        }


        function inAppBrowserClose(event) {
            CommonServices.showLoading(false);
        }

    }


    /*****added for CR_MOBL_0061 End*****/



    /*start changes for CR867*/

    $scope.fetchPolicyHolderDetails = function (policyHolderCode) {

        var policyHolderData = {
            "userProfile": {
                "userId": CommonServices.getCommonData("userId"),
                "loggedInRole": "SUPERUSER"
            }, "partyDetails": { "partyCode": policyHolderCode }
        };
        var policyHolderResponse = RestServices.postService(RestServices.urlPathsNewPortal.getPolicyHolderDetail, policyHolderData);
        policyHolderResponse.then(
            function (response) { // success

                CommonServices.showLoading(false);

                if (response.data.partyDetails !== undefined) {

                    //console.log("policy holder details::"+JSON.stringify(response.data));
                    $scope.customerData = response.data.partyDetails.individualDetails;
                    //console.log("policy holder details::"+JSON.stringify($scope.customerData));

                } else {

                    CommonServices.showLoading(false);
                    RestServices.handleWebServiceError("Customer Data not found");
                }
            },
            function (error) { // failure
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            });


    }

    $scope.fetchPolicyHolderDetailsNetBank = function (policyHolderCode) {

        var policyHolderData = {
            "userProfile": {
                "userId": CommonServices.getCommonData("userId"),
                "loggedInRole": "SUPERUSER"
            }, "partyDetails": { "partyCode": policyHolderCode }
        };
        var policyHolderResponse = RestServices.postService(RestServices.urlPathsNewPortal.getPolicyHolderDetail, policyHolderData);
        policyHolderResponse.then(
            function (response) { // success

                CommonServices.showLoading(false);

                if (response.data.partyDetails !== undefined) {

                    //console.log("policy holder details::"+JSON.stringify(response.data));
                    $scope.customerData = response.data.partyDetails.individualDetails;
                    console.log("policy holder details::" + JSON.stringify($scope.customerData));
                    $scope.billDesk(CommonServices.saveQuoteDetailsData.quote);


                } else {

                    CommonServices.showLoading(false);
                    RestServices.handleWebServiceError("Customer Data not found");
                }
            },
            function (error) { // failure
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            });


    }



    $scope.quoteNo = "";
    $scope.txnId = "";
    $scope.ezeTap = function (fetchQuoteDetails) {
        //alert('take it eze!!!!')
        //middle ware caled before ezetap initialize.
        //console.log("Initialize. cardPayment"+JSON.stringify(fetchQuoteDetails));
        $scope.quoteNo = fetchQuoteDetails.quoteNumber;
        var paymentGatewayInput = {
            "quoteNo": fetchQuoteDetails.quoteNumber,
            "premAmount": $scope.netPremium,
            "productCode": fetchQuoteDetails.productCode,
            "productName": fetchQuoteDetails.productName,
            "isRenewal": "Y",
            "oldPolicyNo": $scope.oldPolicy,
            "isOMPExtn": $scope.ompextn,
            "quoteCreatedBy": null,
            "roleCode": CommonServices.getCommonData("loggedInRole"),
            "emailId": fetchQuoteDetails.emailId,
            "phoneNo": fetchQuoteDetails.mobileNo,
            "channel": CommonServices.getCommonData("stakeCode"),
            "policyType": "NB",
            "userId": CommonServices.getCommonData("userCode").toUpperCase(),
            "userType": CommonServices.getCommonData("stakeCode"),
        };
        var paymentGatewayInputResp = RestServices.postService(RestServices.urlPathsNewPortal.paymentGatewayInput, paymentGatewayInput);

        //console.log("paymentGatewayInput-->"+JSON.stringify(paymentGatewayInput));

        paymentGatewayInputResp.then(
            function (response) {
                //alert("success");
                //console.log("getPaymentDetailsEasyTab responsedata: "+JSON.stringify(response));
                if (response.data.errCode === "0") {
                    $scope.txnId = response.data.msg;
                    //console.log("getPaymentDetailsEasyTab responsedata: "+JSON.stringify(response));

                    $scope.initEzetap();
                }
                else {
                    //CommonServices.showLoading(false);
                    $('#loader').hide();
                    RestServices.handleWebServiceError(response.data.msg);
                }
            },
            function (error) { // failure

                //alert("error");
                //console.log("getPaymentDetailsEasyTab errordata: "+JSON.stringify(error));
                //CommonServices.showLoading(false);
                $('#loader').hide();
                $("#payEze").removeAttr('disabled');
                RestServices.handleWebServiceError(error);

            });

        //$scope.initEzetap();
        //$scope.prepEzetap();
        //$scope.cardPayment(fetchQuoteDetails);

    }
    $scope.initEzetap = function () {
        var EzetapConfig = {
            "demoAppKey": "04982253-8a5a-4a0b-b061-48c6e24a971f",
            "prodAppKey": "04982253-8a5a-4a0b-b061-48c6e24a971f",
            "merchantName": "THE_NEW_INDIA_ASSURANCE_",
            "userName": "1112220033",
            "currencyCode": "INR",
            "appMode": "PROD",
            "captureSignature": "false",
            "prepareDevice": "true"
        };

        cordova.exec(ezeTapSuccessCallBack, ezeTapFailureCallBack, "EzeAPIPlugin", "initialize",
            [EzetapConfig]);
        function ezeTapSuccessCallBack(response) {
            //CommonServices.showAlert("Transaction successful. initEzetap"+JSON.stringify(response));
            //$scope.prepEzetap();
            $scope.cardPayment();
        };
        function ezeTapFailureCallBack(response) {
            $scope.closeEzetap();
            //console.log("Transaction failed. cardPayment"+JSON.parse(response));
            $scope.errorResponsedata = JSON.parse(response);
            //console.log("Transaction failed. cardPayment"+JSON.stringify($scope.errorResponsedata));
            //CommonServices.showLoading(false);
            $('#loader').hide();
            $("#payEze").removeAttr('disabled');
            //alert("ezeTapFailureCallBack");
            CommonServices.showAlert($scope.errorResponsedata.error.message);
        };
    }
    $scope.prepEzetap = function () {
        cordova.exec(ezeTapSuccessCallBack, ezeTapFailureCallBack, "EzeAPIPlugin", "prepareDevice", []);
        function ezeTapSuccessCallBack(response) {
            //CommonServices.showAlert("Transaction successful. prepEzetap"+JSON.stringify(response));
            $scope.cardPayment();
        };
        function ezeTapFailureCallBack(response) {
            $scope.closeEzetap();
            //console.log("Transaction failed. cardPayment"+JSON.parse(response));
            $scope.errorResponsedata = JSON.parse(response);
            //console.log("Transaction failed. cardPayment"+JSON.stringify($scope.errorResponsedata));
            //CommonServices.showLoading(false);
            $('#loader').hide();
            //alert("shhhhh");
            CommonServices.showAlert($scope.errorResponsedata.error.message);
        };
    }
    $scope.cardPayment = function () {
        var Request = {
            "amount": $scope.netPremium, //jsonRequest.put("amount", 0.00);
            "mode": "SALE", //jsonRequest.put("mode", "SALE | CASHBACK | CASH@POS");

            "options": {//jsonRequest.put("options", jsonOptionalParams);
                "amountCashback": 0.0,//jsonOptionalParams.put("amountCashback",0.00);
                "amountTip": 0.0,//jsonOptionalParams.put("amountTip",0.00);
                "references": { //jsonOptionalParams.put("references",jsonReferences);
                    //Building References Object
                    "reference1": $scope.quoteNo,
                    "reference2": $scope.txnId
                },
                "customer": {//jsonOptionalParams.put("customer",jsonCustomer);
                    //Building Customer Object
                    "name": $scope.customerData.firstName + " " + $scope.customerData.lastName,
                    "mobileNo": $scope.customerData.mobileNo,
                    "email": $scope.customerData.emailId
                }
            },
        };


        //  console.log("Ezetap request json::"+JSON.stringify(Request));
        cordova.exec(ezeTapSuccessCallBack, ezeTapFailureCallBack, "EzeAPIPlugin", "cardTransaction", [Request]);
        function ezeTapSuccessCallBack(response) {
            //CommonServices.showAlert("Transaction successful. cardPayment"+JSON.stringify(response));

            $scope.inputResponsedata = JSON.parse(response);
            //console.log("Transaction successful. cardPayment"+$scope.inputResponsedata);
            $scope.inputResponsedata.userType = CommonServices.getCommonData("stakeCode");
            //console.log("policy source "+ $scope.sourceTransaction);
            $scope.inputResponsedata.policySource = $scope.sourceTransaction;
            $scope.inputResponsedata.userId = CommonServices.getCommonData("userCode").toUpperCase();

            //console.log("Transaction successful. cardPayment"+JSON.stringify($scope.inputResponsedata));
            //middleware called for response update.
            $scope.issuePolicy($scope.inputResponsedata);
            $scope.closeEzetap();
        };
        function ezeTapFailureCallBack(response) {
            $scope.closeEzetap();
            //console.log("Transaction failed. cardPayment"+JSON.parse(response));
            $scope.errorResponsedata = JSON.parse(response);
            //console.log("Transaction failed. cardPayment"+JSON.stringify($scope.errorResponsedata));
            //CommonServices.showLoading(false);
            $('#loader').hide();
            $("#payEze").removeAttr('disabled');
            //alert("shhhhh");
            CommonServices.showAlert($scope.errorResponsedata.error.message);

        };
    }
    $scope.closeEzetap = function () {
        cordova.exec(ezeTapSuccessCallBack, ezeTapFailureCallBack, "EzeAPIPlugin", "close", []);
        function ezeTapSuccessCallBack(response) {
            //CommonServices.showAlert("Transaction successful."+JSON.stringify(response));
            //CommonServices.showLoading(false);
            //$('#loader').hide();
        };
        function ezeTapFailureCallBack(response) {
            $scope.errorResponsedata = JSON.parse(response);
            //console.log("Transaction failed. cardPayment"+JSON.stringify($scope.errorResponsedata));
            //CommonServices.showLoading(false);
            $('#loader').hide();
            CommonServices.showAlert($scope.errorResponsedata.error.message);
        };
    }


    /****adeed by kausik****/
    $scope.issuePolicy = function (ezeTapResponse) {

        //var localMiddleWareUrl="http://01hw363146:7777/BaNCSIntegrationWebComp/rest/mobPaymentGateway/processEzetapResponse"
        // RestServices.urlPathsNewPortal.getPaymentGatewayURL
        //console.log("input issuepolicy"+JSON.stringify(ezeTapResponse));
        var paymentGatewayInputResp = RestServices.postService(RestServices.urlPathsNewPortal.processEzetapResponse, ezeTapResponse);
        paymentGatewayInputResp.then(function (response) {
            //console.log("Success reponse from processEzetapResponse: "+JSON.stringify(response));
            $scope.collectionPaymentFlag = true;
            CommonServices.setCommonData("ezetapCollectionPaymentFlag", $scope.collectionPaymentFlag);
            //console.log("error code::"+response.data.userProfile.footer.errorCode);
            var vErrorCode = response.data.userProfile.footer.errorCode;
            //console.log("vErrorCode code::"+vErrorCode);
            //alert(vErrorCode);
            if (vErrorCode == "0") {
                CommonServices.setCommonData("ezetapQuote", response.data.quote.quoteNumber);
                CommonServices.setCommonData("ezetapResponse", response.data);
                //angular.extend($rootScope.travelData,{"paymentConfirmation":response.data});
                CommonServices.setCommonData("paymentMode", "ezetap");
                //if (response.data.authId === "0300" && response.data.quote.policyNumber === undefined) {
                //console.log("inside 0");
                //console.log("policy number::"+response.data.quote.policyNumber);
                if (response.data.quote.policyNumber === undefined) {
                    // Payment success and Policy Issuance failure
                    //refBillDesk.close();
                    //CommonServices.showLoading(false);
                    $('#loader').hide();
                    //console.log("inside first condition");

                    $scope.showViewPolDetailsBtn = false;
                    CommonServices.setCommonData("ezetapResponseFlag", $scope.showViewPolDetailsBtn);
                    $state.go("acknowledgement");

                } else if (response.data.quote.policyNumber != undefined) {

                    // Payment success and Policy Issuance success
                    //refBillDesk.close();
                    //CommonServices.showLoading(false);
                    $('#loader').hide();
                    //console.log("inside second condition");
                    $scope.showViewPolDetailsBtn = true;
                    CommonServices.setCommonData("ezetapResponseFlag", $scope.showViewPolDetailsBtn);
                    $state.go("acknowledgement");
                } else {
                    // Payment failure
                    //refBillDesk.close();
                    //console.log("inside third condition");
                    //CommonServices.showLoading(false);
                    $('#loader').hide();
                    $scope.showViewPolDetailsBtn = false;
                    CommonServices.setCommonData("ezetapResponseFlag", $scope.showViewPolDetailsBtn);
                    $state.go("acknowledgement");
                }
            } else {

                //console.log("inside third condition");
                //refBillDesk.close();
                //CommonServices.showLoading(false);

                console.log("error code::" + response.data.userProfile.footer.errorCode);
                CommonServices.setCommonData("ezetapQuote", response.data.quote.quoteNumber);
                CommonServices.setCommonData("ezetapResponse", response.data);
                //angular.extend($rootScope.travelData,{"paymentConfirmation":response.data});
                CommonServices.setCommonData("paymentMode", "ezetap");

                $('#loader').hide();
                CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
                $scope.showViewPolDetailsBtn = false;
                CommonServices.setCommonData("ezetapResponseFlag", $scope.showViewPolDetailsBtn);
                $state.go("acknowledgement");
                //$state.go('home');
            }




        }, function (error) {
            //console.log("Error reponse from processEzetapResponse "+JSON.stringify(error));
            //RestServices.handleWebServiceError(error);
            //CommonServices.showLoading(false);
            $('#loader').hide();
            RestServices.handleWebServiceError(error);

        });

    }

    /*****added by kausik end***
/*end changes for CR867*/

    //Service Call for Cheque Bank Name Start
    $scope.search = function () {
        if ($scope.bankSearch == null || $scope.bankSearch == undefined) //bank search text empty
        {
            $scope.list = [];
            $scope.bankSearchError = true;

        } else { // bank search text not empty
            var bankSearchData = JSON.stringify({
                "bankName": $scope.bankSearch.toUpperCase()
            });
            var bankSearchResponse = RestServices.postService(RestServices.urlPathsNewPortal.getBankDetails, bankSearchData);
            //web service call for bank search
            bankSearchResponse.then(
                function (response) { // success 
                    CommonServices.showLoading(false);
                    $scope.list = response.data.bankDataList;
                },
                function (error) { // failure 
                    CommonServices.showLoading(false);
                    RestServices.handleWebServiceError(error);
                });
        }
    };

    $scope.searchBank = function ($event) {
        $scope.showModal = true;
        $scope.clickedbank_id = $event;
        $scope.bankSearchError = false;
        $scope.bankSearch = null;
        $scope.list = null;
    };

    $scope.selectedBank = function (item) {
        var id = $scope.clickedbank_id;
        $scope.showModal = false;
        $scope.bankNameLabel = item.bankName;
        bankName = item.bankName;
        bankCode = item.draweeBankCode;
        $scope.collectionFormData.chequeFormData[id].draweeBankName = item.bankName;
        $scope.collectionFormData.chequeFormData[id].draweeBankCode = item.draweeBankCode;
        $scope.bankNameError = false;
    };

    $scope.hideModal = function () {
        $scope.referenceModel = false;
        $scope.subCodeModel = false;
        $scope.showModal = false;
        $scope.chequeModal = false;
    };

    /* CR_NP_779 Start */

    $scope.FetchEmailIDMobileNoDetails = function () {
        $scope.SPLAgentEmalid = CommonServices.saveQuoteDetailsData.quote.emailId;
        $scope.SPLAgentMobileNo = CommonServices.saveQuoteDetailsData.quote.mobileNo;
    }
    $scope.FetchPaymentLinkDeatils = function () {
        var SendPaymentLinkDataDeatils = {
            "productCode": CommonServices.saveQuoteDetailsData.quote.productCode,
            "polHolName": CommonServices.saveQuoteDetailsData.quote.policyHolderName,
            "quoteNo": $scope.quoteNumber,
            "paymentAmount": $scope.netPremium,
            "mobileNo": $scope.SPLAgentMobileNo,
            "emailId": $scope.SPLAgentEmalid,
            "splLink": "",
            "product": CommonServices.saveQuoteDetailsData.quote.productName,
            "onloadFlag": "Y",
            "policyHolderCode": CommonServices.saveQuoteDetailsData.quote.policyHolderCode
        }
        var SendPaymentLinkDataCountResponse = RestServices.postService(RestServices.urlPathsNewPortal.sendPaymentLinkCount, SendPaymentLinkDataDeatils);
        SendPaymentLinkDataCountResponse.then(function (response) {
            CommonServices.showLoading(false);
            if (response.data !== "") {
                if (response.data.statusMSg !== 'Successfull') {
                    CommonServices.showAlert(response.data.errorMessage);
                    return;
                } else {
                    if (response.data.statusMSg == 'Successfull') {
                        if (response.data.createdDate !== undefined) {
                            $scope.SPLcreatedDate = response.data.createdDate;
                        }
                        if (response.data.linkSend !== undefined) {
                            $scope.SPLLinkSend = response.data.linkSend;
                        }
                        if (response.data.sendCount !== undefined) {
                            $scope.CountReSendPaymntLink = response.data.sendCount;
                        }
                        if ($scope.CountReSendPaymntLink >= 1) {
                            $scope.buttonText = "Re-Send Payment Link"
                        }
                    }
                }
            } else {
                CommonServices.showAlert("Not able to load data of PaymentLinkCount");
            }
        }, function (error) { // failure 
            CommonServices.showLoading(false);
            RestServices.handleWebServiceError(error);
        });
    }

    $scope.SendPaymentLink = function () {
        if ($scope.collectionFormData.SendPaymentLinkFormData.length > 0) {
            if ($scope.CountReSendPaymntLink >= 4) {
                CommonServices.showAlert("You are allowed to re-send the payment link for a maximum of 3 times");
                return;
            }
            var SendPaymentLinkData = {
                "productCode": CommonServices.saveQuoteDetailsData.quote.productCode,
                "polHolName": CommonServices.saveQuoteDetailsData.quote.policyHolderName,
                "quoteNo": $scope.quoteNumber,
                "paymentAmount": $scope.netPremium,
                "mobileNo": $scope.SPLAgentMobileNo,
                "emailId": $scope.SPLAgentEmalid,
                "splLink": "",
                "product": CommonServices.saveQuoteDetailsData.quote.productName,
                "onloadFlag": "N",
                "policyHolderCode": CommonServices.saveQuoteDetailsData.quote.policyHolderCode
            }
            if ($scope.buttonText == 'Send Payment Link') {
                var SendPaymentLinkDataResponse = RestServices.postService(RestServices.urlPathsNewPortal.sendPaymentLink, SendPaymentLinkData);
                SendPaymentLinkDataResponse.then(function (response) {
                    CommonServices.showLoading(false);
                    if (response.data !== "") {
                        if (response.data.statusMSgEmail == 'Successfull' && response.data.statusMSgSMS == 'Successfull') {
                            CommonServices.showAlert("The payment link has successfully been sent to the policyholder\'s email ID and mobile number. ");
                            $scope.buttonText = "Re-Send Payment Link";
                            $scope.CountReSendPaymntLink = response.data.sendCount;
                        } else if (response.data.statusMSgEmail == 'Successfull') {
                            CommonServices.showAlert("The payment link has successfully been sent to the policyholder\'s email ID ");
                            $scope.buttonText = "Re-Send Payment Link";
                            $scope.CountReSendPaymntLink = response.data.sendCount;
                        } else if (response.data.statusMSgSMS == 'Successfull') {
                            CommonServices.showAlert("The payment link has successfully been sent to the policyholder\'s mobile number ");
                            $scope.buttonText = "Re-Send Payment Link";
                            $scope.CountReSendPaymntLink = response.data.sendCount;
                        } else {
                            CommonServices.showAlert(response.data.errorMessage);
                            return;
                        }
                    } else {
                        CommonServices.showAlert("Not able to load send Payment Link data");
                    }
                }, function (error) { // failure 
                    CommonServices.showLoading(false);
                    RestServices.handleWebServiceError(error);
                });
            }
            if ($scope.buttonText == 'Re-Send Payment Link') {
                if (CommonServices.deviceType !== "NA") {
                    navigator.notification.confirm("The Payment Link has already been sent to the policyholder. Would you like to Re-Send?", ReSendPaymentLink, "Confirm",
                        ["YES", "NO"]);
                } else {
                    var ReSendPaymentLinkConfirm;
                    ReSendPaymentLinkConfirm = confirm("The Payment Link has already been sent to the policyholder. Would you like to Re-Send?");
                    if (ReSendPaymentLinkConfirm) {
                        ReSendPaymentLink(1);
                    }
                }
            }
        }
    }

    function ReSendPaymentLink(button) {
        if (button == 1) {
            if ($scope.collectionFormData.SendPaymentLinkFormData.length > 0) {
                if ($scope.CountReSendPaymntLink >= 4) {
                    CommonServices.showAlert("You are allowed to re-send the payment link for a maximum of 3 times");
                    return;
                }
                var ReSendPaymentLinkData = {
                    "productCode": CommonServices.saveQuoteDetailsData.quote.productCode,
                    "polHolName": CommonServices.saveQuoteDetailsData.quote.policyHolderName,
                    "quoteNo": $scope.quoteNumber,
                    "paymentAmount": $scope.netPremium,
                    "mobileNo": $scope.SPLAgentMobileNo,
                    "emailId": $scope.SPLAgentEmalid,
                    "splLink": "",
                    "product": CommonServices.saveQuoteDetailsData.quote.productName,
                    "onloadFlag": "N",
                    "policyHolderCode": CommonServices.saveQuoteDetailsData.quote.policyHolderCode
                }
                var SendPaymentLinkDataResponse = RestServices.postService(RestServices.urlPathsNewPortal.sendPaymentLink, ReSendPaymentLinkData);
                SendPaymentLinkDataResponse.then(function (response) {
                    CommonServices.showLoading(false);
                    if (response.data !== "") {
                        if (response.data.statusMSgEmail == 'Successfull' && response.data.statusMSgSMS == 'Successfull') {
                            CommonServices.showAlert("The payment link has successfully been sent to the policyholder\'s email ID and mobile number. ");
                            $scope.buttonText = "Re-Send Payment Link";
                            $scope.CountReSendPaymntLink = response.data.sendCount;
                        } else if (response.data.statusMSgEmail == 'Successfull') {
                            CommonServices.showAlert("The payment link has successfully been sent to the policyholder\'s email ID ");
                            $scope.buttonText = "Re-Send Payment Link";
                            $scope.CountReSendPaymntLink = response.data.sendCount;
                        } else if (response.data.statusMSgSMS == 'Successfull') {
                            CommonServices.showAlert("The payment link has successfully been sent to the policyholder\'s mobile number ");
                            $scope.buttonText = "Re-Send Payment Link";
                            $scope.CountReSendPaymntLink = response.data.sendCount;
                        } else {
                            CommonServices.showAlert(response.data.errorMessage);
                            return;
                        }
                    } else {
                        CommonServices.showAlert("Not able to load Re-Send Payment Link data");
                    }
                }, function (error) { // failure 
                    CommonServices.showLoading(false);
                    RestServices.handleWebServiceError(error);
                });
            }
        }
    }

    /* CR_NP_779 End */

}]);

agentApp.controller('AcknowledgementCtrl', ['$scope', '$location', 'RestServices', 'CommonServices', function ($scope, $location, RestServices, CommonServices) {

    if (CommonServices.getCommonData("stakeCode") == "AGENT") {
        angular.element(document.querySelector(".businessDetails")).removeClass("hide");
    } else {
        angular.element(document.querySelector(".businessDetails")).addClass("hide");
    }

    $scope.closeAck = function () {
        if (CommonServices.isManageRenewals === true) {
            $location.path('/manageRenewals/manageRenewalsCalendar');
        } else {
            $location.path('/newRenewPolicy/getNewRenewPolicy');
        }

    };

}]);
