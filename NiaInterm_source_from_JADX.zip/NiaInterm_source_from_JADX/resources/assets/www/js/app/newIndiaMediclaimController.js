agentApp.controller('newIndiaMediclaimController', ['$scope','$rootScope','RestServices','CommonServices','$state','$rootScope', function ($scope,$rootScope, RestServices,CommonServices,$state) {
	
	CommonServices.floaterObj.goToNomineeInfoEdit ="premiumCalculate";
	CommonServices.floaterObj.goToMemeberInfoEdit ="premiumCalculate";
	CommonServices.floaterObj.serviceCall="";
	$scope.termsAndCondition = function(){
		$rootScope.termsCondOpen= true;
	}
	$scope.cataractLimit = 800000;
	/** Members Sum Insured **/
	$scope.sumInsuredData=[{
			"name":"100000",
			"value": "100000"
		},{
			"name":"200000",
			"value": "200000"	
		},{
			"name":"300000",
			"value": "300000"	
		},{
			"name":"500000",
			"value": "500000"	
		},{
			"name":"800000",
			"value": "800000"	
		},{
			"name":"1000000",
			"value": "1000000"	
		},{
			"name":"1200000",
			"value": "1200000"	
		},{
			"name":"1500000",
			"value": "1500000"	
		}
	];
	
	/** Calender Icon click **/
	$scope.calIconClick= function(event) {
			angular.element("#"+ event.currentTarget.children[0].id).focus(); 
	}; 
	var mydateStr = new Date(CommonServices.getCommonData("serverDate"));
    var mynewdateFrom = "";
	if(mydateStr != undefined){
		mynewdateFrom = new Date(mydateStr);
	} else {
		mynewdateFrom = new Date();
	}
	/** Set Proposer, Spouse, Parent DOB**/
	var enableProposerDOBCalMin = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 18));
    enableProposerDOBCalMin = new Date(enableProposerDOBCalMin.setDate(enableProposerDOBCalMin.getDate()));
	enableProposerDOBCalMin = getFormattedDate(enableProposerDOBCalMin);
	var TodyasDateFormatToCal = CommonServices.getCommonData("serverDate");
	
	/** Set Calender range for proposer, spouse, child and parent **/
	var enableProposerDOBCalfrom = getFormattedDate(mynewdateFrom);
	var enableProposerDOBCalTo =new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 61));
	/**Proposer DOB**/
	$('#proposerDateOfBirth').loadCalendar({
		'enableDateRange': true,
		'enableCalendarFrom': enableProposerDOBCalTo,
		'enableCalendarTo': enableProposerDOBCalfrom
	});
	/**Spouse DOB**/
	$('#spouseDateOfBirth').loadCalendar({
		'enableDateRange': true,
		'enableCalendarFrom': enableProposerDOBCalTo,
		'enableCalendarTo': enableProposerDOBCalfrom
	});
	/**Child DOB**/
	$scope.childDateOfBirth = function(index){
	  $("#idDocNoProposer"+index).loadCalendar({
		   'enableDateRange': true,
		   'enableCalendarFrom': enableProposerDOBCalTo,
		   'enableCalendarTo': enableProposerDOBCalfrom
	   });
       return true;
    };
	/**Parent DOB**/
	$scope.parentDateOfBirth = function(index){    
		$("#idDocNoParent"+index).loadCalendar({
		   'enableDateRange': true,
		   'enableCalendarFrom': enableProposerDOBCalTo,
		   'enableCalendarTo': enableProposerDOBCalfrom
		});
        return true;
    };
	//CR3738_A
	$scope.memberDateOfBirth = function(memberType,index,fromDate=null,toDate=null){

		console.log(memberType,index,fromDate,toDate);
		var elementID = '';
		if(fromDate==null) fromDate = enableProposerDOBCalTo;
		if(toDate==null) toDate = enableProposerDOBCalfrom;
		switch (memberType) {
			case "ward":
				elementID = '#idDocNoWard';
				break;
			case "brother":
				elementID = '#idDocNoBrother';
				break;
			case "sister":
				elementID = '#idDocNoSister';
				break;
			case "guardian":
				elementID = '#idDocNoGuardian';
				break;
			case "employee":
				elementID = '#idDocNoEmployee';
				break;	
			default:
				break;
		}

		setTimeout(()=> {
			$(elementID+index).loadCalendar({
				'enableDateRange': true,
				'enableCalendarFrom': fromDate,
				'enableCalendarTo': toDate
			});
			return true;
		},1000);
	};
	
	//3 months
	var childAgeEnableFrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 45));
	
	//25 years
	var enableChildDOBDOBCalTo = new Date(new Date().setFullYear(mynewdateFrom.getFullYear()-25));
	enableChildDOBDOBCalTo = new Date(enableChildDOBDOBCalTo.setDate(enableChildDOBDOBCalTo));
	enableChildDOBDOBCalTo = getFormattedDate(enableChildDOBDOBCalTo); 
	
	/** Policy Start date set to current date**/
	var policyStartDate = enableProposerDOBCalfrom;
    var arr = policyStartDate.split('/');
    policyStartDate =arr[1] + '/' + arr[0] + '/' + arr[2]; //dd/mm/yyyy
    CommonServices.floaterObj.policyStartDate = policyStartDate;
	
	/** Policy End date set to policyStartDate + 1 year **/
	var policyEndDate =new Date(mydateStr);
    policyEndDate.setFullYear(policyEndDate.getFullYear() +1);
    policyEndDate.setDate(policyEndDate.getDate() - 1);
    var dd = policyEndDate.getDate();
    var mm = policyEndDate.getMonth() + 1;
    var yyyy = policyEndDate.getFullYear();
	if (dd < 10) {
        dd = "0" + dd;
    }
	if (mm < 10) {
		mm = "0" + mm;
	}
	policyEndDate = dd + "/" +mm + "/" + yyyy;//policy end date
	CommonServices.floaterObj.policyExpiryDate = policyEndDate;
	
	$scope.memberInfo = {
		showProposer: true,
		cataractLimitProposer: 'N',
		showSpouse: false,
		addChildDisable: false,
		addParentDisable: false,
		childReq: false,
		parentReq: false,
		disableCountBtn: 1,
		coveredChildDetails: [],
		coveredParentDetails: [],
		coveredGuardianDetails: [],
		coveredEmployeeDetails: [],
		coveredWardDetails: [],
		coveredBrotherDetails: [],
		coveredSisterDetails: [],
		riskPremiumDetails : [],
		disableAddChildBtn: 0,
		disableAddParentBtn: 0,
		/** Add member to UK Product **/
		addMember:function(member) {
			this.disableCountBtn = this.disableCountBtn + 1;
			if(member === "SPOUSE") {
				$scope.memberInfo.spouseIsAdded = true;
				// if(this.disableAddChildBtn === 4){
					// $scope.memberInfo.addChildDisable=true;
				// }
				this.showSpouse=true;
				$scope.memberInfo.cataractLimitSpouse = "N"; //CR3738_A
				//$scope.memberInfo.addSpouseDisable=true;             
			} else if(member === "CHILD") {
				//$scope.memberInfo.addChildDisable = true;
				//$scope.memberInfo.showChildDOB=true;
				$scope.memberInfo.childReq = true;
				if($scope.memberInfo.coveredChildDetails.length <= 2){
					this.addChildFunc();					
					this.disableAddChildBtn = this.disableAddChildBtn + 1;
				} else if($scope.memberInfo.coveredChildDetails.length <= 3){
					$scope.memberInfo.addChildDisable=true;
					this.addChildFunc();				
					this.disableAddChildBtn = this.disableAddChildBtn + 1;					
                } else if($scope.memberInfo.coveredChildDetails.length  === 4){
					$scope.memberInfo.addChildDisable=true;
					this.addChildFunc();
					this.disableAddChildBtn = this.disableAddChildBtn + 1;
				} else {
					return false;
				}							
			} else if(member === "PROPOSER") {
				$scope.memberInfo.addProposerDisable = true;
				$scope.memberInfo.showProposer = true;
				$scope.memberInfo.cataractLimitProposer = "N"; //CR3738_A			
			} else if(member === "PARENT") {
				$scope.memberInfo.parentReq = true;
				if($scope.memberInfo.coveredParentDetails.length < 1){									
					this.addParentFunc();
					this.disableAddParentBtn = this.disableAddParentBtn + 1;
				} else if($scope.memberInfo.coveredParentDetails.length === 1){
					$scope.memberInfo.addParentDisable = true;
					this.addParentFunc();
					this.disableAddParentBtn = this.disableAddParentBtn + 1;
				} else {
					return false;
				}				
			}
			//CR3738_A
			else if(member === "WARD"){
				if($scope.memberInfo.coveredWardDetails.length<8 && this.disableCountBtn<=8){
					
					this.addOtherRelationFunc("WARD");
					$scope.memberDateOfBirth('ward',$scope.memberInfo.coveredWardDetails.length-1);	
				} else {
					return false;
				}		
			}else if(member === "BROTHER"){
				if($scope.memberInfo.coveredBrotherDetails.length<8 && this.disableCountBtn<=8){
					this.addOtherRelationFunc("BROTHER");
					$scope.memberDateOfBirth('brother',$scope.memberInfo.coveredBrotherDetails.length-1);	
				} else {
					return false;
				}		
			}else if(member === "SISTER"){
				if($scope.memberInfo.coveredSisterDetails.length<8 && this.disableCountBtn<=8){
					this.addOtherRelationFunc("SISTER");
					$scope.memberDateOfBirth('sister',$scope.memberInfo.coveredSisterDetails.length-1);	
				} else {
					return false;
				}		
			}else if(member === "GUARDIAN"){
				if($scope.memberInfo.coveredGuardianDetails.length<8 && this.disableCountBtn<=8){
					this.addOtherRelationFunc("GUARDIAN");
					$scope.memberDateOfBirth('guardian',$scope.memberInfo.coveredGuardianDetails.length-1);	
				} else {
					return false;
				}		
			}else if(member === "EMPLOYEE"){
				if($scope.memberInfo.coveredEmployeeDetails.length<8 && this.disableCountBtn<=8){
					this.addOtherRelationFunc("EMPLOYEE");
					$scope.memberDateOfBirth('employee',$scope.memberInfo.coveredEmployeeDetails.length-1);	
				} else {
					return false;
				}		
			}

		},
		addChildFunc: function(){
			$scope.memberInfo.coveredChildDetails
			.push({
				childDateOfBirth:'',
				sumInsuredAmountChild:'',
				dependentType:'',
				cataractLimit: 'N' //CR3738_A
			});				
		},
		addParentFunc: function(){
			$scope.memberInfo.coveredParentDetails
				.push({
					parentDateOfBirth:'',
					sumInsuredAmountParent:'',
					cataractLimit: 'N' //CR3738_A
				});
		},
		addOtherRelationFunc: function(memberType){ //CR3738_A
			if(memberType=='WARD'){
				$scope.memberInfo.coveredWardDetails
				.push({
					dateOfBirth:'',
					sumInsuredAmount:'',
					dependentType:'',
					cataractLimit: 'N'
				});
			}else if(memberType=='BROTHER'){
				$scope.memberInfo.coveredBrotherDetails
				.push({
					dateOfBirth:'',
					sumInsuredAmount:'',
					dependentType:'',
					cataractLimit: 'N'
				});
			}else if(memberType=='SISTER'){
				$scope.memberInfo.coveredSisterDetails
				.push({
					dateOfBirth:'',
					sumInsuredAmount:'',
					dependentType:'',
					cataractLimit: 'N'
				});
			}else if(memberType=='GUARDIAN'){
				$scope.memberInfo.coveredGuardianDetails
				.push({
					dateOfBirth:'',
					sumInsuredAmount:'',
					cataractLimit: 'N'
				});
			}else if(memberType=='EMPLOYEE'){
				$scope.memberInfo.coveredEmployeeDetails
				.push({
					dateOfBirth:'',
					sumInsuredAmount:'',
					cataractLimit: 'N'
				});
			}
							
		},
		
		/** Delete member from UK Product **/
		closeMember :function(member,index) {
			this.disableCountBtn = this.disableCountBtn - 1;
			if(member === 'SPOUSE'){
				//$scope.memberInfo.spouseIsAdded = false;
				$scope.memberInfo.showSpouse = false;
				$scope.memberInfo.spouseDateOfBirth = "";
				$scope.memberInfo.sumInsuredAmountSpouse = "";
				//$scope.memberInfo.dateOfBirthSpouseErr = false;
				$scope.memberInfo.cataractLimitSpouse = "N"; //CR3738_A
			} else if(member === 'CHILD'){
				this.disableAddChildBtn = this.disableAddChildBtn - 1;
				$scope.memberInfo.showChildDOB = false;
				$scope.memberInfo.childDateOfBirth ="";
				//$scope.memberInfo.dateOfBirthChildErr = false;
				this.coveredChildDetails.splice(this.coveredChildDetails.indexOf(index), 1);
				if(this.disableAddChildBtn < 4){
					$scope.memberInfo.addChildDisable=false;
				} 
				if(this.disableAddChildBtn === 0){
					$scope.memberInfo.childReq = false;
				}
			} else if(member === 'PROPOSER'){
				$scope.memberInfo.showProposer = false;
				$scope.memberInfo.addProposerDisable = false;
				$scope.memberInfo.proposerDateOfBirth = "";
				$scope.memberInfo.sumInsuredAmountProposer = "";
				$scope.memberInfo.cataractLimitProposer = "N"; //CR3738_A
			}  else if(member === 'PARENT'){
				this.disableAddParentBtn = this.disableAddParentBtn - 1;
				$scope.memberInfo.addParentDisable = false;
				$scope.memberInfo.parentDateOfBirth ="";
				this.coveredParentDetails.splice(this.coveredParentDetails.indexOf(index), 1);
				if(this.disableAddParentBtn < 2){
					$scope.memberInfo.addParentDisable=false;
				}
				if(this.disableAddParentBtn === 0){
					$scope.memberInfo.parentReq = false;
				}
			}
			//CR3738_A
			else if(member === 'GUARDIAN'){
				this.coveredGuardianDetails.splice(this.coveredGuardianDetails.indexOf(index), 1);
				
			}else if(member === 'EMPLOYEE'){
				this.coveredEmployeeDetails.splice(this.coveredEmployeeDetails.indexOf(index), 1);
				
			}else if(member === 'WARD'){
				this.coveredWardDetails.splice(this.coveredWardDetails.indexOf(index), 1);
				
			}else if(member === 'BROTHER'){
				this.coveredBrotherDetails.splice(this.coveredBrotherDetails.indexOf(index), 1);
				
			}else if(member === 'SISTER'){
				this.coveredSisterDetails.splice(this.coveredSisterDetails.indexOf(index), 1);
				
			}
		},
		dateOfBirthFunc: function(member){
		    enableProposerDOBCalComp = new Date(enableProposerDOBCalMin);
			if(member === "PROPOSER"){
				var dt1 = this.proposerDateOfBirth.split('/'),
				proposerbirthDateComp = dt1[1] + '/' + dt1[0] + '/' + dt1[2], //mm/dd/yyyy
				proposerbirthDateComp = new Date(proposerbirthDateComp);
				if(proposerbirthDateComp > enableProposerDOBCalComp){				
				    $scope.memberInfo.proposerDateOfBirth = "";
                    CommonServices.showAlert("Age of the Proposer should be between 18 years to 60 Years"); 					
				}else {					
					if($scope.memberInfo.coveredChildDetails.length > 0){
						var childDobCheck = false;
						for(var i=0; i< $scope.memberInfo.coveredChildDetails.length; i++){
							if(this.childParentsAgeCheck($scope.memberInfo.coveredChildDetails[i].childDateOfBirth, this.proposerDateOfBirth)){
								$scope.memberInfo.coveredChildDetails[i].childDateOfBirth = "";
								childDobCheck = true;
							}
						}
						if(childDobCheck){
							CommonServices.showAlert("Children Age cannot be more than that of Parents");
						}
					} else {
						//$scope.memberInfo.dateOfBirthProposerErr = false;
						var date = new Date(proposerbirthDateComp);
						var ageDifMs = Date.now() - date.getTime();
						var ageProposerYrs = new Date(ageDifMs); // miliseconds from epoch
						ageProposerYrs = Math.abs(ageProposerYrs.getUTCFullYear() - 1970);
						ageProposerYrs =ageProposerYrs.toString();
						CommonServices.floaterObj.ageProposerYrs=ageProposerYrs;	
					}
				}
			} else if(member === "SPOUSE"){
                var dt1 = this.spouseDateOfBirth.split('/'),
				spouseDateOfBirthComp = dt1[1] + '/' + dt1[0] + '/' + dt1[2], //mm/dd/yyyy
				spouseDateOfBirthComp = new Date(spouseDateOfBirthComp);
				if(spouseDateOfBirthComp > enableProposerDOBCalComp){
					$scope.memberInfo.spouseDateOfBirth = "";
					CommonServices.showAlert("Age of the Spouse should be between 18 years to 60 Years");
				}else{
					if($scope.memberInfo.coveredChildDetails.length > 0){
						var childDobCheck = false;
						for(var i=0; i< $scope.memberInfo.coveredChildDetails.length; i++){
							if(this.childParentsAgeCheck($scope.memberInfo.coveredChildDetails[i].childDateOfBirth, this.spouseDateOfBirth)){
								$scope.memberInfo.coveredChildDetails[i].childDateOfBirth = "";
								childDobCheck = true;
							}
						}
						if(childDobCheck){
							CommonServices.showAlert("Children Age cannot be more than that of Parents");
						}
					} else{
						var date = new Date(spouseDateOfBirthComp);
						var ageDifMs = Date.now() - date.getTime();
						var ageSpouseYrs = new Date(ageDifMs); // miliseconds from epoch
						ageSpouseYrs = Math.abs(ageSpouseYrs.getUTCFullYear() - 1970);
						ageSpouseYrs =ageSpouseYrs.toString();
						CommonServices.floaterObj.ageSpouseYrs=ageSpouseYrs;					
					}
				}				
			} else if(member === "PARENT"){
				for(var i =0; i< $scope.memberInfo.coveredParentDetails.length; i++){   
					if($scope.memberInfo.coveredParentDetails[i].memberInfo !== undefined){
						dt1 = $scope.memberInfo.coveredParentDetails[i].memberInfo.parentDateOfBirth.split('/'),
						parentDateOfBirthComp = dt1[1] + '/' + dt1[0] + '/' + dt1[2], //mm/dd/yyyy
						parentDateOfBirthComp = new Date(parentDateOfBirthComp);
						if(parentDateOfBirthComp > enableProposerDOBCalComp){
							$scope.memberInfo.coveredParentDetails[i].memberInfo.parentDateOfBirth = "";
							CommonServices.showAlert("Age of the Insured should be between 18 years to 60 Years");
						}
					}				
				}
				CommonServices.floaterObj.coveredParentDetails = $scope.memberInfo.coveredParentDetails;				
			}else if(member === "GUARDIAN"){
				for(var i =0; i< $scope.memberInfo.coveredGuardianDetails.length; i++){   
					dt1 = $scope.memberInfo.coveredGuardianDetails[i].dateOfBirth.split('/'),
					dateOfBirthComp = dt1[1] + '/' + dt1[0] + '/' + dt1[2], //mm/dd/yyyy
					dateOfBirthComp = new Date(dateOfBirthComp);
					if(dateOfBirthComp > enableProposerDOBCalComp){
						$scope.memberInfo.coveredGuardianDetails[i].dateOfBirth = "";
						CommonServices.showAlert("Age of the Insured should be between 18 years to 60 Years");
					}
				}
			}else if(member === "EMPLOYEE"){
				for(var i =0; i< $scope.memberInfo.coveredEmployeeDetails.length; i++){   
					dt1 = $scope.memberInfo.coveredEmployeeDetails[i].dateOfBirth.split('/'),
					dateOfBirthComp = dt1[1] + '/' + dt1[0] + '/' + dt1[2], //mm/dd/yyyy
					dateOfBirthComp = new Date(dateOfBirthComp);
					if(dateOfBirthComp > enableProposerDOBCalComp){
						$scope.memberInfo.coveredEmployeeDetails[i].dateOfBirth = "";
						CommonServices.showAlert("Age of the Insured should be between 18 years to 60 Years");
					}
				}
			}
			if(CommonServices.editQuoteFlag === true){				
				for(var i=0; i < CommonServices.floaterObj.risks.length ; i++){
					if(CommonServices.floaterObj.risks[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "SELF"){
						if(ageProposerYrs !== undefined && ageProposerYrs !== ""){
							CommonServices.floaterObj.risks[i].riskDetails.ageInYrs = ageProposerYrs;
							CommonServices.floaterObj.risks[i].riskDetails.dateOfBirth = $scope.memberInfo.proposerDateOfBirth;
						}						
					}
					else if(CommonServices.floaterObj.risks[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "SPOUSE"){
						if(ageSpouseYrs !== undefined && ageSpouseYrs !== ""){
							CommonServices.floaterObj.risks[i].riskDetails.ageInYrs = ageSpouseYrs;
							CommonServices.floaterObj.risks[i].riskDetails.dateOfBirth = $scope.memberInfo.spouseDateOfBirth;
						}
					}					
				}
			}				
		},
		selectedSumInsured:function(){
			var minAmtAlert = false;
			$scope.memberInfo.sumInsuredEmpty=false;			
			if($scope.memberInfo.sumInsuredAmountProposer === "" || $scope.memberInfo.sumInsuredAmountProposer === undefined){
			} else {
				if($scope.memberInfo.sumInsuredAmountProposer !== undefined){
					this.cataractSelected('proposer');
				}
				if($scope.memberInfo.sumInsuredAmountSpouse !== undefined){ 
					if($scope.memberInfo.sumInsuredAmountSpouse !== ""){
						if(eval($scope.memberInfo.sumInsuredAmountSpouse + ">" + $scope.memberInfo.sumInsuredAmountProposer)){
							minAmtAlert = true;
							$scope.memberInfo.sumInsuredAmountSpouse = "";
						} else {
							this.sumInsuredErr = false;
						}
						this.cataractSelected('spouse');
					}
				}	
				
				for(var i=0; i< $scope.memberInfo.coveredChildDetails.length; i++){
					if($scope.memberInfo.coveredChildDetails[i].memberInfo !== undefined) {
						if($scope.memberInfo.coveredChildDetails[i].memberInfo.sumInsuredAmountChild !== ""){
							if(eval($scope.memberInfo.coveredChildDetails[i].memberInfo.sumInsuredAmountChild + ">" + $scope.memberInfo.sumInsuredAmountProposer)){
								minAmtAlert = true;
								$scope.memberInfo.coveredChildDetails[i].memberInfo.sumInsuredAmountChild = "";
							} else {
								this.sumInsuredErr = false;
							}
							this.cataractSelected('child',i);
						}
					}
				}
				for(var i=0; i< $scope.memberInfo.coveredParentDetails.length; i++){
					if($scope.memberInfo.coveredParentDetails[i].memberInfo !== undefined){ 
						if($scope.memberInfo.coveredParentDetails[i].memberInfo.sumInsuredAmountParent !== ""){
							if(eval($scope.memberInfo.coveredParentDetails[i].memberInfo.sumInsuredAmountParent + ">" + $scope.memberInfo.sumInsuredAmountProposer)){
								minAmtAlert = true;
								$scope.memberInfo.coveredParentDetails[i].memberInfo.sumInsuredAmountParent = "";
							} else {
								this.sumInsuredErr = false;
							}
							this.cataractSelected('parent',i);
						}
					}					
				}

				//CR3738_A
				for(var i=0; i< $scope.memberInfo.coveredGuardianDetails.length; i++){
					if($scope.memberInfo.coveredGuardianDetails[i].sumInsuredAmount !== ""){
						if(eval($scope.memberInfo.coveredGuardianDetails[i].sumInsuredAmount + ">" + $scope.memberInfo.sumInsuredAmountProposer)){
							minAmtAlert = true;
							$scope.memberInfo.coveredGuardianDetails[i].sumInsuredAmount = "";
						} else {
							this.sumInsuredErr = false;
						}
						this.cataractSelected('guardian',i);
					}					
				}
				for(var i=0; i< $scope.memberInfo.coveredEmployeeDetails.length; i++){
					if($scope.memberInfo.coveredEmployeeDetails[i].sumInsuredAmount !== ""){
						if(eval($scope.memberInfo.coveredEmployeeDetails[i].sumInsuredAmount + ">" + $scope.memberInfo.sumInsuredAmountProposer)){
							minAmtAlert = true;
							$scope.memberInfo.coveredEmployeeDetails[i].sumInsuredAmount = "";
						} else {
							this.sumInsuredErr = false;
						}
						this.cataractSelected('employee',i);
					}					
				}
				for(var i=0; i< $scope.memberInfo.coveredWardDetails.length; i++){
					if($scope.memberInfo.coveredWardDetails[i].sumInsuredAmount !== ""){
						if(eval($scope.memberInfo.coveredWardDetails[i].sumInsuredAmount + ">" + $scope.memberInfo.sumInsuredAmountProposer)){
							minAmtAlert = true;
							$scope.memberInfo.coveredWardDetails[i].sumInsuredAmount = "";
						} else {
							this.sumInsuredErr = false;
						}
						this.cataractSelected('ward',i);
					}					
				}
				for(var i=0; i< $scope.memberInfo.coveredBrotherDetails.length; i++){
					if($scope.memberInfo.coveredBrotherDetails[i].sumInsuredAmount !== ""){
						if(eval($scope.memberInfo.coveredBrotherDetails[i].sumInsuredAmount + ">" + $scope.memberInfo.sumInsuredAmountProposer)){
							minAmtAlert = true;
							$scope.memberInfo.coveredBrotherDetails[i].sumInsuredAmount = "";
						} else {
							this.sumInsuredErr = false;
						}
						this.cataractSelected('brother',i);
					}					
				}
				for(var i=0; i< $scope.memberInfo.coveredSisterDetails.length; i++){
					if($scope.memberInfo.coveredSisterDetails[i].sumInsuredAmount !== ""){
						if(eval($scope.memberInfo.coveredSisterDetails[i].sumInsuredAmount + ">" + $scope.memberInfo.sumInsuredAmountProposer)){
							minAmtAlert = true;
							$scope.memberInfo.coveredSisterDetails[i].sumInsuredAmount = "";
						} else {
							this.sumInsuredErr = false;
						}
						this.cataractSelected('sister',i);
					}					
				}

				if(minAmtAlert){
					CommonServices.showAlert("Minimum 1 lakhs or max of Proposer's Sum Insured");
				}
			}
			/*if(CommonServices.editQuoteFlag === true){
				for(var i=0; i < CommonServices.floaterObj.risks.length ; i++){
					if(CommonServices.floaterObj.risks[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "SELF"){
						if($scope.memberInfo.sumInsuredAmount !== undefined && $scope.memberInfo.sumInsuredAmount !== ""){
							CommonServices.floaterObj.risks[i].riskSumInsured = $scope.memberInfo.sumInsuredAmount;
						}
						
					}				
				}*/
			 
		},
		childParentsAgeCheck:function(childAge, parentAge){
			var arr = childAge.split('/'); 
			childAge = arr[1] + '/' + arr[0] + '/' + arr[2]; //mm/dd/yyyy 
			childAge = new Date(childAge); 
			var dt1 = parentAge.split('/'),
			parentAge = dt1[1] + '/' + dt1[0] + '/' + dt1[2], //mm/dd/yyyy
			parentAge = new Date(parentAge);
			if(childAge < parentAge){								
				return true;				
			} else {
				return false;				
			}			
		},
		dependentTypeChanged:function(memberType="child"){
			var AgeInMonths = new Date(new Date().setMonth(mynewdateFrom.getMonth() -3));
			if(memberType=="child"){

				for(var i =0; i< $scope.memberInfo.coveredChildDetails.length; i++){
					if($scope.memberInfo.coveredChildDetails[i].memberInfo !== undefined){
						if($scope.memberInfo.coveredChildDetails[i].childDateOfBirth !== undefined){
							var childAge = $scope.memberInfo.coveredChildDetails[i].childDateOfBirth;
							var arr = childAge.split('/'); 
							childAge = arr[1] + '/' + arr[0] + '/' + arr[2]; //mm/dd/yyyy 
							childAge = new Date(childAge);   
						}					

						/*****commented as uat fix-cr_0044***/
						/*					
						if(this.proposerDateOfBirth !== undefined && this.childParentsAgeCheck($scope.memberInfo.coveredChildDetails[i].childDateOfBirth, this.proposerDateOfBirth)){
							$scope.memberInfo.coveredChildDetails[i].childDateOfBirth = "";
							CommonServices.showAlert("Children Age cannot be more than that of Parents");
						} else if(this.spouseDateOfBirth !== undefined && this.childParentsAgeCheck($scope.memberInfo.coveredChildDetails[i].childDateOfBirth, this.spouseDateOfBirth)){
							$scope.memberInfo.coveredChildDetails[i].childDateOfBirth = "";
							CommonServices.showAlert("Children Age cannot be more than that of Parents");
						} 
						else 
						*/
						
						if($scope.memberInfo.coveredChildDetails[i].memberInfo.dependentType ==='NA'){
							childAgeEnableFrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 18));
							$scope.childDateOfBirth = function(index){
								$("#idDocNoProposer"+index).loadCalendar({
								'enableDateRange': true,
								'enableCalendarFrom': childAgeEnableFrom,
								'enableCalendarTo': enableProposerDOBCalfrom
								});
								return true;
							};
							if(childAge > AgeInMonths || childAge < childAgeEnableFrom) {
								$scope.memberInfo.coveredChildDetails[i].childDateOfBirth = "";
								CommonServices.showAlert("Age of child should be between 3 months to 18 years");   
							} else{
								$scope.memberInfo.dateOfBirthChildErr = false;
							}
						}else if($scope.memberInfo.coveredChildDetails[i].memberInfo.dependentType === 'NORM'){
							childAgeEnableFrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 25));
							$scope.childDateOfBirth = function(index){
								$("#idDocNoProposer"+index).loadCalendar({
								'enableDateRange': true,
								'enableCalendarFrom': childAgeEnableFrom,
								'enableCalendarTo': enableProposerDOBCalfrom
								});
								return true;
							};                         
							if(childAge > AgeInMonths || childAge < childAgeEnableFrom){
								$scope.memberInfo.coveredChildDetails[i].childDateOfBirth = "";
								CommonServices.showAlert("Age of the child should be between 3 Months to 25 Years");   
							}
						} else{
							if($scope.memberInfo.coveredChildDetails[i].memberInfo.dependentType  === 'MC' || $scope.memberInfo.coveredChildDetails[i].memberInfo.dependentType  === 'UD'){
								childAgeEnableFrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 61));
								$scope.childDateOfBirth = function(index){
									$("#idDocNoProposer"+index).loadCalendar({
									'enableDateRange': true,
									'enableCalendarFrom': childAgeEnableFrom,
									'enableCalendarTo': enableProposerDOBCalfrom
									});
								return true;
								};									 
								if(childAge > AgeInMonths|| childAge < childAgeEnableFrom){
									$scope.memberInfo.coveredChildDetails[i].childDateOfBirth = "";
									CommonServices.showAlert("Age of the child should be between 3 Months to 60 Years");
								}
							} else {
								$scope.childDateOfBirth = function(index){
									$("#idDocNoProposer"+index).loadCalendar({
									'enableDateRange': true,
									'enableCalendarFrom': childAgeEnableFrom,
									'enableCalendarTo': enableProposerDOBCalfrom
									});
								return true;
								};
							}							   
						}
						
							
					}		
				}           
            }else{ //CR3738_A
				var memberArr = null;
				if(memberType=='ward') memberArr = $scope.memberInfo.coveredWardDetails;
				if(memberType=='brother') memberArr = $scope.memberInfo.coveredBrotherDetails;
				if(memberType=='sister') memberArr = $scope.memberInfo.coveredSisterDetails;
				
				for(var i=0; i< memberArr.length; i++){
					
					if(memberArr[i].dateOfBirth !== undefined){
						var childAge = memberArr[i].dateOfBirth;
						var arr = childAge.split('/'); 
						childAge = arr[1] + '/' + arr[0] + '/' + arr[2]; //mm/dd/yyyy 
						childAge = new Date(childAge);      
					}					
					
					if(memberArr[i].dependentType ==='NA'){
						childAgeEnableFrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 18));
						$scope.memberDateOfBirth(memberType,i,childAgeEnableFrom,enableProposerDOBCalfrom);
						if(childAge > AgeInMonths || childAge < childAgeEnableFrom) {
							memberArr[i].dateOfBirth = "";
							CommonServices.showAlert(`Age of ${memberType} should be between 3 months to 18 years`);   
						} 
					}else if(memberArr[i].dependentType === 'NORM'){
						childAgeEnableFrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 25));
						$scope.memberDateOfBirth(memberType,i,childAgeEnableFrom,enableProposerDOBCalfrom);
						if(childAge > AgeInMonths || childAge < childAgeEnableFrom){
							memberArr[i].dateOfBirth = "";
							CommonServices.showAlert(`Age of the ${memberType} should be between 3 Months to 25 Years`);   
						}
					} else{
						if(memberArr[i].dependentType  === 'MC' || memberArr[i].dependentType  === 'UD'){
							childAgeEnableFrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 61));
							$scope.memberDateOfBirth(memberType,i,childAgeEnableFrom,enableProposerDOBCalfrom);
							if(childAge > AgeInMonths|| childAge < childAgeEnableFrom){
								memberArr[i].dateOfBirth = "";
								CommonServices.showAlert(`Age of the ${memberType} should be between 3 Months to 60 Years`);
							}
						} else {
							$scope.memberDateOfBirth(memberType,i,childAgeEnableFrom,enableProposerDOBCalfrom);
						}							   
					}

					if(memberArr[i].dependentType == 'UD' && (memberType=='ward' || memberType=='brother')){
						memberArr[i].dependentType = '';
						CommonServices.showAlert(`Unmarried option can be chosen only for sister`);
					}else if(memberArr[i].dependentType == 'NA' && (memberType=='brother' || memberType=='sister')){
						memberArr[i].dependentType = '';
						CommonServices.showAlert(`Only dependent ${memberType} can be covered in the policy`);
					}
					
				}
			}	
		//	CommonServices.floaterObj.coveredChildDetails = $scope.memberInfo.coveredChildDetails;
		},
		checkAgeLimit: function(){ //CR3738_A
			let ageLimitCount = 0, maxAgeCount = 0;
			if(this.getAge(this.proposerDateOfBirth)<35) ageLimitCount++;
			if(this.getAge(this.proposerDateOfBirth)>50) maxAgeCount++;
			if(this.getAge(this.spouseDateOfBirth)<35) ageLimitCount++;
			if(this.getAge(this.spouseDateOfBirth)>50) maxAgeCount++;
			this.coveredChildDetails.forEach(member=>{
				if(this.getAge(member.childDateOfBirth)<35) ageLimitCount++;
				if(this.getAge(member.childDateOfBirth)>50) maxAgeCount++;
			});
			this.coveredParentDetails.forEach(member=>{
				if(this.getAge(member.memberInfo.parentDateOfBirth)<35) ageLimitCount++;
				if(this.getAge(member.memberInfo.parentDateOfBirth)>50) maxAgeCount++;
			});
			this.coveredWardDetails.forEach(member=>{
				if(this.getAge(member.dateOfBirth)<35) ageLimitCount++;
				if(this.getAge(member.dateOfBirth)>50) maxAgeCount++;
			});
			this.coveredBrotherDetails.forEach(member=>{
				if(this.getAge(member.dateOfBirth)<35) ageLimitCount++;
				if(this.getAge(member.dateOfBirth)>50) maxAgeCount++;
			});
			this.coveredSisterDetails.forEach(member=>{
				if(this.getAge(member.dateOfBirth)<35) ageLimitCount++;
				if(this.getAge(member.dateOfBirth)>50) maxAgeCount++;
			});
			this.coveredGuardianDetails.forEach(member=>{
				if(this.getAge(member.dateOfBirth)<35) ageLimitCount++;
				if(this.getAge(member.dateOfBirth)>50) maxAgeCount++;
			});
			this.coveredEmployeeDetails.forEach(member=>{
				if(this.getAge(member.dateOfBirth)<35) ageLimitCount++;
				if(this.getAge(member.dateOfBirth)>50) maxAgeCount++;
			});
			if(maxAgeCount>0 && (this.disableCountBtn<3 || ageLimitCount<1)){
				CommonServices.showAlert(`For age more than 50 years the following conditions needs to be satisfied in order to continue:-<br/>
				1. A minimum of 3 persons should be covered in the policy.<br/>
				2. At least one of the  members age should be less than 35 years.
				`);
				return true;
			}
			return false;
		},
		getAge: function(dateString) { //CR3738_A
			if(dateString){

				var today = new Date();
				var ageArr = dateString.split('/');
				ageCal = ageArr[2] + '/' + ageArr[1] + '/' + ageArr[0]; //mm/dd/yyyy
				var birthDate = new Date(ageCal);
				var age = today.getFullYear() - birthDate.getFullYear();
				var m = today.getMonth() - birthDate.getMonth();
				if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
					age--;
				}
				return age;
			}else{
				return NaN;
			}
		},
		cataractSelected: function(memberType,index=0){ //CR3738_A
			let errTxt = "The cover shall be available only Sum Insured of 8 lakhs and above.";
			if(memberType=='proposer' && (+this.sumInsuredAmountProposer<$scope.cataractLimit || !this.sumInsuredAmountProposer) && this.cataractLimitProposer=='Y'){
				this.cataractLimitProposer = 'N';
				CommonServices.showAlert(errTxt);
			}else if(memberType=='spouse' && (+this.sumInsuredAmountSpouse<$scope.cataractLimit || !this.sumInsuredAmountSpouse) && this.cataractLimitSpouse=='Y'){
				this.cataractLimitSpouse = 'N';
				CommonServices.showAlert(errTxt);
			}else if(memberType=='child' && (!this.coveredChildDetails[index].memberInfo || +this.coveredChildDetails[index].memberInfo.sumInsuredAmountChild<$scope.cataractLimit) && this.coveredChildDetails[index].cataractLimit=='Y'){
				this.coveredChildDetails[index].cataractLimit = 'N';
				CommonServices.showAlert(errTxt);
			}else if(memberType=='parent' && (!this.coveredParentDetails[index].memberInfo || +this.coveredParentDetails[index].memberInfo.sumInsuredAmountParent<$scope.cataractLimit) && this.coveredParentDetails[index].cataractLimit=='Y'){
				this.coveredParentDetails[index].cataractLimit = 'N';
				CommonServices.showAlert(errTxt);
			}else if(memberType=='guardian' && +this.coveredGuardianDetails[index].sumInsuredAmount<$scope.cataractLimit && this.coveredGuardianDetails[index].cataractLimit=='Y'){
				this.coveredGuardianDetails[index].cataractLimit = 'N';
				CommonServices.showAlert(errTxt);
			}else if(memberType=='employee' && +this.coveredEmployeeDetails[index].sumInsuredAmount<$scope.cataractLimit && this.coveredEmployeeDetails[index].cataractLimit=='Y'){
				this.coveredEmployeeDetails[index].cataractLimit = 'N';
				CommonServices.showAlert(errTxt);
			}else if(memberType=='ward' && +this.coveredWardDetails[index].sumInsuredAmount<$scope.cataractLimit && this.coveredWardDetails[index].cataractLimit=='Y'){
				this.coveredWardDetails[index].cataractLimit = 'N';
				CommonServices.showAlert(errTxt);
			}else if(memberType=='brother' && +this.coveredBrotherDetails[index].sumInsuredAmount<$scope.cataractLimit && this.coveredBrotherDetails[index].cataractLimit=='Y'){
				this.coveredBrotherDetails[index].cataractLimit = 'N';
				CommonServices.showAlert(errTxt);
			}else if(memberType=='sister' && +this.coveredSisterDetails[index].sumInsuredAmount<$scope.cataractLimit && this.coveredSisterDetails[index].cataractLimit=='Y'){
				this.coveredSisterDetails[index].cataractLimit = 'N';
				CommonServices.showAlert(errTxt);
			}
		},
		calcPremium: function(){
			 
			this.riskPremiumDetails =[];
			var totalSumInsured = "0";
			if (CommonServices.editQuoteFlag !== true) {
                CommonServices.floaterObj.addedMemberDetails = [];
            }
			if(this.checkAgeLimit()){
				return;
			}
			if($scope.memberInfo.showProposer === false && $scope.memberInfo.showSpouse === false && 
			$scope.memberInfo.coveredChildDetails.length === 0 && $scope.memberInfo.coveredParentDetails.length === 0 && $scope.memberInfo.coveredGuardianDetails.length === 0 && $scope.memberInfo.coveredEmployeeDetails.length === 0 && $scope.memberInfo.coveredWardDetails.length === 0 && $scope.memberInfo.coveredBrotherDetails.length === 0 && $scope.memberInfo.coveredSisterDetails.length === 0){
				CommonServices.showAlert("Atleast one member is required to take the policy");
			} else {
				if($scope.memberInfo.coveredChildDetails !== "undefined"){
					//According to CR_851
					//if($scope.memberInfo.showProposer === false && $scope.memberInfo.showSpouse === false) {
						//CommonServices.showAlert("Atleast one parent (Proposer/Spouse) should be covered.");
						//return;
					//} else {
						CommonServices.floaterObj.coveredChildDetails = $scope.memberInfo.coveredChildDetails;
					//}
				} else {
					CommonServices.floaterObj.coveredChildDetails = 0;
				}
				if($scope.memberInfo.showProposer === true){
					$scope.proposerRiskDetails={
						"riskSumInsured": $scope.memberInfo.sumInsuredAmountProposer,
						"riskDetails": {
						  "relationWithPolicyHolder": "Proposer",
						  "dateOfBirth": $scope.memberInfo.proposerDateOfBirth,
						  "ageInYrs": CommonServices.floaterObj.ageProposerYrs,
						  "cataractLimit": $scope.memberInfo.cataractLimitProposer
						}
					};
					totalSumInsured = eval(totalSumInsured + "+" + $scope.memberInfo.sumInsuredAmountProposer);
					this.riskPremiumDetails.push($scope.proposerRiskDetails);
				}
				CommonServices.floaterObj.addProposerDisable = $scope.memberInfo.showProposer;
				if($scope.memberInfo.showSpouse === true){
					$scope.spouseRiskDetails= {
						"riskSumInsured": $scope.memberInfo.sumInsuredAmountSpouse,
						"riskDetails": {
						  "relationWithPolicyHolder": "Spouse",
						  "dateOfBirth": $scope.memberInfo.spouseDateOfBirth,
						  "ageInYrs": CommonServices.floaterObj.ageSpouseYrs,
						  "cataractLimit": $scope.memberInfo.cataractLimitSpouse
						}
					};
					totalSumInsured = eval(totalSumInsured + "+" + $scope.memberInfo.sumInsuredAmountSpouse);
					this.riskPremiumDetails.push( $scope.spouseRiskDetails);
				}
				CommonServices.floaterObj.addSpouseDisable = $scope.memberInfo.showSpouse;
				if($scope.memberInfo.disableAddChildBtn > 0){
					for(var i =0; i< $scope.memberInfo.coveredChildDetails.length; i++){
						// var childAgeCal = $scope.memberInfo.coveredChildDetails[i].childDateOfBirth;
						// var Arr = childAgeCal.split('/');
						// childAgeCal = Arr[2] + '/' + Arr[1] + '/' + Arr[0]; //mm/dd/yyyy
						// var date = new Date(childAgeCal);
						// var ageDifMs = Date.now() - date.getTime();
						// var ageDinYrs = new Date(ageDifMs); // miliseconds from epoch
						// ageDinYrs = Math.abs(ageDinYrs.getUTCFullYear() - 1970);
						// ageDinYrs =ageDinYrs.toString();
						ageDinYrs=this.getAge($scope.memberInfo.coveredChildDetails[i].childDateOfBirth).toString();
						$scope.childRiskDetails = {
							"riskSumInsured": $scope.memberInfo.coveredChildDetails[i].memberInfo.sumInsuredAmountChild,
							"riskDetails": {
								"relationWithPolicyHolder": "Children",
								"dateOfBirth": $scope.memberInfo.coveredChildDetails[i].childDateOfBirth,
								"ageInYrs": ageDinYrs,
								"dependent": $scope.memberInfo.coveredChildDetails[i].memberInfo.dependentType === "NA"?"N":"Y",
								"dependentType": $scope.memberInfo.coveredChildDetails[i].memberInfo.dependentType,
								"cataractLimit": $scope.memberInfo.coveredChildDetails[i].cataractLimit
							}
						};
						totalSumInsured = eval(totalSumInsured + "+" + $scope.memberInfo.coveredChildDetails[i].memberInfo.sumInsuredAmountChild);
						this.riskPremiumDetails.push($scope.childRiskDetails);
					}					
				}
				CommonServices.floaterObj.addChildDisable = $scope.memberInfo.addChildDisable;
				CommonServices.floaterObj.coveredChildDetails = $scope.memberInfo.coveredChildDetails;
				CommonServices.floaterObj.countOfChild = $scope.memberInfo.disableAddChildBtn;
				if($scope.memberInfo.coveredParentDetails.length > 0){
					for(var i =0; i< $scope.memberInfo.coveredParentDetails.length; i++) {
						// var parentAgeCal = $scope.memberInfo.coveredParentDetails[i].memberInfo.parentDateOfBirth;
						// var Arr = parentAgeCal.split('/');
						// parentAgeCal = Arr[2] + '/' + Arr[1] + '/' + Arr[0]; //mm/dd/yyyy
						// var date = new Date(parentAgeCal);
						// var ageDifMs = Date.now() - date.getTime();
						// var ageDinYrs = new Date(ageDifMs); // miliseconds from epoch
						// ageDinYrs = Math.abs(ageDinYrs.getUTCFullYear() - 1970);
						// ageDinYrs =ageDinYrs.toString();
						ageDinYrs=this.getAge($scope.memberInfo.coveredParentDetails[i].memberInfo.parentDateOfBirth).toString();
						$scope.parentRiskDetails = {
							"riskSumInsured": $scope.memberInfo.coveredParentDetails[i].memberInfo.sumInsuredAmountParent,
							"riskDetails": {
							  "relationWithPolicyHolder": "Parents",
							  "dateOfBirth": $scope.memberInfo.coveredParentDetails[i].memberInfo.parentDateOfBirth,
							  "ageInYrs": ageDinYrs,
							  "cataractLimit": $scope.memberInfo.coveredParentDetails[i].cataractLimit
							}
						};
						totalSumInsured = eval(totalSumInsured + "+" + $scope.memberInfo.coveredParentDetails[i].memberInfo.sumInsuredAmountParent);
					//	totalSumInsured = totalSumInsured + $scope.memberInfo.coveredParentDetails[i].memberInfo.sumInsuredAmountParent;
						this.riskPremiumDetails.push($scope.parentRiskDetails);
					}
				}
				CommonServices.floaterObj.coveredParentDetails = $scope.memberInfo.coveredParentDetails;
				CommonServices.floaterObj.addParentDisable = $scope.memberInfo.addParentDisable;

				//CR3738_A
				//Guardian member block
				if($scope.memberInfo.coveredGuardianDetails.length > 0){
					for(var i =0; i< $scope.memberInfo.coveredGuardianDetails.length; i++) {
						
						ageDinYrs=this.getAge($scope.memberInfo.coveredGuardianDetails[i].dateOfBirth).toString();
						
						let guardianRiskDetails = {
							"riskSumInsured": $scope.memberInfo.coveredGuardianDetails[i].sumInsuredAmount,
							"riskDetails": {
							  "relationWithPolicyHolder": "Guardian",
							  "dateOfBirth": $scope.memberInfo.coveredGuardianDetails[i].dateOfBirth,
							  "ageInYrs": ageDinYrs,
							  "cataractLimit": $scope.memberInfo.coveredGuardianDetails[i].cataractLimit
							}
						};
						totalSumInsured = eval(totalSumInsured + "+" + $scope.memberInfo.coveredGuardianDetails[i].sumInsuredAmount);
						this.riskPremiumDetails.push(guardianRiskDetails);
					}
				}
				CommonServices.floaterObj.coveredGuardianDetails = $scope.memberInfo.coveredGuardianDetails;
				
				//Employee member block
				if($scope.memberInfo.coveredEmployeeDetails.length > 0){
					for(var i=0; i< $scope.memberInfo.coveredEmployeeDetails.length; i++) {
						
						ageDinYrs=this.getAge($scope.memberInfo.coveredEmployeeDetails[i].dateOfBirth).toString();
						let guardianRiskDetails = {
							"riskSumInsured": $scope.memberInfo.coveredEmployeeDetails[i].sumInsuredAmount,
							"riskDetails": {
							  "relationWithPolicyHolder": "Employee",
							  "dateOfBirth": $scope.memberInfo.coveredEmployeeDetails[i].dateOfBirth,
							  "ageInYrs": ageDinYrs,
							  "cataractLimit": $scope.memberInfo.coveredEmployeeDetails[i].cataractLimit
							}
						};
						totalSumInsured = eval(totalSumInsured + "+" + $scope.memberInfo.coveredEmployeeDetails[i].sumInsuredAmount);
						this.riskPremiumDetails.push(guardianRiskDetails);
					}
				}
				CommonServices.floaterObj.coveredEmployeeDetails = $scope.memberInfo.coveredEmployeeDetails;

				//Ward member block
				if($scope.memberInfo.coveredWardDetails.length > 0){
					for(var i=0; i< $scope.memberInfo.coveredWardDetails.length; i++){
						
						ageDinYrs=this.getAge($scope.memberInfo.coveredWardDetails[i].dateOfBirth).toString();
						$scope.childRiskDetails = {
							"riskSumInsured": $scope.memberInfo.coveredWardDetails[i].sumInsuredAmount,
							"riskDetails": {
								"relationWithPolicyHolder": "Ward",
								"dateOfBirth": $scope.memberInfo.coveredWardDetails[i].dateOfBirth,
								"ageInYrs": ageDinYrs,
								"dependent": $scope.memberInfo.coveredWardDetails[i].dependentType === "NA"?"N":"Y",
								"dependentType": $scope.memberInfo.coveredWardDetails[i].dependentType,
								"cataractLimit": $scope.memberInfo.coveredWardDetails[i].cataractLimit
							}
						};
						totalSumInsured = eval(totalSumInsured + "+" + $scope.memberInfo.coveredWardDetails[i].sumInsuredAmount);
						this.riskPremiumDetails.push($scope.childRiskDetails);
					}					
				}
				CommonServices.floaterObj.coveredWardDetails = $scope.memberInfo.coveredWardDetails;

				//Brother member block
				if($scope.memberInfo.coveredBrotherDetails.length > 0){
					for(var i=0; i< $scope.memberInfo.coveredBrotherDetails.length; i++){
						
						ageDinYrs=this.getAge($scope.memberInfo.coveredBrotherDetails[i].dateOfBirth).toString();
						$scope.childRiskDetails = {
							"riskSumInsured": $scope.memberInfo.coveredBrotherDetails[i].sumInsuredAmount,
							"riskDetails": {
								"relationWithPolicyHolder": "Brother",
								"dateOfBirth": $scope.memberInfo.coveredBrotherDetails[i].dateOfBirth,
								"ageInYrs": ageDinYrs,
								"dependent": $scope.memberInfo.coveredBrotherDetails[i].dependentType === "NA"?"N":"Y",
								"dependentType": $scope.memberInfo.coveredBrotherDetails[i].dependentType,
								"cataractLimit": $scope.memberInfo.coveredBrotherDetails[i].cataractLimit
							}
						};
						totalSumInsured = eval(totalSumInsured + "+" + $scope.memberInfo.coveredBrotherDetails[i].sumInsuredAmount);
						this.riskPremiumDetails.push($scope.childRiskDetails);
					}					
				}
				CommonServices.floaterObj.coveredBrotherDetails = $scope.memberInfo.coveredBrotherDetails;

				//Sister member block
				if($scope.memberInfo.coveredSisterDetails.length > 0){
					for(var i=0; i< $scope.memberInfo.coveredSisterDetails.length; i++){
						
						ageDinYrs=this.getAge($scope.memberInfo.coveredSisterDetails[i].dateOfBirth).toString();
						$scope.childRiskDetails = {
							"riskSumInsured": $scope.memberInfo.coveredSisterDetails[i].sumInsuredAmount,
							"riskDetails": {
								"relationWithPolicyHolder": "Sister",
								"dateOfBirth": $scope.memberInfo.coveredSisterDetails[i].dateOfBirth,
								"ageInYrs": ageDinYrs,
								"dependent": $scope.memberInfo.coveredSisterDetails[i].dependentType === "NA"?"N":"Y",
								"dependentType": $scope.memberInfo.coveredSisterDetails[i].dependentType,
								"cataractLimit": $scope.memberInfo.coveredSisterDetails[i].cataractLimit
							}
						};
						totalSumInsured = eval(totalSumInsured + "+" + $scope.memberInfo.coveredSisterDetails[i].sumInsuredAmount);
						this.riskPremiumDetails.push($scope.childRiskDetails);
					}					
				}
				CommonServices.floaterObj.coveredSisterDetails = $scope.memberInfo.coveredSisterDetails;				
				CommonServices.floaterObj.numberOfMembers = this.disableCountBtn;
				CommonServices.floaterObj.addedMemberDetails = JSON.parse(JSON.stringify(this.riskPremiumDetails));
				CommonServices.floaterObj.memberCoveredInPolicy =  $scope.memberInfo.showProposer? 'Y': 'N';

				this.riskPremiumDetails.forEach(item=>{
					delete item.riskDetails.cataractLimit;
				})
				var riskPremiumDetailsData = {
					"quote": {
						"risks": this.riskPremiumDetails,
						"productCode": "UK",
						"policyStartDate": policyStartDate,
						"policyExpiryDate": policyEndDate,
						"mobileNo": null,
						"emailId": null,
						"progressLevel": null,
						"optionalCoverINoProportionateDeduction":"NO",
					    "optionalCoverIIIRevisioninCataractLimit":"NO",
					    "optionalCoverIVVoluntaryCopay":"NO" 
					},
					"userProfile": {
						"userId": CommonServices.getCommonData("userId"),
						"loggedInRole": "SUPERUSER"
					}
				};
				var premCalcResponse = RestServices.postService(RestServices.urlPathsNewPortal.topUpCalcPremium, riskPremiumDetailsData);
				premCalcResponse.then(
				  function(response) { // success 				
					CommonServices.showLoading(false);	
					if(response.data !== undefined && response.data !== ""){
						if(response.data.hasOwnProperty('errorMessage')){
							CommonServices.showAlert(response.data.errorMessage);	
						}else{
						//	CommonServices.floaterObj.premiumCalResponse = response.data.quote;	
							CommonServices.floaterObj.quoteNumber = response.data.quote.quoteNumber;
							CommonServices.floaterObj.premiumDetails = response.data.quote.premiumDetails;
							CommonServices.floaterObj.premiumDetails.sumInsured = totalSumInsured;
							$state.go("floaterBasicPremium");
						}
					} else {
						CommonServices.showAlert("Something went wrong. Please try after some time");
					}	                  
				},
				function(error) { // failure
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
				});
			}
		}			
	};
	$scope.goBack = function() {
        $rootScope.backFlag = "";
        $state.go("topUpMediclaimLandingScreen");
    };
    
    /*$scope.next = function(){
        //if ($rootScope.currentIndex === $rootScope.additionalDetailsArray.length) {
  	$rootScope.dataforSaveQuote();
  	CommonServices.floaterObj.localStorageVAlues = $rootScope.additionalDetailsArray;
      $state.go("policyPeriodAndNomineeDetailsHealth");
       // }
  };
    */
    var policyStartDate = TodyasDateFormatToCal;
    var arr = policyStartDate.split('/');
        policyStartDate =arr[1] + '/' + arr[0] + '/' + arr[2]; //dd/mm/yyyy

        CommonServices.floaterObj.policyStartDate = policyStartDate;
        $scope.policyStartDate = policyStartDate;

        var policyEndDate =new Date(mydateStr);
        policyEndDate.setFullYear(policyEndDate.getFullYear() +1);
        policyEndDate.setDate(policyEndDate.getDate() - 1);
        var dd = policyEndDate.getDate();
        var mm = policyEndDate.getMonth() + 1;
        var yyyy = policyEndDate.getFullYear();

        if (dd < 10) {
        dd = "0" + dd;
        }

        if (mm < 10) {
        mm = "0" + mm;
        }
        policyEndDate = dd + "/" +mm + "/" + yyyy;//policy end date
        CommonServices.floaterObj.policyExpiryDate = policyEndDate;
        $scope.policyEndDate = policyEndDate;
        
    $scope.approvePay = function() { 
        $state.go("docUpload");
    };
	
	if ($rootScope.backFlag === "premCal") {
        $(".form-group").addClass('focused');
		$scope.memberInfo.showProposer = CommonServices.floaterObj.addProposerDisable;
		$scope.memberInfo.showSpouse = CommonServices.floaterObj.addSpouseDisable;
        $scope.memberInfo.addChildDisable = CommonServices.floaterObj.addChildDisable;
		$scope.memberInfo.addParentDisable = CommonServices.floaterObj.addParentDisable;
		
        $scope.memberInfo.coveredChildDetails = CommonServices.floaterObj.coveredChildDetails;
		$scope.memberInfo.coveredParentDetails = CommonServices.floaterObj.coveredParentDetails;
        $scope.memberInfo.disableAddChildBtn = CommonServices.floaterObj.countOfChild;
        // $scope.memberInfo.spouseIsAdded = CommonServices.floaterObj.addSpouseDisable;
        // $scope.memberInfo.sumInsuredEmpty = false;
        $scope.memberInfo.toupTermsAndCondition = true;
        $scope.memberInfo.disableCountBtn = CommonServices.floaterObj.numberOfMembers;

		//CR3738_A
        $scope.memberInfo.coveredGuardianDetails = CommonServices.floaterObj.coveredGuardianDetails;
        $scope.memberInfo.coveredEmployeeDetails = CommonServices.floaterObj.coveredEmployeeDetails;
        $scope.memberInfo.coveredWardDetails = CommonServices.floaterObj.coveredWardDetails;
        $scope.memberInfo.coveredSisterDetails = CommonServices.floaterObj.coveredSisterDetails;
        $scope.memberInfo.coveredBrotherDetails = CommonServices.floaterObj.coveredBrotherDetails;

		$scope.memberInfo.coveredGuardianDetails.forEach((item,index)=>{

			$scope.memberDateOfBirth('guardian',index);
		});
		$scope.memberInfo.coveredEmployeeDetails.forEach((item,index)=>{

			$scope.memberDateOfBirth('employee',index);
		});
		$scope.memberInfo.coveredWardDetails.forEach((item,index)=>{

			$scope.memberDateOfBirth('ward',index);
		});
		$scope.memberInfo.coveredSisterDetails.forEach((item,index)=>{

			$scope.memberDateOfBirth('sister',index);
		});
		$scope.memberInfo.coveredBrotherDetails.forEach((item,index)=>{

			$scope.memberDateOfBirth('brother',index);
		});

        //$scope.cityResidence = CommonServices.floaterObj.cityOfResidenceData;
        for (i = 0; i < CommonServices.floaterObj.addedMemberDetails.length; i++) {

            if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "PROPOSER") {
                $scope.memberInfo.proposerDateOfBirth = CommonServices.floaterObj.addedMemberDetails[i].riskDetails.dateOfBirth;
				$scope.sumInsuredProposer = CommonServices.floaterObj.addedMemberDetails[i].riskSumInsured;
				$scope.memberInfo.cataractLimitProposer = CommonServices.floaterObj.addedMemberDetails[i].riskDetails.cataractLimit;
            }

            if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "SPOUSE") {
                //$scope.memberInfo.showSpouseDOB = true;
                $scope.memberInfo.spouseDateOfBirth = CommonServices.floaterObj.addedMemberDetails[i].riskDetails.dateOfBirth;
				$scope.sumInsuredSpouse = CommonServices.floaterObj.addedMemberDetails[i].riskSumInsured;
				$scope.memberInfo.cataractLimitSpouse = CommonServices.floaterObj.addedMemberDetails[i].riskDetails.cataractLimit;
            }
			// if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "SPOUSE") {
                // //$scope.memberInfo.showSpouseDOB = true;
                // $scope.memberInfo.spouseDateOfBirth = CommonServices.floaterObj.addedMemberDetails[1].riskDetails.dateOfBirth;
				// $scope.sumInsuredSpouse = CommonServices.floaterObj.addedMemberDetails[i].riskSumInsured;
            // }

        }
    }	
	CommonServices.getDomainValues();
}]);
