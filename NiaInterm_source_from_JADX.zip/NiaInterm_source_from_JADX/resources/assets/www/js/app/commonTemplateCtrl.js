agentApp.controller('premCalCntrl', ['$scope', 'RestServices', 'CommonServices', '$state', '$rootScope', function ($scope, RestServices, CommonServices, $state, $rootScope) {

    $rootScope.termsCondOpen = false;
    CommonServices.floaterObj.serviceCall = "";
    $scope.termsAndCondition = function () {
        $rootScope.termsCondOpen = true;
    }
    $scope.notYoungMembers = true;       // CR_3738_B
    $scope.addedSenior = false;     // CR_3738_B
    CommonServices.floaterObj.goToNomineeInfoEdit = "premiumCalculate";
    CommonServices.floaterObj.goToMemeberInfoEdit = "premiumCalculate";

    $scope.memberInfo = {
        addSelfDisable: true,
        selfIsAdded: true,
        showSelfDOB: true,
        dateOfBirthProposerErr: false,
        sumInsuredEmpty: true,
        spouseIsAdded: false,
        enableSpouse: false,
        enableSelf: false,
        enableChild: false,
        dateOfBirthSpouseErr: false,
        dateOfBirthSelfErr: false,
        dateOfBirthChildErr: false,
        childDOBReq: false,
        sumInsured: true,
        showSpouseDOB: false,
        ahoeSelfDOB: false,
        showChildDOB: false,
        addSpouseDisable: false,
        addChildDisable: false,
        coveredChildDetails: [],

        // Start CR_3738_B
        coveredGuardianDetails: [], 
        coveredWardDetails: [],     
        coveredBrotherDetails: [],  
        coveredSisterDetails: [],   
        coveredParentDetails: [], 
        addWardDisable: false,
        addGuardianDisable: false,
        addBrotherDisable: false,
        addSisterDisable: false,
        addParentDisable: false,
        // End CR_3738_B

        riskPremiumDetails: [],
        disableAddChildBtn: 0,
        disableAddspouseBtn: 0,
        dateOfBirthFunc: function (member, index=1) {
            enableProposerDOBCalComp = new Date(enableProposerDOBCalMin);
            if (member === "PROPOSER") {
                var dt1 = this.proposerDateOfBirth.split('/'),
                    proposerbirthDateComp = dt1[1] + '/' + dt1[0] + '/' + dt1[2], //mm/dd/yyyy
                    proposerbirthDateComp = new Date(proposerbirthDateComp);
                if (proposerbirthDateComp > enableProposerDOBCalComp) {
                    $scope.memberInfo.proposerDateOfBirth = "";
                    if($rootScope.productName === "NP")
                        CommonServices.showAlert("Age should be between 18 years to 60 Years");      // CR_3738_B
                    else
                        CommonServices.showAlert("Age should be between 18 years to 50 Years"); 
                } else {
                    $scope.memberInfo.dateOfBirthProposerErr = false;
                    var date = new Date(proposerbirthDateComp);
                    var ageDifMs = Date.now() - date.getTime();
                    var ageProposerYrs = new Date(ageDifMs); // miliseconds from epoch
                    ageProposerYrs = Math.abs(ageProposerYrs.getUTCFullYear() - 1970);
                    ageProposerYrs = ageProposerYrs.toString();
                    CommonServices.floaterObj.ageProposerYrs = ageProposerYrs;

                }
            }
            if (member === "SPOUSE") {
                var dt1 = [];
                if(this.spouseDateOfBirth !== undefined)
                    dt1 = this.spouseDateOfBirth.split('/');
                spouseDateOfBirthComp = dt1[1] + '/' + dt1[0] + '/' + dt1[2], //mm/dd/yyyy
                spouseDateOfBirthComp = new Date(spouseDateOfBirthComp);
                if (spouseDateOfBirthComp > enableProposerDOBCalComp) {
                    $scope.memberInfo.spouseDateOfBirth = "";
                    if($rootScope.productName === "NP")
                        CommonServices.showAlert("Age should be between 18 years to 60 Years");      // CR_3738_B
                    else
                        CommonServices.showAlert("Age should be between 18 years to 50 Years"); 
                } else {
                    var date = new Date(spouseDateOfBirthComp);
                    var ageDifMs = Date.now() - date.getTime();
                    var ageSpouseYrs = new Date(ageDifMs); // miliseconds from epoch
                    ageSpouseYrs = Math.abs(ageSpouseYrs.getUTCFullYear() - 1970);
                    ageSpouseYrs = ageSpouseYrs.toString();
                    CommonServices.floaterObj.ageSpouseYrs = ageSpouseYrs;
                    // this.checkAgeCondition(memberDetail.childDateOfBirth);
                }
            }

            // Start CR_3738_B
            if (member === "GUARDIAN"){
                if((this.calculateAgeInYearsFromDate(this.coveredGuardianDetails[index].dateOfBirth) < 18) || (this.calculateAgeInYearsFromDate(this.coveredGuardianDetails[index].dateOfBirth) > 60)){
                    CommonServices.showAlert(" Age should be between 18 years to 60 Years");
                    this.coveredGuardianDetails[index].dateOfBirth = "";
                }
            }
            if (member === "PARENTS"){
                if((this.calculateAgeInYearsFromDate(this.coveredParentDetails[index].dateOfBirth) < 18) || (this.calculateAgeInYearsFromDate(this.coveredParentDetails[index].dateOfBirth) > 60)){
                    CommonServices.showAlert(" Age should be between 18 years to 60 Years");
                    this.coveredParentDetails[index].dateOfBirth = "";
                }
            }
            // End 3738_B
        },

        dependentTypeChanged: function () {

            var AgeInMonths = new Date(new Date().setMonth(mynewdateFrom.getMonth() - 3));

            for (var i = 0; i < $scope.memberInfo.coveredChildDetails.length; i++) {
                var childAge = $scope.memberInfo.coveredChildDetails[i].childDateOfBirth;
                if ($scope.memberInfo.coveredChildDetails[i].childDateOfBirth !== undefined) {

                    var arr = childAge.split('/');
                    childAge = arr[1] + '/' + arr[0] + '/' + arr[2]; //mm/dd/yyyy 
                    childAge = new Date(childAge);
                }
                if ($scope.memberInfo.coveredChildDetails[i].dependentType === 'NA') {
                    childAgeEnableFrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 18));
                    $scope.childDateOfBirth = function (index) {
                        $("#idDocNoProposer" + index).loadCalendar({
                            'enableDateRange': true,
                            'enableCalendarFrom': childAgeEnableFrom,
                            'enableCalendarTo': enableProposerDOBCalfrom
                        });
                        return true;
                    };

                    if (childAge > AgeInMonths || childAge < childAgeEnableFrom) {
                        $scope.memberInfo.coveredChildDetails[i].childDateOfBirth = "";
                        CommonServices.showAlert("Age of child should be between 3 months to 18 years");
                    } else {
                        $scope.memberInfo.dateOfBirthChildErr = false;
                    }
                } else if ($scope.memberInfo.coveredChildDetails[i].dependentType === 'NORM') {
                    childAgeEnableFrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 25));

                    $scope.childDateOfBirth = function (index) {
                        $("#idDocNoProposer" + index).loadCalendar({
                            'enableDateRange': true,
                            'enableCalendarFrom': childAgeEnableFrom,
                            'enableCalendarTo': enableProposerDOBCalfrom
                        });
                        return true;
                    };

                    if (childAge > AgeInMonths || childAge < childAgeEnableFrom) {
                        $scope.memberInfo.coveredChildDetails[i].childDateOfBirth = "";
                        CommonServices.showAlert("Age of the child should be between 3 Months to 25 Years");
                    }
                } else {
                    if ($scope.memberInfo.coveredChildDetails[i].dependentType === 'MC' || $scope.memberInfo.coveredChildDetails[i].dependentType === 'UD') {

                        childAgeEnableFrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 61));
                        $scope.childDateOfBirth = function (index) {
                            $("#idDocNoProposer" + index).loadCalendar({
                                'enableDateRange': true,
                                'enableCalendarFrom': childAgeEnableFrom,
                                'enableCalendarTo': enableProposerDOBCalfrom
                            });
                            return true;
                        };

                        if (childAge > AgeInMonths || childAge < childAgeEnableFrom) {
                            $scope.memberInfo.coveredChildDetails[i].childDateOfBirth = "";
                            if($rootScope.productName === "NP")
                                CommonServices.showAlert("Age of the child should be between 3 Months to 60 Years");      // CR_3738_B
                            else
                                CommonServices.showAlert("Age of the child should be between 3 Months to 50 Years"); 
                                }
                    } else {
                        $scope.childDateOfBirth = function (index) {
                            $("#idDocNoProposer" + index).loadCalendar({
                                'enableDateRange': true,
                                'enableCalendarFrom': childAgeEnableFromDefault,
                                'enableCalendarTo': enableProposerDOBCalfrom
                            });
                            return true;
                        };
                    }

                }
            }

            CommonServices.floaterObj.coveredChildDetails = $scope.memberInfo.coveredChildDetails;
        },

        checkAgeOnly: function(age){                //for CR_3738_B
            if(age < 35)
                $scope.notYoungMembers = false;
            else if(age > 50)   
                $scope.addedSenior = true; 
        },

        verifyAgeDependentType: function(id, memberDetail, relation){             //for CR_3738_B
            let AgeInMonths = new Date(new Date().setMonth(mynewdateFrom.getMonth() - 3));
            let memberAge = memberDetail.childDateOfBirth;         
            if(memberAge != undefined){
                let arr = memberAge.split('/');
                memberAge = arr[1] + '/' + arr[0] + '/' + arr[2]; //mm/dd/yyyy 
                memberAge = new Date(memberAge);
            }

            if (memberDetail.dependentType === 'NA') {
                memberAgeEnableFrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 18));
                    $(id).loadCalendar({
                        'enableDateRange': true,
                        'enableCalendarFrom': memberAgeEnableFrom,
                        'enableCalendarTo': enableProposerDOBCalfrom
                    });
                if (memberAge > AgeInMonths || memberAge < memberAgeEnableFrom) {
                    memberDetail.childDateOfBirth = "";
                    CommonServices.showAlert("Age of " + relation + " should be between 3 months to 18 years");
                }
                // else
                //     this.checkAgeCondition(memberDetail.childDateOfBirth);    
                return memberDetail.dependentType;
            }
            else if (memberDetail.dependentType === 'NORM') {
                memberAgeEnableFrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 25));
                    $(id).loadCalendar({
                        'enableDateRange': true,
                        'enableCalendarFrom': memberAgeEnableFrom,
                        'enableCalendarTo': enableProposerDOBCalfrom
                    });
                if (memberAge > AgeInMonths || memberAge < memberAgeEnableFrom) {
                    memberDetail.childDateOfBirth = "";
                    CommonServices.showAlert("Age of " + relation + " should be between 3 months to 25 years");
                }
                // else
                //     this.checkAgeCondition(memberDetail.childDateOfBirth);
                return memberDetail.dependentType;
            }
            else if (memberDetail.dependentType === 'MC' || memberDetail.dependentType === 'UD') {
                memberAgeEnableFrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 61));
                    $(id).loadCalendar({
                        'enableDateRange': true,
                        'enableCalendarFrom': memberAgeEnableFrom,
                        'enableCalendarTo': enableProposerDOBCalfrom
                    });

                if (memberAge > AgeInMonths || memberAge < memberAgeEnableFrom) {
                    memberDetail.childDateOfBirth = "";
                    if($rootScope.productName === "NP")
                        CommonServices.showAlert("Age of the " + relation + " should be between 3 Months to 60 Years");      // CR_3738_B
                    else
                        CommonServices.showAlert("Age of the " + relation + " should be between 3 Months to 50 Years"); 
                }
                // else
                //     this.checkAgeCondition(memberDetail.childDateOfBirth);
                return memberDetail.dependentType;
            }

        },

        dependentTypeChangedNP: function(member, index) {   //for CR_3738_B

            switch(member){
                case "CHILD":
                    var id = "#idDocNoProposer" + index;
                    if(this.verifyAgeDependentType(id, this.coveredChildDetails[index], "child") != undefined);
                    return true;
                case "WARD":
                    var id = "#idDocNoProposerWard" + index;
                    if(this.verifyAgeDependentType(id, this.coveredWardDetails[index], "ward") === "UD"){
                        CommonServices.showAlert("Unmarried can be chosen only for Sister");
                        this.coveredWardDetails[index].dependentType = "";
                    }
                    return true;
                case "BROTHER":
                    var id = "#idDocNoProposerBrother" + index;
                    if(this.verifyAgeDependentType(id, this.coveredBrotherDetails[index], "brother") === "UD"){
                        CommonServices.showAlert("Unmarried can be chosen only for Sister");
                        this.coveredBrotherDetails[index].dependentType = "";
                    }
                    else if(this.verifyAgeDependentType(id, this.coveredBrotherDetails[index], "brother") === "NA"){
                        CommonServices.showAlert("Only dependent  brother can be covered in the Policy");
                        this.coveredBrotherDetails[index].dependentType = "";
                    }
                    return true;
                case "SISTER":
                    var id = "#idDocNoProposerSister" + index;
                    if(this.verifyAgeDependentType(id, this.coveredSisterDetails[index], "sister") === "NA"){
                        CommonServices.showAlert("Only dependent  sister can be covered in the Policy");
                        this.coveredSisterDetails[index].dependentType = "";
                    }
                    return true
            }
            
        },

        selectedSumInsured: function () {
            $scope.memberInfo.sumInsuredEmpty = false;
            if (CommonServices.editQuoteFlag === true) {
                for (var i = 0; i < CommonServices.floaterObj.risks.length; i++) {
                    if (CommonServices.floaterObj.risks[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "SELF") {
                        if ($scope.memberInfo.sumInsuredAmount !== undefined && $scope.memberInfo.sumInsuredAmount !== "") {
                            CommonServices.floaterObj.risks[i].riskSumInsured = $scope.memberInfo.sumInsuredAmount;
                        }

                    }
                }
            }
        },

        selectResidence: function () {
            if (CommonServices.editQuoteFlag === true) {
                for (var i = 0; i < CommonServices.floaterObj.risks.length; i++) {
                    if (CommonServices.floaterObj.risks[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "SELF") {
                        if ($scope.memberInfo.cityOfResidenceData !== undefined && $scope.memberInfo.cityOfResidenceData !== "") {
                            CommonServices.floaterObj.risks[i].riskDetails.cityOfResidence = $scope.memberInfo.cityOfResidenceData;
                        }

                    }
                }
            }
        },

        addChildFunc: function () {
            if (CommonServices.editQuoteFlag !== true) {
                $scope.memberInfo.coveredChildDetails
                    .push({
                        childDateOfBirth: '',
                        dependentType: ''
                    });

            } else {
                /**If Edit Quote Start**/
                $scope.memberInfo.coveredChildDetails
                    .push({
                        "cityOfResidence": "",
                        "thresholdLimit": "",
                        "relationWithPolicyHolder": "",
                        "childDateOfBirth": "",
                        "nameOfInsuredPerson": "",
                        "areYouEarningHeadOfFamily": "",
                        "ageInYrs": "",
                        "sex": "",
                        "ifAnyOtherOccupation": "",
                        "doYouChewTobacco": "",
                        "doYouSmoke": "",
                        "doYouDrinkAlcohol": "",
                        "adverseMedicialHistory": "",
                        "preExistingDisease": "",
                        "dependent": "",
                        "dependentType": "",
                        "startDtOfMember": "",
                        "previousPolicyDetails": {
                            "whetherYouHadAHealthPolicyInThePast": "",
                            "previousClaimOrHospitalisation": "",
                            "claimAmountReceived": ""
                        },
                        "bonusdetails": ""
                    });
                /* Start CR 0045*/
                if ($rootScope.productName === "AK") {
                    $scope.memberInfo.coveredChildDetails.sex = "F";
                }
                /* End CR 0045*/
                /**If Edit Quote End**/
            }

            $scope.memberInfo.dependentTypeChanged();

        },

        addDependentFunc: function (member) {       //CR_3738_B
            let addedData = {};
            if (CommonServices.editQuoteFlag !== true) {
                addedData = {
                                childDateOfBirth: '',
                                dependentType: ''
                            };
                if(member === "GUARDIAN" || member === "PARENTS"){
                    addedData = {
                        dateOfBirth: ''
                    }
                }

            } else {
                /**If Edit Quote Start**/
                addedData = {
                        "cityOfResidence": "",
                        "thresholdLimit": "",
                        "relationWithPolicyHolder": "",
                        "childDateOfBirth": "",
                        "nameOfInsuredPerson": "",
                        "areYouEarningHeadOfFamily": "",
                        "ageInYrs": "",
                        "sex": "",
                        "ifAnyOtherOccupation": "",
                        "doYouChewTobacco": "",
                        "doYouSmoke": "",
                        "doYouDrinkAlcohol": "",
                        "adverseMedicialHistory": "",
                        "preExistingDisease": "",
                        "dependent": "",
                        "dependentType": "",
                        "startDtOfMember": "",
                        "previousPolicyDetails": {
                            "whetherYouHadAHealthPolicyInThePast": "",
                            "previousClaimOrHospitalisation": "",
                            "claimAmountReceived": ""
                        },
                        "bonusdetails": ""
                    };
                /**If Edit Quote End**/
            }
            let len = 0;
            switch(member){
                case "CHILD":
                    this.coveredChildDetails.push(addedData);
                    len = this.coveredChildDetails.length;
                    break;
                case "WARD":
                    this.coveredWardDetails.push(addedData);
                    len = this.coveredWardDetails.length;
                    break;
                case "BROTHER":
                    this.coveredBrotherDetails.push(addedData);
                    len = this.coveredBrotherDetails.length;
                    break;
                case "SISTER":
                    this.coveredSisterDetails.push(addedData);
                    len = this.coveredSisterDetails.length;
                    break;
                case "GUARDIAN":
                    this.coveredGuardianDetails.push(addedData);
                    len = this.coveredGuardianDetails.length;
                    break;
                case "EMPLOYER":
                    this.coveredEmployerDetails.push(addedData);
                    len = this.coveredEmployerDetails.length;
                    break;
                case "PARENTS":
                    this.coveredParentDetails.push(addedData);
                    len = this.coveredParentDetails.length;
                    break;
                default:
                    CommonServices.showAlert("Member Relation Invalid");
            }
            $scope.memberInfo.dependentTypeChangedNP(member, (len-1));
        },

        disableAllBtnNP(){          //Ayush
                $scope.memberInfo.addSelfDisable = true;
                $scope.memberInfo.addSpouseDisable = true;
                $scope.memberInfo.addChildDisable = true;
                $scope.memberInfo.addWardDisable = true;
                $scope.memberInfo.addBrotherDisable = true;
                $scope.memberInfo.addSisterDisable = true;                
                $scope.memberInfo.addGuardianDisable = true;
                $scope.memberInfo.addParentDisable = true;
        },

        enableAllBtnNP(){       //Ayush
            if(this.disableCountBtn >= 6)
                this.disableAllBtnNP();
            else{
                if(!$scope.memberInfo.selfIsAdded)
                    $scope.memberInfo.addSelfDisable = false;
                if(!$scope.memberInfo.spouseIsAdded)
                    $scope.memberInfo.addSpouseDisable = false;
                if(this.disableAddChildBtn < 5)
                    $scope.memberInfo.addChildDisable = false;
                if(this.coveredWardDetails.length < 6)
                    $scope.memberInfo.addWardDisable = false;
                if(this.coveredBrotherDetails.length < 6)
                    $scope.memberInfo.addBrotherDisable = false;
                if(this.coveredSisterDetails.length < 6)
                    $scope.memberInfo.addSisterDisable = false;
                if(this.coveredGuardianDetails.length < 6)
                    $scope.memberInfo.addGuardianDisable = false;
                if(this.coveredParentDetails.length < 2)
                    $scope.memberInfo.addParentDisable = false;
            }
        },

        addMember: function (member) {
            this.disableCountBtn = this.disableCountBtn + 1;
            if (this.disableCountBtn > 6 && $rootScope.productName === "NP") {
                // $scope.memberInfo.addSelfDisable = true;
                // $scope.memberInfo.addSpouseDisable = true;
                // $scope.memberInfo.addChildDisable = true;
                this.disableAllBtnNP();

            } 
            else {
                switch(member){
                    case "SELF": 
                    {
                        if (CommonServices.floaterObj.SelfDOBPolicyHolder !== undefined || CommonServices.editQuoteFlag === true) {
                            enableProposerDOBCalComp = new Date(enableProposerDOBCalfrom);
                            var dt1;
                            if (CommonServices.floaterObj.proposerInfo !== undefined) {
                                dt1 = CommonServices.floaterObj.proposerInfo.riskDetails.dateOfBirth.split('/');
                            } else {
                                dt1 = CommonServices.floaterObj.SelfDOBPolicyHolder.split('/');
                            }
                            proposerbirthDateComp = dt1[1] + '/' + dt1[0] + '/' + dt1[2], //mm/dd/yyyy
                                proposerbirthDateComp = new Date(proposerbirthDateComp);
                            var date = new Date(proposerbirthDateComp);
                            var ageDifMs = Date.now() - date.getTime();
                            var ageProposerYrs = new Date(ageDifMs); // miliseconds from epoch
                            ageProposerYrs = Math.abs(ageProposerYrs.getUTCFullYear() - 1970);
                            ageProposerYrs = ageProposerYrs.toString();
                            if (($rootScope.productName ==="NP" && ageProposerYrs > 60) || ($rootScope.productName !=="NP" && ageProposerYrs > 50)) {
                                this.disableCountBtn = this.disableCountBtn - 1;
                                CommonServices.showAlert("Proposer/self 's age(as per policy holder's date of birth) should be between 18-60 years to add into policy online. Please contact nearest NIA branch to add member to the policy.");
                                return;
                            }
                            else {
                                $scope.enableProposerDOB = true;
                                CommonServices.showAlert("Proposer/Self DoB is being captured from Policy holder details, if you want to make any change please contact NIA .");
                                if (CommonServices.editQuoteFlag === true) {
                                    $scope.memberInfo.proposerDateOfBirth = CommonServices.floaterObj.proposerInfo.riskDetails.dateOfBirth;
                                } else {
                                    $scope.memberInfo.proposerDateOfBirth = CommonServices.floaterObj.SelfDOBPolicyHolder;
                                }
                            }
                        } else {
                            $scope.enableProposerDOB = false;
                            $scope.memberInfo.proposerDateOfBirth = "";
                        }
                        CommonServices.floaterObj.memberCoveredInPolicy = 'Y';
                        $scope.memberInfo.selfIsAdded = true;
                        $scope.memberInfo.showSelfDOB = true;
                        $scope.memberInfo.addSelfDisable = true;
                        //CR747
                        if (this.disableCountBtn === 6 && $rootScope.productName === "NP") {
                            this.disableAllBtnNP();
                        }

                    }
                    break;
                    case "SPOUSE": 
                    {
                        $scope.memberInfo.spouseIsAdded = true;
                        this.disableAddspouseBtn = this.disableAddspouseBtn + 1;
                        $scope.memberInfo.showSpouseDOB = true;
                        $scope.memberInfo.addSpouseDisable = true;
                        $scope.memberInfo.spouseDateOfBirth = "";
                        //CR747
                        if (this.disableCountBtn === 6 && $rootScope.productName === "NP") {
                            this.disableAllBtnNP();
                        }
                    } 
                    break;
                    case "CHILD": 
                    {
                        $scope.memberInfo.childDOBReq = true;
                        $scope.memberInfo.showChildDOB = true;
                        this.disableAddChildBtn = this.disableAddChildBtn + 1;
                        if ($rootScope.productName === "NP") {
                            //CR747 start
                            if (this.disableAddChildBtn == 5) {
                                this.addDependentFunc("CHILD");
                                $scope.memberInfo.addChildDisable = true;
                                if (this.disableCountBtn === 6) {
                                    this.disableAllBtnNP();
                                }
                            } 
                            else if (this.disableCountBtn === 6) 
                            {
                                this.disableAllBtnNP();
                                if (this.disableAddChildBtn == 5) {
                                    $scope.memberInfo.addChildDisable = true;
                                } 
                                else {
                                    this.addDependentFunc("CHILD");
                                    $scope.memberInfo.addChildDisable = true;
                                }
                            } 
                            else {
                                this.addDependentFunc("CHILD");
                            }
                            //CR747 end

                        }
                    /* Start CR 0045*/
                        if ($rootScope.productName === "AK") {
                            if ($scope.memberInfo.coveredChildDetails.length === 2) {
                                $scope.memberInfo.addChildDisable = true;
                                return false;
                            } else if ($scope.memberInfo.coveredChildDetails.length === 1) {
                                this.addChildFunc();
                                $scope.memberInfo.addChildDisable = true;
                            } else {
                                this.addChildFunc();
                            }
                        }
                        /* End CR 0045*/
                    }
                    break;

                    // Start CR_3738_B
                    case "WARD":
                    {
                        if($rootScope.productName === "NP"){
                            this.addDependentFunc("WARD");
                            if(this.coveredWardDetails.length == 6)
                                this.addWardDisable = true;
                        }
                    }
                    break;
                    case "BROTHER": 
                    {
                        if($rootScope.productName === "NP"){
                            this.addDependentFunc("BROTHER");
                            if(this.coveredBrotherDetails.length == 6)
                                this.addBrotherDisable = true;
                        }
                    }
                    break;
                    case "SISTER": 
                    {   
                        if($rootScope.productName === "NP"){
                            this.addDependentFunc("SISTER");
                            if(this.coveredSisterDetails.length == 6)
                                this.addSisterDisable = true;
                        }

                    }
                    break;
                    case "GUARDIAN": 
                    {
                        if($rootScope.productName === "NP"){
                            this.addDependentFunc("GUARDIAN");
                            if(this.coveredGuardianDetails.length == 6)
                                this.addGuardianDisable = true;
                        }
                    }
                    break;
                    case "PARENTS": 
                    {
                        if($rootScope.productName === "NP"){
                            this.addDependentFunc("PARENTS");
                            if(this.coveredParentDetails.length > 1)
                                this.addParentDisable = true;
                        }

                    }
                    break;
                    default:
                        CommonServices.showAlert("This member cannot be added");
                }
                if (this.disableCountBtn === 6 && $rootScope.productName === "NP") {
                    this.disableAllBtnNP();
                }

                //End 3738_B
            }
        },

        closeMember: function (member, index, count) {
            this.disableCountBtn = this.disableCountBtn - 1;
            if ($scope.numberOfmembers > 6) {
                $scope.memberInfo.addSelfDisable = true;
                $scope.memberInfo.addSpouseDisable = true;
                $scope.memberInfo.addChildDisable = true;
            } else {

                switch(member){
                    case 'SELF': 
                    {
                        // $scope.memberInfo.addSelfDisable = false;
                        $scope.memberInfo.selfIsAdded = false;
                        $scope.memberInfo.showSelfDOB = false;
                        $scope.memberInfo.proposerDateOfBirth = "";
                        $scope.memberInfo.dateOfBirthelfErr = false;
                        $scope.memberInfo.enableSelf = false;
                        CommonServices.floaterObj.memberCoveredInPolicy = 'N';
                        //CR747  starts
                        if ($rootScope.productName === "NP") {
                            // if (this.disableCountBtn < 6) {
                            //     $scope.memberInfo.addChildDisable = false;
                            // }
                            // if (this.disableAddChildBtn === 5 && this.disableCountBtn === 5) {
                            //     $scope.memberInfo.addSpouseDisable = false;
                            // }
                            this.enableAllBtnNP();
                        }
                        //CR747  ends
                    }
                    break;
                    case 'SPOUSE': 
                    {
                        this.disableAddspouseBtn = this.disableAddspouseBtn - 1;
                        $scope.memberInfo.spouseIsAdded = false;
                        $scope.memberInfo.showSpouseDOB = false;
                        $scope.memberInfo.spouseDateOfBirth = "";
                        $scope.memberInfo.dateOfBirthSpouseErr = false;
                        $scope.memberInfo.enableSpouse = false;
                        // $scope.memberInfo.addSpouseDisable = false;
                        if ($rootScope.productName === "NP") {
                            // if (this.disableCountBtn < 6) {
                            //     $scope.memberInfo.addChildDisable = false;
                            // }
                            // if (this.disableAddChildBtn === 5 && this.disableCountBtn === 5) {
                            //     $scope.memberInfo.addSelfDisable = false;
                            // }
                            this.enableAllBtnNP();
                        }

                    } 
                    break;
                    case 'CHILD': 
                    {
                        if ($rootScope.productName !== "AK") { //CR 0045
                            $scope.memberInfo.coveredChildDetails[count].dependentType = "";
                        }
                        // $scope.memberInfo.dependentTypeChanged();
                        //CR747 STARTS
                        // if (this.disableAddChildBtn <= 5 && $rootScope.productName === "NP") {
                        //     $scope.memberInfo.addChildDisable = false;
                        // }
                        if ($rootScope.productName === "AK") {//CR 0045
                            $scope.memberInfo.dependentTypeChanged();
                            $scope.memberInfo.addChildDisable = false;
                        }
                        //CR747 ENDS
                        $scope.memberInfo.showChildDOB = false;
                        $scope.memberInfo.childDateOfBirth = "";
                        $scope.memberInfo.dateOfBirthChildErr = false;
                        $scope.memberInfo.enableChild = false;
                        this.disableAddChildBtn = this.disableAddChildBtn - 1;
                        this.coveredChildDetails.splice(this.coveredChildDetails.indexOf(index), 1);
                        if ($rootScope.productName === "NP") {
                            // if (this.disableAddChildBtn < 5 && this.disableCountBtn === 5) {
                            //     if ($scope.memberInfo.spouseIsAdded === false) {
                            //         $scope.memberInfo.addSpouseDisable = false;
                            //     }
                            //     if ($scope.memberInfo.selfIsAdded === false) {
                            //         $scope.memberInfo.addSelfDisable = false;
                            //     }
                            // }
                            this.enableAllBtnNP();
                        }
                    }
                    break;

                    // Start cr_3738_B
                    case 'WARD':
                    {
                        this.coveredWardDetails.splice(this.coveredWardDetails.indexOf(index), 1);
                        this.enableAllBtnNP();
                    }
                    break;
                    case 'BROTHER':
                    {
                        this.coveredBrotherDetails.splice(this.coveredBrotherDetails.indexOf(index), 1);
                        this.enableAllBtnNP();
                    }
                    break;
                    case 'SISTER':
                    {
                        this.coveredSisterDetails.splice(this.coveredSisterDetails.indexOf(index), 1);
                        this.enableAllBtnNP();
                    }
                    break;
                    case 'GUARDIAN':
                    {
                        this.coveredGuardianDetails.splice(this.coveredGuardianDetails.indexOf(index), 1);
                        this.enableAllBtnNP();
                    }
                    break;
                    case "PARENTS":
                    {
                        this.coveredParentDetails.splice(this.coveredParentDetails.indexOf(index), 1);
                        this.enableAllBtnNP();                        
                    }
                    break;
                    default:
                        CommonServices.showAlert("Already Deleted");
                }

                // End CR_3738_B
            }
        },

        calculateAgeInYearsFromDate: function(dob){             //CR_3738_B
            // var Arr = dob.split('/');
            // dob = Arr[2] + '/' + Arr[1] + '/' + Arr[0]; //mm/dd/yyyy
            // var date = new Date(dob);
            // var ageDifMs = Date.now() - date.getTime() - 86400000;
            // var ageDinYrs = new Date(ageDifMs); // miliseconds from epoch
            // ageDinYrs = Math.abs(ageDinYrs.getUTCFullYear() - 1970);
            // return ageDinYrs.toString();
            
            if(!dob){
                return;
            }
            var today = new Date();
            var ageArr = dob.split('/');
            ageCal = ageArr[2] + '/' + ageArr[1] + '/' + ageArr[0]; //mm/dd/yyyy
            var birthDate = new Date(ageCal);
            var age = today.getFullYear() - birthDate.getFullYear();
            var m = today.getMonth() - birthDate.getMonth();
            if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
                age--;
            }
            return age.toString();
        },

        addMemberToSavedArray: function(memberDetail, relation){        //CR_3738_B
            var dob = memberDetail.dateOfBirth;
            let ageDinYrs = this.calculateAgeInYearsFromDate(dob);
            this.checkAgeOnly(ageDinYrs);
            if (CommonServices.editQuoteFlag !== true) {
                $scope.childRiskDetails = {
                    "riskSumInsured": "",
                    "riskDetails": {
                        "thresholdLimit": null,
                        "cityOfResidence": $scope.memberInfo.cityOfResidenceData !== "" && $scope.memberInfo.cityOfResidenceData !== undefined ? $scope.memberInfo.cityOfResidenceData : "NA",
                        "relationWithPolicyHolder": relation,
                        "dateOfBirth": dob,
                        "ageInYrs": ageDinYrs,
                    }
                };
            } else {
                $scope.childRiskDetails = {
                    "riskSumInsured": "",
                    "riskDetails": {
                        "cityOfResidence": $scope.memberInfo.cityOfResidenceData !== "" && $scope.memberInfo.cityOfResidenceData !== undefined ? $scope.memberInfo.cityOfResidenceData : "NA",
                        "thresholdLimit": null,
                        "relationWithPolicyHolder": relation,
                        "dateOfBirth": dob,
                        "nameOfInsuredPerson": memberDetail.nameOfInsuredPerson !== "" && memberDetail.nameOfInsuredPerson !== undefined ? memberDetail.nameOfInsuredPerson : "",
                        "areYouEarningHeadOfFamily": "N",
                        "ageInYrs": ageDinYrs,
                        "sex": memberDetail.sex !== "" && memberDetail.sex !== undefined ? memberDetail.sex:"",
                        "ifAnyOtherOccupation": memberDetail.ifAnyOtherOccupation !== "" &&memberDetail.ifAnyOtherOccupation !== undefined ? memberDetail.ifAnyOtherOccupation : "",
                        "doYouChewTobacco": memberDetail.doYouChewTobacco !== undefined && memberDetail.doYouChewTobacco !== "" ? memberDetail.doYouChewTobacco : "N",
                        "doYouSmoke": memberDetail.doYouSmoke !== undefined && memberDetail.doYouSmoke !== "" ? memberDetail.doYouSmoke : "N",
                        "doYouDrinkAlcohol": memberDetail.doYouDrinkAlcohol !== undefined && memberDetail.doYouDrinkAlcohol !== "" ?memberDetail.doYouDrinkAlcohol : "N",
                        "adverseMedicialHistory": memberDetail.adverseMedicialHistory !== undefined && memberDetail.adverseMedicialHistory !== "" ?memberDetail.adverseMedicialHistory : "N",
                        "preExistingDisease": memberDetail.preExistingDisease !== undefined && memberDetail.preExistingDisease !== "" ? memberDetail.preExistingDisease : "null",
                        "dependent": memberDetail.dependentType === "NA" ? "N" : "Y",
                        "dependentType": memberDetail.dependentType,
                        "startDtOfMember": memberDetail.startDtOfMember !== undefined && memberDetail.startDtOfMember !== "" ? memberDetail.startDtOfMember : "null",
                        "occupation": memberDetail.occupation,
                        "previousPolicyDetails": {
                            "whetherYouHadAHealthPolicyInThePast": memberDetail.previousPolicyDetails.whetherYouHadAHealthPolicyInThePast !== undefined && memberDetail.previousPolicyDetails.whetherYouHadAHealthPolicyInThePast !== "" ? memberDetail.previousPolicyDetails.whetherYouHadAHealthPolicyInThePast : "N",
                            "previousClaimOrHospitalisation": memberDetail.previousPolicyDetails.previousClaimOrHospitalisation !== undefined && memberDetail.previousPolicyDetails.previousClaimOrHospitalisation !== "" ? memberDetail.previousPolicyDetails.previousClaimOrHospitalisation : "null",
                            "claimAmountReceived": memberDetail.previousPolicyDetails.claimAmountReceived !== undefined && memberDetail.previousPolicyDetails.claimAmountReceived !== "" ? memberDetail.previousPolicyDetails.claimAmountReceived : "null"
                        },
                        "bonusdetails": null,
                        "cataractLimit": memberDetail.cataractLimit != undefined? memberDetail.cataractLimit : "N",
                        "maternityExpense": memberDetail.maternityExpense != undefined ? memberDetail.maternityExpense : "N"
                    }
                };
                {           // Block to be executed only when product is NP w.r.t. current conditions
                    $scope.childRiskDetails.riskDetails.previousPolicyDetails.company =memberDetail.previousPolicyDetails.company;
                    $scope.childRiskDetails.riskDetails.previousPolicyDetails.currentPolicyNumber = memberDetail.previousPolicyDetails.currentPolicyNumber;
                    $scope.childRiskDetails.riskDetails.previousPolicyDetails.expiryDate = memberDetail.previousPolicyDetails.expiryDate;
                    $scope.childRiskDetails.riskDetails.previousPolicyDetails.sumInsured = memberDetail.previousPolicyDetails.sumInsured;
                    $scope.childRiskDetails.riskDetails.previousPolicyDetails.inceptionDate = memberDetail.previousPolicyDetails.inceptionDate;
                }

            }
            $scope.riskDetailsEditQuote.push($scope.childRiskDetails);
            this.riskPremiumDetails.push($scope.childRiskDetails);
        },

        addDependentMemberToSavedArray: function(memberDetail, relation){       //for CR_3738_B
            var dob = memberDetail.childDateOfBirth;
            let ageDinYrs = this.calculateAgeInYearsFromDate(dob);
            this.checkAgeOnly(ageDinYrs);
            if (CommonServices.editQuoteFlag !== true) {
                $scope.childRiskDetails = {
                    "riskSumInsured": "",
                    "riskDetails": {
                        "thresholdLimit": null,
                        "cityOfResidence": $scope.memberInfo.cityOfResidenceData !== "" && $scope.memberInfo.cityOfResidenceData !== undefined ? $scope.memberInfo.cityOfResidenceData : "NA",
                        "relationWithPolicyHolder": relation,
                        "dateOfBirth": dob,
                        "ageInYrs": ageDinYrs,
                        "dependent": memberDetail.dependentType === "NA" ? "N" : "Y",
                        "dependentType": memberDetail.dependentType
                    }
                };
            } else {
                $scope.childRiskDetails = {
                    "riskSumInsured": "",
                    "riskDetails": {
                        "cityOfResidence": $scope.memberInfo.cityOfResidenceData !== "" && $scope.memberInfo.cityOfResidenceData !== undefined ? $scope.memberInfo.cityOfResidenceData : "NA",
                        "thresholdLimit": null,
                        "relationWithPolicyHolder": relation,
                        "dateOfBirth": dob,
                        "nameOfInsuredPerson": memberDetail.nameOfInsuredPerson !== "" && memberDetail.nameOfInsuredPerson !== undefined ? memberDetail.nameOfInsuredPerson : "",
                        "areYouEarningHeadOfFamily": "N",
                        "ageInYrs": ageDinYrs,
                        "sex": memberDetail.sex !== "" && memberDetail.sex !== undefined ? memberDetail.sex:"",
                        "ifAnyOtherOccupation": memberDetail.ifAnyOtherOccupation !== "" &&memberDetail.ifAnyOtherOccupation !== undefined ? memberDetail.ifAnyOtherOccupation : "",
                        "doYouChewTobacco": memberDetail.doYouChewTobacco !== undefined && memberDetail.doYouChewTobacco !== "" ? memberDetail.doYouChewTobacco : "N",
                        "doYouSmoke": memberDetail.doYouSmoke !== undefined && memberDetail.doYouSmoke !== "" ? memberDetail.doYouSmoke : "N",
                        "doYouDrinkAlcohol": memberDetail.doYouDrinkAlcohol !== undefined && memberDetail.doYouDrinkAlcohol !== "" ?memberDetail.doYouDrinkAlcohol : "N",
                        "adverseMedicialHistory": memberDetail.adverseMedicialHistory !== undefined && memberDetail.adverseMedicialHistory !== "" ?memberDetail.adverseMedicialHistory : "N",
                        "preExistingDisease": memberDetail.preExistingDisease !== undefined && memberDetail.preExistingDisease !== "" ? memberDetail.preExistingDisease : "null",
                        "dependent": memberDetail.dependentType === "NA" ? "N" : "Y",
                        "dependentType": memberDetail.dependentType,
                        "startDtOfMember": memberDetail.startDtOfMember !== undefined && memberDetail.startDtOfMember !== "" ? memberDetail.startDtOfMember : "null",
                        "occupation": memberDetail.occupation,
                        "previousPolicyDetails": {
                            "whetherYouHadAHealthPolicyInThePast": memberDetail.previousPolicyDetails.whetherYouHadAHealthPolicyInThePast !== undefined && memberDetail.previousPolicyDetails.whetherYouHadAHealthPolicyInThePast !== "" ? memberDetail.previousPolicyDetails.whetherYouHadAHealthPolicyInThePast : "N",
                            "previousClaimOrHospitalisation": memberDetail.previousPolicyDetails.previousClaimOrHospitalisation !== undefined && memberDetail.previousPolicyDetails.previousClaimOrHospitalisation !== "" ? memberDetail.previousPolicyDetails.previousClaimOrHospitalisation : "null",
                            "claimAmountReceived": memberDetail.previousPolicyDetails.claimAmountReceived !== undefined && memberDetail.previousPolicyDetails.claimAmountReceived !== "" ? memberDetail.previousPolicyDetails.claimAmountReceived : "null"
                        },
                        "bonusdetails": null,
                        "cataractLimit": memberDetail.cataractLimit != undefined? memberDetail.cataractLimit : "N",
                        "maternityExpense": memberDetail.maternityExpense != undefined ? memberDetail.maternityExpense : "N"
                    }
                };
                {           // Block to be executed only when product is NP w.r.t. current conditions
                    $scope.childRiskDetails.riskDetails.previousPolicyDetails.company =memberDetail.previousPolicyDetails.company;
                    $scope.childRiskDetails.riskDetails.previousPolicyDetails.currentPolicyNumber = memberDetail.previousPolicyDetails.currentPolicyNumber;
                    $scope.childRiskDetails.riskDetails.previousPolicyDetails.expiryDate = memberDetail.previousPolicyDetails.expiryDate;
                    $scope.childRiskDetails.riskDetails.previousPolicyDetails.sumInsured = memberDetail.previousPolicyDetails.sumInsured;
                    $scope.childRiskDetails.riskDetails.previousPolicyDetails.inceptionDate = memberDetail.previousPolicyDetails.inceptionDate;
                }

            }
            $scope.riskDetailsEditQuote.push($scope.childRiskDetails);
            this.riskPremiumDetails.push($scope.childRiskDetails);
        },

        calcPremium: function () {
            $scope.addedSenior = false;
            $scope.notYoungMembers = true;
            if ((this.disableAddspouseBtn === 0 && this.selfIsAdded === false) && $rootScope.productName === "AK") {//CR 0045
                CommonServices.showAlert("Either self or spouse should be covered in the policy");
            }
            else {
                $scope.riskDetailsEditQuote = [];
                if ($scope.memberInfo.selfIsAdded === true) {
                    $scope.memberCoveredInPolicy = 'Y';
                } else {
                    $scope.memberCoveredInPolicy = 'N';
                }
                CommonServices.floaterObj.memberCoveredInPolicy = $scope.memberCoveredInPolicy;
                CommonServices.floaterObj.reviewSummary = false;
                this.riskPremiumDetails = [];
                if (CommonServices.editQuoteFlag !== true) {
                    CommonServices.floaterObj.addedMemberDetails = [];
                }

                if ($scope.memberInfo.coveredChildDetails != "undefined") {
                    CommonServices.floaterObj.coveredChildDetails = $scope.memberInfo.coveredChildDetails;
                } else {
                    CommonServices.floaterObj.coveredChildDetails = 0;
                }
                /****************** START CR #3738B ******************/
                if($rootScope.productName==="NP")
                {
                    if($scope.memberInfo.coveredWardDetails != undefined && $scope.memberInfo.coveredWardDetails.length != 0){
                        CommonServices.floaterObj.coveredWardDetails = $scope.memberInfo.coveredWardDetails;
                    }
                    if($scope.memberInfo.coveredBrotherDetails != undefined && $scope.memberInfo.coveredBrotherDetails.length != 0){
                        CommonServices.floaterObj.coveredBrotherDetails = $scope.memberInfo.coveredBrotherDetails;
                    }
                    if($scope.memberInfo.coveredSisterDetails != undefined && $scope.memberInfo.coveredSisterDetails.length != 0){
                        CommonServices.floaterObj.coveredSisterDetails = $scope.memberInfo.coveredSisterDetails;
                    }
                    if($scope.memberInfo.coveredGuardianDetails != undefined && $scope.memberInfo.coveredGuardianDetails.length != 0){
                        CommonServices.floaterObj.coveredGuardianDetails = $scope.memberInfo.coveredGuardianDetails;
                    }
                    if($scope.memberInfo.coveredParentDetails != undefined && $scope.memberInfo.coveredParentDetails.length != 0){
                        CommonServices.floaterObj.coveredParentDetails = $scope.memberInfo.coveredParentDetails;
                    }
                }
                /*********************END CR #3738_B *****************/

                CommonServices.floaterObj.countOfChild = this.disableAddChildBtn;
                CommonServices.floaterObj.countOfSpouse = this.disableAddspouseBtn;
                if (CommonServices.editQuoteFlag !== true) {
                    CommonServices.floaterObj.ageProposerYrs = this.calculateAgeInYearsFromDate($scope.memberInfo.proposerDateOfBirth);
                    this.checkAgeOnly(CommonServices.floaterObj.ageProposerYrs);
                    $scope.proposerRiskDetails = {
                        "riskSumInsured": $scope.memberInfo.sumInsuredAmount,
                        "riskDetails": {
                            "thresholdLimit": null,
                            "cityOfResidence": $scope.memberInfo.cityOfResidenceData !== "" && $scope.memberInfo.cityOfResidenceData !== undefined ? $scope.memberInfo.cityOfResidenceData : "NA",
                            "relationWithPolicyHolder": "SELF",
                            "dateOfBirth": $scope.memberInfo.proposerDateOfBirth,
                            "ageInYrs": CommonServices.floaterObj.ageProposerYrs
                        }
                    };
                    CommonServices.floaterObj.ageSpouseYrs = this.calculateAgeInYearsFromDate($scope.memberInfo.spouseDateOfBirth);
                    this.checkAgeOnly(CommonServices.floaterObj.ageSpouseYrs);
                    $scope.spouseRiskDetails = {
                        "riskSumInsured": "",
                        "riskDetails": {
                            "thresholdLimit": null,
                            "cityOfResidence": $scope.memberInfo.cityOfResidenceData !== "" && $scope.memberInfo.cityOfResidenceData !== undefined ? $scope.memberInfo.cityOfResidenceData : "NA",
                            "relationWithPolicyHolder": $rootScope.productName === "NP" ? "SPOUSE" : "Spouse",
                            "dateOfBirth": $scope.memberInfo.spouseDateOfBirth,
                            "ageInYrs": CommonServices.floaterObj.ageSpouseYrs
                        },
                    };
                } else {
                    for (var i = 0; i < CommonServices.floaterObj.risks.length; i++) {
                        if (CommonServices.floaterObj.memberCoveredInPolicy === 'N' && CommonServices.floaterObj.risks[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "SELF") {
                            CommonServices.floaterObj.policyHolderDetails = {
                                "relationWithPolicyHolder": "SELF",
                                "occupation": CommonServices.floaterObj.risks[i].riskDetails.occupation,
                                "ifAnyOtherOccupation": CommonServices.floaterObj.risks[i].riskDetails.ifAnyOtherOccupation !== "" && CommonServices.floaterObj.risks[i].riskDetails.ifAnyOtherOccupation !== undefined ? CommonServices.floaterObj.risks[i].riskDetails.ifAnyOtherOccupation : "",
                                "sex": CommonServices.floaterObj.risks[i].riskDetails.sex,
                                "nameOfInsuredPerson": CommonServices.floaterObj.risks[i].riskDetails.nameOfInsuredPerson,
                                "dateOfBirth": CommonServices.floaterObj.proposerInfo.riskDetails.dateOfBirth,
                                "ageInYrs": CommonServices.floaterObj.ageProposerYrs,
                                "cityOfResidence": $scope.memberInfo.cityOfResidenceData !== "" && $scope.memberInfo.cityOfResidenceData !== undefined ? $scope.memberInfo.cityOfResidenceData : "NA",
                                "riskParty": CommonServices.floaterObj.risks[i].riskParty,
                                "riskSumInsured": $scope.memberInfo.sumInsuredAmount,
                                "startDtOfMember": null,
                                "doYouChewTobacco": CommonServices.floaterObj.risks[i].riskDetails.doYouChewTobacco,
                                "doYouSmoke ": CommonServices.floaterObj.risks[i].riskDetails.doYouSmoke,
                                "doYouDrinkAlcohol": CommonServices.floaterObj.risks[i].riskDetails.doYouDrinkAlcohol,
                                "adverseMedicialHistory": CommonServices.floaterObj.risks[i].riskDetails.adverseMedicialHistory,
                                "dependent": CommonServices.floaterObj.risks[i].riskDetails.dependent,
                                "dependentType": "NORM",
                                "thresholdLimit": null,
                                "cataractLimit": CommonServices.floaterObj.risks[i].riskDetails.cataractLimit != undefined? CommonServices.floaterObj.risks[i].riskDetails.cataractLimit : "N",
                                "maternityExpense": CommonServices.floaterObj.risks[i].riskDetails.maternityExpense != undefined ? CommonServices.floaterObj.risks[i].riskDetails.maternityExpense : "N",
                                "previousPolicyDetails": {
                                    "whetherYouHadAHealthPolicyInThePast": CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails !== undefined ? CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails.whetherYouHadAHealthPolicyInThePast : 'N',
                                    "previousClaimOrHospitalisation": null,
                                    "claimAmountReceived": null
                                }

                            }
                            if ($rootScope.productName === "NP") {
                                CommonServices.floaterObj.policyHolderDetails.previousPolicyDetails.company = CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails !== undefined ? CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails.company : undefined;
                                CommonServices.floaterObj.policyHolderDetails.previousPolicyDetails.currentPolicyNumber = CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails !== undefined ? CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails.currentPolicyNumber : undefined;
                                CommonServices.floaterObj.policyHolderDetails.previousPolicyDetails.expiryDate = CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails !== undefined ? CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails.expiryDate : undefined;
                                CommonServices.floaterObj.policyHolderDetails.previousPolicyDetails.inceptionDate = CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails !== undefined ? CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails.inceptionDate : undefined;
                                CommonServices.floaterObj.policyHolderDetails.previousPolicyDetails.sumInsured = CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails !== undefined ? CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails.sumInsured : undefined;
                            }

                        }
                        else {
                            if (CommonServices.floaterObj.risks[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "SELF") {
                                $scope.proposerRiskDetails = {
                                    "riskParty": CommonServices.floaterObj.risks[i].riskParty !== undefined ? CommonServices.floaterObj.risks[i].riskParty : CommonServices.floaterObj.policyHolderDetails.riskParty,
                                    "riskSumInsured": $scope.memberInfo.sumInsuredAmount,
                                    "riskDetails": {
                                        "relationWithPolicyHolder": "SELF",
                                        "ifAnyOtherOccupation": CommonServices.floaterObj.risks[i].riskDetails.ifAnyOtherOccupation !== "" && CommonServices.floaterObj.risks[i].riskDetails.ifAnyOtherOccupation !== undefined ? CommonServices.floaterObj.risks[i].riskDetails.ifAnyOtherOccupation : CommonServices.floaterObj.policyHolderDetails !== undefined ? CommonServices.floaterObj.policyHolderDetails.ifAnyOtherOccupation : "",
                                        "occupation": CommonServices.floaterObj.risks[i].riskDetails.occupation !== undefined ? CommonServices.floaterObj.risks[i].riskDetails.occupation : (CommonServices.floaterObj.policyHolderDetails!= undefined)? CommonServices.floaterObj.policyHolderDetails.occupation : "",
                                        "thresholdLimit": null,
                                        "dateOfBirth": $scope.memberInfo.proposerDateOfBirth,
                                        "nameOfInsuredPerson": CommonServices.floaterObj.risks[i].riskDetails.nameOfInsuredPerson !== undefined ? CommonServices.floaterObj.risks[i].riskDetails.nameOfInsuredPerson : CommonServices.floaterObj.policyHolderDetails.nameOfInsuredPerson,
                                        "ageInYrs": CommonServices.floaterObj.ageProposerYrs !== undefined ? CommonServices.floaterObj.ageProposerYrs : CommonServices.floaterObj.policyHolderDetails.ageInYrs,
                                        "sex": CommonServices.floaterObj.risks[i].riskDetails.sex !== undefined ? CommonServices.floaterObj.risks[i].riskDetails.sex : (CommonServices.floaterObj.policyHolderDetails !== undefined) ?CommonServices.floaterObj.policyHolderDetails.sex : "",
                                        "doYouChewTobacco": CommonServices.floaterObj.risks[i].riskDetails.doYouChewTobacco !== undefined ? CommonServices.floaterObj.risks[i].riskDetails.doYouChewTobacco : CommonServices.floaterObj.policyHolderDetails !== undefined ? CommonServices.floaterObj.policyHolderDetails.doYouChewTobacco : "N",
                                        "doYouSmoke": CommonServices.floaterObj.risks[i].riskDetails.doYouSmoke !== undefined ? CommonServices.floaterObj.risks[i].riskDetails.doYouSmoke : CommonServices.floaterObj.policyHolderDetails !== undefined ? CommonServices.floaterObj.policyHolderDetails.doYouSmoke : "N",
                                        "doYouDrinkAlcohol": CommonServices.floaterObj.risks[i].riskDetails.doYouDrinkAlcohol !== undefined ? CommonServices.floaterObj.risks[i].riskDetails.doYouDrinkAlcohol : CommonServices.floaterObj.policyHolderDetails !== undefined ? CommonServices.floaterObj.policyHolderDetails.doYouDrinkAlcohol : "N",
                                        "adverseMedicialHistory": CommonServices.editQuoteFlag === true ?"N":CommonServices.floaterObj.risks[i].riskDetails.adverseMedicialHistory !== undefined ? CommonServices.floaterObj.risks[i].riskDetails.adverseMedicialHistory : CommonServices.floaterObj.policyHolderDetails.adverseMedicialHistory,//CR_0054
                                        "preExistingDisease": CommonServices.floaterObj.risks[i].riskDetails.preExistingDisease !== undefined ? CommonServices.floaterObj.risks[i].riskDetails.preExistingDisease : "null",
                                        "dependent": CommonServices.floaterObj.risks[i].riskDetails.dependent !== undefined ? CommonServices.floaterObj.risks[i].riskDetails.dependent : (CommonServices.floaterObj.policyHolderDetails !== undefined)? CommonServices.floaterObj.policyHolderDetails.dependent: "",
                                        "cityOfResidence": $scope.memberInfo.cityOfResidenceData !== "" && $scope.memberInfo.cityOfResidenceData !== undefined ? $scope.memberInfo.cityOfResidenceData : "NA",
                                        "cataractLimit": CommonServices.floaterObj.risks[i].riskDetails.cataractLimit != undefined? CommonServices.floaterObj.risks[i].riskDetails.cataractLimit : "N",
                                        "maternityExpense": CommonServices.floaterObj.risks[i].riskDetails.maternityExpense != undefined ? CommonServices.floaterObj.risks[i].riskDetails.maternityExpense : "N",
                                        "previousPolicyDetails": {
                                            "whetherYouHadAHealthPolicyInThePast": CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails !== undefined ? CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails.whetherYouHadAHealthPolicyInThePast : (CommonServices.floaterObj.policyHolderDetails !== undefined) ? CommonServices.floaterObj.policyHolderDetails.previousPolicyDetails.whetherYouHadAHealthPolicyInThePast: "",
                                            "inceptionDate": CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails !== undefined ? CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails.inceptionDate : (CommonServices.floaterObj.policyHolderDetails !== undefined) ?CommonServices.floaterObj.policyHolderDetails.previousPolicyDetails.inceptionDate:""
                                        }
                                    }

                                };
                                if ($rootScope.productName === "NP") {
                                    $scope.proposerRiskDetails.riskDetails.previousPolicyDetails.company = CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails !== undefined ? CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails.company : CommonServices.floaterObj.policyHolderDetails.previousPolicyDetails.company;
                                    $scope.proposerRiskDetails.riskDetails.previousPolicyDetails.currentPolicyNumber = CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails !== undefined ? CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails.currentPolicyNumber : CommonServices.floaterObj.policyHolderDetails.previousPolicyDetails.currentPolicyNumber;
                                    $scope.proposerRiskDetails.riskDetails.previousPolicyDetails.expiryDate = CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails !== undefined ? CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails.expiryDate : CommonServices.floaterObj.policyHolderDetails.previousPolicyDetails.expiryDate;
                                    $scope.proposerRiskDetails.riskDetails.previousPolicyDetails.inceptionDate = CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails !== undefined ? CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails.inceptionDate : undefined;
                                    $scope.proposerRiskDetails.riskDetails.previousPolicyDetails.sumInsured = CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails !== undefined ? CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails.sumInsured : CommonServices.floaterObj.policyHolderDetails.previousPolicyDetails.sumInsured;
                                }


                                $scope.riskDetailsEditQuote.push($scope.proposerRiskDetails);
                            } else if (CommonServices.floaterObj.risks[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "SPOUSE") {
                                $scope.spouseRiskDetails = {
                                    "riskSumInsured": "",
                                    "riskDetails": {
                                        "thresholdLimit": null,
                                        "relationWithPolicyHolder": $rootScope.productName === "NP" ? "SPOUSE" : "Spouse",
                                        "ifAnyOtherOccupation": CommonServices.floaterObj.risks[i].riskDetails.ifAnyOtherOccupation !== "" && CommonServices.floaterObj.risks[i].riskDetails.ifAnyOtherOccupation !== undefined ? CommonServices.floaterObj.risks[i].riskDetails.ifAnyOtherOccupation : "",
                                        "occupation":CommonServices.floaterObj.risks[i].riskDetails.occupation !== undefined &&  CommonServices.floaterObj.risks[i].riskDetails.occupation !== ""? CommonServices.floaterObj.risks[i].riskDetails.occupation : "",
                                        "dateOfBirth": $scope.memberInfo.spouseDateOfBirth,
                                        "nameOfInsuredPerson": CommonServices.floaterObj.risks[i].riskDetails.nameOfInsuredPerson !== "" && CommonServices.floaterObj.risks[i].riskDetails.nameOfInsuredPerson !== undefined ? CommonServices.floaterObj.risks[i].riskDetails.nameOfInsuredPerson : "",
                                        "ageInYrs": CommonServices.floaterObj.risks[i].riskDetails.ageInYrs !== "" && CommonServices.floaterObj.risks[i].riskDetails.ageInYrs !== undefined ? CommonServices.floaterObj.risks[i].riskDetails.ageInYrs : CommonServices.floaterObj.ageSpouseYrs,
                                        "sex": CommonServices.floaterObj.risks[i].riskDetails.sex !== "" && CommonServices.floaterObj.risks[i].riskDetails.sex !== undefined ? CommonServices.floaterObj.risks[i].riskDetails.sex : "",
                                        "doYouChewTobacco": CommonServices.floaterObj.risks[i].riskDetails.doYouChewTobacco !== "" && CommonServices.floaterObj.risks[i].riskDetails.doYouChewTobacco !== undefined ? CommonServices.floaterObj.risks[i].riskDetails.doYouChewTobacco : "N",
                                        "doYouSmoke": CommonServices.floaterObj.risks[i].riskDetails.doYouSmoke !== "" && CommonServices.floaterObj.risks[i].riskDetails.doYouSmoke !== undefined ? CommonServices.floaterObj.risks[i].riskDetails.doYouSmoke : "N",
                                        "doYouDrinkAlcohol": CommonServices.floaterObj.risks[i].riskDetails.doYouDrinkAlcohol !== "" && CommonServices.floaterObj.risks[i].riskDetails.doYouDrinkAlcohol !== undefined ? CommonServices.floaterObj.risks[i].riskDetails.doYouDrinkAlcohol : "N",
                                        "adverseMedicialHistory": CommonServices.floaterObj.risks[i].riskDetails.adverseMedicialHistory !== "" && CommonServices.floaterObj.risks[i].riskDetails.adverseMedicialHistory !== undefined ? CommonServices.floaterObj.risks[i].riskDetails.adverseMedicialHistory : "N",
                                        "preExistingDisease": CommonServices.floaterObj.risks[i].riskDetails.preExistingDisease !== "" && CommonServices.floaterObj.risks[i].riskDetails.preExistingDisease !== undefined ? CommonServices.floaterObj.risks[i].riskDetails.preExistingDisease : null,
                                        "dependent": CommonServices.floaterObj.risks[i].riskDetails.dependent !== "" && CommonServices.floaterObj.risks[i].riskDetails.dependent !== undefined ? CommonServices.floaterObj.risks[i].riskDetails.dependent : "NORM",
                                        "cityOfResidence": $scope.memberInfo.cityOfResidenceData !== "" && $scope.memberInfo.cityOfResidenceData !== undefined ? $scope.memberInfo.cityOfResidenceData : "NA",
                                        "cataractLimit": CommonServices.floaterObj.risks[i].riskDetails.cataractLimit != undefined? CommonServices.floaterObj.risks[i].riskDetails.cataractLimit : "N",
                                        "maternityExpense": CommonServices.floaterObj.risks[i].riskDetails.maternityExpense != undefined ? CommonServices.floaterObj.risks[i].riskDetails.maternityExpense : "N",
                                        "previousPolicyDetails": {
                                            "whetherYouHadAHealthPolicyInThePast": CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails.whetherYouHadAHealthPolicyInThePast !== "" && CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails.whetherYouHadAHealthPolicyInThePast !== undefined ? CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails.whetherYouHadAHealthPolicyInThePast : "N",
                                            "inceptionDate": CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails.inceptionDate !== "" && CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails.inceptionDate !== undefined ? CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails.inceptionDate : ""
                                        }
                                        

                                    }
                                };
                                if ($rootScope.productName === "NP") {
                                    $scope.spouseRiskDetails.riskDetails.previousPolicyDetails.company = CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails.company;
                                    $scope.spouseRiskDetails.riskDetails.previousPolicyDetails.currentPolicyNumber = CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails.currentPolicyNumber;
                                    $scope.spouseRiskDetails.riskDetails.previousPolicyDetails.expiryDate = CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails.expiryDate;
                                    $scope.spouseRiskDetails.riskDetails.previousPolicyDetails.inceptionDate = CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails.inceptionDate;
                                    $scope.spouseRiskDetails.riskDetails.previousPolicyDetails.sumInsured = CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails.sumInsured;
                                }
                                // }
                                $scope.riskDetailsEditQuote.push($scope.spouseRiskDetails);
                            }

                        }
                    }
                }

                var numberOfmembers = 1;
                CommonServices.floaterObj.addSelfDisable = $scope.memberInfo.addSelfDisable;
                CommonServices.floaterObj.selfIsAdded = $scope.memberInfo.selfIsAdded;
                CommonServices.floaterObj.addSpouseDisable = $scope.memberInfo.addSpouseDisable;
                CommonServices.floaterObj.spouseIsAdded = $scope.memberInfo.spouseIsAdded;
                if ($scope.memberInfo.selfIsAdded === true) {

                    this.riskPremiumDetails.push($scope.proposerRiskDetails);
                }
                if ($scope.memberInfo.spouseIsAdded === true) {

                    if (CommonServices.editQuoteFlag === true) {
                        if ($scope.spouseRiskDetails === undefined) {
                            let spouseRiskDetails = {}
                            if($rootScope.productName==="NP")
                                spouseRiskDetails = {
                                    "riskSumInsured": "",
                                    "riskDetails": {
                                        "thresholdLimit": null,
                                        "relationWithPolicyHolder": $rootScope.productName === "NP" ? "SPOUSE" : "Spouse",
                                        "ifAnyOtherOccupation": null,
                                        "occupation": "",
                                        "dateOfBirth": $scope.memberInfo.spouseDateOfBirth,
                                        "nameOfInsuredPerson": "",
                                        "ageInYrs": CommonServices.floaterObj.ageSpouseYrs,
                                        "doYouChewTobacco": "N",
                                        "doYouSmoke": "N",
                                        "doYouDrinkAlcohol": "N",
                                        "adverseMedicialHistory": "N",
                                        "preExistingDisease": null,
                                        "dependent": "NORM",
                                        "cityOfResidence": "NA",
                                        "cataractLimit": "N",
                                        "maternityExpense": "N",
                                        "previousPolicyDetails": {
                                            "whetherYouHadAHealthPolicyInThePast": "N",
                                            "inceptionDate": null
                                        }
                                    }
                                };
                                else
                                spouseRiskDetails = {
                                    "riskSumInsured": "",
                                    "riskDetails": {
                                        "thresholdLimit": null,
                                        "relationWithPolicyHolder": $rootScope.productName === "NP" ? "SPOUSE" : "Spouse",
                                        "ifAnyOtherOccupation": null,
                                        "occupation": "",
                                        "dateOfBirth": $scope.memberInfo.spouseDateOfBirth,
                                        "nameOfInsuredPerson": "",
                                        "ageInYrs": CommonServices.floaterObj.ageSpouseYrs,
                                        "doYouChewTobacco": "N",
                                        "doYouSmoke": "N",
                                        "doYouDrinkAlcohol": "N",
                                        "adverseMedicialHistory": "N",
                                        "preExistingDisease": null,
                                        "dependent": "NORM",
                                        "cityOfResidence": "NA",
                                        "previousPolicyDetails": {
                                            "whetherYouHadAHealthPolicyInThePast": "N",
                                            "inceptionDate": null
                                        }
                                    }
                                };
                            $scope.riskDetailsEditQuote.push($scope.spouseRiskDetails);
                        }

                    }
                    this.riskPremiumDetails.push($scope.spouseRiskDetails);

                }

                CommonServices.floaterObj.numberOfMembers = this.disableCountBtn;//memberCount

                $scope.riskPlusProposerDeatils = [];
                for (var i = 0; i < $scope.memberInfo.coveredChildDetails.length; i++) {

                    var ageDinYrs = this.calculateAgeInYearsFromDate($scope.memberInfo.coveredChildDetails[i].childDateOfBirth);
                    if (CommonServices.editQuoteFlag !== true) {
                        $scope.childRiskDetails = {
                            "riskSumInsured": "",
                            "riskDetails": {
                                "thresholdLimit": null,
                                "cityOfResidence": $scope.memberInfo.cityOfResidenceData !== "" && $scope.memberInfo.cityOfResidenceData !== undefined ? $scope.memberInfo.cityOfResidenceData : "NA",
                                "relationWithPolicyHolder": $rootScope.productName === "AK" ? "Daughter" : "CHILD",
                                "dateOfBirth": $scope.memberInfo.coveredChildDetails[i].childDateOfBirth,
                                "ageInYrs": ageDinYrs,
                                "dependent": $scope.memberInfo.coveredChildDetails[i].dependentType === "NA" ? "N" : "Y",
                                "dependentType": $scope.memberInfo.coveredChildDetails[i].dependentType
                            }
                        };
                    } else {
                        $scope.childRiskDetails = {
                            "riskSumInsured": "",
                            "riskDetails": {
                                "cityOfResidence": $scope.memberInfo.cityOfResidenceData !== "" && $scope.memberInfo.cityOfResidenceData !== undefined ? $scope.memberInfo.cityOfResidenceData : "NA",
                                "thresholdLimit": null,
                                "relationWithPolicyHolder": $rootScope.productName === "AK" ? "Daughter" : "CHILD",
                                "dateOfBirth": $scope.memberInfo.coveredChildDetails[i].childDateOfBirth,
                                "nameOfInsuredPerson": $scope.memberInfo.coveredChildDetails[i].nameOfInsuredPerson !== "" && $scope.memberInfo.coveredChildDetails[i].nameOfInsuredPerson !== undefined ? $scope.memberInfo.coveredChildDetails[i].nameOfInsuredPerson : "",
                                "areYouEarningHeadOfFamily": "N",
                                "ageInYrs": ageDinYrs,
                                "sex": "F",
                                "ifAnyOtherOccupation": $scope.memberInfo.coveredChildDetails[i].ifAnyOtherOccupation !== "" && $scope.memberInfo.coveredChildDetails[i].ifAnyOtherOccupation !== undefined ? $scope.memberInfo.coveredChildDetails[i].ifAnyOtherOccupation : "",
                                "doYouChewTobacco": $scope.memberInfo.coveredChildDetails[i].doYouChewTobacco !== undefined && $scope.memberInfo.coveredChildDetails[i].doYouChewTobacco !== "" ? $scope.memberInfo.coveredChildDetails[i].doYouChewTobacco : "N",
                                "doYouSmoke": $scope.memberInfo.coveredChildDetails[i].doYouSmoke !== undefined && $scope.memberInfo.coveredChildDetails[i].doYouSmoke !== "" ? $scope.memberInfo.coveredChildDetails[i].doYouSmoke : "N",
                                "doYouDrinkAlcohol": $scope.memberInfo.coveredChildDetails[i].doYouDrinkAlcohol !== undefined && $scope.memberInfo.coveredChildDetails[i].doYouDrinkAlcohol !== "" ? $scope.memberInfo.coveredChildDetails[i].doYouDrinkAlcohol : "N",
                                "adverseMedicialHistory": $scope.memberInfo.coveredChildDetails[i].adverseMedicialHistory !== undefined && $scope.memberInfo.coveredChildDetails[i].adverseMedicialHistory !== "" ? $scope.memberInfo.coveredChildDetails[i].adverseMedicialHistory : "N",
                                "preExistingDisease": $scope.memberInfo.coveredChildDetails[i].preExistingDisease !== undefined && $scope.memberInfo.coveredChildDetails[i].preExistingDisease !== "" ? $scope.memberInfo.coveredChildDetails[i].preExistingDisease : "null",
                                "dependent": $scope.memberInfo.coveredChildDetails[i].dependentType === "NA" ? "N" : "Y",
                                "dependentType": $scope.memberInfo.coveredChildDetails[i].dependentType,
                                "startDtOfMember": $scope.memberInfo.coveredChildDetails[i].startDtOfMember !== undefined && $scope.memberInfo.coveredChildDetails[i].startDtOfMember !== "" ? $scope.memberInfo.coveredChildDetails[i].startDtOfMember : "null",
                                "occupation": $scope.memberInfo.coveredChildDetails[i].occupation,
                                "previousPolicyDetails": {
                                    "whetherYouHadAHealthPolicyInThePast": $scope.memberInfo.coveredChildDetails[i].previousPolicyDetails.whetherYouHadAHealthPolicyInThePast !== undefined && $scope.memberInfo.coveredChildDetails[i].previousPolicyDetails.whetherYouHadAHealthPolicyInThePast !== "" ? $scope.memberInfo.coveredChildDetails[i].previousPolicyDetails.whetherYouHadAHealthPolicyInThePast : "N",
                                    "previousClaimOrHospitalisation": $scope.memberInfo.coveredChildDetails[i].previousPolicyDetails.previousClaimOrHospitalisation !== undefined && $scope.memberInfo.coveredChildDetails[i].previousPolicyDetails.previousClaimOrHospitalisation !== "" ? $scope.memberInfo.coveredChildDetails[i].previousPolicyDetails.previousClaimOrHospitalisation : "null",
                                    "claimAmountReceived": $scope.memberInfo.coveredChildDetails[i].previousPolicyDetails.claimAmountReceived !== undefined && $scope.memberInfo.coveredChildDetails[i].previousPolicyDetails.claimAmountReceived !== "" ? $scope.memberInfo.coveredChildDetails[i].previousPolicyDetails.claimAmountReceived : "null"
                                },
                                "cataractLimit": CommonServices.floaterObj.risks[i].riskDetails.cataractLimit != undefined? CommonServices.floaterObj.risks[i].riskDetails.cataractLimit : "N",
                                "maternityExpense": CommonServices.floaterObj.risks[i].riskDetails.maternityExpense != undefined ? CommonServices.floaterObj.risks[i].riskDetails.maternityExpense : "N",
                                "bonusdetails": null
                            }
                        };
                        if ($rootScope.productName === "NP") {
                            $scope.childRiskDetails.riskDetails.previousPolicyDetails.company = $scope.memberInfo.coveredChildDetails[i].previousPolicyDetails.company;
                            $scope.childRiskDetails.riskDetails.previousPolicyDetails.currentPolicyNumber = $scope.memberInfo.coveredChildDetails[i].previousPolicyDetails.currentPolicyNumber;
                            $scope.childRiskDetails.riskDetails.previousPolicyDetails.expiryDate = $scope.memberInfo.coveredChildDetails[i].previousPolicyDetails.expiryDate;
                            $scope.childRiskDetails.riskDetails.previousPolicyDetails.sumInsured = $scope.memberInfo.coveredChildDetails[i].previousPolicyDetails.sumInsured;
                            $scope.childRiskDetails.riskDetails.previousPolicyDetails.inceptionDate = $scope.memberInfo.coveredChildDetails[i].previousPolicyDetails.inceptionDate;
                        }

                    }
                    if($rootScope.productName === "NP")
                        this.checkAgeOnly(ageDinYrs);
                    $scope.riskDetailsEditQuote.push($scope.childRiskDetails);
                    this.riskPremiumDetails.push($scope.childRiskDetails);
                }

                //Start for CR_3738_B
                if ($rootScope.productName === "NP") {
                    for (var i = 0; i < $scope.memberInfo.coveredWardDetails.length; i++) {    
                        this.addDependentMemberToSavedArray($scope.memberInfo.coveredWardDetails[i], "Ward");
                    }
                    for(var i = 0; i < $scope.memberInfo.coveredBrotherDetails.length; i++){
                        this.addDependentMemberToSavedArray($scope.memberInfo.coveredBrotherDetails[i], "Brother");
                    }
                    for(var i = 0; i < $scope.memberInfo.coveredSisterDetails.length; i++){
                        this.addDependentMemberToSavedArray($scope.memberInfo.coveredSisterDetails[i], "Sister");
                    }
                    for(var i = 0; i < $scope.memberInfo.coveredGuardianDetails.length; i++){
                        this.addMemberToSavedArray($scope.memberInfo.coveredGuardianDetails[i], "Guardian");
                    }
                    for(var i = 0; i < $scope.memberInfo.coveredParentDetails.length; i++){
                        this.addMemberToSavedArray($scope.memberInfo.coveredParentDetails[i], "PARENTS");
                    }
                
                    if($scope.addedSenior){
                        if($scope.notYoungMembers || this.riskPremiumDetails.length < 3){
                            CommonServices.showAlert('<p>For age more than 50 years the following conditions needs to be satisfied in order to continue: - </p>\
                            <ol><li>1. A minimum of 3 persons should be covered in the policy.</li>\
                            <li>2. At least one of the members age should be less than 35 Years.</li></ol>');
                            return;
                        }
                    }
                }
                //End CR_3738_B

                if (this.selfIsAdded === false) {

                    $scope.riskPlusProposerDeatils.push({
                        "riskDetails": {
                            "relationWithPolicyHolder": "SELF",
                            "riskSumInsured": $scope.memberInfo.sumInsuredAmount,
                            "cityOfResidence": $scope.memberInfo.cityOfResidenceData,
                            "occupation": CommonServices.editQuoteFlag === true ? CommonServices.floaterObj.policyHolderDetails.occupation : undefined,
                            "ifAnyOtherOccupation": CommonServices.editQuoteFlag === true ? CommonServices.floaterObj.policyHolderDetails.ifAnyOtherOccupation : undefined
                        }
                    });
                    if (CommonServices.editQuoteFlag === true && CommonServices.floaterObj.policyHolderDetails !== undefined) {
                        $scope.riskPlusProposerDeatils[0].riskDetails = CommonServices.floaterObj.policyHolderDetails;
                    }

                    for (var i = 0; i < this.riskPremiumDetails.length; i++) {
                        $scope.riskPlusProposerDeatils.push(this.riskPremiumDetails[i]);
                    }

                    CommonServices.floaterObj.addedMemberDetails = $scope.riskPlusProposerDeatils;
                } else {
                    CommonServices.floaterObj.addedMemberDetails = this.riskPremiumDetails;
                }
                if (CommonServices.floaterObj.serviceCall === "saveQuote" || CommonServices.editQuoteFlag === true) {

                    if (CommonServices.editQuoteFlag === true) { //If coming from Edit Quote
                        if (CommonServices.floaterObj.selectedAgentDetails !== undefined && CommonServices.floaterObj.selectedAgentDetails !== "") {
                            CommonServices.floaterObj.selectedAgentDetails = [
                                {
                                    "partyCode": CommonServices.floaterObj.selectedAgentDetails.partyCode,
                                    "partyStakeCode": CommonServices.floaterObj.selectedAgentDetails.partyStakeCode,
                                    "partyName": CommonServices.floaterObj.selectedAgentDetails.partyName,
                                    "address": CommonServices.floaterObj.selectedAgentDetails.address
                                }
                            ];
                        }

                        if(CommonServices.floaterObj.selectedTPA != undefined){

                            let selectedTpa = CommonServices.floaterObj.partyDetailsList.filter(item=> item.partyCode===CommonServices.floaterObj.selectedTPA && item.partyStakeCode=='TPA')[0];
                            if(selectedTpa)
                            CommonServices.floaterObj.tpaDetails = {
                                tpaCode: selectedTpa.partyCode,
                                tpaName: selectedTpa.partyName,
                                address: selectedTpa.address
                            }
                        }

                        
                        if($rootScope.productName === "NP"){

                            let partyDetails = [];
                            if( CommonServices.getCommonData("stakeCode") === 'DEVLP-OFF' && CommonServices.floaterObj.selectedAgentDetails)
                                partyDetails.push(CommonServices.floaterObj.selectedAgentDetails[0]);  
                            if(CommonServices.floaterObj.selectedTPA != undefined){

                                partyDetails.push({
                                    "partyCode": CommonServices.floaterObj.tpaDetails.tpaCode,
                                    "partyStakeCode":"TPA",
                                    "partyName": CommonServices.floaterObj.tpaDetails.tpaName
                                });
                            }

                            var healthSaveQuoteInput = {
                                "quote": {
                                    "quoteNumber": CommonServices.floaterObj.quoteNumber,
                                    "productCode": $rootScope.productName,
                                    "policyHolderCode": CommonServices.floaterObj.policyHolderCode,
                                    "isTPARequired": CommonServices.floaterObj.isTPARequired,
                                    "policyBranchCode": CommonServices.floaterObj.policyBranchCode,
                                    "policyHolderName": CommonServices.floaterObj.policyHolderName,
                                    "memberCoveredInPolicy": CommonServices.floaterObj.memberCoveredInPolicy === 'Y' ? "YES" : "NO",
                                    "roomRentRider": "N",
                                    "policyStartDate": CommonServices.floaterObj.policyStartDate,
                                    "policyExpiryDate": CommonServices.floaterObj.policyExpiryDate,
                                    "mobileNo": null,
                                    "emailId": null,
                                    "progressLevel": null,
                                    "typeOfCover": null,
                                    "preMedicalCheckUpDetails": null,
                                    "physicianDetails": {
                                        "physicianName": null,
                                        "physicianAddress": null
                                    },
                                    "nomineeDetails": {
                                        "name": CommonServices.floaterObj.nomineeDetails.name.toUpperCase(),
                                        "relationshipWithInsured": CommonServices.floaterObj.nomineeDetails.relationshipWithInsured
                                    },
                                    "risks": $scope.riskDetailsEditQuote,
                                    "optionalCoverINoProportionateDeduction": CommonServices.floaterObj.noProportionateDeduction != undefined? CommonServices.floaterObj.noProportionateDeduction: "N",
                                    "partyDetailsList": partyDetails
                                },
                                "userProfile": {
                                    "userId": CommonServices.getCommonData("userId"),
                                    "loggedInRole": "SUPERUSER"
                                }
                            };
                        }
                        else{
                            var healthSaveQuoteInput = {
                                "quote": {
                                    "quoteNumber": CommonServices.floaterObj.quoteNumber,
                                    "productCode": $rootScope.productName,
                                    "policyHolderCode": CommonServices.floaterObj.policyHolderCode,
                                    "isTPARequired": CommonServices.floaterObj.isTPARequired,
                                    "policyBranchCode": CommonServices.floaterObj.policyBranchCode,
                                    "policyHolderName": CommonServices.floaterObj.policyHolderName,
                                    "memberCoveredInPolicy": CommonServices.floaterObj.memberCoveredInPolicy === 'Y' ? "YES" : "NO",
                                    "roomRentRider": "N",
                                    "policyStartDate": CommonServices.floaterObj.policyStartDate,
                                    "policyExpiryDate": CommonServices.floaterObj.policyExpiryDate,
                                    "mobileNo": null,
                                    "emailId": null,
                                    "progressLevel": null,
                                    "typeOfCover": null,
                                    "preMedicalCheckUpDetails": null,
                                    "physicianDetails": {
                                        "physicianName": null,
                                        "physicianAddress": null
                                    },
                                    "nomineeDetails": {
                                        "name": CommonServices.floaterObj.nomineeDetails.name.toUpperCase(),
                                        "relationshipWithInsured": CommonServices.floaterObj.nomineeDetails.relationshipWithInsured
                                    },
                                    "risks": $scope.riskDetailsEditQuote,
                                    "partyDetailsList": CommonServices.getCommonData("stakeCode") === 'DEVLP-OFF' ? CommonServices.floaterObj.selectedAgentDetails : undefined
                                },
                                "userProfile": {
                                    "userId": CommonServices.getCommonData("userId"),
                                    "loggedInRole": "SUPERUSER"
                                }
                            };
                        }

                        if (CommonServices.floaterObj.memberCoveredInPolicy === 'N') {
                            healthSaveQuoteInput.quote.policyHolderDetails = CommonServices.floaterObj.policyHolderDetails;
                        }
                        var healthSaveQuoteResponse = RestServices.postService(RestServices.urlPathsNewPortal.topUpSaveQuote, healthSaveQuoteInput);
                        healthSaveQuoteResponse.then(
                            function (response) { // success	
                                CommonServices.showLoading(false);
                                if (response.data.hasOwnProperty('errorMessage')) {
                                    CommonServices.showAlert(response.data.errorMessage);
                                } else {
                                    CommonServices.floaterObj.saveQuoteResponse = response.data.quote;
                                    CommonServices.floaterObj.risks = CommonServices.floaterObj.addedMemberDetails;
                                    if (CommonServices.editQuoteFlag === true) {
                                        CommonServices.floaterObj.premiumDetails = response.data.quote.premiumDetails;
                                        for (var i = 0; i < response.data.quote.risks.length; i++) {
                                            if (response.data.quote.policyHolderDetails !== undefined && i === 0) {
                                                CommonServices.floaterObj.premiumDetails.sumInsured = response.data.quote.policyHolderDetails.riskSumInsured;
                                            }
                                            else if (response.data.quote.risks[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "SELF") {
                                                CommonServices.floaterObj.premiumDetails.sumInsured = response.data.quote.risks[i].riskSumInsured;
                                            }
                                        }

                                    }
                                    $state.go("floaterBasicPremium");
                                }

                            },
                            function (error) { // failure
                                CommonServices.showLoading(false);
                                RestServices.handleWebServiceError(error);
                            }
                        );
                    } else { // If coming from Save Quote
                        CommonServices.floaterObj.serviceCall = "calcPremium";
                        CommonServices.floaterObj.backSaveQuote = "premiumCalc";
                        $rootScope.dataforSaveQuote();
                    }

                } else {
                    CommonServices.floaterObj.addChildDisable = $scope.memberInfo.addChildDisable;
                    this.premiumServicecall();
                }
            }
        },

        premiumServicecall: function () {
            CommonServices.floaterObj.policyHolderSelf = {
                "ageInYrs": "33",
                "cityOfResidence": $rootScope.productName === "AK" ? $scope.memberInfo.cityOfResidenceData : "NA",
                "dateOfBirth": "01/01/1985",
                "riskSumInsured": $scope.memberInfo.sumInsuredAmount
            };
            if (CommonServices.editQuoteFlag === true) {
                $state.go("floaterBasicPremium");
            } else {
                var floaterCalPremiumInput = {
                    "quote": {
                        "risks": this.riskPremiumDetails,
                        "productCode": $rootScope.productName,
                        "policyStartDate": policyStartDate,
                        "policyExpiryDate": policyEndDate,
                        "mobileNo": null,
                        "emailId": null,
                        "progressLevel": null,
                        "memberCoveredInPolicy": $scope.memberCoveredInPolicy,
                        "typeOfCover": $scope.basciDetailsRadio
                    },
                    "userProfile": {
                        "userId": CommonServices.getCommonData("userId"),
                        "loggedInRole": "SUPERUSER"
                    }

                };
                if ($scope.memberCoveredInPolicy === 'N') {
                    floaterCalPremiumInput.quote.policyHolderDetails = CommonServices.floaterObj.policyHolderSelf;
                }
            }
            var topUpPremiumCalResponse = RestServices.postService(RestServices.urlPathsNewPortal.topUpCalcPremium, floaterCalPremiumInput);
            topUpPremiumCalResponse.then(
                function (response) { // success 

                    CommonServices.showLoading(false);

                    if (response.data !== undefined && response.data !== "") {
                        if (response.data.hasOwnProperty('errorMessage')) {
                            CommonServices.showAlert(response.data.errorMessage);
                        } else {
                            CommonServices.floaterObj.quoteNumber = response.data.quote.quoteNumber;
                            CommonServices.floaterObj.premiumDetails = response.data.quote.premiumDetails;
                            CommonServices.floaterObj.premiumDetails.sumInsured = $scope.memberInfo.sumInsuredAmount;
                            $state.go("floaterBasicPremium");
                        }
                    } else {
                        CommonServices.showAlert("Please try after some time");
                    }

                },
                function (error) { // failure
                    CommonServices.showLoading(false);
                    RestServices.handleWebServiceError(error);
                });
        }

    };


    //Basic Details Start
    var cityOfResidenceData = [{
        "id": "MUM",
        "name": "Zone I-Greater Mumbai & Gujarat"
    }, {
        "id": "DAB",
        "name": "Zone II-Delhi NCR, Bangalore, Pune, Kolkata, Hyderabad & Secunderabad, Chennai"
    }, {
        "id": "ROI",
        "name": "Zone III-Rest of India"
    }];
    $scope.sumInsuredData = [{
        "name": "200000",
        "value": "200000"
    }, {
        "name": "300000",
        "value": "300000"
    }, {
        "name": "500000",
        "value": "500000"
    }, {
        "name": "800000",
        "value": "800000"
    }];

    if ($rootScope.productName === "NP") {
        $scope.sumInsuredData.push({
            "name": "1000000",
            "value": "1000000"
        }, {
                "name": "1200000",
                "value": "1200000"
            }, {
                "name": "1500000",
                "value": "1500000"
            });
    }
    //CR 0045 STARTS
    if ($rootScope.productName === "AK") {
        $scope.memberInfo.childDOBReq = true;
        $scope.cityOfResidenceData = cityOfResidenceData;
        $scope.memberInfo.coveredChildDetails
            .push({
                childDateOfBirth: '',
                dependentType: ''
            });
        $scope.memberInfo.disableCountBtn = 2;
    } else {
        $scope.memberInfo.disableCountBtn = 1;
    }
    //Basic Details End
    //Focus Label Start		 
    $scope.foucs = function ($event) {
        $($event.target).parent().addClass('focusLabel');
    };
    //Focus Label End
    //Back click on screen start
    $scope.goBack = function () {
        $rootScope.backFlag = "";
        $state.go("newIndiaFloaterMediclaim");
    };

    var mydateStr = new Date();
    var mynewdateFrom = "";
    if (mydateStr != undefined) {
        mynewdateFrom = new Date(mydateStr);
    } else {
        mynewdateFrom = new Date();
    }

    var enableProposerDOBCalfrom = getFormattedDate(mynewdateFrom);

    /**Proposer Date of Birth**/
    if($rootScope.productName==="NP")
        var enableProposerDOBCalTo = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 61));
    else    
        var enableProposerDOBCalTo = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 51));


    var enableProposerDOBCalMin = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 18));
    enableProposerDOBCalMin = new Date(enableProposerDOBCalMin.setDate(enableProposerDOBCalMin.getDate()));
    enableProposerDOBCalMin = getFormattedDate(enableProposerDOBCalMin);

    //3 months
    var childAgeEnableFromDefault = enableProposerDOBCalTo;

    //25 years
    var enableChildDOBDOBCalTo = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 25));
    enableChildDOBDOBCalTo = new Date(enableChildDOBDOBCalTo.setDate(enableChildDOBDOBCalTo.getDate()));
    enableChildDOBDOBCalTo = getFormattedDate(enableChildDOBDOBCalTo);



    /**Proposer DOB**/
    $('#proposerDateOfBirth').loadCalendar({
        'enableDateRange': true,
        'enableCalendarFrom': enableProposerDOBCalTo,
        'enableCalendarTo': enableProposerDOBCalfrom
    });
    /**Spouse DOB**/
    $('#spouseDateOfBirth').loadCalendar({
        'enableDateRange': true,
        'enableCalendarFrom': enableProposerDOBCalTo,
        'enableCalendarTo': enableProposerDOBCalfrom
    });
    $scope.childDateOfBirth = function (index) {
        $("#idDocNoProposer" + index).loadCalendar({
            'enableDateRange': true,
            'enableCalendarFrom': enableProposerDOBCalTo,
            'enableCalendarTo': enableProposerDOBCalfrom
        });
        return true;
    };

    /*Start CR_3738_B*///Ayush
    /*Brother DOB */
    $scope.brotherDateOfBirth = function(index){
		$("#idDocNoProposerBrother"+index).loadCalendar({
			 'enableDateRange': true,
			 'enableCalendarFrom': enableProposerDOBCalTo,
			 'enableCalendarTo': enableProposerDOBCalfrom
		 });
		 return true;
    }; 
    /**Sister DOB */
    $scope.sisterDateOfBirth = function(index){
    $("#idDocNoProposerSister"+index).loadCalendar({
            'enableDateRange': true,
            'enableCalendarFrom': enableProposerDOBCalTo,
            'enableCalendarTo': enableProposerDOBCalfrom
        });
        return true;
    };
    /**Guardian DOB */
    $scope.guardianDateOfBirth = function(index){
    $("#idDocNoProposerGuardian"+index).loadCalendar({
            'enableDateRange': true,
            'enableCalendarFrom': enableProposerDOBCalTo,
            'enableCalendarTo': enableProposerDOBCalfrom
        });
        return true;
    };

    /**Parent DOB */
    $scope.parentDateOfBirth = function(index){
    $("#idDocNoProposerParent"+index).loadCalendar({
            'enableDateRange': true,
            'enableCalendarFrom': enableProposerDOBCalTo,
            'enableCalendarTo': enableProposerDOBCalfrom
        });
        return true;
    };

    /*Added CR_3738_B*///Ayush


    /**Ward DOB**///sourav CR_3725
	$scope.wardDateOfBirth = function(index){
		$("#idDocNoProposerWard"+index).loadCalendar({
			 'enableDateRange': true,
			 'enableCalendarFrom': enableProposerDOBCalTo,
			 'enableCalendarTo': enableProposerDOBCalfrom
		 });
		 return true;
	  };
    /**********Policy Start Date and End Date Validations*********/
    var policyStartDate = enableProposerDOBCalfrom;
    var arr = policyStartDate.split('/');
    policyStartDate = arr[1] + '/' + arr[0] + '/' + arr[2]; //dd/mm/yyyy

    CommonServices.floaterObj.policyStartDate = policyStartDate;


    var policyEndDate = new Date(mydateStr);
    policyEndDate.setFullYear(policyEndDate.getFullYear() + 1);
    policyEndDate.setDate(policyEndDate.getDate() - 1);
    var dd = policyEndDate.getDate();
    var mm = policyEndDate.getMonth() + 1;
    var yyyy = policyEndDate.getFullYear();

    if (dd < 10) {
        dd = "0" + dd;
    }

    if (mm < 10) {
        mm = "0" + mm;
    }
    policyEndDate = dd + "/" + mm + "/" + yyyy; //policy end date
    CommonServices.floaterObj.policyExpiryDate = policyEndDate;
    /**On click of calendar Start**/
    $scope.calIconClick = function (event) {
        angular.element("#" + event.currentTarget.children[0].id).focus();
    };
    /**On click of calendar End**/
    //validation for dob

    //restore data
    if ($rootScope.backFlag === "premCal") {
        $scope.memberInfo.proposerDateOfBirth = CommonServices.floaterObj.SelfDOBPolicyHolder;
        $scope.memberInfo.addSelfDisable = CommonServices.floaterObj.addSelfDisable;
        $scope.memberInfo.addSpouseDisable = CommonServices.floaterObj.addSpouseDisable;
        $scope.memberInfo.addChildDisable = CommonServices.floaterObj.addChildDisable;
        $scope.memberInfo.coveredChildDetails = CommonServices.floaterObj.coveredChildDetails;

        /**********************************       Start CR_3738_B       ***************************/
        $scope.memberInfo.coveredWardDetails = CommonServices.floaterObj.coveredWardDetails != undefined? CommonServices.floaterObj.coveredWardDetails: [];
        $scope.memberInfo.coveredBrotherDetails = CommonServices.floaterObj.coveredBrotherDetails!= undefined? CommonServices.floaterObj.coveredBrotherDetails: [];
        $scope.memberInfo.coveredSisterDetails = CommonServices.floaterObj.coveredSisterDetails!= undefined? CommonServices.floaterObj.coveredSisterDetails: [];
        $scope.memberInfo.coveredGuardianDetails = CommonServices.floaterObj.coveredGuardianDetails!= undefined? CommonServices.floaterObj.coveredGuardianDetails: [];
        $scope.memberInfo.coveredParentDetails = CommonServices.floaterObj.coveredParentDetails!= undefined? CommonServices.floaterObj.coveredParentDetails: [];
        $scope.memberInfo.addParentDisable = $scope.memberInfo.coveredParentDetails.length>1?true:false;
        /**********************************        End CR_3738_B       ***************************/

        $scope.memberInfo.disableAddChildBtn = CommonServices.floaterObj.countOfChild;
        $scope.memberInfo.disableAddspouseBtn = CommonServices.floaterObj.countOfSpouse;
        $scope.memberInfo.spouseIsAdded = CommonServices.floaterObj.spouseIsAdded;
        $scope.memberInfo.selfIsAdded = CommonServices.floaterObj.selfIsAdded;
        $scope.memberInfo.sumInsuredEmpty = false;
        $scope.memberInfo.toupTermsAndCondition = true;
        $scope.memberInfo.disableCountBtn = CommonServices.floaterObj.numberOfMembers;
        $scope.sumInsured = CommonServices.floaterObj.premiumDetails.sumInsured;
        if ($scope.memberInfo.selfIsAdded === true) {
            $scope.enableProposerDOB = true;
            $scope.memberInfo.showSelfDOB = true;
        } else {
            $scope.enableProposerDOB = false;
            $scope.memberInfo.showSelfDOB = false;
        }
        //$scope.cityResidence = CommonServices.floaterObj.cityOfResidenceData;
        for (i = 0; i < CommonServices.floaterObj.addedMemberDetails.length; i++) {

            if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "SELF") {
                if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.dateOfBirth !== undefined) {
                    $scope.memberInfo.proposerDateOfBirth = CommonServices.floaterObj.addedMemberDetails[i].riskDetails.dateOfBirth;
                } else if (CommonServices.floaterObj.policyHolderDetails !== undefined) {
                    $scope.memberInfo.proposerDateOfBirth = CommonServices.floaterObj.policyHolderDetails.dateOfBirth;
                }
                $scope.cityResidence = CommonServices.floaterObj.addedMemberDetails[i].riskDetails.cityOfResidence;
            }

            if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "SPOUSE") {
                $scope.memberInfo.showSpouseDOB = true;
                $scope.memberInfo.spouseDateOfBirth = CommonServices.floaterObj.addedMemberDetails[i].riskDetails.dateOfBirth;
            }

        }

        if(CommonServices.floaterObj.policyHolderDetails!==undefined && $scope.cityResidence === undefined ){
			$scope.cityResidence = CommonServices.floaterObj.policyHolderDetails.cityOfResidence;
        }
        $scope.memberInfo.enableAllBtnNP();
    }

    //Edit Quote
    if (CommonServices.editQuoteFlag === true) {
        /**Setting values in Basic Information Screen Start**/
        CommonServices.floaterObj.addedMemberDetails = CommonServices.floaterObj.risks;

        $scope.memberInfo.coveredChildDetails = [];
        $scope.memberInfo.coveredGuardianDetails = [];
        $scope.memberInfo.coveredWardDetails = [];     
        $scope.memberInfo.coveredBrotherDetails = [];  
        $scope.memberInfo.coveredSisterDetails = [];   
        $scope.memberInfo.coveredParentDetails = [];

        if (CommonServices.floaterObj.selfIsAdded === true) {
            $scope.enableProposerDOB = true;
            $scope.memberInfo.showSelfDOB = true;
        } else {
            $scope.enableProposerDOB = false;
            $scope.memberInfo.showSelfDOB = false;
        }

        var count = 0;
        for (var i = 0; i < CommonServices.floaterObj.risks.length; i++) {
            if (CommonServices.floaterObj.risks[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "SELF") {
                $scope.cityResidence = CommonServices.floaterObj.risks[i].riskDetails.cityOfResidence;
                CommonServices.floaterObj.proposerInfo = CommonServices.floaterObj.risks[i];
                CommonServices.floaterObj.ageProposerYrs = CommonServices.floaterObj.risks[i].riskDetails.ageInYrs;
                CommonServices.floaterObj.premiumDetails.sumInsured = CommonServices.floaterObj.risks[i].riskSumInsured;
                if (CommonServices.floaterObj.policyHolderDetails !== undefined) {
                    $scope.memberInfo.proposerName = CommonServices.floaterObj.policyHolderDetails.nameOfInsuredPerson;
                    /* $scope.memberInfo.proposerName = CommonServices.floaterObj.risks[i].riskDetails.nameOfInsuredPerson; */

                } else if (CommonServices.floaterObj.risks[i].riskDetails.nameOfInsuredPerson !== undefined) {
                    $scope.memberInfo.proposerName = CommonServices.floaterObj.risks[i].riskDetails.nameOfInsuredPerson;
                }
                if (CommonServices.floaterObj.risks[i].riskDetails.memberCoveredInPolicy !== undefined) {
                    CommonServices.floaterObj.memberCoveredInPolicy = CommonServices.floaterObj.risks[i].riskDetails.memberCoveredInPolicy;
                }
                $scope.enableProposer = true;
                if (CommonServices.floaterObj.memberCoveredInPolicy === 'N') {
                    $scope.enableProposerDOB = false;
                    $scope.memberInfo.showSelfDOB = false;
                    $scope.memberInfo.addSelfDisable = false;
                    $scope.memberInfo.selfIsAdded = false;
                } else {
                    $scope.enableProposerDOB = true;
                    $scope.memberInfo.showSelfDOB = true;
                    $scope.memberInfo.addSelfDisable = true;
                    $scope.memberInfo.selfIsAdded = true;
                    count++;
                }
                CommonServices.floaterObj.selfIsAdded = $scope.memberInfo.selfIsAdded;

            } else if (CommonServices.floaterObj.risks[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "SPOUSE") {

                $scope.memberInfo.disableAddspouseBtn = 1;
                $scope.memberInfo.showSpouseDOB = true;
                $scope.memberInfo.spouseIsAdded = true;
                $scope.memberInfo.addSpouseDisable = true;
                CommonServices.floaterObj.spouseInfo = CommonServices.floaterObj.risks[i];
                $scope.memberInfo.spouseName = CommonServices.floaterObj.risks[i].riskDetails.nameOfInsuredPerson;
                if ($scope.memberInfo.spouseName !== undefined && $scope.memberInfo.spouseName !== "") {
                    $scope.memberInfo.enableSpouse = true;
                }
                count++;
            } else {
                count++;
                switch(CommonServices.floaterObj.risks[i].riskDetails.relationWithPolicyHolder.toUpperCase()){
                    case "CHILD":
                        $scope.memberInfo.coveredChildDetails.push({
                            "cityOfResidence": CommonServices.floaterObj.risks[i].riskDetails.cityOfResidence,
                            "thresholdLimit": "",
                            "relationWithPolicyHolder": CommonServices.floaterObj.risks[i].riskDetails.relationWithPolicyHolder,
                            "childDateOfBirth": CommonServices.floaterObj.risks[i].riskDetails.dateOfBirth,
                            "nameOfInsuredPerson": CommonServices.floaterObj.risks[i].riskDetails.nameOfInsuredPerson,
                            "areYouEarningHeadOfFamily": "",
                            "ageInYrs": CommonServices.floaterObj.risks[i].riskDetails.ageInYrs,
                            "sex": CommonServices.floaterObj.risks[i].riskDetails.sex?CommonServices.floaterObj.risks[i].riskDetails.sex:"",
                            "ifAnyOtherOccupation": CommonServices.floaterObj.risks[i].riskDetails.ifAnyOtherOccupation !== undefined && CommonServices.floaterObj.risks[i].riskDetails.ifAnyOtherOccupation !== "" ? CommonServices.floaterObj.risks[i].riskDetails.ifAnyOtherOccupation : "",
                            "doYouChewTobacco": CommonServices.floaterObj.risks[i].riskDetails.doYouChewTobacco,
                            "doYouSmoke": CommonServices.floaterObj.risks[i].riskDetails.doYouSmoke,
                            "doYouDrinkAlcohol": CommonServices.floaterObj.risks[i].riskDetails.doYouDrinkAlcohol,
                            "adverseMedicialHistory": CommonServices.floaterObj.risks[i].riskDetails.adverseMedicialHistory,
                            "preExistingDisease": CommonServices.floaterObj.risks[i].riskDetails.preExistingDisease,
                            "dependent": CommonServices.floaterObj.risks[i].riskDetails.dependent,
                            "dependentType": CommonServices.floaterObj.risks[i].riskDetails.dependent === "N" ? "NA" : CommonServices.floaterObj.risks[i].riskDetails.dependentType,
                            "startDtOfMember": "",
                            "previousPolicyDetails": CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails,
                            "bonusdetails": "",
                            "occupation": CommonServices.floaterObj.risks[i].riskDetails.occupation,
                            "cataractLimit": CommonServices.floaterObj.risks[i].riskDetails.cataractLimit != undefined? CommonServices.floaterObj.risks[i].riskDetails.cataractLimit : false,
                            "maternityExpense": CommonServices.floaterObj.risks[i].riskDetails.maternityExpense != undefined ? CommonServices.floaterObj.risks[i].riskDetails.maternityExpense : "N",
                            "disableChildFlag": CommonServices.floaterObj.risks[i].riskDetails.nameOfInsuredPerson !== undefined && CommonServices.floaterObj.risks[i].riskDetails.nameOfInsuredPerson !== "" ? true : false
                        });
                        break;
                    case "WARD":
                        $scope.memberInfo.coveredWardDetails.push({
                            "cityOfResidence": CommonServices.floaterObj.risks[i].riskDetails.cityOfResidence,
                            "thresholdLimit": "",
                            "relationWithPolicyHolder": CommonServices.floaterObj.risks[i].riskDetails.relationWithPolicyHolder,
                            "childDateOfBirth": CommonServices.floaterObj.risks[i].riskDetails.dateOfBirth,
                            "nameOfInsuredPerson": CommonServices.floaterObj.risks[i].riskDetails.nameOfInsuredPerson,
                            "areYouEarningHeadOfFamily": "",
                            "ageInYrs": CommonServices.floaterObj.risks[i].riskDetails.ageInYrs,
                            "sex": CommonServices.floaterObj.risks[i].riskDetails.sex?CommonServices.floaterObj.risks[i].riskDetails.sex:"",
                            "ifAnyOtherOccupation": CommonServices.floaterObj.risks[i].riskDetails.ifAnyOtherOccupation !== undefined && CommonServices.floaterObj.risks[i].riskDetails.ifAnyOtherOccupation !== "" ? CommonServices.floaterObj.risks[i].riskDetails.ifAnyOtherOccupation : "",
                            "doYouChewTobacco": CommonServices.floaterObj.risks[i].riskDetails.doYouChewTobacco,
                            "doYouSmoke": CommonServices.floaterObj.risks[i].riskDetails.doYouSmoke,
                            "doYouDrinkAlcohol": CommonServices.floaterObj.risks[i].riskDetails.doYouDrinkAlcohol,
                            "adverseMedicialHistory": CommonServices.floaterObj.risks[i].riskDetails.adverseMedicialHistory,
                            "preExistingDisease": CommonServices.floaterObj.risks[i].riskDetails.preExistingDisease,
                            "dependent": CommonServices.floaterObj.risks[i].riskDetails.dependent,
                            "dependentType": CommonServices.floaterObj.risks[i].riskDetails.dependent === "N" ? "NA" : CommonServices.floaterObj.risks[i].riskDetails.dependentType,
                            "startDtOfMember": "",
                            "previousPolicyDetails": CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails,
                            "bonusdetails": "",
                            "occupation": CommonServices.floaterObj.risks[i].riskDetails.occupation,
                            "cataractLimit": CommonServices.floaterObj.risks[i].riskDetails.cataractLimit != undefined? CommonServices.floaterObj.risks[i].riskDetails.cataractLimit : false,
                            "maternityExpense": CommonServices.floaterObj.risks[i].riskDetails.maternityExpense != undefined ? CommonServices.floaterObj.risks[i].riskDetails.maternityExpense : "N",
                            "disableChildFlag": CommonServices.floaterObj.risks[i].riskDetails.nameOfInsuredPerson !== undefined && CommonServices.floaterObj.risks[i].riskDetails.nameOfInsuredPerson !== "" ? true : false
                        });
                        break;
                    case "BROTHER":
                        $scope.memberInfo.coveredBrotherDetails.push({
                            "cityOfResidence": CommonServices.floaterObj.risks[i].riskDetails.cityOfResidence,
                            "thresholdLimit": "",
                            "relationWithPolicyHolder": CommonServices.floaterObj.risks[i].riskDetails.relationWithPolicyHolder,
                            "childDateOfBirth": CommonServices.floaterObj.risks[i].riskDetails.dateOfBirth,
                            "nameOfInsuredPerson": CommonServices.floaterObj.risks[i].riskDetails.nameOfInsuredPerson,
                            "areYouEarningHeadOfFamily": "",
                            "ageInYrs": CommonServices.floaterObj.risks[i].riskDetails.ageInYrs,
                            "sex": "M",
                            "ifAnyOtherOccupation": CommonServices.floaterObj.risks[i].riskDetails.ifAnyOtherOccupation !== undefined && CommonServices.floaterObj.risks[i].riskDetails.ifAnyOtherOccupation !== "" ? CommonServices.floaterObj.risks[i].riskDetails.ifAnyOtherOccupation : "",
                            "doYouChewTobacco": CommonServices.floaterObj.risks[i].riskDetails.doYouChewTobacco,
                            "doYouSmoke": CommonServices.floaterObj.risks[i].riskDetails.doYouSmoke,
                            "doYouDrinkAlcohol": CommonServices.floaterObj.risks[i].riskDetails.doYouDrinkAlcohol,
                            "adverseMedicialHistory": CommonServices.floaterObj.risks[i].riskDetails.adverseMedicialHistory,
                            "preExistingDisease": CommonServices.floaterObj.risks[i].riskDetails.preExistingDisease,
                            "dependent": CommonServices.floaterObj.risks[i].riskDetails.dependent,
                            "dependentType": CommonServices.floaterObj.risks[i].riskDetails.dependent === "N" ? "NA" : CommonServices.floaterObj.risks[i].riskDetails.dependentType,
                            "startDtOfMember": "",
                            "previousPolicyDetails": CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails,
                            "bonusdetails": "",
                            "occupation": CommonServices.floaterObj.risks[i].riskDetails.occupation,
                            "cataractLimit": CommonServices.floaterObj.risks[i].riskDetails.cataractLimit != undefined? CommonServices.floaterObj.risks[i].riskDetails.cataractLimit : false,
                            "maternityExpense": CommonServices.floaterObj.risks[i].riskDetails.maternityExpense != undefined ? CommonServices.floaterObj.risks[i].riskDetails.maternityExpense : "N",
                            "disableChildFlag": CommonServices.floaterObj.risks[i].riskDetails.nameOfInsuredPerson !== undefined && CommonServices.floaterObj.risks[i].riskDetails.nameOfInsuredPerson !== "" ? true : false
                        });
                        break;
                    case "SISTER":
                        $scope.memberInfo.coveredSisterDetails.push({
                            "cityOfResidence": CommonServices.floaterObj.risks[i].riskDetails.cityOfResidence,
                            "thresholdLimit": "",
                            "relationWithPolicyHolder": CommonServices.floaterObj.risks[i].riskDetails.relationWithPolicyHolder,
                            "childDateOfBirth": CommonServices.floaterObj.risks[i].riskDetails.dateOfBirth,
                            "nameOfInsuredPerson": CommonServices.floaterObj.risks[i].riskDetails.nameOfInsuredPerson,
                            "areYouEarningHeadOfFamily": "",
                            "ageInYrs": CommonServices.floaterObj.risks[i].riskDetails.ageInYrs,
                            "sex": "F",
                            "ifAnyOtherOccupation": CommonServices.floaterObj.risks[i].riskDetails.ifAnyOtherOccupation !== undefined && CommonServices.floaterObj.risks[i].riskDetails.ifAnyOtherOccupation !== "" ? CommonServices.floaterObj.risks[i].riskDetails.ifAnyOtherOccupation : "",
                            "doYouChewTobacco": CommonServices.floaterObj.risks[i].riskDetails.doYouChewTobacco,
                            "doYouSmoke": CommonServices.floaterObj.risks[i].riskDetails.doYouSmoke,
                            "doYouDrinkAlcohol": CommonServices.floaterObj.risks[i].riskDetails.doYouDrinkAlcohol,
                            "adverseMedicialHistory": CommonServices.floaterObj.risks[i].riskDetails.adverseMedicialHistory,
                            "preExistingDisease": CommonServices.floaterObj.risks[i].riskDetails.preExistingDisease,
                            "dependent": CommonServices.floaterObj.risks[i].riskDetails.dependent,
                            "dependentType": CommonServices.floaterObj.risks[i].riskDetails.dependent === "N" ? "NA" : CommonServices.floaterObj.risks[i].riskDetails.dependentType,
                            "startDtOfMember": "",
                            "previousPolicyDetails": CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails,
                            "bonusdetails": "",
                            "occupation": CommonServices.floaterObj.risks[i].riskDetails.occupation,
                            "cataractLimit": CommonServices.floaterObj.risks[i].riskDetails.cataractLimit != undefined? CommonServices.floaterObj.risks[i].riskDetails.cataractLimit : false,
                            "maternityExpense": CommonServices.floaterObj.risks[i].riskDetails.maternityExpense != undefined ? CommonServices.floaterObj.risks[i].riskDetails.maternityExpense : "N",
                            "disableChildFlag": CommonServices.floaterObj.risks[i].riskDetails.nameOfInsuredPerson !== undefined && CommonServices.floaterObj.risks[i].riskDetails.nameOfInsuredPerson !== "" ? true : false
                        });
                        break;
                    case "GUARDIAN":
                        $scope.memberInfo.coveredGuardianDetails.push({
                            "cityOfResidence": CommonServices.floaterObj.risks[i].riskDetails.cityOfResidence,
                            "thresholdLimit": "",
                            "relationWithPolicyHolder": CommonServices.floaterObj.risks[i].riskDetails.relationWithPolicyHolder,
                            "dateOfBirth": CommonServices.floaterObj.risks[i].riskDetails.dateOfBirth,
                            "nameOfInsuredPerson": CommonServices.floaterObj.risks[i].riskDetails.nameOfInsuredPerson,
                            "areYouEarningHeadOfFamily": "",
                            "ageInYrs": CommonServices.floaterObj.risks[i].riskDetails.ageInYrs,
                            "sex": CommonServices.floaterObj.risks[i].riskDetails.sex?CommonServices.floaterObj.risks[i].riskDetails.sex:"",
                            "ifAnyOtherOccupation": CommonServices.floaterObj.risks[i].riskDetails.ifAnyOtherOccupation !== undefined && CommonServices.floaterObj.risks[i].riskDetails.ifAnyOtherOccupation !== "" ? CommonServices.floaterObj.risks[i].riskDetails.ifAnyOtherOccupation : "",
                            "doYouChewTobacco": CommonServices.floaterObj.risks[i].riskDetails.doYouChewTobacco,
                            "doYouSmoke": CommonServices.floaterObj.risks[i].riskDetails.doYouSmoke,
                            "doYouDrinkAlcohol": CommonServices.floaterObj.risks[i].riskDetails.doYouDrinkAlcohol,
                            "adverseMedicialHistory": CommonServices.floaterObj.risks[i].riskDetails.adverseMedicialHistory,
                            "preExistingDisease": CommonServices.floaterObj.risks[i].riskDetails.preExistingDisease,
                            "dependent": CommonServices.floaterObj.risks[i].riskDetails.dependent,
                            "dependentType": CommonServices.floaterObj.risks[i].riskDetails.dependent === "N" ? "NA" : CommonServices.floaterObj.risks[i].riskDetails.dependentType,
                            "startDtOfMember": "",
                            "previousPolicyDetails": CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails,
                            "bonusdetails": "",
                            "occupation": CommonServices.floaterObj.risks[i].riskDetails.occupation,
                            "cataractLimit": CommonServices.floaterObj.risks[i].riskDetails.cataractLimit != undefined? CommonServices.floaterObj.risks[i].riskDetails.cataractLimit : false,
                            "maternityExpense": CommonServices.floaterObj.risks[i].riskDetails.maternityExpense != undefined ? CommonServices.floaterObj.risks[i].riskDetails.maternityExpense : "N",
                            "disableChildFlag": CommonServices.floaterObj.risks[i].riskDetails.nameOfInsuredPerson !== undefined && CommonServices.floaterObj.risks[i].riskDetails.nameOfInsuredPerson !== "" ? true : false
                        });
                        break;
                    case "PARENTS":
                        $scope.memberInfo.coveredParentDetails.push({
                            "cityOfResidence": CommonServices.floaterObj.risks[i].riskDetails.cityOfResidence,
                            "thresholdLimit": "",
                            "relationWithPolicyHolder": CommonServices.floaterObj.risks[i].riskDetails.relationWithPolicyHolder,
                            "dateOfBirth": CommonServices.floaterObj.risks[i].riskDetails.dateOfBirth,
                            "nameOfInsuredPerson": CommonServices.floaterObj.risks[i].riskDetails.nameOfInsuredPerson,
                            "areYouEarningHeadOfFamily": "",
                            "ageInYrs": CommonServices.floaterObj.risks[i].riskDetails.ageInYrs,
                            "sex": CommonServices.floaterObj.risks[i].riskDetails.sex?CommonServices.floaterObj.risks[i].riskDetails.sex:"",
                            "ifAnyOtherOccupation": CommonServices.floaterObj.risks[i].riskDetails.ifAnyOtherOccupation !== undefined && CommonServices.floaterObj.risks[i].riskDetails.ifAnyOtherOccupation !== "" ? CommonServices.floaterObj.risks[i].riskDetails.ifAnyOtherOccupation : "",
                            "doYouChewTobacco": CommonServices.floaterObj.risks[i].riskDetails.doYouChewTobacco,
                            "doYouSmoke": CommonServices.floaterObj.risks[i].riskDetails.doYouSmoke,
                            "doYouDrinkAlcohol": CommonServices.floaterObj.risks[i].riskDetails.doYouDrinkAlcohol,
                            "adverseMedicialHistory": CommonServices.floaterObj.risks[i].riskDetails.adverseMedicialHistory,
                            "preExistingDisease": CommonServices.floaterObj.risks[i].riskDetails.preExistingDisease,
                            "dependent": CommonServices.floaterObj.risks[i].riskDetails.dependent,
                            "dependentType": CommonServices.floaterObj.risks[i].riskDetails.dependent === "N" ? "NA" : CommonServices.floaterObj.risks[i].riskDetails.dependentType,
                            "startDtOfMember": "",
                            "previousPolicyDetails": CommonServices.floaterObj.risks[i].riskDetails.previousPolicyDetails,
                            "bonusdetails": "",
                            "occupation": CommonServices.floaterObj.risks[i].riskDetails.occupation,
                            "cataractLimit": CommonServices.floaterObj.risks[i].riskDetails.cataractLimit != undefined? CommonServices.floaterObj.risks[i].riskDetails.cataractLimit : false,
                            "maternityExpense": CommonServices.floaterObj.risks[i].riskDetails.maternityExpense != undefined ? CommonServices.floaterObj.risks[i].riskDetails.maternityExpense : "N",
                            "disableChildFlag": CommonServices.floaterObj.risks[i].riskDetails.nameOfInsuredPerson !== undefined && CommonServices.floaterObj.risks[i].riskDetails.nameOfInsuredPerson !== "" ? true : false
                        });
                        break;
                }

            }
        }
        $scope.memberInfo.disableCountBtn = count;
        if (CommonServices.floaterObj.proposerInfo !== undefined && CommonServices.floaterObj.proposerInfo !== "") {
            $scope.cityResidence = CommonServices.floaterObj.proposerInfo.riskDetails.cityOfResidence;
        }
        if (CommonServices.floaterObj.proposerInfo.riskSumInsured !== undefined) {
            $scope.sumInsured = CommonServices.floaterObj.proposerInfo.riskSumInsured;
        } else if (CommonServices.floaterObj.proposerInfo.riskDetails.riskSumInsured !== undefined) {
            $scope.sumInsured = CommonServices.floaterObj.proposerInfo.riskDetails.riskSumInsured;
        }
        if (CommonServices.floaterObj.proposerInfo.riskDetails.dateOfBirth !== undefined) {
            $scope.memberInfo.proposerDateOfBirth = CommonServices.floaterObj.proposerInfo.riskDetails.dateOfBirth;
        } else if (CommonServices.floaterObj.policyHolderDetails !== undefined) {
            $scope.memberInfo.proposerDateOfBirth = CommonServices.floaterObj.policyHolderDetails.dateOfBirth;
        }

        if (CommonServices.floaterObj.spouseInfo !== undefined && CommonServices.floaterObj.spouseInfo !== "") {
            $scope.memberInfo.spouseDateOfBirth = CommonServices.floaterObj.spouseInfo.riskDetails.dateOfBirth;
        }
        $scope.memberInfo.disableAddChildBtn = $scope.memberInfo.coveredChildDetails.length;
        if ($rootScope.productName === "AK") {
            if ($scope.memberInfo.coveredChildDetails.length >= 2) {
                $scope.memberInfo.addChildDisable = true;
            }
        }
        else {
            if ($scope.memberInfo.coveredChildDetails.length === 4 && $scope.memberInfo.spouseIsAdded === true) {
                $scope.memberInfo.addChildDisable = true;
            }
        }
        if($rootScope.productName === "NP" && $scope.memberInfo.coveredParentDetails.length > 1){
            $scope.memberInfo.addParentDisable = true;
        }
        $scope.memberInfo.enableAllBtnNP();

        /**Setting values in Basic Information Screen End**/
    }

    /**Domain Values Service Call**/
    CommonServices.getDomainValues();


}]);
agentApp.controller('floaterBasicPremiumCtrl', ['$scope', 'RestServices', 'CommonServices', '$state', '$rootScope', function ($scope, RestServices, CommonServices, $state, $rootScope) {
    $rootScope.backFlag = "premCal";
    $scope.cancerMaxSumInsuredCheck = CommonServices.checkMaxInsuredAmount;
    console.log("$scope.cancerMaxSumInsuredCheck"+$scope.cancerMaxSumInsuredCheck);
    $scope.goBack = function () {
        if ($rootScope.productName === "UK") {
            $state.go("premiumCalculatorUK");
        }else if ($rootScope.productName === 'CJ') { //CR_3725
            $state.go("premiumCalculatorCJ");//CR_3725
        }else if($rootScope.productName === 'CZ'){
            $state.go("coronaKavachPremiumCalc");
        }else {
            $state.go("premiumCalculatorHealth");
        }
    };

    CommonServices.floaterObj.numberOfMembers = CommonServices.floaterObj.numberOfMembers;
    $scope.countOfMembers = CommonServices.floaterObj.numberOfMembers;
    $scope.basicPremium = CommonServices.floaterObj;


    $scope.topUpBreakupClick = function () {
        var healthViewBreakUpInput;
        if ($rootScope.productName === "UK" || $rootScope.productName === 'CZ' || $rootScope.productName === 'CJ') { // CR_3725 
            healthViewBreakUpInput = {
                "header": null,
                "quote": {
                    "quoteNumber": $scope.basicPremium.quoteNumber,
                    "policyHolderCode": "",
                    "productCode": $rootScope.productName,
                }
            };
        }
         else {
            healthViewBreakUpInput = {
                "header": null,
                "quote": {
                    "quoteNumber": $scope.basicPremium.quoteNumber,
                    "policyHolderCode": ""
                }
            };
        }
        var healthViewBreakUpResponse = RestServices.postService(RestServices.urlPathsNewPortal.healthViewBreakup, healthViewBreakUpInput);
        healthViewBreakUpResponse.then(
            function (response) { // success 

                CommonServices.showLoading(false);
                if (response.data !== undefined && response.data !== "") {
                    if (response.data.userProfile.footer.errorCode === "1") {
                        CommonServices.floaterObj.viewBreakUpResponse = response.data.quote;
                        CommonServices.floaterObj.viewBreakUpNavigation = "ViewBreakupSummaryFirst";
                        $state.go("floaterViewBreakUp");
                    } 

                    else if(response.data.userProfile.footer.errorCode === "0" && $rootScope.productName === "CZ"){
                        CommonServices.floaterObj.viewBreakUpNavigation = "ViewBreakupSummaryFirst";
                        CommonServices.floaterObj.viewBreakUpResponse = response.data.quote;
                        $state.go("coronaKavachViewBreakup");
                    }


                    else if (response.data.userProfile.footer.errorCode === "0" && $rootScope.productName === "UK") {
                        CommonServices.floaterObj.viewBreakUpResponse = response.data.quote;
                        CommonServices.floaterObj.viewBreakUpNavigation = "ViewBreakupSummaryFirst";
                        $state.go("floaterViewBreakUp");
                    }
                    else if (response.data.userProfile.footer.errorCode === "0" && $rootScope.productName === "CJ") { // Sourav/sudip CR_3725
                        CommonServices.floaterObj.viewBreakUpResponse = response.data.quote;
                        CommonServices.floaterObj.viewBreakUpNavigation = "ViewBreakupSummaryFirst";
                        $state.go("floaterViewBreakUp");
                    } else {
                        CommonServices.showAlert(response.data.userProfile.footer.status);
                    }
                } else {
                    CommonServices.showAlert("Please try after some time");
                }
            },
            function (error) { // failure
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            });

    };
    $scope.healthViewBreakCntBtn = function () {
        CommonServices.policyDetailsObj.enableEditModels = "";
        $rootScope.searchLength = 0;
        $state.go("policyHolderInformation");
    };



}]);
agentApp.controller('healthViewbreakUpCtrl', ['$scope', 'RestServices', 'CommonServices', '$state', '$rootScope', function ($scope, RestServices, CommonServices, $state, $rootScope) {

    CommonServices.floaterObj.ViewBreakUp = true;
    $scope.goBack = function () {
        if (CommonServices.floaterObj.viewBreakUpNavigation === "ViewBreakupSummary") {
            $state.go("reviewSummaryScreen");
        } else {
            $state.go("floaterBasicPremium");
        }
    };

    $scope.riskPremiums = CommonServices.floaterObj.viewBreakUpResponse.risks;
    var childCount = 0, daughterCount = 0;
    var parentCount = 0;
    var wardCount = 0; // Sudip CR_3725
    var totalFamilyDiscount = 0;  //CR 3599 Subhajit
    var guardianCount = 0, parentCount = 0, brotherCount = 0, sisterCount = 0; //CR3738A

     //CR 3599 Subhajit*******
     for(var i = 0; i < $scope.riskPremiums.length; i++)
     {   
         totalFamilyDiscount += parseInt($scope.riskPremiums[i].familyDiscountForTheMember);
     }
     $scope.totalFamilyDiscount = totalFamilyDiscount;
     $scope.totalBasicPremium = parseInt(CommonServices.floaterObj.viewBreakUpResponse.premiumDetails.totalPremium) + totalFamilyDiscount ;
     //CR 3599 Ends*******
    for (var i = 0; i < $scope.riskPremiums.length; i++) {
        if ($scope.riskPremiums[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILD" || $scope.riskPremiums[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILDREN") {
            childCount = childCount + 1;
            if($rootScope.productName === "CJ" || $rootScope.productName === "UK" || $rootScope.productName === "NP"){  // Sudip CR_3725
                $scope.riskPremiums[i].riskDetails.policyHolder = "Child " + childCount;
            }
            
        }else if ($scope.riskPremiums[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "PARENTS") {
            parentCount = parentCount + 1;
            $scope.riskPremiums[i].riskDetails.policyHolder = "Parent "+parentCount;
        }else if ($scope.riskPremiums[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "WARD") { // Sudip CR_3725
            wardCount = wardCount + 1;
            if($rootScope.productName === "CJ" || $rootScope.productName === "UK" || $rootScope.productName === "NP"){  // Sudip CR_3725
                $scope.riskPremiums[i].riskDetails.policyHolder = "Ward " + wardCount;
            }
        }else if ($scope.riskPremiums[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "DAUGHTER") {
            daughterCount = daughterCount + 1;
            $scope.riskPremiums[i].riskDetails.policyHolder = "Daughter "+daughterCount;
        }else if ($scope.riskPremiums[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "GUARDIAN") { //CR3738A
            guardianCount = guardianCount + 1;
            $scope.riskPremiums[i].riskDetails.policyHolder = "Guardian " + guardianCount;
        } else if ($scope.riskPremiums[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "PARENTS") {
            parentCount = parentCount + 1;
            $scope.riskPremiums[i].riskDetails.policyHolder = "Parent " + parentCount;
        } else if ($scope.riskPremiums[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "SISTER") {
            sisterCount = sisterCount + 1;
            $scope.riskPremiums[i].riskDetails.policyHolder = "Sister " + sisterCount;
        } else if ($scope.riskPremiums[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "BROTHER") {
            brotherCount = brotherCount + 1;
            $scope.riskPremiums[i].riskDetails.policyHolder = "Brother " + brotherCount;
        }else if ($scope.riskPremiums[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SELF' || $scope.riskPremiums[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "PROPOSER") {
            $scope.riskPremiums[i].riskDetails.policyHolder = "Proposer";
        } else if ($scope.riskPremiums[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SPOUSE') {
            $scope.riskPremiums[i].riskDetails.policyHolder = "Spouse";
        } else if ($scope.riskPremiums[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "PARENTS" && parentCount === 1) {
            $scope.riskPremiums[i].riskDetails.policyHolder = "Parent 1";
        } else if ($scope.riskPremiums[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "PARENTS" && parentCount === 2) {
            $scope.riskPremiums[i].riskDetails.policyHolder = "Parent 2";
        } else {
            //CR3738A code comment
            // if ($rootScope.productName === "NP" || $rootScope.productName === "UK") {
            //     if (($scope.riskPremiums[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILD" || $scope.riskPremiums[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILDREN") && childCount === 1) {
            //         $scope.riskPremiums[i].riskDetails.policyHolder = "Child 1";
            //     } else if (($scope.riskPremiums[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILD" || $scope.riskPremiums[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILDREN") && childCount === 2) {
            //         $scope.riskPremiums[i].riskDetails.policyHolder = "Child 2";
            //     } else if (($scope.riskPremiums[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILD" || $scope.riskPremiums[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILDREN") && childCount === 3) {
            //         $scope.riskPremiums[i].riskDetails.policyHolder = "Child 3";
            //     } else if (($scope.riskPremiums[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILD" || $scope.riskPremiums[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILDREN") && childCount === 4) {
            //         $scope.riskPremiums[i].riskDetails.policyHolder = "Child 4";
            //     } else if ($scope.riskPremiums[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILD" && childCount === 5) {
            //         $scope.riskPremiums[i].riskDetails.policyHolder = "Child 5";
            //     }
            //     else
            //         $scope.riskPremiums[i].riskDetails.policyHolder = "Child 6";
            // }else if ($rootScope.productName === "CJ"){  // Sudip CR_3725
            //     console.log($rootScope.productName);
            // } else {
            //     if ($scope.riskPremiums[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "DAUGHTER" && daughterCount === 1) {
            //         $scope.riskPremiums[i].riskDetails.policyHolder = "Daughter 1";
            //     } else {
            //         $scope.riskPremiums[i].riskDetails.policyHolder = "Daughter 2";
            //     }
            // }

        }
    }
    $scope.premiumDetails = CommonServices.floaterObj.viewBreakUpResponse;

    $scope.healthViewBreakCntBtn = function () {
        $rootScope.searchLength = 0;
        $state.go("policyHolderInformation");
    };
}]);
agentApp.controller('policyHolderCtrl', ['$scope', 'RestServices', 'CommonServices', '$state', '$rootScope', function ($scope, RestServices, CommonServices, $state, $rootScope) {
    
    $scope.gstinMsg = "GSTIN";
    /*CR 3712 starts
	$scope.isNonIndia = false;
	// $scope.policyDetailsObj.clientNationality ="";
	$scope.onNationalityChange = function(){
		$scope.policyHolderCreate.clientCountry = '';
		if($scope.policyHolderCreate.clientNationality == "NonIndian"){
			$scope.isNonIndia = true;
		}
		else{
			$scope.isNonIndia = false;
		}
	}
	//CR_3712 ends*/
    
    $scope.policyHolderDetailsCtrl = {
        onload: function () {
            if ($rootScope.backFlag === "policyHolder") {
                $scope.policyHolderRadio = CommonServices.policyDetailsObj.policyHolderRadio;
            }
            $scope.newcustomerFlag = true;
            $scope.cityEnable = true;
            $scope.pinEnable = true;
            $scope.gstInPatternErr = true;
            $scope.disableInputField = false;
            $scope.isNIAPAN = false;//CR3746
            $scope.regexPanNo = regexPanNoGlobal;
        }
    };
 //CR3746
 $scope.onPANNoChange = function () {
    if($scope.policyHolderCreate.pan != undefined){
        $scope.policyHolderCreate.pan = $scope.policyHolderCreate.pan.toUpperCase();
        $scope.isNIAPAN = isNIAPANNo($scope.policyHolderCreate.pan);
    }
    else
        $scope.isNIAPAN = false;
};
//CR3746

    $scope.missingField = false;
    $scope.policyHolderDetailsCtrl.onload();
    $scope.policyHolderCreate = {};

     //CR3746
//      $scope.onPANNoChange = function () {
//         if($scope.policyHolderCreate.pan != undefined){
//            $scope.policyHolderCreate.pan = $scope.policyHolderCreate.pan.toUpperCase();
//            $scope.isNIAPAN = isNIAPANNo($scope.policyHolderCreate.pan.toUpperCase());
//         }
//        else
//            $scope.isNIAPAN = false;
//    };
   //CR3746
    $scope.goBack = function () {
        if ($rootScope.productName === "RK") {
            $state.go("rakViewBreakup");
        }else{
            $state.go("floaterBasicPremium");
        }
        
    };

    /*CR_NP_0880 Starts*/
    $scope.disableCityInput = true;
    $scope.disablePinCodeInput = true;
    //  if(CommonServices.backFromPolSearch){
    //     $scope.disablePinCodeInput = false;
    // }
    // if(CommonServices.topUpObj.getPolicyholderDetails.cityName != undefined && CommonServices.topUpObj.getPolicyholderDetails.cityName != ""){
    //     $scope.policyHolderCreate.cityName = CommonServices.topUpObj.getPolicyholderDetails.cityName;
    // }
    /*CR_NP_0880 Ends */

    /*Added for CR_NP_0744*/
    // $rootScope.regexPanNo = /^(?:([A-Za-z])(?!(?:\1){4})){3}(?:([ABCEFGHJLPTabcefghjlpt])(?!(?:\1){4})){1}(?:([A-Za-z])(?!(?:\1){4})){1}(?:([0-9])(?!(?:\4){3})){4}[A-Za-z]$/;    CR_3746 actual
    $rootScope.regexPanNo = /^[A-Za-z]{5}[0-9]{4}[0-9]{1}$/;
    $rootScope.regexAadhaarInput = /^(?!\1+$)\d{4}$/;
    $rootScope.regexAadhaarNumber = /^(?!\1+$)\d{12}$/;


    var configurationData = CommonServices.getCommonData("ConfigurationData");
    if (configurationData != undefined && configurationData != '') {
        if (configurationData[0].value == "Y") {
            $scope.isPanNumberMandatory = true;
        } else {
            $scope.isPanNumberMandatory = false;
        }
        /*Below block Commented for CR_NP_0744E */
        //  if(configurationData[1].value == "Y"){
        // 	 $scope.isAadhaarNumberMandatory = true;
        //  }else{
        // 	  $scope.isAadhaarNumberMandatory = false;
        //  }
        /* CR_NP_0744E ends*/
    }


    /**Added for CR_NP_0744, commented for CR_NP_0744E**/
    // $(".aadhaarInput").keyup(function () {
    // 	if (this.value.length == 4) {
    // 		$(this).next('.aadhaarInput').focus();
    // 	}
    // 	if (this.value.length < 1) {
    // 	  $(this).prev('.aadhaarInput').focus();
    // 	}
    // });

    // $scope.aadhaarNoField = function(){
    // 	if(($rootScope.policyDetailsObj.aadhaarNumber1 != undefined && $rootScope.policyDetailsObj.aadhaarNumber1 !='')||($rootScope.policyDetailsObj.aadhaarNumber2 != undefined && $rootScope.policyDetailsObj.aadhaarNumber2 !='')||($rootScope.policyDetailsObj.aadhaarNumber3 != undefined && $rootScope.policyDetailsObj.aadhaarNumber3 !='')){
    // 		$scope.aadharFieldIsRequired = true;
    // 		if(($rootScope.policyDetailsObj.aadhaarNumber1 != undefined && $rootScope.policyDetailsObj.aadhaarNumber1 !='') && ($rootScope.policyDetailsObj.aadhaarNumber2 != undefined && $rootScope.policyDetailsObj.aadhaarNumber2 !='') && ($rootScope.policyDetailsObj.aadhaarNumber3 != undefined && $rootScope.policyDetailsObj.aadhaarNumber3 !='')){
    // 			$scope.aadharFieldIsRequired = false;
    // 		}
    // 	}else{
    // 		$scope.aadharFieldIsRequired = false;
    // 	}
    // };
    /*CR_NP_0744 and CR_NP_0744 Changes ends*/

    /* Date Of Birth validation starts */
    var mydateStr = new Date();
    var mynewdateFrom = "";
    if (mydateStr != undefined) {
        mynewdateFrom = new Date(mydateStr);
    } else {
        mynewdateFrom = new Date();
    }

    var enableProposerDOBCalfrom = getFormattedDate(mynewdateFrom);
    var enableAgefrom;
    if ($rootScope.productName === "UK") {
        if(CommonServices.floaterObj.addedMemberDetails.length > 2)
            enableAgefrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 61));
        else 
            enableAgefrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 51));
    } else if ($rootScope.productName === "CJ"){
        enableAgefrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 66)); // Sudip CR_3725
    } else if ($rootScope.productName === 'CZ') { /** CR 4092 - Corona Kavach Policy */
        var date66YearsOld = new Date(new Date().setFullYear(new Date().getFullYear() - 66));
        enableAgefrom = resetTime(new Date(date66YearsOld.setDate(date66YearsOld.getDate() + 1))); /** Age <= 65 */
    } else {
        if (CommonServices.floaterObj.memberCoveredInPolicy === 'Y') {
            if (($rootScope.productName === "NP") && (CommonServices.floaterObj.addedMemberDetails.length > 2)) 
                enableAgefrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 61));
            else
                enableAgefrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 51));
        } else {
            enableAgefrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 100));
        }
    }

    var enableAgeTo = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 18));
    enableAgeTo = getFormattedDate(enableAgeTo);

    $scope.dateOfBirth = function () {
        $("#dateOfBirth").loadCalendar({
            'enableDateRange': true,
            'enableCalendarFrom': enableAgefrom,
            'enableCalendarTo': enableProposerDOBCalfrom
        });
        return true;
    };


    $scope.policyHldrDateBithChange = function () {
        var policyHldrDateOfBithChanged = $scope.policyHolderCreate.dateOfBirth;
        var arr = policyHldrDateOfBithChanged.split('/');
        policyHldrDateOfBithChanged = arr[1] + '/' + arr[0] + '/' + arr[2]; //mm/dd/yyyy 
        policyHldrDateOfBithChanged = new Date(policyHldrDateOfBithChanged);
        var enableToDate = new Date(enableAgeTo);
        CommonServices.floaterObj.SelfDOBPolicyHolder = $scope.policyHolderCreate.dateOfBirth;
        if (policyHldrDateOfBithChanged > enableToDate) {
            if (CommonServices.floaterObj.memberCoveredInPolicy === 'Y' || $rootScope.productName === "UK") {
                if($rootScope.productName === "UK" || $rootScope.productName === "NP"){ //CR3738A

                    CommonServices.showAlert("Age should be between  18 to 60 Years");
                }else{
                    CommonServices.showAlert("Age should be between  18 to 50 Years");
                }
                $scope.policyHolderCreate.dateOfBirth = "";
            } else {
                CommonServices.showAlert("Age should be between  18 to 100 Years");
                $scope.policyHolderCreate.dateOfBirth = "";
            }
        } else {
            if ($rootScope.productName === "UK") {
                if (CommonServices.floaterObj.addedMemberDetails[0].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PROPOSER') {
                    if ($scope.policyHolderCreate.dateOfBirth !== CommonServices.floaterObj.addedMemberDetails[0].riskDetails.dateOfBirth) {
                        CommonServices.showAlert("There is a mismatch between the Date of Birth entered for Proposer and Policy Holder. Please note that the Date of Birth entered in the Policy holder/Personal information shall be considered");
                    }
                }
            } 
            else if ($rootScope.productName === "CJ" || $rootScope.productName === "CZ") {  //CZ for CR_4092
                if (CommonServices.floaterObj.addedMemberDetails[0].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PROPOSER') {
                    console.log("cancer date of birth mismatch condition"+CommonServices.floaterObj.addedMemberDetails[0].riskDetails.dateOfBirth);
                    if ($scope.policyHolderCreate.dateOfBirth !== CommonServices.floaterObj.addedMemberDetails[0].riskDetails.dateOfBirth) {
                        CommonServices.showAlert("There is a mismatch between the Date of Birth entered for Proposer and Policy Holder. Please note that the Date of Birth entered in the Policy holder/Personal information shall be considered");
                    }
                }
            }else if ($rootScope.productName === "RK") {
                if (CommonServices.floaterObj.addedMemberDetails[0].riskdetails.relationPolicyHolder.toUpperCase() === 'PROPOSER') {
                    if ($scope.policyHolderCreate.dateOfBirth !== CommonServices.floaterObj.addedMemberDetails[0].riskdetails.dateOfBirth) {
                        CommonServices.showAlert("There is a mismatch between the Date of Birth entered for Proposer and Policy Holder. Please note that the Date of Birth entered in the Policy holder/Personal information shall be considered");
                    }
                }
            }
            else {
                if ($scope.policyHolderCreate.dateOfBirth !== CommonServices.floaterObj.addedMemberDetails[0].riskDetails.dateOfBirth && CommonServices.floaterObj.memberCoveredInPolicy === 'Y') {
                    CommonServices.showAlert("There is a mismatch between the Date of Birth entered for Proposer and Policy Holder. Please note that the Date of Birth entered in the Policy holder/Personal information shall be considered");
                }
            }
        }
    };

    calculateAgeInYearsFromDate = function(dob) {             //CR_3738_B
        if(!dob){
            return;
        }
        // var Arr = dob.split('/');
        // dob = Arr[2] + '/' + Arr[1] + '/' + Arr[0]; //mm/dd/yyyy
        // var date = new Date(dob);
        // var ageDifMs = Date.now() - date.getTime();
        // var ageDinYrs = new Date(ageDifMs); // miliseconds from epoch
        // ageDinYrs = Math.abs(ageDinYrs.getUTCFullYear() - 1970);
        // return ageDinYrs.toString();

        var today = new Date();
        var ageArr = dob.split('/');
        ageCal = ageArr[2] + '/' + ageArr[1] + '/' + ageArr[0]; //mm/dd/yyyy
        var birthDate = new Date(ageCal);
        var age = today.getFullYear() - birthDate.getFullYear();
        var m = today.getMonth() - birthDate.getMonth();
        if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
            age--;
        }
        return age.toString();
    };

    $scope.ageVerify = function(dob) {
        var addedSenior = false, addedYoung = false; 
        var polHolderAge = calculateAgeInYearsFromDate(dob);
        if((polHolderAge < 35) || (CommonServices.floaterObj.addedMemberDetails[0].riskDetails.ageInYrs > 50))
            return true;
        for(let i = 1; i <  CommonServices.floaterObj.addedMemberDetails.length; i++){
            if(CommonServices.floaterObj.addedMemberDetails[i].riskDetails.ageInYrs > 50)
                addedSenior = true;
            else if(CommonServices.floaterObj.addedMemberDetails[i].riskDetails.ageInYrs < 35)
                addedYoung = true;
        }
        if(polHolderAge >50)
            addedSenior = true;
        if(addedSenior &&  ((CommonServices.floaterObj.addedMemberDetails.length < 3) || (!addedYoung)))
            return false;
        else
            return true;
    };

    /* Date Of Birth validation Ends */

    $scope.onGstIdChange = function () {
        var valid = true;
        var regxNRI = /^[0-9]{12}[N]{1}[0-9A-Z]{1}[T]{1}$/;
        var regxUNB = /^[0-9]{12}[U]{1}[0-9A-Z]{1}[N]{1}$/;
        var regxNCC = regexGSTidGlobal;///^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[A-Z0-9]{2}[^\s]$/;
        /*if(!genCustomComponents.conversionService.objectIsEmpty($scope.quickRenewalForm)){
        	$scope.quickRenewalForm.gstinInd.$setValidity('gstinExp',true);	
        }*/

        if ($scope.policyHolderCreate.gstRegistraionIdType == '' || $scope.policyHolderCreate.gstRegistraionIdType == undefined) {
            $scope.policyHolderCreate.gstin = '';
            $scope.policyHolderForm.gstin.$setValidity("validateNIAPAN", true);
            $scope.policyHolderForm.gstin.$setValidity("gstin", true);
            $scope.gstInPatternErr = false;
            $scope.policyHolderCreate.uin ='';
            //return;
        }

        if ($scope.policyHolderCreate.gstRegistraionIdType !== '' && $scope.policyHolderCreate.gstRegistraionIdType !== undefined && $scope.policyHolderCreate.gstin !== "" && $scope.policyHolderCreate.gstin !== undefined) {
            if ($scope.policyHolderCreate.gstRegistraionIdType === 'NRI') {
                valid = (regxNRI.test($scope.policyHolderCreate.gstin.toUpperCase()));
                // $scope.policyHolderForm.gstin.$setValidity("gstStateCode", true);//UC for 3749
            } else if ($scope.policyHolderCreate.gstRegistraionIdType === 'UNB') {
                valid = (regxUNB.test($scope.policyHolderCreate.gstin.toUpperCase()));
                // $scope.policyHolderForm.gstin.$setValidity("gstStateCode", true);//UC for 3749
            } else if ($scope.policyHolderCreate.gstRegistraionIdType === 'NCC') {
                valid = (regxNCC.test($scope.policyHolderCreate.gstin.toUpperCase()));
                
                //Uncomment it for 3749
                // if(valid){
                //     if(CommonServices.gstIdStateCode[$scope.policyHolderCreate.gstin.slice(0,2)] != undefined){
                //         if($scope.policyHolderCreate.stateName.state == CommonServices.gstIdStateCode[$scope.policyHolderCreate.gstin.slice(0,2)]){
                //             $scope.policyHolderForm.gstin.$setValidity("gstStateCode", true);
                //             console.log("state code valid");
                //         }
                //         else{
                //             $scope.policyHolderForm.gstin.$setValidity("gstStateCode", false);
                //             $scope.gstErrorMsg = "Please enter valid GSTIN. State code of GSTIN and the state mentioned in address should match.";	
                //         }
                //     }
                //     else{
                //         $scope.policyHolderForm.gstin.$setValidity("gstStateCode", false);
                //         $scope.gstErrorMsg = "Please enter GSTIN with a valid state code";
                //     }
                // }
            }
            $scope.gstInPatternErr = valid;
            //$scope.quickRenewalForm.gstinInd.$setValidity('gstinExp',valid);
        } else if ($scope.policyHolderCreate.gstin === "" || $scope.policyHolderCreate.gstin === undefined) {
            $scope.gstInPatternErr = true;
        } else if ($scope.policyHolderCreate.gstRegistraionIdType === '' || $scope.policyHolderCreate.gstRegistraionIdType === undefined) {
            if ($scope.policyHolderCreate.gstin !== "" && $scope.policyHolderCreate.gstin !== undefined) {
                $scope.gstInPatternErr = false;
            }
        }

        if ($scope.gstInPatternErr === false) {
            $scope.policyHolderForm.gstin.$setValidity("gstin", false);
        } else {
            $scope.policyHolderForm.gstin.$setValidity("gstin", true);
        }

        //added by himanshu for CR_875
        if ($scope.policyHolderCreate.gstRegistraionIdType !== '' && $scope.policyHolderCreate.gstRegistraionIdType !== undefined && $scope.policyHolderCreate.gstin !== "" && $scope.policyHolderCreate.gstin !== undefined) {
            if ($scope.policyHolderCreate.gstin != undefined) {
                $scope.policyHolderCreate.gstin = $scope.policyHolderCreate.gstin.toUpperCase();
                if ($scope.policyHolderCreate.gstin.includes("AAACN4165C")) {
                    $scope.policyHolderForm.gstin.$setValidity("validateNIAPAN", false);
                } else {
                    $scope.policyHolderForm.gstin.$setValidity("validateNIAPAN", true);
                }
            }
        }
    };

    $scope.startsWith = function (state, viewValue) {
        return state.substr(0, viewValue.length).toLowerCase() == viewValue.toLowerCase();
    };

    var stateInputMin = 3;
    /*var countryInputMin = 3;//3712*/
    $scope.policyHolderCreate.stateName = '';
    $scope.result = '';

    $scope.textChanged = function (data/*,type*/) {//3712
        /* if(type!=undefined && type === 'state'){//3712 */
            /*CR_NP_0880 Starts */
            $scope.result = 'Please enter valid State by providing at least first 3 characters';
            $scope.showStateError = true;
            if (data != null && data.length >= stateInputMin) {
                return gstStateServiceCall(data);
            }
            /*CR_NP_0880 Ends */
        /* 3712 starts/////////////////
        }
        else if(type!=undefined && type === 'country'){
            $scope.result = 'Please enter valid Country by providing at least first 3 characters';
            $scope.showCountryError = true;
            if (data != null && data.length >= countryInputMin) {
                return gstCountryServiceCall(data);
            }
        }
        // 3712 ends//////////*/
    };

    /*//// 3712 Starts
    function gstCountryServiceCall(data) {
        var getStateListInput = {
            "state": data.toUpperCase()
        };
        var getStateListResponse = RestServices.postService(RestServices.urlPathsNewPortal.getStateList, getStateListInput);
        return getStateListResponse.then(function (response) { // success
            CommonServices.showLoading(false);
            $scope.showCountryError = true;
            if (response.data.hasOwnProperty('states')) {
                return $scope.stateList = response.data.states;
            } else {
                $scope.stateList = "";
                $scope.result = "No search results found";
                if (data == null) {
                    $scope.showCountryError = false;
                } else {
                    $scope.showCountryError = true;
                }
                return $scope.stateList;
            }

        }, function (error) {
            CommonServices.showLoading(false);
            RestServices.handleWebServiceError(error);
        });
    };
    ////////3712 Ends /////////*/

    function gstStateServiceCall(data) {
        /*CR_NP_0880 Starts */
        var getStateListInput = {
            "state": data.toUpperCase()
        };
        var getStateListResponse = RestServices.postService(RestServices.urlPathsNewPortal.getStateList, getStateListInput);
        return getStateListResponse.then(function (response) { // success
            CommonServices.showLoading(false);
            $scope.showStateError = true;
            if (response.data.hasOwnProperty('states')) {
                return $scope.stateList = response.data.states;
            } else {
                $scope.stateList = "";
                $scope.result = "No search results found";
                if (data == null) {
                    $scope.showStateError = false;
                } else {
                    $scope.showStateError = true;
                }
                return $scope.stateList;
                /*CR_NP_0880 Ends*/
            }

        }, function (error) {
            CommonServices.showLoading(false);
            RestServices.handleWebServiceError(error);
        });
    };

    $scope.onChange = function (data) {
        /*CR_NP_0880 Starts */

        if (data === 'state') {
            $scope.showStateError = true;
            $scope.showPincodeError = false;
            $scope.showCityError = false;
            $scope.policyHolderCreate.pinCode = "";
            $scope.policyHolderCreate.cityName = "";
            $scope.disablePinCodeInput = true; // To disable Pincode Input
            // $scope.disableCityInput = true; // To disable City Input

        } else if (data === 'pinCode') {
            $scope.showPincodeError = true;
            $scope.showCityError = false;
            $scope.policyHolderCreate.cityName = "";
            // $scope.disableCityInput = true; // To disable City Input

        } else if (data === 'city') {
            $scope.showCityError = true;
        }
        /*CR_NP_0880 Ends */
        /*/3712 starts////////
        else if(data === 'country') {
            $scope.showCountryError = true;
        }
        // 3712 ends */
    };

    /*//// 3712 Start/////////////////////
    $scope.countrySelect = function () {
        $scope.showCountryError = false;
    };
    ///// 3712 End////////////////////*/

    $scope.stateSelect = function () {
        /*CR_NP_0880 start*/
        $scope.showStateError = false;
        $scope.showPincodeError = true;
        $scope.disablePinCodeInput = false;
        $scope.policyHolderCreate.pinCode = "";
        // $scope.gstCityLocation = "";

        var getZipCodeListInput = {
            "state": $scope.policyHolderCreate.stateName.state === undefined ? $scope.policyHolderCreate.stateName : $scope.policyHolderCreate.stateName.state
        };

        var getZipCodeListResponse = RestServices.postService(RestServices.urlPathsNewPortal.getZipCodesbyState, getZipCodeListInput);
        getZipCodeListResponse.then(function (response) {
            CommonServices.showLoading(false);
            if (response.data.hasOwnProperty('pincodes')) {
                $scope.allZipCodeList = response.data.pincodes;
            }

        }, function (error) {
            CommonServices.showLoading(false);
            RestServices.handleWebServiceError(error);
        });
        /*CR_NP_0880 Ends */

        //Uncomment it for CR_3749
        // angular.forEach(CommonServices.gstIdStateCode,function(value,key){
        //     if($scope.policyHolderCreate.stateName.state == value){
        //         $scope.gstinMsg = "GSTIN should start with "+key;
        //     }

        // });
        // $scope.onGstIdChange();

    };

    $scope.pincodeSelect = function () {
        $scope.showPincodeError = false;
        $scope.policyHolderForm.pinCode.$setValidity("parse", true);
        /*CR_NP_0880 start*/
        var getCitiesListInput = {
            "state": $scope.policyHolderCreate.stateName.state === undefined ? $scope.policyHolderCreate.stateName : $scope.policyHolderCreate.stateName.state,
            "zipCode": $scope.policyHolderCreate.pinCode,
            //"additionalParameter": "MOBILE",
            "city": ""
        };

        var getCitiesListResponse = RestServices.postService(RestServices.urlPathsNewPortal.getCitiesList, getCitiesListInput);
        getCitiesListResponse.then(function (response) {
            CommonServices.showLoading(false);
            if (response.data.hasOwnProperty('cities')) {
                $scope.cityList = response.data.cities;
                $scope.policyHolderCreate.cityName = response.data.cities[0];
            } else {
                CommonServices.showAlert("Error Occured. Please try again");
            }

        }, function (error) {
            CommonServices.showLoading(false);
            RestServices.handleWebServiceError(error);
        });
        /*CR_NP_0880 Ends */
    };

    $scope.citySelect = function () {
        /*CR_NP_0880 start*/
        $scope.showCityError = false;
    };
    /*CR_NP_0880 Ends */

    $scope.newCustomerChanging = function () {
        CommonServices.userClickedOnDivFunc = false;
        CommonServices.floaterObj.SelfDOBPolicyHolder = undefined;
        CommonServices.floaterObj.reviewSummary = false;
        CommonServices.stateCodeType = undefined;
        CommonServices.cityCodeType = undefined;
        $scope.minimize = false;
        CommonServices.floaterObj.goToMemeberInfoEdit = "NEW";
        CommonServices.policyDetailsObj = {};

        if ($scope.policyHolderRadio === 'newCustomer') {
            /*Added for CR_NP_0744, and aadhaar related commented for CR_NP_0744E*/
            $rootScope.policyDetailsObj.panNoInputDisable = false;
            // $rootScope.policyDetailsObj.aadhaarInputDisable = false;
            CommonServices.panNoInputDisable = false;
            // CommonServices.aadhaarInputDisable = false;
            $rootScope.policyDetailsObj.aadhaarNumber1 = "";
            $rootScope.policyDetailsObj.aadhaarNumber2 = "";
            $rootScope.policyDetailsObj.aadhaarNumber3 = "";
            CommonServices.policyHolderType = "newCustomer";
            /*CR_NP_0744 and CR_NP_0744E Ends*/
            $scope.newcustomerFlag = true;
            $scope.existingcustomerFlag = false;
            $scope.showIndividualData = false;
            $scope.disableInputField = false;
            $scope.pinEnable = true;
            $scope.cityEnable = true;
            $scope.showPartyDetailsData = false;
            $scope.policyHolderCreate.policyHolderName = undefined;
            $scope.policyHolderCreate.policyHolderMidName = undefined;
            $scope.policyHolderCreate.policyHolderLastName = undefined;
           // if ($rootScope.productName === "CJ"){
            //    $scope.policyHolderCreate.createPolGender = $scope.gender[0];//false;
            // }else{
            //    $scope.policyHolderCreate.createPolGender = false;
            // }
             //Sourav CR_3618 Third Gender
            $scope.policyHolderCreate.createPolGender = '';//$scope.gender[0];//false;
            $scope.policyHolderCreate.dateOfBirth = undefined;
            /*
            $scope.policyHolderCreate.clientNationality = undefined;//3712
            $scope.policyHolderCreate.clientCountry = undefined;//3712
            */
            $scope.policyHolderCreate.buildingStreet = undefined;
            $scope.policyHolderCreate.gstRegistraionIdType = undefined;
            $scope.policyHolderCreate.gstin = undefined;
            $scope.policyHolderCreate.uin = undefined;
            $scope.policyHolderCreate.stateName = undefined;
            $scope.policyHolderCreate.cityName = undefined;
            $scope.policyHolderCreate.pinCode = undefined;
            $scope.policyHolderCreate.mobile = undefined;
            $scope.policyHolderCreate.email = undefined;
            $scope.policyHolderCreate.pan = undefined;
            $scope.policyHolderCreate.eInsurance = undefined;
            $scope.policyHolderSearchResult = {};
        } else {
            if ($scope.policyHolderRadio === 'existingCustomer') {
                CommonServices.policyDetailsObj.navigationFrom = "existing";
                $scope.showPartyDetailsData = false;
                CommonServices.floaterObj.goToNomineeInfoEdit = "EXISTING";
                $scope.topUpPolicyHolderSearch.policyHolderCode = '';
                $scope.topUpPolicyHolderSearch.policyHolderName = '';
                $scope.topUpPolicyHolderSearch.policyHolderLastName = '';
                $scope.topUpPolicyHolderSearch.emailId = '';
                $scope.topUpPolicyHolderSearch.mobileNum = '';
                $scope.newcustomerFlag = false;
                $scope.showIndividualData = false;
                $scope.existingcustomerFlag = true;
                $scope.policyHolderSearchResult = {};
                $scope.disableInputField = false;
                /* CommonServices.policyDetailsObj.policyHolderCreateText = "policyHolderDeleted"; */
            }

        }
    };

    // Service call policy holder Creation 
    $scope.policyHolderCreatefun = function () {
        if ($rootScope.policyDetailsObj.aadhaarNumber1 !== undefined && $rootScope.policyDetailsObj.aadhaarNumber1 !== "" && $rootScope.policyDetailsObj.aadhaarNumber2 !== undefined && $rootScope.policyDetailsObj.aadhaarNumber2 !== "" && $rootScope.policyDetailsObj.aadhaarNumber3 !== undefined && $rootScope.policyDetailsObj.aadhaarNumber3 !== "") {
            $rootScope.policyDetailsObj.aadhaarNumber = $rootScope.policyDetailsObj.aadhaarNumber1 + $rootScope.policyDetailsObj.aadhaarNumber2 + $rootScope.policyDetailsObj.aadhaarNumber3;
        } else {
            $rootScope.policyDetailsObj.aadhaarNumber = "";
        }

        if ($scope.policyHolderCreate.gstRegistraionIdType !== 'UNB') {
            $scope.policyHolderCreate.uin = undefined;
        }

        if(($rootScope.productName === "NP" || $rootScope.productName === "UK") && CommonServices.floaterObj.memberCoveredInPolicy !== 'N'){
            if(!($scope.ageVerify($scope.policyHolderCreate.dateOfBirth))){
                CommonServices.showAlert('<p>For any member age more than 50 years the following conditions needs to be satisfied in order to continue: - </p>\
                                        <ol><li>1. A minimum of 3 persons should be covered in the policy.</li>\
                                        <li>2. At least one of the members age should be less than 35 Years.</li></ol>');
                return;
            }
        }
        
        //CR_3725 sourav/sudip     
        if($rootScope.productName === "CJ") { //Sudip CR_3725
            var policyHolderCreateInput = {
                "userProfile": {
                    "userId": CommonServices.getCommonData("userId"),
                    "loggedInRole": "SUPERUSER"
                },
                "partyDetails": {
                    "individualDetails": {
                        "title": "",
                        "firstName": $scope.policyHolderCreate.policyHolderName.toUpperCase(),
                        "middleName": $scope.policyHolderCreate.policyHolderMidName !== undefined ? $scope.policyHolderCreate.policyHolderMidName.toUpperCase() : $scope.policyHolderCreate.policyHolderMidName,
                        "lastName": $scope.policyHolderCreate.policyHolderLastName.toUpperCase(),
                        "gender": $scope.policyHolderCreate.createPolGender,//$scope.policyHolderCreate.createPolGender === true ? "F" : "M",
                        "dateOfBirth": $scope.policyHolderCreate.dateOfBirth,
                        "buildingNoStreet": $scope.policyHolderCreate.buildingStreet.toUpperCase(),
                        "gstRegIdType": $scope.policyHolderCreate.gstRegistraionIdType,
                        "gstin": $scope.policyHolderCreate.gstin !== undefined ? $scope.policyHolderCreate.gstin.toUpperCase() : $scope.policyHolderCreate.gstin,
                        "uin": $scope.policyHolderCreate.uin !== undefined ? $scope.policyHolderCreate.uin.toUpperCase() : $scope.policyHolderCreate.uin,
                        "cityObj": $scope.policyHolderCreate.cityName,
                        "stateObj": $scope.policyHolderCreate.stateName,
                        "pinCode": $scope.policyHolderCreate.pinCode, //CR880
                        "mobileNo": $scope.policyHolderCreate.mobile,
                        "state": $scope.policyHolderCreate.stateName.stateCode,
                        "city": $scope.policyHolderCreate.cityName.cityCode,
                        "emailId": $scope.policyHolderCreate.email,
                        "panNumber": $scope.policyHolderCreate.pan !== undefined ? $scope.policyHolderCreate.pan.toUpperCase() : $scope.policyHolderCreate.pan,
                        "aadhaarNo": $rootScope.policyDetailsObj.aadhaarNumber,
                        "eInsuranceAccountNo": $scope.policyHolderCreate.eInsurance !== undefined ? $scope.policyHolderCreate.eInsurance.toUpperCase() : $scope.policyHolderCreate.eInsurance
                    },
                    "partyType": "I"
                }
            };
        }else{ //Sudip CR_3725
            var policyHolderCreateInput = {
                "userProfile": {
                    "userId": CommonServices.getCommonData("userId"),
                    "loggedInRole": "SUPERUSER"
                },
                "partyDetails": {
                    "individualDetails": {
                        "title": "",
                        "firstName": $scope.policyHolderCreate.policyHolderName.toUpperCase(),
                        "middleName": $scope.policyHolderCreate.policyHolderMidName !== undefined ? $scope.policyHolderCreate.policyHolderMidName.toUpperCase() : $scope.policyHolderCreate.policyHolderMidName,
                        "lastName": $scope.policyHolderCreate.policyHolderLastName.toUpperCase(),
                        "gender": $scope.policyHolderCreate.createPolGender,// === true ? "F" : "M",
                        "dateOfBirth": $scope.policyHolderCreate.dateOfBirth,
                        /*
                        "clientNationality": $scope.policyHolderCreate.clientNationality,//3712
                        "clientCountryObj": $scope.policyHolderCreate.clientCountry,//3712
                        "clientCountry": $scope.policyHolderCreate.clientCountry.stateCode,//3712
                        */
                        "buildingNoStreet": $scope.policyHolderCreate.buildingStreet.toUpperCase(),
                        "gstRegIdType": $scope.policyHolderCreate.gstRegistraionIdType,
                        "gstin": $scope.policyHolderCreate.gstin !== undefined ? $scope.policyHolderCreate.gstin.toUpperCase() : $scope.policyHolderCreate.gstin,
                        "uin": $scope.policyHolderCreate.uin !== undefined ? $scope.policyHolderCreate.uin.toUpperCase() : $scope.policyHolderCreate.uin,
                        "cityObj": $scope.policyHolderCreate.cityName,
                        "stateObj": $scope.policyHolderCreate.stateName,
                        "pinCode": $scope.policyHolderCreate.pinCode, //CR880
                        "mobileNo": $scope.policyHolderCreate.mobile,
                        "state": $scope.policyHolderCreate.stateName.stateCode,
                        "city": $scope.policyHolderCreate.cityName.cityCode,
                        "emailId": $scope.policyHolderCreate.email,
                        "panNumber": $scope.policyHolderCreate.pan !== undefined ? $scope.policyHolderCreate.pan.toUpperCase() : $scope.policyHolderCreate.pan,
                        "aadhaarNo": $rootScope.policyDetailsObj.aadhaarNumber,
                        "eInsuranceAccountNo": $scope.policyHolderCreate.eInsurance !== undefined ? $scope.policyHolderCreate.eInsurance.toUpperCase() : $scope.policyHolderCreate.eInsurance
                    },
                    "partyType": "I"
                }
            };

        }

        var policyHolderCreateResponse = RestServices.postService(RestServices.urlPathsNewPortal.createPolicyHolder, policyHolderCreateInput);
        policyHolderCreateResponse.then(
            function (response) { // success	
                CommonServices.showLoading(false);
                if (response.data.hasOwnProperty('errorMessage')) {
                    CommonServices.showAlert(response.data.errorMessage);
                } else {
                    CommonServices.policyDetailsObj.createPolicyHolderRes = response.data;
                    CommonServices.policyDetailsObj.policyHolderCreateText = "policyHolderCreated";
                    CommonServices.policyDetailsObj.policyHolderRadio = $scope.policyHolderRadio;
                    $scope.userSelectOnDiv();
                }

            },
            function (error) { // failure
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            });

    };

    /*************** policy hoder search details*******************/
    $scope.topUpPolicyHolderSearch = {};

    //reset Policy holder search details 
    $scope.policyHldrReset = function () {
        $(".form-group").removeClass('focused');
        $scope.topUpPolicyHolderSearch.policyHolderCode = '';
        $scope.topUpPolicyHolderSearch.policyHolderName = '';
        $scope.topUpPolicyHolderSearch.policyHolderLastName = '';
        $scope.topUpPolicyHolderSearch.emailId = '';
        $scope.topUpPolicyHolderSearch.mobileNum = '';

    };

    $scope.policyHolderSearch = function () {
        //if ($scope.topUpPolicyHolderSearch.policyHolderCode !== undefined || $scope.topUpPolicyHolderSearch.policyHolderName !== undefined || $scope.topUpPolicyHolderSearch.policyHolderMiddleName !== undefined || $scope.topUpPolicyHolderSearch.policyHolderLastName !== undefined || $scope.topUpPolicyHolderSearch.emailId !== undefined || $scope.topUpPolicyHolderSearch.mobileNum !== undefined) {
           if ($scope.topUpPolicyHolderSearch.policyHolderCode !== "" || $scope.topUpPolicyHolderSearch.policyHolderName !== "" || $scope.topUpPolicyHolderSearch.policyHolderLastName !== "" || $scope.topUpPolicyHolderSearch.emailId !== "" || $scope.topUpPolicyHolderSearch.mobileNum !== "") {//CR_0044
            $scope.policyHolderSearchCall();
        }else if($rootScope.productName === "UK"){ //CR_0044
        	CommonServices.showAlert("Enter atleast 1 input parameter to proceed with the Policy Holder search.");//CR_0044
        }
           else {
            //alert("Enter minimum one search input criteria.");
            CommonServices.showAlert("Enter minimum one search input criteria.");
        }

    };

    $scope.policyHolderSearchCall = function (data) {
        var policyHolderSearchUppercase = $scope.topUpPolicyHolderSearch.policyHolderCode !== undefined ? $scope.topUpPolicyHolderSearch.policyHolderCode.toUpperCase() : $scope.topUpPolicyHolderSearch.policyHolderCode;

        if ($scope.topUpPolicyHolderSearch.policyHolderCode === "") {
            $scope.topUpPolicyHolderSearch.policyHolderCode = undefined;
        }
        var policyHolderSearchInput = {
            "userProfile": {
                "userId": CommonServices.getCommonData("userId"),
                "loggedInRole": "SUPERUSER"
            },
            "partyDetails": {
                "individualDetails": {
                    "firstName": $scope.topUpPolicyHolderSearch.policyHolderName !== undefined ? $scope.topUpPolicyHolderSearch.policyHolderName.toUpperCase() : $scope.topUpPolicyHolderSearch.policyHolderName,
                    "lastName": $scope.topUpPolicyHolderSearch.policyHolderLastName !== undefined ? $scope.topUpPolicyHolderSearch.policyHolderLastName.toUpperCase() : $scope.topUpPolicyHolderSearch.policyHolderLastName,
                    "emailId": $scope.topUpPolicyHolderSearch.emailId,
                    "mobileNo": $scope.topUpPolicyHolderSearch.mobileNum
                },
                "organizationDetails": {},
                "partyCode": $scope.topUpPolicyHolderSearch.policyHolderCode !== undefined ? $scope.topUpPolicyHolderSearch.policyHolderCode.toUpperCase() : undefined,
                "productCode": $rootScope.productName,
                "partyType": "I"
            },
            "productCode": $rootScope.productName
        };

        var policyHolderSearchRes = RestServices.postService(RestServices.urlPathsNewPortal.searchPolicyHolderDetails, policyHolderSearchInput);
        policyHolderSearchRes.then(
            function (response) { // success	
                CommonServices.showLoading(false);
                if (response.data.hasOwnProperty('footer')) {
                    //alert(response.data.footer.errorDescription);
                    CommonServices.showAlert(response.data.footer.errorDescription);
                } else {
                    CommonServices.policyDetailsObj.policyHolderCreateText = "policyHolderSearch";
                    CommonServices.policyDetailsObj.searchResult = response.data;
                    CommonServices.policyDetailsObj.getPolicyholderDetails = response.data;
                    $rootScope.searchLength = response.data.partyDetailsList.length;
                    if ($rootScope.searchLength === 1) {
                        CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails = response.data.partyDetailsList[0];
                    }
                    CommonServices.policyDetailsObj.policyHolderRadio = $scope.policyHolderRadio;
                    if (data === undefined) {
                        $scope.showPartyDetailsData = true;
                        $scope.showIndividualData = false;
                        $scope.existingcustomerFlag = false;
                        $scope.policyHolderRadio = 'existingCustomer';
                        CommonServices.policyDetailsObj.policyHolderRadio = $scope.policyHolderRadio;
                        $scope.policyHolderSearchResult = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetailsList;
                        CommonServices.policyDetailsObj.saveQuotePolicyHolderCode = response.data.partyDetailsList[0].partyCode;
                    } else {
                        $scope.showIndividualData = true;
                        $scope.getIndividualResult = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetailsList[0];
                        $scope.getIndividualResult.partyCode = CommonServices.policyDetailsObj.createPolicyHolderRes.partyDetails.partyCode;

                    }
                }
            },
            function (error) { // failure
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            }
        );
    };


    if (CommonServices.policyDetailsObj.enableEditModels === "MODELSEDIT") {
        $scope.newcustomerFlag = false;
        $scope.showIndividualData = true;
        $scope.getIndividualResult = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails;
        $scope.getIndividualResult.partyCode = CommonServices.policyDetailsObj.saveQuotePolicyHolderCode;
        $scope.policyHolderRadio = CommonServices.policyDetailsObj.policyHolderRadio;
    }
    $scope.setFieldData = function () {
        if (CommonServices.policyDetailsObj.navigationFrom === "existing" || CommonServices.policyDetailsObj.enableEditModels === "MODELSEDIT") {
            $scope.disableInputField = true;
            $scope.policyHolderRadio = CommonServices.policyDetailsObj.policyHolderRadio;
            /*Added for CR_NP_0744*/
            // To set the values on load of the page
            if ($rootScope.policyDetailsObj.panNoInputDisable == undefined || $rootScope.policyDetailsObj.panNoInputDisable === "") {
                $rootScope.policyDetailsObj.panNoInputDisable = CommonServices.panNoInputDisable;
            }
            /*Below block Commented for CR_NP_0744E */
            // if($rootScope.policyDetailsObj.aadhaarInputDisable == undefined || $rootScope.policyDetailsObj.aadhaarInputDisable == ""){
            // 	$rootScope.policyDetailsObj.aadhaarInputDisable = CommonServices.aadhaarInputDisable;
            // }
            /*CR_NP_0744 and CR_NP_0744E ends*/
            $(".form-group").addClass('focused');
            $scope.pinEnable = false;
            $scope.cityEnable = false;
            $scope.policyHolderCreate.policyHolderName = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.firstName;
            $scope.policyHolderCreate.policyHolderMidName = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.middleName;
            $scope.policyHolderCreate.policyHolderLastName = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.lastName;
            // CR_3618 Third Gender
           // if($rootScope.productName === "CJ") {
                $scope.policyHolderCreate.createPolGender = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.gender;
                console.log("line 2020"+$scope.policyHolderCreate.createPolGender);
            // }else{
            //     $scope.policyHolderCreate.createPolGender = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.gender === "F" ? true : false;
            // }
            $scope.policyHolderCreate.dateOfBirth = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.dateOfBirth;
            $scope.policyHolderCreate.email = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.emailId;
            $scope.policyHolderCreate.pan = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.panNumber;
            $scope.policyHolderCreate.eInsurance = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.eInsuranceAccountNo;
            $scope.policyHolderCreate.buildingStreet = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.buildingNoStreet;
            $scope.policyHolderCreate.gstRegistraionIdType = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.gstRegIdType !== '' ? CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.gstRegIdType : undefined;
            $scope.policyHolderCreate.gstin = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.gstin !== '' ? CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.gstin : undefined;
            $scope.policyHolderCreate.uin = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.uin !== '' ? CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.uin : undefined;
            $scope.policyHolderCreate.stateName = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.stateName.state;
            $scope.policyHolderCreate.cityName = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.cityName.city;
            $scope.policyHolderCreate.pinCode = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.pinCode;
            $scope.policyHolderCreate.mobile = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.mobileNo;
            /*Changed for CR_NP_0744*/
            if (CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.panNumber !== undefined && CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.panNumber !== ""){ //&& $rootScope.regexPanNo.test(CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.panNumber.toUpperCase())) {
                $scope.policyHolderCreate.pan = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.panNumber;
            } else {
                $scope.policyHolderCreate.pan = "";
            }

            /*/3712 Starts////
            // Dummy Data // to be replaced with service response data
            $scope.policyHolderCreate.clientNationality = "NonIndian";
            $scope.policyHolderCreate.clientCountry = "Nepal";

            if($scope.policyHolderCreate.clientNationality = "NonIndian"){
                $scope.isNonIndia = true;
            }else{
                $scope.isNonIndia = false;
            }
            if($scope.policyHolderCreate.clientNationality!=undefined && $scope.policyHolderCreate.clientNationality!=''){
                $scope.isNationalityExists = true;
            }else{
                $scope.isNationalityExists = false;
            }
            if($scope.policyHolderCreate.clientCountry!=undefined && $scope.policyHolderCreate.clientCountry!=''){
                $scope.isCountryExists = true;
            }else{
                $scope.isCountryExists =false;
            }
            //////3712  Ends//////*/

            if (CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.aadhaarNo !== undefined && CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.aadhaarNo !== "" && $rootScope.regexAadhaarNumber.test(CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.aadhaarNo)) {
                $rootScope.policyDetailsObj.aadhaarNumber1 = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.aadhaarNo.substr(0, 4);
                $rootScope.policyDetailsObj.aadhaarNumber2 = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.aadhaarNo.substr(4, 4);
                $rootScope.policyDetailsObj.aadhaarNumber3 = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.aadhaarNo.substr(8, 4);
            } else {
                $rootScope.policyDetailsObj.aadhaarNumber1 = "";
                $rootScope.policyDetailsObj.aadhaarNumber2 = "";
                $rootScope.policyDetailsObj.aadhaarNumber1 = "";
            }
            /*CR_NP_0744 ends*/
            $scope.cityList = CommonServices.policyDetailsObj.editCityRes;
            $scope.allZipCodeList = CommonServices.policyDetailsObj.editZipRes;

        }
    };

    // update policy holder changes
    $scope.policyHolderSave = function () {
        var cityCode, stateCode, pinCode;
        if ($scope.policyHolderCreate.cityName.cityCode !== undefined) {
            cityCode = $scope.policyHolderCreate.cityName.cityCode;
        } else if (CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.hasOwnProperty('cityName')) {
            cityCode = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.cityName.cityCode;
        } else {
            cityCode = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.city;
        }
        if ($scope.policyHolderCreate.stateName.stateCode !== undefined) {
            stateCode = $scope.policyHolderCreate.stateName.stateCode;
        } else if (CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.hasOwnProperty('stateName')) {
            stateCode = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.stateName.stateCode;
        } else {
            stateCode = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.state;
        }
        if ($scope.policyHolderCreate.pinCode.zipCode !== undefined) {
            pinCode = $scope.policyHolderCreate.pinCode.zipCode;
        } else {
            pinCode = $scope.policyHolderCreate.pinCode;
        }
        //CommonServices.policyDetailsObj.saveUpdatePolicyHolder = "Save";

        /*Changed for CR_NP_0744, aadhaar related code commented for CR_NP_0744E*/
        if ($rootScope.policyDetailsObj.aadhaarNumber1 !== undefined && $rootScope.policyDetailsObj.aadhaarNumber1 !== "" && $rootScope.policyDetailsObj.aadhaarNumber2 !== undefined && $rootScope.policyDetailsObj.aadhaarNumber2 !== "" && $rootScope.policyDetailsObj.aadhaarNumber3 !== undefined && $rootScope.policyDetailsObj.aadhaarNumber3 !== "") {
            $rootScope.policyDetailsObj.aadhaarNumber = $rootScope.policyDetailsObj.aadhaarNumber1 + $rootScope.policyDetailsObj.aadhaarNumber2 + $rootScope.policyDetailsObj.aadhaarNumber3;
        } else {
            $rootScope.policyDetailsObj.aadhaarNumber = "";
        }
        if ($rootScope.policyDetailsObj.panNoInputDisable === true) {
            CommonServices.panNoInputDisable = true;
        }
        // if($rootScope.policyDetailsObj.aadhaarInputDisable === true){
        // 	CommonServices.aadhaarInputDisable = true;
        // }
        /*CR_NP_0744 and CR_NP_0744E ends*/
        if ($scope.policyHolderCreate.gstRegistraionIdType !== 'UNB') {
            $scope.policyHolderCreate.uin = undefined;
        }

     /*   if($rootScope.productName === "CJ") { //Sudip CR_3725
            var updatePolicyHolderInput = {
                "userCode": CommonServices.getCommonData("userId"),
                "rolecode": "SUPERUSER",
                "policyHolderCode": CommonServices.policyDetailsObj.saveQuotePolicyHolderCode === undefined ? CommonServices.policyDetailsObj.createPolicyHolderRes.partyDetails.partyCode : CommonServices.policyDetailsObj.saveQuotePolicyHolderCode,
                "mobileNo": $scope.policyHolderCreate.mobile,
                "emailId": $scope.policyHolderCreate.email,
                "dateOfBirth": $scope.policyHolderCreate.dateOfBirth,
                "gstRegIdType": $scope.policyHolderCreate.gstRegistraionIdType === undefined ? '' : $scope.policyHolderCreate.gstRegistraionIdType,
                "gender": $scope.policyHolderCreate.createPolGender,
                "gstin": $scope.policyHolderCreate.gstin === undefined ? '' : $scope.policyHolderCreate.gstin,
                "uin": $scope.policyHolderCreate.uin === undefined ? '' : $scope.policyHolderCreate.uin,
                "city": cityCode,
                "state": stateCode,
                "pinCode": pinCode,
                "panNumber": $scope.policyHolderCreate.pan,
                "aadhaarNo": $rootScope.policyDetailsObj.aadhaarNumber,
                "addressLine1": $scope.policyHolderCreate.buildingStreet
            };
        }else{ */

            if(($rootScope.productName === "NP" || $rootScope.productName === "UK") && CommonServices.floaterObj.memberCoveredInPolicy !== 'N'){
                if(!($scope.ageVerify($scope.policyHolderCreate.dateOfBirth))){
                    CommonServices.showAlert('<p>For any member age more than 50 years the following conditions needs to be satisfied in order to continue: - </p>\
                                            <ol><li>1. A minimum of 3 persons should be covered in the policy.</li>\
                                            <li>2. At least one of the members age should be less than 35 Years.</li></ol>');
                    return;
                }
            }
            var updatePolicyHolderInput = {
                "userCode": CommonServices.getCommonData("userId"),
                "rolecode": "SUPERUSER",
                "policyHolderCode": CommonServices.policyDetailsObj.saveQuotePolicyHolderCode === undefined ? CommonServices.policyDetailsObj.createPolicyHolderRes.partyDetails.partyCode : CommonServices.policyDetailsObj.saveQuotePolicyHolderCode,
                "mobileNo": $scope.policyHolderCreate.mobile,
                "emailId": $scope.policyHolderCreate.email,
                "dateOfBirth": $scope.policyHolderCreate.dateOfBirth,
                /*
                "clientNationality": $scope.policyHolderCreate.clientNationality,//3712
                //"clientCountry": $scope.policyHolderCreate.clientCountry.countryCode,//3712
                "clientCountry": stateCode,//3712
                */
                "gstRegIdType": $scope.policyHolderCreate.gstRegistraionIdType === undefined ? '' : $scope.policyHolderCreate.gstRegistraionIdType,
                "gstin": $scope.policyHolderCreate.gstin === undefined ? '' : $scope.policyHolderCreate.gstin,
                "uin": $scope.policyHolderCreate.uin === undefined ? '' : $scope.policyHolderCreate.uin,
                "city": cityCode,
                "state": stateCode,
                "pinCode": pinCode,
                /*Added for CR_NP_0744*/
                "panNumber": $scope.policyHolderCreate.pan,
                "aadhaarNo": $rootScope.policyDetailsObj.aadhaarNumber,
                /*CR_NP_0744 ends*/
                "addressLine1": $scope.policyHolderCreate.buildingStreet
            };
       // }

        var updatePolicyHolderRes = RestServices.postService(RestServices.urlPathsNewPortal.updatePolicyHolderContact, updatePolicyHolderInput);
        updatePolicyHolderRes.then(
            function (response) { // success	
                CommonServices.showLoading(false);
                if (response.data.hasOwnProperty('footer')) {
                    //alert(response.data.footer.errorDescription);
                    CommonServices.showAlert(response.data.footer.errorDescription);
                } else {

                    if (response.data.hasOwnProperty('errorMessage')) {
                        //alert(response.data.errorMessage);
                        CommonServices.showAlert(response.data.errorMessage);
                    } else {
                        $scope.missingField = false;
                        $scope.newcustomerFlag = false;
                        $scope.disableInputField = false;
                        /* if ($scope.policyHolderRadio === "newCustomer") {
                            $scope.policyHolderRadio = 'newCustomer';
                        } else {
                            $scope.policyHolderRadio = 'existingCustomer';
                        } */
                        $scope.policyHolderRadio = CommonServices.policyDetailsObj.policyHolderRadio;
                        $scope.showIndividualData = true;
                        if ($scope.policyHolderCreate.dateOfBirth !== undefined) {
                            var Arr = $scope.policyHolderCreate.dateOfBirth.split('/');
                            proposerAgeCalculation = Arr[2] + '/' + Arr[1] + '/' + Arr[0]; //mm/dd/yyyy
                            var date = new Date(proposerAgeCalculation);
                            var ageDifMs = Date.now() - date.getTime();
                            var ageDinYrs = new Date(ageDifMs); // miliseconds from epoch
                            ageDinYrs = Math.abs(ageDinYrs.getUTCFullYear() - 1970);
                            ageDinYrs = ageDinYrs.toString();

                            for (var i = 0; i < CommonServices.floaterObj.addedMemberDetails.length; i++) {
                                if ($rootScope.productName==="RK" && (CommonServices.floaterObj.addedMemberDetails[i].riskdetails.relationPolicyHolder.toUpperCase() === "SELF" || CommonServices.floaterObj.addedMemberDetails[i].riskdetails.relationPolicyHolder.toUpperCase() === "PROPOSER")) {
                                    CommonServices.floaterObj.addedMemberDetails[i].riskdetails.dateOfBirth = $scope.policyHolderCreate.dateOfBirth;
                                    CommonServices.floaterObj.addedMemberDetails[i].riskdetails.ageInYrs = ageDinYrs;
                                }else if ($rootScope.productName!=="RK" && CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "SELF" || CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "PROPOSER") {
                                    CommonServices.floaterObj.addedMemberDetails[i].riskDetails.dateOfBirth = $scope.policyHolderCreate.dateOfBirth;
                                    CommonServices.floaterObj.addedMemberDetails[i].riskDetails.ageInYrs = ageDinYrs;
                                }
                            }
                        }
                        CommonServices.policyDetailsObj.getPolicyholderDetails = response.data;
                        CommonServices.stateCodeType = CommonServices.policyDetailsObj.getPolicyholderDetails.state;
                        CommonServices.cityCodeType = CommonServices.policyDetailsObj.getPolicyholderDetails.city;
                        var updatePolicyData = {
                            "savedPartyDetails": {
                                "partyDetails": {
                                    "individualDetails": {
                                        "firstName": $scope.policyHolderCreate.policyHolderName,
                                        "lastName": $scope.policyHolderCreate.policyHolderLastName,
                                        "middleName": $scope.policyHolderCreate.policyHolderMidName,
                                        "gender": $scope.policyHolderCreate.createPolGender,
                                        "dateOfBirth": $scope.policyHolderCreate.dateOfBirth,
                                        "buildingNoStreet": $scope.policyHolderCreate.buildingStreet,
                                        "pinCode": $scope.policyHolderCreate.pinCode,
                                        "mobileNo": $scope.policyHolderCreate.mobile,
                                        "emailId": $scope.policyHolderCreate.email,
                                        "panNumber": $scope.policyHolderCreate.pan,
                                        "eInsuranceAccountNo": $scope.policyHolderCreate.eInsurance,
                                        "gstRegIdType": $scope.policyHolderCreate.gstRegistraionIdType,
                                        "gstin": $scope.policyHolderCreate.gstin,
                                        "uin": $scope.policyHolderCreate.uin,
                                        "city": $scope.policyHolderCreate.cityName,
                                        "state": $scope.policyHolderCreate.stateName,
                                        /*Added for CR_NP_0744*/
                                        "aadhaarNo": $rootScope.policyDetailsObj.aadhaarNumber
                                    }
                                }
                            }
                        };
                        CommonServices.policyDetailsObj.getPolicyholderDetails = updatePolicyData.savedPartyDetails;
                        $scope.getIndividualResult = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails;
                       // console.log("line 2211" +CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.gender);
                        //    CR_3618 third gender
                       // if (CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.gender === true) {
                        //     CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.gender = 'F';
                        // } else {
                        //     CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.gender = 'M';
                        // }
                        $scope.getIndividualResult.partyCode = CommonServices.policyDetailsObj.saveQuotePolicyHolderCode;
                        /* $scope.policyHolderSearchCall(); */
                    }
                }
            },
            function (error) { // failure
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            });

    };

    /*Repeat*/

    function stateServiceCall() {
        var state;
        if (CommonServices.policyDetailsObj.enableEditModels === "MODELSEDIT" && CommonServices.stateCodeType !== undefined) {
            state = CommonServices.stateCodeType;
        } else {
            state = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.state;
        }


        var getStateInput = {
            "state": ""
        };

        var GetStateListResponse = RestServices.postService(RestServices.urlPathsNewPortal.getStateList, getStateInput);
        GetStateListResponse.then(
            function (response) { // success	
                CommonServices.showLoading(false);
                if (response.data.hasOwnProperty('states')) {
                    $scope.stateList = response.data.states;
                    if (state == undefined) {
                        $scope.setFieldData();
                    }

                    for (var i = 0; i < $scope.stateList.length; i++) {
                        if ($scope.stateList[i].stateCode === state) {
                            CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.stateName = $scope.stateList[i];
                            /*CR_NP_0880 Starts */
                            $scope.zipCodeServiceCall();
                            // $scope.cityServicecall();
                            /*CR_NP_0880 Ends */
                        }
                    }
                }
            },
            function (error) { // failure
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            });
    };
    /*CR_NP_0880 Starts */
    $scope.zipCodeServiceCall = function () {
        // city = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.cityName.city;
        state = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.stateName.state;

        var getZipCodeListInput = {
            "state": state,
            // "city": city,
            "zipCode": ""
        }

        var getZipCodeResponse = RestServices.postService(RestServices.urlPathsNewPortal.getZipCodesbyState, getZipCodeListInput);
        getZipCodeResponse.then(
            function (response) { // success	
                CommonServices.showLoading(false);
                if (response.data.hasOwnProperty('pincodes')) {
                    $scope.allZipCodeList = response.data.pincodes;
                    // $scope.allZipCodeList = response.data.pincodes.sort(CommonServices.sort_by('zipCode', response.data.pincodes, ''));
                    CommonServices.policyDetailsObj.editZipRes = $scope.allZipCodeList;
                    // $scope.setFieldData();

                    for (var i = 0; i < $scope.allZipCodeList.length; i++) {
                        if ($scope.allZipCodeList[i] == CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.pinCode) {
                            CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.pinCode = $scope.allZipCodeList[i];
                            $scope.cityServicecall();
                        }

                    }

                }
            },
            function (error) { // failure
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            });
    };

    $scope.cityServicecall = function () {
        if (CommonServices.policyDetailsObj.enableEditModels === "MODELSEDIT" && CommonServices.cityCodeType !== undefined) {
            cityCode = CommonServices.cityCodeType;
            state = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.stateName.state;
            zipCode = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.pinCode;
        } else {
            cityCode = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.city;
            state = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.stateName.state;
            zipCode = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.pinCode;
        }

        var getCityInput = {
            "state": state,
            "zipCode": zipCode,
            //"additionalParameter": "MOBILE",
            "city": ""
        };

        var GetCityListResponse = RestServices.postService(RestServices.urlPathsNewPortal.getCitiesList, getCityInput);
        GetCityListResponse.then(
            function (response) { // success	
                CommonServices.showLoading(false);
                if (response.data.hasOwnProperty('cities')) {
                    $scope.cityList = response.data.cities;
                    // $scope.cityList = response.data.cities.sort(CommonServices.sort_by('city', response.data.cities, ''));
                    CommonServices.policyDetailsObj.editCityRes = $scope.cityList;
                    // $scope.policyHolderCreate.cityName = response.data.cities[0];
                    CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.cityName = response.data.cities[0];
                    $scope.setFieldData();


                    // for (var i = 0; i < $scope.cityList.length; i++) {
                    //     if ($scope.cityList[i].cityCode === cityCode) {
                    //         CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.cityName = $scope.cityList[i];
                    //         CommonServices.policyDetailsObj.state = state;
                    //         CommonServices.policyDetailsObj.city = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.cityName.city;
                    //         if (CommonServices.floaterObj.fecthState === true) {
                    //             CommonServices.floaterObj.fecthState = false;
                    //         } else {
                    //             $scope.zipCodeServiceCall();
                    //         }

                    //     }
                    // }
                }

            },
            function (error) { // failure
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            });

    };
    /*CR_NP_0880 Ends */

    //minimize form
    $scope.minimizeForm = function () {
        $scope.minimize = true;
        $scope.disableInputField = false;
        $scope.newcustomerFlag = false;
        $scope.userSelectOnDiv();

    };

    /* edit */
    $scope.userClickedOnDiv = function (policyData) {
        CommonServices.userClickedOnDivFunc = true;
        $scope.showPartyDetailsData = false;
        $(".form-group").addClass('focused');
        if (policyData !== undefined) {
            CommonServices.policyDetailsObj.saveQuotePolicyHolderCode = policyData.partyCode;
        }

        var topUpGetPolicyHolderDetailInput = {
            "userProfile": {
                "userId": CommonServices.getCommonData("userId"),
                "loggedInRole": "SUPERUSER"
            },
            "partyDetails": {
                "partyCode": policyData.partyCode
            }
        };
        var topUpGetPolicyHolderDetailResponse = RestServices.postService(RestServices.urlPathsNewPortal.getPolicyHolderDetail, topUpGetPolicyHolderDetailInput);
        topUpGetPolicyHolderDetailResponse.then(
            function (response) { // success	

                CommonServices.showLoading(false);
                CommonServices.policyDetailsObj.getPolicyholderDetails = response.data;
                if (CommonServices.editQuoteFlag === true) {
                    CommonServices.floaterObj.partyDetailsList = [];
                    CommonServices.floaterObj.partyDetailsList.push(CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails);
                    CommonServices.floaterObj.partyDetailsList[0].partyCode = policyData.partyCode;
                }
                /*Added for CR_NP_0744*/
                if (CommonServices.policyDetailsObj.policyHolderRadio === "existingCustomer") {

                    //To set the initial value of PAN and Aadhaar Numbers
                    if (CommonServices.initialPartyCode != policyData.partyCode) { //If party code is changed
                        CommonServices.initialPanNumberIsEmpty = false;
                        /*Commented for CR_NP_0744E */
                        //   CommonServices.initialAadhaarNoIsEmpty = false;
                    }
                    CommonServices.initialPartyCode = policyData.partyCode;
                    //For PAN Number
                    if (response.data.partyDetails.individualDetails.panNumber != undefined && response.data.partyDetails.individualDetails.panNumber != "" && $rootScope.regexPanNo.test(response.data.partyDetails.individualDetails.panNumber.toUpperCase())) {
                        $rootScope.policyDetailsObj.panNoInputDisable = true;
                        if (CommonServices.initialPanNumberIsEmptyTU == true) {
                            $rootScope.policyDetailsObj.panNoInputDisable = false;
                        }
                    } else {
                        $rootScope.policyDetailsObj.panNoInputDisable = false;
                        CommonServices.initialPanNumberIsEmptyTU = true;
                    }
                    //For Aadhaar Number, commented for CR_NP_0744E
                    //   if(response.data.partyDetails.individualDetails.aadhaarNo != undefined && response.data.partyDetails.individualDetails.aadhaarNo != "" && $rootScope.regexAadhaarNumber.test(response.data.partyDetails.individualDetails.aadhaarNo)){
                    // 		$rootScope.policyDetailsObj.aadhaarInputDisable = true;
                    // 		if(CommonServices.initialAadhaarNoIsEmptyTU == true){
                    // 			$rootScope.policyDetailsObj.aadhaarInputDisable = false;
                    // 		}
                    // 	}else{
                    // 		$rootScope.policyDetailsObj.aadhaarInputDisable = false;
                    // 		CommonServices.initialAadhaarNoIsEmptyTU = true;
                    // 	}

                } else {
                    $rootScope.policyDetailsObj.panNoInputDisable = false;
                    //   $rootScope.policyDetailsObj.aadhaarInputDisable = false;
                    /*CR_NP_0744E ends */
                }
                /*CR_NP_0744 ends*/
                $scope.fetchDetail = true;
                CommonServices.policyDetailsObj.enableEditModels = "MODELSEDIT";
                /* $scope.missingField=true; */
                stateServiceCall();
                CommonServices.policyDetailsObj.policyHolderCreateText = "policyHolderGet";
                CommonServices.policyDetailsObj.navigationFrom = "existing";
                $scope.showIndividualData = false;
                $scope.newcustomerFlag = true;
                $scope.disableInputField = true;
                $scope.policyHolderRadio = CommonServices.policyDetailsObj.policyHolderRadio;

            },
            function (error) { // failure
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            });
        $scope.selectedPolicyHolderDetails = policyData;
        $scope.selectedDivYes = true;
    };

    $scope.visibleDetails = function () {
        $scope.showIndividualData = true;
        $scope.showPartyDetailsData = false;
    }


    /*select*/
    $scope.userSelectOnDiv = function (index) {
        $scope.newcustomerFlag = false;
        /* if (CommonServices.policyDetailsObj.created === true) {
            $scope.policyHolderRadio = 'newCustomer';
        } else {
            $scope.policyHolderRadio = 'existingCustomer';
        } */
        $scope.policyHolderRadio = CommonServices.policyDetailsObj.policyHolderRadio;
        if (CommonServices.policyDetailsObj.policyHolderCreateText === "policyHolderSearch") {
            CommonServices.policyDetailsObj.saveQuotePolicyHolderCode = index;
        } else if (CommonServices.policyDetailsObj.policyHolderCreateText === "policyHolderCreated") {
            CommonServices.policyDetailsObj.saveQuotePolicyHolderCode = CommonServices.policyDetailsObj.createPolicyHolderRes.partyDetails.partyCode;
        } else if (CommonServices.policyDetailsObj.policyHolderCreateText === "") {

        }
        if($scope.policyHolderSearchResult !== undefined && Array.isArray($scope.policyHolderSearchResult)){
            if(($rootScope.productName === "NP" || $rootScope.productName === "UK") && CommonServices.floaterObj.memberCoveredInPolicy !== 'N'){
                let selectedParty = $scope.policyHolderSearchResult.filter(item=> item.partyCode==index)[0];
                if(!($scope.ageVerify(selectedParty.individualDetails.dateOfBirth))){
                    CommonServices.showAlert('<p>For any member age more than 50 years the following conditions needs to be satisfied in order to continue: - </p>\
                                            <ol><li>1. A minimum of 3 persons should be covered in the policy.</li>\
                                            <li>2. At least one of the members age should be less than 35 Years.</li></ol>');
                    return;
                }
            }
        }

        CommonServices.setCommonData("partyCode", CommonServices.policyDetailsObj.saveQuotePolicyHolderCode);//CR-3738_A pan issue fix
        var topUpGetPolicyHolderDetailInput = {
            "userProfile": {
                "userId": CommonServices.getCommonData("userId"),
                "loggedInRole": "SUPERUSER"
            },
            "partyDetails": {
                "partyCode": CommonServices.policyDetailsObj.saveQuotePolicyHolderCode
            }
        };
        var topUpGetPolicyHolderDetailResponse = RestServices.postService(RestServices.urlPathsNewPortal.getPolicyHolderDetail, topUpGetPolicyHolderDetailInput);
        topUpGetPolicyHolderDetailResponse.then(
            function (response) { // success	
                CommonServices.showLoading(false);
                if (response.data.hasOwnProperty('errorMessage')) {
                    CommonServices.showAlert(response.data.errorMessage);
                    if (CommonServices.editQuoteFlag === true) {
                        if (response.data.errorCode === 959) {
                            $scope.newcustomerFlag = true;
                            $scope.policyHolderRadio = "newCustomer";
                        }
                    }
                } else {

                    CommonServices.policyDetailsObj.getPolicyholderDetails = response.data;
                    CommonServices.policyDetailsObj.pinCode = response.data.partyDetails.individualDetails.pinCode;
                    if ($scope.minimize === true) {
                        $scope.showIndividualData = true;
                        if ($scope.missingField === true) {
                            $scope.showPartyDetailsData = true;
                            $scope.policyHolderSearchResult = CommonServices.policyDetailsObj.searchResult.partyDetailsList;
                        } else {
                            $scope.getIndividualResult = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails;
                            $scope.getIndividualResult.partyCode = CommonServices.policyDetailsObj.saveQuotePolicyHolderCode;
                        }
                    } else {

                        if (response.data.partyDetails.individualDetails.hasOwnProperty('state')) {
                            CommonServices.floaterObj.fecthState = true;
                            stateServiceCall();
                        }
                        if ($scope.policyHolderCreate.cityName !== undefined && $scope.policyHolderCreate.stateName !== undefined) {
                            CommonServices.policyDetailsObj.state = $scope.policyHolderCreate.stateName;
                            CommonServices.policyDetailsObj.city = $scope.policyHolderCreate.cityName;
                        }
                        CommonServices.stateCodeType = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.state;
                        CommonServices.cityCodeType = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.city;


                        $scope.getIndividualResult = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails;
                        $scope.getIndividualResult.partyCode = CommonServices.policyDetailsObj.saveQuotePolicyHolderCode;

                        if (CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.dateOfBirth !== undefined) {
                            CommonServices.floaterObj.SelfDOBPolicyHolder = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.dateOfBirth;
                            var proposerAgeCalculation = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.dateOfBirth;

                            //Code commenting due to date calculation error years+364days
                            // var Arr = proposerAgeCalculation.split('/');
                            // proposerAgeCalculation = Arr[2] + '/' + Arr[1] + '/' + Arr[0]; //mm/dd/yyyy
                            // var date = new Date(proposerAgeCalculation);
                            // var ageDifMs = Date.now() - date.getTime();
                            // var ageDinYrs = new Date(ageDifMs); // miliseconds from epoch
                            // ageDinYrs = Math.abs(ageDinYrs.getUTCFullYear() - 1970);
                            // ageDinYrs = ageDinYrs.toString();

                            ageDinYrs = $scope.getAge(proposerAgeCalculation); //CR3738_A/B
                        }

                        for (var i = 0; i < CommonServices.floaterObj.addedMemberDetails.length; i++) {
                            if ($rootScope.productName==='RK' && (CommonServices.floaterObj.addedMemberDetails[i].riskdetails.relationPolicyHolder.toUpperCase() === "SELF" || CommonServices.floaterObj.addedMemberDetails[i].riskdetails.relationPolicyHolder.toUpperCase() === 'PROPOSER')) {
                                CommonServices.floaterObj.SelfDOB = CommonServices.floaterObj.addedMemberDetails[i].riskdetails.dateOfBirth;
                                CommonServices.floaterObj.proposerGender = CommonServices.floaterObj.addedMemberDetails[i].riskdetails.sex; //Sudip CR_3725
                                CommonServices.floaterObj.addedMemberDetails[i].riskdetails.dateOfBirth = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.dateOfBirth;
                                CommonServices.floaterObj.policyHolderCode = CommonServices.policyDetailsObj.saveQuotePolicyHolderCode;
                                CommonServices.floaterObj.policyHolderName = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.firstName+ " " +CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.lastName;  
                                
                                if (CommonServices.editQuoteFlag === true) {
                                    CommonServices.floaterObj.addedMemberDetails[i].riskParty = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.partyCode;
                                    //$scope.proposerOcc = CommonServices.floaterObj.addedMemberDetails[i].riskdetails.occupation;
                                }
                            }else if ($rootScope.productName!=='RK' && (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "SELF" || CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PROPOSER')) {
                                CommonServices.floaterObj.SelfDOB = CommonServices.floaterObj.addedMemberDetails[i].riskDetails.dateOfBirth;
                                CommonServices.floaterObj.proposerGender = CommonServices.floaterObj.addedMemberDetails[i].riskDetails.sex; //Sudip CR_3725
                                CommonServices.floaterObj.addedMemberDetails[i].riskDetails.dateOfBirth = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.dateOfBirth;
                                CommonServices.floaterObj.addedMemberDetails[i].riskDetails.ageInYrs = ageDinYrs;
                               // CommonServices.floaterObj.addedMemberDetails[i].riskDetails.gender = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.gender; //Sudip CR_3725
                                CommonServices.floaterObj.addedMemberDetails[i].riskDetails.sex = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.gender; //Sourav 01.11.2019

                                if (CommonServices.editQuoteFlag === true) {
                                    CommonServices.floaterObj.addedMemberDetails[i].riskParty = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.partyCode;
                                    //$scope.proposerOcc = CommonServices.floaterObj.addedMemberDetails[i].riskDetails.occupation;
                                }
                            }
                        }
                        if (CommonServices.editQuoteFlag === true) {
                            CommonServices.floaterObj.partyDetailsList = [];
                            CommonServices.floaterObj.partyDetailsList.push(CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails);

                            $scope.getIndividualResult = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails;
                            $scope.getIndividualResult.partyCode = CommonServices.policyDetailsObj.saveQuotePolicyHolderCode;
                            if ($rootScope.searchLength >= 1) {
                                if (CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.hasOwnProperty('dateOfBirth')) {

                                    if (CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.state === undefined || CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.city === undefined || CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.pinCode === undefined) {
                                        $scope.missingField = true;
                                        CommonServices.showAlert("Please update mandatory Policy Holder Details");
                                    } else {
										if(CommonServices.floaterObj.memberCoveredInPolicy === 'N'){
											for (var i = 0; i < CommonServices.floaterObj.addedMemberDetails.length; i++) {
											if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "SELF" || CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PROPOSER') {
                                            CommonServices.floaterObj.SelfDOB = CommonServices.floaterObj.addedMemberDetails[i].riskDetails.dateOfBirth;
                                            CommonServices.floaterObj.proposerGender = CommonServices.floaterObj.addedMemberDetails[i].riskDetails.sex; //Sudip CR_3725
											CommonServices.floaterObj.addedMemberDetails[i].riskDetails.dateOfBirth = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.dateOfBirth;
                                            CommonServices.floaterObj.addedMemberDetails[i].riskDetails.ageInYrs = ageDinYrs;
                                           //  CommonServices.floaterObj.addedMemberDetails[i].riskDetails.gender = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.gender; //Sudip CR_3725
                                            CommonServices.floaterObj.addedMemberDetails[i].riskDetails.sex = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.gender; //Sourav 01.11.2019

											}
											}
                                            CommonServices.policyDetailsObj.policyHolderRadio = $scope.policyHolderRadio;
                                            
                                            //RAK CR_3547
                                            if($rootScope.productName === "RK"){
                                                $state.go("rakProposerDetails");
                                            }
                                            else{
                                                $state.go("proposerDetailsHealth");
                                            }	
                                        }else if (ageDinYrs >= 18 && ((ageDinYrs <= 50 && $rootScope.productName!=='UK' && $rootScope.productName!=='NP') || (ageDinYrs <= 60 && ($rootScope.productName=='UK' || $rootScope.productName=='NP')))) {
												if (CommonServices.floaterObj.SelfDOB !== undefined) {
													if (CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.dateOfBirth !== CommonServices.floaterObj.SelfDOB) {
														CommonServices.showAlert("There is a mismatch between the Date of Birth entered for Proposer and Policy Holder. Please note that the Date of Birth entered in the Policy holder/Personal information shall be considered");
													}
												}
                                                CommonServices.policyDetailsObj.policyHolderRadio = $scope.policyHolderRadio;
                                                 //RAK CR_3547
                                            if($rootScope.productName === "RK"){
                                                $state.go("rakProposerDetails");
                                            }
                                            else{
                                                $state.go("proposerDetailsHealth");
                                            }
											//	$state.go("proposerDetailsHealth");
										} else {//sourav change 4.10.2019 
                                            if($rootScope.productName === "CJ" || $rootScope.productName === "CZ"){
												CommonServices.showAlert("Age of policy holder should be between 18 and 65 years.");
                                            }
                                            else if($rootScope.productName === "UK" || $rootScope.productName === "NP"){ //CR3738A
                                                CommonServices.showAlert("Age of policy holder should be between 18 and 60 years.");
                                            }else{
                                                CommonServices.showAlert("Age of policy holder should be between 18 and 50 years.");
                                            }
										}
									}
                                        
                                }
                                else {
                                    if($rootScope.productName === "CJ" || $rootScope.productName === "CZ"){
                                        CommonServices.showAlert("Age of policy holder should be between 18 and 65 years.");
                                        $scope.missingField = true;
                                    }else if($rootScope.productName === "UK" || $rootScope.productName === "NP"){ //CR3738A
                                        CommonServices.showAlert("Age of policy holder should be between 18 and 60 years.");
                                    }else{
                                        CommonServices.showAlert("Age of policy holder should be between 18 and 50 years.");
                                        $scope.missingField = true;
                                    }
                                }
                            }
                            $scope.showIndividualData = true; //To show individual data
                            $scope.showPartyDetailsData = false; // To clear the search result

                            //CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.occupation = 	$scope.proposerOcc;								
                        }
                        else if (CommonServices.policyDetailsObj.policyHolderCreateText !== "policyHolderCreated") {


                            if (CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.hasOwnProperty('dateOfBirth')) {

                                if (CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.state === undefined || CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.city === undefined || CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.pinCode === undefined) {
                                    $scope.missingField = true;
                                    CommonServices.showAlert("Please update mandatory Policy Holder Details");
                                } else {
									if(CommonServices.floaterObj.memberCoveredInPolicy === 'N'){
										for (var i = 0; i < CommonServices.floaterObj.addedMemberDetails.length; i++) {
										if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "SELF" || CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PROPOSER') {
										CommonServices.floaterObj.SelfDOB = CommonServices.floaterObj.addedMemberDetails[i].riskDetails.dateOfBirth;
										CommonServices.floaterObj.addedMemberDetails[i].riskDetails.dateOfBirth = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.dateOfBirth;
										CommonServices.floaterObj.addedMemberDetails[i].riskDetails.ageInYrs = ageDinYrs;

										}
										}
                                    CommonServices.policyDetailsObj.policyHolderRadio = $scope.policyHolderRadio;
                                    //RAK CR_3547
                                    if($rootScope.productName === "RK"){
                                        $state.go("rakProposerDetails");
                                    }
                                    else{
                                        $state.go("proposerDetailsHealth");
                                    }	
									//$state.go("proposerDetailsHealth");
                                    }else if (ageDinYrs >= 18 && ((ageDinYrs <= 50 && $rootScope.productName !== "CJ" && $rootScope.productName !== "CZ" && $rootScope.productName!=='UK' && $rootScope.productName!=='NP') || (ageDinYrs <= 60 && ($rootScope.productName=='UK' || $rootScope.productName=='NP')))) { //CR3738_A/B
                                        if (CommonServices.floaterObj.SelfDOB !== undefined) {
                                            if (CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.dateOfBirth !== CommonServices.floaterObj.SelfDOB) {
                                                CommonServices.showAlert("There is a mismatch between the Date of Birth entered for Proposer and Policy Holder. Please note that the Date of Birth entered in the Policy holder/Personal information shall be considered");
                                            }
                                        }
                                        CommonServices.policyDetailsObj.policyHolderRadio = $scope.policyHolderRadio;
                                        //RAK CR_3547
                                        if($rootScope.productName === "RK"){
                                            $state.go("rakProposerDetails");
                                        }
                                        else{
                                            $state.go("proposerDetailsHealth");
                                        }	
                                      //  $state.go("proposerDetailsHealth");
                                        // $rootScope.productName === "CJ"
                                    } else if ((ageDinYrs >= 18 && ageDinYrs <= 65 && ($rootScope.productName === "CJ" || $rootScope.productName === "CZ")) && ((CommonServices.floaterObj.proposerGender === 'M' || CommonServices.floaterObj.proposerGender === 'F' || CommonServices.floaterObj.proposerGender === 'T') && $rootScope.productName === "CJ" || $rootScope.productName === "CZ")) { //Sudip CR_3725
                                        if (CommonServices.floaterObj.SelfDOB !== undefined) { //Sudip CR_3725
                                            if (CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.dateOfBirth !== CommonServices.floaterObj.SelfDOB) {
                                                CommonServices.showAlert("There is a mismatch between the Date of Birth entered for Proposer and Policy Holder. Please note that the Date of Birth entered in the Policy holder/Personal information shall be considered");
                                            }else if(CommonServices.floaterObj.proposerGender !== undefined){ //Sudip CR_3725
                                                if (CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.gender !== CommonServices.floaterObj.proposerGender) {
                                                    CommonServices.showAlert("There is a mismatch between the Gender entered for Proposer and Policy Holder which may cause changes in premium. Please note that the Gender entered in the Policy holder/Personal information shall be considered for premium calculation");
                                                }
                                            }
                                        }
                                        CommonServices.policyDetailsObj.policyHolderRadio = $scope.policyHolderRadio;
                                        $state.go("proposerDetailsHealth");
                                        // $rootScope.productName === "CJ"
                                    }/*else if (proposerGender === 'M' || proposerGender === 'F' || proposerGender === 'T' && $rootScope.productName === "CJ") { //Sudip CR_3725
                                        if (CommonServices.floaterObj.proposerGender !== undefined) {
                                            if (CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.gender !== CommonServices.floaterObj.proposerGender) {
                                                CommonServices.showAlert("There is a mismatch between the gender entered for Proposer and Policy Holder. Please note that the gender entered in the Policy holder/Personal information shall be considered");
                                            }
                                        }
                                        CommonServices.policyDetailsObj.policyHolderRadio = $scope.policyHolderRadio;
                                        $state.go("proposerDetailsHealth");
                                        // $rootScope.productName === "CJ"
                                    }*/else {
                                        if($rootScope.productName === "CJ" || $rootScope.productName === "CZ"){
                                            CommonServices.showAlert("Age of policy holder should be between 18 and 65 years.");
                                        }else if($rootScope.productName === "UK" || $rootScope.productName === "NP"){ //CR3738A
                                            CommonServices.showAlert("Age of policy holder should be between 18 and 60 years.");
                                        }else{
                                            CommonServices.showAlert("Age of policy holder should be between 18 and 50 years.");
                                        }
                                        
                                    }
                                }
                            } 
							else {
                                if($rootScope.productName === "CJ" || $rootScope.productName === "CZ"){
                                    CommonServices.showAlert("Age of policy holder should be between 18 and 65 years.");
                                    $scope.missingField = true;
                                }else if($rootScope.productName === "UK" || $rootScope.productName === "NP"){ //CR3738A
                                    CommonServices.showAlert("Age of policy holder should be between 18 and 60 years.");
                                }else{
                                    CommonServices.showAlert("Age of policy holder should be between 18 and 50 years.");
                                    $scope.missingField = true;
                                }                                
                            }
                        } else {//sourav change on 8.10.2019 to handle 50 years error for cancer policy
                            if ($rootScope.searchLength === 1 && ($rootScope.productName === "CJ" || $rootScope.productName === "CZ")) {
                                if (ageDinYrs >= 18 && ageDinYrs <= 65) {
                                    CommonServices.policyDetailsObj.policyHolderRadio = $scope.policyHolderRadio;
                                    $state.go("proposerDetailsHealth");
                                } else {
                                    CommonServices.showAlert("Age of policy holder should be between 18 and 65 years.");
                                }
                            }
                            else if ($rootScope.searchLength === 1 && ($rootScope.productName != "CJ" || $rootScope.productName !== "CZ")) {
                                if (ageDinYrs >= 18 && ageDinYrs <= 50) {
                                    CommonServices.policyDetailsObj.policyHolderRadio = $scope.policyHolderRadio;
                                     //RAK CR_3547
                                     if($rootScope.productName === "RK"){
                                        $state.go("rakProposerDetails");
                                    }
                                    else{
                                        $state.go("proposerDetailsHealth");
                                    }
                                   // $state.go("proposerDetailsHealth");
                                }else if($rootScope.productName === "UK" || $rootScope.productName === "NP"){ //CR3738A
                                    CommonServices.showAlert("Age of policy holder should be between 18 and 60 years.");
                                }else {
                                    CommonServices.showAlert("Age of policy holder should be between 18 and 50 years.");
                                }
                            } else if ($scope.missingField === false) {
                                $scope.visibleDetails();
                            }
                        }
                    }
                    $scope.minimize = false;
                }

            },
            function (error) { // failure
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            });

    };

    $scope.getAge = function(dateString) { //CR3738_A/B
        if(dateString){

            var today = new Date();
            var ageArr = dateString.split('/');
            ageCal = ageArr[2] + '/' + ageArr[1] + '/' + ageArr[0]; //mm/dd/yyyy
            var birthDate = new Date(ageCal);
            var age = today.getFullYear() - birthDate.getFullYear();
            var m = today.getMonth() - birthDate.getMonth();
            if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
                age--;
            }
            return age;
        }else{
            return NaN;
        }
    }

    $scope.proposerDetailScreen = function () {
        var proposerAgeCalculation = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.dateOfBirth;
        //commenting code due to years+364days validation failed
        // var Arr = proposerAgeCalculation.split('/');
        // proposerAgeCalculation = Arr[2] + '/' + Arr[1] + '/' + Arr[0]; //mm/dd/yyyy
        // var date = new Date(proposerAgeCalculation);
        // var ageDifMs = Date.now() - date.getTime();
        // var ageDinYrs = new Date(ageDifMs); // miliseconds from epoch
        // ageDinYrs = Math.abs(ageDinYrs.getUTCFullYear() - 1970);
        // ageDinYrs = ageDinYrs.toString();

        ageDinYrs = $scope.getAge(proposerAgeCalculation); //CR3738_A/B

        CommonServices.floaterObj.SelfDOBPolicyHolder = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.dateOfBirth;
        //CR_3725 Sourav 24.09.2019
        // CommonServices.floaterObj.SelfGenderPolicyHolder = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.gender;

        if ($scope.policyHolderCreate.cityName !== undefined && $scope.policyHolderCreate.cityName != "" && $scope.policyHolderCreate.stateName !== undefined && $scope.policyHolderCreate.stateName !="") {
            CommonServices.policyDetailsObj.state = $scope.policyHolderCreate.stateName.state;
            CommonServices.policyDetailsObj.city = $scope.policyHolderCreate.cityName.city; //CR_NP_0880
            CommonServices.policyDetailsObj.pinCode = $scope.policyHolderCreate.pinCode;
        }
        CommonServices.policyDetailsObj.policyHolderRadio = $scope.policyHolderRadio;
        if (CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.hasOwnProperty('dateOfBirth')) {
            if (CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.state === undefined || CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.city === undefined || CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.pinCode === undefined) {
                $scope.missingField = true;
                CommonServices.showAlert("Please update mandatory Policy Holder Details");
            } 
            else if($rootScope.productName === "CJ" || $rootScope.productName === "CZ"){//sourav change 4.10.2019 to handle 50 years issue for cancer
				if(CommonServices.floaterObj.memberCoveredInPolicy === 'N'){
					for (var i = 0; i < CommonServices.floaterObj.addedMemberDetails.length; i++) {
                            if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "SELF" || CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PROPOSER') {
                                CommonServices.floaterObj.SelfDOB = CommonServices.floaterObj.addedMemberDetails[i].riskDetails.dateOfBirth;
                                CommonServices.floaterObj.addedMemberDetails[i].riskDetails.dateOfBirth = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.dateOfBirth;
                                CommonServices.floaterObj.addedMemberDetails[i].riskDetails.ageInYrs = ageDinYrs;
                                
                            }
                        }
					CommonServices.policyDetailsObj.policyHolderRadio = $scope.policyHolderRadio;
                    $state.go("proposerDetailsHealth");
				}
                else if (ageDinYrs >= 18 && ageDinYrs <= 65) {
                    if (CommonServices.floaterObj.SelfDOB !== undefined) {
                        if (CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.dateOfBirth !== CommonServices.floaterObj.SelfDOB) {
                            CommonServices.showAlert("There is a mismatch between the Date of Birth entered for Proposer and Policy Holder. Please note that the Date of Birth entered in the Policy holder/Personal information shall be considered");
                        }
                    }
                    CommonServices.policyDetailsObj.policyHolderRadio = $scope.policyHolderRadio;
                    $state.go("proposerDetailsHealth");
                } else {
                    CommonServices.showAlert("Age of policy holder should be between 18 and 65 years.");
                }
            }else if($rootScope.productName === "RK"){//RAK
				if(CommonServices.floaterObj.memberCoveredInPolicy === 'N'){
					for (var i = 0; i < CommonServices.floaterObj.addedMemberDetails.length; i++) {
                            if (CommonServices.floaterObj.addedMemberDetails[i].riskdetails.relationPolicyHolder.toUpperCase() === "SELF" || CommonServices.floaterObj.addedMemberDetails[i].riskdetails.relationPolicyHolder.toUpperCase() === 'PROPOSER') {
                                CommonServices.floaterObj.SelfDOB = CommonServices.floaterObj.addedMemberDetails[i].riskdetails.dateOfBirth;
                                CommonServices.floaterObj.addedMemberDetails[i].riskdetails.dateOfBirth = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.dateOfBirth;
                                CommonServices.floaterObj.addedMemberDetails[i].riskdetails.ageInYrs = ageDinYrs;
                                
                            }
                        }
					CommonServices.policyDetailsObj.policyHolderRadio = $scope.policyHolderRadio;
                    $state.go("rakProposerDetails");
				}
                else if (ageDinYrs >= 18 && ageDinYrs <= 80) {
                    if (CommonServices.floaterObj.SelfDOB !== undefined) {
                        if (CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.dateOfBirth !== CommonServices.floaterObj.SelfDOB) {
                            CommonServices.showAlert("There is a mismatch between the Date of Birth entered for Proposer and Policy Holder. Please note that the Date of Birth entered in the Policy holder/Personal information shall be considered");
                        }
                    }
                    CommonServices.policyDetailsObj.policyHolderRadio = $scope.policyHolderRadio;
                    $state.go("rakProposerDetails");
                } else {
                    CommonServices.showAlert("Age of policy holder should be between 18 and 80 years.");
                }
            } else {
				if(CommonServices.floaterObj.memberCoveredInPolicy === 'N'){
					for (var i = 0; i < CommonServices.floaterObj.addedMemberDetails.length; i++) {
                            if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "SELF" || CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PROPOSER') {
                                CommonServices.floaterObj.SelfDOB = CommonServices.floaterObj.addedMemberDetails[i].riskDetails.dateOfBirth;
                                CommonServices.floaterObj.addedMemberDetails[i].riskDetails.dateOfBirth = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.dateOfBirth;
                                CommonServices.floaterObj.addedMemberDetails[i].riskDetails.ageInYrs = ageDinYrs;
                                
                            }
                        }
					CommonServices.policyDetailsObj.policyHolderRadio = $scope.policyHolderRadio;
                    $state.go("proposerDetailsHealth");
                }else if (ageDinYrs >= 18 && ((ageDinYrs <= 50 && $rootScope.productName!=='UK' && $rootScope.productName!=='NP') || (ageDinYrs <= 60 && ($rootScope.productName=='UK' || $rootScope.productName=='NP')))) {
                    if (CommonServices.floaterObj.SelfDOB !== undefined) {
                        if (CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.dateOfBirth !== CommonServices.floaterObj.SelfDOB) {
                            CommonServices.showAlert("There is a mismatch between the Date of Birth entered for Proposer and Policy Holder. Please note that the Date of Birth entered in the Policy holder/Personal information shall be considered");
                        }
                    }
                    CommonServices.policyDetailsObj.policyHolderRadio = $scope.policyHolderRadio;
                    $state.go("proposerDetailsHealth");
                } else {
                    if($rootScope.productName=='UK' || $rootScope.productName=='NP'){ //CR3738A
                        CommonServices.showAlert("Age of policy holder should be between 18 and 60 years.");
                    }else{
                        CommonServices.showAlert("Age of policy holder should be between 18 and 50 years.");
                    }
                }
            }
        } else {
            if($rootScope.productName === "CJ" || $rootScope.productName === "CZ"){
                CommonServices.showAlert("Age of policy holder should be between 18 and 65 years.");
                $scope.missingField = true;
            }else if($rootScope.productName === "UK" || $rootScope.productName === "NP"){ //CR3738A
                CommonServices.showAlert("Age of policy holder should be between 18 and 60 years.");
                $scope.missingField = true;
            }
            else{
                CommonServices.showAlert("Age of policy holder should be between 18 and 50 years.");
                $scope.missingField = true;
            }
           
        }	

    };
    if ($rootScope.backFlag === "premCal") {
        if (CommonServices.policyDetailsObj.saveQuotePolicyHolderCode !== undefined) {
            CommonServices.policyDetailsObj.enableEditModels = "";


            if (CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails !== undefined && CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails !== "") {
                $scope.policyHolderRadio = CommonServices.policyDetailsObj.policyHolderRadio;
                $scope.showIndividualData = true;
                $scope.existingcustomerFlag = false;
                $scope.newcustomerFlag = false;
                $scope.getIndividualResult = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails;
                $scope.getIndividualResult.partyCode = CommonServices.policyDetailsObj.saveQuotePolicyHolderCode;
            }

            $scope.disableInputField = false;
        }
    }
    if ($rootScope.backFlag === "policyHolder") {
        $scope.policyHolderRadio = CommonServices.policyDetailsObj.policyHolderRadio;
        CommonServices.policyDetailsObj.enableEditModels = "";
        CommonServices.policyDetailsObj.navigationFrom = "";
        $scope.existingcustomerFlag = false;
        $scope.newcustomerFlag = false;
        $scope.showIndividualData = true;
        $scope.disableInputField = false;
        $scope.getIndividualResult = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails;
        $scope.getIndividualResult.partyCode = CommonServices.policyDetailsObj.saveQuotePolicyHolderCode;
    }

    if (CommonServices.editQuoteFlag === true) {
        var getConfigurationDataInput = { "keys": ["CalculatePremium_self"] };
        var getConfigurationDataResponse = RestServices.postService(RestServices.urlPathsNewPortal.getConfigurationData, getConfigurationDataInput);
        getConfigurationDataResponse.then(
            function (response) { // success	
                CommonServices.showLoading(false);

                $scope.riskParty = response.data.configurableDatas[0].value;
                for (var i = 0; i < CommonServices.floaterObj.addedMemberDetails.length; i++) {
                    if ($rootScope.productName === "UK") {
                        for (var j = 0; j < CommonServices.floaterObj.partyDetailsList.length; j++) {
                            if (CommonServices.floaterObj.partyDetailsList[j].partyStakeCode === 'POLICY-HOL') {
                                CommonServices.policyDetailsObj.saveQuotePolicyHolderCode = CommonServices.floaterObj.partyDetailsList[j].partyCode;
                                CommonServices.policyDetailsObj.EditPolicyHolderCode = CommonServices.floaterObj.partyDetailsList[j].partyCode;
                                $scope.userSelectOnDiv(CommonServices.floaterObj.partyDetailsList[j].partyCode);
                                if (CommonServices.policyDetailsObj.policyHolderRadio === undefined) {
                                    CommonServices.policyDetailsObj.policyHolderRadio = "existingCustomer";
                                    $scope.policyHolderRadio = "existingCustomer";
                                }
                                return;
                            }
                        }
                    }else if ($rootScope.productName === "CJ") {
                        for (var j = 0; j < CommonServices.floaterObj.partyDetailsList.length; j++) {
                            if (CommonServices.floaterObj.partyDetailsList[j].partyStakeCode === 'POLICY-HOL') {
                                CommonServices.policyDetailsObj.saveQuotePolicyHolderCode = CommonServices.floaterObj.partyDetailsList[j].partyCode;
                                CommonServices.policyDetailsObj.EditPolicyHolderCode = CommonServices.floaterObj.partyDetailsList[j].partyCode;
                                $scope.userSelectOnDiv(CommonServices.floaterObj.partyDetailsList[j].partyCode);
                                if (CommonServices.policyDetailsObj.policyHolderRadio === undefined) {
                                    CommonServices.policyDetailsObj.policyHolderRadio = "existingCustomer";
                                    $scope.policyHolderRadio = "existingCustomer";
                                }
                                return;
                            }
                        }
                    } else if ($rootScope.productName === "RK") {
                        for (var j = 0; j < CommonServices.floaterObj.partyDetailsList.length; j++) {
                            if (CommonServices.floaterObj.partyDetailsList[j].partyStakeCode === 'POLICY-HOL') {
                                CommonServices.policyDetailsObj.saveQuotePolicyHolderCode = CommonServices.floaterObj.partyDetailsList[j].partyCode;
                                CommonServices.policyDetailsObj.EditPolicyHolderCode = CommonServices.floaterObj.partyDetailsList[j].partyCode;
                                $scope.userSelectOnDiv(CommonServices.floaterObj.partyDetailsList[j].partyCode);
                                if (CommonServices.policyDetailsObj.policyHolderRadio === undefined) {
                                    CommonServices.policyDetailsObj.policyHolderRadio = "existingCustomer";
                                    $scope.policyHolderRadio = "existingCustomer";
                                }
                                return;
                            }
                        }
                    }
                    else {
                        if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "SELF") {
                            for (var j = 0; j < CommonServices.floaterObj.partyDetailsList.length; j++) {
                                if (CommonServices.floaterObj.partyDetailsList[j].partyStakeCode === 'POLICY-HOL') {
                                    CommonServices.policyDetailsObj.saveQuotePolicyHolderCode = CommonServices.floaterObj.partyDetailsList[j].partyCode;
                                    CommonServices.policyDetailsObj.EditPolicyHolderCode = CommonServices.floaterObj.partyDetailsList[j].partyCode;
                                    $scope.userSelectOnDiv(CommonServices.floaterObj.partyDetailsList[j].partyCode);
                                    if (CommonServices.policyDetailsObj.policyHolderRadio === undefined) {
                                        CommonServices.policyDetailsObj.policyHolderRadio = "existingCustomer";
                                        $scope.policyHolderRadio = "existingCustomer";
                                    }
                                    return;
                                }
                            }
                        }
                    }
                }
            },
            function (error) { // failure
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            });


    }

}]);
agentApp.controller('proposerDetailsHealthCtrl', ['$scope', 'RestServices', 'CommonServices', '$state', '$rootScope', function ($scope, RestServices, CommonServices, $state, $rootScope) {
    $rootScope.backFlag = "policyHolder";
    $rootScope.searchLength = 0;
    // $scope.additionalDetailsArray = CommonServices.floaterObj.addedMemberDetails;
    $scope.additionalDetailsArray = [];
    $scope.proposerDeatils = [];
    CommonServices.floaterObj.healthshow = [];
    $scope.riskDeatilsForSaveQuoteHealth = [];
    $scope.healthshow = [];
    $scope.regexPanNo = regexPanNoGlobal;//CR3746
    $scope.isNIAPAN = false;//CR3746
    $scope.isValidPAN = false;//CR3746
    $scope.iDDocNoRegexPattern = iDDocNoRegexGlobal;//CR3746
    $scope.notEligible = false;
    $scope.gstinMsg = "GSTIN";  //CR 3749
    $scope.goBack = function () {
        if ($rootScope.productName === "UK" || $rootScope.productName === 'CJ' || $rootScope.productName === 'CZ') {  //CR_3725
            $state.go("floaterBasicPremium");
        }
    };
    if($rootScope.productName==="CZ" && (CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.gender !== CommonServices.floaterObj.addedMemberDetails[0].riskDetails.sex)) {
        CommonServices.showAlert("Proposer Gender Mistach. Please go back and fill Policy Holder Deatils again");
        $scope.go("policyHolderInformation");
    }
    /*CR 3712 starts
	$scope.isNonIndia = false;
	// $scope.additionalDetailsArray[i].clientNationality ="";
	$scope.onNationalityChange = function(i){
		$scope.additionalDetailsArray[i].clientCountry = '';
		if($scope.additionalDetailsArray[i].clientNationality == "NonIndian"){
			$scope.isNonIndia = true;
		}
		else{
			$scope.isNonIndia = false;
		}
	}
    // CR_3712 ends*/
    console.log(CommonServices.floaterObj);
    $scope.onChange = function (data) {
        /*3712 Starts
        if(data === 'country') {
            $scope.showCountryError = true;
        }
        3712 Ends*/
    };

    /*/// 3712 Start/////////////////////
    $scope.countrySelect = function () {
        $scope.showCountryError = false;
    };
    ///// 3712 End///////////////////*/

    /* var countryInputMin = 3;//3712 */
    $scope.result = '';

    $scope.textChanged = function (data,type) {
       
        /* 3712 starts/////////////////
        if(type!=undefined && type === 'country'){
            $scope.result = 'Please enter valid Country by providing at least first 3 characters';
            $scope.showCountryError = true;
            if (data != null && data.length >= countryInputMin) {
                return gstCountryServiceCall(data);
            }
        }
        //3712 ends/////////*/
    };

    /*//// 3712 Starts
    function gstCountryServiceCall(data) {
        var getStateListInput = {
            "state": data.toUpperCase()
        };
        var getStateListResponse = RestServices.postService(RestServices.urlPathsNewPortal.getStateList, getStateListInput);
        return getStateListResponse.then(function (response) { // success
            CommonServices.showLoading(false);
            $scope.showCountryError = true;
            if (response.data.hasOwnProperty('states')) {
                return $scope.stateList = response.data.states;
            } else {
                $scope.stateList = "";
                $scope.result = "No search results found";
                if (data == null) {
                    $scope.showCountryError = false;
                } else {
                    $scope.showCountryError = true;
                }
                return $scope.stateList;
            }

        }, function (error) {
            CommonServices.showLoading(false);
            RestServices.handleWebServiceError(error);
        });
    };
    ////////3712 Ends */
    
 //CR3746
 $scope.onPANNoChange = function () {
    if($scope.policyHolderCreate.pan != undefined){
        $scope.policyHolderCreate.pan = $scope.policyHolderCreate.pan.toUpperCase();
        $scope.isNIAPAN = isNIAPANNo($scope.policyHolderCreate.pan);
    }
    else
        $scope.isNIAPAN = false;
};

$scope.onIDTypeSelect = function (index) {
    $scope.additionalDetailsArray[index].iDDocNo = '';  
    
    // Uncomment for CR_3746
    // if($scope.additionalDetailsArray[index].natureOfId == "PAN" || $scope.additionalDetailsArray[index].natureOfId == "PANCard" || $scope.additionalDetailsArray[index].natureOfId == "PAN Card")
    //     $scope.iDDocNoRegexPattern = regexPanNoGlobal;
    //     if($scope.existingPanNo != undefined){ // 3746 autopopulate starts
    //         $scope.additionalDetailsArray[index].iDDocNo = $scope.existingPanNo;
    //     }// 3746 autopopulate ends
    // else
    {
        $scope.iDDocNoRegexPattern = iDDocNoRegexGlobal;
        $scope.isNIAPAN = false;
}
};
$scope.onIDDocNoChange = function (index,idNo){
    
    // //Uncomment for 3746
    // if($scope.additionalDetailsArray[index].natureOfId == "PAN" || $scope.additionalDetailsArray[index].natureOfId == "PANCard" || $scope.additionalDetailsArray[index].natureOfId == "PAN Card"){
    //     $scope.additionalDetailsArray[index].iDDocNo = $scope.additionalDetailsArray[index].iDDocNo!=undefined? $scope.additionalDetailsArray[index].iDDocNo.toUpperCase(): undefined;
    //     var docNo = $scope.additionalDetailsArray[index].iDDocNo;
    //     $scope.existingPanNo = undefined// 3746 autopopulate

    //     if(docNo != undefined){
    //         if(docNo.length==10){
    //                 $scope.isValidPAN =  (regexPanNoGlobal.test(docNo.toUpperCase()));
                    
    //                 $scope.isNIAPAN = isNIAPANNo($scope.additionalDetailsArray[index].iDDocNo);
    //         }else{
    //             $scope.isValidPAN = false;
    //             $scope.isNIAPAN = false;
    //         }
    //     }else{
    //         $scope.isValidPAN = false;
    //         $scope.isNIAPAN = false;
    //     }
    // }
    // console.log("is pan valid " +docNo+" "+ $scope.isValidPAN);
};

//CR3746
    // $scope.floaterObj;
    var proposerGender, childrenCount = 0, wardCount = 0,//sourav CR_3725
        daughterCount = 0, parentCount = 0, parentInLawCount = 0;
    var guardianCount = 0, parentCount = 0, brotherCount = 0, sisterCount = 0; //CR3738A    

    $scope.valeOccupationOfProposer = function () {
        for (var i = 0; i < $scope.additionalDetailsArray.length; i++) {
            if ($scope.additionalDetailsArray[i].occupation !== "OTHERS" && $scope.additionalDetailsArray[i].occupation !== "Any Other" && $scope.additionalDetailsArray[i].occupation !== "AO") {
                $scope.additionalDetailsArray[i].anyOther = undefined;
            }
        }
    };

    // To get the insured details and display all members details in Proposer details screen
    for (var i = 0; i < CommonServices.floaterObj.addedMemberDetails.length; i++) {
        
        switch(CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase()){
            case "DAUGHTER":
                if ($rootScope.productName === "AK") {
                    daughterCount = daughterCount + 1;
                }
            case "CHILD":
            case "CHILDREN":
                childrenCount++;
                break;
            case "PARENTS":
            case "PARENT":
                parentCount++;
                break;
            case "WARD":
                wardCount++;
                break;
            case "GUARDIAN": 
                guardianCount++;
                break;
            case "BROTHER":
                brotherCount++;
                break;
            case "SISTER":
                sisterCount++;
                break;
            case "PARINLAW":
                parentInLawCount++;
                break;
        }

        // if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "DAUGHTER" || CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder === "CHILD" || CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILDREN") {
        //     if ($rootScope.productName === "AK") {
        //         daughterCount = daughterCount + 1;
        //     } else {
        //         childrenCount = childrenCount + 1;
        //     }
        // }else if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "PARENTS") {
        //     parentCount = parentCount + 1;
        // }else if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "WARD") { //Jit CR_3725
        //     wardCount = wardCount + 1;
        // }else if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "GUARDIAN") { //CR3738A
        //     guardianCount = guardianCount + 1;
        // }else if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "PARENTS") {
        //     parentCount = parentCount + 1;
        // }else if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "BROTHER") {
        //     brotherCount = brotherCount + 1;
        // }else if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "SISTER") {
        //     sisterCount = sisterCount + 1;
        // }else if(CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "PARINLAW"){
        //     parentInLawCount++
        // }
        
        
        $scope.memberCoveredInPolicy = CommonServices.floaterObj.memberCoveredInPolicy;
        
        if ($rootScope.productName === "UK") {
            /*Added for CR_NP_0744E */
            if (CommonServices.editQuoteFlag === true && CommonServices.floaterObj.premiumDetails.serviceTax !== undefined) {
                CommonServices.floaterObj.addedMemberDetails[i].riskDetails.aadhaarChangeMessage = "";
                if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.natureOfId === "AD") {
                    CommonServices.floaterObj.addedMemberDetails[i].riskDetails.aadhaarChangeMessage = "Due to regulatory constraint Aadhaar document cannot be taken online. Please select other available ID";
                    CommonServices.floaterObj.addedMemberDetails[i].riskDetails.natureOfId = "";
                    CommonServices.floaterObj.addedMemberDetails[i].riskDetails.iDDocNo = "";
                }
            }
            //CR_3618
            //gender: (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PROPOSER' && CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.gender === 'F') ? true : false,
            
            //CR_3618 third gender. spouse gender can't be auto calculated
            // fieldDisable: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PROPOSER' ? true : CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder === 'Spouse' ? true : false,

            //gender: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.dependentType === 'UD' ? "F":(CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PROPOSER') ?  CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.gender : (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.sex? CommonServices.floaterObj.addedMemberDetails[i].riskDetails.sex:""),
            $scope.additionalDetailsArray.push({
                name: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PROPOSER' ? CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.firstName + " " + CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.lastName : "",
                relationshipWith: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder,
                occupation: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.occupation !== undefined && CommonServices.floaterObj.addedMemberDetails[i].riskDetails.occupation != "" ? CommonServices.floaterObj.addedMemberDetails[i].riskDetails.occupation : "",
                anyOther: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.ifAnyOtherOccupation !== undefined && CommonServices.floaterObj.addedMemberDetails[i].riskDetails.ifAnyOtherOccupation !== "" ? CommonServices.floaterObj.addedMemberDetails[i].riskDetails.ifAnyOtherOccupation : undefined,
                gender: (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PROPOSER') ?  CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.gender : CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SISTER'? "F":CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'BROTHER'? "M":(CommonServices.floaterObj.addedMemberDetails[i].riskDetails.sex? CommonServices.floaterObj.addedMemberDetails[i].riskDetails.sex:""),
                headerName: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PROPOSER' ? "Proposer" : CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SPOUSE' ? "Spouse" :
                    (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILDREN" || CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILD") ? "Child "+childrenCount :
                        (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "PARENTS") ? "Parent " + parentCount :
                            (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "WARD") ? "Ward " + wardCount :
                                (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "BROTHER") ? "Brother " + brotherCount :
                                    (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "SISTER") ? "Sister " + sisterCount :
                                        (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "GUARDIAN") ? "Guardian " + guardianCount :
                                            (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "PARENTS") ? "Parent " + parentCount :
                                                (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "DAUGHTER") ? "Daughter " + daughterCount : "",
                dependentType: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.dependentType,
                previousPolicyDetails: {
                    company: undefined,
                    currentPolicyNumber: undefined,
                    sumInsured: undefined,
                    inceptionDate: undefined,
                    expiryDate: undefined
                }, //CommonServices.floaterObj.addedMemberDetails[i].riskDetails.dependentType === 'UD' ? true : 
                fieldDisable: ((CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PROPOSER') || (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SISTER') || (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'BROTHER')) ? true : false,
                nameFieldDisable: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PROPOSER' ? true : false,
                showMaternity: ((CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PROPOSER') && (CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.gender === 'F'))? true : false,
                maternityExpense: (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.maternityExpense !== undefined && CommonServices.floaterObj.addedMemberDetails[i].riskDetails.maternityExpense !== "") ? (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.maternityExpense === "Y" ? true : false) : false,
                natureOfId: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.natureOfId !== undefined || CommonServices.floaterObj.addedMemberDetails[i].riskDetails.natureOfId !== "" ? CommonServices.floaterObj.addedMemberDetails[i].riskDetails.natureOfId : "",
                anyOtherId: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.anyOtherId !== undefined && CommonServices.floaterObj.addedMemberDetails[i].riskDetails.anyOtherId !== "" ? CommonServices.floaterObj.addedMemberDetails[i].riskDetails.anyOtherId === "none" ? "" : CommonServices.floaterObj.addedMemberDetails[i].riskDetails.anyOtherId : "",
                iDDocNo: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.iDDocNo !== undefined && CommonServices.floaterObj.addedMemberDetails[i].riskDetails.iDDocNo !== "" ? CommonServices.floaterObj.addedMemberDetails[i].riskDetails.iDDocNo : "",
                aadhaarChangeMessage: (CommonServices.editQuoteFlag === true && CommonServices.floaterObj.premiumDetails.serviceTax !== undefined) ? CommonServices.floaterObj.addedMemberDetails[i].riskDetails.aadhaarChangeMessage : ""
                /* 3712 Starts
                ,
                clientNationality: undefined,//3712
                clientCountry: undefined,//3712
                isNationalityExists: false,//3712
                isCountryExists: false//3712
                // 3712 Ends */
            });
        }else if ($rootScope.productName === 'CJ') { // Jit CR_3725
            console.log(CommonServices.floaterObj);

            console.log($scope.additionalDetailsArray);
            console.log(CommonServices.floaterObj.addedMemberDetails);
                /*Added for CR_NP_0744E */
                if (CommonServices.editQuoteFlag === true && CommonServices.floaterObj.premiumDetails.serviceTax !== undefined) {
                    CommonServices.floaterObj.addedMemberDetails[i].riskDetails.aadhaarChangeMessage = "";
                    if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.natureOfId === "AD") {
                        CommonServices.floaterObj.addedMemberDetails[i].riskDetails.aadhaarChangeMessage = "Due to regulatory constraint Aadhaar document cannot be taken online. Please select other available ID";
                        CommonServices.floaterObj.addedMemberDetails[i].riskDetails.natureOfId = "";
                        CommonServices.floaterObj.addedMemberDetails[i].riskDetails.iDDocNo = "";
                    }
                }
                //CR_3618 third gender
                // fieldDisable: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PROPOSER' ? true : CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder === 'Spouse' ? true : false,
                $scope.additionalDetailsArray.push({
                    name: (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.edit)? CommonServices.floaterObj.addedMemberDetails[i].riskDetails.nameOfInsuredPerson:(CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PROPOSER' || CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SELF') ? CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.firstName + " " + CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.lastName : "",
                    relationshipWith: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder,
                    occupation: (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.edit)? CommonServices.floaterObj.addedMemberDetails[i].riskDetails.occupation:CommonServices.floaterObj.addedMemberDetails[i].riskDetails.occupation !== undefined && CommonServices.floaterObj.addedMemberDetails[i].riskDetails.occupation != "" ? CommonServices.floaterObj.addedMemberDetails[i].riskDetails.occupation : "",
                    anyOther: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.ifAnyOtherOccupation !== undefined && CommonServices.floaterObj.addedMemberDetails[i].riskDetails.ifAnyOtherOccupation !== "" ? CommonServices.floaterObj.addedMemberDetails[i].riskDetails.ifAnyOtherOccupation : undefined,
                    gender:(CommonServices.floaterObj.addedMemberDetails[i].riskDetails.edit)? CommonServices.floaterObj.addedMemberDetails[i].riskDetails.sex:(CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PROPOSER') ?  CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.gender : (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.sex? CommonServices.floaterObj.addedMemberDetails[i].riskDetails.sex:""),//tempGender,//(CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PROPOSER' && CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.gender === 'F') ? true : false,
                    headerName: (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PROPOSER' || CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SELF') ? "Proposer" : CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SPOUSE' ? "Spouse" :
                        (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILDREN") ? "Child "+childrenCount :
                            (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "PARENTS") ? "Parent "+parentCount :
                                (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "WARD") ? "Ward "+wardCount : "",
                    dependentType: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.dependentType,
                    previousPolicyDetails: {
                        company: undefined,
                        currentPolicyNumber: undefined,
                        sumInsured: undefined,
                        inceptionDate: undefined,
                        expiryDate: undefined
                    },
                    fieldDisable: (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PROPOSER' || CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SELF') ? true : false,
                    nameFieldDisable: (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PROPOSER' || CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SELF') ? true : false,
                    showMaternity: (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PROPOSER' || CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SELF') && CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.gender === 'F' ? true : false,
                    maternityExpense: (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.maternityExpense !== undefined && CommonServices.floaterObj.addedMemberDetails[i].riskDetails.maternityExpense !== "") ? (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.maternityExpense === "Y" ? true : false) : false,
                    natureOfId: (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.edit)? CommonServices.floaterObj.addedMemberDetails[i].riskDetails.natureOfId : CommonServices.floaterObj.addedMemberDetails[i].riskDetails.natureOfId !== undefined || CommonServices.floaterObj.addedMemberDetails[i].riskDetails.natureOfId !== "" ? CommonServices.floaterObj.addedMemberDetails[i].riskDetails.natureOfId : "",
                    anyOtherId: (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.edit)? CommonServices.floaterObj.addedMemberDetails[i].riskDetails.anyOtherId : CommonServices.floaterObj.addedMemberDetails[i].riskDetails.anyOtherId !== undefined && CommonServices.floaterObj.addedMemberDetails[i].riskDetails.anyOtherId !== "" ? CommonServices.floaterObj.addedMemberDetails[i].riskDetails.anyOtherId === "none" ? "" : CommonServices.floaterObj.addedMemberDetails[i].riskDetails.anyOtherId : "",
                    iDDocNo: (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.edit)? CommonServices.floaterObj.addedMemberDetails[i].riskDetails.iDDocNo:CommonServices.floaterObj.addedMemberDetails[i].riskDetails.iDDocNo !== undefined && CommonServices.floaterObj.addedMemberDetails[i].riskDetails.iDDocNo !== "" ? CommonServices.floaterObj.addedMemberDetails[i].riskDetails.iDDocNo : "",
                    aadhaarChangeMessage: (CommonServices.editQuoteFlag === true && CommonServices.floaterObj.premiumDetails.serviceTax !== undefined) ? CommonServices.floaterObj.addedMemberDetails[i].riskDetails.aadhaarChangeMessage : "",
                    // CR_3725
                    cumulativeBonus: "0",
                    preExistingDisease: (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.edit)? CommonServices.floaterObj.addedMemberDetails[i].riskDetails.preExistingDisease:CommonServices.floaterObj.addedMemberDetails[i].riskDetails.preExistingDisease !== undefined && CommonServices.floaterObj.addedMemberDetails[i].riskDetails.preExistingDisease !== "" ? CommonServices.floaterObj.addedMemberDetails[i].riskDetails.preExistingDisease : "",
                    // Radio 3725
                    anychangeBowelBladderHabits: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.anyChangeinBowel === "No" ? "N" : "",
                    soreanyWherefortnight: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.aSoreDidnotHealed === "No" ? "N" : "",
                    dischargeBodyOpening: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.unusualBleeding === "No" ? "N" : "",
                    thickeningLumpBreast: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.lumpInTheBreast === "No" ? "N" : "",
                    persistentIndigestion: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.persistentIndigestion === "No" ? "N" : "",
                    obviousChangeWart: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.anyObviousChange === "No" ? "N" : "",
                    coughHoarseness: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.coughOrHoarseness === "No" ? "N" : "",
                    experiencedAbnormal: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.abnormalWeightLoss === "No" ? "N" : "",
                    diagnosedInvestigated: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.underwentChemotherapy === "No" ? "N" : "",
                    parentsSiblingDiagnosed: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.parentsDiagnosedWithCancer === "No" ? "N" : ""
                    /* 3712 Starts
                    ,
                    clientNationality: undefined,//3712
                    clientCountry: undefined,//3712
                    isNationalityExists: false,//3712
                    isCountryExists: false//3712
                    // 3712 Ends */
                });
            
        } else if($rootScope.productName === 'NP'){
            $scope.showCataract = true;
            console.log(CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase());
            console.log(CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.gender);
            $scope.additionalDetailsArray.push({
                name: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SELF' ? CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.firstName + " " + CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.lastName : "",
                relationshipWith: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder,
                occupation: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.occupation !== undefined && CommonServices.floaterObj.addedMemberDetails[i].riskDetails.occupation != "" ? CommonServices.floaterObj.addedMemberDetails[i].riskDetails.occupation : "",
                anyOther: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.ifAnyOtherOccupation !== undefined && CommonServices.floaterObj.addedMemberDetails[i].riskDetails.ifAnyOtherOccupation !== "" ? CommonServices.floaterObj.addedMemberDetails[i].riskDetails.ifAnyOtherOccupation : undefined,
                gender: (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PROPOSER' || CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SELF') ?  CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.gender : CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SISTER'? "F":CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'BROTHER'? "M":(CommonServices.floaterObj.addedMemberDetails[i].riskDetails.sex? CommonServices.floaterObj.addedMemberDetails[i].riskDetails.sex:""),
                headerName:  (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SELF' && CommonServices.floaterObj.memberCoveredInPolicy === 'N') ? "Policy holder/Proposer details" :
                (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SELF' && CommonServices.floaterObj.memberCoveredInPolicy === 'Y') ? "Proposer" :
                    CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SPOUSE' ? "Spouse" :
                        (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILDREN" || CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILD") ? "Child "+childrenCount :
                            (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "PARENTS") ? "Parent "+parentCount :
                                (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "WARD") ? "Ward "+wardCount :
                                    (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "BROTHER") ? "Brother "+brotherCount :
                                        (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "SISTER") ? "Sister "+sisterCount :
                                            (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "GUARDIAN") ? "Guardian "+guardianCount :
                                                (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "PARENTS") ? "Parent "+parentCount :
                                                    (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "DAUGHTER") ? "Daughter "+daughterCount : "",
                dependentType: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.dependentType,
                previousPolicyDetails: {
                    company: undefined,
                    currentPolicyNumber: undefined,
                    sumInsured: undefined,
                    inceptionDate: undefined,
                    expiryDate: undefined
                },//CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SPOUSE' ? true
                fieldDisable: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SELF' ? true : ((CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SISTER') || (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'BROTHER' || CommonServices.floaterObj.addedMemberDetails[i].riskDetails.dependentType ==="UD")) ? true : false,
                nameFieldDisable: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SELF' ? true : false, 
                showMaternity: ((CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SELF') && (CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.gender === 'F') && (CommonServices.floaterObj.memberCoveredInPolicy ==="Y"))? true : false,
                maternityExpense: (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.maternityExpense !== undefined && CommonServices.floaterObj.addedMemberDetails[i].riskDetails.maternityExpense !== "") ? ((CommonServices.floaterObj.addedMemberDetails[i].riskDetails.maternityExpense === "Y" && parseInt(CommonServices.floaterObj.premiumDetails.sumInsured) >= 500000)? true : false) : false,
                cataractLimit: (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.cataractLimit !== undefined && CommonServices.floaterObj.addedMemberDetails[i].riskDetails.cataractLimit !== "") ? ((CommonServices.floaterObj.addedMemberDetails[i].riskDetails.cataractLimit === "Y" && parseInt(CommonServices.floaterObj.premiumDetails.sumInsured) >= 800000)? true : false) : false
                /* 3712 Starts
                ,
                clientNationality: undefined,//3712
                clientCountry: undefined,//3712
                isNationalityExists: false,//3712
                isCountryExists: false//3712
                // 3712 Ends */
            });
            console.log(JSON.stringify($scope.additionalDetailsArray));
        } else if($rootScope.productName === 'CZ'){
            var nameOfInsuredMember = '';
            if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SELF') {
                nameOfInsuredMember = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.firstName + " " + CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.lastName;
            } else if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.nameOfInsuredPerson && /^[a-zA-Z.' ]+$/.test(CommonServices.floaterObj.addedMemberDetails[i].riskDetails.nameOfInsuredPerson)) {
                nameOfInsuredMember = CommonServices.floaterObj.addedMemberDetails[i].riskDetails.nameOfInsuredPerson;
            }
            $scope.additionalDetailsArray.push({
                name: nameOfInsuredMember,
                relationshipWith: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder,
                occupation: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.occupation || '',
                anyOther: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.ifAnyOtherOccupation || null,
                gender: (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PROPOSER' || CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SELF') ?  CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.gender :  (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "DAUGHTER") ? "F": CommonServices.floaterObj.addedMemberDetails[i].riskDetails.dependentType === 'UD' ? "F":(CommonServices.floaterObj.addedMemberDetails[i].riskDetails.sex? CommonServices.floaterObj.addedMemberDetails[i].riskDetails.sex:""),
                headerName: (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SELF') ? "Proposer" :
                                    CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SPOUSE' ? "Spouse" :
                                        (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILD") ? "Child "+ childrenCount :
                                            (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "PARENT") ? "Parent "+ parentCount :
                                                (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "PARINLAW") ? "Parent-in-law "+ parentInLawCount : "",
                   
                dependentType: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.dependentType,
                previousPolicyDetails: {
                    company: undefined,
                    currentPolicyNumber: undefined,
                    sumInsured: undefined,
                    inceptionDate: undefined,
                    expiryDate: undefined
                },
                fieldDisable: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SELF' ? true : (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.dependentType === 'UD' ? true : false),
                nameFieldDisable: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SELF' ? true : false,
                natureOfId: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SELF' ? CommonServices.floaterObj.addedMemberDetails[i].riskDetails.natureOfId : null,
                anyOtherId: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SELF' ? (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.anyOtherId || null) : null, 
                iDDocNo: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SELF' ? CommonServices.floaterObj.addedMemberDetails[i].riskDetails.iDDocNo : null,
            });
        }else {
            $scope.additionalDetailsArray.push({
                name: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SELF' ? CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.firstName + " " + CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.lastName : "",
                relationshipWith: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder,
                occupation: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.occupation !== undefined && CommonServices.floaterObj.addedMemberDetails[i].riskDetails.occupation != "" ? CommonServices.floaterObj.addedMemberDetails[i].riskDetails.occupation : "",
                anyOther: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.ifAnyOtherOccupation !== undefined && CommonServices.floaterObj.addedMemberDetails[i].riskDetails.ifAnyOtherOccupation !== "" ? CommonServices.floaterObj.addedMemberDetails[i].riskDetails.ifAnyOtherOccupation : undefined,
                gender: (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PROPOSER' || CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SELF') ?  CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.gender :  (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "DAUGHTER") ? "F": CommonServices.floaterObj.addedMemberDetails[i].riskDetails.dependentType === 'UD' ? "F":(CommonServices.floaterObj.addedMemberDetails[i].riskDetails.sex? CommonServices.floaterObj.addedMemberDetails[i].riskDetails.sex:""),//tempGender,//(CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SELF' && CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.gender === 'F') ? true : false,
                headerName: (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SELF' && CommonServices.floaterObj.memberCoveredInPolicy === 'N') ? "Policy holder/Proposer details" :
                                (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SELF' && CommonServices.floaterObj.memberCoveredInPolicy === 'Y') ? "Proposer" :
                                    CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SPOUSE' ? "Spouse" :
                                        (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILDREN" || CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILD") ? "Child "+childrenCount :
                                            (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "PARENTS") ? "Parent "+parentCount :
                                                (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "WARD") ? "Ward "+wardCount :
                                                    (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "BROTHER") ? "Brother "+brotherCount :
                                                        (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "SISTER") ? "Sister "+sisterCount :
                                                            (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "GUARDIAN") ? "Guardian "+guardianCount :
                                                                (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "PARENTS") ? "Parent "+parentCount :
                                                                    (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "DAUGHTER") ? "Daughter "+daughterCount : "",
                dependentType: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.dependentType,
                previousPolicyDetails: {
                    company: undefined,
                    currentPolicyNumber: undefined,
                    sumInsured: undefined,
                    inceptionDate: undefined,
                    expiryDate: undefined
                },//CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SPOUSE' ? true
                fieldDisable: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SELF' ? true : CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'DAUGHTER' ? true : CommonServices.floaterObj.addedMemberDetails[i].riskDetails.dependentType === 'UD' ? true : false,
                nameFieldDisable: CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SELF' ? true : false 
                /* 3712 Starts
                ,
                clientNationality: undefined,//3712
                clientCountry: undefined,//3712
                isNationalityExists: false,//3712
                isCountryExists: false//3712
                // 3712 Ends */
            });
        }

        /*////// 3712 Starts
        if(CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SELF' || CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PROPOSER'){
            //Dummy data
            CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.clientNationality = 'NonIndian';
            CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.clientCountry = 'Bhutan';

            //enabling nationality and country fields
            $scope.additionalDetailsArray[i].isNationalityExists = false;
            $scope.additionalDetailsArray[i].isCountryExists = false;

            if(CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.clientNationality!=undefined && CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.clientNationality!=""){
                //disabling nationality fields
                $scope.additionalDetailsArray[i].isNationalityExists = true;
            }

            if(CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.clientCountry!=undefined && CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.clientCountry!=""){
                //disabling country fields
                $scope.additionalDetailsArray[i].isCountryExists = true;
            }

            $scope.additionalDetailsArray[i].clientNationality = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.clientNationality;
            $scope.additionalDetailsArray[i].clientCountry = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.clientCountry;

        }else{
            //enabling nationality and country fields
            $scope.additionalDetailsArray[i].isNationalityExists = false;
            $scope.additionalDetailsArray[i].isCountryExists = false;
        }
        //////// 3712 Ends ////*/

        if ($rootScope.productName === "AK") {
            if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'DAUGHTER') {
                $scope.additionalDetailsArray[i].gender = "F";
                //$scope.additionalDetailsArray[i].gender = true;
                //CR_3618 Third gender
              //  $scope.additionalDetailsArray[i].gender = "Female";
              console.log($scope.additionalDetailsArray[i]);
            }
        }
        console.log($scope.additionalDetailsArray);

        if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.previousPolicyDetails !== undefined && CommonServices.floaterObj.addedMemberDetails[i].riskDetails.previousPolicyDetails !== "") {
            $scope.additionalDetailsArray[i].previousPolicyDetails = CommonServices.floaterObj.addedMemberDetails[i].riskDetails.previousPolicyDetails;
            if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.previousPolicyDetails.whetherYouHadAHealthPolicyInThePast !== undefined && CommonServices.floaterObj.addedMemberDetails[i].riskDetails.previousPolicyDetails.whetherYouHadAHealthPolicyInThePast !== "") {
                if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.previousPolicyDetails.whetherYouHadAHealthPolicyInThePast === "Y") {
                    $scope.additionalDetailsArray[i].health = true;
                }
            }
        }
        /**
         * Added
         * CR 4092 - Corona Kavach Policy
         */
        if(($rootScope.productName === 'CJ' || $rootScope.productName === 'CZ') && CommonServices.editQuoteFlag === true){
            console.log("do nothing");
        } else {
            if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "SPOUSE" || CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "DAUGHTER" || CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILD" || CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILDREN" || CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "PARENTS" || CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "WARD" ||
            CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "GUARDIAN" ||
            CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "PARENTS" ||
            CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "BROTHER" ||
            CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "SISTER") {
                if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.nameOfInsuredPerson !== "NULL" && CommonServices.floaterObj.addedMemberDetails[i].riskDetails.nameOfInsuredPerson !== undefined && CommonServices.floaterObj.addedMemberDetails[i].riskDetails.nameOfInsuredPerson !== "") {
                    $scope.additionalDetailsArray[i].name = CommonServices.floaterObj.addedMemberDetails[i].riskDetails.nameOfInsuredPerson;
                }
                else {
                    $scope.additionalDetailsArray[i].name = "";
                }
    
            }
        }

 /* Start of CR 3746 autopopulate*/         //Uncomment for CR_3746
//  if(CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PROPOSER' || 
//  CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SELF'){
//  $scope.existingPanNo = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.panNumber;
// }
/* End of CR 3746 autopopulate*/
        /**
         * By passed for
         * CR 4092 - Corona Kavach Policy
         */
        if (CommonServices.editQuoteFlag === true && $rootScope.productName !== 'CZ') {
            if ($scope.additionalDetailsArray[i].name !== undefined && $scope.additionalDetailsArray[i].name !== "" && $scope.additionalDetailsArray[i].name !== null) {
                $scope.additionalDetailsArray[i].nameFieldDisable = true;
                $scope.additionalDetailsArray[i].fieldDisable = true;
            }
            else {
                if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.dependentType === 'UD' || CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SPOUSE' || CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "DAUGHTER" || CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "SISTER" || CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "BROTHER") {
                    $scope.additionalDetailsArray[i].fieldDisable = true;
                }
                else {
                    $scope.additionalDetailsArray[i].fieldDisable = false;
                }
            }
        }

        // To get Proposer Gender
        if ($rootScope.productName === "UK") {
            proposerGender = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.gender;//CR_3628 third gender. as now true false logic for gender not valid
            // if (CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.gender === 'F') {
                
            //     proposerGender = true;
            // } else {
            //     proposerGender = false;
            // }
        } else {
            // if ($scope.additionalDetailsArray[i].relationshipWith === 'SELF' && $scope.additionalDetailsArray[i].gender === true) {
            //     proposerGender = true;
            // }
            if ($scope.additionalDetailsArray[i].relationshipWith === 'SELF') {
                proposerGender = $scope.additionalDetailsArray[i].gender;
            }
        }

    }
    $scope.occupationArray = [];
    $scope.childOccupationArray = [];
    $scope.natureOfIdArray = [];
    if($rootScope.productName === "CZ"){
        if(CommonServices.floaterObj.occupationArray && CommonServices.floaterObj.childOccupationArray && CommonServices.floaterObj.natureOfIdArray) {
            $scope.occupationArray = CommonServices.floaterObj.occupationArray;
            $scope.childOccupationArray = CommonServices.floaterObj.childOccupationArray;
            $scope.natureOfIdArray = CommonServices.floaterObj.natureOfIdArray;
        } 
        else {
            for(let i=0; i<CommonServices.productDomainValues.productDomainValues.length; i++){
                switch(CommonServices.productDomainValues.productDomainValues[i].domainValues.codeId){
                    case "OCCUPATION":
                        $scope.occupationArray.push(CommonServices.productDomainValues.productDomainValues[i].domainValues);
                        break;
                    case "OCCUPATION_CHILDREN":
                        $scope.childOccupationArray.push(CommonServices.productDomainValues.productDomainValues[i].domainValues);
                        break;
                    case "NATURE_OF_ID":
                        $scope.natureOfIdArray.push(CommonServices.productDomainValues.productDomainValues[i].domainValues);
                }
            }
            CommonServices.floaterObj.occupationArray = $scope.occupationArray;
            CommonServices.floaterObj.childOccupationArray = $scope.childOccupationArray;
            CommonServices.floaterObj.natureOfIdArray = $scope.natureOfIdArray;
        }
    }




    $scope.maternityShow = function(index) {
        if($rootScope.productName === "NP" || $rootScope.productName === "UK"){
            if(($scope.additionalDetailsArray[index].gender == "F") && (CommonServices.floaterObj.addedMemberDetails[index].riskDetails.ageInYrs > 17))
                $scope.additionalDetailsArray[index].showMaternity = true;
            else{
                $scope.additionalDetailsArray[index].showMaternity = false;
                $scope.additionalDetailsArray[index].maternityExpense = false;
            }
        }
    }
    $scope.healthPolicyChange = function (healthData, index) {

        if (healthData === false) {
            for (var i = 0; i < $scope.additionalDetailsArray.length; i++) {
                if (i === index) {
                    $scope.additionalDetailsArray[index].previousPolicyDetails.company = "";
                    $scope.additionalDetailsArray[index].previousPolicyDetails.currentPolicyNumber = "";
                    $scope.additionalDetailsArray[index].previousPolicyDetails.sumInsured = "";
                    $scope.additionalDetailsArray[index].previousPolicyDetails.inceptionDate = "";
                    $scope.additionalDetailsArray[index].previousPolicyDetails.expiryDate = "";
                }
            }
        }
    }
    // TO set Spouse gender based on Proposer gender
    for (var i = 0; i < $scope.additionalDetailsArray.length; i++) {

        //sourav CR_3618 commented this part but not sure what will be the replacement
        // if ($scope.additionalDetailsArray[i].relationshipWith.toUpperCase() === 'SPOUSE') {
        //     if (proposerGender === true) {
        //         $scope.additionalDetailsArray[i].gender = false;
        //     } else {
        //         $scope.additionalDetailsArray[i].gender = true;
        //     }
        // }
        if (($scope.additionalDetailsArray[i].dependentType === 'UD' && $rootScope.productName !== "UK") || $scope.additionalDetailsArray[i].relationshipWith === 'DAUGHTER') {
           // $scope.additionalDetailsArray[i].gender = true;
            $scope.additionalDetailsArray[i].gender = "F";
        }
        //Show Maternity expense
        if ($rootScope.productName === "UK" || $rootScope.productName === "NP") {
            //CR_3618 third gender
            // if ($scope.additionalDetailsArray[i].relationshipWith.toUpperCase() === 'PROPOSER' && $scope.additionalDetailsArray[i].gender === true) {
            //     $scope.additionalDetailsArray[i].showMaternity = true;
            //     $scope.additionalDetailsArray[i].maternityExpense = checkSumInsuredForMaternity(CommonServices.floaterObj.addedMemberDetails[i].riskSumInsured, i);
            // } else if ($scope.additionalDetailsArray[i].relationshipWith.toUpperCase() === 'SPOUSE' && $scope.additionalDetailsArray[i].gender === true) {
            //     $scope.additionalDetailsArray[i].showMaternity = true;
            //     $scope.additionalDetailsArray[i].maternityExpense = checkSumInsuredForMaternity(CommonServices.floaterObj.addedMemberDetails[i].riskSumInsured, i);
            // } else {
            //     $scope.additionalDetailsArray[i].showMaternity = false;

            // }

            if ($scope.additionalDetailsArray[i].gender == 'F' && +CommonServices.floaterObj.addedMemberDetails[i].riskDetails.ageInYrs >= 18) {
                $scope.additionalDetailsArray[i].showMaternity = true;
                let sumInsured = $rootScope.productName === "UK"?CommonServices.floaterObj.addedMemberDetails[i].riskSumInsured:CommonServices.floaterObj.addedMemberDetails[0].riskSumInsured;
                $scope.additionalDetailsArray[i].maternityExpense = checkSumInsuredForMaternity(sumInsured, i);
            }  else {
                $scope.additionalDetailsArray[i].showMaternity = false;
            }
        }
    }
    function checkSumInsuredForMaternity(riskSumInsured, index) {
        if (CommonServices.floaterObj.addedMemberDetails[index].riskDetails.maternityExpense === undefined) {
            return false;
        } else {
            if (parseInt(riskSumInsured) < 500000) {
                return false;
            } else {
                if (CommonServices.setmaternityExpense) {
                    return true;
                } else {
                    return false;
                }
            }
        }
    }

    CommonServices.floaterObj.additionalArray = $scope.additionalDetailsArray;
    $scope.maternityExpFunc = function (event, index) {
        if($rootScope.productName === "NP"){
             index = 0;
        }
        if ((CommonServices.floaterObj.addedMemberDetails[index].riskSumInsured != undefined && parseInt(CommonServices.floaterObj.addedMemberDetails[index].riskSumInsured) < 500000) || (CommonServices.floaterObj.addedMemberDetails[index].riskDetails.riskSumInsured != undefined && parseInt(CommonServices.floaterObj.addedMemberDetails[index].riskDetails.riskSumInsured) < 500000)) {
            CommonServices.showAlert("This cover cannot be opted as the sum insured is less than 5 lakhs. Please change the sum insured and proceed.")
            event.currentTarget.checked = false;
            $scope.additionalDetailsArray[index].maternityExpense = false;
        }
        CommonServices.setmaternityExpense = event.currentTarget.checked;
    }

    $scope.cataractLimFunc = function(event, index) {
        
        if ((CommonServices.floaterObj.addedMemberDetails[0].riskSumInsured != undefined && parseInt(CommonServices.floaterObj.addedMemberDetails[0].riskSumInsured) < 800000) || (CommonServices.floaterObj.addedMemberDetails[0].riskDetails.riskSumInsured != undefined && parseInt(CommonServices.floaterObj.addedMemberDetails[0].riskDetails.riskSumInsured) < 800000)) {
            CommonServices.showAlert("This cover cannot be opted as the sum insured is less than 8 lakhs. Please change the sum insured and proceed.")
            event.currentTarget.checked = false;
            $scope.additionalDetailsArray[index].cataractLimit = false;
        }
        else
            $scope.additionalDetailsArray[index].cataractLimit = event.currentTarget.checked;
    }
   //CR_0044
    $scope.natureOfIdAadharCard = function (index) {
        $scope.additionalDetailsArray[index].iDDocNo = ''
        if (CommonServices.floaterObj.additionalArray[index].natureOfId === "AO" || CommonServices.floaterObj.additionalArray[index].natureOfId === "Any Other"){
            CommonServices.showAlert("Please upload ID other than Aadhaar.");
            return true;
        }

            //UAT Defect 
        // else {
        //     if($scope.additionalDetailsArray[index].natureOfId == "PAN" || $scope.additionalDetailsArray[index].natureOfId == "PANCard" || $scope.additionalDetailsArray[index].natureOfId == "PAN Card"){
        //         $scope.iDDocNoRegexPattern = regexPanNoGlobal;
        //         if($scope.existingPanNo != undefined && ($scope.additionalDetailsArray[index].relationshipWith.toUpperCase() === 'PROPOSER' || $scope.additionalDetailsArray[index].relationshipWith.toUpperCase() === 'SELF')){
        //             $scope.additionalDetailsArray[index].iDDocNo = $scope.existingPanNo;
        //         }
        //     }
        //      else{
        //         $scope.iDDocNoRegexPattern = iDDocNoRegexGlobal;
        //         $scope.isNIAPAN = false;
        //      }
        // }
    };
    	    //CR_0044
    // To display Individual member details in single screen
    $scope.direction = 'right';
    $scope.currentIndex = 0;

    $scope.setCurrentSlideIndex = function (index) {
        $scope.direction = (index > $scope.currentIndex) ? 'left' : 'right';
        $scope.currentIndex = index;
    };

    $scope.isCurrentSlideIndex = function (index) {
        return $scope.currentIndex === index;
    };

    $scope.prevSlide = function (index) {
        $(".form-group").addClass('focused');
        $scope.direction = 'left';
        if (index > 0) {
            $scope.currentIndex = index - 1;
        } else {
            $state.go("policyHolderInformation");
        }
    };

    $scope.nextSlide = function (index) {

        $scope.direction = 'right';
        $scope.currentIndex = index + 1;
        if ($scope.currentIndex === $scope.additionalDetailsArray.length) {
            console.log("$scope.additionalDetailsArray.length"+$scope.additionalDetailsArray.length);
            if ($rootScope.productName === "UK" || $rootScope.productName === 'CJ'|| $rootScope.productName === 'CZ')  { // CR_3725
                if($rootScope.productName === 'UK'){
                    $rootScope.dataforSaveQuoteUK();
                }
                else if($rootScope.productName === 'CZ'){
                    $rootScope.dataforSaveQuoteCZ();    //To be defined
                }
                else {
                    $rootScope.dataforSaveQuoteCJ();
                }

                CommonServices.floaterObj.localStorageVAlues = $scope.additionalDetailsArray;
                if($rootScope.productName === 'CJ' || $rootScope.productName === 'CZ'){ // CR_3725
                    $state.go("policyPeriodAndNomineeDetailsHealthCancer"); // CR_3725
                    return;
                }else{
                    $state.go("additionalCovers");
                    return;
                }
            } else {
                $rootScope.dataforSaveQuote();
                console.log("$scope.additionalDetailsArray___");
                console.log($scope.additionalDetailsArray);
                CommonServices.floaterObj.localStorageVAlues = $scope.additionalDetailsArray;
                $state.go("policyPeriodAndNomineeDetailsHealth");//sourav added
            }
        }
        
        bladderHabbits = 1, soreanyWherefortnight = 1, dischargeBody = 1, thickeningLump = 1, persistentIndigestion = 1, obviousChange = 1, diagnosedInvestigated = 1, experiencedAbnormal = 1, parentsSiblingDiagnosed = 1, coughHoarseness = 1;
    };
   /* start CR_0044*/
    $scope.nextSlide1 = function () {
	   
        CommonServices.floaterObj.proportionateDeduction = false;
        CommonServices.floaterObj.cataract =false;
        CommonServices.floaterObj.voluntaryCoPay = false;
        if($("input:radio[name=proportionateDeduction]:checked").val() === 'Y') {
            CommonServices.floaterObj.proportionateDeduction = true;
        }
        
        if($("input:radio[name=cataractLimit]:checked").val() === 'Y') {
            CommonServices.floaterObj.cataract =true;
        }
        
        if($("input:radio[name=coPay]:checked").val() === 'Y') {
            CommonServices.floaterObj.voluntaryCoPay =true;
        }
            
        $state.go("policyPeriodAndNomineeDetailsHealth");
             
    };

	var bladderHabbits = 1; // CR_3725
    $scope.anychangeBowelBladderSelected  = function(index) {  // CR_3725
		if($("input:radio[name=anychangeBowelBladderHabits"+index+"]:checked").val() === 'Y') {	
            CommonServices.showAlert("This member cannot be covered through online channel due to adverse medical history. However you may take this policy for rest of the family member.For covering this member, please contact the nearest branch of New India Assurance.");
            //$("#proposerDetailsFormNextslide"+index).attr("disabled", true);
            $scope.notEligible = true;
            bladderHabbits = 1;
		} else if($("input:radio[name=anychangeBowelBladderHabits"+index+"]:checked").val() === 'N') {
            bladderHabbits = 0;
            resetAdditionalDetails(index);// to handle disable logic for more than one member --enable/disable any option
		}	
    }

    var soreanyWherefortnight = 1; // CR_3725
	$scope.soreanyWherefortnightSelected  = function(index) { // CR_3725
		if($("input:radio[name=soreanyWherefortnight"+index+"]:checked").val() === 'Y') {			
			CommonServices.showAlert("This member cannot be covered through online channel due to adverse medical history. However you may take this policy for rest of the family member.For covering this member, please contact the nearest branch of New India Assurance.");
            //$("#proposerDetailsFormNextslide"+index).attr("disabled", true);
            $scope.notEligible = true;
            soreanyWherefortnight = 1;
		} else if($("input:radio[name=soreanyWherefortnight"+index+"]:checked").val() === 'N') {
            soreanyWherefortnight = 0;
            resetAdditionalDetails(index);
		}	
    }

    var dischargeBody = 1; // CR_3725
	$scope.dischargeBodyOpeningSelected  = function(index) { // CR_3725
		if($("input:radio[name=dischargeBodyOpening"+index+"]:checked").val() === 'Y') {			
			CommonServices.showAlert("This member cannot be covered through online channel due to adverse medical history. However you may take this policy for rest of the family member.For covering this member, please contact the nearest branch of New India Assurance.");
            //$("#proposerDetailsFormNextslide"+index).attr("disabled", true);
            $scope.notEligible = true;
            dischargeBody = 1;
		} else if($("input:radio[name=dischargeBodyOpening"+index+"]:checked").val() === 'N') {
            dischargeBody = 0;
            resetAdditionalDetails(index);
		}	
    }

    var thickeningLump = 1; // CR_3725
	$scope.thickeningLumpBreastSelected  = function(index) { // CR_3725
		if($("input:radio[name=thickeningLumpBreast"+index+"]:checked").val() === 'Y') {			
			CommonServices.showAlert("This member cannot be covered through online channel due to adverse medical history. However you may take this policy for rest of the family member.For covering this member, please contact the nearest branch of New India Assurance.");
            //$("#proposerDetailsFormNextslide"+index).attr("disabled", true);
            $scope.notEligible = true;
            thickeningLump = 1;
		} else if($("input:radio[name=thickeningLumpBreast"+index+"]:checked").val() === 'N') {
            thickeningLump = 0;
            resetAdditionalDetails(index);
		}	
    }

    var persistentIndigestion = 1; // CR_3725
	$scope.persistentIndigestionSelected  = function(index) { // CR_3725
		if($("input:radio[name=persistentIndigestion"+index+"]:checked").val() === 'Y') {			
			CommonServices.showAlert("This member cannot be covered through online channel due to adverse medical history. However you may take this policy for rest of the family member.For covering this member, please contact the nearest branch of New India Assurance.");
            //$("#proposerDetailsFormNextslide"+index).attr("disabled", true);
            $scope.notEligible = true;
            persistentIndigestion = 1;
		} else if($("input:radio[name=persistentIndigestion"+index+"]:checked").val() === 'N') {
            persistentIndigestion = 0;
            resetAdditionalDetails(index);
		}	
    }

    var obviousChange = 1; // CR_3725
	$scope.obviousChangeWartSelected  = function(index) { // CR_3725
		if($("input:radio[name=obviousChangeWart"+index+"]:checked").val() === 'Y') {			
            CommonServices.showAlert("This member cannot be covered through online channel due to adverse medical history. However you may take this policy for rest of the family member.For covering this member, please contact the nearest branch of New India Assurance.");
            //$("#proposerDetailsFormNextslide"+index).attr("disabled", true);
            $scope.notEligible = true;
            obviousChange = 1;
		} else if($("input:radio[name=obviousChangeWart"+index+"]:checked").val() === 'N') {
            obviousChange = 0;
            resetAdditionalDetails(index);
		}	
    }

    var coughHoarseness = 1; // CR_3725
	$scope.coughHoarsenessSelected  = function(index) { // CR_3725
		if($("input:radio[name=coughHoarseness"+index+"]:checked").val() === 'Y') {			
			CommonServices.showAlert("This member cannot be covered through online channel due to adverse medical history. However you may take this policy for rest of the family member.For covering this member, please contact the nearest branch of New India Assurance.");
            //$("#proposerDetailsFormNextslide"+index).attr("disabled", true);
            $scope.notEligible = true;
            coughHoarseness = 1; 
		} else if($("input:radio[name=coughHoarseness"+index+"]:checked").val() === 'N') {
            coughHoarseness = 0;
            resetAdditionalDetails(index);
		}	
    }

    var diagnosedInvestigated = 1; // CR_3725
	$scope.diagnosedInvestigatedSelected  = function(index) { // CR_3725
		if($("input:radio[name=diagnosedInvestigated"+index+"]:checked").val() === 'Y') {			
			CommonServices.showAlert("People  diagnosed with, operated for, investigated for or underwent chemotherapy/ Radiotherapy for any reason cannot take this policy.");
            //$("#proposerDetailsFormNextslide"+index).attr("disabled", true);
            $scope.notEligible = true;
            diagnosedInvestigated = 1;
		} else if($("input:radio[name=diagnosedInvestigated"+index+"]:checked").val() === 'N') {
            diagnosedInvestigated = 0;
            resetAdditionalDetails(index);
		}	
    }

    var experiencedAbnormal = 1; // CR_3725
	$scope.experiencedAbnormalSelected  = function(index) { // CR_3725
		if($("input:radio[name=experiencedAbnormal"+index+"]:checked").val() === 'Y') {			
			CommonServices.showAlert("This member cannot be covered through online channel due to adverse medical history. However you may take this policy for rest of the family member.For covering this member, please contact the nearest branch of New India Assurance.");
            //$("#proposerDetailsFormNextslide"+index).attr("disabled", true);
            $scope.notEligible = true;
            experiencedAbnormal = 1;
		} else if($("input:radio[name=experiencedAbnormal"+index+"]:checked").val() === 'N') {
            experiencedAbnormal = 0;
            resetAdditionalDetails(index);
		}	
    }

    var parentsSiblingDiagnosed = 1; // CR_3725
	$scope.parentsSiblingDiagnosedSelected  = function(index) { // CR_3725
		if($("input:radio[name=parentsSiblingDiagnosed"+index+"]:checked").val() === 'Y') {			
			CommonServices.showAlert("People whose parents or siblings ever been diagnosed with any form of cancer cannot take this policy.");
            //$("#proposerDetailsFormNextslide"+index).attr("disabled", true);
            $scope.notEligible = true;
            parentsSiblingDiagnosed = 1;
		} else if($("input:radio[name=parentsSiblingDiagnosed"+index+"]:checked").val() === 'N') {
            parentsSiblingDiagnosed = 0;
            resetAdditionalDetails(index);
		}	
    }
    
    // function resetAdditionalDetails(index){
    //     if(bladderHabbits== 0 && soreanyWherefortnight == 0 && dischargeBody == 0 && thickeningLump == 0 && persistentIndigestion == 0 && obviousChange == 0 && diagnosedInvestigated == 0 && experiencedAbnormal == 0 && parentsSiblingDiagnosed == 0 && coughHoarseness == 0){
    //         $("#proposerDetailsFormNextslide"+index).attr("disabled", false);
    //     }else{
    //         $("#proposerDetailsFormNextslide"+index).attr("disabled", true);
    //     }
    // }

    function resetAdditionalDetails(index){
        if(($("input:radio[name=anychangeBowelBladderHabits"+index+"]:checked").val() === 'N') && ($("input:radio[name=soreanyWherefortnight"+index+"]:checked").val() === 'N') && ($("input:radio[name=dischargeBodyOpening"+index+"]:checked").val() === 'N') && ($("input:radio[name=thickeningLumpBreast"+index+"]:checked").val() === 'N') && ($("input:radio[name=persistentIndigestion"+index+"]:checked").val() === 'N') && ($("input:radio[name=obviousChangeWart"+index+"]:checked").val() === 'N') && ($("input:radio[name=diagnosedInvestigated"+index+"]:checked").val() === 'N') && ($("input:radio[name=experiencedAbnormal"+index+"]:checked").val() === 'N') && ($("input:radio[name=parentsSiblingDiagnosed"+index+"]:checked").val() === 'N') && ($("input:radio[name=coughHoarseness"+index+"]:checked").val() === 'N')){
            $scope.notEligible = false;
            //$("#proposerDetailsFormNextslide"+index).attr("disabled", false);
        }
        else{
            $scope.notEligible = true;
            //$("#proposerDetailsFormNextslide"+index).attr("disabled", true);
        }
    }
    var porpotionateCheck = 0;
	$scope.propotionateSelected  = function() {
		if($("input:radio[name=proportionateDeduction]:checked").val() === 'Y') {			
			if(porpotionateCheck === 0){
				CommonServices.showAlert("The cover shall be available only for those persons with Sum Insured of 2 lakhs and above.");
				porpotionateCheck++;
			} else {
				porpotionateCheck++;
			}
		} else if($("input:radio[name=proportionateDeduction]:checked").val() === 'N') {
			porpotionateCheck = 0;
		}	
	}
	var cataractCheck = 0;
	$scope.cataractSelected  = function(){
		if($("input:radio[name=cataractLimit]:checked").val() === 'Y') {			
			if(cataractCheck === 0){
				CommonServices.showAlert("The cover shall be available only for those persons whose age is 46 years & above with Sum Insured of 8 lakhs and above.");
				cataractCheck++;
			} else {
				cataractCheck++;
			}
		} else if($("input:radio[name=cataractLimit]:checked").val() === 'N') {
			cataractCheck = 0;
		}	
    }
    
    /* start CR_3725*/
    $rootScope.dataforSaveQuoteCJ = function () {
        for (var i = 0; i < CommonServices.floaterObj.addedMemberDetails.length; i++) {
           // console.log("anyOther_occu",$scope.additionalDetailsArray[i].anyOtherId);
         if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PROPOSER') {
            CommonServices.floaterObj.addedMemberDetails[i].riskParty = CommonServices.policyDetailsObj.saveQuotePolicyHolderCode;
         }
            CommonServices.floaterObj.addedMemberDetails[i].riskDetails.occupation = $scope.additionalDetailsArray[i] === undefined ? null : $scope.additionalDetailsArray[i].occupation;
            CommonServices.floaterObj.addedMemberDetails[i].riskDetails.nameOfInsuredPerson = $scope.additionalDetailsArray[i] === undefined ? null : $scope.additionalDetailsArray[i].name;
            console.log("$scope.additionalDetailsArray[i].gender"+ $scope.additionalDetailsArray[i].gender);
           // CommonServices.floaterObj.addedMemberDetails[i].riskDetails.sex = $scope.additionalDetailsArray[i] === undefined ? undefined : $scope.additionalDetailsArray[i].gender === true ? "F" : "M"; sourav 01.112019
            //sourav next button click blank issue fix try
            if($scope.additionalDetailsArray[i] === undefined){
                CommonServices.floaterObj.addedMemberDetails[i].riskDetails.ifAnyOtherOccupation = null;
            }
            else{
                CommonServices.floaterObj.addedMemberDetails[i].riskDetails.ifAnyOtherOccupation = $scope.additionalDetailsArray[i].anyOther === undefined ? null : $scope.additionalDetailsArray[i].anyOther;
            }
           // CommonServices.floaterObj.addedMemberDetails[i].riskDetails.ifAnyOtherOccupation = $scope.additionalDetailsArray[i].anyOther === undefined ? null : $scope.additionalDetailsArray[i].anyOther;
            CommonServices.floaterObj.addedMemberDetails[i].riskDetails.natureOfId = $scope.additionalDetailsArray[i] === undefined ? null : $scope.additionalDetailsArray[i].natureOfId;
             //sourav next button click blank issue fix try
             if($scope.additionalDetailsArray[i] === undefined){
                CommonServices.floaterObj.addedMemberDetails[i].riskDetails.anyOtherId = null;
            }
            else{
                CommonServices.floaterObj.addedMemberDetails[i].riskDetails.anyOtherId = $scope.additionalDetailsArray[i].anyOtherId === undefined ? null : $scope.additionalDetailsArray[i].anyOtherId;
            }
           // CommonServices.floaterObj.addedMemberDetails[i].riskDetails.anyOtherId = $scope.additionalDetailsArray[i].anyOtherId === "" ? null : $scope.additionalDetailsArray[i].anyOtherId;
            CommonServices.floaterObj.addedMemberDetails[i].riskDetails.iDDocNo = $scope.additionalDetailsArray[i] === undefined ? null : $scope.additionalDetailsArray[i].iDDocNo;
            // CR_3725
               CommonServices.floaterObj.addedMemberDetails[i].riskDetails.preExistingDisease = $scope.additionalDetailsArray[i] === undefined ? null : $scope.additionalDetailsArray[i].preExistingDisease;
               CommonServices.floaterObj.addedMemberDetails[i].riskDetails.cumulativeBonusAmount = $scope.additionalDetailsArray[i] === undefined ? null : $scope.additionalDetailsArray[i].cumulativeBonus;
              
               CommonServices.floaterObj.addedMemberDetails[i].riskDetails.anyChangeinBowel = $scope.additionalDetailsArray[i] === undefined ? null : ($scope.additionalDetailsArray[i].anychangeBowelBladderHabits === "N" ? "No" : "");
               CommonServices.floaterObj.addedMemberDetails[i].riskDetails.aSoreDidnotHealed = $scope.additionalDetailsArray[i] === undefined ? null : ($scope.additionalDetailsArray[i].soreanyWherefortnight === "N" ? "No" : "");
               CommonServices.floaterObj.addedMemberDetails[i].riskDetails.unusualBleeding = $scope.additionalDetailsArray[i] === undefined ? null : ($scope.additionalDetailsArray[i].dischargeBodyOpening === "N" ? "No" : "");
               CommonServices.floaterObj.addedMemberDetails[i].riskDetails.lumpInTheBreast = $scope.additionalDetailsArray[i] === undefined ? null : ($scope.additionalDetailsArray[i].thickeningLumpBreast === "N" ? "No" : "");
               CommonServices.floaterObj.addedMemberDetails[i].riskDetails.persistentIndigestion = $scope.additionalDetailsArray[i] === undefined ? null : ($scope.additionalDetailsArray[i].persistentIndigestion === "N" ? "No" : "");
               CommonServices.floaterObj.addedMemberDetails[i].riskDetails.anyObviousChange = $scope.additionalDetailsArray[i] === undefined ? null : ($scope.additionalDetailsArray[i].obviousChangeWart === "N" ? "No" : "");
               CommonServices.floaterObj.addedMemberDetails[i].riskDetails.coughOrHoarseness = $scope.additionalDetailsArray[i] === undefined ? null : ($scope.additionalDetailsArray[i].coughHoarseness === "N" ? "No" : "");
               CommonServices.floaterObj.addedMemberDetails[i].riskDetails.abnormalWeightLoss = $scope.additionalDetailsArray[i] === undefined ? null : ($scope.additionalDetailsArray[i].experiencedAbnormal === "N" ? "No" : "");
               CommonServices.floaterObj.addedMemberDetails[i].riskDetails.underwentChemotherapy = $scope.additionalDetailsArray[i] === undefined ? null : ($scope.additionalDetailsArray[i].diagnosedInvestigated === "N" ? "No" : "");
               CommonServices.floaterObj.addedMemberDetails[i].riskDetails.parentsDiagnosedWithCancer = $scope.additionalDetailsArray[i] === undefined ? null : ($scope.additionalDetailsArray[i].parentsSiblingDiagnosed === "N" ? "No" : "");
              
            //CommonServices.floaterObj.addedMemberDetails[i].riskDetails.doYouChewTobacco = "N";
            //CommonServices.floaterObj.addedMemberDetails[i].riskDetails.doYouSmoke = "N";
            //CommonServices.floaterObj.addedMemberDetails[i].riskDetails.doYouDrinkAlcohol = "N";
            
          //  CommonServices.floaterObj.addedMemberDetails[i].riskDetails.adverseMedicialHistory = "N";
            CommonServices.floaterObj.addedMemberDetails[i].riskDetails.document = {};
            CommonServices.floaterObj.addedMemberDetails[i].riskDetails.previousPolicyDetails = {};
        }
        // console.log($scope.additionalDetailsArray);
        // console.log(CommonServices.floaterObj.addedMemberDetails);
        //console.log($scope.additionalDetailsArray);
        if (CommonServices.floaterObj.serviceCall === "calcPremium") {
            CommonServices.floaterObj.serviceCall = "";
            $rootScope.saveQuote();
        }
    }
    /* End CR_3725*/

    /* start CR_4092*/
    $rootScope.dataforSaveQuoteCZ = function(){
        // console.log(CommonServices.floaterObj);
        CommonServices.floaterObj.addedMemberDetails[0].riskParty = CommonServices.policyDetailsObj.saveQuotePolicyHolderCode;
        CommonServices.floaterObj.addedMemberDetails[0].riskDetails.natureOfId = $scope.additionalDetailsArray[0].natureOfId;
        CommonServices.floaterObj.addedMemberDetails[0].riskDetails.anyOtherId = $scope.additionalDetailsArray[0].anyOtherId;
        CommonServices.floaterObj.addedMemberDetails[0].riskDetails.iDDocNo = $scope.additionalDetailsArray[0].iDDocNo;
        CommonServices.floaterObj.addedMemberDetails[0].riskDetails.ageInYrs = CommonServices.floaterObj.addedMemberDetails[0].riskDetails.ageInYrs.toString();
        for(var i=0; i<CommonServices.floaterObj.addedMemberDetails.length; i++){
            if($scope.additionalDetailsArray[i]){
                CommonServices.floaterObj.addedMemberDetails[i].riskDetails.nameOfInsuredPerson = $scope.additionalDetailsArray[i].name;
                CommonServices.floaterObj.addedMemberDetails[i].riskDetails.sex = $scope.additionalDetailsArray[i].gender;
                CommonServices.floaterObj.addedMemberDetails[i].riskDetails.occupation = $scope.additionalDetailsArray[i].occupation;
                CommonServices.floaterObj.addedMemberDetails[i].riskDetails.ifAnyOtherOccupation = $scope.additionalDetailsArray[i].anyOther || null;
                CommonServices.floaterObj.addedMemberDetails[i].riskDetails.document = {};
            }
        }
        if (CommonServices.floaterObj.serviceCall === "calcPremium") {
            CommonServices.floaterObj.serviceCall = "";
            $rootScope.saveQuote();
        }
    }
    /* End CR_4092*/
    
    /* start CR_0044*/
    $rootScope.dataforSaveQuoteUK = function () {
        for (var i = 0; i < CommonServices.floaterObj.addedMemberDetails.length; i++) {

            if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PROPOSER') {
                CommonServices.floaterObj.addedMemberDetails[i].riskParty = CommonServices.policyDetailsObj.saveQuotePolicyHolderCode;
                CommonServices.floaterObj.addedMemberDetails[i].riskDetails.maternityExpense = $scope.additionalDetailsArray[i] === undefined ? null : $scope.additionalDetailsArray[i].maternityExpense === true ? "Y" : "N";
                CommonServices.floaterObj.addedMemberDetails[i].riskDetails.previousPolicyDetails = {};
            }
            if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SPOUSE') {
                CommonServices.floaterObj.addedMemberDetails[i].riskDetails.maternityExpense = $scope.additionalDetailsArray[i] === undefined ? null : $scope.additionalDetailsArray[i].maternityExpense === true ? "Y" : "N";
                CommonServices.floaterObj.addedMemberDetails[i].riskDetails.preExistingDisease = null;
            }
            if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'CHILDREN' || CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PARENTS') {
                CommonServices.floaterObj.addedMemberDetails[i].riskDetails.preExistingDisease = 'N';
            }
            if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SPOUSE' || CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'CHILDREN' || CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PARENTS') {
                CommonServices.floaterObj.addedMemberDetails[i].riskDetails.hypertension = 'N';
                CommonServices.floaterObj.addedMemberDetails[i].riskDetails.diabetes = 'N';
                CommonServices.floaterObj.addedMemberDetails[i].riskDetails.criticalIllNess = 'N';
                CommonServices.floaterObj.addedMemberDetails[i].riskDetails.recurringIllNess = 'N';
                CommonServices.floaterObj.addedMemberDetails[i].riskDetails.chronicIllNess = 'N';
                CommonServices.floaterObj.addedMemberDetails[i].riskDetails.psychiatric = 'N';
                CommonServices.floaterObj.addedMemberDetails[i].riskDetails.previousPolicyDetails = {
                    "whetherYouHadAHealthPolicyInThePast": 'N'
                };
            }
            CommonServices.floaterObj.addedMemberDetails[i].riskDetails.occupation = $scope.additionalDetailsArray[i] === undefined ? null : $scope.additionalDetailsArray[i].occupation;
            CommonServices.floaterObj.addedMemberDetails[i].riskDetails.nameOfInsuredPerson = $scope.additionalDetailsArray[i] === undefined ? null : $scope.additionalDetailsArray[i].name;
              //CommonServices.floaterObj.addedMemberDetails[i].riskDetails.sex = $scope.additionalDetailsArray[i] === undefined ? undefined : $scope.additionalDetailsArray[i].gender === true ? "F" : "M";
            
              CommonServices.floaterObj.addedMemberDetails[i].riskDetails.sex = $scope.additionalDetailsArray[i] === undefined ? undefined : $scope.additionalDetailsArray[i].gender;
              
            CommonServices.floaterObj.addedMemberDetails[i].riskDetails.ifAnyOtherOccupation = $scope.additionalDetailsArray[i] === undefined ? null : $scope.additionalDetailsArray[i].anyOther;
            CommonServices.floaterObj.addedMemberDetails[i].riskDetails.natureOfId = $scope.additionalDetailsArray[i] === undefined ? null : $scope.additionalDetailsArray[i].natureOfId;
            CommonServices.floaterObj.addedMemberDetails[i].riskDetails.anyOtherId = $scope.additionalDetailsArray[i] === undefined ? null : $scope.additionalDetailsArray[i].anyOtherId;
            CommonServices.floaterObj.addedMemberDetails[i].riskDetails.iDDocNo = $scope.additionalDetailsArray[i] === undefined ? null : $scope.additionalDetailsArray[i].iDDocNo;
            CommonServices.floaterObj.addedMemberDetails[i].riskDetails.doYouChewTobacco = "N";
            CommonServices.floaterObj.addedMemberDetails[i].riskDetails.doYouSmoke = "N";
            CommonServices.floaterObj.addedMemberDetails[i].riskDetails.doYouDrinkAlcohol = "N";
            CommonServices.floaterObj.addedMemberDetails[i].riskDetails.adverseMedicialHistory = "N";
            CommonServices.floaterObj.addedMemberDetails[i].riskDetails.document = {};
            CommonServices.floaterObj.addedMemberDetails[i].riskDetails.maternityExpense = $scope.additionalDetailsArray[i] === undefined ? null : $scope.additionalDetailsArray[i].maternityExpense === true ? "Y" : "N";
        }
        if (CommonServices.floaterObj.serviceCall === "calcPremium") {
            CommonServices.floaterObj.serviceCall = "";
            $rootScope.saveQuote();
        }
    }
    $rootScope.dataforSaveQuote = function () {

       // console.log("CommonServices.floaterObj.addedMemberDetails[i].riskDetails.sex"+CommonServices.floaterObj.addedMemberDetails[i].riskDetails.sex);
        for (var i = 0; i < CommonServices.floaterObj.addedMemberDetails.length; i++) {
            if ($scope.additionalDetailsArray[i].headerName === "Policy holder/Proposer details") {
            // "sex": ($scope.additionalDetailsArray[i] === undefined ? undefined : $scope.additionalDetailsArray[i].gender === true ? "F" : "M"), CR_3618 third gender
                console.log("dataforSaveQuote line 3600"+$scope.additionalDetailsArray[i].gender);
                CommonServices.floaterObj.policyHolderDetails = {
                    "relationWithPolicyHolder": "SELF",
                    "occupation": ($scope.additionalDetailsArray[i] === undefined ? null : $scope.additionalDetailsArray[i].occupation),
                    "ifAnyOtherOccupation": ($scope.additionalDetailsArray[i].anyOther === undefined ? null : $scope.additionalDetailsArray[i].anyOther),
                    "sex": ($scope.additionalDetailsArray[i] === undefined ? undefined : $scope.additionalDetailsArray[i].gender),
                    "nameOfInsuredPerson": $scope.additionalDetailsArray[i].name.toUpperCase(),
                    "dateOfBirth": CommonServices.floaterObj.addedMemberDetails[i].riskDetails.dateOfBirth,
                    "ageInYrs": CommonServices.floaterObj.addedMemberDetails[i].riskDetails.ageInYrs,
                    "cityOfResidence": $rootScope.productCode === "AK" ? "NA" : CommonServices.floaterObj.addedMemberDetails[i].riskDetails.cityOfResidence,
                    "riskParty": CommonServices.policyDetailsObj.saveQuotePolicyHolderCode,
                    "riskSumInsured": CommonServices.floaterObj.addedMemberDetails[i].riskDetails.riskSumInsured,
                    "startDtOfMember": null,
                    "doYouChewTobacco": "N",
                    "doYouSmoke ": "N",
                    "doYouDrinkAlcohol": "N",
                    "adverseMedicialHistory": "N",
                    "dependent": "N",
                    "dependentType": "NORM",
                    "thresholdLimit": null,
                    "previousPolicyDetails": {
                        "whetherYouHadAHealthPolicyInThePast": $scope.additionalDetailsArray[i] === undefined ? undefined : $scope.additionalDetailsArray[i].health === true ? "Y" : "N",
                        "previousClaimOrHospitalisation": null,
                        "claimAmountReceived": null,
                        "company": ($scope.additionalDetailsArray[i] === undefined ? undefined : $scope.additionalDetailsArray[i].previousPolicyDetails.company),
                        "currentPolicyNumber": ($scope.additionalDetailsArray[i] === undefined ? undefined : $scope.additionalDetailsArray[i].previousPolicyDetails.currentPolicyNumber),
                        "inceptionDate": ($scope.additionalDetailsArray[i] === undefined ? undefined : $scope.additionalDetailsArray[i].previousPolicyDetails.inceptionDate),
                        "expiryDate": ($scope.additionalDetailsArray[i] === undefined ? undefined : $scope.additionalDetailsArray[i].previousPolicyDetails.expiryDate),
                        "sumInsured": ($scope.additionalDetailsArray[i] === undefined ? undefined : $scope.additionalDetailsArray[i].previousPolicyDetails.sumInsured)
                    }

                }
                CommonServices.floaterObj.addedMemberDetails[0].riskDetails = CommonServices.floaterObj.policyHolderDetails;

            } else {
                if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SELF') {
                    CommonServices.floaterObj.addedMemberDetails[i].riskParty = CommonServices.policyDetailsObj.saveQuotePolicyHolderCode;
                    CommonServices.floaterObj.addedMemberDetails[i].riskDetails.dependent = "N";
                    CommonServices.floaterObj.addedMemberDetails[i].riskDetails.dependentType = "NORM";
                }

                if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SPOUSE') {
                    CommonServices.floaterObj.addedMemberDetails[i].riskDetails.dependent = "N";
                    CommonServices.floaterObj.addedMemberDetails[i].riskDetails.dependentType = "NORM";
                    CommonServices.floaterObj.addedMemberDetails[i].riskDetails.preExistingDisease = null; //NP
                }
                if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'CHILD' || CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'DAUGHTER') {
                    CommonServices.floaterObj.addedMemberDetails[i].riskDetails.bonusdetails = null;
                }
                CommonServices.floaterObj.addedMemberDetails[i].riskDetails.occupation = $scope.additionalDetailsArray[i] === undefined ? null : $scope.additionalDetailsArray[i].occupation;
                CommonServices.floaterObj.addedMemberDetails[i].riskDetails.nameOfInsuredPerson = $scope.additionalDetailsArray[i] === undefined ? null : $scope.additionalDetailsArray[i].name;
                CommonServices.floaterObj.addedMemberDetails[i].riskDetails.areYouEarningHeadOfFamily = "N";
                CommonServices.floaterObj.addedMemberDetails[i].riskDetails.ifAnyOtherOccupation = $scope.additionalDetailsArray[i].anyOther === undefined ? null : $scope.additionalDetailsArray[i].anyOther;
               // CommonServices.floaterObj.addedMemberDetails[i].riskDetails.sex = $scope.additionalDetailsArray[i] === undefined ? undefined : $scope.additionalDetailsArray[i].gender === true ? "F" : "M"; sourav 01.11.2019
               console.log("line 5712" + $scope.additionalDetailsArray[i].gender);
               CommonServices.floaterObj.addedMemberDetails[i].riskDetails.sex = $scope.additionalDetailsArray[i] === undefined ? undefined : $scope.additionalDetailsArray[i].gender;//tempGenderValue; //CR_3618
                CommonServices.floaterObj.addedMemberDetails[i].riskDetails.startDtOfMember = null;
                CommonServices.floaterObj.addedMemberDetails[i].riskDetails.doYouChewTobacco = "N";
                CommonServices.floaterObj.addedMemberDetails[i].riskDetails.doYouSmoke = "N";
                CommonServices.floaterObj.addedMemberDetails[i].riskDetails.doYouDrinkAlcohol = "N";
                CommonServices.floaterObj.addedMemberDetails[i].riskDetails.adverseMedicialHistory = "N";

                CommonServices.floaterObj.addedMemberDetails[i].riskDetails.previousPolicyDetails = {
                    "whetherYouHadAHealthPolicyInThePast": $scope.additionalDetailsArray[i] === undefined ? undefined : $scope.additionalDetailsArray[i].health === true ? "Y" : "N",
                    "previousClaimOrHospitalisation": null,
                    "claimAmountReceived": null
                }

                // IF block is for CR_3738_B
                if($rootScope.productName === "NP"){
                    CommonServices.floaterObj.addedMemberDetails[i].riskDetails.cataractLimit = $scope.additionalDetailsArray[i].cataractLimit? "Y":"N";
                    CommonServices.floaterObj.addedMemberDetails[i].riskDetails.maternityExpense = $scope.additionalDetailsArray[i].maternityExpense? "Y":"N";
                }

                if ($rootScope.productName !== "AK") {
                    CommonServices.floaterObj.addedMemberDetails[i].riskDetails.previousPolicyDetails.company = ($scope.additionalDetailsArray[i] === undefined ? undefined : $scope.additionalDetailsArray[i].previousPolicyDetails.company);
                    CommonServices.floaterObj.addedMemberDetails[i].riskDetails.previousPolicyDetails.currentPolicyNumber = ($scope.additionalDetailsArray[i] === undefined ? undefined : $scope.additionalDetailsArray[i].previousPolicyDetails.currentPolicyNumber);
                    CommonServices.floaterObj.addedMemberDetails[i].riskDetails.previousPolicyDetails.inceptionDate = ($scope.additionalDetailsArray[i] === undefined ? undefined : $scope.additionalDetailsArray[i].previousPolicyDetails.inceptionDate);
                    CommonServices.floaterObj.addedMemberDetails[i].riskDetails.previousPolicyDetails.expiryDate = ($scope.additionalDetailsArray[i] === undefined ? undefined : $scope.additionalDetailsArray[i].previousPolicyDetails.expiryDate);
                    CommonServices.floaterObj.addedMemberDetails[i].riskDetails.previousPolicyDetails.sumInsured = ($scope.additionalDetailsArray[i] === undefined ? undefined : $scope.additionalDetailsArray[i].previousPolicyDetails.sumInsured);
                }
                $scope.riskDeatilsForSaveQuoteHealth.push(CommonServices.floaterObj.addedMemberDetails[i]);

                CommonServices.floaterObj.riskDeatilsForSaveQuoteHealth = $scope.riskDeatilsForSaveQuoteHealth;
            }

        }

        if (CommonServices.floaterObj.serviceCall === "calcPremium") {
            CommonServices.floaterObj.serviceCall = "";
            $rootScope.saveQuote();
        }
    };



    var mydateStr = new Date();
    var mynewdateFrom = "";
    if (mydateStr != undefined) {
        mynewdateFrom = new Date(mydateStr);
    } else {
        mynewdateFrom = new Date();
    }

    var enableDateOfInceptionfrom = getFormattedDate(mynewdateFrom);

    /**Proposer Date of Birth**/

    var enableDateOfInceptionCalTo = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 1017));

    /**Proposer DOB**/

    $scope.dateOfInception = function (index) {
        $('#dateOfInception' + index).loadCalendar({
            'enableDateRange': true,
            'enableCalendarFrom': enableDateOfInceptionCalTo,
            'enableCalendarTo': enableDateOfInceptionfrom
        });
        return true;
    };
    $scope.dateOfExpiry = function (index) {
        $('#dateOfExpiry' + index).loadCalendar({
            'enableDateRange': false
        });
        return true;
    };



    /* if (CommonServices.floaterObj.goToNomineeInfoEdit === "proposerDetailsEdit" || CommonServices.floaterObj.goToNomineeInfoEdit === "policyHolderInformation" || CommonServices.floaterObj.goToMemeberInfoEdit === "proposerDetailsEdit") { */
    if (CommonServices.floaterObj.reviewSummary === true) {
    	if($rootScope.productName ==="UK" || $rootScope.productName ==="CJ" || $rootScope.productName ==="CZ"){ //CR_3725 sourav added
    		$scope.additionalDetailsArray=CommonServices.floaterObj.additionalArray;
    	}else{
            $scope.additionalDetailsArray = CommonServices.floaterObj.localStorageVAlues;
    	}
        CommonServices.uploadUKFiles = [];
    }

}]);

agentApp.controller('nomineeAndRelationDetailsCtrl', ['$scope', 'RestServices', 'CommonServices', '$state', '$rootScope', function ($scope, RestServices, CommonServices, $state, $rootScope) {
    $scope.agentModels = {};
    $scope.selectedAgentDetails = [];
    $scope.isAgentRequired = true;
    $scope.gstinMsg = "GSTIN";
    $scope.productName = $rootScope.productName;
    $scope.noProportionateDeduction = (CommonServices.floaterObj.proportionateDeduction != undefined && CommonServices.floaterObj.proportionateDeduction != "")? CommonServices.floaterObj.proportionateDeduction: false;
    //$scope.selectedRadioYes = false; // popup variable

    $scope.healthWorkerDetails = {};


    $scope.noProportionateDeductionFunc = function(event) {
        $scope.noProportionateDeduction = event.currentTarget.checked;
    }

    $scope.goBack = function () {
        CommonServices.floaterObj.goToMemeberInfoEdit = "proposerDetailsEdit";
        $(".form-group").addClass('focused');
        if ($rootScope.productName === "UK") {
            $state.go("additionalCovers");
        } else if($rootScope.productName === "RK") {
            $state.go("rakProposerDetails");
        } else {
            $state.go("proposerDetailsHealth");
        }
    };

//     $scope.calIconClick= function(event) {
//         angular.element("#"+ event.currentTarget.children[0].id).focus(); 
//    };

//CR 3845
$scope.tpaList = [];
    $scope.getTPAList = function(){
        $scope.tpaDetails = null;
        let reqData = {
            "userCode": CommonServices.getCommonData("userId"),
            "stakeCode": CommonServices.getCommonData("stakeCode").toUpperCase(),
            // "stateCode" : CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.state,
            "branchCode": CommonServices.getCommonData("LoginData").branchCode,
            "quoteNumber" : null
        }

        let getTPAListResponse = RestServices.postService(RestServices.urlPathsNewPortal.getTPAList, reqData);
        getTPAListResponse.then(
            function (response) { //success
                CommonServices.showLoading(false);
                if (response.data.hasOwnProperty('errorMessage')) {
                    CommonServices.showLoading(false);
                    CommonServices.showAlert(response.data.errorMessage);
                } else {
                   $scope.tpaList = response.data.tpaList || [];
                   if(CommonServices.floaterObj && CommonServices.floaterObj.selectedTPA){
                       $scope.tpaDetails = CommonServices.floaterObj.selectedTPA;
                   }else{
                        $scope.tpaList.forEach(item=>{
                            if(item.indicator==='Y') $scope.tpaDetails = item.tpaCode;
                        });
                   } 
                }

            }, function (error) { //failure
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            }
        );

    }
    $scope.getTPAList();

   // Start CR_3725
   $scope.nomineeDateOfBirthshow = false;
   var mydateStr = new Date(CommonServices.getCommonData("serverDate"));
    var mynewdateFrom = "";
	if(mydateStr != undefined){
		mynewdateFrom = new Date(mydateStr);
	} else {
		mynewdateFrom = new Date();
	}
   
   var enableProposerDOBCalfrom = getFormattedDate(mynewdateFrom);
    var enableProposerDOBCalTo =new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 66));
    
   $('#nomineeDateOfBirth').loadCalendar({
    'enableDateRange': true,
    'enableCalendarFrom': enableProposerDOBCalTo,
    'enableCalendarTo': enableProposerDOBCalfrom
   });

   $scope.nomineedateOfBirthFunc = function(){
    // var dt1 = $scope.nomineeDateOfBirth.split('/'),
    // proposerbirthDateComp = dt1[1] + '/' + dt1[0] + '/' + dt1[2], //mm/dd/yyyy
    // proposerbirthDateComp = new Date(proposerbirthDateComp);
    // var ageDifMs = Date.now() - proposerbirthDateComp.getTime();
    // var ageProposerYrs = new Date(ageDifMs); // miliseconds from epoch
    // ageProposerYrs = Math.abs(ageProposerYrs.getUTCFullYear() - 1970);
        var ageProposerYrs = calculateAge($scope.nomineeDateOfBirth);
        console.log(ageProposerYrs);
        if(ageProposerYrs < 18){
            $scope.nomineeDateOfBirthshow = true;
        }else{
            $scope.nomineeDateOfBirthshow = false;   
        }
    }

   // End CR_3725

    $scope.goBackFromRelationDetails = function () {
        CommonServices.floaterObj.goToMemeberInfoEdit = "proposerDetailsEdit";
        $(".form-group").addClass('focused');
        $state.go("policyPeriodAndNomineeDetailsHealth");
    };


    $scope.occpDataArray = [];
    if($rootScope.productName ==="CZ"){
        for (var i = 0; i < CommonServices.productDomainValues.productDomainValues.length; i++) {
            if (CommonServices.productDomainValues.productDomainValues[i].domainValues.codeId === "RELATIONSHIP_WITH_NOMINEE") {
                $scope.domainvalues = CommonServices.productDomainValues.productDomainValues[i].domainValues;
                $scope.occpDataArray.push($scope.domainvalues);
            }
        }
    }
    else{
        for (var i = 0; i < CommonServices.domainValues.domainValues.length; i++) {
            if (CommonServices.domainValues.domainValues[i].codeId === "RELATIONSHIP_WITH_THE_NOMINEE") {
                $scope.domainvalues = CommonServices.domainValues.domainValues[i];
                $scope.occpDataArray.push($scope.domainvalues);
            }
        }
    }

    if ($rootScope.productName === "UK" || $rootScope.productName === 'CJ') {  // CR_3725
        for (var i = 0; i < $scope.occpDataArray.length; i++) {
            if ($scope.occpDataArray[i].description === "Self") {
                $scope.occpDataArray.splice(i, 1);
            }
            if ($scope.occpDataArray[i].description === "Others" && $rootScope.productName !== 'CJ') {
                $scope.occpDataArray.splice(i, 1);
            }
        }
    }
    
    /**
     * CR 4092 - Corona Kavach Policy
     */
    if($rootScope.productName === 'CZ'){
        $scope.healthWorkerDetails.isHealthWorker = CommonServices.floaterObj.premiumCalcModel.healthcareWorker==='YES'? true:false;
        $scope.healthWorkerDetails.healthcareWorkerIdNo = CommonServices.floaterObj.healthcareWorkerIdNo? CommonServices.floaterObj.healthcareWorkerIdNo : ""; 
        $scope.healthWorkerDetails.healthcareWorkerIdNoRegexPattern = /^[a-zA-Z0-9]+$/;
    }

    if($rootScope.productName === 'CJ' && CommonServices.floaterObj.nomineeDetails && CommonServices.floaterObj.nomineeDetails.relationshipWithInsured){
        let nomineeRelation = CommonServices.floaterObj.nomineeDetails.relationshipWithInsured;
        let firstChar = nomineeRelation.slice(0,1).toUpperCase();
        nomineeRelation = firstChar+nomineeRelation.slice(1,nomineeRelation.length).toLowerCase();
        CommonServices.floaterObj.nomineeDetails.relationshipWithInsured = nomineeRelation;
    }

    $scope.foucs = function ($event) {
        $($event.target).parent().addClass('focused');
    };

    $scope.blur = function ($event) {
        if ($event.currentTarget.value.length > 0) {
            $($event.target).parent().addClass('focused');
        } else {
            $($event.target).parent().removeClass('focused');
        }
    };

    $scope.typeOfLogin = CommonServices.getCommonData("stakeCode");

    if($rootScope.productName!=='CZ'){
        var policyStartDate = CommonServices.floaterObj.policyStartDate;
        var arr = policyStartDate.split('/');
        policyStartDate = arr[0] + '/' + arr[1] + '/' + arr[2]; //dd/mm/yyyy
        $scope.policyStartDate = policyStartDate;
        $scope.policyEndDate = CommonServices.floaterObj.policyExpiryDate;
    }

    // var saveQuoteInpuCollections = CommonServices.floaterObj;

    $scope.nomineeDetailsFunc = function () {

        if ($scope.nomineeDetailsName !== undefined || $scope.agentModels.relationshipWithNominee !== undefined) {
            if (CommonServices.editQuoteFlag !== true) {
                if (CommonServices.floaterObj.nomineeDetails === undefined || CommonServices.floaterObj.nomineeDetails === "")
                    CommonServices.floaterObj.nomineeDetails = {};
            }

            if (CommonServices.editQuoteFlag == true && $rootScope.productName === 'CJ') {
                if (CommonServices.floaterObj.nomineeDetails === undefined || CommonServices.floaterObj.nomineeDetails === "")
                    CommonServices.floaterObj.nomineeDetails = {};
                CommonServices.floaterObj.nomineeDetails.name = $scope.nomineeDetailsName;
                CommonServices.floaterObj.nomineeDetails.relationshipWithInsured = $scope.agentModels.relationshipWithNominee;
            }
            else {
                CommonServices.floaterObj.nomineeDetails.name = $scope.nomineeDetailsName;
                CommonServices.floaterObj.nomineeDetails.relationshipWithInsured = $scope.agentModels.relationshipWithNominee;
            }
            

        //     console.log("$scope.nomineeAppointeeName__jet");
        //     console.log($scope.nomineeDetailsName);
        //     console.log($scope.agentModels.relationshipWithNominee);
        //    console.log($scope.agentModels.nomineeAppointeeName);
        //    console.log($scope.agentModels.nomineePolicyholder);

            if ($rootScope.productName === 'CJ' || $rootScope.productName === 'CZ') { 
                CommonServices.floaterObj.nomineeDetails.nomineeDateOfBirth = $scope.nomineeDateOfBirth; 
                CommonServices.floaterObj.nomineeDetails.nomineeAppointeeName = $scope.nomineeDateOfBirthshow? $scope.agentModels.nomineeAppointeeName: undefined;
                CommonServices.floaterObj.nomineeDetails.nomineePolicyholder = $scope.nomineeDateOfBirthshow? $scope.agentModels.nomineePolicyholder: undefined;
            }
        } else {
            if ($rootScope.productName==='RK' || CommonServices.editQuoteFlag !== true) {
                if (CommonServices.floaterObj.nomineeDetails === undefined || CommonServices.floaterObj.nomineeDetails === "")
                    CommonServices.floaterObj.nomineeDetails = {};
            }
            else {
                CommonServices.floaterObj.nomineeDetails.name = CommonServices.floaterObj.name;
                CommonServices.floaterObj.nomineeDetails.relationshipWithInsured = CommonServices.floaterObj.relationshipWithInsured;
                if ($rootScope.productName === 'CJ' || $rootScope.productName === 'CZ') { 
                    CommonServices.floaterObj.nomineeDetails.nomineeDateOfBirth = $scope.nomineeDateOfBirth;
                    CommonServices.floaterObj.nomineeDetails.nomineeAppointeeName = $scope.nomineeDateOfBirthshow? $scope.agentModels.nomineeAppointeeName: undefined;
                    CommonServices.floaterObj.nomineeDetails.nomineePolicyholder = $scope.nomineeDateOfBirthshow? $scope.agentModels.nomineePolicyholder: undefined;
                }
            }

        }
    }

    $scope.goToRelationScreen = function () {
        CommonServices.floaterObj.tpaDetails = $scope.tpaList.filter(item=> item.tpaCode===$scope.tpaDetails)[0];
        CommonServices.floaterObj.selectedTPA = CommonServices.floaterObj.tpaDetails?CommonServices.floaterObj.tpaDetails.tpaCode:undefined;
        $scope.nomineeDetailsFunc();
        if($scope.healthWorkerDetails.isHealthWorker)
            CommonServices.floaterObj.healthcareWorkerIdNo = $scope.healthWorkerDetails.healthcareWorkerIdNo;
        CommonServices.floaterObj.screenName = "relationDetails";
        $state.go("relationDetails");
    };

    //Relation Details Starts	
    $scope.getRelatedAgentDetails = function () {

        if(CommonServices.getCommonData("stakeCode") !== 'DEVLP-OFF') {
            return;
        }
        
        var getAgentListInput = {
            "userProfile": {
                "userId": CommonServices.getCommonData("userId"),
                "loggedInRole": "SUPERUSER"
            },
            partyDetails: {
                partyType: "I"
            }
        };

        var getAgentListResponse = RestServices.postService(RestServices.urlPathsNewPortal.getAgentList, getAgentListInput);
        getAgentListResponse.then(
            function (response) { //success

                CommonServices.showLoading(false);
                if (response.data.hasOwnProperty('errorMessage')) {
                    CommonServices.showLoading(false);
                    CommonServices.showAlert(response.data.errorMessage);
                } else {
                    $scope.relatedAgentsOfLoggedInDevOff = response.data.partyDetailsList;
                    if($scope.relatedAgentsOfLoggedInDevOff.length==0){
                        CommonServices.showAlert("No records found");
                        return;
                    }
                    if (CommonServices.floaterObj.selectedAgentDetails !== undefined && CommonServices.floaterObj.selectedAgentDetails !== "") {
                        for (var i = 0; i < $scope.relatedAgentsOfLoggedInDevOff.length; i++) {
                            if ($scope.relatedAgentsOfLoggedInDevOff[i].partyCode === CommonServices.floaterObj.selectedAgentDetails[0].partyCode) {
                                $scope.agentModels.selectedAgent = i;
                            }
                        }
                    }

                }

            },
            function (error) { //failure
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            }
        );
    };


    $scope.agentRequired = function () {
        if ($scope.agentModels.relationDetailsRadio === 'yes') {
            $scope.isAgentRequired = false;
        } else {
            $scope.isAgentRequired = true;
            $scope.agentModels.selectedAgent = -1;
        }
    };

    $scope.editRelationDetails = function () {
        $scope.isAgentRequired = false;
        $scope.agentModels.relationDetailsRadio = 'yes';
        $scope.getRelatedAgentDetails();
        //$scope.selectedRadioYes = false;
    };

    $scope.relationSearchClose = function () {
        //$scope.selectedRadioYes = false;
        $scope.agentModels.relationDetailsRadio = false;
        //$scope.agentNotRequired = true;
        $scope.agentModels.relationDetailsRadio = 'no';
    };

    //Relation Details Ends

    $rootScope.saveQuote = function () {
       // console.log(CommonServices.floaterObj.riskDeatilsForSaveQuoteHealth);
        $scope.nomineeDetailsFunc();
        
        if($scope.healthWorkerDetails.isHealthWorker)
            CommonServices.floaterObj.healthcareWorkerIdNo = $scope.healthWorkerDetails.healthcareWorkerIdNo;
        CommonServices.floaterObj.proportionateDeduction = $scope.noProportionateDeduction;

        CommonServices.floaterObj.serviceCall = "saveQuote";
        CommonServices.floaterObj.tpaDetails = $scope.tpaList.filter(item=> item.tpaCode===$scope.tpaDetails)[0]; //CR3845
        if ($scope.agentModels.relationDetailsRadio !== 'no' && $scope.agentModels.relationDetailsRadio !== undefined && $scope.agentModels.selectedAgent!==undefined) {
            if (CommonServices.getCommonData("stakeCode") === 'DEVLP-OFF') {
                $scope.selectedAgentDetails.push({
                    "partyCode": $scope.relatedAgentsOfLoggedInDevOff[$scope.agentModels.selectedAgent].partyCode,
                    "partyStakeCode": "AGENT",
                    "partyName": $scope.relatedAgentsOfLoggedInDevOff[$scope.agentModels.selectedAgent].partyName,
                    "address": $scope.relatedAgentsOfLoggedInDevOff[$scope.agentModels.selectedAgent].address
                });
                CommonServices.floaterObj.selectedAgentDetails = $scope.selectedAgentDetails;
            }

        } else {
            CommonServices.floaterObj.selectedAgentDetails = undefined;
        }

         //CR3845
         CommonServices.floaterObj.selectedTPA = CommonServices.floaterObj.tpaDetails?CommonServices.floaterObj.tpaDetails.tpaCode:undefined;
         let partyDetailsList = []; 
		if(CommonServices.getCommonData("stakeCode") ==='DEVLP-OFF' && CommonServices.floaterObj.selectedAgentDetails){
			partyDetailsList.push(CommonServices.floaterObj.selectedAgentDetails[0]);
		}
		if(CommonServices.floaterObj && CommonServices.floaterObj.tpaDetails && (CommonServices.getCommonData("stakeCode") ==='DEVLP-OFF' || CommonServices.getCommonData("stakeCode") ==='AGENT')){
			partyDetailsList.push({
				"partyCode": CommonServices.floaterObj.tpaDetails.tpaCode,
				"partyStakeCode":"TPA",
				"partyName": CommonServices.floaterObj.tpaDetails.tpaName
			});
		}

        //Health Save Quote Input
        var healthSaveQuoteInput;
        let saveQuoteURL = RestServices.urlPathsNewPortal.topUpSaveQuote;
        if ($rootScope.productName === "UK") {   // CR_3725
            //console.log("CommonServices.floaterObj____",CommonServices.floaterObj);
            healthSaveQuoteInput = {
                "quote": {
                    "quoteNumber": CommonServices.floaterObj.quoteNumber,
                    "productCode": $rootScope.productName,
                    "policyHolderCode": CommonServices.policyDetailsObj.saveQuotePolicyHolderCode,
                    "isTPARequired": null,
                    "branchcode": null,
                    "policyHolderName": CommonServices.floaterObj.addedMemberDetails[0].riskDetails.nameOfInsuredPerson,
                    "policyStartDate": $scope.policyStartDate,
                    "policyExpiryDate": $scope.policyEndDate,
                    "mobileNo": null,
                    "emailId": null,
                    "progressLevel": "DQ",
                    "optionalCoverINoProportionateDeduction": CommonServices.floaterObj.proportionateDeduction === true ? "Y" : "N",
                    "optionalCoverIIIRevisioninCataractLimit": "N", //CR3738A - CommonServices.floaterObj.cataract === true ? "Y" : "N"
                    "optionalCoverIVVoluntaryCopay": CommonServices.floaterObj.voluntaryCoPay === true ? "Y" : "N",
                    "preMedicalCheckUpDetails": null,
                    "premiumDetails": {
                        "grossPremium": CommonServices.floaterObj.premiumDetails.grossPremium,
                        "netPremium": CommonServices.floaterObj.premiumDetails.netPremium,
                        "noOfMembers": parseInt(CommonServices.floaterObj.numberOfMembers),
                        "sumInsured": parseInt(CommonServices.floaterObj.premiumDetails.sumInsured)
                    },
                    "nomineeDetails": {
                        "name": CommonServices.floaterObj.nomineeDetails.name.toUpperCase(),
                        "relationshipWithInsured": CommonServices.floaterObj.nomineeDetails.relationshipWithInsured
                    },
                    "risks": CommonServices.floaterObj.addedMemberDetails,
                    "partyDetailsList": (CommonServices.getCommonData("stakeCode") ==='DEVLP-OFF' || CommonServices.getCommonData("stakeCode") ==='AGENT')?partyDetailsList:undefined
                },
                "userProfile": {
                    "userId": CommonServices.getCommonData("userId"),
                    "loggedInRole": "SUPERUSER"
                }
            }
        
        }else if($rootScope.productName === "CJ"){
            healthSaveQuoteInput = {
                "quote": {
                    "quoteNumber": CommonServices.floaterObj.quoteNumber,
                    "productCode": $rootScope.productName,
                    "policyHolderCode": CommonServices.policyDetailsObj.saveQuotePolicyHolderCode,
                    "isTPARequired": null,
                    "branchcode": null,
                    "policyHolderName": CommonServices.floaterObj.addedMemberDetails[0].riskDetails.nameOfInsuredPerson,
                    "policyStartDate": $scope.policyStartDate,
                    "policyExpiryDate": $scope.policyEndDate,
                    "mobileNo": null,
                    "emailId": null,
                    "progressLevel": "DQ",
                    //"preMedicalCheckUpDetails": null,
                    "premiumDetails": {
                        "grossPremium": CommonServices.floaterObj.premiumDetails.grossPremium,
                        "netPremium": CommonServices.floaterObj.premiumDetails.netPremium,
                        "noOfMembers": parseInt(CommonServices.floaterObj.numberOfMembers),
                        "sumInsured": (CommonServices.floaterObj.premiumDetails.sumInsured) //parseInt(100000),
                    },
                    "nomineeDetails": {
                        "name": CommonServices.floaterObj.nomineeDetails.name.toUpperCase(),
                        "relationshipWithInsured": CommonServices.floaterObj.nomineeDetails.relationshipWithInsured.toUpperCase(),
                        "dobOfNominee": $rootScope.productName === 'CJ' ? CommonServices.floaterObj.nomineeDetails.nomineeDateOfBirth : "", // CR_3725
                        "nameOfTheAppointee": $rootScope.productName === 'CJ' ? ($scope.nomineeDateOfBirthshow ? CommonServices.floaterObj.nomineeDetails.nomineeAppointeeName : "") : "", // CR_3725
                        "relationshipOfTheAppointee": $rootScope.productName === 'CJ' ? ($scope.nomineeDateOfBirthshow ? CommonServices.floaterObj.nomineeDetails.nomineePolicyholder : "") : "" // CR_3725
                    },
                    "risks": CommonServices.floaterObj.addedMemberDetails,
                    "partyDetailsList": (CommonServices.getCommonData("stakeCode") ==='DEVLP-OFF' || CommonServices.getCommonData("stakeCode") ==='AGENT')?partyDetailsList:undefined
                },
                "userProfile": {
                    "userId": CommonServices.getCommonData("userId"),
                    "loggedInRole": "SUPERUSER"
                }
            }
        }else if($rootScope.productName === "CZ"){
            healthSaveQuoteInput = {
                "quote": {
                    "quoteNumber": CommonServices.floaterObj.quoteNumber,
                    "productCode": $rootScope.productName,
                    "policyHolderCode": CommonServices.policyDetailsObj.saveQuotePolicyHolderCode,
                    "typeOfCover": CommonServices.floaterObj.typeOfCover,
                    "sumInsured": CommonServices.floaterObj.typeOfCover === 'INDV'? "0" : CommonServices.floaterObj.sumInsured,
                    "isTPARequired": null,
                    "branchcode": null,
                    "policyHolderName": CommonServices.floaterObj.addedMemberDetails[0].riskDetails.nameOfInsuredPerson,
                    "policyStartDate": CommonServices.floaterObj.premiumCalcModel.policyDetails.policyStartDate,
                    "policyExpiryDate": CommonServices.floaterObj.premiumCalcModel.policyDetails.policyStartDate,
                    "mobileNo": null,
                    "emailId": null,
                    "progressLevel": "DQ",
                    "healthcareWorker": CommonServices.floaterObj.premiumCalcModel.healthcareWorker,
                    "hospCashBenefit": CommonServices.floaterObj.premiumCalcModel.hospCashBenefit,
                    "policyDuration": CommonServices.floaterObj.premiumCalcModel.policyDetails.policyDuration,
                    "healthcareWorkerIdNo": $scope.healthWorkerDetails.healthcareWorkerIdNo,
                    "premiumDetails": {
                        "grossPremium": CommonServices.floaterObj.premiumDetails.grossPremium,
                        "netPremium": CommonServices.floaterObj.premiumDetails.netPremium,
                        "noOfMembers": parseInt(CommonServices.floaterObj.numberOfMembers),
                    },
                    "memberCoveredInPolicy": "YES",
                    "nomineeDetails": {
                        "name": CommonServices.floaterObj.nomineeDetails.name.toUpperCase(),
                        "relationshipWithInsured": CommonServices.floaterObj.nomineeDetails.relationshipWithInsured,
                        "dobOfNominee": CommonServices.floaterObj.nomineeDetails.nomineeDateOfBirth,
                        "nameOfTheAppointee": $scope.nomineeDateOfBirthshow ? CommonServices.floaterObj.nomineeDetails.nomineeAppointeeName : null,
                        "relationshipOfTheAppointee": $scope.nomineeDateOfBirthshow ? CommonServices.floaterObj.nomineeDetails.nomineePolicyholder : null,
                    },
                    "risks": CommonServices.floaterObj.addedMemberDetails,
                    "partyDetailsList": (CommonServices.getCommonData("stakeCode") ==='DEVLP-OFF' || CommonServices.getCommonData("stakeCode") ==='AGENT') ? partyDetailsList : undefined
                },
                "userProfile": {
                    "userId": CommonServices.getCommonData("userId"),
                    "loggedInRole": "SUPERUSER"
                }
            }
        }else if($rootScope.productName === "RK"){
            saveQuoteURL = RestServices.urlPathsNewPortal.cpSaveQuote;
            healthSaveQuoteInput = {
                "quote": {

                    "quoteNumber":CommonServices.floaterObj.quoteNumber,
                    "productCode": "RK",
                    "policyHolderCode": CommonServices.floaterObj.policyHolderCode,
                    "policyHolderName":CommonServices.floaterObj.policyHolderName,
                    "policyStartDate": CommonServices.floaterObj.policyDetails.policyStartDate,
                    "policyExpiryDate": CommonServices.floaterObj.policyDetails.policyEndDate,
                    "term": CommonServices.floaterObj.policyDetails.policyDuration,
                    "mobileNo": null,
                    "emailId": null,
                    "progressLevel": null,
                    "risks":CommonServices.floaterObj.addedMemberDetails,
                    "partyDetailsList": CommonServices.getCommonData("stakeCode") === 'DEVLP-OFF' ? CommonServices.floaterObj.selectedAgentDetails : undefined
                },
                "userProfile": {
                    "userId": CommonServices.getCommonData("userId"),
                    "loggedInRole": "SUPERUSER"
                }
            }
        }else if($rootScope.productName === "NP"){
            healthSaveQuoteInput = {
                "quote": {
                    "quoteNumber": CommonServices.floaterObj.quoteNumber,
                    "productCode": $rootScope.productName,
                    "policyHolderCode": CommonServices.policyDetailsObj.saveQuotePolicyHolderCode,
                    "isTPARequired": null,
                    "policyBranchCode": null,
                    "policyHolderName": CommonServices.floaterObj.addedMemberDetails[0].riskDetails.nameOfInsuredPerson !== undefined ? CommonServices.floaterObj.addedMemberDetails[0].riskDetails.nameOfInsuredPerson : CommonServices.floaterObj.policyHolderDetails.nameOfInsuredPerson,
                    "roomRentRider": "N",
                    "policyStartDate": $scope.policyStartDate,
                    "policyExpiryDate": $scope.policyEndDate,
                    "memberCoveredInPolicy": CommonServices.floaterObj.memberCoveredInPolicy === 'Y' ? "YES" : "NO",
                    "mobileNo": null,
                    "emailId": null,
                    "progressLevel": null,
                    "typeOfCover": null,
                    "preMedicalCheckUpDetails": null,
                    "optionalCoverINoProportionateDeduction":  CommonServices.floaterObj.proportionateDeduction === true ? "Y" : "N",
                    "physicianDetails": {
                        "physicianName": null,
                        "physicianAddress": null
                    },
                    "nomineeDetails": {
                        "name": CommonServices.floaterObj.nomineeDetails.name.toUpperCase(),
                        "relationshipWithInsured": CommonServices.floaterObj.nomineeDetails.relationshipWithInsured
                    },
                    "risks": CommonServices.floaterObj.riskDeatilsForSaveQuoteHealth,
                    "partyDetailsList": (CommonServices.getCommonData("stakeCode") ==='DEVLP-OFF' || CommonServices.getCommonData("stakeCode") ==='AGENT')?partyDetailsList:undefined
                },
                "userProfile": {
                    "userId": CommonServices.getCommonData("userId"),
                    "loggedInRole": "SUPERUSER"
                }
            };
        }else{
            healthSaveQuoteInput = {
                "quote": {
                    "quoteNumber": CommonServices.floaterObj.quoteNumber,
                    "productCode": $rootScope.productName,
                    "policyHolderCode": CommonServices.policyDetailsObj.saveQuotePolicyHolderCode,
                    "isTPARequired": null,
                    "policyBranchCode": null,
                    "policyHolderName": CommonServices.floaterObj.addedMemberDetails[0].riskDetails.nameOfInsuredPerson !== undefined ? CommonServices.floaterObj.addedMemberDetails[0].riskDetails.nameOfInsuredPerson : CommonServices.floaterObj.policyHolderDetails.nameOfInsuredPerson,
                    "roomRentRider": "N",
                    "policyStartDate": $scope.policyStartDate,
                    "policyExpiryDate": $scope.policyEndDate,
                    "memberCoveredInPolicy": CommonServices.floaterObj.memberCoveredInPolicy === 'Y' ? "YES" : "NO",
                    "mobileNo": null,
                    "emailId": null,
                    "progressLevel": null,
                    "typeOfCover": null,
                    "preMedicalCheckUpDetails": null,
                    "physicianDetails": {
                        "physicianName": null,
                        "physicianAddress": null
                    },
                    "nomineeDetails": {
                        "name": CommonServices.floaterObj.nomineeDetails.name.toUpperCase(),
                        "relationshipWithInsured": CommonServices.floaterObj.nomineeDetails.relationshipWithInsured
                    },
                    "risks": CommonServices.floaterObj.riskDeatilsForSaveQuoteHealth,
                    "partyDetailsList": (CommonServices.getCommonData("stakeCode") ==='DEVLP-OFF' || CommonServices.getCommonData("stakeCode") ==='AGENT')?partyDetailsList:undefined
                },
                "userProfile": {
                    "userId": CommonServices.getCommonData("userId"),
                    "loggedInRole": "SUPERUSER"
                }
            };
        }

        if (CommonServices.floaterObj.memberCoveredInPolicy === 'N') {
            healthSaveQuoteInput.quote.policyHolderDetails = CommonServices.floaterObj.policyHolderDetails;
        }

        // var healthSaveQuoteResponse = RestServices.postService(RestServices.urlPathsNewPortal.topUpSaveQuote, healthSaveQuoteInput);
        var healthSaveQuoteResponse = RestServices.postService(saveQuoteURL, healthSaveQuoteInput);
        healthSaveQuoteResponse.then(
            function (response) { // success	
                CommonServices.showLoading(false);
                if ($rootScope.productName === 'UK' || $rootScope.productName === 'CJ') { //CR_3725
                    if (response.data.userProfile.footer.hasOwnProperty('errorDescription') && response.data.userProfile.footer.errorDescription === " Portal Quotation Saved") {
                        CommonServices.floaterObj.saveQuoteResponse = response.data.quote;
                        if ($rootScope.backFlag === "premCal") {
                            $state.go("floaterBasicPremium");
                        } else {
                            $state.go("reviewSummaryScreen");
                        }
                    } else {
                        CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
                    }
                }else if($rootScope.productName === 'RK'){
                    if(response.data.hasOwnProperty('errorMessage')){
						CommonServices.showAlert(response.data.errorMessage);
					}else{
						let totSumIns = CommonServices.floaterObj.premiumDetails.sumInsured;
                        CommonServices.floaterObj.saveQuoteResponse = response.data.quote;
						CommonServices.floaterObj.premiumDetails = response.data.quote.premiumDetails;
						CommonServices.floaterObj.premiumDetails.sumInsured = totSumIns;
						$state.go("rakReviewSummary");
					}
                } else {
                    if (response.data.hasOwnProperty('errorMessage')) {
                        CommonServices.showAlert(response.data.errorMessage);
                    } else {
                        CommonServices.floaterObj.saveQuoteResponse = response.data.quote;
                        if ($rootScope.backFlag === "premCal") {
                            $state.go("floaterBasicPremium");
                        } else {
                            $state.go("reviewSummaryScreen");
                        }
                    }
                }
            },
            function (error) { // failure
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            }
        );


    };

    if (CommonServices.floaterObj.goToRelationInfoEdit === "relationInfoEdit") {
        if (CommonServices.floaterObj.saveQuoteResponse.partyDetailsList === undefined) {
            //$scope.selectedRadioYes = false;
            $scope.agentModels.relationDetailsRadio = false;
            //$scope.isAgentRequired = true;
            $scope.agentModels.relationDetailsRadio = 'no';
            $scope.selectedAgentPartyCode = undefined;

        } else {
            $scope.isAgentRequired = false;
            $scope.getRelatedAgentDetails();
            $scope.agentModels.relationDetailsRadio = 'yes';
            //$scope.selectedRadioYes = false;
        }

    }


    /* if (CommonServices.floaterObj.goToNomineeInfoEdit === "policyHolderInformation" || $rootScope.backFlag === "reviewSummary"|| CommonServices.floaterObj.goToNomineeInfoEdit === "policyPeriodAndNomineeEdit" || CommonServices.floaterObj.goToNomineeInfoEdit === "proposerDetailsEdit") { */
    if (CommonServices.floaterObj.nomineeDetails !== undefined && CommonServices.floaterObj.localStorageVAlues !== undefined) {
        $scope.nomineeDetailsName = CommonServices.floaterObj.nomineeDetails.name;
        $scope.agentModels.relationshipWithNominee = CommonServices.floaterObj.nomineeDetails.relationshipWithInsured;
        /** 
         * CR 4092 - Corona Kavach Policy
         */
        if ($rootScope.productName === 'CZ') {
            $scope.healthWorkerDetails.healthcareWorkerIdNo = (CommonServices.editQuoteFlag)? CommonServices.floaterObj.healthcareWorkerIdNo : CommonServices.floaterObj.healthcareWorkerIdNo;
        }
       
        switch($rootScope.productName)
        {
            case 'CZ':
            case 'CJ':
                    $scope.nomineeDateOfBirth = (CommonServices.editQuoteFlag)? CommonServices.floaterObj.nomineeDetails.dobOfNominee: CommonServices.floaterObj.nomineeDetails.nomineeDateOfBirth;
                    // var dt1 = $scope.nomineeDateOfBirth.split('/'),
                    // proposerbirthDateComp = dt1[1] + '/' + dt1[0] + '/' + dt1[2], //mm/dd/yyyy
                    // proposerbirthDateComp = new Date(proposerbirthDateComp);
                    // var ageDifMs = Date.now() - proposerbirthDateComp.getTime();
                    // var ageProposerYrs = new Date(ageDifMs); // miliseconds from epoch
                    // ageProposerYrs = Math.abs(ageProposerYrs.getUTCFullYear() - 1970);
                    var ageProposerYrs = calculateAge($scope.nomineeDateOfBirth)
                        console.log(ageProposerYrs);

                    if(ageProposerYrs < 18){
                        $scope.nomineeDateOfBirthshow = true;
                        $scope.agentModels.nomineeAppointeeName = (CommonServices.editQuoteFlag)? CommonServices.floaterObj.nomineeDetails.nameOfTheAppointee: CommonServices.floaterObj.nomineeDetails.nomineeAppointeeName;
                        $scope.agentModels.nomineePolicyholder = (CommonServices.editQuoteFlag)? CommonServices.floaterObj.nomineeDetails.relationshipOfTheAppointee: CommonServices.floaterObj.nomineeDetails.nomineePolicyholder;
                    }else{
                        $scope.nomineeDateOfBirthshow = false;
                    }
   
        }
        
        $scope.isAgentRequired = false;
        if (CommonServices.floaterObj.selectedAgentDetails !== undefined && CommonServices.floaterObj.selectedAgentDetails !== "") {
            $scope.agentModels.relationDetailsRadio = 'yes';
            $scope.getRelatedAgentDetails();
            $scope.isAgentRequired = false;
        } else {
            $scope.agentModels.relationDetailsRadio = 'no';
            $scope.isAgentRequired = true;
        }

    }
    if (CommonServices.editQuoteFlag === true) {
        /**
         * Added 
         * CR 4092 - Corona Kavach Policy
         */
        if($rootScope.productName === 'CJ' || $rootScope.productName === 'CZ') {
            $scope.nomineeDetailsName = CommonServices.floaterObj.nomineeDetails.name;
            $scope.agentModels.relationshipWithNominee = CommonServices.floaterObj.nomineeDetails.relationshipWithInsured;
        //  $scope.nomineeDateOfBirth = CommonServices.floaterObj.nomineeDetails.nomineeDateOfBirth;
            $scope.nomineeDateOfBirth = CommonServices.floaterObj.nomineeDetails.dobOfNominee;

            var dt1 = $scope.nomineeDateOfBirth.split('/'),
            proposerbirthDateComp = dt1[1] + '/' + dt1[0] + '/' + dt1[2], //mm/dd/yyyy
            proposerbirthDateComp = new Date(proposerbirthDateComp);
            var ageDifMs = Date.now() - proposerbirthDateComp.getTime();
            var ageProposerYrs = new Date(ageDifMs); // miliseconds from epoch
            ageProposerYrs = Math.abs(ageProposerYrs.getUTCFullYear() - 1970);
            console.log(ageProposerYrs);

            if(ageProposerYrs < 18){
                $scope.nomineeDateOfBirthshow = true;
                $scope.agentModels.nomineeAppointeeName = CommonServices.floaterObj.nomineeDetails.nameOfTheAppointee;
                $scope.agentModels.nomineePolicyholder = CommonServices.floaterObj.nomineeDetails.relationshipOfTheAppointee;
            }else{
                $scope.nomineeDateOfBirthshow = false;
            }
        } else {
            $scope.nomineeDetailsName = CommonServices.floaterObj.nomineeDetails.name;
            $scope.agentModels.relationshipWithNominee = CommonServices.floaterObj.nomineeDetails.relationshipWithInsured;
        }
        
        if (CommonServices.floaterObj.selectedAgentDetails !== undefined && CommonServices.floaterObj.selectedAgentDetails !== "") {
            $scope.isAgentRequired = false;
            $scope.agentModels.relationDetailsRadio = 'yes';
            $scope.getRelatedAgentDetails();
        }
        else {
            $scope.agentModels.relationDetailsRadio = 'no';
            $scope.isAgentRequired = true;
        }
    }

}]);

agentApp.controller('reviewSummaryHealthCtrl', ['$scope', 'RestServices', 'CommonServices', '$state', '$rootScope','CartServices', function ($scope, RestServices, CommonServices, $state, $rootScope,CartServices) {
    CommonServices.floaterObj.reviewSummary = true;
    $rootScope.backFlag = "reviewSummary";
    CommonServices.policyDetailsObj.policyHolderCreateText = "reviewSummaryEdit";
    $scope.typeOfLogin = CommonServices.getCommonData("stakeCode");

    $scope.reviewSummaryObj = CommonServices.floaterObj;
    if ($rootScope.productName !== 'UK' && $rootScope.productName !== 'CJ' && $rootScope.productName !== 'CZ') {
        console.log( $scope.reviewSummaryObj.addedMemberDetails);
        $scope.reviewSummaryObj.addedMemberDetails = $scope.reviewSummaryObj.riskDeatilsForSaveQuoteHealth;
    }

    $scope.reviewSummaryObj.getPolicyholderDetails = CommonServices.policyDetailsObj.getPolicyholderDetails;

    /* 3712 Starts
    $scope.reviewSummaryObj.getPolicyholderDetails.partyDetails.individualDetails.clientNationality = 'NonIndian'; //3712
    $scope.reviewSummaryObj.getPolicyholderDetails.partyDetails.individualDetails.clientCountry = 'Australia'; //3712
    // 3712 Ends */
    /* Starts 3712 
    for (var i = 0; i < $scope.reviewSummaryObj.addedMemberDetails.length; i++) {
        $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.clientNationality = 'NonIndian'+i;
        $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.clientCountry = 'Australia'+i;
    }
    // Ends 3712 */
    

    

    if (CommonServices.policyDetailsObj.state === undefined) {
        if(CommonServices.policyDetailsObj.navigationFrom == "existing" && CommonServices.userClickedOnDivFunc != true){
            $scope.reviewSummaryObj.state = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.stateName.state;
            $scope.reviewSummaryObj.city = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.cityName.city;
        }else{
            $scope.reviewSummaryObj.state = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.state;
            $scope.reviewSummaryObj.city = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.city;
        }
        $scope.reviewSummaryObj.pinCode = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.pinCode;
    } else {
        $scope.reviewSummaryObj.state = CommonServices.policyDetailsObj.state;
        $scope.reviewSummaryObj.city = CommonServices.policyDetailsObj.city;
        $scope.reviewSummaryObj.pinCode = CommonServices.policyDetailsObj.pinCode;

    }

    $scope.goBack = function () {
        if (CommonServices.floaterObj.screenName === "relationDetails") {
            $state.go("relationDetails");
        } else
        //JIT CR_3725
             if($rootScope.productName === 'CJ' || $rootScope.productName === 'CZ') {
                $state.go("policyPeriodAndNomineeDetailsHealthCancer");
                return;
            }
            else {
                $state.go("policyPeriodAndNomineeDetailsHealth");
                return;
            }
    }
    $scope.occpDataArray = [];
    $scope.relationWithPolicyHolderList = []; // Added for CR 4902
    if($rootScope.productName === "CZ"){
        $scope.occupationArray = CommonServices.floaterObj.occupationArray;
        $scope.childOccupationArray = CommonServices.floaterObj.childOccupationArray;
        for (var i = 0; i < CommonServices.productDomainValues.productDomainValues.length; i++) {
            if (CommonServices.productDomainValues.productDomainValues[i].domainValues.codeId === "RELATIONSHIP_WITH_NOMINEE") {
                $scope.domainvalues = CommonServices.productDomainValues.productDomainValues[i].domainValues;
                if ($scope.domainvalues.codeValue === $scope.reviewSummaryObj.nomineeDetails.relationshipWithInsured) {
                    $scope.nomineeDescription = $scope.domainvalues.mnemonic;
                }
                $scope.occpDataArray.push($scope.domainvalues);
            } else if (CommonServices.productDomainValues.productDomainValues[i].domainValues.codeId === "RELATIONSHIP_WITH_PROPOSER") {
                $scope.domainvalues = CommonServices.productDomainValues.productDomainValues[i].domainValues;
                $scope.relationWithPolicyHolderList.push($scope.domainvalues);
            }
        }
    }
    else{
        for (var i = 0; i < CommonServices.domainValues.domainValues.length; i++) {
            if (CommonServices.domainValues.domainValues[i].codeId === "RELATIONSHIP_WITH_THE_NOMINEE") {
                $scope.domainvalues = CommonServices.domainValues.domainValues[i];
                $scope.occpDataArray.push($scope.domainvalues);
            }
        }
    }
    if ($rootScope.productName === "UK" || $rootScope.productName === 'CJ') {
        for (var i = 0; i < $scope.occpDataArray.length; i++) {
            if ($scope.occpDataArray[i].description === "Self") {
                $scope.occpDataArray.splice(i, 1);
            }
            if ($scope.occpDataArray[i].description === "Others") {
                $scope.occpDataArray.splice(i, 1);
            } 
        }
    }

    //Code commenting due to uat issue fixing for CR3738
    // if ($rootScope.productName === "NP" || $rootScope.productName === "UK") {
    //     for (var i = 0; i < $scope.occpDataArray.length; i++) {
    //         if ($scope.reviewSummaryObj.nomineeDetails.relationshipWithInsured === $scope.occpDataArray[i].codeValue) {
    //             $scope.nomineeDescription = $scope.occpDataArray[i].description;
    //         }
    //     }
    // }
    // else {
        $scope.nomineeDescription = $scope.nomineeDescription || $scope.reviewSummaryObj.nomineeDetails.relationshipWithInsured;
    // }

    var daughterCount = 0, childCount = 0, parentCount = 0, wardCount = 0;  //Jit CR_3725
    var guardianCount = 0, parentCount = 0, brotherCount = 0, sisterCount = 0;
    var parentInLaw=0;

    if ($rootScope.productName != 'CJ' && $rootScope.productName != 'UK' && $rootScope.productName != 'NP' && $rootScope.productName != 'CZ') { // Give this condition for other products except Cancer product // Jit CR_3725 //CR3738A/B
        for (var i = 0; i < $scope.reviewSummaryObj.addedMemberDetails.length; i++) {
            if ($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILDREN" || $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILD") {
                childCount = childCount + 1;
            } else if ($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PARENTS') {
                parentCount = parentCount + 1;
            } else if ($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "DAUGHTER") {
                daughterCount = daughterCount + 1;
            }
            if ($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PROPOSER' || ($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SELF' && $scope.reviewSummaryObj.memberCoveredInPolicy === 'Y')) {
                $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.policyHolder = "Proposer";
            }
            else if ($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SPOUSE') {
                $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.policyHolder = "Spouse";
            } else {
                if ($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "DAUGHTER" && daughterCount === 1) {
                    $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.policyHolder = "DAUGHTER 1";
                } else if ($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "DAUGHTER" && daughterCount === 2) {
                    $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.policyHolder = "DAUGHTER 2";
                } else if (($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILDREN" || $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILD") && childCount === 1) {
                    $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.policyHolder = "CHILD 1";
                } else if (($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILDREN" || $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILD") && childCount === 2) {
                    $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.policyHolder = "CHILD 2";
                } else if (($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILDREN" || $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILD") && childCount === 3) {
                    $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.policyHolder = "CHILD 3";
                } else if (($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILDREN" || $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILD") && childCount === 4) {
                    $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.policyHolder = "CHILD 4";
                } else if (($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILDREN" || $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILD") && childCount === 5) {
                    $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.policyHolder = "CHILD 5";
                } else if (($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILDREN" || $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILD") && childCount === 6) {
                    $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.policyHolder = "CHILD 6";
                } else if ($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PARENTS' && parentCount === 1) {
                    $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.policyHolder = "PARENT 1";
                } else if ($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PARENTS' && parentCount === 2) {
                    $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.policyHolder = "PARENT 2";
                } else {

                }
            }
        }
    }

    else if($rootScope.productName === 'CZ') {
        for (var i = 0; i < $scope.reviewSummaryObj.addedMemberDetails.length; i++) {
            if ($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PROPOSER' || $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase()==='SELF')
                $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.policyHolder = "Proposer";
            else if($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase()==='SPOUSE')
                $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.policyHolder = "Spouse";
            else if($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase()==='CHILD') {
                childCount++;
                $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.policyHolder = "Child " + childCount;
            }
            else if($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase()==='PARENT') {
                parentCount++;
                $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.policyHolder = "Parent " + parentCount;
            }
            else if($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase()==='PARINLAW') {
                parentInLaw++;
                $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.policyHolder = "Parent-in-law " + parentInLaw;
            }
        }
    }

    else if ($rootScope.productName === 'CJ') { //Jit CR_3725
        console.log($scope.reviewSummaryObj.addedMemberDetails);
        for (var i = 0; i < $scope.reviewSummaryObj.addedMemberDetails.length; i++) {
            if ($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILDREN" || $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILD") {
                childCount = childCount + 1;
            } else if ($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PARENTS') {
                parentCount = parentCount + 1;
            } else if ($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'WARD') {
                wardCount = wardCount + 1;
            } 
            // else if ($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "DAUGHTER") {
            //     daughterCount = daughterCount + 1;
            // }
            if ($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PROPOSER' || ($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SELF' && $scope.reviewSummaryObj.memberCoveredInPolicy === 'Y')) {
                $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.policyHolder = "Proposer";
            }
            else if ($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SPOUSE') {
                $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.policyHolder = "Spouse";
            } else {
                // if ($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "DAUGHTER" && daughterCount === 1) {
                //     $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.policyHolder = "DAUGHTER 1";
                // } else if ($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "DAUGHTER" && daughterCount === 2) {
                //     $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.policyHolder = "DAUGHTER 2";
                // } 
                if (($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILDREN" || $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILD")) {
                    $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.policyHolder = "CHILD "+childCount;
                }  else if ($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PARENTS') {
                    $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.policyHolder = "PARENT "+parentCount;
                } else if ($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'WARD') {
                    $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.policyHolder = "WARD "+wardCount;
                } else {

                }
            }
        }
    }

    else if ($rootScope.productName === 'UK' || $rootScope.productName === 'NP') { //CR_3738_A/B
        
        for (var i = 0; i < $scope.reviewSummaryObj.addedMemberDetails.length; i++) {
            if ($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILDREN" || $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILD") {
                childCount = childCount + 1;
                $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.policyHolder = "CHILD "+childCount;
            } else if ($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PARENTS') {
                parentCount = parentCount + 1;
                $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.policyHolder = "PARENT "+parentCount;
            } else if ($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'WARD') {
                wardCount = wardCount + 1;
                $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.policyHolder = "WARD "+wardCount;
            } else if ($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'GUARDIAN') {
                guardianCount = guardianCount + 1;
                $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.policyHolder = "GUARDIAN "+guardianCount;
            } else if ($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PARENTS') {
                parentCount = parentCount + 1;
                $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.policyHolder = "PARENT "+parentCount;
            } else if ($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'BROTHER') {
                brotherCount = brotherCount + 1;
                $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.policyHolder = "BROTHER "+brotherCount;
            } else if ($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SISTER') {
                sisterCount = sisterCount + 1;
                $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.policyHolder = "SISTER "+sisterCount;
            } else if ($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PROPOSER' || ($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SELF' && $scope.reviewSummaryObj.memberCoveredInPolicy === 'Y')) {
                $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.policyHolder = "Proposer";
            }else if ($scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SPOUSE') {
                $scope.reviewSummaryObj.addedMemberDetails[i].riskDetails.policyHolder = "Spouse";
            }
        }
    }

    $scope.breakupClickSummary = function () {

        var healthViewBreakUpInput;
        switch($rootScope.productName){
            case "UK":
            case "CJ":
            case "CZ": 
                    healthViewBreakUpInput = {
                        "header": null,
                        "quote": {
                            "quoteNumber": CommonServices.floaterObj.saveQuoteResponse.quoteNumber,
                            "policyHolderCode": CommonServices.policyDetailsObj.saveQuotePolicyHolderCode,
                            "productCode": $rootScope.productName,
                        }
                    };
                    break;
            default: 
                    healthViewBreakUpInput = {
                        "header": null,
                        "quote": {
                            "quoteNumber": CommonServices.floaterObj.saveQuoteResponse.quoteNumber,
                            "policyHolderCode": CommonServices.floaterObj.saveQuoteResponse.policyHolderCode
                        }
                    };
        }
        // if ($rootScope.productName === "UK") { // CR_3725
        //     healthViewBreakUpInput = {
        //         "header": null,
        //         "quote": {
        //             "quoteNumber": CommonServices.floaterObj.saveQuoteResponse.quoteNumber,
        //             "policyHolderCode": CommonServices.policyDetailsObj.saveQuotePolicyHolderCode,
        //             "productCode": "UK"
        //         }
        //     };
        // } else if($rootScope.productName === 'CJ'){
        //     healthViewBreakUpInput = {
        //         "header": null,
        //         "quote": {
        //             "quoteNumber": CommonServices.floaterObj.saveQuoteResponse.quoteNumber,
        //             "policyHolderCode": CommonServices.policyDetailsObj.saveQuotePolicyHolderCode,
        //             "productCode": 'CJ'
        //         }
        //     };
        // }
        //  else {
        //     healthViewBreakUpInput = {
        //         "header": null,
        //         "quote": {
        //             "quoteNumber": CommonServices.floaterObj.saveQuoteResponse.quoteNumber,
        //             "policyHolderCode": CommonServices.floaterObj.saveQuoteResponse.policyHolderCode
        //         }
        //     };
        // }
        var healthViewBreakUpResponse = RestServices.postService(RestServices.urlPathsNewPortal.healthViewBreakup, healthViewBreakUpInput);
        healthViewBreakUpResponse.then(
            function (response) { // success 

                CommonServices.showLoading(false);

                CommonServices.floaterObj.viewBreakUpResponse = response.data.quote;
                CommonServices.floaterObj.viewBreakUpNavigation = "ViewBreakupSummary";
                if($rootScope.productName==="CZ")
                    $state.go("coronaKavachViewBreakup");
                else 
                    $state.go("floaterViewBreakUp");
            },
            function (error) { // failure
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            });
    };
    /**CR690 Start**/
    $rootScope.panmodalOpen = false;

    var panCardDetails = {
        "quoteNumber": CommonServices.floaterObj.saveQuoteResponse.quoteNumber,
        "policyHolderCode": CommonServices.floaterObj.saveQuoteResponse.policyHolderCode
    }
    CommonServices.setCommonData("panCardData", panCardDetails);
    /**CR690 End**/

    $scope.approvePay = function (type = '') {
        var messageSystemDate = CommonServices.getCommonData("serverDate");
        var arr = messageSystemDate.split('/');
        messageSystemDate = arr[1] + '/' + arr[0] + '/' + arr[2]; //mm/dd/yyyy  
        CommonServices.setCommonData("addToCart", type); // CR3546

        var msg = "Do you wish to proceed with approval of quotation? Once Approved, no more changes will be made available on your quotation. Your payment should be made by " + messageSystemDate + " 23:59:59. Please confirm";
		CommonServices.messageModal('info', msg, false, 'Cancel', 'Confirm', function () {
			paymentExitFunction(2);
		}, function () {
			paymentExitFunction(1);
		}, 'Alert');

        // if (CommonServices.deviceType !== "NA") {
        //     navigator.notification.confirm("Do you wish to proceed with approval of quotation? Once Approved, no more changes will be made available on your quotation. Your payment should be made by " + messageSystemDate + " 23:59:59. Please confirm.", paymentExitFunction, "Alert", ["Confirm", "Cancel"]);
        // } else {
        //     var approvePayment;
        //     approvePayment = confirm("Do you wish to proceed with approval of quotation? Once Approved, no more changes will be made available on your quotation. Your payment should be made by " + messageSystemDate + " 23:59:59. Please confirm");
        //     if (approvePayment === true) {
        //         paymentExitFunction(1);
        //     } else {
        //         paymentExitFunction(2);
        //     }
        // }
    };

    function paymentExitFunction(button) {
        if (button == 1) {
            switch($rootScope.productName){
                case "CZ":   
                case "UK":
                case "CJ":
                    $state.go("docUpload");
                    break;
                default:
                    approvePolicy();
            }
            
            // if ($rootScope.productName === "UK" || $rootScope.productName === 'CJ') { // CR_3725
            //     $state.go("docUpload");
            // } else {
            //     approvePolicy();
            // }

        } else {
            CommonServices.showLoading(false);
            // $state.go("reviewSummaryScreen");
        }
    }

    function approvePolicy() {
        var approveQuoteInput = {
            "userProfile": {
                "userId": CommonServices.getCommonData("userId"),
                "loggedInRole": "SUPERUSER",
                "uiFlow": "NON_CUSTOMER"
            },
            "quote": {
                "quoteNumber": $scope.reviewSummaryObj.quoteNumber,
                "policyType": null,
                "productCode": $rootScope.productName
            }
        };

        if (CommonServices.getCommonData("addToCart")==='cart') { // CR3546
            CartServices.approveAndAddToCart(approveQuoteInput, $rootScope.productName);
            return;
        }
        var TopUpapproveQuoteGen = RestServices.postService(RestServices.urlPathsNewPortal.approveRenewedQuote, approveQuoteInput);
        TopUpapproveQuoteGen.then(
            function (response) { // success 

                CommonServices.showLoading(false);

                CommonServices.floaterObj.TopUpapproveQuoteRes = response.data.quote;
                CommonServices.setCommonData("CollectionPaymentDetails", CommonServices.floaterObj.saveQuoteResponse);
                //CommonServices.showLoading(false);
                if (response.data.userProfile.footer.errorDescription.trim() === "Proposal Approved") {
                    $state.go("collectionForm");
                }
                else {
                    /**CR690 Start**/
                    if (response.data.userProfile.footer.errorCode === "224541") {
                        $rootScope.panmodalOpen = true;
                        CommonServices.setCommonData("setPanMsg", response.data.userProfile.footer.errorDescription);
                    }
                    /**CR690 End**/
                    else {
                        CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
                    }

                }

            },
            function (error) { // failure
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            });

    };


    $scope.goToPolicyHolderInfoEdit = function () {
        CommonServices.policyDetailsObj.enableEditModels = "MODELSEDIT";
        CommonServices.floaterObj.goToNomineeInfoEdit = "policyHolderInformation";
        $state.go("policyHolderInformation");

    };

    $scope.goToMemeberInfoEdit = function () {

        CommonServices.floaterObj.goToNomineeInfoEdit = "proposerDetailsEdit";
        $state.go("proposerDetailsHealth");

    };

    $scope.goToNomineeInfoEdit = function () {
        CommonServices.floaterObj.goToNomineeInfoEdit = "policyPeriodAndNomineeEdit";
        if ($rootScope.productName === 'CJ' || $rootScope.productName === 'CZ') { // CR_3725
           $state.go("policyPeriodAndNomineeDetailsHealthCancer");
           return;
        }else{
            $state.go("policyPeriodAndNomineeDetailsHealth");
            return;
        }
    };

    $scope.goToRelationInfoEdit = function () {
        CommonServices.floaterObj.goToRelationInfoEdit = "relationInfoEdit";
        $state.go("relationDetails");
    };

}]);

agentApp.controller('docUploadCtrl', ['$scope', 'RestServices', 'CommonServices', '$state', '$rootScope','CartServices', function ($scope, RestServices, CommonServices, $state, $rootScope,CartServices) {

    $scope.goBack = function () {
        /******  CR_0052 changes in go-back function starts **********/
        if ($rootScope.productName === "HN") {
            $state.go("toUpReviewSummaryScreen");
        } else {
            $state.go("reviewSummaryScreen");
        }
        /******CR_0052 changes in go-back function ends**********/
    }

    if ($rootScope.productName === 'HN') {
        $scope.filesAllowedToUpload = "Note:Only jpg, jpeg,bmp,png and pdf file types are allowed";
    } else {
        $scope.filesAllowedToUpload = "Note:Only jpg, jpeg,gif,bmp,png file types are allowed";
    }


    $("#showOverlay").hide();

    /******  CR_0052 changes in getIDdocName switch starts **********/
    function getIDdocName(idDocName) {
        switch (idDocName) {
            case "VoterIden":
	        case "Voter Identity Card":
            case "VOTERID":
            case "Voter Iden":
                return "Voter Identity Card";
            case "AD":
            case "AADHAR":
                return "Aadhaar Card";
            case "PANCard":
            case "PAN":
            case "PAN Card":
                return "PAN Card";
            case "DrivingLS":
            case "Driving LS":
	        case "Driving License":
            case "DRIVING":
                return "Driving License";
            case "Passport":
            case "PASSPORT":
                return "Passport";
            case "AO":
            case "Any Other":
            case "OTHER":
                return "Any Other";
            default:
                return "";
        }
    }
    /******  CR_0052 changes in getIDdocName switch ends **********/

    var childCount = 0, parentCount = 0, wardCount = 0; brotherCount = 0, sisterCount = 0, parentCount = 0, guardianCount = 0;
    for (var i = 0; i < CommonServices.floaterObj.addedMemberDetails.length; i++) {
        CommonServices.floaterObj.addedMemberDetails[i].selectedDocName = "";
    }
    if($rootScope.productName==="CZ"){
        $scope.insuredMembers = [];
        $scope.insuredMembers = angular.copy(CommonServices.floaterObj.addedMemberDetails.slice(0,1));
    }
    else 
        $scope.insuredMembers = CommonServices.floaterObj.addedMemberDetails;
    
    $scope.healthCareObj = {
        isHealthWorker: CommonServices.floaterObj.premiumCalcModel?CommonServices.floaterObj.premiumCalcModel.healthcareWorker:'NO',
        selectedDocName: ''
    }
    $scope.docLastIndex = 1;
    if (CommonServices.uploadUKFiles === undefined || CommonServices.uploadUKFiles.length === 0) {
        CommonServices.uploadUKFiles = [];
        for (var i = 0; i < $scope.insuredMembers.length; i++) {
            CommonServices.uploadFiles = {
                "documentName": "",
                "docByteString": "",
                "documentType": "",
                "toBeUploadedFlag": true,
                "duplicateFlag": false
            };
            // CommonServices.floaterObj.addedMemberDetails[i].riskDetails.natureOfId = getIDdocName(CommonServices.floaterObj.addedMemberDetails[i].riskDetails.natureOfId);
            setDetails(i);
            $scope.insuredMembers[i].selectedDocName = "";
            CommonServices.uploadUKFiles.push(CommonServices.uploadFiles);
        }
        if($rootScope.productName=='CZ' && $scope.healthCareObj.isHealthWorker=='YES'){
            CommonServices.uploadFiles = {
                "documentName": "",
                "docByteString": "",
                "documentType": "HEALTHCAREID",
                "toBeUploadedFlag": true,
                "duplicateFlag": false
            };
            $scope.healthCareObj.selectedDocName = "";    
            CommonServices.uploadUKFiles.push(CommonServices.uploadFiles);
        }
    } else {
        for (var i = 0; i < $scope.insuredMembers.length; i++) {
            CommonServices.uploadFiles = {
                "documentName": CommonServices.uploadUKFiles[i].documentName,
                "docByteString": CommonServices.uploadUKFiles[i].docByteString,
                "documentType": CommonServices.uploadUKFiles[i].documentType,
                "toBeUploadedFlag": true,
                "duplicateFlag": false
            };
            $scope.insuredMembers[i].selectedDocName = CommonServices.uploadUKFiles[i].documentName;
            setDetails(i);
        }
        if($rootScope.productName=='CZ' && $scope.healthCareObj.isHealthWorker=='YES'){
            CommonServices.uploadFiles = {
                "documentName": CommonServices.uploadUKFiles[$scope.docLastIndex].documentName,
                "docByteString": CommonServices.uploadUKFiles[$scope.docLastIndex].docByteString,
                "documentType": "HEALTHCAREID",
                "toBeUploadedFlag": true,
                "duplicateFlag": false
            };
            $scope.healthCareObj.selectedDocName = CommonServices.uploadUKFiles[$scope.docLastIndex].documentName;
        }
    }

    function setDetails(i) {
        if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILDREN") {
            childCount = childCount + 1;
            if($rootScope.productName === 'CJ'){
                $scope.insuredMembers[i].riskDetails.relation = "Child "+childCount;
            }else{
                if (childCount === 1) {
                    $scope.insuredMembers[i].riskDetails.relation = "Child 1";
                } else if (childCount === 2) {
                    $scope.insuredMembers[i].riskDetails.relation = "Child 2";
                } else if (childCount === 3) {
                    $scope.insuredMembers[i].riskDetails.relation = "Child 3";
                } else if (childCount === 4) {
                    $scope.insuredMembers[i].riskDetails.relation = "Child 4";
                }
            }
           
        } else if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "WARD") { // This condition for CR_3725(Cancer gurad)
            wardCount = wardCount + 1; 
            $scope.insuredMembers[i].riskDetails.relation = "Ward "+wardCount;
        }
        else if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "PARENTS") {
            parentCount = parentCount + 1;
            if (parentCount === 1) {
                $scope.insuredMembers[i].riskDetails.relation = "Parent 1";
            } else if (parentCount === 2) {
                $scope.insuredMembers[i].riskDetails.relation = "Parent 2";
            }
        }else if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "GUARDIAN") { // This condition for CR_3738_A
            guardianCount = guardianCount + 1; 
            $scope.insuredMembers[i].riskDetails.relation = "Guardian "+guardianCount;
        }else if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "PARENTS") { // This condition for CR_3738_A
            parentCount = parentCount + 1; 
            $scope.insuredMembers[i].riskDetails.relation = "Parent "+parentCount;
        }else if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "BROTHER") { // This condition for CR_3738_A
            brotherCount = brotherCount + 1; 
            $scope.insuredMembers[i].riskDetails.relation = "Brother "+brotherCount;
        }else if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "SISTER") { // This condition for CR_3738_A
            sisterCount = sisterCount + 1; 
            $scope.insuredMembers[i].riskDetails.relation = "Sister "+sisterCount;
        } else {
            $scope.insuredMembers[i].riskDetails.relation = CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder;
        }
        if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.natureOfId === "Any Other" || CommonServices.floaterObj.addedMemberDetails[i].riskDetails.natureOfId === "AO") {
            CommonServices.uploadFiles.documentType = CommonServices.floaterObj.addedMemberDetails[i].riskDetails.anyOtherId;
            $scope.insuredMembers[i].riskDetails.natureOfId = CommonServices.floaterObj.addedMemberDetails[i].riskDetails.anyOtherId;
        } else {
            CommonServices.uploadFiles.documentType = getIDdocName(CommonServices.floaterObj.addedMemberDetails[i].riskDetails.natureOfId);
            $scope.insuredMembers[i].riskDetails.natureOfId = getIDdocName(CommonServices.floaterObj.addedMemberDetails[i].riskDetails.natureOfId);
        }
    }

    $scope.chooseImageUploadOption = function (event) {
        $scope.artID = $(event.target).parent().parent().attr("id");
        $("#upload-options").show();
        $("#showOverlay").show();
    }

    $scope.capturePhoto = function (event) {


        if (CommonServices.deviceType == "A") {
            navigator.camera.getPicture($scope.onSuccessImageUploadAndroid, $scope.onFailImageUploadAndroid, { quality: 85, destinationType: 0, targetWidth: 2048, targetHeight: 2048 });
        } else if (CommonServices.deviceType == "I") {
            navigator.camera.getPicture($scope.onSuccessImageUploadAndroid, $scope.onFailImageUploadAndroid, { quality: 50, destinationType: 0, targetWidth: 2048, targetHeight: 2048 });
        } else {
            var fileURI = "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAUDBAQEAwUEBAQFBQUGBwwIBwcHBw8LCwkMEQ8SEhEPERETFhwXExQaFRERGCEYGh0dHx8fExciJCIeJBweHx7/2wBDAQUFBQcGBw4ICA4eFBEUHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh7/wAARCASACAADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD5dRFUbcE+tOUADFAJHB5PtSgHk96x1NEhMAIelInAz1pxBIpEA/OgVhyj5e9C455oOM5OePehcA5x1osINqk7iMkVSkObvNaBPHtVCUYuVB6HihBcnUAn0qYsD8o9OtMABHHGOKVQM5PagBQDt44xTgTnk0Ee/m9RkMaQhhVWyGRWAOOaglsrMqQ9tEc9flBqztwP60wjIJ6ihAZ0ui6PId32RVJ/u8VWl8L6UwJjMqH68flitcjB+U03+v6VSk0KxzsvhK2Kny7t1/3lqm3hO4AJjmibj+I4rrSQ3ykHJHemgEDsfTiqUxcpxE3hrUUJKRK4H91s5qpNpF/ENzWkuM44Gf5V6EGdCSDjFAdtoxxinzgoHmb2lwrcwyAj1UiomSQfwtgV6e7K+Q8Yb6iq8trZSDc9tGSfbFCaDlPNdrE9PzpQzA4Fd/Jo+mSE/6MFJ9+lU5fDdgc7HkU9jwadxcpxoY4PFGa6ebwvwTFeDAAUDBAQEAwUEBAQFBQUGBwwIBwcHBw8LCwkMEQ8SEhEPERETFhwXExQaFRERGCEYGh0dHx8fExciJCIeJBweHx7/2wBDAQUFBQcGBw4ICA4eFBEUHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh7/wAARCASACAADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD5dRFUbcE+tOUADFAJHB5PtSgHk96x1NEhMAIelInAz1pxBIpEA/OgVhyj5e9C455oOM5OePehcA5x1osINqk7iMkVSkObvNaBPHtVCUYuVB6HihBcnUAn0qYsD8o9OtMABHHGOKVQM5PagBQDt44xTgTnk0Ee/m9RkMaQhhVWyGRWAOOaglsrMqQ9tEc9flBqztwP60wjIJ6ihAZ0ui6PId32RVJ/u8VWl8L6UwJjMqH68flitcjB+U03+v6VSk0KxzsvhK2Kny7t1/3lqm3hO4AJjmibj+I4rrSQ3ykHJHemgEDsfTiqUxcpxE3hrUUJKRK4H91s5qpNpF/ENzWkuM44Gf5V6EGdCSDjFADAAUDBAQEAwUEBAQFBQUGBwwIBwcHBw8LCwkMEQ8SEhEPERETFhwXExQaFRERGCEYGh0dHx8fExciJCIeJBweHx7/2wBDAQUFBQcGBw4ICA4eFBEUHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eCSDjFA";
            this.onSuccessImageUploadAndroid(fileURI);
        }
    };

    $scope.onSuccessImageUploadAndroid = function (fileURI) {
        $("#upload-options").hide();
        $("#showOverlay").hide();
        var rId = Math.floor(Math.random() * (999 - 100 + 1));
        var fileURISize = sizeof(fileURI) / (1024 * 2.67);
        if (fileURISize >= 100 && fileURISize < 501) {
            var fileNamePrefix = Math.floor(Math.random() * (999 - 100 + 1));
            var docName = $('#' + $scope.artID+' .doc-label').text().replace('*', '').trim();
            var newFileName = docName + "_" + fileNamePrefix + ".JPG";
            CommonServices.uploadUKFiles[parseInt($scope.artID)].documentName = newFileName;
            CommonServices.uploadUKFiles[parseInt($scope.artID)].docByteString = fileURI;
            $scope.$apply(function () {
                if($scope.insuredMembers[parseInt($scope.artID)]){
                    
                    $scope.insuredMembers[parseInt($scope.artID)].selectedDocName = newFileName;
                }else{
                    $scope.healthCareObj.selectedDocName = newFileName;
                }
            });
        } else {
            CommonServices.showAlert("Image size should be greater than 100kb and less than 500kb");
            return false;
        }
    };

    $scope.hideModal = function () {
        $("#upload-options").hide();
        $("#showOverlay").hide();
    }

    function checkDuplicatesInSelectedDocs(toBeUploadedDocs) {
        var toBeUploadedDocsComapre = [];
        angular.copy(toBeUploadedDocs, toBeUploadedDocsComapre);
        if (toBeUploadedDocs.length > 1) {
            for (var i = 0; i < toBeUploadedDocsComapre.length; i++) {
                for (var j = 0; j < toBeUploadedDocs.length; j++) {
                    if (toBeUploadedDocs[i].documentName.toUpperCase() === toBeUploadedDocs[j].documentName.toUpperCase() && i !== j) {
                        toBeUploadedDocs[i].toBeUploadedFlag = false;
                        toBeUploadedDocs[i].duplicateFlag = true;
                        break;
                    }
                }
            }
        }
        return toBeUploadedDocs;
    }

    $scope.approveQuote = function () {

        /**CR690 Start**/
        var panCardDetails = {
            "quoteNumber": $rootScope.productName === "HN" ? CommonServices.topUpObj.reviewSummaryResponse.quote.quoteNumber : CommonServices.floaterObj.saveQuoteResponse.quoteNumber,
            "policyHolderCode": $rootScope.productName === "HN" ? CommonServices.topUpObj.reviewSummaryResponse.quote.policyHolderCode : CommonServices.floaterObj.saveQuoteResponse.policyHolderCode
        }
        CommonServices.setCommonData("panCardData", panCardDetails);
        /**CR690 End**/

        var fileTobeUploaded = [];
        $scope.docsToService = [];
        fileTobeUploaded = CommonServices.uploadUKFiles;
        for (var i = 0; i < fileTobeUploaded.length; i++) {
            $scope.documentsList = {};
            $scope.documentsList.documentName = fileTobeUploaded[i].documentName;
            $scope.documentsList.docByteString = fileTobeUploaded[i].docByteString;
            $scope.documentsList.documentType = fileTobeUploaded[i].documentType;
            $scope.documentsList.toBeUploadedFlag = true;
            $scope.documentsList.duplicateFlag = false;
            $scope.docsToService.push($scope.documentsList);
        }
        var checkDuplicatesFile = checkDuplicatesInSelectedDocs($scope.docsToService);
        var toBeUploadedDuplicateNames = [];
        for (var i = 0; i < checkDuplicatesFile.length; i++) {
            if (checkDuplicatesFile[i].duplicateFlag) {
                toBeUploadedDuplicateNames.push(checkDuplicatesFile[i].documentName);
            }
        }
        toBeUploadedDuplicateNames = toBeUploadedDuplicateNames.filter(function (item, index, inputArray) {
            return inputArray.indexOf(item) == index;
        });
        if (toBeUploadedDuplicateNames.length > 0) {
            CommonServices.showAlert(toBeUploadedDuplicateNames + " is selected more than once for this quote number. Please select a different file.");
        } else {

            var approveQuoteData = {
                "userProfile": {
                    "userId": CommonServices.getCommonData("userId"),
                    "loggedInRole": "SUPERUSER",
                    "uiFlow": "NON_CUSTOMER"
                },
                "quote": {
                    "quoteNumber": $rootScope.productName === "HN" ? CommonServices.topUpObj.reviewSummaryResponse.quote.quoteNumber : CommonServices.floaterObj.saveQuoteResponse.quoteNumber,
                    "policyType": null,
                    "productCode": $rootScope.productName,
                    "policyStartDate": $rootScope.productName === "HN" ? CommonServices.topUpObj.reviewSummaryResponse.quote.policyStartDate : CommonServices.floaterObj.policyStartDate,
                    "documents": $scope.docsToService
                }
            };
            if (CommonServices.getCommonData("addToCart")==='cart') { // CR3546
                CartServices.approveAndAddToCart(approveQuoteData, $rootScope.productName);
                return;
            }
            var approveQuoteResponse = RestServices.postService(RestServices.urlPathsNewPortal.approveRenewedQuote, approveQuoteData);
            approveQuoteResponse.then(
                function (response) {
                    CommonServices.showLoading(false);
                    if (response.data.userProfile.footer.errorDescription.trim() === "Proposal Approved") {
                        CommonServices.floaterObj.TopUpapproveQuoteRes = response.data.quote;
                        CommonServices.uploadUKFiles = [];

                        if ($rootScope.productName === "HN") {
                            CommonServices.setCommonData("CollectionPaymentDetails", CommonServices.topUpObj.reviewSummaryResponse.quote);
                            $state.go("collectionForm");

                        } else {
                            CommonServices.setCommonData("CollectionPaymentDetails", CommonServices.floaterObj.saveQuoteResponse);
                            $state.go("collectionForm");
                        }

                    } else {

                        if (response.data.userProfile.footer.errorCode === "224541") {
                            $rootScope.panmodalOpen = true;
                            CommonServices.setCommonData("setPanMsg", response.data.userProfile.footer.errorDescription);
                        } else {
                            CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
                        }
                    }
                },
                function (error) {
                    CommonServices.showLoading(false);
                    RestServices.handleWebServiceError(error);
                });
        }
    }

}]);

//Terms & Conditions Start
agentApp.controller('termsConditionCntrl', ['$scope', 'RestServices', 'CommonServices', '$state', '$rootScope', function ($scope, RestServices, CommonServices, $state, $rootScope) {
    $scope.termsObj = {
        closeModal: function () {
            $rootScope.termsCondOpen = false;
        }
    }
}]);
//Terms & Conditions End
