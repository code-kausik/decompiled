agentApp.controller('agentController', ['$scope','RestServices','CommonServices','$rootScope', function ($scope, RestServices,CommonServices,$rootScope) {
	
			$scope.bodyHeight = window.innerHeight+'px';
            CommonServices.showLoading(true);
			CommonServices.setCommonData("changePassFlag","");
	 
			$rootScope.buyNow={
            	grihaSuvidha :{
            		sumInsuredList:[]
            	},twoWheeler:{
					newVehicle : "",
					quickQuote:{},
					basicPremium:{},
					additionalDetails:{},
					ncbDetails:{},
					addCovers:{},
					prevPolicyDetails:{},
					financierDetails:{},
					insuredDetails:{},
					summaryDetails:{}
            	},
				personalAccident:{
					premiumCalculator:{},
					insuredDetails:{},
					spouseDetails:{},
					daughterDetails:{},
					sonDetails:{},
					individualDetails:{},
					saveQuoteRes:{}
            	},
            	standaloneCPAProduct:{
            		
            	}
            };
			
			// Open Message Modal in parent controller
			// $scope.$parent.messageModal('info', message, false, 'OK', '', function () {}, function () {}, 'Alert');
			$scope.messageModal = function (type, message, headerText = false, noBtnText = "No", yesBtnText = 'Yes', noButtonAction, yesButtonAction, title = '') {
				CommonServices.messageModal(type, message, headerText, noBtnText, yesBtnText, noButtonAction, yesButtonAction, title);
			};
			
			// Open General Modal in parent controller
			// $scope.$parent.generalModal({title: 'Terms', bodyMsg: 'Test'}, 'lg');
			$scope.generalModal = function (modalObj = {}, modalSize = 'lg') {
				CommonServices.generalModal(modalObj, modalSize);
			};

			// $scope.generalModal({title: 'Terms', bodyMsg: 'Test'}, 'lg');
}]);

agentApp.controller('LoginCtrl', ['$rootScope','$scope', 'CommonServices','$location', 'RestServices','$state', '$timeout','CartServices', function($rootScope, $scope, CommonServices, $location, RestServices, $state, $timeout,CartServices) {

		/** Green Marathon Start **/
	    $scope.$on("displayMarathon", function(event, args) {
	        showMarathon();
	    });
	    if(CommonServices.displayMarathon){
	        showMarathon();
	    }
	    function showMarathon(){
	        $scope.showGreenMarathon = true;
	        $timeout(function() {
	             $scope.showGreenMarathon = false;
	         }, 10000);
	    }
	    $scope.showGreenMarathonFun = function(){
	        $scope.showGreenMarathon = false;
	    }
	/** Green Marathon End **/
	
	if(!CommonServices.checkNetConnection()) {
		CommonServices.showAlert("Cannot connect to Internet.\nPlease check your network settings.");
	}
	if (!CommonServices.checkNetConnection()) {
		CommonServices.showAlert("Cannot connect to Internet. Please check your network settings.");
		CommonServices.showLoading(false);
	}

		$scope.login = function() { //login

		if($scope.agent.userName === null) {
			CommonServices.showAlert("Please enter agent Username");
		} else if( $scope.agent.password === null) {
			CommonServices.showAlert("Please enter agent Password");
		}
		CommonServices.setCommonData("userCode", $scope.agent.userName);
	  	var loginDataNewPortal = JSON.stringify({
            "userId": $scope.agent.userName,
            "password": $scope.agent.password,
			"quoteProcess":"false" 
        });
		
		  CommonServices.setCommonData("hash",$scope.agent.password); //3585
		
			if(CommonServices.checkNetConnection()) {

				var loginResponseNewPortal;
				CommonServices.showLoading(true);
				if (CommonServices.deviceType !== "NA") {
				//	window.plugins.sslCertificateChecker.check(sslSuccessCallback,sslErrorCallback,RestServices.serverPath,RestServices.fingerprint);
				
				if($rootScope.environment == 'p')
					{
						window.plugins.sslCertificateChecker.check(sslSuccessCallback,sslErrorCallback,RestServices.serverPath,RestServices.fingerprint);
					}
					else 
					{
					sslSuccessCallback(CommonServices.deviceType);
					}
				}
				else{
					 sslSuccessCallback(CommonServices.deviceType);
				}
				function sslSuccessCallback(message) {
				RestServices.headerWithoutToken = true;
				loginResponseNewPortal = RestServices.postService(RestServices.urlPathsNewPortal.login, loginDataNewPortal);
				if(loginResponseNewPortal === undefined){
				}else{
				loginResponseNewPortal.then(
					function(response) { // success
					if(response.data === ""){
						CommonServices.showLoading(false);
						CommonServices.showAlert("Could not connect to server. Please try again later.");
					} else if(response.data.userProfile && response.data.userProfile.stakeCode && response.data.userProfile.stakeCode.toUpperCase() === "SURVEYOR"){ //Production issue #578959 stop surveyor login
						CommonServices.showLoading(false);
						CommonServices.showAlert("Invalid credentials");

					} else {
						RestServices.headerWithoutToken = false;
						$scope.changePasswordFlag = response.data.changePasswordFlag;
						CommonServices.setCommonData("changePassFlag",$scope.changePasswordFlag);
						CommonServices.setCommonData("loggedIn",response.data.loggedIn);
						
						if(response.data.loggedIn === "false"){
							CommonServices.showAlert(response.data.statusMessage);
							CommonServices.showLoading(false);
						} else {
							if(response.data.userProfile.stakeCode === undefined){
								CommonServices.showAlert("User data not found");
								CommonServices.showLoading(false);
							} else {
								CommonServices.setCommonData("LoginData",response.data);
								CommonServices.setCommonData("token",response.data.token);
								CommonServices.setCommonData("userId",response.data.userProfile.userId);
								CommonServices.setCommonData("serverDate", response.data.systemDate);
								//CommonServices.setCommonData("loggedInRole", response.data.userProfile.loggedInRole);
								CommonServices.setCommonData("loggedInRole", "SUPERUSER");
								CommonServices.setCommonData("LoginCity",response.data.city);
								CommonServices.setCommonData("stakeCode", response.data.userProfile.stakeCode);
								CommonServices.setCommonData("lastLoginDate",response.data.lastLoginDate);
								CommonServices.systemDate= response.data.systemDate;
								CommonServices.setCommonData("agentFirstName", response.data.userProfile.firstName);
								CommonServices.setCommonData("agentSecondName", response.data.userProfile.lastName);
								CommonServices.setCommonData("systemTimeStamp", response.data.systemTimeStamp);
								CommonServices.setCommonData("mobileNo", response.data.userProfile.relation.addresses[0].mobileNumber1);
								CommonServices.setCommonData("emailId", response.data.userProfile.relation.addresses[0].emailId1);
               					CommonServices.setCommonData("branchCode", response.data.branchCode);
								CommonServices.setCommonData("channel", response.data.userProfile.channel);
								if(response.data.userProfile.dob!== '' || response.data.userProfile.dob!== undefined){
								CommonServices.setCommonData("dateOfBirth", response.data.userProfile.dob); //CR-3693 Sudip
								}
								var collection = {
									"emailID":response.data.userProfile.relation.addresses[0].emailId1,
									"mobileNum":response.data.userProfile.relation.addresses[0].mobileNumber1
								}
								CommonServices.setCommonData("collectionDetails",collection)
								if($scope.changePasswordFlag === "false" || $scope.changePasswordFlag === null){
									$rootScope.onFirstLoggedIn = false; 		// to check if the user is redirected to home screen from login page CR_3773
								   	$location.path('/home');
								}
								else if($scope.changePasswordFlag === "true"){
								   $state.go('profileUpdate.changePassword');
								}
								
								/* Added for CR_NP_0744 to fetch Configuration Data*/

								/*Commented/Changed for CR_NP_0744E */
								// var getConfigurationDataInput = {"keys": ["IS_PAN_MANDATORY","IS_AADHAAR_MANDATORY"]};
								var getConfigurationDataInput = {"keys": ["IS_PAN_MANDATORY","UIDAI_WEBSITE_URL"]};
								/* CR_NP_0744E ends*/

								getConfigurationDataResponse = RestServices.postService(RestServices.urlPathsNewPortal.getConfigurationData, getConfigurationDataInput);								
								   getConfigurationDataResponse.then(
										function(response){
										  CommonServices.setCommonData("ConfigurationData", response.data.configurableDatas);
									  });					
								/*CR_NP_0744 ends*/
								
								var collectionModesData = JSON.stringify({
									"userProfile":{
										"userId":response.data.userProfile.userId,
										"channel":response.data.userProfile.channel
									}
								});
								collectionModesResponse = RestServices.postService(RestServices.urlPathsNewPortal.collectionModes, collectionModesData);
								if(collectionModesResponse === undefined){
								}else{

								collectionModesResponse.then(
									function(response) { // success
										CommonServices.showLoading(false);
										if(response.data.collectionModesList !== undefined) {
											CommonServices.setCommonData("disableCollectionMob", response.data.collectionModesList);
										} else {
											CommonServices.setCommonData("disableCollectionMob", "");
											CommonServices.showAlert("Collection modes not available");
										}
									},
									function(error) {
										CommonServices.showLoading(false);
										RestServices.headerWithoutToken = false;
									});
									}

							}

							if(localStorage.getItem("renewalNotify") === null){
							    localStorage.setItem("renewalNotify", "true");
							    if (CommonServices.deviceType != "NA") {
                                    cordova.plugins.notification.local.hasPermission(function (granted) {
                                    if(!granted){
										if(CommonServices.deviceType === "A"){
											cordova.plugins.notification.local.registerPermission(function (granted) {
												notifyRenewals();
											});
										} else if(CommonServices.deviceType === "I"){
											cordova.plugins.notification.local.requestPermission(function (granted) {
												notifyRenewals();
											});
										}   
                                    } else{
                                        notifyRenewals();
                                    }
                                    });
                                }
							}
							}
					}
						},
						function(error) { // failure
							CommonServices.showLoading(false);
							RestServices.handleWebServiceError(error);
						});
						}
                	  // Message is always: CONNECTION_SECURE.
                	  // Now do something with the trusted server.
            	}

                	 function notifyRenewals(){
                        	var date = new Date(CommonServices.getCommonData("serverDate")).setHours(8, 0, 0);
                    		cordova.plugins.notification.local.schedule({
                              id         : 1,
                              title      : 'Renewals Pending',
                              text       : "Please check if you have any renewals pending for today.",
                             foreground : true,
                             trigger    : {at: date, every: 'day'}
                                            });
                        }

                	function sslErrorCallback(message) {
                		  if (message == "CONNECTION_NOT_SECURE") {
                		  // There is likely a man in the middle attack going on, be careful!
                		  CommonServices.showAlert("Could not connect to server. Suspicious connection detected");


                		  } else if (message == "CONNECTION_FAILED") {
                		  // There was no connection (yet). Internet may be down. Try again (a few times) after a little timeout.
                		  CommonServices.showAlert("Could not connect to server. Please try again later or check your network settings");
                		  }
                	}

			} else {
				CommonServices.showAlert("Cannot connect to Internet.\nPlease check your network settings1.");
			}
		};
		
		$scope.forgotPass = function(){
			$state.go('profileUpdate.forgotPass');
		};
		
		$scope.forgottenUserId = function(){
			$state.go('profileUpdate.forgotUserID');
		}
		
		$scope.businessHolidays = function(){
			$state.go('businessHolidays.travelDetails');
		}
		
	

}]);

agentApp.controller('HomeCtrl', ['$rootScope', '$scope', 'CommonServices', 'RestServices','$state','$location', 'CartServices','$filter', function($rootScope, $scope, CommonServices, RestServices, $state, $location, CartServices,$filter) {
	CommonServices.editQuoteObj ={}; 
	$rootScope.backFlag ="";
    $scope.stakeValue = CommonServices.getCommonData("stakeCode");
	var agentFirstName = CommonServices.getCommonData("agentFirstName");
	var agentSecondName = CommonServices.getCommonData("agentSecondName");
	/*****CR 3693 - Sudip*/
	// var serverDate = CommonServices.getCommonData("serverDate"); // CR 3693 - Sudip
	// $scope.agentDateOfBirth = CommonServices.getCommonData("dateOfBirth"); // CR 3693 - Sudip

	CommonServices.isManageRenewals = false;
	if(agentFirstName !== undefined && agentSecondName !== undefined){
		$scope.agentName = agentFirstName + " " + agentSecondName;
	}if(agentFirstName === undefined){
		$scope.agentName = agentSecondName;
	} if(agentSecondName === undefined){
		$scope.agentName = agentFirstName;
	}
	/*****CR 3693 - Sudip Birthday message on dashboard*************** */
	var serverDateStr = CommonServices.getCommonData("serverDate");
	var agentBirthDateStr = CommonServices.getCommonData("dateOfBirth");
	if(serverDateStr !== undefined && serverDateStr !== '' && agentBirthDateStr !== undefined && agentBirthDateStr !== ''){
    var serverDate = new Date(serverDateStr);
    var serverDateDay = serverDate.getDate();
    var serverDateMonth = serverDate.getMonth()+1;
	
	//var agentBirthDateStr = "09/12/1993";
	var agentBirthDateSplitStr = agentBirthDateStr.split("/", 3)
	var agentNewdateFromsplitStr = agentBirthDateSplitStr[1]+'/'+agentBirthDateSplitStr[0]+'/'+agentBirthDateSplitStr[2]
	var agentNewdateFrom = new Date(agentNewdateFromsplitStr);
	var birthDayDate = agentNewdateFrom.getDate();
	var birthDayMonth = agentNewdateFrom.getMonth()+1;

		if(serverDateDay == birthDayDate && serverDateMonth == birthDayMonth){
			$scope.birthDayMessage = "New India Assurance wishes you a very Happy Birthday!";
		} else {
			$scope.birthDayMessage = "";
		}
	}
	/**********CR 3693 - Sudip*************** */
	
	$scope.lastLoginTime=CommonServices.getCommonData("lastLoginDate");
	

    //LogOut Start
    $scope.logOut = function() {
		RestServices.logOut();
    };
	//LogOut End
	
	/**
	 * CR 3546 - Cart Feature
	 */
	$scope.goTOcart = function() {
		$state.go("showCart");
	};


	/****************** UC for CR_3546 ***************/
	// $scope.cartCount = CartServices.cartListing.length;
	// CartServices.cartPaymenEnable = false;
	
	// var cartCount = CartServices.getCartCount();
	// cartCount.then(function (data) {
	// 	$scope.cartCount = data;
	// }, function (data) {
	// 	$scope.cartCount = data;
	// });

	// CartServices.cartReset();



	//Change State Start
	$scope.changeState= function(state){
		if(state == "home"){
		
			var profileDetailsInput = 
			{"userProfile":
				{"userId":CommonServices.getCommonData("userCode"),
				"loggedInRole":CommonServices.getCommonData("loggedInRole")
				}
			}
			var profileDetailsResponse = RestServices.postService(RestServices.urlPathsNewPortal.getNCProfileDetails, profileDetailsInput);
			if(profileDetailsResponse === undefined){
			}else {
			profileDetailsResponse.then(
				function(response) { // success
					if(response.data.userProfile.relation.addresses[0] !== undefined){
						CommonServices.setCommonData("profileDetailsData", response.data);
						$state.go("profileUpdate.updateProfile");
					}
					else{
						CommonServices.showAlert(response.data.errorMessage);
						return;
					}				
																
				},
				function(error) { // failure
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
			});
		    }
		}		
	}
	//Change State End	
    
    //Home Page Start
	//$scope.renewalTab={"name":"Renewals Notices","uiState":"renewalNotices","img":"images/manage-renewals-notices104x104.svg"};/*CR_675*/
	var homeListResponse = RestServices.getService('json/home.json','local');
	//$scope.profilleImg = "images/my-polices-144.svg"; /**dummy implementation for profile pic **/
	homeListResponse.then(
        function(response) { /* success */
		
			$scope.lists = response.data;
	// if($scope.stakeValue==='AGENT'){/*CR_675 Start*/
	// 				$scope.lists.push($scope.renewalTab);
	// 			}/*CR_675 End*/
			for(var i=0;i < response.data.length; i++){
				if(response.data[i].uiState == "profileUpdate.updateProfile"){
					$scope.lists[i].uiState = "home";
				}
			}
            
		      //  CommonServices.showLoading(false);
        },
        function(error) { /* failure */
            CommonServices.showLoading(false);
			RestServices.handleWebServiceError(error);
			
        });

		//Home Page End
		
		/*************Implement of CR_3693 profile pic - sudip ***********/
		function sendFCMRefreshToken(){

			let channelName = CommonServices.getCommonData("channel");
			let appId = '';
			if(channelName=='MISP') appId = 'MISPAPP';
			else if(channelName=='DEVELOPMENT OFFICER') appId = 'DEVAPP';
			else if(channelName=='DEALER') appId = 'DLAPP';
			else if(channelName=='AGENT') appId = 'AGENTAPP';
			else appId = channelName;
			 var profileFCMInput = {
                "appID":appId,
                                "userID": CommonServices.getCommonData("userId"),
                                "deviceToken":CommonServices.fcmRefreshToken, // SUBHAPAM - TODO
                                "deviceType": CommonServices.deviceType==='A'?'android':'ios' // SUBHAPAM - TODO
                                }
                            var profileFCMResponse = RestServices.postService(RestServices.urlPathsNewPortal.sendDeviceDetails, profileFCMInput);
                profileFCMResponse.then(
                    function(response) { // success 
                        //runOncePerDay();
                    },
                    function(error) { // failure
                    });
                   
        }
        
        
        if((CommonServices.fcmRefreshToken !=='' && CommonServices.fcmRefreshToken !== undefined && CommonServices.fcmRefreshToken !== null) && (CommonServices.deviceType =="A" || CommonServices.deviceType =="I")){
        
                        sendFCMRefreshToken();
              } 
                else if((CommonServices.fcmRefreshToken ==='' || CommonServices.fcmRefreshToken === undefined || CommonServices.fcmRefreshToken === null) && (CommonServices.deviceType =="A" || CommonServices.deviceType =="I")){
						device.getInfo(function(details){
							CommonServices.fcmRefreshToken = details.fcmToken;
							console.log(CommonServices.fcmRefreshToken);
							sendFCMRefreshToken();
						},function(err){
							console.log("FCM Token error");
						})
							
					}
				else{
					console.log("FCM Token error");	
				}    
				            /************************/
			
			//console.log(CommonServices.isProfilePicUpdated, CommonServices.profilePicUpdatedPath)
			$scope.profilePicDetails = CommonServices.profilePicUpdatedPath;
		if($scope.stakeValue === 'AGENT' && !CommonServices.isProfilePicUpdated){
			var profilePicDetailsInput = {
				"userId":CommonServices.getCommonData("userId")
				}
				//getUserProfileURL
			var profilePicResponse = RestServices.postService(RestServices.urlPathsNewPortal.getUserProfileURL, profilePicDetailsInput);
			if(profilePicResponse === undefined){
				$scope.profilePicDetails = "images/profile_icon.svg";
				return;
			} else{
				profilePicResponse.then(
				function(response) { // success	
					CommonServices.showLoading(false);	
					if(response.data !== ""){
						if(response.data.url === "null" || response.data.url === '' || response.data.url === undefined){
							//CommonServices.showAlert(response.data.errorMessage);
							//CommonServices.showAlert("Not able to fetch profile picture from server");
							$scope.profilePicDetails = "images/profile_icon.svg";
						}
						else{
							if(response.data.url !== undefined && response.data.url !== '' && response.data.url !== null && response.data.url !== "null"){
								$scope.profilePicDetails = response.data.url;
								CommonServices.profilePicUpdatedPath = $scope.profilePicDetails;
								CommonServices.isProfilePicUpdated = true;
								console.log("Agent profile image" +$scope.profilePicDetails);
							} else {
								//CommonServices.showAlert("Not able to fetch profile picture from server");
								$scope.profilePicDetails = "images/profile_icon.svg";
							}
						}
						
					}
					else{
						$scope.profilePicDetails = "images/profile_icon.svg";
					}
					//runOncePerDay();
				},
				function(error) { // failure
					CommonServices.showLoading(false);
					//RestServices.handleWebServiceError(error);
					$scope.profilePicDetails = "images/profile_icon.svg";
					//CommonServices.showAlert("Not able find profile pic from server");
				});
			}
		}
		/*****************Implementation CR_3693 end*****************/
		//CR 3868 starts here
		function getAdditionalDisc(){

			if($scope.stakeValue==='AGENT'){

				let requestPayload = {
					"userProfile":{
						"userId":CommonServices.getCommonData("userId"),
						"loggedInRole":CommonServices.getCommonData("loggedInRole")
					}
				}

				let discountResponse = RestServices.postService(RestServices.urlPathsNewPortal.getAddDisc, requestPayload);
				if(discountResponse){
					discountResponse.then(
						function(response) { // success
							CommonServices.showLoading(false);	
							if(response.data && response.data.addDisc !== ""){
								CommonServices.setCommonData("additionalDisc",response.data.addDisc);
							}else{
								CommonServices.setCommonData("additionalDisc","N");
							}
						},
						function(error) { // failure
							CommonServices.showLoading(false);
							RestServices.handleWebServiceError(error);
						});
				}
			}else{
				CommonServices.setCommonData("additionalDisc","N");
			}
		}
		//CR 3868 ends here
		//$scope.init = function(){
				var apdInput = {"userProfile":{
									"userId":CommonServices.getCommonData("userId"),
									"loggedInRole":CommonServices.getCommonData("loggedInRole")
									},"quote":{
										"payment":{
											"paymentDetailsList":[{"collectionMode":"APD"}]
										}
									}
								}
				
				var apdResponse = RestServices.postService(RestServices.urlPathsNewPortal.getAPDBalance, apdInput);
				if(apdResponse === undefined){
				} else{
					apdResponse.then(
						function(response) { // success	
							CommonServices.showLoading(false);	
							if(response.data !== ""){
								if(response.data.errorCode === 960){
									CommonServices.showAlert(response.data.errorMessage);
									return;
								}
								else{
									if(response.data.quote.payment.totalAmount !== undefined){
										$scope.apdDetails = response.data.quote.payment.totalAmount;
									} else {
										$scope.apdDetails = "0";
									}
								}

							}
							else{
								CommonServices.showAlert("Not able to load APD balance");
							}
							runOncePerDay();
						},
						function(error) { // failure
							CommonServices.showLoading(false);
							RestServices.handleWebServiceError(error);
					});
				}
				getAdditionalDisc(); //CR 3868
					//CR_NP_868 Start
				if($scope.stakeValue==='AGENT'){
					
					var CommissionAmtInput = {"userProfile":{
									"userId":"",
									"password":""
									},"partyDetails":{
										"partyCode":CommonServices.getCommonData("userId")
										}
									}
									//commenting out getCommissionAmt service call to solve sit issue
				// var CommissionAmtResponse = RestServices.postService(RestServices.urlPathsNewPortal.getCommissionAmt, CommissionAmtInput);
				// if(CommissionAmtResponse === undefined){
				// } else{

				// 	CommissionAmtResponse.then(
				// 		function(response) { // success	
				// 			CommonServices.showLoading(false);	
				// 			if(response.data !== ""){
				// 				if(response.data.errorCode === 960){
				// 					CommonServices.showAlert(response.data.errorMessage);
				// 					return;
				// 				}
				// 				else{
				// 					if(response.data.commission !== undefined){
				// 						$scope.CommissionDetails = response.data.commission;
				// 					} else {
				// 						$scope.CommissionDetails = "0";
				// 					}
				// 					if(response.data.incentive !== undefined){
				// 						$scope.IncentiveDetails = response.data.incentive;
				// 					} else {
				// 						$scope.IncentiveDetails = "0";
				// 					}
				// 				}
								
				// 			}
				// 			else{
				// 				CommonServices.showAlert("Not able to load Commission Amount Balance");
				// 			}
				// 			runOncePerDay();
				// 		},
				// 		function(error) { // failure
				// 			CommonServices.showLoading(false);
				// 			RestServices.handleWebServiceError(error);
				// 	});
				// 	}
				  }
					//CR_NP_868 End
					
					
					function hasOneDayPassed(){
					  var date = new Date().toLocaleDateString();
                        if( localStorage.app_date === date ){
                            if(CommonServices.getCommonData("channel") === "AGENT" && localStorage.agentChannel === "true"){
                                return false;
                              } else if(CommonServices.getCommonData("channel") === "DEALER" && localStorage.dealerChannel === "true"){
                                 return false;
                              } else if(CommonServices.getCommonData("channel") === "DEVELOPMENT OFFICER" && localStorage.devOffChannel === "true"){
                                 return false;
                              
                              /* added for CR_NP_754 */   
                                 
                              } else if(CommonServices.getCommonData("channel") === "MISP" && localStorage.mispChannel === "true"){
                                 return false;
                              }
                              
                            /* CR_NP_754 ends */ 
                          }
                          localStorage.app_date = date;
                          if(CommonServices.getCommonData("channel") === "AGENT"){
                              localStorage.agentChannel = "true";
                          } else if(CommonServices.getCommonData("channel") === "DEALER"){
                              localStorage.dealerChannel = "true";
                          } else if(CommonServices.getCommonData("channel") === "DEVELOPMENT OFFICER"){
                              localStorage.devOffChannel = "true";
                           
                            /* added for CR_NP_754 */    
                              
                          } else if(CommonServices.getCommonData("channel") === "MISP"){
                              localStorage.mispChannel = "true";
                          }
                          
                           /* CR_NP_754 ends */ 
                           
                          return true;
					}

					function runOncePerDay(){
						if(!hasOneDayPassed()) {
							CommonServices.showLoading(false);
							CommonServices.notifyRenewal = false;
							return false;
						}
						var currentDate = new Date(CommonServices.getCommonData("serverDate"));
					   CommonServices.notifyRenewal = true;
						RestServices.updateRenewalsCount(currentDate, currentDate);

					}


					$rootScope.$on("renewalsCallNotify", function(event, args) {
						/** Renewal policy service call **/
						CommonServices.notifyRenewal = false;
						var count;
						if(args.data === "") {
							count = 0;
						} else {
							count = args.data;
						}
                        var notifyText = "You have " + count + " pending for today.";
						cordova.plugins.notification.local.schedule({
						  id         : 2,
						  title      : 'Renewals Pending',
                           text       : notifyText,
                           foreground : true
                           });
					});
					
					/**** //UC for 3749
					if(CommonServices.gstIdStateCode.length == 0){
					CommonServices.getStateDomainValues();}
					*/

	/** CR_3773 START **/ 

	$scope.goToManagePolicies = function(msg) {
		$state.go("managePolicies.managePolicies");
		CommonServices.setCommonData("polNo", msg);		
	}
	
	// var lastTransactionDetailsPayload = { }
	if($rootScope.onFirstLoggedIn) {
		var fetchedLastTrasactionDetails = RestServices.postService(RestServices.urlPathsNewPortal.lastTransactionDetails, JSON.stringify({"userId": CommonServices.getCommonData("userCode").toUpperCase()}));
		if(fetchedLastTrasactionDetails === undefined) { }
		else{
			fetchedLastTrasactionDetails.then(
				function (response) {
					CommonServices.showLoading(false);
					if(response.data !== "") {
						// response.data.billDeskReferenceNo = "SSM28752432148";
						// response.data.productCode = "BH";
						// response.data.quoteNo = "1301002010083401";
						// response.data.transactionAmt = "3867";
						// response.data.transactionDate = "30-04-2020 13:21:37";
						// response.data.pretCode = "0";
						if(response.data.pretCode == "0") { //Success of last transaction
							let polFlag = false;
							if(response.data.quoteNo != undefined)
								var valQP = response.data.quoteNo;
							else{
								polFlag = true;
								var valQP = response.data.policyNumber;
							}
							let dateTimeArr = response.data.transactionDate.split(' ');
							let dateArr = dateTimeArr[0].split("-");
							let newDate = `${dateArr[2]}-${dateArr[1]}-${dateArr[0]}T${dateTimeArr[1]}.000+05:30`;
							newDate = new Date(newDate);
							let transDate = $filter('date')(newDate, 'dd-MMM-yyyy HH:mm') + " Hrs";
							var msg =  `<p>${polFlag?'Policy No.': 'Quote No.'}: ${valQP} </p> \n
										<p>BillDesk Reference No.: ${response.data.billDeskReferenceNo} </p> \n
										<p>Date and Time of Transaction: ${transDate} </p> \n
										<p>Transaction Amount: ₹ ${response.data.transactionAmt} </p> \n
										<p>${polFlag?'':'Transaction was not successful, debited amount will be refunded in due course, please try again.'}</p>
										`;

										let buttonTxt = polFlag?'View Details': 'Close';
										let closeBtn = polFlag?'Close': '';
										
										CommonServices.messageModal('info', msg, false, closeBtn, buttonTxt,  function(){  
										}, function() {
											
											if(polFlag){

												$rootScope.isAutoManagePolicy = true;
												$scope.goToManagePolicies(valQP); 
											}else{

												$state.go("home");
											}

										} , 'Last BillDesk Transaction Details');

											
						}

						// else if(response.data.pretCode == "1"){ 	// Failure of last transaction 
						// 	CommonServices.messageModal('info', response.data.pretError, false, '', 'Close', function(){
						// 		}, function(){
						// 			$state.go("home");
						// 		}, 'Alert');
						// }
					}
				}
			);
		}
		$rootScope.onFirstLoggedIn = false;
	}

				/** CR_3773 End**/
}]);

//Product Menu CR655A Start
agentApp.controller('productMenuCntrl', ['$scope', 'CommonServices', 'RestServices','$state','$location','$rootScope', function($scope, CommonServices, RestServices, $state, $location,$rootScope) {
		
	$scope.continueProdMenu = function(){
		if($scope.productMenuForm.productRadio === "Yes"){
			$rootScope.prodDiscOpen = true;
			$rootScope.prodMenuOpen = false;
			if($rootScope.productName === "BH"){
			$rootScope.prodDiscMsg ="People with pre-existing illness / disease / disability and / or had met with an accident cannot take the policy online. They are requested to contact nearest New India office for taking the cover.";
			}
			if($rootScope.productName === "AK"){ //CR 0045
				$rootScope.prodDiscMsg ="People suffering/diagnosed/under any treatment for Hypertension / diabetes / critical illness / Adverse Medical History / chronic illness / recurring illness or above age of 50 years cannot take the policy online. They are requested to contact nearest New India office for taking the cover.";
			}
		}
		else{
			if($rootScope.productName === "BH"){
				$state.go('businessHolidays.travelDetails');
			}
			if($rootScope.productName === "AK"){ //CR 0045
				$state.go('detailedQuoteScreenAK');
		}
	}
	};
	/**CR43**/
	
}]);
agentApp.controller('productCntrl', ['$scope', 'CommonServices', 'RestServices','$state','$location','$rootScope','$timeout', function($scope, CommonServices, RestServices, $state, $location,$rootScope, $timeout) {	
	$scope.goBack = function(){
		if($rootScope.backFlag !== ""){
			history.go(-1);
		}
		else{
			if(CommonServices.editQuoteHistory === true){
				$state.go("managePolicies.managePolicies");
			}
			else{
				$state.go("buyNowSubLandingScreen");				
			}
			
		}
        	
    };
	/*Added for CR_NP_0744*/
		$rootScope.policyDetailsObj = {};
		/*CR_NP_0744 ends*/
	
	$rootScope.prodDiscShow = false;
	$scope.toUpToggle = false;
	 $scope.topUptoggleBtn = function(){
		$rootScope.prodDiscMsg = "";
		
		if($scope.toUpToggle === true){
			  $timeout(function() {
				$rootScope.prodDiscShow = true;
			 	if($rootScope.productName === "NP" || $rootScope.productName === "UK"){   //CR 0045
					$rootScope.prodDiscMsg="People suffering/diagnosed/under any treatment for Hypertension / diabetes / critical illness / Adverse Medical History / chronic illness / recurring illness or above age of 60 years cannot take the policy online. They are requested to contact nearest New India office for taking the cover.";
				}
				else if($rootScope.productName === "AK")
				$rootScope.prodDiscMsg="People suffering/diagnosed/under any treatment for Hypertension / diabetes / critical illness / Adverse Medical History / chronic illness / recurring illness or above age of 50 years cannot take the policy online. They are requested to contact nearest New India office for taking the cover.";
            }, 700);
          } else {
          $rootScope.prodDiscShow = false;
		}
		}
	
	
	$scope.detailedQuoteScreen = function(){
		if($rootScope.productName === "UK") {
			$state.go("premiumCalculatorUK");
		} 
		else if ($rootScope.productName === 'CJ') { //CR_3725
            $state.go("premiumCalculatorCJ");//CR_3725
        }
		else {
        $state.go("premiumCalculatorHealth");
		}        
    };
}]);	
agentApp.controller('prodDisMenuCntrl', ['$scope', 'CommonServices', 'RestServices','$state','$location','$rootScope', function($scope, CommonServices, RestServices, $state, $location,$rootScope) {
	
	$scope.discMenu = function(){
		if($rootScope.productName === "BH"){
			$rootScope.prodDiscOpen = false;
		}
		else{			
			$rootScope.prodDiscShow = false;
			if($rootScope.backFlag !== ""){
				history.go(-1);
			}
			else{
				if(CommonServices.editQuoteHistory === true){
					$state.go("managePolicies.managePolicies");
				}
				else{
					$state.go("buyNowSubLandingScreen");				
				}
				
			}		    
		}
	} 
	$scope.branchLocator = function(){
		$state.go("contactDetails.locator");
	}
	
}]);
//Product Menu CR655A End
//Pan Card Controller Start
agentApp.controller('panCardCntrl', ['$scope','RestServices','CommonServices','$state','$rootScope', function ($scope, RestServices,CommonServices,$state,$rootScope) {
	
	$scope.panMsg= CommonServices.getCommonData("setPanMsg");
	$scope.closePanModal = function(){
		$rootScope.panmodalOpen = false;
	}
	$scope.panCardData = CommonServices.getCommonData("panCardData");
	$scope.panCardNo ="";
	/**Update Pan Card Start CommonServices.getCommonData("partyCode")**/

	$scope.regexPanNo = regexPanNoGlobal;//3746
	$scope.isNIAPAN = false;//CR3746
	$scope.isPanDisabled = false;//CR3746

	//CR3746
	$scope.onPANNoChange = function () {
		if($scope.panCardNo != undefined){
			$scope.panCardNo = $scope.panCardNo.toUpperCase();
			$scope.isNIAPAN = isNIAPANNo($scope.panCardNo);
		}
		else
			$scope.isNIAPAN = false;
	};
	//CR3746

	$scope.updatePan = function() {
		
		var updatePanCardData = {
			"userProfile": {
			  "userId": CommonServices.getCommonData("userId")
			},
			"quote": {
			  "quoteNumber": $scope.panCardData.quoteNumber,
			  "policyHolderCode": $rootScope.productName === "UK"?CommonServices.policyDetailsObj.saveQuotePolicyHolderCode:$scope.panCardData.policyHolderCode,//CR_0044
			  "partyDetailsList": [
				{
				  "individualDetails": {
					"panNumber": $scope.panCardNo.toUpperCase()
				  }
				}
			  ]
			}
		};
			
		var updatePanCardResponse = RestServices.postService(RestServices.urlPathsNewPortal.updatePanCard,updatePanCardData); 

		updatePanCardResponse.then(
			function(response) { /* success */
				CommonServices.showLoading(false); 
				if(response.data === ""){
					CommonServices.showAlert("Could not connect to server. Please try again later.");
				} 
				else {
					
					if(response.data.errorCode !== undefined && response.data.errorCode !==""){
						CommonServices.showAlert(response.data.errorMessage);
					}
					else{
						if(response.data.userProfile.footer.errorCode === "0"){
							$rootScope.panCardNum = $scope.panCardNo.toUpperCase();
							CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
							$rootScope.panmodalOpen = false;							
							return true;
						} 
						else {
							CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
							return false;
						}
					}
					

				}
			},
			function(error) { /* failure */
				CommonServices.showLoading(false);
				restServices.handleWebServiceError(error);
			}
		);
		$rootScope.panmodalOpen = false;
	};
	
	/**Update Pan Card End**/
	
}]);

//Pan Card Controller End

/**Common message Modal Controller START**/
agentApp.controller('commonMessageModalController', ['$scope','$rootScope','$location', '$sce', function($scope,$rootScope,$location, $sce) {
      
	$rootScope.title = "Success";
	$rootScope.isSuccess = false;
	$rootScope.isError = false;
	$rootScope.isNoInfo = false;
	$rootScope.isModalClose = false;

	$scope.goToManagePolicies = function(collCode){	//For CR_3773
		$state.go("managePolicies.managePolicies");
		CommonServices.setCommonData("polNo", collCode);
	}

	$scope.trustHtmlTags = function(message){  //Ayush for 3773
		return $sce.trustAsHtml(message);
	}
  
	$rootScope.noButtonClick = function (noButtonAction) {
		//loadSpinner.hideLoading();
		$('.modal-backdrop').remove();
		$("#messageModal").modal('toggle');
		if (noButtonAction != undefined) noButtonAction();
	};

	$rootScope.yesButtonClick = function (yesButtonAction) {
		//loadSpinner.hideLoading();
		$('.modal-backdrop').remove();
		$("#messageModal").modal('toggle');
		yesButtonAction();
	};
  
}]);
/**Common message Modal Controller END**/

/**General Modal Controller START**/
agentApp.controller('generalModalController', ['$scope','$rootScope','$modalInstance','$location','modalData', 'CommonServices', 'RestServices',
	function($scope,$rootScope,$modalInstance,$location,modalData, CommonServices, RestServices) {
      
		$scope.modalObj = modalData;
		//$("#bodyContent").html(modalObj.html);
		
		$scope.ok = function() {
			$modalInstance.close('ok');
		};
		$scope.cancel = function() {
			$modalInstance.close('No');
		};

		$scope.noButtonClick = function () {
			// loadSpinner.hideLoading();
			// $('.modal-backdrop').remove();
			// $("#messageModal").modal('toggle');
			$modalInstance.close('No');
			$scope.modalObj.noButtonAction(false);
		};
		
		var son = CommonServices.counts;
		var daughter = CommonServices.countd;
		var count = CommonServices.noOfMembers;

		$scope.limit = 0;
		if ($scope.modalObj.page === 'TU_policyAutoPopulate') {
			$scope.limit = 6;
			// count = CommonServices.counts; 
		} 
		else if($scope.modalObj.page === 'PU_policyAutoPopulate') {
			$scope.limit = 2;
		}
		else if($scope.modalObj.page === 'RAK_policyAutoPopulate') {
			$scope.limit = 2;
		}
		$scope.flag = true;
		var relError = [];
		var errCount = {};//0;
		var errAray = [];
		$scope.errInTemplate = [];
		$scope.alertInTemplate = [];
		angular.forEach($scope.modalObj.dataSet, function (value, key) {
			errAray[key] = '';
			relError[key] = '';
		});
		$scope.chkAction = function (i, obj) {
			$scope.flag = true;
			// $scope.modalObj.modalError =false;
			if(obj.isSelected === undefined)
				obj.isSelected = false;
			$scope.modalObj.modalError = false;
			$scope.modalObj.modalErrorMsg = "";
			var occupationObj = isValidOccupation(obj);
			if (occupationObj.mnemonic !== undefined && occupationObj.mnemonic !== "") obj.occupation = occupationObj.mnemonic;

			if (obj.isSelected && (obj.relation.toLowerCase() === 'children'|| obj.relation.toLowerCase() === 'child' || obj.relation.toLowerCase() === 'daughter' || obj.relation.toLowerCase() === 'son') && (obj.sex === 'M' || obj.sex === 'F')) {
				count++;
				if(obj.sex === 'M')
					son++;
				else if(obj.sex === 'F')
					daughter++;
				if((son > $scope.limit || daughter > $scope.limit) && $scope.modalObj.page === 'RAK_policyAutoPopulate')  {
					// var msg = "Max two sons and two daughters can be added";
					// var msg = "For Raasta Apatti Kavach, maximum 2 sons and 2 daughters can be added.";
					var msg = "The maximum member limit for Raasta Apatti Kavach is 2 sons and 2 daughters. Please remove some of the members either from 'Previous policy search' or from 'Basic Premium details - current policy' and try again.";
					displayError(msg, i);
				}
				else if ((son+daughter) > $scope.limit && $scope.limit==2 && ($scope.modalObj.page !== 'RAK_policyAutoPopulate')) {		// for personal accident
					// var msg = "Max two child can be added. i.e. either 2 son or 2 daughter or 1 son and 1 daughter";
					// var msg = "For Personal Accident, maximum 2 children can be added."
					var msg = "The maximum member limit for Personal Accident is 2 children. Please remove some of the members either from 'Previous policy search' or from 'Basic Premium details - current policy' and try again.";
					displayError (msg, i);
				}
				else if (count > $scope.limit && $scope.limit==6) {		//for TopUp Mediclaim
					// var msg = "Max 6 members can be added";
					// var msg = "For New India Top Up Mediclaim, maximum 6 members can be added.";
					var msg = "The maximum member limit for New India Top Up Mediclaim is 6. Please remove some of the members either from 'Previous policy search' or from 'Basic Premium details - current policy' and try again.";
					displayError (msg, i);
				}
			} else if (!obj.isSelected && (obj.relation.toLowerCase() === 'children' || obj.relation.toLowerCase() === 'child' || obj.relation.toLowerCase() === 'daughter' || obj.relation.toLowerCase() === 'son') && (obj.sex === 'M' || obj.sex === 'F')) {
				count = (count > 0) ? count-1 : 0;
				if(obj.sex === 'M')
					son--;
				else if(obj.sex === 'F')
					daughter--;

				if(son <= $scope.limit && daughter <= $scope.limit && $scope.modalObj.page === 'RAK_policyAutoPopulate')  {
					var msg = "";
					populateError(msg, i);
				}
				else if((son > $scope.limit || daughter > $scope.limit) && $scope.modalObj.page === 'RAK_policyAutoPopulate')  {
					// var msg = "Max two sons and two daughters can be added";
					// var msg = "For Raasta Apatti Kavach, maximum 2 sons and 2 daughters can be added.";
					var msg = "The maximum member limit for Raasta Apatti Kavach is 2 sons and 2 daughters. Please remove some of the members either from 'Previous policy search' or from 'Basic Premium details - current policy' and try again.";
					displayError(msg, i);
				}
				else if ((son+daughter) > $scope.limit && $scope.limit==2 && ($scope.modalObj.page !== 'RAK_policyAutoPopulate')) { // for personal accident
					// var msg = "Max two child can be added. i.e. either 2 son or 2 daughter or 1 son and 1 daughter";
					// var msg = "For Personal Accident, maximum 2 children can be added.";
					var msg = "The maximum member limit for Personal Accident is 2 children. Please remove some of the members either from 'Previous policy search' or from 'Basic Premium details - current policy' and try again.";
					displayError (msg, i);
				}
				// else if(count <= $scope.limit){
				// 	populateError("", i);
				// } 
				
				else if (count > $scope.limit && $scope.limit==6) { 	// for TopUp Mediclaim
					// var msg = "Max six members can be added";
					// var msg = "For New India Top Up Mediclaim, maximum 6 members can be added.";
					var msg = "The maximum member limit for New India Top Up Mediclaim is 6. Please remove some of the members either from 'Previous policy search' or from 'Basic Premium details - current policy' and try again.";
					displayError (msg, i);
				}
			} else if (obj.isSelected && !isValidRelation(obj)) {
				var msg = '"' + obj.relation + '" cannot be added in this policy.';
				relError[i] = msg;
				// populateError (msg, i);
			}
			else if(obj.isSelected && obj.sex ==='T'){
				var msg = "Note: Since in previous health policy, gender of child is 'Third gender' therefore, you have to manually add child in the policy.";
				relError[i] = msg;
			}
			// else if (obj.isSelected && !isValidOccupation(obj)) {
			else if (obj.isSelected && obj.occupation !=="" && (occupationObj.mnemonic == "" || occupationObj.mnemonic == undefined)) {
				var msg = '"' + obj.occupation + '" cannot be added in this policy.';
				populateError (msg, i);

			} 
			
			else {
				if (!obj.isSelected && (obj.relation.toLowerCase() === 'children' || obj.relation.toLowerCase() === 'child' || obj.relation.toLowerCase() === 'daughter' || obj.relation.toLowerCase() === 'son') && (obj.sex === 'M' || obj.sex === 'F')) {
					count = (count > 0) ? count-1 : 0;
					if(obj.sex === 'M')
						son--;
					else if(obj.sex === 'F')
						daughter--;


					if(son <= $scope.limit && daughter <= $scope.limit && $scope.modalObj.page === 'RAK_policyAutoPopulate')  {
						var msg = "";
						populateError(msg, i);
					}
					else if ((son+daughter) > $scope.limit && $scope.limit==2 && ($scope.modalObj.page !== 'RAK_policyAutoPopulate')) { // for personal accident
						// var msg = "Max two child can be added. i.e. either 2 son or 2 daughter or 1 son and 1 daughter";
						// var msg = "For Personal Accident, maximum 2 children can be added."
						var msg = "The maximum member limit for Personal Accident is 2 children. Please remove some of the members either from 'Previous policy search' or from 'Basic Premium details - current policy' and try again.";
						displayError (msg, i);
					}
					else if(count <= $scope.limit){
						displayError(undefined, i);
					} 

					else if ((son+daughter) > $scope.limit) {
						// var msg = "Max two child can be added. i.e. either 2 son or 2 daughter or 1 son and 1 daughter";
						// var msg = "For Personal Accident, maximum 2 children can be added."
						var msg = "The maximum member limit for Personal Accident is 2 children. Please remove some of the members either from 'Previous policy search' or from 'Basic Premium details - current policy' and try again.";
						displayError (msg, i);
					}
					else if (count > $scope.limit) {
						// var msg = "Max six members can be added";
						// var msg = "For New India Top Up Mediclaim, maximum 6 members can be added.";
						var msg = "The maximum member limit for New India Top Up Mediclaim is 6. Please remove some of the members either from 'Previous policy search' or from 'Basic Premium details - current policy' and try again.";
						displayError (msg, i);
					}
				}
				errAray[i] = "";
				relError[i] = "";
			}
			if(!obj.isSelected){
				errAray[i] = "";
				relError[i] = "";
			}
			checkErrArray();
			if((son+daughter) > 2 && $scope.modalObj.page === 'PU_policyAutoPopulate'){
				// var msg = "Max two child can be added. i.e. either 2 son or 2 daughter or 1 son and 1 daughter";
				// var msg = "For Personal Accident, maximum 2 children can be added."
				var msg = "The maximum member limit for Personal Accident is 2 children. Please remove some of the members either from 'Previous policy search' or from 'Basic Premium details - current policy' and try again.";
				displayError (msg, i);
			}
			if((son > 2 || daughter > 2) && $scope.modalObj.page === 'RAK_policyAutoPopulate'){
				// var msg = "Max two sons and two daughters can be added";
				// var msg = "For Raasta Apatti Kavach, maximum 2 sons and 2 daughters can be added.";
				var msg = "The maximum member limit for Raasta Apatti Kavach is 2 sons and 2 daughters. Please remove some of the members either from 'Previous policy search' or from 'Basic Premium details - current policy' and try again.";
				displayError(msg, i);
			}
			if (($scope.modalObj.page === 'PU_policyAutoPopulate' || $scope.modalObj.page === 'TU_policyAutoPopulate' || $scope.modalObj.page === 'RAK_policyAutoPopulate')) {
				var c = 0;
				angular.forEach($scope.modalObj.dataSet, function (value, key) {
					if (value.isSelected){
							$scope.flag = false;
						//do not add if proposer is there
							if((value.relation.toLowerCase()==="self" || value.relation.toLowerCase()==="proposer") && !$scope.modalObj.proposer)
								c++;
							else if(value.relation.toLowerCase()==="spouse" && !$scope.modalObj.spouse){
								c++;
							}
						}
				});
				if((c+count) > 4 && $scope.modalObj.page === 'PU_policyAutoPopulate'){
					// var msg = "Max two child can be added. i.e. either 2 son or 2 daughter or 1 son and 1 daughter";
					// var msg = "For Personal Accident, maximum 4 members can be added.";
					var msg = "The maximum member limit for Personal Accident is 4. Please remove some of the members either from 'Previous policy search' or from 'Basic Premium details - current policy' and try again.";
					displayError (msg, i);
				}
				else if ((c+count) > 6 &&  $scope.modalObj.page === 'TU_policyAutoPopulate') {
					// var msg = "For New India Top Up Mediclaim, maximum 6 members can be added.";
					var msg = "The maximum member limit for New India Top Up Mediclaim is 6. Please remove some of the members either from 'Previous policy search' or from 'Basic Premium details - current policy' and try again.";
					displayError (msg, i);
				}
				else if((c+son+daughter) > 6 &&  $scope.modalObj.page === 'RAK_policyAutoPopulate'){
					// var msg = "For Raasta Apatti Kavach, maximum 6 members can be added."
					var msg = "The maximum member limit for Raasta Apatti Kavach is 6. Please remove some of the members either from 'Previous policy search' or from 'Basic Premium details - current policy' and try again.";
					displayError (msg, i);
				}
			}

			$scope.errInTemplate = relError.filter( item => !!item);
			$scope.alertInTemplate = errAray.filter( item => !!item);

		}
		function checkErrArray () {
			$scope.eCount = 0;
			var index;
			angular.forEach(errAray, function (value, key) {
				if (errAray[key] != '' && errAray[key] != undefined) {
					$scope.eCount++;
					index = key;
				}
				if(relError[key] !== '' && errAray[key]!=undefined)
					$scope.modalObj.modalError = true;
			});
			return; //{'eCount': $scope.eCount, 'key': index};
		}
		function displayError(msg){
			if(msg != undefined && msg != ""){
				$scope.modalObj.modalError = true;
				$scope.modalObj.modalErrorMsg = msg;
			}
			else 
				$scope.modalObj.modalError = false;
		}
		function populateError (msg, i) {
			if(msg != undefined && msg != "")
				//$scope.modalObj.modalError = true;
			//else 
				//$scope.modalObj.modalError = false;
			//$scope.modalObj.modalErrorMsg = msg;
			errAray[i] = msg;
		}

		function isValidOccupation (o) {
			if (o.occupation == 'Any Other' || o.occupation == 'AO' || o.occupation == 'OTHERS') {
				return true;
			}
			else if ($scope.modalObj.page === 'PU_policyAutoPopulate' || $scope.modalObj.page === 'TU_policyAutoPopulate' || $scope.modalObj.page === 'RAK_policyAutoPopulate') {
				// var occupationObj = getSelectedOccupationObj(o.occupation);
				var occupationObj = RestServices.getOccupationList(o.occupation.toUpperCase(), $scope.modalObj.page);
				return occupationObj;
				// return (occupationObj.mnemonic !== "");
			}
			return false;
		}
		function isValidRelation (o) {
			return ($scope.modalObj.page === 'PU_policyAutoPopulate' || $scope.modalObj.page === 'TU_policyAutoPopulate' || $scope.modalObj.page === 'RAK_policyAutoPopulate') && (o.relation.toLowerCase() == 'children' || o.relation.toLowerCase() == 'spouse' || o.relation.toLowerCase() == 'self' || o.relation.toLowerCase() == 'proposer');
		}
		function getSelectedOccupationObj (o) {
			var obj = {
				codeId: "",
				codeValue: "",
				description: "",
				domainId: '',
				lngCode: "",
				mnemonic: "",
				sortOrder: null
			};
			var data = CommonServices.getCommonData("OCCUPATION");
			if ($scope.modalObj.page === 'TU_policyAutoPopulate') data = RestServices.getOccupationList(o.occupation, $scope.modalObj.page);
			angular.forEach(data, function (value, key) {
				if (value.mnemonic.toLowerCase() === o.toLowerCase()) {
					obj = value;
					return;
				}
			});
			return obj;
		}

		$scope.noButtonClick = function () {
			$modalInstance.close('No');
			$scope.modalObj.noButtonAction(false);
		};
		$scope.yesButtonClick = function () {
			$modalInstance.close('ok');
			$scope.modalObj.yesButtonAction(true);
		};
}]);
/**General Modal Controller END**/

//Directives Start

agentApp.directive('numberOnly', function() {
	return{
		require:'ngModel',
		link: function(scope, element,attrs, model){
			element.on("focus", function(event){
				if(event.currentTarget.type !== "number")
					event.currentTarget.type = "number";
			});
			element.on("keypress keydown keyup", function(event) {
                if(event.currentTarget.type !== "number") {
                    event.currentTarget.type = "number";
                }
				var keyCode = event.which || event.keyCode;
				var val = event.currentTarget.value;
				var regex = new RegExp(/[^0-9]/g);

				if (keyCode !== 46 && keyCode > 31 && (keyCode < 48 || keyCode > 57) && (val.split('.').length === 1)){
					val = val.toString().replace(regex,"");
					val = val.slice(0,Number(attrs.numberOnly));
					model.$setViewValue(val);
					model.$render();
					event.preventDefault();
				} else if(keyCode !== 46 && keyCode > 31 && (Number(attrs.numberOnly) < (event.currentTarget.value.length+1))){
					val = val.toString().replace(regex,"");
					val = val.slice(0,Number(attrs.numberOnly));
					model.$setViewValue(val);
					model.$render();
					event.preventDefault();
				}

			});
			
			element.bind('paste keydown', function(event) {

				setTimeout(function() {
					var val = element.val();
					var regex = new RegExp(/[^0-9]/g);
					val = val.toString().replace(regex,"");
					val = val.slice(0,Number(attrs.numberOnly));
					model.$setViewValue(val);
					model.$render();
					scope.$apply();
				}, 5);

			});
			
            model.$parsers.push(function(val){
                if(!val){
                return;}
                var regex = new RegExp(/[^0-9]/g);
                var replaced = val.toString().replace(regex,"");
                if(replaced !== val){
                    model.$setViewValue(replaced);
                    model.$render();
                }
                return replaced;
            });
		}
	};
});

agentApp.directive('defaultNumberOnly', function() {
	return{
		require:'ngModel',
		link: function(scope, element,attrs, model){
			
			element.on("keypress keydown keyup", function(event) {
                
				var keyCode = event.which || event.keyCode;
				var val = event.currentTarget.value;
				var regex = new RegExp(/[^0-9]/g);

				if (keyCode !== 46 && keyCode > 31 && (keyCode < 48 || keyCode > 57) && (val.split('.').length === 1)){
					val = val.toString().replace(regex,"");
					val = val.slice(0,Number(attrs.defaultNumberOnly));
					model.$setViewValue(val);
					model.$render();
					event.preventDefault();
				} else if(keyCode !== 46 && keyCode > 31 && (Number(attrs.defaultNumberOnly) < (event.currentTarget.value.length+1))){
					val = val.toString().replace(regex,"");
					val = val.slice(0,Number(attrs.defaultNumberOnly));
					model.$setViewValue(val);
					model.$render();
					event.preventDefault();
				}

			});
			
			element.bind('paste keydown', function(event) {

				setTimeout(function() {
					var val = element.val();
					var regex = new RegExp(/[^0-9]/g);
					val = val.toString().replace(regex,"");
					val = val.slice(0,Number(attrs.defaultNumberOnly));
					model.$setViewValue(val);
					model.$render();
					scope.$apply();
				}, 5);

			});
			
            model.$parsers.push(function(val){
                if(!val){
                return;}
                var regex = new RegExp(/[^0-9]/g);
                var replaced = val.toString().replace(regex,"");
                if(replaced !== val){
                    model.$setViewValue(replaced);
                    model.$render();
                }
                return replaced;
            });
		}
	};
});


agentApp.directive('textOnly', function() {
	return{
		require:'ngModel',
		link: function(scope, element,attrs, model) {
			element.on("keyup", function(event) {

				var keyCode = event.which || event.keyCode;
				var val = event.currentTarget.value;
				if(keyCode !== 46 && keyCode > 31 && (Number(attrs.textOnly) < (event.currentTarget.value.length+1))){
					var regex = new RegExp(/[^a-zA-Z]/g);
					val = val.toString().replace(regex,"");
					val = val.slice(0,Number(attrs.textOnly));
					model.$setViewValue(val);
                    model.$render();
					event.preventDefault();
				}

			});
			
			element.bind('paste keydown', function(event) {

				setTimeout(function() {
					val = element.val();
					var regex = new RegExp(/[^a-zA-Z]/g);
					val = val.toString().replace(regex,"");
					val = val.slice(0,Number(attrs.textOnly));
					model.$setViewValue(val);
					model.$render();
					scope.$apply();
				}, 5);

			});
			
			model.$parsers.push(function(val){
					if(!val){
					return;}
					var regex = new RegExp(/[^a-zA-Z]/g);
					var replaced = val.toString().replace(regex,"");
					if(replaced !== val){
						model.$setViewValue(replaced);
						model.$render();
					}
					return replaced;				
			});
		}
	};
});

agentApp.directive('textOnlyBankBranch', function() {
                   return{
                   require:'ngModel',
                   link: function(scope, element,attrs, model) {
                   element.on("keyup", function(event) {
                              
                              var keyCode = event.which || event.keyCode;
                              var val = event.currentTarget.value;
                              if(keyCode !== 46 && keyCode > 31 && (Number(attrs.textOnly) < (event.currentTarget.value.length+1))){
                              //var regex = new RegExp(/[^a-zA-Z]/g);
                               var regex = new RegExp(/^[a-zA-Z ]*$/);
                              val = val.toString().replace(regex,"");
                              val = val.slice(0,Number(attrs.textOnly));
                              model.$setViewValue(val);
                              model.$render();
                              event.preventDefault();
                              }
                              
                              });
                   
                   element.bind('paste keydown', function(event) {
                                
                                setTimeout(function() {
                                           val = element.val();
                                           //var regex = new RegExp(/[^a-zA-Z]/g);
                                           var regex = new RegExp(/^[a-zA-Z ]*$/);
                                           val = val.toString().replace(regex,"");
                                           val = val.slice(0,Number(attrs.textOnly));
                                           model.$setViewValue(val);
                                           model.$render();
                                           scope.$apply();
                                           }, 5);
                                
                                });
                   
                   model.$parsers.push(function(val){
                                       if(!val){
                                       return;}
                                      // var regex = new RegExp(/[^a-zA-Z]/g);
                                       var regex = new RegExp(/^[a-zA-Z ]*$/);
                                       var replaced = val.toString().replace(regex,"");
                                       if(replaced !== val){
                                       model.$setViewValue(replaced);
                                       model.$render();
                                       }
                                       return replaced;				
                                       });
                   }
                   };
});

agentApp.directive('validDecimalNumber', function() {
      return {
        require: '?ngModel',
        link: function(scope, element, attrs, model) {
          if(!model) {
            return; 
          }

          model.$parsers.push(function(val) {
			
            if (angular.isUndefined(val) || val === null) {
                val = '';
            }
            // it accepts only number and dot
            var clean = val.toString().replace(/[^-0-9\.]/g, '');
            var negativeCheck = clean.split('-');
			var decimalCheck = clean.split('.');
            if(!angular.isUndefined(negativeCheck[1])) {
                negativeCheck[1] = negativeCheck[1].slice(0, negativeCheck[1].length);
                clean =negativeCheck[0] + '-' + negativeCheck[1];
                if(negativeCheck[0].length > 0) {
                	clean =negativeCheck[0];
                }
            }
              
            if(!angular.isUndefined(decimalCheck[1])) {
                decimalCheck[1] = decimalCheck[1].slice(0,2);
                clean =decimalCheck[0] + '.' + decimalCheck[1];
            }

            if (val !== clean) {
              model.$setViewValue(clean);
              model.$render();
            }
            return clean;
          });

          element.on('keypress', function(event) {
            if(event.keyCode == 32) {
              event.preventDefault();
            }
          });
        }
      };
});
	
agentApp.directive('handleSubmit', function () {
    return function (scope, element, attr) {
        var textFieldInput = element.find('input[type=text]');
        var textFieldPassword = element.find('input[type=password]');
        var textFieldNumber = element.find('input[type=number]');
        $(element).submit(function() {
            textFieldInput.blur();
            textFieldPassword.blur();
            textFieldNumber.blur();
        });
    };
});

agentApp.directive('touchField', [function() {
    return function(scope, element, attr) {

        element.on('touchstart', function(event) {
            scope.$apply(function() {

                element[0].focus();
            });
        });
    };
}]);

agentApp.directive('noSpecialChar', function() {
    return {
      require: 'ngModel',
      link: function(scope, element, attrs, modelCtrl) {
        modelCtrl.$parsers.push(function(inputValue) {
          if (inputValue == null){
            return '';
          }
          var cleanInputValue = inputValue.toString().replace(/[^a-zA-Z0-9]/gi, '');
          if (cleanInputValue !== inputValue) {
            modelCtrl.$setViewValue(cleanInputValue);
            modelCtrl.$render();
          }
          return cleanInputValue;
        });
      }
    };
});

agentApp.directive('myMaxlength', function() {
  return {
    require: 'ngModel',
    link: function (scope, element, attrs, ngModelCtrl) {
      var maxlength = Number(attrs.myMaxlength);
      function fromUser(text) {
          if (text.length > maxlength) {
            var transformedInput = text.substring(0, maxlength);
            ngModelCtrl.$setViewValue(transformedInput);
            ngModelCtrl.$render();
            return transformedInput;
          } 
          return text;
      }
      ngModelCtrl.$parsers.push(fromUser);
    }
  }; 
});

agentApp.directive('hideon', function() {
    return function(scope, element, attrs) {
		
        scope.$watch(attrs.hideon, function(value) {
			var regx = /^[a-zA-Z0-9]*$/;
			if(regx.test(value) === false || value.length < 5) {
				element.show();
			} else {
				element.hide();
			}
        }, true);
    };
	
	
});

agentApp.directive('hideonrcbook', function() {
    return function(scope, element, attrs) {
		  
        scope.$watch(attrs.hideonrcbook, function(value) {
			var regx = /^[a-zA-Z0-9]*$/;
			if(regx.test(value) === false || value === undefined) {
				element.show();
			} else {
				element.hide();
			}
        }, true);
    };
});

agentApp.factory('liveChat',function(){
	return function() {
		var pswo =
			'menubar=0,location=0,scrollbars=auto,'+
				'resizable=1,status=0,width=400,height=540';
		var pswn = 'pscw_' + psSDrLn();
		var url = 'http://messenger.providesupport.com/messenger/'+
				'16dgmm17e2o580iku70zkmckm0.html?ps_l='
			+ escape(document.location) + '';
		this.onClick = function(){
			window.open(url, pswn, pswo);
		};
	};
	function psSDrLn() {
		return new Date().getTime();
	}
});

agentApp.directive("fileread", ['CommonServices', '$parse', function (CommonServices, $parse) {
	return {
		scope: {
			fileread: "="
		},
		link: function (scope, element, attrs) {
			var model = $parse(attrs.fileread),
				modelSetter = model.assign;
			$('#' + element[0].parentElement.id).hide();
			element.bind("change", function (changeEvent) {
				var reader = new FileReader();
				reader.onload = function (loadEvent) {
					scope.$apply(function () {
						scope.fileread = loadEvent.target.result;
						//var fileURISize = sizeof(scope.fileread)/(1024*2.67);
						if (element[0].files[0].size < 512000) {
							CommonServices.uploadUKFiles[parseInt(scope.$parent.artID)].documentName = element[0].files[0].name;
							CommonServices.uploadUKFiles[parseInt(scope.$parent.artID)].docByteString = scope.fileread.split(',')[1];
							modelSetter(scope, element[0].files[0]);
							if (scope.$parent.insuredMembers[parseInt(scope.$parent.artID)]) {
								scope.$parent.insuredMembers[parseInt(scope.$parent.artID)].selectedDocName = element[0].files[0].name;
							} else {
								scope.$parent.healthCareObj.selectedDocName = element[0].files[0].name;
							}
							scope.$parent.hideModal();
							if(element[0].parentElement) $('#' + element[0].parentElement.id).hide(); // Hide the model "upload-options"	
							if(element[0].parentElement.parentElement.nextElementSibling) $('#' + element[0].parentElement.parentElement.nextElementSibling.id).hide(); // Hide the overlay							
							changeEvent.target.value = null; // Same file cannot be selected fix
						} else {
							CommonServices.showAlert("Image size should be 500KB");
							$('#upload-options').hide(); // Hide the model "upload-options"	
							$('#showOverlay').hide(); // Hide the overlay
							changeEvent.target.value = null; // Same file cannot be selected fix
						}
					});
				}
				if (changeEvent.target.files.length !== 0) {
					reader.readAsDataURL(changeEvent.target.files[0]);
				}
			});
		}
	}
}]);


agentApp.directive('floatingLabel', function () {
	return {
		require: 'ngModel',
		link: function (scope, element, attrs, model) {
			element.on('focus', function () {
				element.parent().addClass('focused');
			});
			element.on('paste keydown blur change bind', function () {

				setTimeout(function () {

					if (element.val().length === 0) {
						element.parent().removeClass('focused');
					}
					else {
						element.parent().addClass('focused');
					}
				}, 0);

			});

		}

	};

});


agentApp.directive('commonMessageModalDirective', function () {
	return {
		restrict: 'EA',
		controller: 'commonMessageModalController',
		templateUrl: 'partials/general/commonMessageModal.html'
	};
});
