agentApp.controller('clientsController', ['$scope','RestServices','CommonServices', function ($scope, RestServices,CommonServices) {
			
			$scope.bodyHeight = window.innerHeight+'px';

}]);

agentApp.controller('myClientsController', ['$scope','RestServices','CommonServices','$state', function ($scope, RestServices,CommonServices,$state) {
			
		$scope.home = function() {
			$state.go("home");
		};	
		
		$scope.addClient = function(){
			$state.go("clients.addClient");
		}
		
		var oldInputMaxLen = 0;
		$scope.validateTextInput = function (model, maxLen) {
			if (model != undefined && model != '') {
				var len = model.length;
				if (len > maxLen) {
					$scope.myClientObj.searchText = oldInputMaxLen;
				} else {
					oldInputMaxLen = model;
				}
			}
		}
		//Creating object for manage policy
		$scope.myClientObj = {
			searchTypeVal: [{
				id:"clientID",
				name: "Client ID"
			},
			{
				id:"phone",
				name: "Mobile Number"
			},
			{
				id:"firstName",
				name: "First Name"
			},
			{
				id:"LastName",
				name: "Last Name"
			},
			{
				id:"emailID",
				name: "Email ID"
			}],
			clientSearch: function(form){
				
				if(this.prospectType === undefined || this.prospectType === ""){
					CommonServices.showAlert("Please select Prospect Type");
					return;
				}
				if(!form.$valid) {
					return;
				}
				
				//On Search of CLient
				var clientData = {
					  "clientUpsertASBOList": [
						{
						  "mobileNumber": this.searchType === 'phone' ? this.searchText : "",
						  "emailId": this.searchType === 'emailID' ? this.searchText : "",
						  "firstName": this.searchType === 'firstName' ? this.searchText : "",
						  "lastName": this.searchType === 'LastName' ? this.searchText : "",
						  "title": "",
						  "status": "",
						  "clientID":this.searchType === 'clientID' ? this.searchText : "",
						  "prospectPositions": [
							{
							  "userID": CommonServices.getCommonData("userId"),//"AG_ASHIS53",
							  "isPrimaryMVG": ""
							}
						  ],
						  "oppotunities": [
							{
							  "expectedPremium": "",
							  "productName": "",
							  "status":""
							}
						  ]
						}
					  ],
					  "prospectType": this.prospectType.toUpperCase()
					};
				
				//Service call on submit of manage policy
				var clientResponse = RestServices.postService(RestServices.urlPathsNewPortal.clientList, clientData);
				clientResponse.then(
					function(response) { // success	
			
						//CommonServices.showAlert(response.data.userProfile.footer.status);
						CommonServices.showLoading(false);	
						if(response.data.errorCode === "0"){
						    
							$scope.clientDetails = response.data.clientUpsertASBOList;
							CommonServices.setCommonData("prospectType",response.data.prospectType);
                          
						}
						else{
                            CommonServices.showAlert(response.data.erroMessage);
						}
							
					},
					function(error) { // failure
						CommonServices.showLoading(false);
						RestServices.handleWebServiceError(error);
				});		
				
			},
			clientDetailsClick: function(data){
				
				CommonServices.setCommonData("clientDetails",data);
				$state.go("clients.viewClients");
			},
			prospectRadio: function(radioVal){
				
				if(radioVal === "CORPORATE"){
					$scope.myClientObj.searchTypeVal =[{
							id:"clientID",
							name: "Client ID"
						},
						{
							id:"firstName",
							name: "First Name"
						}]
				}
				if(radioVal === "INDIVIDUAL"){
					$scope.myClientObj.searchTypeVal =[{
							id:"clientID",
							name: "Client ID"
						},
						{
							id:"phone",
							name: "Mobile Number"
						},
						{
							id:"firstName",
							name: "First Name"
						},
						{
							id:"LastName",
							name: "Last Name"
						},
						{
							id:"emailID",
							name: "Email ID"
						}]
				}
			}
		}
		
		$scope.myClientObj.searchType = $scope.myClientObj.searchTypeVal[0].id;		

}]);

agentApp.controller('viewClientsController', ['$scope','RestServices','CommonServices','$state', function ($scope, RestServices,CommonServices,$state) {
		
	$scope.clientObj = {
		productTypeVal:[{id:"Private Car",name:"Private Car"},
		{id:"Two Wheeler",name:"Two Wheeler"},
		{id:"Commercial Vehicle",name:"Commercial Vehicle"},
		{id:"Personal Accident",name:"Personal Accident"},
		{id:"Personal Accident (Death & PTD)",name:"Personal Accident (Death & PTD)"},
		{id:"Standard Fire and Special Perils",name:"Standard Fire and Special Perils"},
		{id:"Specific Voyage",name:"Specific Voyage"},
		{id:"New India Floater Mediclaim",name:"New India Floater Mediclaim"},
		{id:"Asha Kiran",name:"Asha Kiran"},
		{id:"Universal Health Insurance",name:"Universal Health Insurance"},
		{id:"New India Top Up Mediclaim",name:"New India Top Up Mediclaim"},
		{id:"New India Griha Suvidha Policy",name:"New India Griha Suvidha Policy"},
		{id:"House Holder",name:"House Holder"},
		{id:"Pravasi Bhartiya Bima Yojana",name:"Pravasi Bhartiya Bima Yojana"},
		{id:"Eproduct for Laghu Bima Health",name:"Eproduct for Laghu Bima Health"},
		{id:"Eproduct for Laghu Bima Cattle",name:"Eproduct for Laghu Bima Cattle"},
		{id:"Janata Personal Accident",name:"Janata Personal Accident"},
		{id:"Cattle Insurance",name:"Cattle Insurance"},
		{id:"New Family Floater 2012",name:"New Family Floater 2012"},
		{id:"New MediClaim 2012",name:"New MediClaim 2012"},
		{id:"Office Protection",name:"Office Protection"},
		{id:"Shop Keeper",name:"Shop Keeper"},
		{id:"Overseas Mediclaim (Bus & Hol)",name:"Overseas Mediclaim (Bus & Hol)"},
		{id:"Overseas Mediclaim (ES)",name:"Overseas Mediclaim (ES)"},
		{id:"Eproduct for Laghu Bima Hut",name:"Eproduct for Laghu Bima Hut"},
		{id:"Eproduct for Laghu Bima Personal Accident",name:"Eproduct for Laghu Bima Personal Accident"}],
		editClient: false,
		clientSearchDetail: "",
		edit: function(){
			$scope.clientObj.editClient = true;
		},
		ProductNameData:{
			oppotunities:""
		},
		updateClient: function(){
			
			for(i= 0; i < $scope.clientObj.ProductNameData.oppotunities.length ;i++){
				$scope.clientObj.ProductNameData.oppotunities[i]["expectedPremium"] = this.expectedPremium;
				this.ProductNameData.oppotunities[i]["status"] = "Active";
				delete this.ProductNameData.oppotunities[i].$$hashKey;
			}
			
			var updateClientData="";
			if($scope.clientObj.prospectType === "INDIVIDUAL"){
				updateClientData= {
				  "clientUpsertASBOList": [
					{
					  "mobileNumber": this.clientSearchDetail.mobileNumber,
					  "emailId": this.clientSearchDetail.emailId,
					  "firstName": this.clientSearchDetail.firstName,
					  "lastName": this.clientSearchDetail.lastName,
					  "title": this.productTitle,
					  "status": "Prospect",
					  "prospectPositions": [
						{
						  "userID": CommonServices.getCommonData("userId"),
						  "isPrimaryMVG": "Y"
						}
					  ],
					  "oppotunities": this.ProductNameData.oppotunities
					}
				  ],
				  "prospectType": $scope.clientObj.prospectType
				};
			}
			if($scope.clientObj.prospectType === "CORPORATE"){
				this.productTitle ="";
				this.mobileNumber="";
				updateClientData= {
				  "clientUpsertASBOList": 
				  [
					{
					  "mobileNumber": this.clientSearchDetail.mobileNumber,
					  "firstName": this.clientSearchDetail.firstName,
					  "title": this.productTitle,
					  "status": "Prospect",
					  "prospectPositions": [
						{
						  "userID": CommonServices.getCommonData("userId"),
						  "isPrimaryMVG": "Y"
						}
					  ],
					  "oppotunities": this.ProductNameData.oppotunities
					}
				  ],
				  "prospectType": $scope.clientObj.prospectType
				};
			}
			
			var updateClientResponse = RestServices.postService(RestServices.urlPathsNewPortal.updateInsertClient, updateClientData);
			updateClientResponse.then(
				function(response) { // success	
 
					CommonServices.showLoading(false);	
					if(response.data.errorCode === "0"){
						CommonServices.showAlert("Details has been successfully submitted");
					}
					else if(response.data.errorCode === "1"){
						CommonServices.showAlert(response.data.erroMessage);
					}
					else{
						CommonServices.showAlert(response.data.errorMessage);
					}
				
						
				},
				function(error) { // failure
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
			});
		},
		titleVal:[{
			id:"Mr.",
			name:"Mr."
		},
		{
			id:"Mrs.",
			name:"Mrs."
		},
		{
			id:"Dr.",
			name:"Dr."
		},
		{
			id:"Ms.",
			name:"Ms."
		},
		{
			id:"Proff.",
			name:"Proff."
		},
		{
			id:"Sh.",
			name:"Sh."
		},
		{
			id:"Sha.",
			name:"Sha."
		}],
		cancelClient: function(){
		   $scope.clientObj.editClient = false
		}
	}
	
	var details = CommonServices.getCommonData("clientDetails")
	$scope.clientObj.clientSearchDetail = details;
	$scope.clientObj.prospectType = CommonServices.getCommonData("prospectType");
	
	if($scope.clientObj.clientSearchDetail.oppotunities !== undefined && $scope.clientObj.clientSearchDetail.oppotunities !== ""){
	    if($scope.clientObj.clientSearchDetail.oppotunities[0].expectedPremium !== undefined && $scope.clientObj.clientSearchDetail.oppotunities[0].expectedPremium !== ""){
	        $scope.clientObj.expectedPremium = $scope.clientObj.clientSearchDetail.oppotunities[0].expectedPremium;
	    }
		
		if($scope.clientObj.clientSearchDetail.oppotunities.length > 0){
			$scope.clientObj.ProductNameData.oppotunities = $scope.clientObj.clientSearchDetail.oppotunities;
           /* for(var i; i< $scope.clientObj.clientSearchDetail.oppotunities; i++){
                if($scope.clientObj.productTypeVal[i] === $scope.clientObj.clientSearchDetail.oppotunities[i]){
                                              $scope.data.productName[i] = $scope.clientObj.clientSearchDetail.oppotunities[i];
                }
                   
            }*/
            
		}
	}

	$scope.home = function(){
		
		if($scope.clientObj.editClient === false){
			$state.go("clients.myClients");
		}
		else{
			$scope.clientObj.editClient = false
		}
		
	}
	
	
}]);

agentApp.controller('addClientController', ['$scope','RestServices','CommonServices','$state', function ($scope, RestServices,CommonServices,$state) {
	
	$scope.home = function(){
		$state.go("clients.myClients");
	}

	$scope.counter=1;
	
	$scope.addClientObj ={
		productTypeVal:[{id:"Private Car",name:"Private Car"},
		{id:"Two Wheeler",name:"Two Wheeler"},
		{id:"Commercial Vehicle",name:"Commercial Vehicle"},
		{id:"Personal Accident",name:"Personal Accident"},
		{id:"Personal Accident (Death & PTD)",name:"Personal Accident (Death & PTD)"},
		{id:"Standard Fire and Special Perils",name:"Standard Fire and Special Perils"},
		{id:"Specific Voyage",name:"Specific Voyage"},
		{id:"New India Floater Mediclaim",name:"New India Floater Mediclaim"},
		{id:"Asha Kiran",name:"Asha Kiran"},
		{id:"Universal Health Insurance",name:"Universal Health Insurance"},
		{id:"New India Top Up Mediclaim",name:"New India Top Up Mediclaim"},
		{id:"New India Griha Suvidha Policy",name:"New India Griha Suvidha Policy"},
		{id:"House Holder",name:"House Holder"},
		{id:"Pravasi Bhartiya Bima Yojana",name:"Pravasi Bhartiya Bima Yojana"},
		{id:"Eproduct for Laghu Bima Health",name:"Eproduct for Laghu Bima Health"},
		{id:"Eproduct for Laghu Bima Cattle",name:"Eproduct for Laghu Bima Cattle"},
		{id:"Janata Personal Accident",name:"Janata Personal Accident"},
		{id:"Cattle Insurance",name:"Cattle Insurance"},
		{id:"New Family Floater 2012",name:"New Family Floater 2012"},
		{id:"New MediClaim 2012",name:"New MediClaim 2012"},
		{id:"Office Protection",name:"Office Protection"},
		{id:"Shop Keeper",name:"Shop Keeper"},
		{id:"Overseas Mediclaim (Bus & Hol)",name:"Overseas Mediclaim (Bus & Hol)"},
		{id:"Overseas Mediclaim (ES)",name:"Overseas Mediclaim (ES)"},
		{id:"Eproduct for Laghu Bima Hut",name:"Eproduct for Laghu Bima Hut"},
		{id:"Eproduct for Laghu Bima Personal Accident",name:"Eproduct for Laghu Bima Personal Accident"}],
		prospect:[{
			id:"INDIVIDUAL",
			name:"Individual"
		},
		{
			id:"CORPORATE",
			name:"Organisation"
		}],
		corporatePartyField: false,
		titleVal:[{
			id:"Mr.",
			name:"Mr."
		},
		{
			id:"Mrs.",
			name:"Mrs."
		},
		{
			id:"Dr.",
			name:"Dr."
		},
		{
			id:"Ms.",
			name:"Ms."
		},
		{
			id:"Proff.",
			name:"Proff."
		},
		{
			id:"Sh.",
			name:"Sh."
		},
		{
			id:"Sha.",
			name:"Sha."
		}],
		ProductNameData:{
			oppotunities:[{
			    opportunityID:$scope.counter,
				productName: ""
			}]
		},
		addProductName: function(){
            $scope.counter++;
			this.ProductNameData.oppotunities.unshift({
			            opportunityID:$scope.counter,
						productName:''
					});
		},
		deleteProductName: function(index){
			if(this.ProductNameData.oppotunities.length > 1){
				this.ProductNameData.oppotunities.splice(index, 1);
			}
			 
		},
		addNewClient: function(){
			
			for(i= 0; i < this.ProductNameData.oppotunities.length ;i++){
				this.ProductNameData.oppotunities[i]["expectedPremium"] = this.premium;
				this.ProductNameData.oppotunities[i]["status"] = "Active";
				delete this.ProductNameData.oppotunities[i].$$hashKey;
			}
			var addClientData="";
			if(this.prospectType === "INDIVIDUAL"){
				addClientData= {
				  "clientUpsertASBOList": [
					{
					  "mobileNumber": this.mobileNumber,
					  "emailId": this.emailID,
					  "firstName": this.firstName,
					  "lastName": this.lastName,
					  "title": this.productTitle,
					  "status": "Prospect",
					  "prospectPositions": [
						{
						  "userID": CommonServices.getCommonData("userId"),
						  "isPrimaryMVG": "Y"
						}
					  ],
					  "oppotunities": this.ProductNameData.oppotunities
					}
				  ],
				  "prospectType": this.prospectType
				};
			}
			if(this.prospectType === "CORPORATE"){
				//this.productTitle ="Mrs.";
				//this.mobileNumber="9999999498";
				this.productTitle ="";
				this.mobileNumber="";
				addClientData= {
				  "clientUpsertASBOList": [
					{
					  "mobileNumber": this.mobileNumber,
					  "firstName": this.firstName,
					  "title": this.productTitle,
					  "status": "Prospect",
					  "prospectPositions": [
						{
						  "userID": CommonServices.getCommonData("userId"),
						  "isPrimaryMVG": "Y"
						}
					  ],
					  "oppotunities": this.ProductNameData.oppotunities
					}
				  ],
				  "prospectType": this.prospectType
				};

			}
			
			
			var addClientResponse = RestServices.postService(RestServices.urlPathsNewPortal.updateInsertClient, addClientData);
			addClientResponse.then(
				function(response) { // success	
						
					CommonServices.showLoading(false);	
					if(response.data.errorCode === "0"){
						CommonServices.showAlert("You have successfully created the Client ID(Prospect ID). Prospect ID# "+ response.data.clientUpsertASBOList[0].clientID);
						$scope.addClientObj.premium ="";
						$scope.addClientObj.mobileNumber ="";
						$scope.addClientObj.emailID ="";
						$scope.addClientObj.lastName ="";
						$scope.addClientObj.firstName ="";
                                   $scope.addClientObj.corporatePartyField= false;
                                   if($scope.addClientObj.ProductNameData.oppotunities.length > 1){
                                        $scope.addClientObj.ProductNameData.oppotunities.splice(1);
                                   }
                                   if($scope.addClientObj.ProductNameData.oppotunities.length === 1){
                                        $scope.addClientObj.ProductNameData.oppotunities[0].productName = "";
                                   }
                                   if(response.data.prospectType === "CORPORATE"){
                                        $scope.addClientObj.prospectType = "";
                                   }
                                   if(response.data.prospectType === "INDIVIDUAL"){
                                        $scope.addClientObj.prospectType = "";
                                        $scope.addClientObj.productTitle = "";
                                   }

					}
					else{
						CommonServices.showAlert(response.data.erroMessage);
					}
				
						
				},
				function(error) { // failure
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
			});	
		},
		cancelClient: function(){
			$state.go("clients.myClients");
		},
		selectParty: function(partyValue){
		
			if(partyValue === "CORPORATE"){
				this.corporatePartyField = true;
			}
			else{
				this.corporatePartyField = false;
			}
		}
	}
	
	
}]);
