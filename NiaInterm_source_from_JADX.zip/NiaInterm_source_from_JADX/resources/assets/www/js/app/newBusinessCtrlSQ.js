agentApp.controller('newBusinessLandingCtrlSQ', ['$scope', '$rootScope', 'CommonServices', 'RestServices', '$location', '$state', function ($scope, $rootScope, CommonServices, RestServices, $location, $state) {
	CommonServices.SQParentPolicyHistory = false;
	$scope.SQfieldDisable = false;
	$scope.goBack = function () {
		/*CommonServices.goBack();*/
		if (CommonServices.isLoggedIn === true) {
			//$state.go('newBusinessMotorLandingScreen');
		}
		else {
			CommonServices.setCommonData("selectedProduct", 'motor');
			$state.go('buyNowSubLandingScreen');
		}
	}
	/*Below line added by 851587 during CR_NP_0752 to get previous Insurer list*/
	CommonServices.getDomainValues();

	$scope.getDefaultRelation = function () {
                /* added for CR_NP_754 */
		//var getDefaultRelationInput = { "userProfile": { "userId": CommonServices.getCommonData("userId"), "loggedInRole": "SUPERUSER", "stakeCode": CommonServices.getCommonData("stakeCode") } };

		//var getDefaultRelationResponse = RestServices.postService(RestServices.urlPathsNewPortal.getDefaultRelation, getDefaultRelationInput);
                /* added for CR_NP_754 */
  
		var getDefaultRelationInput;
		if (CommonServices.getCommonData("channel") === "MISP") {
			getDefaultRelationInput = { "partyDetails": { "partyCode": "" }, "userProfile": { "userId": CommonServices.getCommonData("userId"), "loggedInRole": CommonServices.getCommonData("loggedInRole"), "channel": CommonServices.getCommonData("channel") } };
		}
		else {
			getDefaultRelationInput = { "userProfile": { "userId": CommonServices.getCommonData("userId"), "loggedInRole": "SUPERUSER", "stakeCode": CommonServices.getCommonData("stakeCode") } };
		}
		var getDefaultRelationResponse;
		if (CommonServices.getCommonData("channel") === "MISP") {
			getDefaultRelationResponse = RestServices.postService(RestServices.urlPathsNewPortal.getMISPRelations, getDefaultRelationInput);
		} else {
			getDefaultRelationResponse = RestServices.postService(RestServices.urlPathsNewPortal.getDefaultRelation, getDefaultRelationInput);
		}

  /*CR_NP_754 ends */		
getDefaultRelationResponse.then(
			function (response) {
				CommonServices.showLoading(false);
				if (response.data.partyDetailsList !== undefined && response.data.partyDetailsList !== "") {
					CommonServices.setCommonData("defaultRelationResponse", response.data.partyDetailsList);
				}
				else {
					CommonServices.showAlert(response.data.errorMessage);
				}


			}, function (error) {
				CommonServices.showLoading(false);
				RestServices.handleWebServiceError(error);
			});
	}

	$scope.buyInsuranceTW = function () {

		$rootScope.buyNow.twoWheeler.newVehicle = "";
		$rootScope.buyNow.twoWheeler.quickQuote = {};
		$rootScope.buyNow.twoWheeler.basicPremium = {};
		$rootScope.buyNow.twoWheeler.additionalDetails = {};
		$rootScope.buyNow.twoWheeler.ncbDetails = {};
		$rootScope.buyNow.twoWheeler.addCovers = {};
		$rootScope.buyNow.twoWheeler.prevPolicyDetails = {};
		$rootScope.buyNow.twoWheeler.financierDetails = {};
		$rootScope.buyNow.twoWheeler.insuredDetails = {};
		$rootScope.buyNow.twoWheeler.summaryDetails = {};
		$rootScope.buyNow.twoWheeler.isAgentRequired = "";
		$rootScope.buyNow.twoWheeler.relationDetails = {};
		$rootScope.buyNow.twoWheeler.enhancementCoverages = {};//Added for NP_CR_0898
		

		$rootScope.buyNow.twoWheeler.newVehicle = true;
		if (CommonServices.getCommonData("stakeCode") === "DEALER") {
			$scope.getDefaultRelation();
		}

		$state.go('twQuickQuote');
		/* $state.go("twDetailQuote"); */
	}

	$scope.renewInsuranceTW = function () {

		$rootScope.buyNow.twoWheeler.newVehicle = "";
		$rootScope.buyNow.twoWheeler.quickQuote = {};
		$rootScope.buyNow.twoWheeler.basicPremium = {};
		$rootScope.buyNow.twoWheeler.additionalDetails = {};
		$rootScope.buyNow.twoWheeler.ncbDetails = {};
		$rootScope.buyNow.twoWheeler.addCovers = {};
		$rootScope.buyNow.twoWheeler.prevPolicyDetails = {};
		$rootScope.buyNow.twoWheeler.financierDetails = {};
		$rootScope.buyNow.twoWheeler.insuredDetails = {};
		$rootScope.buyNow.twoWheeler.summaryDetails = {};
		$rootScope.buyNow.twoWheeler.enhancementCoverages = {};//Added for NP_CR_0898
		$rootScope.buyNow.twoWheeler.newVehicle = false;
		$rootScope.buyNow.twoWheeler.StandaloneODDetails = {};
		if (CommonServices.getCommonData("stakeCode") === "DEALER") {
			$scope.getDefaultRelation();
		}
		/* $state.go('sqQuickQuote'); */
		$state.go('standaloneODDetails'); /* CR_3621 */

	}

	//Product Domain Values Service Call Start
	var inputTWData = {
		"productCode": "SQ", "lngCode": "EN", "keys": ["VEHICLE_COLOR", "FUEL_TYPE", "COVERAGE_TYPE",
			"COVERAGE_TYPE_SECOND_YEAR", "COVERAGE_TYPE_THIRD_YEAR", "COVERAGE_TYPE_SECOND_YEAR_CSC", "COVERAGE_TYPE_THIRD_YEAR_CSC",
			"OWN_DRIVER_LICENSE_TYPE", "VOLUNTARY_EXCESS", "LIABILITY_DURATION", "COVERAGE_TYPE_CSC"]
	};

	CommonServices.getProductDomainValues(inputTWData);
	//Product Domain Values Service Call End

}]);

/* Start CR_3621 */

agentApp.controller('standaloneODDetailsCtrl', ['$scope', '$rootScope', 'CommonServices', 'RestServices', 'GetSetResponseService', '$location', '$state', '$timeout', function ($scope, $rootScope, CommonServices, RestServices, GetSetResponseService, $location, $state, $timeout) {
	$scope.showSerachbtn = false;
	$rootScope.buyNow.twoWheeler.StandaloneODDetails = {};
	var mydateStr = CommonServices.getCommonData("serverDate"); // Need to uncomment. Coming from service
	var mynewdateFrom = "";
	if (mydateStr != undefined) {
		mynewdateFrom = new Date(mydateStr);
	}
	else {
		mynewdateFrom = new Date();
	}
        //CR_NP_3561 start
        var data ={'keys':['VEHICLE_AGE_LIMIT']};
	CommonServices.getVehicleAgeCount(data);
	//CR_NP_3561 end
	//Added during CR_NP_0752, since UAT had raised a defect
	var yesterdayDate = new Date(new Date().setDate(mynewdateFrom.getDate() - 1));
	var dd = yesterdayDate.getDate();
	var mm = yesterdayDate.getMonth() + 1;
	var yyyy = yesterdayDate.getFullYear();

	if (dd < 10) {
		dd = "0" + dd;
	}
	if (mm < 10) {
		mm = "0" + mm;
	}
	var maxDate = mm + "/" + dd + "/" + yyyy;//mm/dd/yyyy date till yesterday

	//changes ends	

	// 15 years back to todays date
	var minDate = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 15));
	minDate = new Date(minDate.setDate(minDate.getDate()));
	minDate = getFormattedDate(minDate);

	$('#ODpolicyStartDate').loadCalendar({
		'enableDateRange': true,
		'enableCalendarFrom': minDate,
		'enableCalendarTo': maxDate
	});
	
	$('#ODpolicyExpiryDate').loadCalendar({
	});	

	
	$scope.goBack = function () {
		CommonServices.SQParentPolicyHistory = false;
		$state.go('StandaloneODMotorTW');
		
	};
	
	
	$scope.standaloneODDetailsCtrl = {
		onload: function () {
			$rootScope.buyNow.twoWheeler.StandaloneODDetails.nameOfPrevIns = '';
			$rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyNo = '';
			$rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyStartDate = '';
			$rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyExpiryDate = '';
			$rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyType = '';
			}
		};
	
		$scope.refresh = function () {
		// $scope.twoWheelerODPolicyScreenForm.onload();
		$scope.standaloneODDetailsCtrl.onload();
	};

	$scope.calIconClick = function (event) {
		angular.element("#" + event.currentTarget.children[0].id).focus();
	};
	
	
	  $scope.getSearchbtn = function () {
								if ($rootScope.buyNow.twoWheeler.StandaloneODDetails.nameOfPrevIns == 'OPTION23'){
									$scope.showSerachbtn =true;
									$scope.SQfieldDisable = true;
								}
								else {
									$scope.showSerachbtn =false;
									$scope.SQfieldDisable = false;
									$rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyNo = '';
									$rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyStartDate = '';
									$rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyExpiryDate = '';
									$rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyType = '';
								}	
				};
	
		$scope.validateODDDetails = function () {
				
		if (($rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyNo !== undefined && $rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyNo !== "") && ($rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyStartDate !== undefined &&  $rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyStartDate !== "") && ($rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyExpiryDate !== undefined && $rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyExpiryDate !== "")) {
			
			var ODpolicyStartDatecamp = $rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyStartDate;
					var drr = ODpolicyStartDatecamp.split('/');
					ODpolicyStartDatecamp = drr[1] + '/' + drr[0] + '/' + drr[2]; //mm/dd/yyyy
					
					var ODpolicyExpiryDateComp = $rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyExpiryDate; 
					var srr = ODpolicyExpiryDateComp.split('/');
					ODpolicyExpiryDateComp = srr[1] + '/' + srr[0] + '/' + srr[2]; //mm/dd/yyyy
					
					ODpolicyStartDatecamp = new Date(ODpolicyStartDatecamp) ;
					ODpolicyExpiryDateComp = new Date(ODpolicyExpiryDateComp);

				 if(ODpolicyExpiryDateComp <= ODpolicyStartDatecamp){
					CommonServices.showAlert("Policy expiry date should not be greater than Policy Start Date" + "(" + $rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyStartDate + ")");
					return;
				 }
				var todayTime = new Date();
				var month = todayTime.getMonth() + 1;
				var day = todayTime.getDate();
				var year = todayTime.getFullYear();
				var sysdatecamp = month + "/" + day + "/" + year;
				sysdatecamp = new Date(sysdatecamp);
				  if(ODpolicyExpiryDateComp < sysdatecamp){
					CommonServices.showAlert("Policy expiry date should be greater than or equal to System Date");
					return;
				 }
			$rootScope.buyNow.twoWheeler.StandaloneODDetails.nameOfPrevIns = $scope.buyNow.twoWheeler.StandaloneODDetails.nameOfPrevIns;	 
			$rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyNo = $scope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyNo;
			$rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyStartDate = $scope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyStartDate;
			$rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyExpiryDate = $scope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyExpiryDate;
			$rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyType = $scope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyType;
			//$state.go('sqQuickQuote');

				if ($scope.showSerachbtn == true) {
					var policyDetailsInput = {
                        "userProfile": {
                            "userId": CommonServices.getCommonData("userCode").toUpperCase(),
                            "loggedInRole": CommonServices.getCommonData("loggedInRole")
                        },
                        "quote": {
                            "policyNumber": $rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyNo,
                            "processType": "NB",
                            "productCode": "SQ",
							"renewedQuoteNo":""
                        }
                    };
						
						var getpolicyListResponse = RestServices.postService(RestServices.urlPathsNewPortal.getPolicyDetails, policyDetailsInput);
						getpolicyListResponse.then(
							function(response) { // success	
							CommonServices.showLoading(false);
												  
								if(response.data.quote !== ""){
									CommonServices.setCommonData("SQPolicyDetails",response.data.quote);
									CommonServices.setCommonData("partyCode",response.data.quote.policyHolderCode); 
									CommonServices.SQParentPolicyHistory = true;
									$state.go('sqQuickQuote');
								}
								else{
									CommonServices.showAlert("Not able to load SQ Policy Details");
								}
									
							},
							function(error) { // failure
								CommonServices.showLoading(false);
								RestServices.handleWebServiceError(error);
						});
				} else {
						$state.go('sqQuickQuote');
					}
				}
			};
		
		$scope.searchDetails = function () {
					var todayTime = new Date();
					var month = todayTime.getMonth() + 1;
					var day = todayTime.getDate();
					var year = todayTime.getFullYear();
					var Todaysdatecamp = day + "/" + month + "/" + year;
					if ($rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyNo === undefined || $rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyNo === '') {
						CommonServices.showAlert("Enter policy number to proceed with the Policy Holder search.");
						return;
					}
					$scope.searchData = {
						 "policyNo": $rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyNo, "productCode": "SQ" , "proposalStartDt": Todaysdatecamp};
						
			var policyHolderResponse = RestServices.postService(RestServices.urlPathsNewPortal.SQgetParentPolDetails, $scope.searchData);
			if(policyHolderResponse === undefined){
				} else{
					policyHolderResponse.then(
						function(response) { // success	
							CommonServices.showLoading(false);	
							if(response.data !== ""){
								if(response.data.errCode != 0){
									CommonServices.showAlert(response.data.errMsg);
									$rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyNo = '';
									$rootScope.buyNow.twoWheeler.StandaloneODDetails.nameOfPrevIns = 'Select'
									$scope.showSerachbtn =false;
									$scope.SQfieldDisable = false;
									return;
								}
								else{
									if(response.data.errCode == 0){
										$scope.SQfieldDisable = true;
										$rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyNo = response.data.policyNo;
										$rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyStartDate = response.data.policyStartDt;
										$rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyExpiryDate = response.data.policyExpiryDt;
										$rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyType = response.data.coverageType;
									} 
								}
								
							}
							else{
								CommonServices.showAlert("Not able to load Parent SQ policy details");
							}
							
						},
						function(error) { // failure
							CommonServices.showLoading(false);
							RestServices.handleWebServiceError(error);
					});
					}
				  }
}]);

/* End CR_3621 */


agentApp.controller('sqQuickQuoteCtrl', ['$scope', '$rootScope', 'CommonServices', 'RestServices', 'GetSetResponseService', '$location', '$state', '$timeout', function ($scope, $rootScope, CommonServices, RestServices, GetSetResponseService, $location, $state, $timeout) {
	
	if(CommonServices.SQParentPolicyHistory === true){
		$scope.SQfieldDisable = true;
	}else {
		$scope.SQfieldDisable = false;
	}		
	$rootScope.buyNow.twoWheeler.additionalDetails.inbuiltBiFuelSysTW = "Yes";
	var mydateStr = CommonServices.getCommonData("serverDate"); // Need to uncomment. Coming from service

	var mynewdateFrom = "";
	if (mydateStr != undefined) {
		mynewdateFrom = new Date(mydateStr);
	}
	else {
		mynewdateFrom = new Date();
	}
        //CR_NP_3561 start
        var data ={'keys':['VEHICLE_AGE_LIMIT']};
	CommonServices.getVehicleAgeCount(data);
	//CR_NP_3561 end
	//Added during CR_NP_0752, since UAT had raised a defect
	var yesterdayDate = new Date(new Date().setDate(mynewdateFrom.getDate() - 1));
	var dd = yesterdayDate.getDate();
	var mm = yesterdayDate.getMonth() + 1;
	var yyyy = yesterdayDate.getFullYear();

	if (dd < 10) {
		dd = "0" + dd;
	}
	if (mm < 10) {
		mm = "0" + mm;
	}
	var maxDate = mm + "/" + dd + "/" + yyyy;//mm/dd/yyyy date till yesterday

	//changes ends	

	// 15 years back to todays date
	var minDate = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 15));
	minDate = new Date(minDate.setDate(minDate.getDate()));
	minDate = getFormattedDate(minDate);

	//$scope.todaysDate = arr[1] + '/' + arr[2] + '/' + arr[0];

	if ($rootScope.buyNow.twoWheeler.newVehicle == true) {
		minDate = maxDate;
	}

	$('#dateOfPurchaseReg').loadCalendar({
		'enableDateRange': true,
		'enableCalendarFrom': minDate,
		'enableCalendarTo': maxDate
	});


	$scope.item = "";
	// validates 10 digit mobile no. expression starting with 5,6,7,8,or9
	$scope.mobileNumExp = /^([56789])(?!\1+$)\d{9}$/;

	// validates email id expression ex:a@b.com, a@b.co.in
	$scope.emailIdExp = /\b^[a-zA-Z0-9][a-zA-Z0-9._-]*@[a-zA-Z0-9-]+(\.[a-zA-Z]{2,4}){1,3}\b$/;

	$scope.twoWheelerPolicyScreenCtrl = {
		onload: function () {

			$(':input').val('');
			CommonServices.makeWatch = false;
			$rootScope.buyNow.twoWheeler.quickQuote = {};

			//var getMakeListInputDate = {"motorProductCode":"TW"};//Input for makeList service for customer
			var getMakeListInputDate = { "userProfile": { "userId": CommonServices.getCommonData("userId"), "loggedInRole": "SUPERUSER" }, "motorProductCode": "SQ" };

			var getMakeListResponse = RestServices.postService(RestServices.urlPathsNewPortal.getMakeList, getMakeListInputDate);
			getMakeListResponse.then(
				function (response) {

					$scope.makes = response.data.makes.sort(CommonServices.sort_by('make', response.data.makes, ''));

					$scope.showIdvRange = false;
					GetSetResponseService.addMakeListResponseData(response.data);
					CommonServices.showLoading(false);

				}, function (error) {
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
				});

		},
		idvCall: function () {
			if ($scope.premiumFlag === false)
				$scope.calculateIDVServiceCall();

		}
	};
	$scope.twoWheelerPolicyScreenCtrl.onload();
	$scope.refresh = function () {
	if(CommonServices.SQParentPolicyHistory === true){
				$rootScope.buyNow.twoWheeler.quickQuote.make =CommonServices.getCommonData("SQPolicyDetails").vehicles[0].vehicleDetails.make;
				$rootScope.buyNow.twoWheeler.quickQuote.vehicleModel = CommonServices.getCommonData("SQPolicyDetails").vehicles[0].vehicleDetails.model;
				$rootScope.buyNow.twoWheeler.quickQuote.dateOfPurchaseReg=CommonServices.getCommonData("SQPolicyDetails").vehicles[0].vehicleDetails.dateOfFirstPurchaseOfVehicle;
				$rootScope.buyNow.twoWheeler.quickQuote.motorInvoice=CommonServices.getCommonData("SQPolicyDetails").vehicles[0].vehicleDetails.vehicleInvoiceValue;
				$rootScope.buyNow.twoWheeler.quickQuote.insuredDeclaredValue=CommonServices.getCommonData("SQPolicyDetails").vehicles[0].vehicleDetails.insuredsDeclaredValue;
		}
		else
		{
			$scope.twoWheelerPolicyScreenCtrl.onload();
		}
	}

	$scope.goBack = function () {
		CommonServices.SQParentPolicyHistory = false;
		$scope.SQfieldDisable = false;
		$state.go('standaloneODDetails');
	}

	$scope.calIconClick = function (event) {
		angular.element("#" + event.currentTarget.children[0].id).focus();
	};

	$scope.getModelDetailList = function () {

		CommonServices.makeWatch = true;
		$rootScope.buyNow.twoWheeler.quickQuote.vehicleModel = "";

		var getMakeListInputDate = { "motorProductCode": "SQ", "motorMake": $rootScope.buyNow.twoWheeler.quickQuote.make };
		var getMakeListResponse = RestServices.postService(RestServices.urlPathsNewPortal.getModelDetailList, getMakeListInputDate);
		getMakeListResponse.then(
			function (response) {

				if (response.data.motorMakemodels === undefined) {
					CommonServices.showAlert(response.data.errorMessage);
				}
				else {
					$scope.modelList = response.data.motorMakemodels.sort(
						CommonServices.sort_by('motorModel',
							response.data.motorMakemodels, ''));
					GetSetResponseService.addModelDetailListResponseData(response.data);
					for (var i = 0; i < response.data.motorMakemodels.length; i++) {
						response.data.motorMakemodels[i]["display"] = response.data.motorMakemodels[i].motorModel + "/" + response.data.motorMakemodels[i].motorVariant + "/" + response.data.motorMakemodels[i].motorCarryingCapacity;
					}
				}
				CommonServices.showLoading(false);
			}, function (error) {
				CommonServices.showLoading(false);
				RestServices.handleWebServiceError(error);
			});
	}

	$scope.getCustomerMakeCityList = function ($item) {
		$rootScope.buyNow.twoWheeler.quickQuote.insuredDeclaredValue = "";
		$scope.item = $item;
		$scope.resetIDV();
		// Changed during CR_NP_0752, because date of first purchase is taken as todays date by default for renew from other insurer
		if ($rootScope.buyNow.twoWheeler.newVehicle === false) {
			$scope.getInsuredDeclaredValue("date");
		} else {
			$scope.getInsuredDeclaredValue();
		}
		// changes ends
	}

	$scope.resetIDV = function () {
		$rootScope.buyNow.twoWheeler.quickQuote.insuredDeclaredValue = "";
		$scope.showIdvRange = false;
		$scope.minIDV = "";
		$scope.maxIDV = "";
	}

	$scope.modelChangeFunc = function () {
		$rootScope.buyNow.twoWheeler.quickQuote.insuredDeclaredValue = "";
		$rootScope.buyNow.twoWheeler.quickQuote.motorInvoice = "";
	}

	$scope.discountInfoService = function () {
		var discountInfoInput =
			{
				"userProfile": { "userId": CommonServices.getCommonData("userId"), "loggedInRole": "SUPERUSER", "branchCode": CommonServices.getCommonData("LoginData").branchCode },
				"quote": {
					"additionalQuoteDetails": { "isServiceTaxExempted": "N" }, "premiumDetails": {}, "previousPolicyDetails": {
						"nCBfromPreviousPolicy": $rootScope.buyNow.twoWheeler.ncbDetails.ncbOnPrevPolicyTW,
						"nCBPercentOnPreviousPolicy": $rootScope.buyNow.twoWheeler.ncbDetails.ncbPercOnPrevPolicyTW, "nCBApplicablePercentage": $rootScope.buyNow.twoWheeler.ncbDetails.ncbApplicablePerc,
						"anyClaimPendingOrPaidOnPolicyWhichIsToBeRenewed": $rootScope.buyNow.twoWheeler.ncbDetails.ncbClaimStatusTW !== undefined ? $rootScope.buyNow.twoWheeler.ncbDetails.ncbClaimStatusTW : "",
						"previousPolicyExpiryDate": $rootScope.buyNow.twoWheeler.prevPolicyDetails.prevPolExpDate !== undefined ? $rootScope.buyNow.twoWheeler.prevPolicyDetails.prevPolExpDate : "", "nameofPreviousInsurer": $rootScope.buyNow.twoWheeler.prevPolicyDetails.nameOfPrevIns !== undefined ? $rootScope.buyNow.twoWheeler.prevPolicyDetails.nameOfPrevIns : "",
						"previousPolicyNo": $rootScope.buyNow.twoWheeler.prevPolicyDetails.prevPolNum !== undefined ? $rootScope.buyNow.twoWheeler.prevPolicyDetails.prevPolNum : "", "addressofPreviousInsurer": ""
					}, "vehicles": [{
						"vehicleDetails":
						{
							"ownerDetails": {}, "financierDetails": {}, "discountDetails": {
								"memberOfAutomobileAssociationOfIndia": "N", "lifeMember": "Y", "vehicleDesignedFor": "N",
								"vehicleFittedWithAntiTheftedDevices": "N", "voluntaryExcess": "", "vehicleUseLimitedToOwnPremises": "N",
								"vehicleCertifiedByVinatageOrClassicCarClub": "N"
							}, "trailerDetails": [], "additionalVehicleDetails": {
								"vehicleRequistionedByGovt": "N",
								"vehicleUsedForDrivingTution": "N", "vehicleBelongsTo": "N", "policyExcess": $rootScope.buyNow.twoWheeler.additionalDetails.polExcessTW !== undefined ? $rootScope.buyNow.twoWheeler.additionalDetails.polExcessTW : "", "imposedExcess": "0"
							}, "nomineeDetails": {}, "registrationNo1": $rootScope.buyNow.twoWheeler.additionalDetails.reg1TW !== undefined ? $rootScope.buyNow.twoWheeler.additionalDetails.reg1TW : null,
							"registrationNo2": $rootScope.buyNow.twoWheeler.additionalDetails.reg2TW !== undefined ? $rootScope.buyNow.twoWheeler.additionalDetails.reg2TW : null, "registrationNo3": $rootScope.buyNow.twoWheeler.additionalDetails.reg3TW !== undefined ? $rootScope.buyNow.twoWheeler.additionalDetails.reg3TW : null,
							"registrationNo4": $rootScope.buyNow.twoWheeler.additionalDetails.reg4TW !== undefined ? $rootScope.buyNow.twoWheeler.additionalDetails.reg4TW : null, "dateOfRegistration": $rootScope.buyNow.twoWheeler.additionalDetails.dateOfRegTW !== undefined ? $rootScope.buyNow.twoWheeler.additionalDetails.dateOfRegTW : "", "dateOfFirstPurchaseOfVehicle": $rootScope.buyNow.twoWheeler.quickQuote.dateOfPurchaseReg,
							"doYouHoldValidDrivingLicense": $rootScope.buyNow.twoWheeler.addCovers.ownerDriveVehOrNotTW !== undefined ? $rootScope.buyNow.twoWheeler.addCovers.ownerDriveVehOrNotTW : "", "newVehicle": $rootScope.buyNow.twoWheeler.newVehicle !== undefined ? $rootScope.buyNow.twoWheeler.newVehicle : "",
							"make": $rootScope.buyNow.twoWheeler.quickQuote.make, "model": $rootScope.buyNow.twoWheeler.quickQuote.vehicleModel.motorModel,
							"variant": $rootScope.buyNow.twoWheeler.quickQuote.vehicleModel.motorVariant,
							"cityOfPurchase": CommonServices.getCommonData("LoginCity"), "insuredsDeclaredValue": $rootScope.buyNow.twoWheeler.quickQuote.insuredDeclaredValue,
							"totalIDV": 0, "seatingCapacityIncludingDriver": $rootScope.buyNow.twoWheeler.quickQuote.vehicleModel.motorCarryingCapacity, "cubicCapacity": $rootScope.buyNow.twoWheeler.quickQuote.vehicleModel.motorCC,
							"typeOfFuel": $rootScope.buyNow.twoWheeler.quickQuote.vehicleModel.motorFule, "yearOfManufacture": $rootScope.buyNow.twoWheeler.additionalDetails.yrOfManufactureTW,
							"wattage":$rootScope.buyNow.twoWheeler.additionalDetails.wattageInKW, //CR_3633
							"vehicleInvoiceValue": $rootScope.buyNow.twoWheeler.additionalDetails.vehInVoiceValTW, "valueOfFibreGlassFuelTanksInRs": "0",
							"extraElectricalElectronicFittings": "N", "valueOfACFan": "0", "valueOfLights": "0", "valueOfMusicSystem": "0", "valueOfOtherFittIngs": "0",
							"totalValueOfExtraElectricalElectronicFittingsInRs": "0", "valueOfNonElectricalElectronicFittingsInRs": "0", "trailerAttached": "Y",
							"isSideCarAttached": "N"
						}, "coverages": [{
							"coverageDetails": { "nomineeDetails": {}, "coverage": $rootScope.buyNow.twoWheeler.basicPremium.twCoverageSelected, "typeOfLiabilityCoverage": "A" },
							"additionalCoverageDetails": {
								"namesOfNamedPerson": [null], "extensionOfGeographicalAreaRequired": "N", "extensionToBangladesh": "N",
								"extensionToMaldives": "N", "extensionToPakistan": "N", "extensionToBhutan": "N", "extensionToNepal": "N", "extensionToSriLanka": "N",
								"additionalTowingCoverageAmount": "0", "lossOfAccesoriesCover": "N", "includePACoverForNamedPerson": "N", "numberOfNamedPersons": "1",
								"individualSIForNamedPerson": "0", "capitalSIForAllNamedPersons": "0", "pacoverForPaidDrivers": 0, "pacoverForUnnamedPersonOrHirerOrPillionPassengers": $rootScope.buyNow.twoWheeler.addCovers.indSIforUnnamedPerson,
								"lltoPaidDriversCleanerEmployed": "N", "numberOfLegalLiableDrivers": "0", "lltoEmployeesOfInsuredTravelingAndOrDrivingTheVehicle": "N",
								"numberOfLegalLiableEmployees": "0", "lltoSoldiersOrSailorsOrAirmenEmployedAsDrivers": "N", "numberOfLLSoldiersOrSailorsOrAirmen": "0",
								"reduceTPPDCover": "N"
							}, "addOnEnhancementCoverages": {}
						}]
					}], "salesChannel": { "salesDiscounts": [{ "inputDiscountPercentage": "0" }] },
					"policyHolderCode": "", "productCode": "SQ", "policyStartDate": $rootScope.buyNow.twoWheeler.quickQuote.policyStartDate,
					"policyExpiryDate": $rootScope.buyNow.twoWheeler.quickQuote.policyExpiryDate, "policyDuration": "1",
					"policyDurationUnit": "Year"
				}, "userProduct": { "productCode": "SQ" }
			};

		var discountInfoResponse = RestServices.postService(RestServices.urlPathsNewPortal.getDiscountInfo, discountInfoInput);

		discountInfoResponse.then(
			function (response) {
				CommonServices.showLoading(false);
				if (response.data.salesDiscount.discountPercentage !== undefined && response.data.salesDiscount.discountPercentage !== "") {
					$rootScope.buyNow.twoWheeler.quickQuote.discountPercentage = response.data.salesDiscount.discountPercentage;
						/*********CR: 3719 START*********/		
						if(make=="MG" && response.data.salesDiscount.discountPercentage > 50)
						{
							$rootScope.buyNow.twoWheeler.quickQuote.discountPercentage = 50;
						}
						/*********CR: 3719 START*********/	
				}
				else {
					$rootScope.buyNow.twoWheeler.quickQuote.discountPercentage = 0;
				}

			}, function (error) {
				CommonServices.showLoading(false);
				RestServices.handleWebServiceError(error);
			});
	}

	$scope.calculateIDVServiceCall = function (callDiscService = false) {
		var getInsuredDeclaredValueInputData =
			{
				"motorMake": $scope.item.motorMakeCd, "motorModel": $scope.item.motorModel, "motorCC": $scope.item.motorCC, "motorCarryingCapacity": $rootScope.buyNow.twoWheeler.quickQuote.vehicleModel.motorCarryingCapacity,
				"motorVariant": $scope.item.motorVariant, "motorProductCode": $scope.item.motorProductCode, "motorFule": $rootScope.buyNow.twoWheeler.quickQuote.vehicleModel.motorFule,
				"motorInvoice": $rootScope.buyNow.twoWheeler.quickQuote.motorInvoice, "processType": "NB", "dateOfPurchase": $rootScope.buyNow.twoWheeler.quickQuote.dateOfPurchaseReg, "policyStartDate": $scope.todaysDate,
				"motorIDV": $rootScope.buyNow.twoWheeler.quickQuote.insuredDeclaredValue, "motorZone": CommonServices.getCommonData("LoginCity"), "motorGVW": ""
			};

		CommonServices.setCommonData("makeCode", $scope.item.motorMakeCd);

		var getInsuredDeclaredValueResponse = RestServices.postService(RestServices.urlPathsNewPortal.calculateModelIDV, getInsuredDeclaredValueInputData);

		getInsuredDeclaredValueResponse.then(
			function (response) {
				CommonServices.showLoading(false);
				if (response.data.errorMessage !== undefined && response.data.errorMessage !== "") {
					CommonServices.showAlert(response.data.errorMessage);
				}
				else {
					$rootScope.buyNow.twoWheeler.quickQuote.insuredDeclaredValue = response.data.idv;
					$rootScope.buyNow.twoWheeler.quickQuote.motorInvoice = response.data.motorInvoice;
					$scope.minIDV = response.data.minIDV;
					$scope.maxIDV = response.data.maxIDV;
					$timeout(function () {
						$scope.slider = response.data.idv;
					});
					$scope.showIdvRange = (response.data.maxIDV != undefined);
					$scope.idvInputValueChangeErrorMessage = false;
					if (CommonServices.isLoggedIn === true) {
						if ($rootScope.buyNow.twoWheeler.quickQuote.mobileNumber == undefined || $rootScope.buyNow.twoWheeler.quickQuote.mobileNumber == "") {
							$rootScope.buyNow.twoWheeler.quickQuote.mobileNumber = GetSetResponseService.getloginResponseData()[0].userProfile.relation.addresses[0].mobileNumber1;
						}

						if ($rootScope.buyNow.twoWheeler.quickQuote.emailID == undefined || $rootScope.buyNow.twoWheeler.quickQuote.emailID == "") {
							$rootScope.buyNow.twoWheeler.quickQuote.emailID = GetSetResponseService.getloginResponseData()[0].userProfile.relation.addresses[0].emailId1;
						}

					}
					if (callDiscService) $scope.discountInfoService();
				}


			}, function (error) {
				CommonServices.showLoading(false);
				RestServices.handleWebServiceError(error);
			});
	}

	$scope.getInsuredDeclaredValue = function (date) {


		//var arr = maxDate.split('-');
		$scope.todaysDate = mydateStr;
		var validDate = $scope.todaysDate;
		arr = validDate.split('/');

		//Added during CR_NP_0752, since UAT had raised a defect, BY default date of first purchase is taken a day less than today, also when today is months last date(say 01/06/2018) then date of first purchase is taken as 00/06/2018.
		// expDate ="";
		var todayDate = new Date(validDate);
		var yesterdayDate = new Date(new Date().setDate(todayDate.getDate() - 1));
		var dd = yesterdayDate.getDate();
		var mm = yesterdayDate.getMonth() + 1;
		var yyyy = yesterdayDate.getFullYear();

		if (dd < 10) {
			dd = "0" + dd;
		}
		if (mm < 10) {
			mm = "0" + mm;
		}

		dateOfPurchaseReg = arr[1] + '/' + arr[0] + '/' + arr[2];
		validDate = arr[1] + '/' + arr[0] + '/' + arr[2]; //dd/mm/yyyy
		var expiryDate = dd + '/' + mm + '/' + (Number(yyyy) + 1);

		// Added here because UAT had raised a issue during CR_NP_0752, renew from other insurer, date of first purchase is taken as todays date by default and is non editable.
		$('#dateOfPurchaseReg').loadCalendar({
			'enableDateRange': true,
			'enableCalendarFrom': minDate,
			'enableCalendarTo': maxDate
		});
		//CR_NP_0752 changes ends
		if (date === validDate) {
			$scope.regDateError = true;
			$scope.twoWheelerPolicyScreenForm.$invalid = true;
			return false;
		}
		else {
			$scope.regDateError = false;
			$scope.twoWheelerPolicyScreenForm.$invalid = false;
		}

		if (date === undefined) {
			if ($rootScope.buyNow.twoWheeler.newVehicle === true) {
				$rootScope.buyNow.twoWheeler.quickQuote.dateOfPurchaseReg = dateOfPurchaseReg;
			}
			$rootScope.buyNow.twoWheeler.quickQuote.policyStartDate = validDate;
			$rootScope.buyNow.twoWheeler.quickQuote.policyExpiryDate = expiryDate;
			$rootScope.buyNow.twoWheeler.additionalDetails.yrOfManufactureTW = arr[2];
		}

/* edited for CR_NP_754 */

		// $scope.discountInfoService();
		if (CommonServices.getCommonData("stakeCode") !== "DEALER" || CommonServices.getCommonData("channel") === "MISP") {
			$scope.calculateIDVServiceCall(true);
		} else {
			$scope.discountInfoService();
		}
	};

/* CR_NP_754 ends*/

	$scope.idvInputValueChange = function () {
		if (parseInt($scope.maxIDV) < parseInt($rootScope.buyNow.twoWheeler.quickQuote.insuredDeclaredValue)) {
			$scope.idvInputValueChangeErrorMessage = true;
			return;
		}
		if (parseInt($scope.minIDV) > parseInt($rootScope.buyNow.twoWheeler.quickQuote.insuredDeclaredValue)) {
			$scope.idvInputValueChangeErrorMessage = true;
			return;
		}
		$timeout(function () {
			$scope.slider = $rootScope.buyNow.twoWheeler.quickQuote.insuredDeclaredValue;
		});
		$scope.idvInputValueChangeErrorMessage = false;
	};

	$scope.idvRangeChange = function () {
		$rootScope.buyNow.twoWheeler.quickQuote.insuredDeclaredValue = parseInt($("#idvFromRange").val());
	};

	$scope.showTermsAndConditionsQQ = function () {
		CommonServices.showAlert("I understand that by providing my mobile no and e-mail id through the Mobile App, I agree to being contacted by The New India Assurance Co.Ltd. The New India Assurance Co.Ltd shall protect all such information and it shall not be utilised in any manner that will directly or indirectly result in any harm to me. I understand and accept that The New India Assurance Co.Ltd reserves the right to determine the eligibility and availability of any product or service.I understand that premium shown in the Quick Quote is only estimated premium and may be subjected to change during Detailed Quote depending on the Cover selected and other information provided by me. And I also understand that the premium shown on the Mobile App will be subjected to any changes based on the IRDAI regulations from time to time.");
		CommonServices.setCommonData("backFlag", "");
		$rootScope.saveQuotRespData = "";
	}

	var addYears = function (todaysDate) {

		var dt = new Date(todaysDate);
		var newDate = new Date(dt.getFullYear() + $rootScope.term1, dt.getMonth(), dt.getDate() - 1);//added for CR_0926
		var d = new Date(newDate || Date.now()),

			month = '' + (d.getMonth() + 1),
			day = '' + d.getDate(),
			year = d.getFullYear();

		if (month.length < 2) month = '0' + month;
		if (day.length < 2) day = '0' + day;

		return [day, month, year].join('/'); //dd/mm/yyyy
	}
	$scope.dateFormat = function (todaysDate) {
		var policydt = new Date(todaysDate);
		var policynewDate = new Date(policydt.getFullYear(), policydt.getMonth(), policydt.getDate());
		var policyd = new Date(policynewDate || Date.now()),

			month = '' + (policyd.getMonth() + 1),
			day = '' + policyd.getDate(),
			year = policyd.getFullYear();

		if (month.length < 2) month = '0' + month;
		if (day.length < 2) day = '0' + day;

		return [day, month, year].join('/'); //dd/mm/yyyy
	}
	$scope.premiumFlag = false;
	
	if(CommonServices.SQParentPolicyHistory === true){
			//console.log("CommonServices.SQPolicyDetails :"+JSON.stringify(CommonServices.getCommonData("SQPolicyDetails")));
			$rootScope.buyNow.twoWheeler.quickQuote.make =CommonServices.getCommonData("SQPolicyDetails").vehicles[0].vehicleDetails.make;
			$rootScope.buyNow.twoWheeler.quickQuote.vehicleModel =CommonServices.getCommonData("SQPolicyDetails").vehicles[0].vehicleDetails.model;
			$rootScope.buyNow.twoWheeler.quickQuote.dateOfPurchaseReg=CommonServices.getCommonData("SQPolicyDetails").vehicles[0].vehicleDetails.dateOfFirstPurchaseOfVehicle;
			$rootScope.buyNow.twoWheeler.quickQuote.motorInvoice=CommonServices.getCommonData("SQPolicyDetails").vehicles[0].vehicleDetails.vehicleInvoiceValue;
			$rootScope.buyNow.twoWheeler.quickQuote.insuredDeclaredValue=CommonServices.getCommonData("SQPolicyDetails").vehicles[0].vehicleDetails.insuredsDeclaredValue;
			$rootScope.buyNow.twoWheeler.basicPremium.twCoverageSelected=CommonServices.getCommonData("SQPolicyDetails").vehicles[0].coverages[0].coverageDetails.coverage;
			$rootScope.buyNow.twoWheeler.insuredDetails.partyCode = CommonServices.getCommonData("SQPolicyDetails").policyHolderCode;
			$scope.discountInfoService();
	//console.log("$rootScope.buyNow.twoWheeler.quickQuote :"+CommonServices.getCommonData("SQPolicyDetails").vehicles[0].coverages[0].coverageDetails.coverage);
	
	}
	
	$scope.twoWheelerKnowYourPremium = function () {
		CommonServices.showLoading(true);
	//added for CR_0922 Start
		$rootScope.newdate=$rootScope.buyNow.twoWheeler.quickQuote.dateOfPurchaseReg;
		    $rootScope.getDateDiff1= function(toDate,fromDate,measureUnit,flag){
	        
		    	var d1= toDate,d2= fromDate;
		    	if(toDate<fromDate){
		    		d1= fromDate;
		    		d2= toDate;
		    	}
		    	var m= (d1.getFullYear()-d2.getFullYear())*12+(d1.getMonth()-d2.getMonth());
		    	if(d1.getDate()>d2.getDate())
                 m++;
		    	return m;
		    	
	  	};	
		
			var maxDatePolicyDuration =CommonServices.systemDate.split(' ')[0];
			var arr=maxDatePolicyDuration.split('/');
			var todaysDate1 = new Date( arr[2],arr[0]-1,arr[1]);//arr[1] + '/' + arr[0] + '/' + arr[2]; yyyy/mm/dd
			var arr2=$rootScope.newdate.split('/');
			var todaysDate2 = new Date( arr2[2],arr2[1]-1,arr2[0]);//yyyy/mm/dd
			var datediffMonth1 = this.getDateDiff1(todaysDate2,todaysDate1,'months');
			$rootScope.term1=1;
		/* if(datediffMonth1<=CommonServices.vehicleAgeCount.configurableDatas[0].value) //CR_NP_3561
			{
			$rootScope.term1=5;
			}else $rootScope.term1=1; */	
		//added for CR_0922 end
	
	
	
		$scope.premiumFlag = true;
		$rootScope.buyNow.twoWheeler.quickQuote.mobileNumber = CommonServices.getCommonData("collectionDetails").mobileNum;
		$rootScope.buyNow.twoWheeler.quickQuote.emailID = CommonServices.getCommonData("collectionDetails").emailID;
		$rootScope.buyNow.twoWheeler.quickQuote.vehicleCity = CommonServices.getCommonData("LoginCity");

		var todaysDate = mydateStr; //mm/dd/yyyy
		var forComparingDateOfPurchaseReg = mydateStr; //dd/mm/yyyy

		var policyExpiryDate = addYears(todaysDate);
		var policyStartDate = $scope.dateFormat(todaysDate);

		if ($rootScope.buyNow.twoWheeler.newVehicle == false) {
			if (forComparingDateOfPurchaseReg == $rootScope.buyNow.twoWheeler.quickQuote.dateOfPurchaseReg) {
				CommonServices.showAlert("Date of first purchase of Vehicle/Registration cannot be todays date for renew existing policy from any insurer");
				return;
			}
		}
		if (parseInt($rootScope.buyNow.twoWheeler.quickQuote.insuredDeclaredValue) > parseInt($scope.maxIDV) || parseInt($rootScope.buyNow.twoWheeler.quickQuote.insuredDeclaredValue) < parseInt($scope.minIDV)) {
			CommonServices.showAlert("Please enter values between " + $scope.minIDV + "and " + $scope.maxIDV);
			return;
		};
		$rootScope.buyNow.twoWheeler.quickQuote.policyStartDate = policyStartDate;
		$rootScope.buyNow.twoWheeler.quickQuote.policyExpiryDate = policyExpiryDate;
		
		var getQuickQuoteDetailInputData =
			{
				"userProfile": {
					"userId": CommonServices.getCommonData("userId"),
					"loggedInRole": "SUPERUSER",
					"stakeCode": CommonServices.getCommonData("stakeCode")
				},
				"quote": {
					"vehicles": [
						{
							"vehicleDetails": {
								"drivers": [
									{
										"driverDetails": {

										}
									}
								],
								"make": $rootScope.buyNow.twoWheeler.quickQuote.make,
								"model": $rootScope.buyNow.twoWheeler.quickQuote.vehicleModel.motorModel,
								"variant": $rootScope.buyNow.twoWheeler.quickQuote.vehicleModel.motorVariant,
								"insuredsDeclaredValue": $rootScope.buyNow.twoWheeler.quickQuote.insuredDeclaredValue,
								"dateOfFirstPurchaseOfVehicle": $rootScope.buyNow.twoWheeler.quickQuote.dateOfPurchaseReg,
								"vehicleAgeInMonths": 0,
								"cityOfPurchase": $rootScope.buyNow.twoWheeler.quickQuote.vehicleCity === undefined ? "" : $rootScope.buyNow.twoWheeler.quickQuote.vehicleCity,
								"cubicCapacity": $rootScope.buyNow.twoWheeler.quickQuote.vehicleModel.motorCC,
								"seatingCapacityIncludingDriver": $rootScope.buyNow.twoWheeler.quickQuote.vehicleModel.motorCarryingCapacity,
								"typeOfFuel": $rootScope.buyNow.twoWheeler.quickQuote.vehicleModel.motorFule,
								"wattage":$rootScope.buyNow.twoWheeler.quickQuote.vehicleModel.wattageInKW //CR_3633
							}
						}
					],
					"productCode": "TW",
					"term": $rootScope.term1,//CR_926
					"mobileNo": $rootScope.buyNow.twoWheeler.quickQuote.mobileNumber === undefined ? "" : $rootScope.buyNow.twoWheeler.quickQuote.mobileNumber,
					"emailId": $rootScope.buyNow.twoWheeler.quickQuote.emailID === undefined ? "" : $rootScope.buyNow.twoWheeler.quickQuote.emailID,
					"policyStartDate": $rootScope.buyNow.twoWheeler.quickQuote.policyStartDate,
					"policyExpiryDate": $rootScope.buyNow.twoWheeler.quickQuote.policyExpiryDate
				}
			};


		var getQuickQuoteResponse = RestServices.postService(RestServices.urlPathsNewPortal.getQuickQuoteDetail, getQuickQuoteDetailInputData);

		getQuickQuoteResponse.then(
			function (response) {

				if (response.data.errorCode == 960) {
					CommonServices.showAlert(response.data.errorMessage);
					CommonServices.showLoading(false);
				}
				if (response.data.errorCode == 959) {
					CommonServices.showAlert("Could not connect to server.Please try after some time", "Alert");
					CommonServices.showLoading(false);
				} else if (response.data.userProfile.footer.errorCode == 0) {
					GetSetResponseService.addQuickQuoteDetailResponseData(response.data);
					CommonServices.setCommonData("quickQuoteNumber", response.data);
					$rootScope.twBasicPremium = undefined;
					$state.go('sqBasicPremiumCal');
				} else {
					CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
				}
				CommonServices.showLoading(false);
			}, function (error) {
				CommonServices.showLoading(false);
				RestServices.handleWebServiceError(error);
			});
	};

}]);

agentApp.controller('sqBasicPremiumCalScreenCtrl', ['$scope', '$rootScope', 'CommonServices', 'RestServices', 'GetSetResponseService', '$location', '$state', function ($scope, $rootScope, CommonServices, RestServices, GetSetResponseService, $location, $state) {
		
	$scope.changeTermFlag = false;//To Use
	if ($scope.twBasicPremium === undefined) {//To Use
//Change for CR_926 Start		
		if($rootScope.term1==5)
			$scope.twBasicPremium = "5";
		else
		$scope.twBasicPremium = $rootScope.term1;
	}

	var mydateStr = CommonServices.getCommonData("serverDate");
	var mynewdateFrom = "";
	if (mydateStr != undefined) {
		mynewdateFrom = new Date(mydateStr);
	}
	else {
		mynewdateFrom = new Date();
	}

	$scope.sqBasicPremiumCalScreenCtrl = {
		onload: function () {
			
		if(CommonServices.SQParentPolicyHistory === true){
			$rootScope.buyNow.twoWheeler.basicPremium.packageValue = CommonServices.getCommonData("SQPolicyDetails").premiumDetails.totalPremium;
			$rootScope.buyNow.twoWheeler.basicPremium.enhancementValue = CommonServices.getCommonData("SQPolicyDetails").premiumDetails.totalPremium;
			$rootScope.buyNow.twoWheeler.basicPremium.twCoverageSelected = CommonServices.getCommonData("SQPolicyDetails").vehicles[0].coverages[0].coverageDetails.coverage;
			$rootScope.buyNow.twoWheeler.basicPremium.quoteNumber =  CommonServices.getCommonData("SQPolicyDetails").quoteNumber;
			$rootScope.buyNow.twoWheeler.basicPremium.totalPremium = CommonServices.getCommonData("SQPolicyDetails").premiumDetails.totalPremium;
			$rootScope.buyNow.twoWheeler.basicPremium.coverage=CommonServices.getCommonData("SQPolicyDetails").vehicles[0].coverages[0].coverageDetails.coverage;
				if ($rootScope.buyNow.twoWheeler.basicPremium.coverage === "EHMNTCOVER") {
						$scope.SQE=true;
				}
				else if ($rootScope.buyNow.twoWheeler.basicPremium.coverage === "PACKAGE") {
						$scope.SQP=true;
				}
			} else {
			$scope.SQE=true;
			$scope.SQP=true;
			$rootScope.buyNow.twoWheeler.basicPremium.liabilityValue = GetSetResponseService.getQuickQuoteDetailResponseData()[0].quote.premiumDetails.laibilityPremium;
			$rootScope.buyNow.twoWheeler.basicPremium.packageValue = GetSetResponseService.getQuickQuoteDetailResponseData()[0].quote.premiumDetails.packagePremium;
			$rootScope.buyNow.twoWheeler.basicPremium.enhancementValue = GetSetResponseService.getQuickQuoteDetailResponseData()[0].quote.premiumDetails.enhancementPremium;

			if (CommonServices.fromRAForEditQuote === true) {
				$rootScope.buyNow.twoWheeler.basicPremium.quoteNumber = $rootScope.collectPremRecentActivities.quoteNo;
				$scope.showPremiums = false;
				if ($scope.changeTermFlag === false) {//To Use
					$scope.twBasicPremium = $rootScope.policyDuration;
				}
			} else {
				$rootScope.buyNow.twoWheeler.basicPremium.quoteNumber = GetSetResponseService.getQuickQuoteDetailResponseData()[0].quote.quoteNumber;
				$scope.showPremiums = true;
			}
			$rootScope.buyNow.twoWheeler.basicPremium.quoteNumber = GetSetResponseService.getQuickQuoteDetailResponseData()[0].quote.quoteNumber;
			$rootScope.buyNow.twoWheeler.basicPremium.totalPremium = GetSetResponseService.getQuickQuoteDetailResponseData()[0].quote.premiumDetails.laibilityPremium;
			$rootScope.buyNow.twoWheeler.basicPremium.coverage = undefined;
		}
	  }
	};
		$scope.sqBasicPremiumCalScreenCtrl.onload();

	$scope.goBack = function () {

		// if (CommonServices.deviceType !== "NA")
		// 	navigator.notification.confirm("Are you sure you want to navigate back to Quick Quote screen ? All the saved data will be lost", navigateBackAgain, "Alert", ["Ok", "Cancel"]);
		// else {
		// 	var backConfirm;
		// 	backConfirm = confirm("Are you sure you want to navigate back to Quick Quote screen ? All the saved data will be lost");
		// 	if (backConfirm === true) {
		// 		navigateBackAgain(1);
		// 	}
		// }
		
		var msg = "Are you sure you want to navigate back to Quick Quote screen ? All the saved data will be lost";
		CommonServices.messageModal('info', msg, false, 'Cancel', 'Ok', function () {}, function () { navigateBackAgain(1);}, 'Alert');

		//navigateBackAgain(1);     
	};

	function navigateBackAgain(button) {
		if (button == 1) {
			CommonServices.fromRAForEditQuote = false;
			CommonServices.fromRecentActivities = false;
			CommonServices.makeWatch = true;
			CommonServices.setCommonData("backFlag", "");
			//$state.go('sqQuickQuote');
			CommonServices.SQParentPolicyHistory = false;
			$scope.SQfieldDisable = false;
			$state.go('standaloneODDetails'); /* Cr_3621 */

		}
	}

	//added for CR_0922 Start
	   $rootScope.newdate=$rootScope.buyNow.twoWheeler.quickQuote.dateOfPurchaseReg;
		var maxDatePolicyDuration =CommonServices.systemDate.split(' ')[0];
		var arr=maxDatePolicyDuration.split('/');
		var todaysDate1 = new Date( arr[2],arr[0]-1,arr[1]);//arr[1] + '/' + arr[0] + '/' + arr[2]; yyyy/mm/dd
		var arr2=$rootScope.newdate.split('/');
		var todaysDate2 = new Date( arr2[2],arr2[1]-1,arr2[0]);//yyyy/mm/dd
		
		var policyMonth = $rootScope.getDateDiff1(todaysDate2,todaysDate1,'months');
		//alert("curDate policyMonth"+policyMonth);
		 $rootScope.policyMonthDiff=policyMonth;//added for cr_np_941
	/* if(policyMonth<=CommonServices.vehicleAgeCount.configurableDatas[0].value)//CR_NP_3561
		{
			 $scope.hideother=true;
		     $scope.showfive=true;
			 $scope.isnewVehicle=true;
		}
		else
	    {
			$scope.hideother=false;
		    $scope.showfive=false;
			$scope.isnewVehicle=false;
		} */
		
		$scope.hideother=false; //CR_3621
		$scope.isnewVehicle=false;	
		
		$scope.datediffMonth=policyMonth;

			//added for CR_0922 End
	

	$scope.twCoverageSelected = function ($event, twCoverageSelected) {
	   $(".twBasicPremiumDetails ul li").removeClass("twCoverageSelected");
		$($event.currentTarget).addClass("twCoverageSelected");
	    //added for CR_0922 Start
		  $scope.showfive=false;
		  $scope.hideother=false;
		  //added for CR_0922 End 

		$(".twBasicPremiumDetails ul li").removeClass("twCoverageSelected");
		$($event.currentTarget).addClass("twCoverageSelected");
		$rootScope.buyNow.twoWheeler.basicPremium.twCoverageSelected = twCoverageSelected;

		if (twCoverageSelected == "LIABILITY") {
		
	   //added for CR_0922 Start
			  
			   if($scope.datediffMonth<=CommonServices.vehicleAgeCount.configurableDatas[0].value) //CR_NP_3561
			   {
				   $scope.hideother=true;
				   $scope.showfive=true;
			   }
			   else{
			       $scope.hideother=false;
		           $scope.showfive=false;
				   }
		    
			 //added for CR_0922 End 	
			$rootScope.buyNow.twoWheeler.basicPremium.totalPremium = GetSetResponseService.getQuickQuoteDetailResponseData()[0].quote.premiumDetails.laibilityPremium;
			$rootScope.buyNow.twoWheeler.basicPremium.coverage = "L";
		} else if (twCoverageSelected == "PACKAGE") {
		    //added for CR_0922 Start
			  
			  /*  if($scope.datediffMonth<=CommonServices.vehicleAgeCount.configurableDatas[0].value) //CR_NP_3561
			   {
				   $scope.hideother=true;
				   $scope.showfive=true;
			   }
			   else
			   {
				   $scope.hideother=false;
				   $scope.showfive=false;
			   } */
		    
			 //added for CR_0922 End
			 $scope.hideother=false; /* CR_3621 */
			$scope.showfive=false;
			if(CommonServices.SQParentPolicyHistory === true){
				$rootScope.buyNow.twoWheeler.basicPremium.totalPremium = CommonServices.getCommonData("SQPolicyDetails").premiumDetails.totalPremium;
			}else{
				$rootScope.buyNow.twoWheeler.basicPremium.totalPremium = GetSetResponseService.getQuickQuoteDetailResponseData()[0].quote.premiumDetails.packagePremium;
			}
			$rootScope.buyNow.twoWheeler.basicPremium.coverage = "P";
		} else if (twCoverageSelected == "ENHANCEMENT") {
		    //added for CR_0922 Start
			  
			  /*  if($scope.datediffMonth<=CommonServices.vehicleAgeCount.configurableDatas[0].value) //CR_NP_3561
			   {
				   
				   $scope.hideother=true;
				   $scope.showfive=true;
			   }
			   else
			   {
				   $scope.hideother=false;
				   $scope.showfive=false;
			   }
		     */
			 //added for CR_0922 End 
			 $scope.hideother=false; /* CR_3621 */
			  $scope.showfive=false;
			if(CommonServices.SQParentPolicyHistory === true){
				$rootScope.buyNow.twoWheeler.basicPremium.totalPremium = CommonServices.getCommonData("SQPolicyDetails").premiumDetails.totalPremium;
			}else{
				$rootScope.buyNow.twoWheeler.basicPremium.totalPremium = GetSetResponseService.getQuickQuoteDetailResponseData()[0].quote.premiumDetails.enhancementPremium;
			}
			$rootScope.buyNow.twoWheeler.basicPremium.coverage = "E";
		}
		
		//added for CR_0922 Start
		else if (twCoverageSelected == "PACKAGE5") {
			
			  
			   if($scope.datediffMonth<=CommonServices.vehicleAgeCount.configurableDatas[0].value) //CR_NP_3561
			   {
				   $scope.hideother=true;
				   $scope.showfive=true;
			   }
			   else
			   {
				   $scope.hideother=false;
				   $scope.showfive=false;
			   }
		    
			
			$rootScope.buyNow.twoWheeler.basicPremium.totalPremium = GetSetResponseService.getQuickQuoteDetailResponseData()[0].quote.premiumDetails.packagePremium;
			$rootScope.buyNow.twoWheeler.basicPremium.coverage = "P5";
		} else if (twCoverageSelected == "ENHANCEMENT5") {
			
			
			  
			   if($scope.datediffMonth<=CommonServices.vehicleAgeCount.configurableDatas[0].value) //CR_NP_3561
			   {
				   
				   $scope.hideother=true;
				   $scope.showfive=true;
			   }
			   else
			   {
				   $scope.hideother=false;
				   $scope.showfive=false;
			   }
		    
			
			$rootScope.buyNow.twoWheeler.basicPremium.totalPremium = GetSetResponseService.getQuickQuoteDetailResponseData()[0].quote.premiumDetails.enhancementPremium;
			$rootScope.buyNow.twoWheeler.basicPremium.coverage = "E5";
		}
		 //added for CR_0922 End 
		
	}


	$scope.proceedForDetailsQuote = function () {
	$rootScope.twBasicPremium = $rootScope.term1;//Added for CR_for CR_926
		var selectedCoverageTW=$rootScope.buyNow.twoWheeler.basicPremium.coverage;//Added for CR_0898
	//var IDVvalue=$rootScope.buyNow.twoWheeler.quickQuote.insuredDeclaredValue;//Added for CR_0898
		if ($rootScope.buyNow.twoWheeler.basicPremium.coverage === undefined) {
			CommonServices.showAlert("Please select coverage type");
			return;
		}

		if ($rootScope.buyNow.twoWheeler.basicPremium.coverage == "L") {
			if ($rootScope.buyNow.twoWheeler.basicPremium.liabilityValue == "0") {
				CommonServices.showAlert("Sorry, You cannot proceed with zero premium for this coverage", "Alert");
				return;
			}
		}

		if ($rootScope.buyNow.twoWheeler.basicPremium.coverage == "P") {
			if ($rootScope.buyNow.twoWheeler.basicPremium.packageValue == "0") {
				CommonServices.showAlert("Sorry, You cannot proceed with zero premium for this coverage", "Alert");
				return;
			}
		}

		if ($rootScope.buyNow.twoWheeler.basicPremium.coverage == "E") {
			if ($rootScope.buyNow.twoWheeler.basicPremium.enhancementValue == "0")
			{
			if(policyMonth>58){
				CommonServices.showAlert("Please Change the Cover As vahicle age greter then 58 months", "Alert");
				return;
			}
			else{
				CommonServices.showAlert("Sorry, You cannot proceed with zero premium for this coverage", "Alert");
				return;
			}
		}
		}
		
		if((selectedCoverageTW == "E" || selectedCoverageTW == "E5") && ($rootScope.buyNow.twoWheeler.quickQuote.insuredDeclaredValue > 1500000)){
	   CommonServices.showAlert("Enhancement cover can be selected for vehicale IDV up to 15 Lakhs.Please change the cover to package or Liability to proceed with your policy,if you wish to continue with Enhancement cover please contact policy issuing office");
				return;

	}
		

		var FiveYearsBackTodaysDate = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 5));
		FiveYearsBackTodaysDate = new Date(FiveYearsBackTodaysDate.setDate(FiveYearsBackTodaysDate.getDate()));
		FiveYearsBackTodaysDate = getFormattedDate(FiveYearsBackTodaysDate); // 5 years back todays date mm/dd/yyyy

		var dateOfPurchaseReg = $rootScope.buyNow.twoWheeler.quickQuote.dateOfPurchaseReg; //mm/dd/yyyy

		if (new Date(dateOfPurchaseReg) < new Date(FiveYearsBackTodaysDate)) {
			if ($rootScope.buyNow.twoWheeler.basicPremium.coverage == "E") {
				CommonServices.showAlert("Vehicle age as on policy commencement date exceeds eligibility for opting Enhancement cover. Hence enhancement coverage will not be applicable. Please re-select the applicable coverage from Basic Premium quote screen.");
				return;
			}
		}

		/* NP_CR_0898 Start*/
	
	$rootScope.showaddenhancementCoveragesDiv = false;
	$rootScope.showNCBProtectionCover=false;
	 $rootScope.nillEnd=false;
	if(selectedCoverageTW == "E" && ($rootScope.term1=='2'||$rootScope.term1=='3') ){
	
	   $rootScope.nillEnd=true;
	   $rootScope.showaddenhancementCoveragesDiv = false;
	   $rootScope.showRoadTaxAmount = false;
	   //$rootScope.showNCBProtectionCover=true;
	   
	}
	else if((selectedCoverageTW == "E5"|| selectedCoverageTW == "E")&&($rootScope.term1=='1'||$rootScope.term1=='5')){
	$rootScope.showaddenhancementCoveragesDiv = true;
	$rootScope.showRoadTaxAmount = false;
	   //$rootScope.showNCBProtectionCover=false;
	
	}
	else{ 
	$rootScope.showaddenhancementCoveragesDiv = false;
	}
	
$rootScope.showNCBProtectionCover=false;
	if(selectedCoverageTW=="E"){
	$rootScope.showNCBProtectionCover=true;
	}else if(selectedCoverageTW=="E5")
	{
	$rootScope.showNCBProtectionCover=false;
	}else {
	$rootScope.showNCBProtectionCover=false;
	}

  /* NP_CR_0898 End*/
		
		$scope.saveQuoteDBInputData();
		/*if (CommonServices.isLoggedIn === true) {
				$scope.saveQuoteDBInputData();
		}else{
				var modal = document.getElementById('myLoginModal');
				modal.style.display = "block";
		}*/

	};

	$scope.close = function () {
		var modal = document.getElementById('myLoginModal');
		modal.style.display = "none";
	}

	$scope.redirectToLoginScreen = function () {
		$state.go('loginPage');
	}

	$scope.calculatePremium = function (term) {//To Use

		term = parseInt(term);
		$rootScope.term1=term;//Added for CR_926
		var maxDate = CommonServices.systemDate.split(' ')[0];
		var arr = maxDate.split('/');
		var todaysDate = arr[0] + '/' + arr[1] + '/' + arr[2]; //mm/dd/yyyy
		var forComparingDateOfPurchaseReg = arr[1] + '/' + arr[0] + '/' + arr[2]; //dd/mm/yyyy
		var policyStartDate = arr[1] + '/' + arr[0] + '/' + arr[2]; //dd/mm/yyyy

		var addYears = function (todaysDate) {
			var dt = new Date(todaysDate);
			var newDate = new Date(dt.getFullYear() + term, dt.getMonth(), dt.getDate() - 1);
			var d = new Date(newDate || Date.now()),

				month = '' + (d.getMonth() + 1),
				day = '' + d.getDate(),
				year = d.getFullYear();

			if (month.length < 2) month = '0' + month;
			if (day.length < 2) day = '0' + day;

			return [day, month, year].join('/');
		}

		var policyExpiryDate = addYears(todaysDate);


		$rootScope.buyNow.twoWheeler.quickQuote.policyStartDate = policyStartDate;
		$rootScope.buyNow.twoWheeler.quickQuote.policyExpiryDate = policyExpiryDate;

		var getQuickQuoteDetailInputData =
			{
				"userProfile": {
					"userId": CommonServices.getCommonData("userId"),
					"loggedInRole": "SUPERUSER",
					"stakeCode": CommonServices.getCommonData("stakeCode")
				},
				"quote": {
					"vehicles": [
						{
							"vehicleDetails": {
								"drivers": [
									{
										"driverDetails": {

										}
									}
								],
								"make": $rootScope.buyNow.twoWheeler.quickQuote.make,
								"model": $rootScope.buyNow.twoWheeler.quickQuote.vehicleModel.motorModel,
								"variant": $rootScope.buyNow.twoWheeler.quickQuote.vehicleModel.motorVariant,
								"insuredsDeclaredValue": $rootScope.buyNow.twoWheeler.quickQuote.insuredDeclaredValue,
								"dateOfFirstPurchaseOfVehicle": $rootScope.buyNow.twoWheeler.quickQuote.dateOfPurchaseReg,
								"vehicleAgeInMonths": 0,
								"cityOfPurchase": $rootScope.buyNow.twoWheeler.quickQuote.vehicleCity,
								"cubicCapacity": $rootScope.buyNow.twoWheeler.quickQuote.vehicleModel.motorCC,
								"seatingCapacityIncludingDriver": $rootScope.buyNow.twoWheeler.quickQuote.vehicleModel.motorCarryingCapacity,
								"typeOfFuel": $rootScope.buyNow.twoWheeler.quickQuote.vehicleModel.motorFule,
								"wattage":$rootScope.buyNow.twoWheeler.quickQuote.vehicleModel.wattageInKW //CR_3633
							}
						}
					],
					"productCode": "SQ",
					"term": term,
					"mobileNo": $rootScope.buyNow.twoWheeler.quickQuote.mobileNumber,
					"emailId": $rootScope.buyNow.twoWheeler.quickQuote.emailID,
					"policyStartDate": $rootScope.buyNow.twoWheeler.quickQuote.policyStartDate,
					"policyExpiryDate": $rootScope.buyNow.twoWheeler.quickQuote.policyExpiryDate
				}
			};

		var getQuickQuoteResponse = RestServices.postService(RestServices.urlPathsNewPortal.getQuickQuoteDetail, getQuickQuoteDetailInputData);
		getQuickQuoteResponse.then(
			function (response) {
				if (response.data.errorCode == 960) {
					CommonServices.showAlert(response.data.errorMessage);
					CommonServices.showLoading(false);
				}
				if (response.data.errorCode == 959) {
					CommonServices.showAlert("Could not connect to server.Please try after some time", "Alert");
					CommonServices.showLoading(false);
				} else if (response.data.userProfile.footer.errorCode == 0) {
					$scope.changeTermFlag = true;
					GetSetResponseService.addQuickQuoteDetailResponseData(response.data);
					$(".twBasicPremiumDetails ul li").removeClass("twCoverageSelected");
					$scope.sqBasicPremiumCalScreenCtrl.onload();

				} else {
					CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
				}
				CommonServices.showLoading(false);
			}, function (error) {
				CommonServices.showLoading(false);
				RestServices.handleWebServiceError(error);
			});

	}

	$scope.saveQuoteDBInputData = function () {
		if ($rootScope.buyNow.twoWheeler.newVehicle === true) {
			$rootScope.buyNow.twoWheeler.newVehicle = "Y";
		} else if ($rootScope.buyNow.twoWheeler.newVehicle === false) {
			$rootScope.buyNow.twoWheeler.newVehicle = "N";
		}

		if (CommonServices.fromRAForEditQuote === true) {
			CommonServices.cover = true;
			$state.go('sqDetailQuote');
		} else if (CommonServices.SQParentPolicyHistory === true) { //CR_3621
			CommonServices.cover = true;
			$state.go('sqDetailQuote');
		} else {
			var saveQuoteDBInputData = {
				"quote": {
					"additionalQuoteDetails": {},
					"premiumDetails": {
						"totalPremium": $rootScope.buyNow.twoWheeler.basicPremium.totalPremium,
						"laibilityPremium": $rootScope.buyNow.twoWheeler.basicPremium.liabilityValue,
						"packagePremium": $rootScope.buyNow.twoWheeler.basicPremium.packageValue,
						"enhancementPremium": $rootScope.buyNow.twoWheeler.basicPremium.enhancementValue
					},
					"previousPolicyDetails": {},
					"vehicles": [
						{
							"vehicleDetails": {
								"ownerDetails": {},
								"financierDetails": {},
								"discountDetails": {},
								"trailerDetails": [],
								"additionalVehicleDetails": {},
								"nomineeDetails": {},
								"dateOfFirstPurchaseOfVehicle": $rootScope.buyNow.twoWheeler.quickQuote.dateOfPurchaseReg,
								"make": $rootScope.buyNow.twoWheeler.quickQuote.vehicleModel.motorMake,
								"model": $rootScope.buyNow.twoWheeler.quickQuote.vehicleModel.motorModel,
								"variant": $rootScope.buyNow.twoWheeler.quickQuote.vehicleModel.motorVariant,
								"newVehicle": $rootScope.buyNow.twoWheeler.newVehicle,
								"cityOfPurchase": $rootScope.buyNow.twoWheeler.quickQuote.vehicleCity === undefined ? "" : $rootScope.buyNow.twoWheeler.quickQuote.vehicleCity,
								"suggestedIDV": $rootScope.buyNow.twoWheeler.quickQuote.insuredDeclaredValue,
								"totalIDV": $rootScope.buyNow.twoWheeler.quickQuote.insuredDeclaredValue,
								"seatingCapacityIncludingDriver": $rootScope.buyNow.twoWheeler.quickQuote.vehicleModel.motorCarryingCapacity,
								"cubicCapacity": $rootScope.buyNow.twoWheeler.quickQuote.vehicleModel.motorCC,
								"typeOfFuel": $rootScope.buyNow.twoWheeler.quickQuote.vehicleModel.motorFule,
								"wattage":$rootScope.buyNow.twoWheeler.quickQuote.vehicleModel.wattageInKW, //CR_3633
								"yearOfManufacture": $rootScope.buyNow.twoWheeler.quickQuote.dateOfPurchaseReg.split('/')[2],
								"vehicleAgeInMonths": 0
							},
							"coverages": [
								{
									"coverageDetails": {
										"nomineeDetails": {},
										"coverage": $rootScope.buyNow.twoWheeler.basicPremium.twCoverageSelected
									},
									"additionalCoverageDetails": {
										"namesOfNamedPerson": [null]
									},
									"addOnEnhancementCoverages": {}
								}
							]
						}
					],
					"salesChannel": {
						"salesDiscounts": [{}]
					},
					"quoteNumber": $rootScope.buyNow.twoWheeler.basicPremium.quoteNumber,
					//"productCode": $rootScope.buyNow.twoWheeler.quickQuote.vehicleModel.motorProductCode,
					"productCode": "SQ",
					"emailId": $rootScope.buyNow.twoWheeler.quickQuote.emailID === undefined ? "" : $rootScope.buyNow.twoWheeler.quickQuote.emailID,
					"mobileNo": $rootScope.buyNow.twoWheeler.quickQuote.mobileNumber === undefined ? "" : $rootScope.buyNow.twoWheeler.quickQuote.mobileNumber,
					"progressLevel": "DQ"
				},
				"userProfile": {
					"userId": CommonServices.getCommonData("userId"),
					"loggedInRole": "SUPERUSER",
					"stakeCode": "POLICY-HOL"
				},
				"alfrescoInput": {
					"channel": "AGENT",
					"language": "English",
					//"productName": $rootScope.buyNow.twoWheeler.quickQuote.vehicleModel.motorProductCode
					"productName": "SQ"
				}
			};

			var saveQuoteDBResponse = RestServices.postService(RestServices.urlPathsNewPortal.saveTWQuoteDB, saveQuoteDBInputData);

			saveQuoteDBResponse.then(
				function (response) {
					/* CommonServices.cover = true;*/
					if ($rootScope.buyNow.twoWheeler.newVehicle === "Y") {
						$rootScope.buyNow.twoWheeler.newVehicle = true;
					} else {
						$rootScope.buyNow.twoWheeler.newVehicle = false;
					}

					/* if (CommonServices.isLoggedIn === false){
						   CommonServices.showLoading(false);
						   $scope.loginFromBasicPremium();        
					 }
					 else{*/
					CommonServices.showLoading(false);
					CommonServices.fromQuickQuote = true;
					$state.go('sqDetailQuote');
					//$scope.getCustomerDetails();
					//}
				}, function (error) {
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
				});
		}
	};




	$scope.getCustomerDetails = function () {

		$scope.getUserRelationDetailsSucess = false;
		var getUserRelationDetailsData = {
			"userProfile": {
				"userId": CommonServices.getCommonData("userId"),
				"loggedInRole": "SUPERUSER"
			},
			"partyDetails": {
				"individualDetails": {
					"relationshipWithRegisteredUser": "SELF",
					"title": "",
					"firstName": "",
					"middleName": "",
					"lastName": "",
					"gender": "",
					"dateOfBirth": "",
					"buildingNoStreet": "",
					"locality": "",
					"pinCode": "",
					"mobileNo": CommonServices.getCommonData("collectionDetails").mobileNum,
					"landlineNo": "",
					"emailId": CommonServices.getCommonData("collectionDetails").emailID,
					"eInsuranceAccountNo": "",
					"panNumber": "",
					"relationId": ""
				}
			}
		};
		var getUserRelationDetailsResponse = RestServices.postService(RestServices.urlPathsNewPortal.getUserRelationDetails, getUserRelationDetailsData);

		getUserRelationDetailsResponse.then(
			function (response) {
				CommonServices.showLoading(false);
				if (response.data.partyDetailsList !== undefined && response.data.partyDetailsList !== "") {
					$rootScope.partyStakeCode = response.data.partyDetailsList[0].partyStakeCode;
					$rootScope.custProfileRespData = response.data;
					$scope.getUserRelationDetailsSucess = true;
				}
				else {
					CommonServices.showAlert(response.data.footer.errorDescription);
				}


			}, function (error) {
				CommonServices.showLoading(false);
				RestServices.handleWebServiceError(error);
			}).finally(function () {

				if ($scope.getUserRelationDetailsSucess === true) {
					$scope.getUserRelationDetailsSucess = false;
					$state.go('sqDetailQuote');
				}
			});
	};
}]);

agentApp.controller('sqDetailQuoteScreenCtrl', ['$scope', '$rootScope', 'CommonServices', 'RestServices', 'GetSetResponseService', '$location', '$state', function ($scope, $rootScope, CommonServices, RestServices, GetSetResponseService, $location, $state) {

	$scope.isDiscountAvail = CommonServices.getCommonData("additionalDisc"); //CR 3868
if(CommonServices.SQParentPolicyHistory === true){
		$scope.SQfieldDisable = true;
	}else {
		$scope.SQfieldDisable = false;
 }		
//CR_0898 start
$scope.showFirstSliderSQ = true;
$scope.valueabc=false;
$scope.numberValidate=function(){
if($scope.buyNow.twoWheeler.enhancementCoverages.roadTaxAmount<=0){
$scope.valueabc=true;
}else{
$scope.valueabc=false;
}
}
//CR_0898 End

	var mydateStr = CommonServices.getCommonData("serverDate");
	$scope.regValidate = false;
	$scope.regexName = /^[a-zA-Z][a-zA-Z ]*$/;
	$scope.regexNameWithoutSpace = /^[a-zA-Z][a-zA-Z]*$/;
	$scope.regexAge = /^(?=.*[1-9])\d*$/;
	$scope.regexAlphaNum = /^[a-zA-Z0-9]+$/;
	$scope.regexPanNum = /^[A-Za-z]{5}[0-9]{4}[A-Za-z]{1}$/;
	$scope.regexEmail = /\b^[a-zA-Z0-9][a-zA-Z0-9._-]*@[a-zA-Z0-9-]+(\.[a-zA-Z]{2,4}){1,3}\b$/;
	$scope.regexMobNum = /^([56789])(?!\1+$)\d{9}$/;
	$scope.regexPinCode = /^[1-9][0-9]{5}$/;
	$scope.showncbDiv3 = false;
	$scope.showncbDiv4_5 = false;
	$scope.showaddCoversDiv3_4 = false;
	$scope.showaddCoversDiv9 = false;
	$scope.showaddCoversDiv16 = false;//CR_NP_0898
	$scope.isRenew = false;
	$scope.isStateSelected = false;
	$scope.isCitySelected = false;
	$scope.afterCreatePolicyHolder = false;
	$scope.isUNBSelected = false;
	$scope.regExpDate = '';
	$scope.alphaNumWidSpace = /^(?!\s*$|\s)[A-Za-z0-9 ]+$/; //validates alphanumeric with space
	$scope.nameOfPrevInsurerMandatory = true; //Added for production incident after CR_NP_0752
	/*  cr_np_941  Start*/
	if ($rootScope.policyMonthDiff > CommonServices.vehicleAgeCount.configurableDatas[0].value) //CR_NP_3561
	{
		$scope.DurationForPaOwnerDriverCoverTWDiv = false;
	}else {
	 $scope.DurationForPaOwnerDriverCoverTWDiv = true;
	}
	/*  cr_np_941  End*/
	

	$scope.agentModels = {
		subRelation: false,
		dealerRelationDetails: { "relationDetails": [], "relationList1": [], "relationList2": [] },
		count: 0,
		relationLabel: false,
		typeOfFuelTWVal: [],
		disPercError: false,
		disPercConfiguError: false,
		disAmtError: false,
		disAmtErrorPer:false,//CR_3588
		getRelationFunc: function (partyCode, detail) {

			var getDealerRelationsInput = { "userProfile": { "userId": CommonServices.getCommonData("userId"), "loggedInRole": "SUPERUSER" }, "partyDetails": { "partyCode": partyCode } };

			var getDealerRelationsResponse = RestServices.postService(RestServices.urlPathsNewPortal.getDealerRelations, getDealerRelationsInput);
			getDealerRelationsResponse.then(
				function (response) { //success

					CommonServices.showLoading(false);
					if (response.data.hasOwnProperty('errorMessage')) {
						//$scope.relationDetails =[$scope.agentModels.dealerRelationDetails.relationDetails[$scope.agentModels.selectedAgent]];
						$scope.relationDetails = [];
						if ($scope.agentModels.selectedAgent !== "")
							$scope.relationDetails.push($scope.agentModels.dealerRelationDetails.relationDetails[$scope.agentModels.selectedAgent]);
						if ($scope.agentModels.selectedAgentOne !== "")
							$scope.relationDetails.push($scope.agentModels.dealerRelationDetails.relationList1[$scope.agentModels.selectedAgentOne]);
						if ($scope.agentModels.selectedAgentTwo !== "")
							$scope.relationDetails.push($scope.agentModels.dealerRelationDetails.relationList2[$scope.agentModels.selectedAgentTwo]);

						$scope.agentModels.dealerRelationDetails = { "relationDetails": [], "relationList1": [], "relationList2": [] };
						$scope.agentModels.selectedAgent = "";
						$scope.agentModels.selectedAgentOne = "";
						$scope.agentModels.selectedAgentTwo = "";
						$scope.agentModels.subRelation = false;
						$scope.agentModels.relationLabel = false;
					} else {
						if (detail === "mainDetails") {
							$scope.agentModels.subRelation = true;
						}
						if (partyCode === "") {
							$scope.agentModels.dealerRelationDetails.relationDetails = response.data.partyDetailsList;
						}
						else {
							$scope.agentModels.dealerRelationDetails.relationList2 = [];
							for (var i = 0; i < response.data.partyDetailsList.length; i++) {

								if (detail === "mainDetails") {

									$scope.agentModels.subRelationTwo = false;
									$scope.agentModels.dealerRelationDetails.relationList1.push(response.data.partyDetailsList[i]);
								}
								if (detail === "subDetails") {
									$scope.agentModels.subRelationTwo = true;
									$scope.agentModels.dealerRelationDetails.relationList2.push(response.data.partyDetailsList[i]);
								}

							}

						}

					}

				},
				function (error) { //failure
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
				}
			);
		},
		editDealer: function () {
			this.getRelationFunc("");
			this.relationLabel = true;
		},
		selectRelation: function (data, detail) {

			if (detail === "mainDetails") {
				this.getRelationFunc(data.partyCode, detail);
			}
			if (detail === "subDetails") {

				if (data.partyCode.indexOf("SI") === -1) {
					this.getRelationFunc(data.partyCode, detail);
				}

			}

		},
		cleanDealerRelation: function () {
			this.subRelation = false;
			this.dealerRelationDetails = { "relationDetails": [], "relationList1": [], "relationList2": [] };
			this.selectedAgent = "";
			this.selectedAgentOne = "";
			this.selectedAgentTwo = "";
			this.relationLabel = false;
		},
		subRelationBtnClick: function (value) {
			if (value === "back") {
				this.cleanDealerRelation();
			}
			if (value === "save") {
				$scope.relationDetails = [];
				if (this.selectedAgent !== "")
					$scope.relationDetails.push(this.dealerRelationDetails.relationDetails[this.selectedAgent]);
				if (this.selectedAgentOne !== "")
					$scope.relationDetails.push(this.dealerRelationDetails.relationList1[this.selectedAgentOne]);
				if (this.selectedAgentTwo !== "")
					$scope.relationDetails.push(this.dealerRelationDetails.relationList2[this.selectedAgentTwo]);

				this.cleanDealerRelation();

			}
		},
		discountPerFunc: function (val) {

			if (parseInt(val) > 100) {
				this.disPercError = true;
				$scope.detailQuoteTWScreenForm.$invalid = true;
			} else {
				this.disPercError = false;
				$scope.detailQuoteTWScreenForm.$invalid = false;
			}

			if (parseInt(val) > parseInt($scope.buyNow.twoWheeler.quickQuote.discountPercentage)) {
				this.disPercConfiguError = true;
				$scope.detailQuoteTWScreenForm.$invalid = true;
			} else {
				this.disPercConfiguError = false;
				$scope.detailQuoteTWScreenForm.$invalid = false;
			}

		},
		prePolicyExpiDateFunc: function (data) {

			var validDate = data; // For  Year of Manufacture dropdown			
			var arr = validDate.split('/');
			var validDate = arr[1] + '/' + arr[0] + '/' + arr[2]; //mm/dd/yyyy
			data = new Date(validDate);
			var minDate = new Date(data.setFullYear(data.getFullYear()));
			minDate = new Date(minDate.setDate(minDate.getDate() + 1));
			minDate = getFormattedDate(minDate);
			var finalDate = minDate.split('/');
			finalDate = finalDate[1] + '/' + finalDate[0] + '/' + finalDate[2]; //mm/dd/yyyy
			var loginDate1 = CommonServices.getCommonData('LoginData').systemDate;
			$scope.loginDate = new Date(loginDate1);

			if ($scope.loginDate <= data) {
				$rootScope.buyNow.twoWheeler.additionalDetails.polStartDateTW = finalDate;
			}

		},
		disAmtFunc: function (data) {
			if (data < -50) {
				this.disAmtError = true;
				$scope.detailQuoteTWScreenForm.$invalid = true;
			} else {
				this.disAmtError = false;
				$scope.detailQuoteTWScreenForm.$invalid = false;
			}
		}
	};
/*	start CR_3588*/
	$scope.distAmtContinue=function () {
		var amtDiff=parseFloat($scope.buyNow.twoWheeler.additionalDetails.loadingDiscountPercModel)+parseFloat($scope.buyNow.twoWheeler.additionalDetails.discountPercModel);
		if(amtDiff> ($scope.buyNow.twoWheeler.quickQuote.discountPercentage)){
			this.disAmtErrorPer = true;
			CommonServices.showAlert("Discount percentage and loading/discount amount of OD cannot be greater than configured discount percentage.");
			$scope.detailQuoteTWScreenForm.$invalid = true;		
			}
		 else {
				this.disAmtErrorPer = false;
				$scope.detailQuoteTWScreenForm.$invalid = false;
			}
	};
	/*	end CR_3588*/
	var selectedStateNB = '';
	var selectedCityNB = '';
	var selectedState = '';
	var selectedCity = '';

	$scope.newVehicle = $rootScope.buyNow.twoWheeler.newVehicle;
	/*$scope.newVehicle = false;*/
	if ($scope.newVehicle === true) {
		$scope.isRenew = false;
	} else {
		$scope.isRenew = true;
	}

	/* for tab ----------------------*/
	$scope.sqDetailQuoteScreenCtrl = {
		onload: function () {
			if (CommonServices.makeWatch === true) {
				$rootScope.buyNow.twoWheeler.additionalDetails.yrOfManufactureTW = "";
				$rootScope.buyNow.twoWheeler.additionalDetails.engineNumTW = "";
				$rootScope.buyNow.twoWheeler.additionalDetails.chassisNumTW = "";
				$rootScope.buyNow.twoWheeler.additionalDetails.vehZoneTW = "";
				$rootScope.buyNow.twoWheeler.additionalDetails.clrRCBookTW = "";
				$rootScope.buyNow.twoWheeler.additionalDetails.typeOfFuelTW = "";

				$rootScope.buyNow.twoWheeler.insuredDetails = {};
				CommonServices.makeWatch = false;
			}

			$scope.occpDataArray = [];
			for (var i = 0; i < CommonServices.productDomainValues.productDomainValues.length; i++) {
				if (CommonServices.productDomainValues.productDomainValues[i].domainValues.codeId === "VEHICLE_COLOR") {
					$scope.productDomainValues = CommonServices.productDomainValues.productDomainValues[i];
					$scope.occpDataArray.push($scope.productDomainValues);
				}
				if (CommonServices.productDomainValues.productDomainValues[i].domainValues.codeId === "FUEL_TYPE") {

					$scope.agentModels.typeOfFuelTWVal.push(CommonServices.productDomainValues.productDomainValues[i]);
				}

			}

			if (CommonServices.getCommonData("stakeCode") === "DEVLP-OFF" || CommonServices.getCommonData("stakeCode") === "DEALER") { // If login user is development officer and dealer
				$scope.notAgent = true;
				//Relation Details Starts	
				if (CommonServices.getCommonData("stakeCode") === "DEVLP-OFF") { // If Login user is Development Off this service has to be called
					$scope.developmentOff = true;
					$scope.getRelatedAgentDetails = function () {
						var getAgentListInput = {
							"userProfile": {
								"userId": CommonServices.getCommonData("userId"),
								"loggedInRole": "SUPERUSER"
							},
							partyDetails: {
								partyType: "I"
							}
						};

						var getAgentListResponse = RestServices.postService(RestServices.urlPathsNewPortal.getAgentList, getAgentListInput);
						getAgentListResponse.then(
							function (response) { //success

								CommonServices.showLoading(false);
								if (response.data.hasOwnProperty('errorMessage')) {
									CommonServices.showLoading(false);
									CommonServices.showAlert(response.data.errorMessage);
								} else {
									$scope.relationDetails = response.data.partyDetailsList;
									if ($rootScope.buyNow.twoWheeler.relationDetails !== undefined && $rootScope.buyNow.twoWheeler.relationDetails !== "") {
										for (var i = 0; i < $scope.relationDetails.length; i++) {
											if ($scope.relationDetails[i].partyCode === $rootScope.buyNow.twoWheeler.relationDetails.partyCode) {
												$scope.agentModels.selectedAgent = i;
											}
										}
									}

								}

							},
							function (error) { //failure
								CommonServices.showLoading(false);
								RestServices.handleWebServiceError(error);
							}
						);
					};
				}
        /* added for CR_NP_754 */
				else { // If Login user is Dealer dealer list will be taken from getDefaultRelation
					$scope.dealerRelation = true;
					var relation = "";
					if (CommonServices.editQuoteFlag === true) {
						relation = CommonServices.floaterObj.partyDetailsList;
					} else {
						relation = CommonServices.getCommonData("defaultRelationResponse");
					}

					$scope.relationDetails = [];
					for (var i = 0; i < relation.length; i++) {
						if (relation[i].partyCode.trim() !== undefined && relation[i].partyCode.trim() !== "") {
							if (CommonServices.getCommonData("channel") === "MISP") {
								$scope.mispEditRelation = false;
								if (relation[i].partyStakeCode !== "DEALER" && relation[i].partyStakeCode !== "DSG-PERSON") {
									$scope.relationDetails.push(relation[i]);
								}
							} else {
								$scope.mispEditRelation = true;
								if (CommonServices.editQuoteFlag === true) {
									if (relation[i].partyStakeCode !== "POLICY-HOL" && relation[i].partyStakeCode !== "DEALER" && relation[i].partyStakeCode !== "GSS" && relation[i].partyStakeCode !== "GCE" && relation[i].partyStakeCode !== "DSG-PERSON") {
										$scope.relationDetails.push(relation[i]);
									}
								}
								else {
							$scope.relationDetails.push(relation[i]);
						}
					}
				}
			}
				}
			}
      
      /*CR_NP_754 ends */
			else { // If login user is Agent
				$scope.notAgent = false;
			}

			$scope.buyNow.twoWheeler.ncbDetails.ncbOnPrevPolicyTW = false;
			$scope.buyNow.twoWheeler.addCovers.ownerDriveVehOrNotTW = false;
			$scope.buyNow.twoWheeler.addCovers.paCoverForUnnamedPersonTW = false;
			$scope.buyNow.twoWheeler.addCovers.extensionOfGeographicalAreaRequired = false;

			$scope.isStateSelected = true;
			$scope.isCitySelected = true;


			/* default and hidden fields from view ----------------------*/
			$scope.buyNow.twoWheeler.addCovers.indSIforUnnamedPerson = null;
			$scope.buyNow.twoWheeler.insuredDetails.relnWithRegUser = 'SELF';

			/* default and hidden fields from view ----------------------*/
			// $scope.showFirstSlider = true;
			// setTimeout(function () {
			// 	$('.gallery').flickity({
			// 		cellAlign: 'left',
			// 		contain: true,
			// 		draggable: false
			// 	});

			// }, 1000);
			// $carousel = $('.gallery').flickity({
			// 	cellAlign: 'left',
			// 	contain: true,
			// 	draggable: false,
			// 	prevNextButtons: false,
			// 	pageDots: false
			// });

			// /* /*$scope.detailedQuoteHeaderText = "Vehicle Details";
			// $("#detQuoteHeader").text("Vehicle Details");      */
			// $scope.sliderNext = function () {
			// 	$carousel.flickity('next');
			// }
			
			
			$scope.sliderNext = function (key) {
				$scope.showFirstSliderSQ = false;
				$scope.showSecondSliderSQ = false;
				$scope.showThirdSliderSQ = false;
				if (key === 'first') $scope.showSecondSliderSQ = true;
				if (key === 'second') $scope.showThirdSliderSQ = true;
			}

			/* /*$scope.detailedQuoteHeaderText = "Vehicle Details";
			$("#detQuoteHeader").text("Vehicle Details");      */

			if ($rootScope.buyNow.twoWheeler.additionalDetails.colorOfvehicle !== undefined && $rootScope.buyNow.twoWheeler.additionalDetails.colorOfvehicle !== "") {
				$scope.vehicleColor = $rootScope.buyNow.twoWheeler.additionalDetails.colorOfvehicle;
			}
			if ($rootScope.buyNow.twoWheeler.additionalDetails.typeOfFuelTW !== undefined && $rootScope.buyNow.twoWheeler.additionalDetails.typeOfFuelTW !== "") {
				$scope.typeOfSelectedFuel = $rootScope.buyNow.twoWheeler.additionalDetails.typeOfFuelTW;
			}
			/*Added after CR_NP_0752 prod deployment,because NIA wanted Name of Previous insurer as NOn Mandatory for liability cover */
			if ($rootScope.buyNow.twoWheeler.newVehicle === false && $rootScope.buyNow.twoWheeler.basicPremium.twCoverageSelected === "LIABILITY") {
				$scope.nameOfPrevInsurerMandatory = false;
			}
			/*after CR_NP_0752 changes ends */
			
		}
	};

	$scope.sqDetailQuoteScreenCtrl.onload();
	if (CommonServices.getCommonData("stakeCode") === "DEVLP-OFF") { // If Login User is Development Officer 
		if ($rootScope.buyNow.twoWheeler.isAgentRequired !== undefined && $rootScope.buyNow.twoWheeler.isAgentRequired !== "") {
			if ($rootScope.buyNow.twoWheeler.isAgentRequired === "yes") {
				$scope.agentModels.relationDetailsRadio = "yes";
				$scope.getRelatedAgentDetails();
			}
			else {
				$scope.agentModels.relationDetailsRadio = "no";
			}
		}
		else {
			$scope.agentModels.relationDetailsRadio = "no";
		}
	}
	if (CommonServices.getCommonData("stakeCode") === "DEALER") {  // If Login User is Dealer

	}

	var maxDateDateOfRegDqTW = CommonServices.getCommonData("serverDate"), //mm/dd/yyyy

		maxDateDateOfRegDqTW = new Date(maxDateDateOfRegDqTW);

	var minDateDateOfRegDqTW = $rootScope.buyNow.twoWheeler.quickQuote.dateOfPurchaseReg; //mm/dd/yyyy 
	arr = minDateDateOfRegDqTW.split('/');
	minDateDateOfRegDqTW = arr[1] + '/' + arr[0] + '/' + arr[2];
	minDateDateOfRegDqTW = new Date(minDateDateOfRegDqTW);


	$('#dateOfRegDqTW').loadCalendar({
		'enableDateRange': true,
		'enableCalendarFrom': minDateDateOfRegDqTW,
		'enableCalendarTo': maxDateDateOfRegDqTW
	});

	$scope.calIconClick = function (event) {
		angular.element("#" + event.currentTarget.children[0].id).focus();
	};
	/****************validation for vehicle reg****************/

	$scope.stateCodetrue = false;
	$scope.biFuelRs = true;
	$scope.loginSystemDate = CommonServices.getCommonData('LoginData');//Need to uncomment. Coming from Service
	//$scope.loginSystemDate={"systemDate":"07/27/2017"}; //Need to remove. Hardcoded

	if ($rootScope.buyNow.twoWheeler.newVehicle == true) {
		var validDate = $scope.loginSystemDate.systemDate;
		var arr = validDate.split('/');
		var validDate = arr[1] + '/' + arr[0] + '/' + arr[2]; //mm/dd/yyyy
		var currentYear = arr[2].toString();
		var previousYear1 = arr[2] - 1;
		var previousYear = previousYear1.toString();
	}
	else {
		var validDate = $rootScope.buyNow.twoWheeler.quickQuote.dateOfPurchaseReg; // For  Year of Manufacture dropdown
		var arr = validDate.split('/');
		var validDate = arr[1] + '/' + arr[0] + '/' + arr[2]; //mm/dd/yyyy
		var currentYear = arr[2].toString();
		var previousYear1 = arr[2] - 1;
		var previousYear = previousYear1.toString();
	}

	if ($scope.buyNow.twoWheeler.additionalDetails.valOfBiFuelSysTW === undefined || $scope.buyNow.twoWheeler.additionalDetails.valOfBiFuelSysTW === '') {
		$scope.buyNow.twoWheeler.additionalDetails.valOfBiFuelSysTW = 0;
	}

	$scope.showBiFuelSys = function () {
		if ($scope.buyNow.twoWheeler.additionalDetails.typeOfFuelTW === 'CNG Diesel' || $scope.buyNow.twoWheeler.additionalDetails.typeOfFuelTW === 'CNG Petrol' || $scope.buyNow.twoWheeler.additionalDetails.typeOfFuelTW === 'LPG Diesel' || $scope.buyNow.twoWheeler.additionalDetails.typeOfFuelTW === 'LPG Petrol') {
			$scope.buyNow.twoWheeler.additionalDetails.inbuiltBiFuelSysTW = 'No';
			$scope.valOfBiFuelSys = true;
			$scope.buyNow.twoWheeler.additionalDetails.valOfBiFuelSysTW = 0;
		} 
		/*	CR_3633 start*/
	  else if($scope.buyNow.twoWheeler.additionalDetails.typeOfFuelTW === 'BATTERY'){
		  $scope.buyNow.twoWheeler.additionalDetails.wattageInKW = '';
		}
		/*	CR_3633 end*/
		else {
			$scope.valOfBiFuelSys = false;
			$scope.buyNow.twoWheeler.additionalDetails.valOfBiFuelSysTW = 0;
		}
	}

	$scope.showValOfBiFuelSys = function () {
		if ($scope.buyNow.twoWheeler.additionalDetails.inbuiltBiFuelSysTW === 'No') {
			$scope.valOfBiFuelSys = true;
		} else {
			$scope.valOfBiFuelSys = false;
			$scope.buyNow.twoWheeler.additionalDetails.valOfBiFuelSysTW = 0;
		}
	}
    /*CR_3633 start*/
	$scope.fuelTypeOfBattery= function () {
    		if ($scope.buyNow.twoWheeler.additionalDetails.wattageInKW === "" || $scope.buyNow.twoWheeler.additionalDetails.wattageInKW === "0") {
			this.wattageInKWerror = true;
    			CommonServices.showAlert("Please provide the non-zero value in wattage in KW for 'Type of fuel'chosen as 'Battery'");
    			$scope.detailQuoteTWScreenForm.$invalid = true;
		} else {
			this.wattageInKWerror = false;
    			$scope.detailQuoteTWScreenForm.$invalid = false;
		}
	}
    /*CR_3633 start*/
	//Registration Date on Change

	$scope.passportExpiryFunc = function (date) {
		$scope.todaysDate = mydateStr;
		var validDate = $scope.todaysDate,
			arr = validDate.split('/');
		validDate = arr[1] + '/' + arr[0] + '/' + arr[2];

		var selDt = angular.copy(date);
		var selDtArr = selDt.split('/');
		var dt1 = new Date(selDtArr[1] + '/' + selDtArr[0] + '/' + selDtArr[2]);
		var dt2 = new Date(mydateStr);

		if (dt1 > dt2) {
			$scope.regDateError = true;
			$scope.detailQuoteTWScreenForm.$invalid = true;
			return false;
		}
		else {
			$scope.regDateError = false;
			$scope.detailQuoteTWScreenForm.$invalid = false;
		}
	}

	// policy start and end date  
	if (CommonServices.fromRAForEditQuote === true) {
		$scope.buyNow.twoWheeler.additionalDetails.polStartDateTW = $rootScope.buyNow.twoWheeler.additionalDetails.policyStartDate;
		$scope.buyNow.twoWheeler.additionalDetails.polEndDateTW = $rootScope.buyNow.twoWheeler.additionalDetails.policyExpiryDate;
	} else {
		$scope.buyNow.twoWheeler.additionalDetails.polStartDateTW = $rootScope.buyNow.twoWheeler.quickQuote.policyStartDate;
		$scope.buyNow.twoWheeler.additionalDetails.polEndDateTW = $rootScope.buyNow.twoWheeler.quickQuote.policyExpiryDate;
	}

	//1.Auto populated and non-editable 2.Hide if liability=Yes
	if (CommonServices.fromRAForEditQuote === true) {
		$scope.buyNow.twoWheeler.additionalDetails.vehInVoiceValTW = $rootScope.collectPremRecentActivities.quote.vehicles[0].vehicleDetails.vehicleInvoiceValue;

	} else {
		$scope.buyNow.twoWheeler.additionalDetails.vehInVoiceValTW = $rootScope.buyNow.twoWheeler.quickQuote.motorInvoice;
	}


	//Hidden from screen and defaulted to value 'Other Color'
	$scope.buyNow.twoWheeler.additionalDetails.colorOfvehicle = "OTHER";
	$scope.buyNow.twoWheeler.additionalDetails.polExcessTW = "100";

	if ($rootScope.buyNow.twoWheeler.newVehicle == true) {

		$scope.showVehRegDiv = false;
		$scope.options = [{ name: currentYear, id: currentYear }, { name: previousYear, id: previousYear }];

	} else {

		$scope.showVehRegDiv = true;
		$scope.showInputs = "renew";

		$scope.vehicle1FocusOut = function () {

			var validStateCode = $scope.buyNow.twoWheeler.additionalDetails.reg1TW;
			var statecode = validStateCode.substring(0, 2).toUpperCase();
			var newStateCodeData = {
				"stateCode": statecode
			};
			
			CommonServices.showLoading(true);

			var StateCodeResponse = RestServices.postService(RestServices.urlPathsNewPortal.stateCode, newStateCodeData);

			StateCodeResponse.then(function (response) {
				CommonServices.showLoading(false);
				if (response.data.footer.errorDescription == "State code is not valid") {
					$scope.reg1ErrorMsg = 'Please enter a valid state code in Reg1';
					$scope.stateCodetrue = true;
				} else {
					$scope.stateCodetrue = false;
				}
			});


		};

		// $scope.vehicle4FocusOut = function () {
		// 	var validregNumber = $scope.buyNow.twoWheeler.additionalDetails.reg4TW;
		// }
		$scope.vehReg4Length = function (){
			//var validreg4 = buyNow.twoWheeler.additionalDetails.reg4TW;
			if ($scope.buyNow.twoWheeler.additionalDetails.reg4TW == undefined || $scope.buyNow.twoWheeler.additionalDetails.reg4TW.trim() == ''){
			$scope.regValidate = true;
			$scope.reg4ErrorMsg = 'This is a mandatory field';
			}else if ($scope.buyNow.twoWheeler.additionalDetails.reg4TW !== undefined || $scope.buyNow.twoWheeler.additionalDetails.reg4TW.trim() !== ''){
				$scope.regValidate = false;
			}
		};

		
		$scope.vehReg1Length = function () {
			if ($scope.buyNow.twoWheeler.additionalDetails.reg1TW !== undefined) {
				if ($scope.buyNow.twoWheeler.additionalDetails.reg1TW.length >= 3) {
					$scope.buyNow.twoWheeler.additionalDetails.reg2TW = "";
					$scope.buyNow.twoWheeler.additionalDetails.reg3TW = "";
					return false;
				}else if ($scope.buyNow.twoWheeler.additionalDetails.reg1TW.length <= 1) {
					$scope.vehLength = true;
				}else{
					$scope.vehLength = false;
				}
					return false;
				}
			};
			$scope.vehReg1Length = function () {
				$scope.stateCodetrue = false;
				if ($scope.buyNow.twoWheeler.additionalDetails.reg1TW == undefined || $scope.buyNow.twoWheeler.additionalDetails.reg1TW.trim() == '') {
					$scope.reg1ErrorMsg = 'This is a  mandatory field';
					$scope.stateCodetrue = true;
	
				} else if ($scope.buyNow.twoWheeler.additionalDetails.reg1TW !== undefined) {
					var validStateCode = $scope.buyNow.twoWheeler.additionalDetails.reg1TW;
					if (validStateCode.length < 2) {
						$scope.reg1ErrorMsg = 'Needs to be at least 2 characters long';
						$scope.stateCodetrue = true;
						
					} else if (validStateCode.length >= 3) {
						$scope.buyNow.twoWheeler.additionalDetails.reg2TW = "";
						$scope.buyNow.twoWheeler.additionalDetails.reg3TW = "";
						
					}
				}
			}	

		$scope.options = [{ name: arr[2], id: 1 }, { name: (arr[2] - 1).toString(), id: 2 }, { name: (arr[2] - 2).toString(), id: 3 }, { name: (arr[2] - 3).toString(), id: 4 }, { name: (arr[2] - 4).toString(), id: 5 }, { name: (arr[2] - 5).toString(), id: 6 }, { name: (arr[2] - 6).toString(), id: 7 }, { name: (arr[2] - 7).toString(), id: 8 }, { name: (arr[2] - 8).toString(), id: 9 }, { name: (arr[2] - 9).toString(), id: 10 }, { name: (arr[2] - 10).toString(), id: 11 }, { name: (arr[2] - 11).toString(), id: 12 }, { name: (arr[2] - 12).toString(), id: 13 }, { name: (arr[2] - 13).toString(), id: 14 }, { name: (arr[2] - 14).toString(), id: 15 }, { name: (arr[2] - 15).toString(), id: 16 }];

	};

	if (CommonServices.fromRAForEditQuote === true) {

		if ($scope.coverage === "LIABILITY" || $scope.coverage === "L") {
			$scope.coverageTW = "L";
		} else if ($scope.coverage === "PACKAGE" || $scope.coverage === "P") {
			$scope.coverageTW = "P";
		} else {
			$scope.coverageTW = "E";
		}
	} else {
		$scope.coverageTW = $rootScope.buyNow.twoWheeler.basicPremium.coverage;
	}

	/*$scope.coverageTW = "P";*/
	if ($scope.coverageTW === "L") {
		var myEl = angular.element(document.querySelector('.addCoverslist'));
		myEl.removeAttr('style');
		$scope.buyNow.twoWheeler.ncbDetails.ncbOnPrevPolicyTW = undefined;
	}

	$scope.showNcbDiv3 = function () {
		if ($scope.buyNow.twoWheeler.ncbDetails.ncbOnPrevPolicyTW === true) {
			CommonServices.showAlert("Dear Customer, In case the declaration regarding the NCB on previous insurance details made by you, is found to be incorrect, any claim for the policy would not be admitted.");
			/*$(".ncbDiv3").css('display', 'block');*/
			$scope.showncbDiv3 = true;
			$scope.buyNow.twoWheeler.ncbDetails.ncbPercOnPrevPolicyTW = $("#ncbPercOnPrevPolicyTW option:first").val();
		} else {
			$scope.showncbDiv3 = false;
			$scope.showncbDiv4_5 = false;
			$scope.buyNow.twoWheeler.prevPolicyDetails.nameOfPrevIns = undefined;
			$scope.buyNow.twoWheeler.prevPolicyDetails.prevPolNum = undefined;
			$scope.buyNow.twoWheeler.prevPolicyDetails.prevPolExpDate = undefined;
		}
	}
		/*NP_CR_3444 Start*/
$scope.showDisclaimerDivTW=function(){
	if($scope.buyNow.twoWheeler.addCovers.compulsoryPACoverPolicy === "YES" || $scope.buyNow.twoWheeler.addCovers.sumInsuredOfAtleast15lacs === "YES"){/*Remove buyNow.twoWheeler.addCovers.paCoverForAnyOtherVehicle === "YES" for CR_3444B*/
	$scope.showDisclaimerDivTW1 = true;
	$scope.DurationForPaOwnerDriverCoverTWDiv = false;
	$scope.buyNow.twoWheeler.addCovers.sumInsForOwnerDriver = 0;
	
  }else if($scope.buyNow.twoWheeler.addCovers.compulsoryPACoverPolicy === "NO" && $scope.buyNow.twoWheeler.addCovers.sumInsuredOfAtleast15lacs === "NO") {/*Remove buyNow.twoWheeler.addCovers.paCoverForAnyOtherVehicle === "NO" for CR_3444B*/
  $scope.DurationForPaOwnerDriverCoverTWDiv = true;
  $scope.showDisclaimerDivTW1 = false;
  $scope.buyNow.twoWheeler.addCovers.sumInsForOwnerDriver = 1500000;
  }
  else {
  $scope.showDisclaimerDivTW1 = false;
  $scope.DurationForPaOwnerDriverCoverTWDiv = false;
  }
}
	/*NP_CR_3444 End */
	/*	CR_NP_0898 start*/
	var selectedCoverageTW=$rootScope.buyNow.twoWheeler.basicPremium.coverage;
	$scope.showAddCoversDiv16 = function () {
	if($scope.buyNow.twoWheeler.addCovers.extensionOfGeographicalAreaRequired=== true){
	  if(selectedCoverageTW=='L'||selectedCoverageTW=='P'){
	$scope.showaddCoversDiv16 = true;
	}else if(selectedCoverageTW=='E'||selectedCoverageTW=='E5')
	{
	$scope.showaddCoversDiv16 = false;
	CommonServices.showAlert(" No Geographical extension is allowed for enhancement cover.");
	$scope.buyNow.twoWheeler.addCovers.extensionOfGeographicalAreaRequired=false;
	}
	}else {
	$scope.showaddCoversDiv16 = false;
	}
	
	}
	
		/*CR_NP_0898 End*/


	// $scope.goBack = function () {

	// 	if (CommonServices.fromRAForEditQuote === true) {
	// 		//navigator.notification.confirm("Are you sure you want to navigate back to premiums screen ? All the saved data will be lost", navigateBack, "Alert", ["Ok", "Cancel"]); 
	// 		navigateBack(1);
	// 	} else {
	// 		$state.go('sqBasicPremiumCal');
	// 	}
	// };
			$scope.goBack = function (type='') {
				$scope.showFirstSliderSQ = false;
				$scope.showSecondSliderSQ = false;
				$scope.showThirdSliderSQ = false;
						
				if (type == 'adBack2') {
					$scope.showFirstSliderSQ = true;
				} else if (type == 'adBack3') {
					$scope.showSecondSliderSQ = true;
				/* } else if (type == 'adBack4') {
					$carousel.flickity('previous'); */
				} else {
					if (CommonServices.fromRAForEditQuote === true) {
						//navigator.notification.confirm("Are you sure you want to navigate back to premiums screen ? All the saved data will be lost", navigateBack, "Alert", ["Ok", "Cancel"]); 
						navigateBack(1);
					} else {
						$state.go('sqBasicPremiumCal');
					}
				}
			};


	var stateInputMin = 3;
	$scope.buyNow.twoWheeler.insuredDetails.polHolderState = '';
	$scope.result = '';
	$scope.stateList = '';
	$scope.cityList = '';
	$scope.allZipCodeList = '';



	$scope.startsWith = function (state, viewValue) {
		return state.substr(0, viewValue.length).toLowerCase() == viewValue.toLowerCase();
	}


	$scope.home = function () {
		navigator.notification.confirm("Are you sure you want to navigate back to home screen ? All the entered data will be lost", navigateToHomeScreen, "Alert", ["Ok", "Cancel"]);
	};

	$scope.validateInputs = function () {
		/*if($scope.buyNow.twoWheeler.insuredDetails.gstRegIdType == '' || $scope.buyNow.twoWheeler.insuredDetails.gstRegIdType == undefined){
			$scope.buyNow.twoWheeler.insuredDetails.gstin = undefined;
		} */
		if ($scope.buyNow.twoWheeler.insuredDetails.gstRegIdType === 'UNB') {
			$scope.isUNBSelected = true;
		} else {
			$scope.isUNBSelected = false;
		}
	}

	if ($scope.buyNow.twoWheeler.insuredDetails.gstRegIdType === 'UNB' || $scope.buyNow.twoWheeler.insuredDetails.gstRegIdType === 'UN Bodies/Embassy') {
		$scope.isUNBSelected = true;
	} else {
		$scope.isUNBSelected = false;
	}

	function navigateToHomeScreen(button) {

		if (button == 1) {
			$rootScope.buyNow.twoWheeler.newVehicle = "";
			$rootScope.buyNow.twoWheeler.quickQuote = {};
			$rootScope.buyNow.twoWheeler.basicPremium = {};
			$rootScope.buyNow.twoWheeler.additionalDetails = {};
			$rootScope.buyNow.twoWheeler.ncbDetails = {};
			$rootScope.buyNow.twoWheeler.addCovers = {};
			$rootScope.buyNow.twoWheeler.prevPolicyDetails = {};
			$rootScope.buyNow.twoWheeler.financierDetails = {};
			$rootScope.buyNow.twoWheeler.insuredDetails = {};
			$rootScope.buyNow.twoWheeler.summaryDetails = {};
			$rootScope.buyNow.twoWheeler.enhancementCoverages = {};//Added for NP_CR_0898

			CommonServices.fromRAForEditQuote = false;
			CommonServices.SQParentPolicyHistory = false;
			$scope.SQfieldDisable = false;
			$state.go("home");
		}
	}

	$scope.vehDetailsProceed = function () {
		CommonServices.goBack();
	};

	$scope.showNcbDiv4_5 = function () {
		$scope.showncbDiv4_5 = true;
		$scope.buyNow.twoWheeler.ncbDetails.ncbClaimStatusTW = true;
		$scope.buyNow.twoWheeler.ncbDetails.ncbApplicablePerc = '0%';
		if ($scope.buyNow.twoWheeler.ncbDetails.ncbPercOnPrevPolicyTW === undefined) {
			$scope.showncbDiv4_5 = false;
		}

	};

	if (CommonServices.fromRAForEditQuote === true) {
		/*if($rootScope.collectPremRecentActivities.quote.vehicles[0].vehicleDetails.newVehicle != "Y"){*/
		var curDate = GetSetResponseService.getloginResponseData()[0].systemDate;
		var time = new Date(curDate);
		time = time.setDate(time.getDate() + 30);
		var timeVar = new Date(time);
		var maxDateLim = (timeVar.getMonth() + 1) + '/' + timeVar.getDate() + '/' + timeVar.getFullYear(); //mm/dd/yyyy
		/*var dateFirstPurchase = $rootScope.collectPremRecentActivities.quote.vehicles[0].vehicleDetails.dateOfFirstPurchaseOfVehicle;*/
		var dateFirstPurchase = $rootScope.buyNow.twoWheeler.quickQuote.dateOfPurchaseReg;
		var minFormatArr = dateFirstPurchase.split("/");
		var minDateLim = minFormatArr[1] + '/' + minFormatArr[0] + '/' + minFormatArr[2];

		$('#prevPolicyDetailsTWPrevPolExpDate').loadCalendar({
			'enableDateRange': true,
			'enableCalendarFrom': minDateLim,
			'enableCalendarTo': maxDateLim
		});
		/* }*/
	} else {

		var curDate = CommonServices.getCommonData('LoginData').systemDate;
		var time = new Date(curDate);
		//if($rootScope.buyNow.twoWheeler.newVehicle === true){// need to uncomment during Break in
		time = time.setDate(time.getDate() + 29);
		var timeVar = new Date(time);
		var maxDateLim = (timeVar.getMonth() + 1) + '/' + timeVar.getDate() + '/' + timeVar.getFullYear(); //mm/dd/yyyy
		var dateFirstPurchase = $rootScope.buyNow.twoWheeler.quickQuote.dateOfPurchaseReg;
		var minFormatArr = dateFirstPurchase.split("/");

		minFormatArr[0] = parseInt(minFormatArr[0]);
		var minDateLim = minFormatArr[1] + '/' + minFormatArr[0] + '/' + minFormatArr[2];

		$('#prevPolicyDetailsTWPrevPolExpDate').loadCalendar({
			'enableDateRange': true,
			'enableCalendarFrom': minDateLim,
			'enableCalendarTo': maxDateLim
		});
		//}
		/*else if($rootScope.buyNow.twoWheeler.newVehicle === false){ // need to uncomment during Break in
			time = time.setDate(time.getDate()+28);
			var timeVar = new Date(time);
			var maxDateLim = (timeVar.getMonth() + 1) + '/' + timeVar.getDate() + '/' +  timeVar.getFullYear(); //mm/dd/yyyy

			var currDate = CommonServices.getCommonData('LoginData').systemDate;
			var time1 = new Date(currDate);
			time1 = time1.setDate(time1.getDate() -90);
			var timeVar1 = new Date(time1);

			var minDateLim = (timeVar1.getMonth() + 1) + '/' + timeVar1.getDate() + '/' +  timeVar1.getFullYear();

			$('#prevPolicyDetailsTWPrevPolExpDate').loadCalendar({
				'enableDateRange': true,
				'enableCalendarFrom': minDateLim,
				'enableCalendarTo': maxDateLim
			});
		}*/

	}
// Modified by Rupa 
	$scope.showProperNcbPerc = function () {
		if ($scope.buyNow.twoWheeler.ncbDetails.ncbClaimStatusTW === false) {

			//var sysDate = CommonServices.getCommonData("serverDate").split(' ')[0];
			//var arr = sysDate.split('-');
			//var curDate = arr[1] + '/' + arr[2] + '/' + arr[0];
			var curDate = CommonServices.getCommonData("serverDate");
			$scope.showProperNcbPercAlert = "Declaration in case proof for No claim is not available : I / We declare that the rate of NCB claimed by me/us is correct and that no claim as arisen in the expiring policy period . I/We further undertake that if this declaration is found to be incorrect, all benefits under the policy in respect of Section I of the Policy will stand forfeited. The proof of NCB would be required to be submitted at the time of claim.  Date : " + curDate;

			CommonServices.showAlert($scope.showProperNcbPercAlert);

			switch ($scope.buyNow.twoWheeler.ncbDetails.ncbPercOnPrevPolicyTW) {
				case "0%":
					$scope.buyNow.twoWheeler.ncbDetails.ncbApplicablePerc = "20%";
					break;
				case "20%":
					$scope.buyNow.twoWheeler.ncbDetails.ncbApplicablePerc = "25%";
					break;
				case "25%":
					$scope.buyNow.twoWheeler.ncbDetails.ncbApplicablePerc = "35%";
					break;
				case "35%":
					$scope.buyNow.twoWheeler.ncbDetails.ncbApplicablePerc = "45%";
					break;
				case "45%":
					$scope.buyNow.twoWheeler.ncbDetails.ncbApplicablePerc = "50%";
					break;
				case "50%":
					$scope.buyNow.twoWheeler.ncbDetails.ncbApplicablePerc = "50%";
					break;
				case "Sunset Clause 55%":
					$scope.buyNow.twoWheeler.ncbDetails.ncbApplicablePerc = "55%";
					break;
				case "Sunset Clause 65%":
					$scope.buyNow.twoWheeler.ncbDetails.ncbApplicablePerc = "65%";
					break;
				default:
					$scope.buyNow.twoWheeler.ncbDetails.ncbApplicablePerc = "0%";
					break;
			}
		} 
		else {
			$scope.showNcbDiv4_5();
		}
	}

   	/*NP_CR_0898 Start */
	if($rootScope.showaddenhancementCoveragesDiv === true){
	        $scope.buyNow.twoWheeler.enhancementCoverages.nilDepreciation = $("#nildepreciationTW option:first").val();
			$scope.buyNow.twoWheeler.enhancementCoverages.roadTaxCover = $("#inclusionofRoadTaxCoverTW option:first").val();
			if($scope.buyNow.twoWheeler.enhancementCoverages.roadTaxCover=="Y"){
			$scope.buyNow.twoWheeler.enhancementCoverages.roadTaxAmount=$rootScope.buyNow.twoWheeler.enhancementCoverages.roadTaxAmount;
			}else{
			$scope.buyNow.twoWheeler.enhancementCoverages.roadTaxAmount=0;
			}
			//if($scope.buyNow.twoWheeler.enhancementCoverages.invoiceCover=="Y"){
			//$scope.buyNow.twoWheeler.enhancementCoverages.returnToInvoiceSI=$rootScope.buyNow.twoWheeler.enhancementCoverages.returnToInvoiceSI;
			//}else{
			//$scope.buyNow.twoWheeler.enhancementCoverages.returnToInvoiceSI=0;
			//}
			$scope.buyNow.twoWheeler.enhancementCoverages.invoiceCover = $("#returnToInvoicecoverTW option:first").val();
			if($rootScope.showNCBProtectionCover===true){
			$scope.buyNow.twoWheeler.enhancementCoverages.ncbProtectionCover = $("#nCBProtectionCoverTW option:first").val();
			}
			else if ($rootScope.showNCBProtectionCover===false){
			$scope.buyNow.twoWheeler.enhancementCoverages.ncbProtectionCover=undefined;
			}
			$scope.buyNow.twoWheeler.enhancementCoverages.engineProtectCover = $("#engineProtectCoverTW option:first").val();
			$scope.buyNow.twoWheeler.enhancementCoverages.consumableItemsCover = $("#consumableItemsCoverTW option:first").val();
	}
	else{
		$scope.buyNow.twoWheeler.enhancementCoverages.nilDepreciation=undefined;
		$scope.buyNow.twoWheeler.enhancementCoverages.roadTaxCover=undefined;
		$scope.buyNow.twoWheeler.enhancementCoverages.invoiceCover=undefined;
		$scope.buyNow.twoWheeler.enhancementCoverages.ncbProtectionCover=undefined;
		$scope.buyNow.twoWheeler.enhancementCoverages.engineProtectCover=undefined;
		$scope.buyNow.twoWheeler.enhancementCoverages.consumableItemsCover=undefined;
		$scope.buyNow.twoWheeler.enhancementCoverages.roadTaxAmount=0;
		$scope.buyNow.twoWheeler.enhancementCoverages.returnToInvoiceSI=0;
	  
	}
	$scope.showEnhancementCoveragesTW1=function(){
	//$scope.showEnhancementCoveragesTW1();
	if($scope.buyNow.twoWheeler.enhancementCoverages.roadTaxCover=="Y"){
	   $rootScope.showRoadTaxAmount = true;
	   $scope.buyNow.twoWheeler.enhancementCoverages.roadTaxAmount="";
	} else if ($scope.buyNow.twoWheeler.enhancementCoverages.roadTaxCover=="N")
	   $rootScope.showRoadTaxAmount = false;
	   $scope.buyNow.twoWheeler.enhancementCoverages.roadTaxAmount=0;
	
	}

		
		$scope.showEnhancementCoveragesTW=function(){
	if ($scope.buyNow.twoWheeler.enhancementCoverages.roadTaxCover=="N"&& $scope.buyNow.twoWheeler.enhancementCoverages.nilDepreciation =="N" && 
		$scope.buyNow.twoWheeler.enhancementCoverages.invoiceCover=="N" && 
		($scope.buyNow.twoWheeler.enhancementCoverages.ncbProtectionCover =="N"||$scope.buyNow.twoWheeler.enhancementCoverages.ncbProtectionCover ===undefined) && ($rootScope.buyNow.twoWheeler.basicPremium.twCoverageSelected =="ENHANCEMENT") &&
		$scope.buyNow.twoWheeler.enhancementCoverages.engineProtectCover=="N"&& $scope.buyNow.twoWheeler.enhancementCoverages.consumableItemsCover =="N") {
			CommonServices.showAlert("Please select at least one of Enhancement add-on covers or you can change the coverage to package");
			return false;
		}
		else 
		{
		  return true;
		}
		
		}
		
		
		$scope.showAlertInvoiceCover=function(){
		if(($rootScope.policyMonthDiff>34) && ($scope.buyNow.twoWheeler.enhancementCoverages.invoiceCover=='Y')){
		CommonServices.showAlert(" Return to invoice cover cannot be selected as Yes, if the vehicle age is greater than 34 months");
		$scope.buyNow.twoWheeler.enhancementCoverages.invoiceCover='N';
		$rootScope.showReturnToInvoiceSI = false;
		}else if($scope.buyNow.twoWheeler.enhancementCoverages.invoiceCover=='Y') {
	   $rootScope.showReturnToInvoiceSI = true;
	    $scope.buyNow.twoWheeler.enhancementCoverages.returnToInvoiceSI=$rootScope.buyNow.twoWheeler.quickQuote.insuredDeclaredValue;
		//console.log($scope.buyNow.twoWheeler.enhancementCoverages.returnToInvoiceSI);
		}else if($scope.buyNow.twoWheeler.enhancementCoverages.invoiceCover=='N') {
	   $rootScope.showReturnToInvoiceSI = false;	   
		}
		}
		$scope.showAlertNCBProtectionCover =function(){
		if(($rootScope.policyMonthDiff>58) && ($scope.buyNow.twoWheeler.enhancementCoverages.ncbProtectionCover=='Y')){
		CommonServices.showAlert("Nil Depreciation cover cannot be selected as Yes, if the vehicle age is greater than 58 months.");
		$scope.buyNow.twoWheeler.enhancementCoverages.ncbProtectionCover='N';
		}
		
		}
	/*NP_CR_0898  End*/	
	
	
	
	$scope.showAddCoversDiv3_4 = function () {
		if ($scope.buyNow.twoWheeler.addCovers.ownerDriveVehOrNotTW === true) {
			$scope.showaddCoversDiv3_4 = true;
			$scope.showDisclaimerDivTW1 = false;//NP_CR_3444
			$scope.DurationForPaOwnerDriverCoverTWDiv = false;//NP_CR_3444
			$scope.buyNow.twoWheeler.addCovers.sumInsForOwnerDriver = 1500000;
			$scope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner = $("#licenseTypeOfOwnerTW option:first").val();
			$scope.buyNow.twoWheeler.addCovers.nameOfNominee = undefined;
			$scope.buyNow.twoWheeler.addCovers.ageOfNominee = undefined;
			$scope.buyNow.twoWheeler.addCovers.relnWithInsured = $("#relnWithInsuredTW option:first").val();
			$scope.buyNow.twoWheeler.addCovers.compulsoryPACoverPolicy = $("#compulsoryPACoverPolicyTW option:first").val();//NP_CR_3444
			$scope.buyNow.twoWheeler.addCovers.sumInsuredOfAtleast15lacs = $("#sumInsuredOfAtleast15lacsTW option:first").val();//NP_CR_3444
			/*$scope.buyNow.twoWheeler.addCovers.paCoverForAnyOtherVehicle = $("#paCoverForAnyOtherVehicleTW option:first").val();*///NP_CR_3444B
			/*  cr_np_941  Start*/
			if($scope.DurationForPaOwnerDriverCoverTWDiv === true){
			//$scope.buyNow.twoWheeler.addCovers.DurationForPaOwnerDriverCover = $("#DurationForPaOwnerDriverCoverTW option:first").val();
			}else
			{
				$scope.buyNow.twoWheeler.addCovers.DurationForPaOwnerDriverCover = undefined;
			}
			/*  cr_np_941  End*/
		} else {
			$scope.showaddCoversDiv3_4 = false;
			$scope.buyNow.twoWheeler.addCovers.sumInsForOwnerDriver = undefined;
			$scope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner = undefined;
			$scope.buyNow.twoWheeler.addCovers.nameOfNominee = undefined;
			$scope.buyNow.twoWheeler.addCovers.ageOfNominee = undefined;
			$scope.buyNow.twoWheeler.addCovers.relnWithInsured = undefined;
			$scope.buyNow.twoWheeler.addCovers.DurationForPaOwnerDriverCover=undefined//cr_np_941  Start
			$scope.buyNow.twoWheeler.addCovers.compulsoryPACoverPolicy=undefined;//NP_CR_3444
			$scope.buyNow.twoWheeler.addCovers.sumInsuredOfAtleast15lacs=undefined//NP_CR_3444
			/*$scope.buyNow.twoWheeler.addCovers.paCoverForAnyOtherVehicle=undefined*///NP_CR_3444B
		}
	}

	$scope.showAddCoversDiv9 = function () {
		if ($scope.buyNow.twoWheeler.addCovers.paCoverForUnnamedPersonTW === true) {
			$scope.showaddCoversDiv9 = true;
			$scope.buyNow.twoWheeler.addCovers.paCoverForUnnamedPersonRadioTW = 1;
			$scope.buyNow.twoWheeler.addCovers.indSIforUnnamedPerson = 1500000;
		} else {
			$scope.showaddCoversDiv9 = false;
			$scope.buyNow.twoWheeler.addCovers.paCoverForUnnamedPersonRadioTW = undefined;
			$scope.buyNow.twoWheeler.addCovers.indSIforUnnamedPerson = null;
		}
	}

	$scope.showTypeOfFinancier = function () {

		var len = $("#financierDetailsTWfinancierName").val().length;
		if (len > 0) {
			$scope.showtypeOfFinancier = true;
		} else {
			$scope.showtypeOfFinancier = false;
			$scope.buyNow.twoWheeler.financierDetails.typeOfFinancier = undefined;
			$scope.buyNow.twoWheeler.financierDetails.financierName = undefined;
		}
	}

	$scope.insuredDetailsTWSubmit = function () {
	 //CR_0898 start
	 var isSelected =$scope.showEnhancementCoveragesTW();
	   var selectedCoverageTW=$rootScope.buyNow.twoWheeler.basicPremium.coverage;
	   if(!isSelected && (selectedCoverageTW == "E" ||selectedCoverageTW == "E5"))
	   {
	     return;
	   }
//CR_0898 end
		//CR608 Break In start
		if ($rootScope.buyNow.twoWheeler.prevPolicyDetails.prevPolExpDate !== undefined && $rootScope.buyNow.twoWheeler.prevPolicyDetails.prevPolExpDate !== "") {
			var prePolExpDate = $rootScope.buyNow.twoWheeler.prevPolicyDetails.prevPolExpDate; // For  Year of Manufacture dropdown		
			var arr = prePolExpDate.split('/');
			var validDate = arr[1] + '/' + arr[0] + '/' + arr[2]; //mm/dd/yyyy
			prePolExpDate = new Date(validDate);

			if ($scope.loginDate > prePolExpDate) {
				CommonServices.showAlert("We find there is a break in. We will not be able to avail policy. Please contact nearest NIA branch");
				return;
			}
		}

		//CR608 Break In end

		//var prePolExpDate = $rootScope.buyNow.twoWheeler.prevPolicyDetails.prevPolExpDate;
		//prePolExpDate = new Date(prePolExpDate);

		if ($scope.relationDetails !== undefined && $scope.relationDetails !== "") {
			if (CommonServices.getCommonData("stakeCode") === "DEVLP-OFF") {
				if ($scope.agentModels.relationDetailsRadio === "yes") {
					$rootScope.buyNow.twoWheeler.isAgentRequired = $scope.agentModels.relationDetailsRadio;
					$rootScope.buyNow.twoWheeler.relationDetails = $scope.relationDetails[$scope.agentModels.selectedAgent];
					delete $rootScope.buyNow.twoWheeler.relationDetails.$$hashKey;
				}
				else {
					$rootScope.buyNow.twoWheeler.relationDetails = "";
					$rootScope.buyNow.twoWheeler.isAgentRequired = $scope.agentModels.relationDetailsRadio;
				}
			}
			if (CommonServices.getCommonData("stakeCode") === "DEALER") {
      /* added for CR_NP_754 */
      
				if (CommonServices.getCommonData("channel") === "MISP") {
					$rootScope.buyNow.twoWheeler.relationDetails = CommonServices.getCommonData("defaultRelationResponse");
					for (var i = 0; i < $rootScope.buyNow.twoWheeler.relationDetails.length; i++) {
						delete $rootScope.buyNow.twoWheeler.relationDetails[i].$$hashKey;
					}
					CommonServices.setCommonData("defaultRelationResponse", $rootScope.buyNow.twoWheeler.relationDetails)
				} else {
				$rootScope.buyNow.twoWheeler.relationDetails = $scope.relationDetails;
				for (var i = 0; i < $rootScope.buyNow.twoWheeler.relationDetails.length; i++) {
					delete $rootScope.buyNow.twoWheeler.relationDetails[i].$$hashKey;
				}
					CommonServices.setCommonData("defaultRelationResponse", $rootScope.buyNow.twoWheeler.relationDetails);
			}

		}
      
            /* CR_NP_754 ends */

		}
		$rootScope.buyNow.twoWheeler.additionalDetails.colorOfvehicle = $scope.buyNow.twoWheeler.additionalDetails.colorOfVehicle;
		$state.go("sqcreatePolicyHolder");
	}
	
	//CR_3621 Start New logic
	
					var ParentpolicyExpiryDatecamp = $rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyExpiryDate;
					var drr = ParentpolicyExpiryDatecamp.split('/');
					ParentpolicyExpiryDatecamp = drr[1] + '/' + drr[0] + '/' + drr[2]; //mm/dd/yyyy
					
					var PolExpiryDatecamp= $rootScope.buyNow.twoWheeler.quickQuote.policyExpiryDate;
					var srr = PolExpiryDatecamp.split('/');
					PolExpiryDatecamp = srr[1] + '/' + srr[0] + '/' + srr[2]; //mm/dd/yyyy
					
					ParentpolicyExpiryDatecamp = new Date(ParentpolicyExpiryDatecamp) ;
					PolExpiryDatecamp = new Date(PolExpiryDatecamp);

				if (ParentpolicyExpiryDatecamp < PolExpiryDatecamp) {
					
				var PolStartDate = $rootScope.buyNow.twoWheeler.quickQuote.policyStartDate;
				PolStartDate = new Date(PolStartDate.split('/')[2],PolStartDate.split('/')[1]-1,PolStartDate.split('/')[0]);
				var ParentpolicyExpiryDate = $rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyExpiryDate;
				ParentpolicyExpiryDate = new Date(ParentpolicyExpiryDate.split('/')[2],ParentpolicyExpiryDate.split('/')[1]-1,ParentpolicyExpiryDate.split('/')[0]);
				var timeDiff = Math.abs(ParentpolicyExpiryDate.getTime() - PolStartDate.getTime());
				var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24)); 
				if (diffDays < 365) {
					$rootScope.buyNow.twoWheeler.additionalDetails.durInDays = diffDays;
					$scope.buyNow.twoWheeler.additionalDetails.polEndDateTW = $rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyExpiryDate;
				}else{
					$rootScope.buyNow.twoWheeler.additionalDetails.durInDays = '365';
					$scope.buyNow.twoWheeler.additionalDetails.polEndDateTW = $rootScope.buyNow.twoWheeler.quickQuote.policyExpiryDate;
				}
					
			}else{
					var PolStartDate = $rootScope.buyNow.twoWheeler.quickQuote.policyStartDate;
					PolStartDate = new Date(PolStartDate.split('/')[2],PolStartDate.split('/')[1]-1,PolStartDate.split('/')[0]);
					var PolExpiryDate= $rootScope.buyNow.twoWheeler.quickQuote.policyExpiryDate;
					PolExpiryDate = new Date(PolExpiryDate.split('/')[2],PolExpiryDate.split('/')[1]-1,PolExpiryDate.split('/')[0]);
					var timeDiff = Math.abs(PolExpiryDate.getTime() - PolStartDate.getTime());
					var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24)); 
					$rootScope.buyNow.twoWheeler.additionalDetails.durInDays = diffDays;
					$scope.buyNow.twoWheeler.additionalDetails.polEndDateTW = $rootScope.buyNow.twoWheeler.quickQuote.policyExpiryDate;;
				}
				
			//CR_3621 End

	if(CommonServices.SQParentPolicyHistory === true){
		$rootScope.buyNow.twoWheeler.additionalDetails.reg1TW=CommonServices.getCommonData("SQPolicyDetails").vehicles[0].vehicleDetails.registrationNo1;
		$rootScope.buyNow.twoWheeler.additionalDetails.reg2TW=CommonServices.getCommonData("SQPolicyDetails").vehicles[0].vehicleDetails.registrationNo2;
		$rootScope.buyNow.twoWheeler.additionalDetails.reg3TW=CommonServices.getCommonData("SQPolicyDetails").vehicles[0].vehicleDetails.registrationNo3;
		$rootScope.buyNow.twoWheeler.additionalDetails.reg4TW=CommonServices.getCommonData("SQPolicyDetails").vehicles[0].vehicleDetails.registrationNo4;
		$rootScope.buyNow.twoWheeler.additionalDetails.yrOfManufactureTW=CommonServices.getCommonData("SQPolicyDetails").vehicles[0].vehicleDetails.yearOfManufacture;
		$rootScope.buyNow.twoWheeler.additionalDetails.dateOfRegTW = CommonServices.getCommonData("SQPolicyDetails").vehicles[0].vehicleDetails.dateOfRegistration;
		$rootScope.buyNow.twoWheeler.additionalDetails.engineNumTW=CommonServices.getCommonData("SQPolicyDetails").vehicles[0].vehicleDetails.engineNo;
		$rootScope.buyNow.twoWheeler.additionalDetails.chassisNumTW=CommonServices.getCommonData("SQPolicyDetails").vehicles[0].vehicleDetails.chassisNo;
		var vehZoneTW=CommonServices.getCommonData("SQPolicyDetails").vehicles[0].vehicleDetails.vehicleZone;
		if (vehZoneTW === "A") {
					$rootScope.buyNow.twoWheeler.additionalDetails.vehZoneTW = "A (Ahmedabad, Bengaluru, Chennai, Hyderabad, Kolkata, Mumbai, New Delhi, Pune)";
			} else {
					$rootScope.buyNow.twoWheeler.additionalDetails.vehZoneTW = "B (Rest of India)";
		  }
		$rootScope.buyNow.twoWheeler.additionalDetails.clrRCBookTW=CommonServices.getCommonData("SQPolicyDetails").vehicles[0].vehicleDetails.colorAsPerRCbook;
		$rootScope.buyNow.twoWheeler.additionalDetails.typeOfFuelTW=CommonServices.getCommonData("SQPolicyDetails").vehicles[0].vehicleDetails.typeOfFuel;
		var inbuiltBiFuelSysTW =CommonServices.getCommonData("SQPolicyDetails").inBuiltBifuelSystemfitted;
		if (inbuiltBiFuelSysTW === "N" || inbuiltBiFuelSysTW === "No") {
					$rootScope.buyNow.twoWheeler.additionalDetails.inbuiltBiFuelSysTW = "No";
				} else {
					$rootScope.buyNow.twoWheeler.additionalDetails.inbuiltBiFuelSysTW = "Yes";
		  }
		if ($rootScope.buyNow.twoWheeler.additionalDetails.inbuiltBiFuelSysTW === 'No') {
			$scope.valOfBiFuelSys = true;
			$rootScope.buyNow.twoWheeler.additionalDetails.valOfBiFuelSysTW=CommonServices.getCommonData("SQPolicyDetails").vehicles[0].vehicleDetails.valueOfBifuelsystemInRs;
		} else {
			$scope.valOfBiFuelSys = false;
			$rootScope.buyNow.twoWheeler.additionalDetails.valOfBiFuelSysTW = 0;
		}
		$rootScope.buyNow.twoWheeler.additionalDetails.wattageInKW=CommonServices.getCommonData("SQPolicyDetails").vehicles[0].vehicleDetails.wattage;
		$rootScope.buyNow.twoWheeler.additionalDetails.polExcessTW=CommonServices.getCommonData("SQPolicyDetails").vehicles[0].vehicleDetails.additionalVehicleDetails.policyExcess;
		$rootScope.buyNow.twoWheeler.ncbDetails.ncbOnPrevPolicyTW=CommonServices.getCommonData("SQPolicyDetails").previousPolicyDetails.nCBfromPreviousPolicy;
		$rootScope.buyNow.twoWheeler.ncbDetails.ncbPercOnPrevPolicyTW = CommonServices.getCommonData("SQPolicyDetails").previousPolicyDetails.nCBPercentOnPreviousPolicy;
		$rootScope.buyNow.twoWheeler.ncbDetails.ncbClaimStatusTW=CommonServices.getCommonData("SQPolicyDetails").previousPolicyDetails.anyClaimPendingOrPaidOnPolicyWhichIsToBeRenewed;
		$rootScope.buyNow.twoWheeler.ncbDetails.ncbApplicablePerc=CommonServices.getCommonData("SQPolicyDetails").previousPolicyDetails.nCBApplicablePercentage;
		$rootScope.buyNow.twoWheeler.quickQuote.insuredDeclaredValue=CommonServices.getCommonData("SQPolicyDetails").vehicles[0].vehicleDetails.totalIDV;
		$rootScope.buyNow.twoWheeler.ncbDetails.colorOfVehicle=CommonServices.getCommonData("SQPolicyDetails").vehicles[0].vehicleDetails.colorOfVehicle;
		$rootScope.buyNow.twoWheeler.additionalDetails.colorOfvehicle = $rootScope.buyNow.twoWheeler.ncbDetails.colorOfVehicle;
		for (var i = 0; i < $rootScope.previousInsurersList.length; i++) {
					if ($rootScope.previousInsurersList[i].codeValue == CommonServices.getCommonData("SQPolicyDetails").previousPolicyDetails.nameofPreviousInsurer.toUpperCase()) {
						$rootScope.buyNow.twoWheeler.prevPolicyDetails.nameOfPrevIns = $rootScope.previousInsurersList[i].mnemonic;
						break;
					} else {
						$rootScope.buyNow.twoWheeler.prevPolicyDetails.nameOfPrevIns = "";
					}
				}

		$rootScope.buyNow.twoWheeler.prevPolicyDetails.prevPolNum=$rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyNo;

		var term = parseInt(1);
		var prvpoliexpDate = $rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyStartDate;
		var arr = prvpoliexpDate.split('/');
		var todaysDate = arr[1] + '/' + arr[0] + '/' + arr[2]; //mm/dd/yyyy

		var addYears = function (todaysDate) {
			var dt = new Date(todaysDate);
			var newDate = new Date(dt.getFullYear() + term, dt.getMonth(), dt.getDate() - 1);
			var d = new Date(newDate || Date.now()),

				month = '' + (d.getMonth() + 1),
				day = '' + d.getDate(),
				year = d.getFullYear();

			if (month.length < 2) month = '0' + month;
			if (day.length < 2) day = '0' + day;

			return [day, month, year].join('/');
		}

		var previousPolicyExpiryDate = addYears(todaysDate);
    	$rootScope.buyNow.twoWheeler.prevPolicyDetails.prevPolExpDate=previousPolicyExpiryDate;
		
		if ($rootScope.buyNow.twoWheeler.prevPolicyDetails.prevPolExpDate != undefined && $rootScope.buyNow.twoWheeler.prevPolicyDetails.prevPolExpDate != '')
	{
		var prevpolicyexDate = $rootScope.buyNow.twoWheeler.prevPolicyDetails.prevPolExpDate;
		var arr = prevpolicyexDate.split('/');
		prevpolicyexDate = arr[1] + '/' + arr[0] + '/' + arr[2]; //mm/dd/yyyy
		var policystartDt = new Date(prevpolicyexDate);
		policystartDt.setDate(policystartDt.getDate() + 1);
		var dd = policystartDt.getDate();
		var mm = policystartDt.getMonth()+1;
		var yyyy = policystartDt.getFullYear();
		 if (dd < 10) {
			dd = "0" + dd;
		}

		if (mm < 10) {
			mm = "0" + mm;
		}
		$scope.buyNow.twoWheeler.additionalDetails.polStartDateTW = dd + "/" + mm + "/" + yyyy; //policy start date
		$rootScope.buyNow.twoWheeler.quickQuote.policyStartDate = $scope.buyNow.twoWheeler.additionalDetails.polStartDateTW;
		var polstartDateTW = $rootScope.buyNow.twoWheeler.quickQuote.policyStartDate;
		var arr = polstartDateTW.split('/');
		polstartDateTW = arr[1] + '/' + arr[0] + '/' + arr[2]; //mm/dd/yyyy
    	var polEndDateTW = addYears(polstartDateTW);
		$rootScope.buyNow.twoWheeler.additionalDetails.polEndDateTW = polEndDateTW;
		$rootScope.buyNow.twoWheeler.quickQuote.policyExpiryDate = polEndDateTW;
		$rootScope.buyNow.twoWheeler.additionalDetails.durInDays = '365';
		
		}
		
		$rootScope.buyNow.twoWheeler.addCovers.extensionOfGeographicalAreaRequired = CommonServices.getCommonData("SQPolicyDetails").vehicles[0].coverages[0].additionalCoverageDetails.extensionOfGeographicalAreaRequired;
		$rootScope.buyNow.twoWheeler.additionalDetails.discountPercModel  = CommonServices.getCommonData("SQPolicyDetails").salesChannel.salesDiscounts[0].discountPercentage;
		$rootScope.buyNow.twoWheeler.additionalDetails.loadingDiscountPercModel  = CommonServices.getCommonData("SQPolicyDetails").salesChannel.salesDiscounts[0].discountAmount;
		$rootScope.buyNow.twoWheeler.enhancementCoverages.nilDepreciation = CommonServices.getCommonData("SQPolicyDetails").vehicles[0].coverages[0].addOnEnhancementCoverages.nilDepreciation;
		$rootScope.buyNow.twoWheeler.enhancementCoverages.roadTaxCover = CommonServices.getCommonData("SQPolicyDetails").vehicles[0].coverages[0].addOnEnhancementCoverages.inclusionOfRoadTaxCover;
		if ($rootScope.buyNow.twoWheeler.enhancementCoverages.roadTaxCover === "Y") {
			$rootScope.showRoadTaxAmount = true;
			$rootScope.buyNow.twoWheeler.enhancementCoverages.roadTaxAmount = CommonServices.getCommonData("SQPolicyDetails").vehicles[0].coverages[0].addOnEnhancementCoverages.roadTaxAmount;
		}
		$rootScope.buyNow.twoWheeler.enhancementCoverages.invoiceCover = CommonServices.getCommonData("SQPolicyDetails").vehicles[0].coverages[0].addOnEnhancementCoverages.returnToInvoiceCover;
		if($scope.buyNow.twoWheeler.enhancementCoverages.invoiceCover=='Y') {
			$rootScope.showReturnToInvoiceSI = true;
			$rootScope.buyNow.twoWheeler.enhancementCoverages.returnToInvoiceSI = CommonServices.getCommonData("SQPolicyDetails").vehicles[0].coverages[0].addOnEnhancementCoverages.siForReturnToInvoice;
		}
		$rootScope.buyNow.twoWheeler.enhancementCoverages.ncbProtectionCover = CommonServices.getCommonData("SQPolicyDetails").vehicles[0].coverages[0].addOnEnhancementCoverages.ncbProtectionCover;
		$rootScope.buyNow.twoWheeler.enhancementCoverages.engineProtectCover = CommonServices.getCommonData("SQPolicyDetails").vehicles[0].coverages[0].addOnEnhancementCoverages.engineProtectCover;
		$rootScope.buyNow.twoWheeler.enhancementCoverages.consumableItemsCover = CommonServices.getCommonData("SQPolicyDetails").vehicles[0].coverages[0].addOnEnhancementCoverages.consumableItemsCover;
	}

}]);

agentApp.controller('sqcreatePolicyHolderCtrl', ['$scope', '$rootScope', 'CommonServices', 'RestServices', 'GetSetResponseService', '$location', '$state', '$filter', function ($scope, $rootScope, CommonServices, RestServices, GetSetResponseService, $location, $state, $filter) {
		if(CommonServices.SQParentPolicyHistory === true){
			$scope.SQfieldDisable = true;
		}else {
			$scope.SQfieldDisable = false;
		}
/*Added for CR_NP_0744 and commented for CR_NP_0744E start*/
	$scope.regexPanNo = regexPanNoGlobal;
	$scope.regexAadhaarInput = /^(?!\1+$)\d{4}$/;
	$scope.regexAadhaarNumber = /^(?!\1+$)\d{12}$/;
	/*CR_NP_0880 starts */
	$scope.disablePinCode = true;
	$scope.disableCity = true;
	$scope.stateErr = false;
	$scope.pinCodeErr = false;
	$scope.cityErr = false;
	$scope.gstinMsg = "GSTIN";
	/*
	$scope.countryErr = false;//3712
	$scope.nationalityEmpty = true;  //CR 3712
	*/
	$scope.isNIAPAN = false;//CR3746
	$scope.isPanDisabled = false;//CR3746
	//CR3746
	$scope.onPANNoChange = function () {
		if($scope.buyNow.twoWheeler.insuredDetails.panNum != undefined){
			$scope.buyNow.twoWheeler.insuredDetails.panNum = $scope.buyNow.twoWheeler.insuredDetails.panNum.toUpperCase();
			$scope.isNIAPAN = isNIAPANNo($scope.buyNow.twoWheeler.insuredDetails.panNum);
		}
		else
			$scope.isNIAPAN = false;
	};
	//CR3746

	if ($rootScope.backFlag == "sqSummaryDetails") {
		$scope.disablePinCode = false;
		$scope.disableCity = true;
	}
	/*CR_NP_0880 Ends*/
	
	/*CR 3712 starts
	$scope.isNonIndia = false;
	// $scope.policyDetailsObj.clientNationality ="";
	$scope.onNationalityChange = function(){
		$scope.policyDetailsObj.clientCountry = '';
		if($scope.buyNow.twoWheeler.insuredDetails.clientNationality == "NonIndian"){
			$scope.isNonIndia = true;
		}
		else{
			$scope.isNonIndia = false;
		}
	}
	// CR_3712 ends*/

	var configurationData = CommonServices.getCommonData("ConfigurationData");
	if (configurationData != undefined && configurationData != '') {
		if (configurationData[0].value == "Y") {
			$scope.isPanNumberMandatory = true;
		} else {
			$scope.isPanNumberMandatory = false;
		}

		/*Below block Commented by 851587 for CR_NP_0744E */
		//  if(configurationData[1].value == "Y"){
		// 	 $scope.isAadhaarNumberMandatory = true;
		//  }else{
		// 	  $scope.isAadhaarNumberMandatory = false;
		//  }
		/* CR_NP_0744E ends*/
	}

	/*Below block Commented by 851587 for CR_NP_0744E */
	// $(".aadhaarInput").keyup(function () {
	// 	if (this.value.length == 4) {
	// 		$(this).next('.aadhaarInput').focus();
	// 	}
	// 	if (this.value.length < 1) {
	// 	  $(this).prev('.aadhaarInput').focus();
	// 	}
	// });
	// $scope.aadhaarNoField = function(){
	// 	if(($scope.policyDetailsObj.aadhaarNumber1 != undefined && $scope.policyDetailsObj.aadhaarNumber1 !='')||($scope.policyDetailsObj.aadhaarNumber2 != undefined && $scope.policyDetailsObj.aadhaarNumber2 !='')||($scope.policyDetailsObj.aadhaarNumber3 != undefined && $scope.policyDetailsObj.aadhaarNumber3 !='')){
	// 		$scope.aadharFieldIsRequired = true;
	// 		if(($scope.policyDetailsObj.aadhaarNumber1 != undefined && $scope.policyDetailsObj.aadhaarNumber1 !='') && ($scope.policyDetailsObj.aadhaarNumber2 != undefined && $scope.policyDetailsObj.aadhaarNumber2 !='') && ($scope.policyDetailsObj.aadhaarNumber3 != undefined && $scope.policyDetailsObj.aadhaarNumber3 !='')){
	// 			$scope.aadharFieldIsRequired = false;
	// 		}
	// 	}else{
	// 		$scope.aadharFieldIsRequired = false;
	// 	}
	// };
	/**CR_NP_0744 and CR_NP_0744E Changes End**/

	/*****************Save Quote From Customer*****************************/

	$rootScope.saveQuoteTW = function () {
		//Added just to validate the breakin condition and not allow policy purchase for Enhancement and Package covers. Need to remove this below block of code while implementing CR_NP_0585
		if (($rootScope.buyNow.twoWheeler.newVehicle === false) && ($rootScope.buyNow.twoWheeler.basicPremium.coverage === "E" || $rootScope.buyNow.twoWheeler.basicPremium.coverage === "P")) {
			var todyDate = CommonServices.getCommonData("serverDate");
			todyDate = new Date(todyDate);
			if ($rootScope.buyNow.twoWheeler.prevPolicyDetails.prevPolExpDate == undefined || $rootScope.buyNow.twoWheeler.prevPolicyDetails.prevPolExpDate == "") {
				CommonServices.showAlert("Please select Previous Policy Expiry Date in Previous Policy Details");
				return;
			}

			var userEnteredPrevPolNum = $rootScope.buyNow.twoWheeler.prevPolicyDetails.prevPolExpDate;
			var arr = userEnteredPrevPolNum.split('/');
			arr = arr[1] + '/' + arr[0] + '/' + arr[2];
			userEnteredPrevPolNum = new Date(arr);

			if (userEnteredPrevPolNum < todyDate) {
				CommonServices.showAlert("We find there is a break in insurance and you will not be able to avail policy online. Contact nearest NIA office for more information");
				CommonServices.showLoading(false);
				return;
			}
		}
		//Block ends

		if ($rootScope.buyNow.twoWheeler.newVehicle === true) {
			$rootScope.buyNow.twoWheeler.newVehicle = "Y";
		} else if ($rootScope.buyNow.twoWheeler.newVehicle === false) {
			$rootScope.buyNow.twoWheeler.newVehicle = "N";
		}

		if ($scope.buyNow.twoWheeler.ncbDetails.ncbOnPrevPolicyTW === undefined || $scope.buyNow.twoWheeler.ncbDetails.ncbOnPrevPolicyTW === "") {
			$rootScope.buyNow.twoWheeler.ncbDetails.ncbOnPrevPolicyTW = null;
		}
		else if ($scope.buyNow.twoWheeler.ncbDetails.ncbOnPrevPolicyTW === true || $scope.buyNow.twoWheeler.ncbDetails.ncbOnPrevPolicyTW === "Yes" || $scope.buyNow.twoWheeler.ncbDetails.ncbOnPrevPolicyTW === "Y") {
			$rootScope.buyNow.twoWheeler.ncbDetails.ncbOnPrevPolicyTW = "Y";
		} else {
			$rootScope.buyNow.twoWheeler.ncbDetails.ncbOnPrevPolicyTW = "N";
		}


		if ($scope.buyNow.twoWheeler.ncbDetails.ncbPercOnPrevPolicyTW === undefined || $scope.buyNow.twoWheeler.ncbDetails.ncbPercOnPrevPolicyTW === "") {
			$rootScope.buyNow.twoWheeler.ncbDetails.ncbPercOnPrevPolicyTW = null;
		} else {
			if ($scope.buyNow.twoWheeler.ncbDetails.ncbPercOnPrevPolicyTW !== null && $scope.buyNow.twoWheeler.ncbDetails.ncbPercOnPrevPolicyTW !== "0") {
				if ($scope.buyNow.twoWheeler.ncbDetails.ncbPercOnPrevPolicyTW.substring($scope.buyNow.twoWheeler.ncbDetails.ncbPercOnPrevPolicyTW.length - 1) !== "%") {
					$scope.buyNow.twoWheeler.ncbDetails.ncbPercOnPrevPolicyTW = $scope.buyNow.twoWheeler.ncbDetails.ncbPercOnPrevPolicyTW + "%";
				}

			}

			switch ($scope.buyNow.twoWheeler.ncbDetails.ncbPercOnPrevPolicyTW) {
				case "0%":
					$rootScope.buyNow.twoWheeler.ncbDetails.ncbPercOnPrevPolicyTW = "0";
					break;
				case "20%":
					$rootScope.buyNow.twoWheeler.ncbDetails.ncbPercOnPrevPolicyTW = "20";
					break;
				case "25%":
					$rootScope.buyNow.twoWheeler.ncbDetails.ncbPercOnPrevPolicyTW = "25";
					break;
				case "35%":
					$rootScope.buyNow.twoWheeler.ncbDetails.ncbPercOnPrevPolicyTW = "35";
					break;
				case "45%":
					$rootScope.buyNow.twoWheeler.ncbDetails.ncbPercOnPrevPolicyTW = "45";
					break;
				case "50%":
					$rootScope.buyNow.twoWheeler.ncbDetails.ncbPercOnPrevPolicyTW = "50";
					break;
				case "Sunset Clause 55%":
					$rootScope.buyNow.twoWheeler.ncbDetails.ncbPercOnPrevPolicyTW = "55";
					break;
				case "Sunset Clause 65%":
					$rootScope.buyNow.twoWheeler.ncbDetails.ncbPercOnPrevPolicyTW = "65";
					break;
				default:
					$rootScope.buyNow.twoWheeler.ncbDetails.ncbPercOnPrevPolicyTW = "0";
					break;

			}
		}

		if ($scope.buyNow.twoWheeler.ncbDetails.ncbClaimStatusTW === undefined || $scope.buyNow.twoWheeler.ncbDetails.ncbClaimStatusTW === "") {
			$rootScope.buyNow.twoWheeler.ncbDetails.ncbClaimStatusTW = null;
		}
		else if ($scope.buyNow.twoWheeler.ncbDetails.ncbClaimStatusTW === true || $scope.buyNow.twoWheeler.ncbDetails.ncbClaimStatusTW === "Yes" || $scope.buyNow.twoWheeler.ncbDetails.ncbClaimStatusTW === "Y") {
			$rootScope.buyNow.twoWheeler.ncbDetails.ncbClaimStatusTW = "Y";
		} else {
			$rootScope.buyNow.twoWheeler.ncbDetails.ncbClaimStatusTW = "N";
		}


		if ($scope.buyNow.twoWheeler.ncbDetails.ncbApplicablePerc === undefined || $scope.buyNow.twoWheeler.ncbDetails.ncbApplicablePerc === "") {
			$rootScope.buyNow.twoWheeler.ncbDetails.ncbApplicablePerc = null;
		}
		else {

			if ($scope.buyNow.twoWheeler.ncbDetails.ncbApplicablePerc !== null && $scope.buyNow.twoWheeler.ncbDetails.ncbApplicablePerc !== "0") {
				if ($scope.buyNow.twoWheeler.ncbDetails.ncbApplicablePerc.substring($scope.buyNow.twoWheeler.ncbDetails.ncbApplicablePerc.length - 1) !== "%") {
					$scope.buyNow.twoWheeler.ncbDetails.ncbApplicablePerc = $scope.buyNow.twoWheeler.ncbDetails.ncbApplicablePerc + "%";
				}
			}

			switch ($scope.buyNow.twoWheeler.ncbDetails.ncbApplicablePerc) {
				case "0%":
					$rootScope.buyNow.twoWheeler.ncbDetails.ncbApplicablePerc = "0";
					break;
				case "20%":
					$rootScope.buyNow.twoWheeler.ncbDetails.ncbApplicablePerc = "20";
					break;
				case "25%":
					$rootScope.buyNow.twoWheeler.ncbDetails.ncbApplicablePerc = "25";
					break;
				case "35%":
					$rootScope.buyNow.twoWheeler.ncbDetails.ncbApplicablePerc = "35";
					break;
				case "45%":
					$rootScope.buyNow.twoWheeler.ncbDetails.ncbApplicablePerc = "45";
					break;
				case "50%":
					$rootScope.buyNow.twoWheeler.ncbDetails.ncbApplicablePerc = "50";
					break;
				case "Sunset Clause 55%":
					$rootScope.buyNow.twoWheeler.ncbDetails.ncbApplicablePerc = "55";
					break;
				case "Sunset Clause 65%":
					$rootScope.buyNow.twoWheeler.ncbDetails.ncbApplicablePerc = "65";
					break;
				default:
					$rootScope.buyNow.twoWheeler.ncbDetails.ncbApplicablePerc = "0";
					break;
			}
		}
		/*Changed by 851587 for CR_NP_0752*/

		if ($scope.buyNow.twoWheeler.newVehicle === "Y") {
			if ($scope.buyNow.twoWheeler.ncbDetails.ncbOnPrevPolicyTW === undefined || $scope.buyNow.twoWheeler.ncbDetails.ncbOnPrevPolicyTW === "" || $scope.buyNow.twoWheeler.ncbDetails.ncbOnPrevPolicyTW === "N") {
				//  $rootScope.buyNow.twoWheeler.prevPolicyDetails.nameOfPrevIns = "Not Applicable";
				$rootScope.buyNow.twoWheeler.prevPolicyDetails.nameOfPrevIns = null;
			} else {
				$rootScope.buyNow.twoWheeler.prevPolicyDetails.nameOfPrevIns = $scope.buyNow.twoWheeler.prevPolicyDetails.nameOfPrevIns;
			}

		} else {
			if ($scope.buyNow.twoWheeler.prevPolicyDetails.nameOfPrevIns === undefined || $scope.buyNow.twoWheeler.prevPolicyDetails.nameOfPrevIns === "") {
				$rootScope.buyNow.twoWheeler.prevPolicyDetails.nameOfPrevIns = "Not Available"; //to send the value Not Available to core
			} else {
				$rootScope.buyNow.twoWheeler.prevPolicyDetails.nameOfPrevIns = $scope.buyNow.twoWheeler.prevPolicyDetails.nameOfPrevIns;
			}

		}
		/* CR_NP_0752 ends*/

		if ($scope.buyNow.twoWheeler.prevPolicyDetails.prevPolNum === undefined || $scope.buyNow.twoWheeler.prevPolicyDetails.prevPolNum === "") {
			$rootScope.buyNow.twoWheeler.prevPolicyDetails.prevPolNum = null;
		}
		else {
			$rootScope.buyNow.twoWheeler.prevPolicyDetails.prevPolNum = $scope.buyNow.twoWheeler.prevPolicyDetails.prevPolNum;
		}
		if ($scope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner === undefined || $scope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner === "") {
			$rootScope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner = null;
		}
		else {

			if ($scope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner === "Motor Cycle with Gear") {
				$rootScope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner = "MCGEAR";
			} else {
				$rootScope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner = "MCNOGEAR";
			}

			//$rootScope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner = $scope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner;
		}
		if ($scope.buyNow.twoWheeler.financierDetails.financierName === undefined || $scope.buyNow.twoWheeler.financierDetails.financierName === "") {
			$rootScope.buyNow.twoWheeler.financierDetails.financierName = null;
		}
		else {
			$rootScope.buyNow.twoWheeler.financierDetails.financierName = $scope.buyNow.twoWheeler.financierDetails.financierName;
		}
		if ($scope.buyNow.twoWheeler.financierDetails.typeOfFinancier === undefined || $scope.buyNow.twoWheeler.financierDetails.typeOfFinancier === "") {
			$rootScope.buyNow.twoWheeler.financierDetails.typeOfFinancier = null;
		}
		else {
			$rootScope.buyNow.twoWheeler.financierDetails.typeOfFinancier = $scope.buyNow.twoWheeler.financierDetails.typeOfFinancier;
		}
		if ($scope.buyNow.twoWheeler.additionalDetails.polExcessTW === undefined || $scope.buyNow.twoWheeler.additionalDetails.polExcessTW === "") {
			$rootScope.buyNow.twoWheeler.additionalDetails.polExcessTW = null;
		}
		else {
			$rootScope.buyNow.twoWheeler.additionalDetails.polExcessTW = $scope.buyNow.twoWheeler.additionalDetails.polExcessTW;
		}
		if ($scope.buyNow.twoWheeler.addCovers.nameOfNominee === undefined || $scope.buyNow.twoWheeler.addCovers.nameOfNominee === "") {
			$rootScope.buyNow.twoWheeler.addCovers.nameOfNominee = null;
		}
		else {
			$rootScope.buyNow.twoWheeler.addCovers.nameOfNominee = $scope.buyNow.twoWheeler.addCovers.nameOfNominee;
		}
		if ($scope.buyNow.twoWheeler.addCovers.ageOfNominee === undefined || $scope.buyNow.twoWheeler.addCovers.ageOfNominee === "") {
			$rootScope.buyNow.twoWheeler.addCovers.ageOfNominee = null;
		}
		else {
			$rootScope.buyNow.twoWheeler.addCovers.ageOfNominee = $scope.buyNow.twoWheeler.addCovers.ageOfNominee;
		}
		if ($scope.buyNow.twoWheeler.addCovers.relnWithInsured === undefined || $scope.buyNow.twoWheeler.addCovers.relnWithInsured === "") {
			$rootScope.buyNow.twoWheeler.addCovers.relnWithInsured = null;
		}
		else {
			$rootScope.buyNow.twoWheeler.addCovers.relnWithInsured = $scope.buyNow.twoWheeler.addCovers.relnWithInsured;
		}
		if ($scope.buyNow.twoWheeler.additionalDetails.reg1TW === undefined || $scope.buyNow.twoWheeler.additionalDetails.reg1TW === "") {
			$rootScope.buyNow.twoWheeler.additionalDetails.reg1TW = null;
		}
		else {
			$rootScope.buyNow.twoWheeler.additionalDetails.reg1TW = $scope.buyNow.twoWheeler.additionalDetails.reg1TW;
		}
		if ($scope.buyNow.twoWheeler.additionalDetails.reg2TW === undefined || $scope.buyNow.twoWheeler.additionalDetails.reg2TW === "") {
			$rootScope.buyNow.twoWheeler.additionalDetails.reg2TW = null;
		}
		else {
			$rootScope.buyNow.twoWheeler.additionalDetails.reg2TW = $scope.buyNow.twoWheeler.additionalDetails.reg2TW;
		}
		if ($scope.buyNow.twoWheeler.additionalDetails.reg3TW === undefined || $scope.buyNow.twoWheeler.additionalDetails.reg3TW === "") {
			$rootScope.buyNow.twoWheeler.additionalDetails.reg3TW = null;
		}
		else {
			$rootScope.buyNow.twoWheeler.additionalDetails.reg3TW = $scope.buyNow.twoWheeler.additionalDetails.reg3TW;
		}
		if ($scope.buyNow.twoWheeler.additionalDetails.reg4TW === undefined || $scope.buyNow.twoWheeler.additionalDetails.reg4TW === "") {
			$rootScope.buyNow.twoWheeler.additionalDetails.reg4TW = null;
		}
		else {
			$rootScope.buyNow.twoWheeler.additionalDetails.reg4TW = $scope.buyNow.twoWheeler.additionalDetails.reg4TW;
		}
		if ($scope.buyNow.twoWheeler.additionalDetails.dateOfRegTW === undefined || $scope.buyNow.twoWheeler.additionalDetails.dateOfRegTW === "" || $scope.buyNow.twoWheeler.additionalDetails.dateOfRegTW === null) {
			$rootScope.buyNow.twoWheeler.additionalDetails.dateOfRegTW = null;
		}
		else {
			/*var dateOfReg = $scope.buyNow.twoWheeler.additionalDetails.dateOfRegTW;
			var dateOfRegArr = dateOfReg.split("/");
			dateOfReg = dateOfRegArr[1] + "/" + dateOfRegArr[0] + "/" + dateOfRegArr[2];
			$rootScope.buyNow.twoWheeler.additionalDetails.dateOfRegTW = dateOfReg;*/
			$rootScope.buyNow.twoWheeler.additionalDetails.dateOfRegTW = $scope.buyNow.twoWheeler.additionalDetails.dateOfRegTW;
		}
		if ($scope.buyNow.twoWheeler.additionalDetails.yrOfManufactureTW === undefined || $scope.buyNow.twoWheeler.additionalDetails.yrOfManufactureTW === "") {
			$rootScope.buyNow.twoWheeler.additionalDetails.yrOfManufactureTW = null;
		}
		else {
			$rootScope.buyNow.twoWheeler.additionalDetails.yrOfManufactureTW = $scope.buyNow.twoWheeler.additionalDetails.yrOfManufactureTW;
		}
		if ($scope.buyNow.twoWheeler.additionalDetails.vehZoneTW === undefined || $scope.buyNow.twoWheeler.additionalDetails.vehZoneTW === "") {
			$rootScope.buyNow.twoWheeler.additionalDetails.vehZoneTW = null;
		}
		else {
			if ($scope.buyNow.twoWheeler.additionalDetails.vehZoneTW === "A (Ahmedabad, Bengaluru, Chennai, Hyderabad, Kolkata, Mumbai, New Delhi, Pune)") {
				$rootScope.buyNow.twoWheeler.additionalDetails.vehZoneTW = 'A';
			} else {
				$rootScope.buyNow.twoWheeler.additionalDetails.vehZoneTW = 'B';
			}
		}
		if ($scope.buyNow.twoWheeler.additionalDetails.vehInVoiceValTW === undefined || $scope.buyNow.twoWheeler.additionalDetails.vehInVoiceValTW === "") {
			$rootScope.buyNow.twoWheeler.additionalDetails.vehInVoiceValTW = null;
		}
		else {
			$rootScope.buyNow.twoWheeler.additionalDetails.vehInVoiceValTW = $scope.buyNow.twoWheeler.additionalDetails.vehInVoiceValTW;
		}
		if ($scope.buyNow.twoWheeler.additionalDetails.clrRCBookTW === undefined || $scope.buyNow.twoWheeler.additionalDetails.clrRCBookTW === "") {
			$rootScope.buyNow.twoWheeler.additionalDetails.clrRCBookTW = null;
		}
		else {
			$rootScope.buyNow.twoWheeler.additionalDetails.clrRCBookTW = $scope.buyNow.twoWheeler.additionalDetails.clrRCBookTW;
		}
		if ($scope.buyNow.twoWheeler.additionalDetails.engineNumTW === undefined || $scope.buyNow.twoWheeler.additionalDetails.engineNumTW === "") {
			$rootScope.buyNow.twoWheeler.additionalDetails.engineNumTW = null;
		}
		else {
			$rootScope.buyNow.twoWheeler.additionalDetails.engineNumTW = $scope.buyNow.twoWheeler.additionalDetails.engineNumTW;
		}
		if ($scope.buyNow.twoWheeler.additionalDetails.chassisNumTW === undefined || $scope.buyNow.twoWheeler.additionalDetails.chassisNumTW === "") {
			$rootScope.buyNow.twoWheeler.additionalDetails.chassisNumTW = null;
		}
		else {
			$rootScope.buyNow.twoWheeler.additionalDetails.chassisNumTW = $scope.buyNow.twoWheeler.additionalDetails.chassisNumTW;
		}
		if ($scope.buyNow.twoWheeler.additionalDetails.typeOfFuelTW === undefined || $scope.buyNow.twoWheeler.additionalDetails.typeOfFuelTW === "") {
			$rootScope.buyNow.twoWheeler.additionalDetails.typeOfFuelTW = null;
		}
		else {
			$rootScope.buyNow.twoWheeler.additionalDetails.typeOfFuelTW = $scope.buyNow.twoWheeler.additionalDetails.typeOfFuelTW;
		}
		if ($scope.buyNow.twoWheeler.additionalDetails.wattageInKW === undefined || $scope.buyNow.twoWheeler.additionalDetails.wattageInKW === "") {
			$rootScope.buyNow.twoWheeler.additionalDetails.wattageInKW = null;
		}
		else {
			$rootScope.buyNow.twoWheeler.additionalDetails.wattageInKW = $scope.buyNow.twoWheeler.additionalDetails.wattageInKW;
		}
		if ($scope.buyNow.twoWheeler.additionalDetails.inbuiltBiFuelSysTW === undefined || $scope.buyNow.twoWheeler.additionalDetails.inbuiltBiFuelSysTW === "") {
			$rootScope.buyNow.twoWheeler.additionalDetails.inbuiltBiFuelSysTW = null;
		}
		else {
			$rootScope.buyNow.twoWheeler.additionalDetails.inbuiltBiFuelSysTW = $scope.buyNow.twoWheeler.additionalDetails.inbuiltBiFuelSysTW;
		}
		if ($scope.buyNow.twoWheeler.additionalDetails.valOfBiFuelSysTW === undefined || $scope.buyNow.twoWheeler.additionalDetails.valOfBiFuelSysTW === "") {
			$rootScope.buyNow.twoWheeler.additionalDetails.valOfBiFuelSysTW = null;
		}
		else {
			$rootScope.buyNow.twoWheeler.additionalDetails.valOfBiFuelSysTW = $scope.buyNow.twoWheeler.additionalDetails.valOfBiFuelSysTW;
		}
		if ($scope.buyNow.twoWheeler.addCovers.sumInsForOwnerDriver === undefined || $scope.buyNow.twoWheeler.addCovers.sumInsForOwnerDriver === "") {
			$rootScope.buyNow.twoWheeler.addCovers.sumInsForOwnerDriver = null;
		}
		else {
			$rootScope.buyNow.twoWheeler.addCovers.sumInsForOwnerDriver = $scope.buyNow.twoWheeler.addCovers.sumInsForOwnerDriver;
		}

		if ($scope.buyNow.twoWheeler.addCovers.ownerDriveVehOrNotTW === undefined || $scope.buyNow.twoWheeler.additionalDetails.addCovers === "") {
			$rootScope.buyNow.twoWheeler.addCovers.ownerDriveVehOrNotTW = null;
		}
		else {
			if ($scope.buyNow.twoWheeler.addCovers.ownerDriveVehOrNotTW === true || $scope.buyNow.twoWheeler.addCovers.ownerDriveVehOrNotTW === "Yes") {
				$rootScope.buyNow.twoWheeler.addCovers.ownerDriveVehOrNotTW = "Y";
			} else {
				$rootScope.buyNow.twoWheeler.addCovers.ownerDriveVehOrNotTW = "N";
			}

		}

	 if(CommonServices.SQParentPolicyHistory === false) {
		if ($rootScope.buyNow.twoWheeler.prevPolicyDetails.prevPolExpDate != undefined && $rootScope.buyNow.twoWheeler.prevPolicyDetails.prevPolExpDate != '') {
			//Prev Policy Exp Date is present
			if ($rootScope.buyNow.twoWheeler.newVehicle != 'Y') {
				var addYears = function (todaysDate) {

					var dt = new Date(todaysDate);
					var newDate = new Date(dt.getFullYear() + 1, dt.getMonth(), dt.getDate() - 1);
					var d = new Date(newDate || Date.now()),

						month = '' + (d.getMonth() + 1),
						day = '' + d.getDate(),
						year = d.getFullYear();

					if (month.length < 2) month = '0' + month;
					if (day.length < 2) day = '0' + day;

					return [day, month, year].join('/');
				}
				
				
				var prevpolicyexDate = $rootScope.buyNow.twoWheeler.prevPolicyDetails.prevPolExpDate;
				var arr = prevpolicyexDate.split('/');
				prevpolicyexDate = arr[1] + '/' + arr[0] + '/' + arr[2]; //mm/dd/yyyy
				var newFrmt = new Date(prevpolicyexDate);
				
				var loginDate1 = CommonServices.getCommonData('LoginData').systemDate;
				$scope.loginDate = new Date(loginDate1);
				var todaysDate = "";
				/* if ($scope.loginDate >= newFrmt) { */
				if (newFrmt >=$scope.loginDate) {
				newFrmt.setDate(newFrmt.getDate() + 1);
				var dd = newFrmt.getDate();
				var mm = newFrmt.getMonth()+1;
				var yyyy = newFrmt.getFullYear();
				 if (dd < 10) {
					dd = "0" + dd;
				}

				if (mm < 10) {
					mm = "0" + mm;
				}
					$rootScope.buyNow.twoWheeler.quickQuote.policyStartDate = dd + "/" + mm + "/" + yyyy; //policy start date
					var polstartDateTW = $rootScope.buyNow.twoWheeler.quickQuote.policyStartDate;
					var arr = polstartDateTW.split('/');
					polstartDateTW = arr[1] + '/' + arr[0] + '/' + arr[2]; //mm/dd/yyyy
					var polEndDateTW = addYears(polstartDateTW);
					$rootScope.buyNow.twoWheeler.quickQuote.policyExpiryDate = polEndDateTW;
					$rootScope.buyNow.twoWheeler.additionalDetails.policyStartDate = $rootScope.buyNow.twoWheeler.quickQuote.policyStartDate;
					$rootScope.buyNow.twoWheeler.additionalDetails.policyExpiryDate = $rootScope.buyNow.twoWheeler.quickQuote.policyExpiryDate;
					$rootScope.buyNow.twoWheeler.additionalDetails.durInDays = '365';
				} else {
					$rootScope.buyNow.twoWheeler.additionalDetails.policyExpiryDate = $rootScope.buyNow.twoWheeler.quickQuote.policyExpiryDate;
					$rootScope.buyNow.twoWheeler.additionalDetails.policyStartDate = $rootScope.buyNow.twoWheeler.quickQuote.policyStartDate;
				}
		
				/* var selectedDate = $rootScope.buyNow.twoWheeler.prevPolicyDetails.prevPolExpDate;
				var minFtArr = selectedDate.split("/");
				selectedDate = minFtArr[1] + '/' + minFtArr[0] + '/' + minFtArr[2];

				var newFormat1 = new Date(selectedDate);

				var sysDt = CommonServices.getCommonData("serverDate");
				var newFormat2 = new Date(sysDt);

				var timeDiff = (newFormat2.getTime() > newFormat1.getTime()); */

				/* var addYearsWithTerm = function (todaysDate, term) {//To Use

					var dt = new Date(todaysDate);
					var newDate = new Date(dt.getFullYear() + term, dt.getMonth(), dt.getDate() - 1);
					var d = new Date(newDate || Date.now()),

						month = '' + (d.getMonth() + 1),
						day = '' + d.getDate(),
						year = d.getFullYear();

					if (month.length < 2) month = '0' + month;
					if (day.length < 2) day = '0' + day;

					return [day, month, year].join('/');
				}
 */
				/* if(timeDiff === false){*/
				/* var prevPolExpiryDate = $rootScope.buyNow.twoWheeler.prevPolicyDetails.prevPolExpDate;
				var expDateSplit = prevPolExpiryDate.split("/");
				prevPolExpiryDate = expDateSplit[1] + '/' + expDateSplit[0] + '/' + expDateSplit[2];
				var newFormat = new Date(prevPolExpiryDate);

				newFormat = newFormat.setDate(newFormat.getDate() + 1);
				var newFrmt = new Date(newFormat);


				var monLength = (newFrmt.getMonth() + 1);
				if (monLength < 10) {
					var newPolStartDate = newFrmt.getDate() + '/0' + (newFrmt.getMonth() + 1) + '/' + newFrmt.getFullYear(); //dd/mm/yyyy
				} else {
					var newPolStartDate = newFrmt.getDate() + '/' + (newFrmt.getMonth() + 1) + '/' + newFrmt.getFullYear(); //dd/mm/yyyy
				} */

				/**Prod Issue Resolution **/
				/* var loginDate1 = CommonServices.getCommonData('LoginData').systemDate;
				$scope.loginDate = new Date(loginDate1);
				var todaysDate = "";
				if ($scope.loginDate <= newFrmt) {
					$rootScope.buyNow.twoWheeler.additionalDetails.policyStartDate = newPolStartDate;
					todaysDate = (newFrmt.getMonth() + 1) + '/' + newFrmt.getDate() + '/' + newFrmt.getFullYear();
				}
				else {
					loginDate1 = loginDate1.split("/");
					loginDate1 = loginDate1[1] + '/' + loginDate1[0] + '/' + loginDate1[2];
					$rootScope.buyNow.twoWheeler.additionalDetails.policyStartDate = loginDate1;
					todaysDate = ($scope.loginDate.getMonth() + 1) + '/' + $scope.loginDate.getDate() + '/' + $scope.loginDate.getFullYear();
				} */
				/**Prod Issue Resolution **/

				/* $rootScope.twBasicPremium = parseInt($rootScope.twBasicPremium);//To Use
				if ($rootScope.twBasicPremium > 1) {//To Use
					var policyExpiryDate = addYearsWithTerm(todaysDate, $rootScope.twBasicPremium);
				} else {//To Use
					var policyExpiryDate = addYears(todaysDate);
				}

				$rootScope.buyNow.twoWheeler.additionalDetails.policyExpiryDate = policyExpiryDate; */
			} else {

				$rootScope.buyNow.twoWheeler.additionalDetails.policyExpiryDate = $rootScope.buyNow.twoWheeler.quickQuote.policyExpiryDate;
				$rootScope.buyNow.twoWheeler.additionalDetails.policyStartDate = $rootScope.buyNow.twoWheeler.quickQuote.policyStartDate;
			}
		} else {

			$rootScope.buyNow.twoWheeler.additionalDetails.policyExpiryDate = $rootScope.buyNow.twoWheeler.quickQuote.policyExpiryDate;
			$rootScope.buyNow.twoWheeler.additionalDetails.policyStartDate = $rootScope.buyNow.twoWheeler.quickQuote.policyStartDate;

		}
	  } 	else {
			$rootScope.buyNow.twoWheeler.additionalDetails.policyExpiryDate = $rootScope.buyNow.twoWheeler.quickQuote.policyExpiryDate;
			$rootScope.buyNow.twoWheeler.additionalDetails.policyStartDate = $rootScope.buyNow.twoWheeler.quickQuote.policyStartDate;
		}

		var polStDateArr = $rootScope.buyNow.twoWheeler.additionalDetails.policyStartDate;
		var polEndDateArr = $rootScope.buyNow.twoWheeler.additionalDetails.policyExpiryDate;
		var arr1 = polStDateArr.split("/");
		var arr2 = polEndDateArr.split("/");
		$scope.policyDuration = arr2[2] - arr1[2];

		if ($rootScope.buyNow.twoWheeler.basicPremium.coverage === "L") {
			$scope.coverageSelectedForSaveQuote = "LIABILITY";
		} else if ($rootScope.buyNow.twoWheeler.basicPremium.coverage === "P") {
			$scope.coverageSelectedForSaveQuote = "PACKAGE";
		}
		//added for CR_0926 start
		else if ($rootScope.buyNow.twoWheeler.basicPremium.coverage === "E5") {
			$scope.coverageSelectedForSaveQuote = "EHMNTCOVER";
		} else if ($rootScope.buyNow.twoWheeler.basicPremium.coverage === "P5") {
			$scope.coverageSelectedForSaveQuote = "PACKAGE";
		}
		//added for CR_0926 End
		else {
			$scope.coverageSelectedForSaveQuote = "EHMNTCOVER";
		}


		if ($rootScope.buyNow.twoWheeler.additionalDetails.dateOfRegTW != "" && $rootScope.buyNow.twoWheeler.additionalDetails.dateOfRegTW != undefined && $rootScope.buyNow.twoWheeler.additionalDetails.dateOfRegTW != null) {
			//calculate Registration Expiry Date
			var regDate = $rootScope.buyNow.twoWheeler.additionalDetails.dateOfRegTW;
			var redDateArr = regDate.split("/");
			redDateArr = redDateArr[1] + "/" + redDateArr[0] + "/" + redDateArr[2]; // mm/dd/yyyy
			var formatRegDate = new Date(redDateArr);

			regDate = (formatRegDate.getMonth() + 1) + '/' + formatRegDate.getDate() + '/' + formatRegDate.getFullYear();
			var dt = new Date(regDate);
			var newDate = new Date((dt.getFullYear() + 15), dt.getMonth(), dt.getDate() - 1);

			month = '' + (newDate.getMonth() + 1),
				day = '' + newDate.getDate(),
				year = newDate.getFullYear();

			if (month.length < 2) month = '0' + month;
			if (day.length < 2) day = '0' + day;

			$scope.regExpDate = [day, month, year].join('/');


		} else {
			//Assign Registration Expiry Date to null
			$scope.regExpDate = null;
		}

		/*Added during CR_NP_0752 */
		var nameOfPrevInsur = $rootScope.buyNow.twoWheeler.prevPolicyDetails.nameOfPrevIns;
		var prevInsDetails;
		for (var i = 0; i < $rootScope.previousInsurersList.length; i++) {
			if ($rootScope.previousInsurersList[i].codeValue == nameOfPrevInsur) {
				prevInsDetails = $rootScope.previousInsurersList[i].codeValue;
				break;
			} else if ($rootScope.previousInsurersList[i].mnemonic == nameOfPrevInsur) {
				prevInsDetails = $rootScope.previousInsurersList[i].codeValue;
				break;
			} else if ("Not Available" === nameOfPrevInsur) {
				prevInsDetails = "Option25";
				break;
			} else {
				prevInsDetails = null;
			}
		}
		/*CR_NP_0752 Ends */
		/*CR_np_941_start*/
		var durationForPaOwnerDriverCover ="";
			if( $rootScope.buyNow.twoWheeler.addCovers.DurationForPaOwnerDriverCover==="First Year"){
			 durationForPaOwnerDriverCover="OneYear";
			}
			else if( $rootScope.buyNow.twoWheeler.addCovers.DurationForPaOwnerDriverCover==="Full Policy duration"){
			durationForPaOwnerDriverCover="LongTerm";
			}
		
		
		/*CR_np_941_s end */

		/*Added for NP_CR_3444 Start*/
			if ($scope.buyNow.twoWheeler.addCovers.compulsoryPACoverPolicy === undefined || $scope.buyNow.twoWheeler.addCovers.compulsoryPACoverPolicy === "") {
            $rootScope.buyNow.twoWheeler.addCovers.compulsoryPACoverPolicy = null;
        }
        else {
				if($scope.buyNow.twoWheeler.addCovers.compulsoryPACoverPolicy==="YES"){
				$rootScope.buyNow.twoWheeler.addCovers.compulsoryPACoverPolicy="Y"
				}
				else if($scope.buyNow.twoWheeler.addCovers.compulsoryPACoverPolicy==="NO"){
				$rootScope.buyNow.twoWheeler.addCovers.compulsoryPACoverPolicy="N"
				}
        }
		if ($scope.buyNow.twoWheeler.addCovers.sumInsuredOfAtleast15lacs === undefined || $scope.buyNow.twoWheeler.addCovers.sumInsuredOfAtleast15lacs === "") {
            $rootScope.buyNow.twoWheeler.addCovers.sumInsuredOfAtleast15lacs = null;
        }
        else {
				if($scope.buyNow.twoWheeler.addCovers.sumInsuredOfAtleast15lacs==="YES"){
				$rootScope.buyNow.twoWheeler.addCovers.sumInsuredOfAtleast15lacs="Y"
				}
				else if($scope.buyNow.twoWheeler.addCovers.sumInsuredOfAtleast15lacs==="NO"){
				$rootScope.buyNow.twoWheeler.addCovers.sumInsuredOfAtleast15lacs="N"
				}
        }
		/*Start Remove for CR_3444B
		if ($scope.buyNow.twoWheeler.addCovers.paCoverForAnyOtherVehicle === undefined || $scope.buyNow.twoWheeler.addCovers.paCoverForAnyOtherVehicle === "") {
            $rootScope.buyNow.twoWheeler.addCovers.paCoverForAnyOtherVehicle = null;
        }
        else {
				if($scope.buyNow.twoWheeler.addCovers.paCoverForAnyOtherVehicle==="YES"){
				$rootScope.buyNow.twoWheeler.addCovers.paCoverForAnyOtherVehicle="Y"
				}
				else if($scope.buyNow.twoWheeler.addCovers.paCoverForAnyOtherVehicle==="NO"){
				$rootScope.buyNow.twoWheeler.addCovers.paCoverForAnyOtherVehicle="N"
				}
            }
		End Remove for CR_3444B*/
		/*Added for NP_CR_3444 Start*/
		/*Added for NP_CR_0898 Start*/
		if ($scope.buyNow.twoWheeler.enhancementCoverages.nilDepreciation === undefined || $scope.buyNow.twoWheeler.enhancementCoverages.nilDepreciation === "") {
			if($rootScope.nillEnd)
			{
			   $rootScope.buyNow.twoWheeler.enhancementCoverages.nilDepreciation = "Y";
			}
			else
			{
            $rootScope.buyNow.twoWheeler.enhancementCoverages.nilDepreciation = "N";
			}
        }
        else {
				if($scope.buyNow.twoWheeler.enhancementCoverages.nilDepreciation==="YES"){
				$rootScope.buyNow.twoWheeler.enhancementCoverages.nilDepreciation="Y"
				}
				else if($scope.buyNow.twoWheeler.enhancementCoverages.nilDepreciation==="NO"){
				$rootScope.buyNow.twoWheeler.enhancementCoverages.nilDepreciation="N"
				}
        }
		if ($scope.buyNow.twoWheeler.enhancementCoverages.roadTaxCover === undefined || $scope.buyNow.twoWheeler.enhancementCoverages.roadTaxCover === "") {
            $rootScope.buyNow.twoWheeler.enhancementCoverages.roadTaxCover = "N";
        }
        else {
				if($scope.buyNow.twoWheeler.enhancementCoverages.roadTaxCover==="YES"){
				$rootScope.buyNow.twoWheeler.enhancementCoverages.roadTaxCover="Y"
				}
				else if($scope.buyNow.twoWheeler.enhancementCoverages.roadTaxCover==="NO"){
				$rootScope.buyNow.twoWheeler.enhancementCoverages.roadTaxCover="N"
				}
        }
		if ($scope.buyNow.twoWheeler.enhancementCoverages.invoiceCover === undefined || $scope.buyNow.twoWheeler.enhancementCoverages.invoiceCover === "") {
            $rootScope.buyNow.twoWheeler.enhancementCoverages.invoiceCover = "N";
        }
        else {
				if($scope.buyNow.twoWheeler.enhancementCoverages.invoiceCover==="YES"){
				$rootScope.buyNow.twoWheeler.enhancementCoverages.invoiceCover="Y"
				}
				else if($scope.buyNow.twoWheeler.enhancementCoverages.invoiceCover==="NO"){
				$rootScope.buyNow.twoWheeler.enhancementCoverages.invoiceCover="N"
				}
            }
			if ($scope.buyNow.twoWheeler.enhancementCoverages.ncbProtectionCover === undefined || $scope.buyNow.twoWheeler.enhancementCoverages.ncbProtectionCover === "") {
            $rootScope.buyNow.twoWheeler.enhancementCoverages.ncbProtectionCover = "N";
        }
        else {
				if($scope.buyNow.twoWheeler.enhancementCoverages.ncbProtectionCover ==="YES"){
				$rootScope.buyNow.twoWheeler.enhancementCoverages.ncbProtectionCover ="Y"
				}
				else if($scope.buyNow.twoWheeler.enhancementCoverages.ncbProtectionCover==="NO"){
				$rootScope.buyNow.twoWheeler.enhancementCoverages.ncbProtectionCover="N"
				}
        }
		if ($scope.buyNow.twoWheeler.enhancementCoverages.engineProtectCover === undefined || $scope.buyNow.twoWheeler.enhancementCoverages.engineProtectCover === "") 		  {
            $rootScope.buyNow.twoWheeler.enhancementCoverages.engineProtectCover = "N";
        }
        else {
				if($scope.buyNow.twoWheeler.enhancementCoverages.engineProtectCover==="YES"){
				$rootScope.buyNow.twoWheeler.enhancementCoverages.engineProtectCover="Y"
				}
				else if($scope.buyNow.twoWheeler.enhancementCoverages.engineProtectCover==="NO"){
				$rootScope.buyNow.twoWheeler.enhancementCoverages.engineProtectCover="N"
				}
        }
		if ($scope.buyNow.twoWheeler.enhancementCoverages.consumableItemsCover === undefined || $scope.buyNow.twoWheeler.enhancementCoverages.consumableItemsCover === "") {
            $rootScope.buyNow.twoWheeler.enhancementCoverages.consumableItemsCover = "N";
        }
        else {
				if($scope.buyNow.twoWheeler.enhancementCoverages.consumableItemsCover==="YES"){
				$rootScope.buyNow.twoWheeler.enhancementCoverages.consumableItemsCover="Y"
				}
				else if($scope.buyNow.twoWheeler.enhancementCoverages.consumableItemsCover==="NO"){
				$rootScope.buyNow.twoWheeler.enhancementCoverages.consumableItemsCover="N"
				}
            }
			if ($scope.buyNow.twoWheeler.enhancementCoverages.roadTaxAmount === undefined || $scope.buyNow.twoWheeler.enhancementCoverages.roadTaxAmount === "") {
			$rootScope.buyNow.twoWheeler.enhancementCoverages.roadTaxAmount = 0;
		}
		else {
			$rootScope.buyNow.twoWheeler.enhancementCoverages.roadTaxAmount = $scope.buyNow.twoWheeler.enhancementCoverages.roadTaxAmount;
		}
		
		if($scope.buyNow.twoWheeler.addCovers.extensionToSriLanka===true){
		$rootScope.buyNow.twoWheeler.addCovers.extensionToSriLanka="Y";
		}else if($scope.buyNow.twoWheeler.addCovers.extensionToSriLanka===false){
		$rootScope.buyNow.twoWheeler.addCovers.extensionToSriLanka="N";
		}
		if($scope.buyNow.twoWheeler.addCovers.extensionToBhutan===true){
		$rootScope.buyNow.twoWheeler.addCovers.extensionToBhutan="Y";
		}else if($scope.buyNow.twoWheeler.addCovers.extensionToBhutan===false){
		$rootScope.buyNow.twoWheeler.addCovers.extensionToBhutan="N";
		}
		if($scope.buyNow.twoWheeler.addCovers.extensionToNepal===true){
		$rootScope.buyNow.twoWheeler.addCovers.extensionToNepal="Y";
		}else if($scope.buyNow.twoWheeler.addCovers.extensionToNepal===false){
		$rootScope.buyNow.twoWheeler.addCovers.extensionToNepal="N";
		}
		if($scope.buyNow.twoWheeler.addCovers.extensionToPakistan===true){
		$rootScope.buyNow.twoWheeler.addCovers.extensionToPakistan="Y";
		}else if($scope.buyNow.twoWheeler.addCovers.extensionToPakistan===false){
		$rootScope.buyNow.twoWheeler.addCovers.extensionToPakistan="N";
		}
		if($scope.buyNow.twoWheeler.addCovers.extensionToMaldives===true){
		$rootScope.buyNow.twoWheeler.addCovers.extensionToMaldives="Y";
		}else if($scope.buyNow.twoWheeler.addCovers.extensionToMaldives===false){
		$rootScope.buyNow.twoWheeler.addCovers.extensionToMaldives="N";
		}
		if($scope.buyNow.twoWheeler.addCovers.extensionToBangladesh===true){
		$rootScope.buyNow.twoWheeler.addCovers.extensionToBangladesh="Y";
		}else if($scope.buyNow.twoWheeler.addCovers.extensionToBangladesh===false){
		$rootScope.buyNow.twoWheeler.addCovers.extensionToBangladesh="N";
		}
		if($scope.buyNow.twoWheeler.addCovers.extensionOfGeographicalAreaRequired===true){
		$rootScope.buyNow.twoWheeler.addCovers.extensionOfGeographicalAreaRequired="Y";
		}else if($scope.buyNow.twoWheeler.addCovers.extensionOfGeographicalAreaRequired===false){
		$rootScope.buyNow.twoWheeler.addCovers.extensionOfGeographicalAreaRequired="N";
		$rootScope.buyNow.twoWheeler.addCovers.extensionToSriLanka="N";
		$rootScope.buyNow.twoWheeler.addCovers.extensionToBhutan="N";
		$rootScope.buyNow.twoWheeler.addCovers.extensionToPakistan="N";
		$rootScope.buyNow.twoWheeler.addCovers.extensionToMaldives="N";
		$rootScope.buyNow.twoWheeler.addCovers.extensionToBangladesh="N";
		$rootScope.buyNow.twoWheeler.addCovers.extensionToNepal="N";

		}
		
		
		/*Added for NP_CR_0898  End*/
			//CR- 3868
			var discount = "0";
			if ($rootScope.buyNow.twoWheeler.additionalDetails.discountPercModel) {
				discount = $rootScope.buyNow.twoWheeler.additionalDetails.discountPercModel;
			}
						
	if(CommonServices.SQParentPolicyHistory === true){
			var saveQuoteTWInputData =
			{
				"quote": {
					"additionalQuoteDetails": {
						"isServiceTaxExempted": "N"
					},
					"policyDuration": $scope.policyDuration,
					"policyDurationUnit": "Year",
					"policyExpiryDate": $rootScope.buyNow.twoWheeler.additionalDetails.policyExpiryDate,
					"policyHolderCode": $scope.buyNow.twoWheeler.insuredDetails.partyCode,
					"policyStartDate": $rootScope.buyNow.twoWheeler.additionalDetails.policyStartDate,
					"premiumDetails": {
					},
					"previousPolicyDetails": {
						"addressofPreviousInsurer": "",
						"anyClaimPendingOrPaidOnPolicyWhichIsToBeRenewed": $rootScope.buyNow.twoWheeler.ncbDetails.ncbClaimStatusTW,
						"nameofPreviousInsurer": prevInsDetails,
						"nCBApplicablePercentage": $rootScope.buyNow.twoWheeler.ncbDetails.ncbApplicablePerc,
						"nCBfromPreviousPolicy": $rootScope.buyNow.twoWheeler.ncbDetails.ncbOnPrevPolicyTW,
						"nCBPercentOnPreviousPolicy": $rootScope.buyNow.twoWheeler.ncbDetails.ncbPercOnPrevPolicyTW,
						"previousPolicyExpiryDate": $rootScope.buyNow.twoWheeler.prevPolicyDetails.prevPolExpDate,
						"previousPolicyNo": $rootScope.buyNow.twoWheeler.prevPolicyDetails.prevPolNum
					},
					"standaloneODdetails":{  
						 "bundInsName":$rootScope.buyNow.twoWheeler.StandaloneODDetails.nameOfPrevIns,
						 "bundPolNo":$rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyNo,
						 "bundstdate":$rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyStartDate,
						 "bundexpdate":$rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyExpiryDate,
						 "bundPolCoverage":$rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyType,
						 "durInDays":$rootScope.buyNow.twoWheeler.additionalDetails.durInDays
					 },
					"productCode": "SQ",
					"salesChannel": {
						"salesDiscounts": [
							{
								"discountPercentage": $rootScope.buyNow.twoWheeler.quickQuote.discountPercentage,
								"inputDiscountPercentage": discount,//$rootScope.buyNow.twoWheeler.additionalDetails.discountPercModel,
								"inputDiscountAmt": $rootScope.buyNow.twoWheeler.additionalDetails.loadingDiscountPercModel,
								"discountType": $rootScope.buyNow.twoWheeler.quickQuote.discountType,
							}
						]
					},
					"vehicles": [
						{
							"coverages": [
								{
									"additionalCoverageDetails": {
										"additionalTowingCoverageAmount": "0",
										"capitalSIForAllNamedPersons": "0",
										"extensionOfGeographicalAreaRequired": $rootScope.buyNow.twoWheeler.addCovers.extensionOfGeographicalAreaRequired,//CR_NP_0898
										"extensionToBangladesh": $rootScope.buyNow.twoWheeler.addCovers.extensionToBangladesh,//CR_NP_0898
										"extensionToBhutan": $rootScope.buyNow.twoWheeler.addCovers.extensionToBhutan,//CR_NP_0898
										"extensionToMaldives": $rootScope.buyNow.twoWheeler.addCovers.extensionToMaldives,//CR_NP_0898
										"extensionToNepal": $rootScope.buyNow.twoWheeler.addCovers.extensionToNepal,//CR_NP_0898
										"extensionToPakistan": $rootScope.buyNow.twoWheeler.addCovers.extensionToPakistan,//CR_NP_0898
										"extensionToSriLanka": $rootScope.buyNow.twoWheeler.addCovers.extensionToSriLanka,//CR_NP_0898
										"includePACoverForNamedPerson": "N",
										"individualSIForNamedPerson": "0",
										"lltoEmployeesOfInsuredTravelingAndOrDrivingTheVehicle": "N",
										"lltoPaidDriversCleanerEmployed": "N",
										"lltoSoldiersOrSailorsOrAirmenEmployedAsDrivers": "N",
										"lossOfAccesoriesCover": "N",
										"namesOfNamedPerson": [
											null
										],
										"numberOfLegalLiableDrivers": "0",
										"numberOfLegalLiableEmployees": "0",
										"numberOfLLSoldiersOrSailorsOrAirmen": "0",
										"numberOfNamedPersons": "1",
										"pacoverForPaidDrivers": 0,
										"pacoverForUnnamedPersonOrHirerOrPillionPassengers": $rootScope.buyNow.twoWheeler.addCovers.indSIforUnnamedPerson !== null && $rootScope.buyNow.twoWheeler.addCovers.indSIforUnnamedPerson !== undefined ? $rootScope.buyNow.twoWheeler.addCovers.indSIforUnnamedPerson : 0,
										"reduceTPPDCover": "N",
										"selectPolicyDurationForPAToOwnerDriverCover": durationForPaOwnerDriverCover//cr_np_941  Start
									},
									"addOnEnhancementCoverages": {
									  "inclusionOfRoadTaxCover":  $rootScope.buyNow.twoWheeler.enhancementCoverages.roadTaxCover,//Added NP_CR_0898
									  "consumableItemsCover":  $rootScope.buyNow.twoWheeler.enhancementCoverages.consumableItemsCover,//Added NP_CR_0898
									  "nilDepreciation":  	  $rootScope.buyNow.twoWheeler.enhancementCoverages.nilDepreciation,//Added NP_CR_0898
									  "returnToInvoiceCover":  $rootScope.buyNow.twoWheeler.enhancementCoverages.invoiceCover,//Added NP_CR_0898
									  "ncbProtectionCover":  $rootScope.buyNow.twoWheeler.enhancementCoverages.ncbProtectionCover,//Added NP_CR_0898
									  "engineProtectCover":  $rootScope.buyNow.twoWheeler.enhancementCoverages.engineProtectCover,//Added NP_CR_0898
									  "roadTaxAmount":      $rootScope.buyNow.twoWheeler.enhancementCoverages.roadTaxAmount,//Added NP_CR_0898
									  "siForReturnToInvoice":$rootScope.buyNow.twoWheeler.enhancementCoverages.returnToInvoiceSI//Added NP_CR_0898
									},
									"coverageDetails": {
										"coverage": $scope.coverageSelectedForSaveQuote,
										"nomineeDetails": {

										},
										"typeOfLiabilityCoverage": "A"
									}
								}
							],
							"vehicleDetails": {
								"additionalVehicleDetails": {
									"imposedExcess": "0",
									"policyExcess": $rootScope.buyNow.twoWheeler.additionalDetails.polExcessTW,
									"vehicleBelongsTo": "N",
									"vehicleRequistionedByGovt": "N",
									"vehicleUsedForDrivingTution": "N"
								},
								"chassisNo": $rootScope.buyNow.twoWheeler.additionalDetails.chassisNumTW,
								"cityOfPurchase": $rootScope.buyNow.twoWheeler.quickQuote.vehicleCity,
								"colorAsPerRCbook": $rootScope.buyNow.twoWheeler.additionalDetails.clrRCBookTW,
								"totalIDV": $rootScope.buyNow.twoWheeler.quickQuote.insuredDeclaredValue,
								"colorOfVehicle": $rootScope.buyNow.twoWheeler.additionalDetails.colorOfvehicle,
								"cubicCapacity": CommonServices.getCommonData("SQPolicyDetails").vehicles[0].vehicleDetails.cubicCapacity,
								"dateOfFirstPurchaseOfVehicle": $rootScope.buyNow.twoWheeler.quickQuote.dateOfPurchaseReg,
								"dateOfRegistration": $rootScope.buyNow.twoWheeler.additionalDetails.dateOfRegTW,
								"registrationExpiryDate": $scope.regExpDate,
								"discountDetails": {
									"lifeMember": "Y",
									"memberOfAutomobileAssociationOfIndia": "N",
									"vehicleCertifiedByVinatageOrClassicCarClub": "N",
									"vehicleDesignedFor": "N",
									"vehicleFittedWithAntiTheftedDevices": "N",
									"vehicleUseLimitedToOwnPremises": "N",
									"voluntaryExcess": ""
								},
								"doYouHoldValidDrivingLicense": $rootScope.buyNow.twoWheeler.addCovers.ownerDriveVehOrNotTW,
								"engineNo": $rootScope.buyNow.twoWheeler.additionalDetails.engineNumTW,
								"extraElectricalElectronicFittings": "N",
								"financierDetails": {
									"name": $rootScope.buyNow.twoWheeler.financierDetails.financierName,
									"typeOfAgreement": $rootScope.buyNow.twoWheeler.financierDetails.typeOfFinancier
								},
								"idvofAccessories": 0,
								"inBuiltBifuelSystemfitted": $rootScope.buyNow.twoWheeler.additionalDetails.inbuiltBiFuelSysTW,
								"insuredsDeclaredValue": $rootScope.buyNow.twoWheeler.quickQuote.insuredDeclaredValue,
								"isSideCarAttached": "N",
								"make": $rootScope.buyNow.twoWheeler.quickQuote.make,
								"model": $rootScope.buyNow.twoWheeler.quickQuote.vehicleModel,
								"newVehicle": $rootScope.buyNow.twoWheeler.newVehicle,
								"nomineeDetails": {
									"name": $rootScope.buyNow.twoWheeler.addCovers.nameOfNominee,
									"age": $rootScope.buyNow.twoWheeler.addCovers.ageOfNominee,
									"relationshipWithInsured": $rootScope.buyNow.twoWheeler.addCovers.relnWithInsured
								},
								"ownerDetails": {
									"licenseTypeOwnerDriver": $rootScope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner,
									"standAloneCompulsoryPACover": $rootScope.buyNow.twoWheeler.addCovers.compulsoryPACoverPolicy,
								    "pAPolicyWithSumInsured": $rootScope.buyNow.twoWheeler.addCovers.sumInsuredOfAtleast15lacs
	
								},
								"registrationNo1": $rootScope.buyNow.twoWheeler.additionalDetails.reg1TW,
								"registrationNo2": $rootScope.buyNow.twoWheeler.additionalDetails.reg2TW,
								"registrationNo3": $rootScope.buyNow.twoWheeler.additionalDetails.reg3TW,
								"registrationNo4": $rootScope.buyNow.twoWheeler.additionalDetails.reg4TW,
								"seatingCapacityIncludingDriver": CommonServices.getCommonData("SQPolicyDetails").vehicles[0].vehicleDetails.seatingCapacityIncludingDriver,
								"totalValueOfExtraElectricalElectronicFittingsInRs": "0",
								"trailerAttached": "Y",
								"trailerDetails": [
								],
								"typeOfFuel": $rootScope.buyNow.twoWheeler.additionalDetails.typeOfFuelTW,
								"wattage":$rootScope.buyNow.twoWheeler.additionalDetails.wattageInKW, //CR_3633
								"valueOfACFan": "0",
								"valueOfBifuelsystemInRs": $rootScope.buyNow.twoWheeler.additionalDetails.valOfBiFuelSysTW,
								"valueOfFibreGlassFuelTanksInRs": "0",
								"valueOfLights": "0",
								"valueOfMusicSystem": "0",
								"valueOfNonElectricalElectronicFittingsInRs": "0",
								"valueOfOtherFittIngs": "0",
								"variant": CommonServices.getCommonData("SQPolicyDetails").vehicles[0].vehicleDetails.variant,
								"vehicleInvoiceValue": $rootScope.buyNow.twoWheeler.additionalDetails.vehInVoiceValTW,
								"vehicleZone": $rootScope.buyNow.twoWheeler.additionalDetails.vehZoneTW,
								"yearOfManufacture": $rootScope.buyNow.twoWheeler.additionalDetails.yrOfManufactureTW
							}
						}
					]
				},
				"userProfile": {
					"loggedInRole": "SUPERUSER",
					"userId": CommonServices.getCommonData("userId")
				}
			} 
		} else {
		var saveQuoteTWInputData =
			{
				"quote": {
					"additionalQuoteDetails": {
						"isServiceTaxExempted": "N"
					},
					"policyDuration": $scope.policyDuration,
					"policyDurationUnit": "Year",
					"policyExpiryDate": $rootScope.buyNow.twoWheeler.additionalDetails.policyExpiryDate,
					"policyHolderCode": $scope.buyNow.twoWheeler.insuredDetails.partyCode,
					"policyStartDate": $rootScope.buyNow.twoWheeler.additionalDetails.policyStartDate,
					"premiumDetails": {
					},
					"previousPolicyDetails": {
						"addressofPreviousInsurer": "",
						"anyClaimPendingOrPaidOnPolicyWhichIsToBeRenewed": $rootScope.buyNow.twoWheeler.ncbDetails.ncbClaimStatusTW,
						"nameofPreviousInsurer": prevInsDetails,
						"nCBApplicablePercentage": $rootScope.buyNow.twoWheeler.ncbDetails.ncbApplicablePerc,
						"nCBfromPreviousPolicy": $rootScope.buyNow.twoWheeler.ncbDetails.ncbOnPrevPolicyTW,
						"nCBPercentOnPreviousPolicy": $rootScope.buyNow.twoWheeler.ncbDetails.ncbPercOnPrevPolicyTW,
						"previousPolicyExpiryDate": $rootScope.buyNow.twoWheeler.prevPolicyDetails.prevPolExpDate,
						"previousPolicyNo": $rootScope.buyNow.twoWheeler.prevPolicyDetails.prevPolNum
					},
					"standaloneODdetails":{  
						 "bundInsName":$rootScope.buyNow.twoWheeler.StandaloneODDetails.nameOfPrevIns,
						 "bundPolNo":$rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyNo,
						 "bundstdate":$rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyStartDate,
						 "bundexpdate":$rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyExpiryDate,
						 "bundPolCoverage":$rootScope.buyNow.twoWheeler.StandaloneODDetails.ODpolicyType,
						 "durInDays":$rootScope.buyNow.twoWheeler.additionalDetails.durInDays
					 },
					"productCode": "SQ",
					"salesChannel": {
						"salesDiscounts": [
							{
								"discountPercentage": $rootScope.buyNow.twoWheeler.quickQuote.discountPercentage,
								"inputDiscountPercentage": discount,//$rootScope.buyNow.twoWheeler.additionalDetails.discountPercModel,
								"inputDiscountAmt": $rootScope.buyNow.twoWheeler.additionalDetails.loadingDiscountPercModel,
								"discountType": $rootScope.buyNow.twoWheeler.quickQuote.discountType,
							}
						]
					},
					"vehicles": [
						{
							"coverages": [
								{
									"additionalCoverageDetails": {
										"additionalTowingCoverageAmount": "0",
										"capitalSIForAllNamedPersons": "0",
										"extensionOfGeographicalAreaRequired": $rootScope.buyNow.twoWheeler.addCovers.extensionOfGeographicalAreaRequired,//CR_NP_0898
										"extensionToBangladesh": $rootScope.buyNow.twoWheeler.addCovers.extensionToBangladesh,//CR_NP_0898
										"extensionToBhutan": $rootScope.buyNow.twoWheeler.addCovers.extensionToBhutan,//CR_NP_0898
										"extensionToMaldives": $rootScope.buyNow.twoWheeler.addCovers.extensionToMaldives,//CR_NP_0898
										"extensionToNepal": $rootScope.buyNow.twoWheeler.addCovers.extensionToNepal,//CR_NP_0898
										"extensionToPakistan": $rootScope.buyNow.twoWheeler.addCovers.extensionToPakistan,//CR_NP_0898
										"extensionToSriLanka": $rootScope.buyNow.twoWheeler.addCovers.extensionToSriLanka,//CR_NP_0898
										"includePACoverForNamedPerson": "N",
										"individualSIForNamedPerson": "0",
										"lltoEmployeesOfInsuredTravelingAndOrDrivingTheVehicle": "N",
										"lltoPaidDriversCleanerEmployed": "N",
										"lltoSoldiersOrSailorsOrAirmenEmployedAsDrivers": "N",
										"lossOfAccesoriesCover": "N",
										"namesOfNamedPerson": [
											null
										],
										"numberOfLegalLiableDrivers": "0",
										"numberOfLegalLiableEmployees": "0",
										"numberOfLLSoldiersOrSailorsOrAirmen": "0",
										"numberOfNamedPersons": "1",
										"pacoverForPaidDrivers": 0,
										"pacoverForUnnamedPersonOrHirerOrPillionPassengers": $rootScope.buyNow.twoWheeler.addCovers.indSIforUnnamedPerson !== null && $rootScope.buyNow.twoWheeler.addCovers.indSIforUnnamedPerson !== undefined ? $rootScope.buyNow.twoWheeler.addCovers.indSIforUnnamedPerson : 0,
										"reduceTPPDCover": "N",
										"selectPolicyDurationForPAToOwnerDriverCover": durationForPaOwnerDriverCover//cr_np_941  Start
									},
									"addOnEnhancementCoverages": {
									  "inclusionOfRoadTaxCover":  $rootScope.buyNow.twoWheeler.enhancementCoverages.roadTaxCover,//Added NP_CR_0898
									  "consumableItemsCover":  $rootScope.buyNow.twoWheeler.enhancementCoverages.consumableItemsCover,//Added NP_CR_0898
									  "nilDepreciation":  	  $rootScope.buyNow.twoWheeler.enhancementCoverages.nilDepreciation,//Added NP_CR_0898
									  "returnToInvoiceCover":  $rootScope.buyNow.twoWheeler.enhancementCoverages.invoiceCover,//Added NP_CR_0898
									  "ncbProtectionCover":  $rootScope.buyNow.twoWheeler.enhancementCoverages.ncbProtectionCover,//Added NP_CR_0898
									  "engineProtectCover":  $rootScope.buyNow.twoWheeler.enhancementCoverages.engineProtectCover,//Added NP_CR_0898
									  "roadTaxAmount":      $rootScope.buyNow.twoWheeler.enhancementCoverages.roadTaxAmount,//Added NP_CR_0898
									  "siForReturnToInvoice":$rootScope.buyNow.twoWheeler.enhancementCoverages.returnToInvoiceSI//Added NP_CR_0898
									},
									"coverageDetails": {
										"coverage": $scope.coverageSelectedForSaveQuote,
										"nomineeDetails": {

										},
										"typeOfLiabilityCoverage": "A"
									}
								}
							],
							"vehicleDetails": {
								"additionalVehicleDetails": {
									"imposedExcess": "0",
									"policyExcess": $rootScope.buyNow.twoWheeler.additionalDetails.polExcessTW,
									"vehicleBelongsTo": "N",
									"vehicleRequistionedByGovt": "N",
									"vehicleUsedForDrivingTution": "N"
								},
								"chassisNo": $rootScope.buyNow.twoWheeler.additionalDetails.chassisNumTW,
								"cityOfPurchase": $rootScope.buyNow.twoWheeler.quickQuote.vehicleCity,
								"colorAsPerRCbook": $rootScope.buyNow.twoWheeler.additionalDetails.clrRCBookTW,
								"totalIDV": $rootScope.buyNow.twoWheeler.quickQuote.insuredDeclaredValue,
								"colorOfVehicle": $rootScope.buyNow.twoWheeler.additionalDetails.colorOfvehicle,
								"cubicCapacity": $rootScope.buyNow.twoWheeler.quickQuote.vehicleModel.motorCC,
								"dateOfFirstPurchaseOfVehicle": $rootScope.buyNow.twoWheeler.quickQuote.dateOfPurchaseReg,
								"dateOfRegistration": $rootScope.buyNow.twoWheeler.additionalDetails.dateOfRegTW,
								"registrationExpiryDate": $scope.regExpDate,
								"discountDetails": {
									"lifeMember": "Y",
									"memberOfAutomobileAssociationOfIndia": "N",
									"vehicleCertifiedByVinatageOrClassicCarClub": "N",
									"vehicleDesignedFor": "N",
									"vehicleFittedWithAntiTheftedDevices": "N",
									"vehicleUseLimitedToOwnPremises": "N",
									"voluntaryExcess": ""
								},
								"doYouHoldValidDrivingLicense": $rootScope.buyNow.twoWheeler.addCovers.ownerDriveVehOrNotTW,
								"engineNo": $rootScope.buyNow.twoWheeler.additionalDetails.engineNumTW,
								"extraElectricalElectronicFittings": "N",
								"financierDetails": {
									"name": $rootScope.buyNow.twoWheeler.financierDetails.financierName,
									"typeOfAgreement": $rootScope.buyNow.twoWheeler.financierDetails.typeOfFinancier
								},
								"idvofAccessories": 0,
								"inBuiltBifuelSystemfitted": $rootScope.buyNow.twoWheeler.additionalDetails.inbuiltBiFuelSysTW,
								"insuredsDeclaredValue": $rootScope.buyNow.twoWheeler.quickQuote.insuredDeclaredValue,
								"isSideCarAttached": "N",
								"make": CommonServices.getCommonData("makeCode"),
								"model": $rootScope.buyNow.twoWheeler.quickQuote.vehicleModel.motorModel,
								"newVehicle": $rootScope.buyNow.twoWheeler.newVehicle,
								"nomineeDetails": {
									"name": $rootScope.buyNow.twoWheeler.addCovers.nameOfNominee,
									"age": $rootScope.buyNow.twoWheeler.addCovers.ageOfNominee,
									"relationshipWithInsured": $rootScope.buyNow.twoWheeler.addCovers.relnWithInsured
								},
								"ownerDetails": {
									"licenseTypeOwnerDriver": $rootScope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner,
									"standAloneCompulsoryPACover": $rootScope.buyNow.twoWheeler.addCovers.compulsoryPACoverPolicy,//Added NP_CR_3444
								    "pAPolicyWithSumInsured": $rootScope.buyNow.twoWheeler.addCovers.sumInsuredOfAtleast15lacs//Added NP_CR_3444
								    /*"compulsoryPACoverOtherVehicle": $rootScope.buyNow.twoWheeler.addCovers.paCoverForAnyOtherVehicle*///Added NP_CR_3444B
								},
								"registrationNo1": $rootScope.buyNow.twoWheeler.additionalDetails.reg1TW,
								"registrationNo2": $rootScope.buyNow.twoWheeler.additionalDetails.reg2TW,
								"registrationNo3": $rootScope.buyNow.twoWheeler.additionalDetails.reg3TW,
								"registrationNo4": $rootScope.buyNow.twoWheeler.additionalDetails.reg4TW,
								"seatingCapacityIncludingDriver": $rootScope.buyNow.twoWheeler.quickQuote.vehicleModel.motorCarryingCapacity,
								"totalValueOfExtraElectricalElectronicFittingsInRs": "0",
								"trailerAttached": "Y",
								"trailerDetails": [
								],
								"typeOfFuel": $rootScope.buyNow.twoWheeler.additionalDetails.typeOfFuelTW,
								"wattage":$rootScope.buyNow.twoWheeler.additionalDetails.wattageInKW, //CR_3633
								"valueOfACFan": "0",
								"valueOfBifuelsystemInRs": $rootScope.buyNow.twoWheeler.additionalDetails.valOfBiFuelSysTW,
								"valueOfFibreGlassFuelTanksInRs": "0",
								"valueOfLights": "0",
								"valueOfMusicSystem": "0",
								"valueOfNonElectricalElectronicFittingsInRs": "0",
								"valueOfOtherFittIngs": "0",
								"variant": $rootScope.buyNow.twoWheeler.quickQuote.vehicleModel.motorVariant,
								"vehicleInvoiceValue": $rootScope.buyNow.twoWheeler.additionalDetails.vehInVoiceValTW,
								"vehicleZone": $rootScope.buyNow.twoWheeler.additionalDetails.vehZoneTW,
								"yearOfManufacture": $rootScope.buyNow.twoWheeler.additionalDetails.yrOfManufactureTW
							}
						}
					]
				},
				"userProfile": {
					"loggedInRole": "SUPERUSER",
					"userId": CommonServices.getCommonData("userId")
				}
			} 
		}	
/* added for CR_NP_754 */

		if (CommonServices.getCommonData("userId").substr(0, 2) === "DL" || CommonServices.getCommonData("userId").substr(0, 2) === "MS") {

/* CR_NP_754 ends */
			var response = [];
			for (var i = 0; i < CommonServices.getCommonData("defaultRelationResponse").length; i++) {
				if (CommonServices.getCommonData("defaultRelationResponse")[i].partyCode.trim() !== "") {
					response.push(CommonServices.getCommonData("defaultRelationResponse")[i]);
				}
			}
			saveQuoteTWInputData.quote.partyDetailsList = response;
		}
		if (CommonServices.getCommonData("userId").substr(0, 2) === "DE") {
			saveQuoteTWInputData.quote.partyDetailsList = [];
			if ($rootScope.buyNow.twoWheeler.relationDetails !== undefined && $rootScope.buyNow.twoWheeler.relationDetails !== "") {
				saveQuoteTWInputData.quote.partyDetailsList.push($rootScope.buyNow.twoWheeler.relationDetails);
			}
		}

		if ($rootScope.buyNow.twoWheeler.quickQuote.discountPercentage !== 0) {
			saveQuoteTWInputData.quote.salesChannel.salesDiscounts[0].discountType = "Flexible";
		}

		if ($scope.coverageSelectedForSaveQuote !== "LIABILITY") {//To Use
			if ($scope.policyDuration == "2" || $scope.policyDuration == "3") {
				saveQuoteTWInputData.quote.vehicles[0].coverages[1] = {};
				saveQuoteTWInputData.quote.vehicles[0].coverages[1].coverageDetails = {};
				saveQuoteTWInputData.quote.vehicles[0].coverages[1].coverageDetails.nomineeDetails = {};
				saveQuoteTWInputData.quote.vehicles[0].coverages[1].coverageDetails.coverage = $scope.coverageSelectedForSaveQuote;
				saveQuoteTWInputData.quote.vehicles[0].coverages[1].coverageDetails.typeOfLiabilityCoverage = "A";
				saveQuoteTWInputData.quote.vehicles[0].coverages[1].additionalCoverageDetails = null;
				saveQuoteTWInputData.quote.vehicles[0].coverages[1].addOnEnhancementCoverages = {};

				if ($scope.coverageSelectedForSaveQuote === "EHMNTCOVER") {
					saveQuoteTWInputData.quote.vehicles[0].coverages[1].coverageDetails.coverage = "EHNTCOVER2";
				} else {
					saveQuoteTWInputData.quote.vehicles[0].coverages[1].coverageDetails.coverage = "PACKAGE2";
				}
			}
			if ($scope.policyDuration == "3") {
				saveQuoteTWInputData.quote.vehicles[0].coverages[2] = {};
				saveQuoteTWInputData.quote.vehicles[0].coverages[2].coverageDetails = {};
				saveQuoteTWInputData.quote.vehicles[0].coverages[2].coverageDetails.nomineeDetails = {};
				saveQuoteTWInputData.quote.vehicles[0].coverages[2].coverageDetails.coverage = $scope.coverageSelectedForSaveQuote;
				saveQuoteTWInputData.quote.vehicles[0].coverages[2].coverageDetails.typeOfLiabilityCoverage = "A";
				saveQuoteTWInputData.quote.vehicles[0].coverages[2].additionalCoverageDetails = null;
				saveQuoteTWInputData.quote.vehicles[0].coverages[2].addOnEnhancementCoverages = {};

				if ($scope.coverageSelectedForSaveQuote === "EHMNTCOVER") {
					saveQuoteTWInputData.quote.vehicles[0].coverages[2].coverageDetails.coverage = "EHNTCOVER3";
				} else {
					saveQuoteTWInputData.quote.vehicles[0].coverages[2].coverageDetails.coverage = "PACKAGE3";
				}
			}
			//added for CR_0922 Start
			if ($scope.policyDuration == "5" &&($rootScope.buyNow.twoWheeler.basicPremium.coverage=="P5" ||$rootScope.buyNow.twoWheeler.basicPremium.coverage=="E5")) {
				saveQuoteTWInputData.quote.vehicles[0].coverages[1] = {};
				saveQuoteTWInputData.quote.vehicles[0].coverages[1].coverageDetails = {};
				saveQuoteTWInputData.quote.vehicles[0].coverages[1].coverageDetails.nomineeDetails = {};
				saveQuoteTWInputData.quote.vehicles[0].coverages[1].coverageDetails.coverage = $scope.coverageSelectedForSaveQuote;
				saveQuoteTWInputData.quote.vehicles[0].coverages[1].coverageDetails.typeOfLiabilityCoverage = "A";
				saveQuoteTWInputData.quote.vehicles[0].coverages[1].additionalCoverageDetails = null;
				saveQuoteTWInputData.quote.vehicles[0].coverages[1].addOnEnhancementCoverages = {};

				if ($scope.coverageSelectedForSaveQuote === "EHMNTCOVER" && $rootScope.buyNow.twoWheeler.basicPremium.coverage=="E5") {
					saveQuoteTWInputData.quote.vehicles[0].coverages[1].coverageDetails.coverage = "ENHNEWVCL2";
				} else {
					saveQuoteTWInputData.quote.vehicles[0].coverages[1].coverageDetails.coverage = "PKGNEWVCL2";
				}
				/////******
				saveQuoteTWInputData.quote.vehicles[0].coverages[2] = {};
				saveQuoteTWInputData.quote.vehicles[0].coverages[2].coverageDetails = {};
				saveQuoteTWInputData.quote.vehicles[0].coverages[2].coverageDetails.nomineeDetails = {};
				saveQuoteTWInputData.quote.vehicles[0].coverages[2].coverageDetails.coverage = $scope.coverageSelectedForSaveQuote;
				saveQuoteTWInputData.quote.vehicles[0].coverages[2].coverageDetails.typeOfLiabilityCoverage = "A";
				saveQuoteTWInputData.quote.vehicles[0].coverages[2].additionalCoverageDetails = null;
				saveQuoteTWInputData.quote.vehicles[0].coverages[2].addOnEnhancementCoverages = {};

				if ($scope.coverageSelectedForSaveQuote === "EHMNTCOVER" && $rootScope.buyNow.twoWheeler.basicPremium.coverage=="E5") {
					saveQuoteTWInputData.quote.vehicles[0].coverages[2].coverageDetails.coverage = "ENHNEWVCL3";
				} else {
					saveQuoteTWInputData.quote.vehicles[0].coverages[2].coverageDetails.coverage = "PKGNEWVCL3";
				}
				/////******
				saveQuoteTWInputData.quote.vehicles[0].coverages[3] = {};
				saveQuoteTWInputData.quote.vehicles[0].coverages[3].coverageDetails = {};
				saveQuoteTWInputData.quote.vehicles[0].coverages[3].coverageDetails.nomineeDetails = {};
				saveQuoteTWInputData.quote.vehicles[0].coverages[3].coverageDetails.coverage = $scope.coverageSelectedForSaveQuote;
				saveQuoteTWInputData.quote.vehicles[0].coverages[3].coverageDetails.typeOfLiabilityCoverage = "A";
				saveQuoteTWInputData.quote.vehicles[0].coverages[3].additionalCoverageDetails = null;
				saveQuoteTWInputData.quote.vehicles[0].coverages[3].addOnEnhancementCoverages = {};

				if ($scope.coverageSelectedForSaveQuote === "EHMNTCOVER" && $rootScope.buyNow.twoWheeler.basicPremium.coverage=="E5") {
					saveQuoteTWInputData.quote.vehicles[0].coverages[3].coverageDetails.coverage = "ENHNEWVCL4";
				} else {
					saveQuoteTWInputData.quote.vehicles[0].coverages[3].coverageDetails.coverage = "PKGNEWVCL4";
				}
				/////******
				saveQuoteTWInputData.quote.vehicles[0].coverages[4] = {};
				saveQuoteTWInputData.quote.vehicles[0].coverages[4].coverageDetails = {};
				saveQuoteTWInputData.quote.vehicles[0].coverages[4].coverageDetails.nomineeDetails = {};
				saveQuoteTWInputData.quote.vehicles[0].coverages[4].coverageDetails.coverage = $scope.coverageSelectedForSaveQuote;
				saveQuoteTWInputData.quote.vehicles[0].coverages[4].coverageDetails.typeOfLiabilityCoverage = "A";
				saveQuoteTWInputData.quote.vehicles[0].coverages[4].additionalCoverageDetails = null;
				saveQuoteTWInputData.quote.vehicles[0].coverages[4].addOnEnhancementCoverages = {};

				if ($scope.coverageSelectedForSaveQuote === "EHMNTCOVER" && $rootScope.buyNow.twoWheeler.basicPremium.coverage=="E5") {
					saveQuoteTWInputData.quote.vehicles[0].coverages[4].coverageDetails.coverage = "ENHNEWVCL5";
				} else {
					saveQuoteTWInputData.quote.vehicles[0].coverages[4].coverageDetails.coverage = "PKGNEWVCL5";
				}
				
			}
			//added for CR_0922 end
			
			
		}

		if (CommonServices.getCommonData("quickQuoteNumber") !== undefined && CommonServices.getCommonData("quickQuoteNumber") !== "") {
			saveQuoteTWInputData.quote.quoteNumber = CommonServices.getCommonData("quickQuoteNumber").quote.quoteNumber;
		}
		else {
			saveQuoteTWInputData.quote.quoteNumber = "";
		}
		
        /*CR_0898 Start*/
                 if($rootScope.nillEnd){
        	  saveQuoteTWInputData.quote.vehicles[0].coverages[0].addOnEnhancementCoverages={};
        		 }
        			/*CR_0898 End*/
		//Save and Calculate Premium
		saveQuoteResponse = RestServices.postService(RestServices.urlPathsNewPortal.saveQuoteTWService, saveQuoteTWInputData);
		saveQuoteResponse.then(
			function (response) {
				CommonServices.cover = false;
				if ($rootScope.buyNow.twoWheeler.newVehicle === "Y") {
					$rootScope.buyNow.twoWheeler.newVehicle = true;
				} else {
					$rootScope.buyNow.twoWheeler.newVehicle = false;
				}

				CommonServices.showLoading(false);
				if (response.data.userProfile === undefined) {
					CommonServices.showAlert(response.data.errorMessage);
					// } else if (response.data.userProfile.footer.errorCode == '1'){ //Need to uncomment after testing the service response (For Portal Quotation saved errorCode '1' is coming)
				} else if (response.data.userProfile.footer.errorCode == '0') {//Need to remove after testing the service response
					$rootScope.saveQuotRespData = response.data;
					GetSetResponseService.addsaveQuoteResponseData(response.data);

					//CR821C start "Maruti" will only come for PC product
					if ($rootScope.buyNow.twoWheeler.quickQuote.make === "MARUTI") {
						$rootScope.buyNow.twoWheeler.quickQuote.discountPercentage = $rootScope.saveQuotRespData.quote.salesChannel.salesDiscounts[0].appliedDiscount;
						if (parseInt($rootScope.buyNow.twoWheeler.additionalDetails.discountPercModel) > parseInt($rootScope.buyNow.twoWheeler.quickQuote.discountPercentage)) {
							$rootScope.buyNow.twoWheeler.additionalDetails.discountPercModel = $rootScope.buyNow.twoWheeler.quickQuote.discountPercentage;
						}
					}

					//CR821C end
					CommonServices.setCommonData("CollectionPaymentDetails", response.data.quote);
					CommonServices.fromRecentActivities = false;
					CommonServices.editQuoteBD = true;
					CommonServices.saveQuoteFlag = true;
					if (CommonServices.getCommonData("backFlag") === "summarydetailsBack") {
						$state.go('sqSummaryDetails');
					}
					else {
						$rootScope.reCalPremium = true;
					}


				}
				else if (response.data.userProfile.footer.errorCode != '0') {
					CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
				}
				else {
					CommonServices.showAlert(response.data.errorMessage);
				}
			}, function (error) {
				CommonServices.showLoading(false);
				RestServices.handleWebServiceError(error);
			});
	}
	/*****************Save Quote From Customer End*************************/



	/**********************************************Only For Insured Details Screen************************************************************************/
	$scope.pinCodeModal = false;

	var mydateStr = new Date();
	var mynewdateFrom = "";
	if (mydateStr != undefined) {
		mynewdateFrom = new Date(mydateStr);
	}
	else {
		mynewdateFrom = new Date();
	}

	$scope.back = function () {
		$state.go('sqDetailQuote');
	}


	/**Date of Birth**/
	var dateOfBirthfrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 1100));
	dateOfBirthfrom = new Date(dateOfBirthfrom.setDate(dateOfBirthfrom.getDate() + 1));
	dateOfBirthfrom = getFormattedDate(dateOfBirthfrom);

	var dateOfBirthTo = new Date(new Date().setMonth(mynewdateFrom.getMonth()));
	dateOfBirthTo = new Date(dateOfBirthTo.setDate(dateOfBirthTo.getDate()));
	dateOfBirthTo = getFormattedDate(dateOfBirthTo);
	/**Date of Birth**/

	/**Registration Date**/
	var regDatefrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 1017));
	regDatefrom = new Date(regDatefrom.setDate(regDatefrom.getDate() + 1));
	regDatefrom = getFormattedDate(regDatefrom);

	var regDateTo = new Date(new Date().setMonth(mynewdateFrom.getMonth()));
	regDateTo = new Date(regDateTo.setDate(regDateTo.getDate()));
	regDateTo = getFormattedDate(regDateTo);
	/**Registration Date**/


	

	

	// $scope.registrationDate = function () {
	// 	$("#registrationDate").loadCalendar({
	// 		'enableDateRange': true,
	// 		'enableCalendarFrom': regDatefrom,
	// 		'enableCalendarTo': regDateTo
	// 	});
	// 	return true;
	// };

	$scope.summaryFlag = false;

	setTimeout(function() {
		$('#dateOfBirth').loadCalendar({
			'enableDateRange': true,
			'enableCalendarFrom': dateOfBirthfrom,
			'enableCalendarTo': dateOfBirthTo
		});
	}, 5000);

	$scope.policyDetailsObj = {
		newcustomerFlag: true,
		existingCustomerFlag: false,
		policyHolder: "newPolicyHolder",
		category: "I",
		showSearchResTbl: false,
		noRecords: null,
		showSmallTbl: false,
		fieldDisable: false,
		existingCustomerBtn: true,
		dateOfBirthErr: false,
	

		organizationTypeVal: [{
			id: "E",
			name: "Educational Institution"
		}, {
			id: "F",
			name: "Firm"
		}, {
			id: "T",
			name: "Others"
		}, {
			id: "N",
			name: "Private Limited company"
		}, {
			id: "P",
			name: "PSU(Public Sector Undertaking)"
		}, {
			id: "G",
			name: "Public Limited company"
		}, {
			id: "S",
			name: "Society"
		}],
		gstRegTypeVal: [{
			id: "NCC",
			name: "Normal,Composite,Casual"
		}, {
			id: "NRI",
			name: "NRI"
		}, {
			id: "UNB",
			name: "UN Bodies/Embassy"
		}],
	
		categoryFunc: function (type) {
			if (type === 'O') {
				setTimeout(function () {
					$('#registrationDate').loadCalendar({
						'enableDateRange': true,
						'enableCalendarFrom': regDatefrom,
						'enableCalendarTo': regDateTo
					});
				},5000);
			}
			this.policyHolderFunc(this.policyHolder);
		},
		dateOfBirthFunc: function () {

			var dt1 = $scope.buyNow.twoWheeler.insuredDetails.DOB.split('/'),
				birthDateComp = dt1[1] + '/' + dt1[0] + '/' + dt1[2], //mm/dd/yyyy
				dt2 = $scope.buyNow.twoWheeler.additionalDetails.polStartDateTW.split('/'),
				leaveDateComp = dt2[1] + '/' + dt2[0] + '/' + dt2[2]; //mm/dd/yyyy

			birthDateComp = new Date(birthDateComp);
			leaveDateComp = new Date(leaveDateComp);

			leaveDateComp.setYear(leaveDateComp.getFullYear() - 18);

			if (birthDateComp > leaveDateComp) {
				this.dateOfBirthErr = true;
			}
			else {
				this.dateOfBirthErr = false;
			}
		},
		policyHolderFunc: function (data) {
			CommonServices.setCommonData("backFlag", "");
			this.fieldDisable = false;
			this.existingCustomerBtn = true;
			this.showSmallTbl = false;
			this.showSearchResTbl = false;
			if (data === "existingPolicyHolder") {
				this.existingCustomerFlag = true;
				this.newcustomerFlag = false;
				this.partyCode = "";
				this.EfirstName = "";
				this.ElastName = "";
				this.EmobileNumber = "";
				this.EemailID = "";
				this.organizpartyCode = "";
				this.organizBusinessName = "";
				this.organizmobileNumber = "";
				this.organizemailID = "";
			}
			else if (data === "newPolicyHolder") {

				/*Added by 851587 for CR_NP_0744, commented for CR_NP_0744E*/
				this.panNoInputDisable = false;
				// this.aadhaarInputDisable = false;
				CommonServices.panNoInputDisable = false;
				// CommonServices.aadhaarInputDisable = false;

				$scope.buyNow.twoWheeler.insuredDetails.aadhaarNumber1 = "";
				$scope.buyNow.twoWheeler.insuredDetails.aadhaarNumber2 = "";
				$scope.buyNow.twoWheeler.insuredDetails.aadhaarNumber3 = "";
				/*CR_NP_0744 and CR_NP_0744E Ends*/
				$scope.partyCode = "";
				this.newcustomerFlag = true;
				this.existingCustomerFlag = false;
				$scope.buyNow.twoWheeler.insuredDetails.firstName = "";
				$scope.buyNow.twoWheeler.insuredDetails.middleName = "";
				$scope.buyNow.twoWheeler.insuredDetails.lastName = "";
				$scope.buyNow.twoWheeler.insuredDetails.gender = "";
				$scope.buyNow.twoWheeler.insuredDetails.DOB = "";
				/*
				$scope.buyNow.twoWheeler.insuredDetails.clientNationality = ""; //3712
				$scope.buyNow.twoWheeler.insuredDetails.clientCountry = "";//3712
				*/
				$scope.buyNow.twoWheeler.insuredDetails.buildingNoStreet = "";
				$scope.buyNow.twoWheeler.insuredDetails.pinCode = "";
				$scope.buyNow.twoWheeler.insuredDetails.mobileNo = "";
				$scope.buyNow.twoWheeler.insuredDetails.emailID = "";
				$scope.buyNow.twoWheeler.insuredDetails.panNum = "";
				$scope.buyNow.twoWheeler.insuredDetails.eInsAccNo = "";
				$scope.buyNow.twoWheeler.insuredDetails.gstRegIdType = "";
				$scope.buyNow.twoWheeler.insuredDetails.gstin = "";
				$scope.buyNow.twoWheeler.insuredDetails.uin = "";
				$scope.buyNow.twoWheeler.insuredDetails.polHolderState = "";
				$scope.buyNow.twoWheeler.insuredDetails.polHolderCity = "";
				$scope.disablePinCode = true;
				$scope.disableCity = true;
				$scope.buyNow.twoWheeler.insuredDetails.businessName = "";
				$scope.buyNow.twoWheeler.insuredDetails.registrationNo = "";
				$scope.buyNow.twoWheeler.insuredDetails.registrationDate = "";
				$scope.buyNow.twoWheeler.insuredDetails.typeofOrganization = "";
				$scope.buyNow.twoWheeler.insuredDetails.businessAddress1 = "";
				$scope.buyNow.twoWheeler.insuredDetails.businessAddress2 = "";
				$scope.buyNow.twoWheeler.insuredDetails.businessTelNumOff = "";
				$scope.buyNow.twoWheeler.insuredDetails.businessTelNumExtn = "";
			}
		},
		compareBirthDate: function () {// this will compare the date entered in travel details screen and policy holder screen
			if ($rootScope.travelData.dateOfBirth !== undefined && $rootScope.travelData.savedPartyDetails.partyDetails.individualDetails.dateOfBirth !== undefined) {

				var lossDateComp = $rootScope.travelData.dateOfBirth;
				var drr = lossDateComp.split('/');
				lossDateComp = drr[1] + '/' + drr[0] + '/' + drr[2]; //mm/dd/yyyy

				var policyStartDateComp = $rootScope.travelData.savedPartyDetails.partyDetails.individualDetails.dateOfBirth;
				var srr = policyStartDateComp.split('/');
				policyStartDateComp = srr[1] + '/' + srr[0] + '/' + srr[2]; //mm/dd/yyyy

				lossDateComp = new Date(lossDateComp);
				policyStartDateComp = new Date(policyStartDateComp);
				if (lossDateComp.getTime() === policyStartDateComp.getTime()) {

				}
				else {
					CommonServices.showAlert("Date of birth of the policy holder does not match with the member date of birth.");

				}

			}
			return true;

		},
		gstIDInputChangeFunc: function () { // Onchange of GSTIN input field
			if ($rootScope.buyNow.twoWheeler.insuredDetails.gstRegIdType !== undefined && $rootScope.buyNow.twoWheeler.insuredDetails.gstRegIdType !== "") {
				var reg = "";

				if ($scope.buyNow.twoWheeler.insuredDetails.gstin != undefined && $scope.buyNow.twoWheeler.insuredDetails.gstin.length === 15) {
					$scope.detailQuoteTWScreenForm.gstIN.$invalid = false;
					$scope.detailQuoteTWScreenForm.$invalid = false;
				}
				else {
					$scope.detailQuoteTWScreenForm.gstIN.$invalid = true;
					$scope.detailQuoteTWScreenForm.$invalid = true;
				}

				if ($scope.buyNow.twoWheeler.insuredDetails.gstRegIdType === "NCC") {
					reg = regexGSTidGlobal;///^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[A-Z0-9]{2}[^\s]$/;

					//UC for 3749
				// if(reg){
				// 	if(CommonServices.gstIdStateCode[$scope.buyNow.twoWheeler.insuredDetails.gstin.slice(0,2)] != undefined){
				// 		if($scope.buyNow.twoWheeler.insuredDetails.polHolderState.state == CommonServices.gstIdStateCode[$scope.buyNow.twoWheeler.insuredDetails.gstin.slice(0,2)]){
				// 			$scope.detailQuoteTWScreenForm.gstIN.$setValidity("gstStateCode", true);
				// 			console.log("state code valid");
				// 	}
				// 		else{
				// 			$scope.detailQuoteTWScreenForm.gstIN.$setValidity("gstStateCode", false);
				// 		$scope.gstErrorMsg = "Please enter valid GSTIN. State code of GSTIN and the state mentioned in address should match.";	
				// 		}
				// 	}
				// 	else{
				// 		$scope.detailQuoteTWScreenForm.gstIN.$setValidity("gstStateCode", false);
				// 		$scope.gstErrorMsg = "Please enter GSTIN with a valid state code";
				// 		}
				// 	}
				}
				if ($scope.buyNow.twoWheeler.insuredDetails.gstRegIdType === "NRI") {
					reg = /^[0-9]{12}N[A-Z0-9]{1}T$/;
				}
				if ($scope.buyNow.twoWheeler.insuredDetails.gstRegIdType === "UNB") {
					reg = /^[0-9]{12}U[A-Z0-9]{1}N$/;
				}

				if ($scope.buyNow.twoWheeler.insuredDetails.gstin !== "" || $scope.buyNow.twoWheeler.insuredDetails.gstin !== undefined) {
					if (reg === "")
						valid = false;
					else
						valid = reg.test(($scope.buyNow.twoWheeler.insuredDetails.gstin).toUpperCase());
				}

				if ($scope.buyNow.twoWheeler.insuredDetails.gstRegIdType !== undefined && $scope.buyNow.twoWheeler.insuredDetails.gstRegIdType !== "") {
					$scope.detailQuoteTWScreenForm.$invalid = false;
				} else {
					$scope.detailQuoteTWScreenForm.$invalid = true;
				}

				if (valid) {
					$scope.detailQuoteTWScreenForm.gstIN.$setValidity("gstinPattern", true);
					$scope.detailQuoteTWScreenForm.gstIN.$invalid = false;
					$scope.detailQuoteTWScreenForm.$invalid = false;
					$scope.detailQuoteTWScreenForm.gstIN.$setValidity("gstIN", true);
				} else {
					$scope.detailQuoteTWScreenForm.gstIN.$setValidity("gstinPattern", false);
					$scope.detailQuoteTWScreenForm.gstIN.$invalid = true;
					$scope.detailQuoteTWScreenForm.$invalid = true;
					$scope.detailQuoteTWScreenForm.gstIN.$setValidity("gstIN", false);
				}


				// ADDED BY HIMANSHU FOR CR_875

				if ($scope.buyNow.twoWheeler.insuredDetails.gstin != undefined) {
					$scope.buyNow.twoWheeler.insuredDetails.gstin = $scope.buyNow.twoWheeler.insuredDetails.gstin.toUpperCase();
					if ($scope.buyNow.twoWheeler.insuredDetails.gstin.includes("AAACN4165C")) {
						$scope.detailQuoteTWScreenForm.gstIN.$setValidity("validateNIAPAN", false);
						$scope.detailQuoteTWScreenForm.$invalid = true;
					} else {
						$scope.detailQuoteTWScreenForm.gstIN.$setValidity("validateNIAPAN", true);
						$scope.detailQuoteTWScreenForm.$invalid = false;
					}
				}

				//console.log($scope.detailQuoteTWScreenForm.$invalid);


			}

		},
		uinInputChangeFunc: function () { // Onchange of UIN input field
			if ($scope.buyNow.twoWheeler.insuredDetails.uin.length === 15) {
				$scope.detailQuoteTWScreenForm.UIN.$invalid = false;
				$scope.detailQuoteTWScreenForm.$invalid = false;
			}
			else {
				$scope.detailQuoteTWScreenForm.UIN.$invalid = true;
				$scope.detailQuoteTWScreenForm.$invalid = true;
			}
		},
		stateServiceCall: function () {// this function is service call for getting state
			//if(!this.stateResponse){//this condition will not allow service to get called twice
			this.stateResponse = RestServices.postService(RestServices.urlPathsNewPortal.getStateList, $scope.stateData);
			return this.stateResponse.then(
				function (response) { // success

					CommonServices.showLoading(false);
					if (response.data.states !== undefined && response.data.states !== "") {
						/*CR_NP_0880 starts */
						if ($scope.partyCode !== "" && $scope.partyCode !== undefined) {// if the cutomer is existing customer
							response.data.states.filter(function (b) {//this filter will compare the responseState with the response data
								if ($scope.responseState !== "" && $scope.responseState !== undefined && b.stateCode === $scope.responseState) {
									$scope.policyDetailsObj.contState = b;
									$scope.responseState = "";
									$scope.searchPincode = { "state": $scope.policyDetailsObj.contState.state, "zipCode": "" };
									$scope.policyDetailsObj.pinCodeServiceCall();
									$scope.buyNow.twoWheeler.insuredDetails.polHolderState = $scope.policyDetailsObj.contState;
								}
							});
							$scope.stateList = response.data.states;
						}
						else {// if the customer is new customer
							if ($scope.continueState !== "" && $scope.continueState !== undefined) { // When Back navigation
								response.data.states.filter(function (b) {
									if (b.stateCode === $scope.continueState) {
										$scope.stateObj = {
											"stateObj": b
										}
									}
								});

								//angular.extend($rootScope.travelData.savedPartyDetails.partyDetails, $scope.stateObj);
								if ($scope.stateObj !== undefined && $scope.stateObj !== "") {
									$scope.continueState = "";
									$scope.cityData = { "state": $scope.stateObj.stateObj.state, "zipCode": $scope.continuepinCode, "city": "" };
									$scope.policyDetailsObj.cityServiceCall();
								}
								else {
									CommonServices.showAlert("Please change the state you have entered.");
								}

							}
							$scope.stateData = "";
							$scope.stateList = response.data.states;
						}
						return $scope.stateList;
					} else {
						if (response.data.errorMessage !== undefined && response.data.errorMessage !== "")
							CommonServices.showAlert(response.data.errorMessage);
						else
							// CommonServices.showAlert("Presently our services are not available. Please try after some time");
							CommonServices.showAlert("Error Occured. Please try again later");
					}
				},
				function (error) { // failure
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
				});
			//}

		},
		pinCodeServiceCall: function () { // this function is service call for getting pincodes
			//if(!this.getZipcodeDetailResponse){
			this.getZipcodeDetailResponse = RestServices.postService(RestServices.urlPathsNewPortal.getZipCodesbyState, $scope.searchPincode);
			return this.getZipcodeDetailResponse.then(
				function (response) { // success
					CommonServices.showLoading(false);
					if (response.data.pincodes !== undefined && response.data.pincodes !== "") {
						if ($scope.partyCode !== "" && $scope.partyCode !== undefined) { // if the cutomer is existing customer

							response.data.pincodes.filter(function (b) {//this filter will compare the responsepinCode with the response data
								if ($scope.responsepinCode !== "" && $scope.responsepinCode !== undefined && b === $scope.responsepinCode) {
									$scope.buyNow.twoWheeler.insuredDetails.pinCode = b;
									$scope.responsepinCode = "";
									$scope.cityData = { "state": ($scope.buyNow.twoWheeler.insuredDetails.polHolderState.state === undefined) ? $scope.buyNow.twoWheeler.insuredDetails.polHolderState : $scope.buyNow.twoWheeler.insuredDetails.polHolderState.state, "zipCode": $scope.buyNow.twoWheeler.insuredDetails.pinCode, "city": "" };
									$scope.policyDetailsObj.cityServiceCall();
								}
							});
							$scope.pinCodesList = response.data.pincodes;
							$scope.pinCodeResponseArray = response.data.pincodes;

							var pincodeMatchList = [];
							for (var i = 0; i < $scope.pinCodesList.length; i++) {
								if ($scope.pinCodesList[i].match($scope.searchPincode.zipCode)) {
									pincodeMatchList.push($scope.pinCodesList[i]);
								}
							}
							return $scope.pinCodesList = pincodeMatchList;
						}
						else {// if the customer is new customer
							$scope.searchPincode = "";
							$scope.pinCodesList = response.data.pincodes;
							$scope.pinCodeResponseArray = response.data.pincodes;
						}
					
						return $scope.pinCodesList;

					} else {
						if (response.data.errorMessage !== undefined && response.data.errorMessage !== "")
							CommonServices.showAlert(response.data.errorMessage);
						else
							// CommonServices.showAlert("Presently our services are not available. Please try after some time");
							CommonServices.showAlert("Error Occured. Please try again later");
					}
				},
				function (error) { // failure
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
				});
			//}
			/* CR_NP_0880 ends*/
		},
		cityServiceCall: function () {// this function is service call for getting city
			//if(!this.cityResponse){
			this.cityResponse = RestServices.postService(RestServices.urlPathsNewPortal.getCitiesList, $scope.cityData);
			return this.cityResponse.then(
				function (response) { // success

					CommonServices.showLoading(false);
					if (response.data.cities !== undefined && response.data.cities !== "") {
						if ($scope.partyCode !== "" && $scope.partyCode !== undefined) {// if the cutomer is existing customer

							response.data.cities.filter(function (b) { //this filter will compare the responseCity with the response data
								if ($scope.responseCity !== "" && $scope.responseCity !== undefined && b.cityCode === $scope.responseCity) {
									$scope.policyDetailsObj.countryCity = b;
									$scope.responseCity = "";
									$scope.buyNow.twoWheeler.insuredDetails.polHolderCity = $scope.policyDetailsObj.countryCity;
								}
							});
							$scope.buyNow.twoWheeler.insuredDetails.polHolderCity = response.data.cities[0];
							$scope.cityList = response.data.cities;

						}
						else {// if the cutomer is new customer
							if ($scope.continueCity !== "" && $scope.continueCity !== undefined) {
								response.data.cities.filter(function (b) { //this filter will compare the responseCity with the response data
									if (b.cityCode === $scope.continueCity) {
										$scope.cityObj = {
											"cityObj": b
										}
									}
									//angular.extend($rootScope.travelData.savedPartyDetails.partyDetails, $scope.cityObj);
								});

							}
							$scope.cityData = "";
							$scope.buyNow.twoWheeler.insuredDetails.polHolderCity = response.data.cities[0];
							$scope.cityList = response.data.cities;
						}
						/*Below block added during CR_NP_0880 */
						if ($scope.summaryFlag === true && $scope.buyNow.twoWheeler.insuredDetails.polHolderCity !== undefined && $scope.buyNow.twoWheeler.insuredDetails.polHolderCity !== "") {
							$scope.summaryFlag = false;
							$rootScope.saveQuoteTW();
						}
						/*CR_NP_0880 Ends */
						return $scope.cityList;
					} else {
						if (response.data !== undefined && response.data.errorMessage !== "") {
							if (response.data.errorMessage !== undefined && response.data.errorMessage !== "")
								CommonServices.showAlert(response.data.errorMessage);
							else
								CommonServices.showAlert("Please check the entered value");
						}
						else {
							// CommonServices.showAlert("Presently our services are not available. Please try after some time");
							CommonServices.showAlert("Error Occured. Please try again later");
						}
					}
				},
				function (error) { // failure
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
				});
		},

		gstFunc: function (obj, data) { // This function has the service call for getting StateList and CityList
			/*CR_NP_0880 starts */
			if (data === "state") { // This will give list of states
				$scope.buyNow.twoWheeler.insuredDetails.pinCode = "";
				$scope.buyNow.twoWheeler.insuredDetails.polHolderCity = "";
				$scope.disablePinCode = true;
				$scope.disableCity = true;
				$scope.stateErr = true;
				$scope.pinCodeErr = false;
				$scope.cityErr = false;

				if (obj.length === 3) { // When entered value is of 3 digit
					$scope.stateData = { "state": obj.toUpperCase() };
					return this.stateServiceCall();
				} else {  // When entered value is more than 3 digit
					if (obj.length > 3) {
						return ($filter('filter')($scope.stateList, { state: obj }));
					} else {
						$scope.stateList = {};
						return $scope.stateList;
					}
				}
			}

			if (data === 'pinCode') {
				$scope.pinCodeErr = true;
				$scope.cityErr = false;
				$scope.disableCity = true;
				$scope.buyNow.twoWheeler.insuredDetails.polHolderCity = "";

				if ($scope.pinCodeResponseArray != undefined && $scope.pinCodeResponseArray != "") { //New Customer with pincode response(Once pincode service is called)
					var matchList = [];
					$scope.pinCodesList = $scope.pinCodeResponseArray;
					for (var i = 0; i < $scope.pinCodesList.length; i++) {
						if ($scope.pinCodesList[i].match(obj)) {
							matchList.push($scope.pinCodesList[i]);
						}
					}
					return $scope.pinCodesList = matchList;
				} else { // New Customer when there is no pincode list
					$scope.searchPincode = { "state": ($scope.buyNow.twoWheeler.insuredDetails.polHolderState.state === undefined) ? $scope.buyNow.twoWheeler.insuredDetails.polHolderState.toUpperCase() : $scope.buyNow.twoWheeler.insuredDetails.polHolderState.state.toUpperCase(), "zipCode": obj };
					return this.pinCodeServiceCall();
				}
			}

			if (data === "city") { // This will give list of cities
				$scope.cityErr = true;
				if (obj.length === 1) { // When entered value is of 1 digit
					$scope.cityData = { "state": ($scope.buyNow.twoWheeler.insuredDetails.polHolderState.state === undefined) ? $scope.buyNow.twoWheeler.insuredDetails.polHolderState.toUpperCase() : $scope.buyNow.twoWheeler.insuredDetails.polHolderState.state.toUpperCase(), "zipCode": $scope.buyNow.twoWheeler.insuredDetails.pinCode, "city": obj.toUpperCase() };
					return this.cityServiceCall();
				}
				else { // When entered value is more than 1 digit
					if ($scope.cityList != undefined && $scope.cityList != "") { // if cities list is available
						return ($filter('filter')($scope.cityList, { city: obj }));
					} else {
						$scope.cityData = { "state": ($scope.buyNow.twoWheeler.insuredDetails.polHolderState.state === undefined) ? $scope.buyNow.twoWheeler.insuredDetails.polHolderState.toUpperCase() : $scope.buyNow.twoWheeler.insuredDetails.polHolderState.state.toUpperCase(), "zipCode": $scope.buyNow.twoWheeler.insuredDetails.pinCode, "city": obj.toUpperCase() };
						return this.cityServiceCall();
					}

				}
			}
			/*CR_NP_0880 Ends */
			/* 3712 Starts
			if (data === "country"){
				$scope.countryErr = true;
				if (obj.length === 3) { // When entered value is of 3 digit
					$scope.stateData = { "state": obj.toUpperCase() };
					return this.stateServiceCall();
				} else {  // When entered value is more than 3 digit 
					if (obj.length > 3) {
						return ($filter('filter')($scope.stateList, { state: obj }));
					} else {
						$scope.stateList = {};
						return $scope.stateList;
					}
				}
			}
			// 3712 ends */
		},
		/* 3712 Starts
		onSelectCountry: function ($item, $model, $label) {// onchange of state input field//3712
			console.log($item);
			$scope.countryErr = false;
		},
		// 3712 ends */
		onSelectState: function ($item, $model, $label) {// onchange of state input field
			/*CR_NP_0880 starts */
			$scope.stateErr = false;
			$scope.pinCodeErr = true;
			$scope.cityErr = false;
			$scope.disablePinCode = false;
			$scope.disableCity = true;

			$scope.buyNow.twoWheeler.insuredDetails.pinCode = "";
			$scope.buyNow.twoWheeler.insuredDetails.polHolderCity = "";
			$scope.pinCodeResponseArray = ""; // To make Pincode response list empty
//UC for 3749
			// angular.forEach(CommonServices.gstIdStateCode,function(value,key){
			// 	if($scope.buyNow.twoWheeler.insuredDetails.polHolderState.state == value){
			// 		$scope.gstinMsg = "GSTIN should start with "+key;
			// 	}

			// });

			// $scope.policyDetailsObj.gstIDInputChangeFunc();
			},
		onSelectPinCode: function ($item, $model, $label) {// onchange of pincode input field
			$scope.pinCodeErr = false;
			$scope.cityErr = false;
			$scope.disableCity = true;

			$scope.cityData = { "state": ($scope.buyNow.twoWheeler.insuredDetails.polHolderState.state === undefined) ? $scope.buyNow.twoWheeler.insuredDetails.polHolderState.toUpperCase() : $scope.buyNow.twoWheeler.insuredDetails.polHolderState.state.toUpperCase(), "zipCode": $scope.buyNow.twoWheeler.insuredDetails.pinCode, "city": "" };
			return this.cityServiceCall();
		},
		onSelectCity: function ($item, $model, $label) {// onchange of city input field
			// $scope.detailQuoteTWScreenForm.$invalid = false;
			$scope.cityErr = false;
			/*CR_NP_0880 Ends */
		},

		selectGstIDFunct: function (data) { // This function will validate the GSTIN values according to the changes in GSTID Type values

			if ($scope.buyNow.twoWheeler.insuredDetails.gstRegIdType == '' || $scope.buyNow.twoWheeler.insuredDetails.gstRegIdType == undefined) {
				$scope.buyNow.twoWheeler.insuredDetails.gstin = "";
				$scope.detailQuoteTWScreenForm.gstIN.$setValidity("validateNIAPAN", true);
				$scope.detailQuoteTWScreenForm.gstIN.$setValidity("gstinPattern", true);
				$scope.detailQuoteTWScreenForm.gstIN.$invalid = false;
				$scope.detailQuoteTWScreenForm.$invalid = false;
				$scope.buyNow.twoWheeler.insuredDetails.uin = "";
				//return;

			}
			$scope.reg = "";

			if ($rootScope.buyNow.twoWheeler.insuredDetails.gstin !== "" && $scope.buyNow.twoWheeler.insuredDetails.gstin !== undefined) {
				if ($scope.buyNow.twoWheeler.insuredDetails.gstin.length === 15) {
					$scope.detailQuoteTWScreenForm.gstIN.$invalid = false;
					$scope.detailQuoteTWScreenForm.$invalid = false;
				}
			}
			else {
				$scope.detailQuoteTWScreenForm.gstIN.$invalid = true;
				$scope.detailQuoteTWScreenForm.$invalid = true;
			}
			if ($scope.buyNow.twoWheeler.insuredDetails.gstRegIdType === "NCC") {
				$scope.reg = regexGSTidGlobal;///^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[A-Z0-9]{2}[^\s]$/;
				$scope.buyNow.twoWheeler.insuredDetails.uin = "";
			}
			if ($scope.buyNow.twoWheeler.insuredDetails.gstRegIdType === "NRI") {
				$scope.reg = /^[0-9]{12}N[A-Z0-9]{1}T$/;
				$scope.buyNow.twoWheeler.insuredDetails.uin = "";
				// $scope.detailQuoteTWScreenForm.gstIN.$setValidity("gstStateCode", true);//UC for 3749
			}
			if ($scope.buyNow.twoWheeler.insuredDetails.gstRegIdType === "UNB") {
				$scope.reg = /^[0-9]{12}U[A-Z0-9]{1}N$/;
				// $scope.detailQuoteTWScreenForm.gstIN.$setValidity("gstStateCode", true);//UC for 3749
			}

			var valid = "";

			if ($scope.buyNow.twoWheeler.insuredDetails.gstin !== "" || $scope.buyNow.twoWheeler.insuredDetails.gstin !== undefined) {
				if ($scope.reg === "") {
					valid = true;
				}
				else {
					if ($scope.buyNow.twoWheeler.insuredDetails.gstin !== undefined && $scope.buyNow.twoWheeler.insuredDetails.gstin !== "") {
						valid = $scope.reg.test($scope.buyNow.twoWheeler.insuredDetails.gstin.toUpperCase());
					}
				}

			}

			if (!valid) {
				$scope.detailQuoteTWScreenForm.gstIN.$setValidity("gstIN", false);
				$scope.detailQuoteTWScreenForm.$invalid = true;
				$scope.detailQuoteTWScreenForm.gstIN.$invalid = true;
			}
			else {
				$scope.detailQuoteTWScreenForm.gstIN.$setValidity("gstIN", true);
				$scope.detailQuoteTWScreenForm.$invalid = false;
				$scope.detailQuoteTWScreenForm.gstIN.$invalid = false;
			}

		},
		saveDetails: function (data) { // On click of Create in Policy Holder Information screen
			var policyHolderData = "";

			/*Added by 851587 for CR_NP_0744*/
			if ($scope.buyNow.twoWheeler.insuredDetails.aadhaarNumber1 != undefined && $scope.buyNow.twoWheeler.insuredDetails.aadhaarNumber1 != '' && $scope.buyNow.twoWheeler.insuredDetails.aadhaarNumber2 != undefined && $scope.buyNow.twoWheeler.insuredDetails.aadhaarNumber2 != '' && $scope.buyNow.twoWheeler.insuredDetails.aadhaarNumber3 != undefined && $scope.buyNow.twoWheeler.insuredDetails.aadhaarNumber3 != '') {
				$scope.policyDetailsObj.aadhaarNumber = $scope.buyNow.twoWheeler.insuredDetails.aadhaarNumber1 + $scope.buyNow.twoWheeler.insuredDetails.aadhaarNumber2 + $scope.buyNow.twoWheeler.insuredDetails.aadhaarNumber3;
			} else {
				$scope.policyDetailsObj.aadhaarNumber = "";
			}

			/*Changes for CR_NP_0744 ends*/

			if (this.category === "O") {
				policyHolderData = {
					"userProfile": { "userId": CommonServices.getCommonData("userId"), "loggedInRole": "SUPERUSER" }, "partyDetails": {
						"organizationDetails": {
							"businessName": $scope.buyNow.twoWheeler.insuredDetails.businessName.toUpperCase(),
							"registrationNo": $scope.buyNow.twoWheeler.insuredDetails.registrationNo.toUpperCase(),
							"registrationDate": $scope.buyNow.twoWheeler.insuredDetails.registrationDate,
							"typeofOrganization": $scope.buyNow.twoWheeler.insuredDetails.typeofOrganization.toUpperCase(),
							"businessAddress1": $scope.buyNow.twoWheeler.insuredDetails.businessAddress1.toUpperCase(),
							"businessAddress2": $scope.buyNow.twoWheeler.insuredDetails.businessAddress2 !== undefined ? $scope.buyNow.twoWheeler.insuredDetails.businessAddress2.toUpperCase() : "",
							"gstRegIdType": $scope.buyNow.twoWheeler.insuredDetails.gstRegIdType,
							"uin": $scope.buyNow.twoWheeler.insuredDetails.uin !== undefined ? $scope.buyNow.twoWheeler.insuredDetails.uin.toUpperCase() : "",
							"gstin": $scope.buyNow.twoWheeler.insuredDetails.gstin !== undefined ? $scope.buyNow.twoWheeler.insuredDetails.gstin.toUpperCase() : "",
							"cityObj": $scope.buyNow.twoWheeler.insuredDetails.polHolderCity,
							"stateObj": $scope.buyNow.twoWheeler.insuredDetails.polHolderState,
							"pinCode": $scope.buyNow.twoWheeler.insuredDetails.pinCode,  //CR_NP_0880
							"businessTelNumOff": $scope.buyNow.twoWheeler.insuredDetails.businessTelNumOff,
							"businessTelNumExtn": $scope.buyNow.twoWheeler.insuredDetails.businessTelNumExtn,
							"mobileNo": $scope.buyNow.twoWheeler.insuredDetails.mobileNo,
							"emailId": $scope.buyNow.twoWheeler.insuredDetails.emailID !== undefined ? $scope.buyNow.twoWheeler.insuredDetails.emailID : "",
							"panNumber": $scope.buyNow.twoWheeler.insuredDetails.panNum !== undefined ? $scope.buyNow.twoWheeler.insuredDetails.panNum.toUpperCase() : "",
							"state": $scope.buyNow.twoWheeler.insuredDetails.polHolderState.stateCode,
							"city": $scope.buyNow.twoWheeler.insuredDetails.polHolderCity.cityCode
						}, "partyType": this.category
					}
				};
			} else {
				policyHolderData = {
					"userProfile": { "userId": CommonServices.getCommonData("userId"), "loggedInRole": "SUPERUSER" },
					"partyDetails": {
						"individualDetails": {
							"firstName": $scope.buyNow.twoWheeler.insuredDetails.firstName !== undefined ? $scope.buyNow.twoWheeler.insuredDetails.firstName.toUpperCase() : "",
							"lastName": $scope.buyNow.twoWheeler.insuredDetails.lastName !== undefined ? $scope.buyNow.twoWheeler.insuredDetails.lastName.toUpperCase() : "",
							"middleName": $scope.buyNow.twoWheeler.insuredDetails.middleName !== undefined ? $scope.buyNow.twoWheeler.insuredDetails.middleName.toUpperCase() : "",
							"gender": $scope.buyNow.twoWheeler.insuredDetails.gender,
							"dateOfBirth": $scope.buyNow.twoWheeler.insuredDetails.DOB,
							/*
							"clientNationality": $scope.buyNow.twoWheeler.insuredDetails.clientNationality,//3712
							"clientCountryObj": $scope.buyNow.twoWheeler.insuredDetails.clientCountry,//3712
							"clientCountry": $scope.buyNow.twoWheeler.insuredDetails.clientCountry.stateCode,//3712
							*/
							"buildingNoStreet": $scope.buyNow.twoWheeler.insuredDetails.buildingNoStreet !== undefined ? $scope.buyNow.twoWheeler.insuredDetails.buildingNoStreet.toUpperCase() : "",
							"pinCode": $scope.buyNow.twoWheeler.insuredDetails.pinCode, //CR_NP_0880
							"mobileNo": $scope.buyNow.twoWheeler.insuredDetails.mobileNo,
							"emailId": $scope.buyNow.twoWheeler.insuredDetails.emailID !== undefined ? $scope.buyNow.twoWheeler.insuredDetails.emailID : "",
							"panNumber": $scope.buyNow.twoWheeler.insuredDetails.panNum !== undefined ? $scope.buyNow.twoWheeler.insuredDetails.panNum.toUpperCase() : "",
							"aadhaarNo": $scope.policyDetailsObj.aadhaarNumber !== undefined ? $scope.policyDetailsObj.aadhaarNumber : "",
							"aadhaarNumber1": $scope.buyNow.twoWheeler.insuredDetails.aadhaarNumber1 !== undefined ? $scope.buyNow.twoWheeler.insuredDetails.aadhaarNumber1 : "",
							"aadhaarNumber2": $scope.buyNow.twoWheeler.insuredDetails.aadhaarNumber2 !== undefined ? $scope.buyNow.twoWheeler.insuredDetails.aadhaarNumber2 : "",
							"aadhaarNumber3": $scope.buyNow.twoWheeler.insuredDetails.aadhaarNumber3 !== undefined ? $scope.buyNow.twoWheeler.insuredDetails.aadhaarNumber3 : "",
							"gstRegIdType": $scope.buyNow.twoWheeler.insuredDetails.gstRegIdType,
							"gstin": $scope.buyNow.twoWheeler.insuredDetails.gstin !== undefined ? $scope.buyNow.twoWheeler.insuredDetails.gstin.toUpperCase() : "",
							"uin": $scope.buyNow.twoWheeler.insuredDetails.uin !== undefined ? $scope.buyNow.twoWheeler.insuredDetails.uin.toUpperCase() : "",
							"cityObj": $scope.buyNow.twoWheeler.insuredDetails.polHolderCity,
							"stateObj": $scope.buyNow.twoWheeler.insuredDetails.polHolderState,
							"state": $scope.buyNow.twoWheeler.insuredDetails.polHolderState.stateCode,
							"city": $scope.buyNow.twoWheeler.insuredDetails.polHolderCity.cityCode,
							"eInsuranceAccountNo": $scope.buyNow.twoWheeler.insuredDetails.eInsAccNo !== undefined ? $scope.buyNow.twoWheeler.insuredDetails.eInsAccNo : ""
						}, "partyType": this.category
					}
				};
			}

			var policyHolderResponse = RestServices.postService(RestServices.urlPathsNewPortal.createPolicyHolderTW, policyHolderData);
			policyHolderResponse.then(
				function (response) { // success 

					CommonServices.showLoading(false);
					if (response.data.partyDetails !== undefined) {
						CommonServices.showAlert("Policy details has been successfully submitted. Your Party Code is #" + response.data.partyDetails.partyCode);

						$rootScope.buyNow.twoWheeler.insuredDetails.policyHolder = $scope.policyDetailsObj.policyHolder;
						$rootScope.buyNow.twoWheeler.insuredDetails.partyCode = response.data.partyDetails.partyCode;

						//angular.extend($rootScope.travelData, partyDetails);
						$scope.policyDetailsObj.createdParty(response.data.partyDetails);

					} else {
						CommonServices.showAlert(response.data.errorMessage);
					}
				},
				function (error) { // failure
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
				});
		},
		continueFunc: function () {//On click of continue button
			$scope.partyCode = $scope.buyNow.twoWheeler.insuredDetails.partyCode;
			CommonServices.setCommonData("partyCode", $scope.partyCode);
			CommonServices.setCommonData("categoryval", this.category);
			if (this.category === 'I') {
				if ($rootScope.buyNow.twoWheeler.insuredDetails.individualDetails.dateOfBirth !== undefined && $rootScope.buyNow.twoWheeler.insuredDetails.individualDetails.dateOfBirth !== "") {
					//CommonServices.setCommonData("partyCode",$rootScope.travelData.savedPartyDetails.partyDetails.partyCode);

					if ($rootScope.buyNow.twoWheeler.insuredDetails.individualDetails.state !== undefined && $rootScope.buyNow.twoWheeler.insuredDetails.individualDetails.state !== "") {
						$scope.summaryFlag = true;
						$scope.continueState = $rootScope.buyNow.twoWheeler.insuredDetails.individualDetails.state;
						$scope.continueCity = $rootScope.buyNow.twoWheeler.insuredDetails.individualDetails.city;
						$scope.continuepinCode = $rootScope.buyNow.twoWheeler.insuredDetails.individualDetails.pinCode;
						$scope.responseState = $rootScope.buyNow.twoWheeler.insuredDetails.individualDetails.state;
						$scope.responseCity = $rootScope.buyNow.twoWheeler.insuredDetails.individualDetails.city;
						$scope.responsepinCode = $rootScope.buyNow.twoWheeler.insuredDetails.individualDetails.pinCode;
						if ($scope.continueState !== undefined && $scope.continueState !== "") {
							$scope.stateData = { "state": "" };
							$scope.policyDetailsObj.stateServiceCall();
						}

					}
					else {
						CommonServices.showAlert("Please enter State");
						return false;
					}
				}
				else {
					CommonServices.showAlert("Please enter date of birth");
					return false;
				}

			}
			else if (this.category === 'O') {
				if ($rootScope.buyNow.twoWheeler.insuredDetails.organizationDetails.state !== undefined && $rootScope.buyNow.twoWheeler.insuredDetails.organizationDetails.state !== "") {
					$scope.summaryFlag = true;
					$scope.continueState = $rootScope.buyNow.twoWheeler.insuredDetails.organizationDetails.state;
					$scope.continueCity = $rootScope.buyNow.twoWheeler.insuredDetails.organizationDetails.city;
					$scope.responseState = $rootScope.buyNow.twoWheeler.insuredDetails.organizationDetails.state;
					$scope.responseCity = $rootScope.buyNow.twoWheeler.insuredDetails.organizationDetails.city;
					$scope.responsepinCode = $rootScope.buyNow.twoWheeler.insuredDetails.organizationDetails.pinCode;

					if ($scope.continueState !== undefined && $scope.continueState !== "") {
						$scope.stateData = { "state": "" };
						$scope.policyDetailsObj.stateServiceCall();
					}

				}
				else {
					CommonServices.showAlert("Please enter State");
					return false;
				}
			}


		},
		createdParty: function (item) { //This is to get policy holder details
			/* CR_NP_594A starts*/
			$scope.dateOfBirthEmpty = false;
			/* CR_NP_594A ends*/
			/* $scope.nationalityEmpty = false;  //CR 3712 */
			if (this.policyHolder === "existingPolicyHolder") {
				$scope.policyHolderData = {
					"userProfile": {
						"userId": CommonServices.getCommonData("userId"),
						"loggedInRole": "SUPERUSER"
					}, "partyDetails": { "partyCode": item.partyCode }
				};
			}
			else {
				$rootScope.buyNow.twoWheeler.insuredDetails.policyHolder = this.policyHolder;
				$scope.policyHolderData = {
					"userProfile": {
						"userId": CommonServices.getCommonData("userId"),
						"loggedInRole": "SUPERUSER"
					}, "partyDetails": { "partyCode": $rootScope.buyNow.twoWheeler.insuredDetails.partyCode }
				};
			}


			var policyHolderResponse = RestServices.postService(RestServices.urlPathsNewPortal.getPolicyHolderDetail, $scope.policyHolderData);
			policyHolderResponse.then(
				function (response) { // success
					/* 3712 Starts
					//3712
					// if (response.data.partyDetails.individualDetails.clientCountry === undefined) {
					// 	response.data.partyDetails.individualDetails.clientCountry = 'GA';
					// }
					// if (response.data.partyDetails.individualDetails.clientNationality === undefined) {
					// 	response.data.partyDetails.individualDetails.clientNationality = 'NonIndian';
					// } 
					// 3712 ends */
					$scope.partyresponse = '';
					CommonServices.showLoading(false);
					$scope.policyDetailsObj.showSearchResTbl = true;
					if (response.data.partyDetails !== undefined) {
						CommonServices.setCommonData("backFlag", "summarydetailsBack");
						CommonServices.setCommonData("categoryval", $scope.policyDetailsObj.category);
						/* CR_NP_594A starts*/

						if (response.data.partyDetails.individualDetails !== undefined) {
							if (response.data.partyDetails.individualDetails.dateOfBirth === undefined) {
								$scope.dateOfBirthEmpty = true;
							}
							else{
								var dt1 = response.data.partyDetails.individualDetails.dateOfBirth.split('/'),
							birthDateComp = dt1[1] + '/' + dt1[0] + '/' + dt1[2], //mm/dd/yyyy
							dt2 = $scope.buyNow.twoWheeler.additionalDetails.polStartDateTW.split('/'),
							leaveDateComp = dt2[1] + '/' + dt2[0] + '/' + dt2[2]; //mm/dd/yyyy

							birthDateComp = new Date(birthDateComp);
							leaveDateComp = new Date(leaveDateComp);

							leaveDateComp.setYear(leaveDateComp.getFullYear() - 18);

							if (birthDateComp > leaveDateComp) {
							$scope.dateOfBirthEmpty = true;
							}
							else {
							$scope.dateOfBirthEmpty = false;
							}
								
							}
							/* 3712 Starts
							response.data.partyDetails.individualDetails.clientNationality = 'NonIndian';
							response.data.partyDetails.individualDetails.clientCountry = 'Bangladesh';
							if(response.data.partyDetails.individualDetails.clientNationality !== 'Indian')
								$scope.isNonIndia = true;
							if (response.data.partyDetails.individualDetails.clientNationality === undefined || response.data.partyDetails.individualDetails.clientNationality === '') {
								$scope.nationalityEmpty = true;
							}
							// else{
							// 	policyDetailsObj.clientNationality = response.data.partyDetails.individualDetails.clientNationality;
							// 	policyDetailsObj.clientCountry = response.data.partyDetails.individualDetails.clientCountry;
							// }
							//3712 ends */

						}

						/* CR_NP_594A ends*/
						$scope.policyDetailsObj.showSmallTblFunc();
						$scope.showSmallData = response.data.partyDetails;
						CommonServices.setCommonData("smallTableData", response.data.partyDetails);

						/*if($scope.policyDetailsObj.category === "O"){
							$rootScope.buyNow.twoWheeler.insuredDetails.organizationDetails = $scope.showSmallData.organizationDetails;
						}
						if($scope.policyDetailsObj.category === "I"){
							$rootScope.buyNow.twoWheeler.insuredDetails.individualDetails = $scope.showSmallData.individualDetails;
						}*/
						$rootScope.buyNow.twoWheeler.insuredDetails = $scope.showSmallData;
						if ($scope.policyDetailsObj.policyHolder === "existingPolicyHolder") {
							$scope.buyNow.twoWheeler.insuredDetails.partyCode = item.partyCode;
							$scope.showSmallData.partyCode = item.partyCode;
							$rootScope.buyNow.twoWheeler.insuredDetails.policyHolder = $scope.policyDetailsObj.policyHolder;

						}
						else {

							$scope.buyNow.twoWheeler.insuredDetails.partyCode = item.partyCode;
							$scope.showSmallData.partyCode = $rootScope.buyNow.twoWheeler.insuredDetails.partyCode;
							$rootScope.buyNow.twoWheeler.insuredDetails.policyHolder = $scope.policyDetailsObj.policyHolder;
							/*if($scope.policyDetailsObj.category === "O"){
								  $scope.partyHolderDetails.organizationDetails = response.data.partyDetails;
							  }
							  if($scope.policyDetailsObj.category === "I"){
								  $scope.partyHolderDetails.individualDetails = response.data.partyDetails;
							  }*/
						}
						//angular.extend($rootScope.travelData, $scope.showSmallData);
					} else {
						$scope.policyDetailsObj.noRecords = "No records found";
						//CommonServices.showAlert("Please try again after some time.");
					}
				},
				function (error) { // failure
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
				});
		},
		showSmallTblFunc: function () {
			$scope.policyDetailsObj.showSmallTbl = true;
			$scope.policyDetailsObj.showSearchResTbl = false;
			$scope.policyDetailsObj.existingCustomerFlag = false;
			$scope.policyDetailsObj.newcustomerFlag = false;
			$scope.policyDetailsObj.existingCustomerFlag = false;
			//$scope.policyDetailsObj.policyHolder = "existingPolicyHolder";
		},

		searchDetails: function () {

			if (this.category === "I") {
				if ((this.partyCode === '' || this.partyCode === undefined) && (this.EfirstName === '' || this.EfirstName === undefined) && (this.ElastName === '' || this.ElastName === undefined) && (this.EmobileNumber === '' || this.EmobileNumber === undefined) && (this.EemailID === '' || this.EemailID === undefined)) {
					CommonServices.showAlert("Enter atleast 1 input parameters to proceed with the Policy Holder search.");
					$scope.policyDetailsObj.showSearchResTbl = false;
					return;
				}
				else {
					$scope.searchData = {
						"userProfile": { "userId": CommonServices.getCommonData("userId"), "loggedInRole": "SUPERUSER" },
						"partyDetails": {
							"individualDetails": { "firstName": "", "lastName": "", "emailId": "", "mobileNo": "" }, "organizationDetails": {},
							"partyCode": "", "productCode": "SQ", "partyType": this.category
						}, "productCode": "SQ"
					};
				}
			}
			else if (this.category === "O") {
				if ((this.organizpartyCode === '' || this.organizpartyCode === undefined) && (this.organizBusinessName === '' || this.organizBusinessName === undefined) && (this.organizmobileNumber === '' || this.organizmobileNumber === undefined) && (this.organizemailID === '' || this.organizemailID === undefined)) {
					CommonServices.showAlert("Enter atleast 1 input parameters to proceed with the Policy Holder search.");
					$scope.policyDetailsObj.showSearchResTbl = false;
					return;
				}
				else {
					$scope.searchData = {
						"userProfile": { "userId": CommonServices.getCommonData("userId"), "loggedInRole": "SUPERUSER" },
						"partyDetails": {
							"individualDetails": {}, "organizationDetails": { "businessName": "" },
							"partyCode": "", "productCode": "SQ", "partyType": this.category
						}, "productCode": "SQ"
					};
				}
			}

			if (this.partyCode !== undefined) {
				if (this.partyCode !== '') {
					$scope.searchData.partyDetails.partyCode = this.partyCode.toUpperCase();
				}
			}
			if (this.EfirstName !== undefined) {
				if (this.EfirstName !== '') {
					$scope.searchData.partyDetails.individualDetails.firstName = this.EfirstName.toUpperCase();
				}
			}
			if (this.ElastName !== undefined) {
				if (this.ElastName !== '') {
					$scope.searchData.partyDetails.individualDetails.lastName = this.ElastName.toUpperCase();
				}
			}
			if (this.EmobileNumber !== undefined) {
				if (this.EmobileNumber !== '') {
					$scope.searchData.partyDetails.individualDetails.mobileNo = this.EmobileNumber;
				}
			}
			if (this.EemailID !== undefined) {
				if (this.EmobileNumber !== '') {
					$scope.searchData.partyDetails.individualDetails.emailId = this.EemailID;
				}
			}

			if (this.organizBusinessName !== undefined) {
				if (this.organizBusinessName !== '') {
					$scope.searchData.partyDetails.organizationDetails.businessName = this.organizBusinessName.toUpperCase();
				}
			}
			if (this.organizmobileNumber !== undefined) {
				if (this.organizmobileNumber !== '') {
					$scope.searchData.partyDetails.organizationDetails.mobileNo = this.organizmobileNumber;
				}
			}
			if (this.organizemailID !== undefined) {
				if (this.organizemailID !== '') {
					$scope.searchData.partyDetails.organizationDetails.emailId = this.organizemailID;
				}
			}
			if (this.organizpartyCode !== undefined) {
				if (this.organizpartyCode !== '') {
					$scope.searchData.partyDetails.partyCode = this.organizpartyCode.toUpperCase();
				}
			}


			var policyHolderResponse = RestServices.postService(RestServices.urlPathsNewPortal.searchPolicyHolderDetails, $scope.searchData);
			policyHolderResponse.then(
				function (response) { // success 

					$scope.partyresponse = '';
					CommonServices.showLoading(false);
					$scope.policyDetailsObj.showSearchResTbl = true;
					if (response.data.partyDetailsList !== undefined) {
						$scope.partyresponse = response.data.partyDetailsList;
						$scope.policyDetailsObj.noRecords = null;
						// angular.extend($rootScope.travelData, partyDetails);
					} else {
						$scope.policyDetailsObj.noRecords = "No records found";
						//CommonServices.showAlert("Please try again after some time.");
					}
				},
				function (error) { // failure
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
				});

		},
		closePopup: function () {
			$scope.pinCodeModal = false;
		},
		setValue: function (data) { // this is to set values to the input fields at the time of edit 
			if (CommonServices.getCommonData("backFlag") === "") {
				$scope.detailQuoteTWScreenForm.gstIN.$invalid = false;
				$scope.detailQuoteTWScreenForm.gstIN.$valid = true;
				$rootScope.buyNow.twoWheeler.insuredDetails.policyHolder = this.policyHolder;
			}
			$rootScope.buyNow.twoWheeler.insuredDetails.partyCode = data.partyCode;

			$scope.partyHolderDetails = data;
			/*var partyDetails = {"savedPartyDetails": {"partyDetails":{"individualDetails":data.individualDetails}}};
			partyDetails.savedPartyDetails.partyDetails.partyCode= data.partyCode;
			partyDetails.savedPartyDetails.partyDetails.policyHolder= this.policyHolder;
			angular.extend($rootScope.travelData, partyDetails);*/
			if ($scope.partyHolderDetails.partyType === "I") {
				if (data.individualDetails.firstName !== undefined && data.individualDetails.firstName !== "")
					$scope.buyNow.twoWheeler.insuredDetails.firstName = data.individualDetails.firstName;
				if (data.individualDetails.middleName !== undefined && data.individualDetails.middleName !== "")
					$scope.buyNow.twoWheeler.insuredDetails.middleName = data.individualDetails.middleName;
				if (data.individualDetails.lastName !== undefined && data.individualDetails.lastName !== "")
					$scope.buyNow.twoWheeler.insuredDetails.lastName = data.individualDetails.lastName;
				if (data.individualDetails.gender !== undefined && data.individualDetails.gender !== "")
					$scope.buyNow.twoWheeler.insuredDetails.gender = data.individualDetails.gender;
				if (data.individualDetails.dateOfBirth !== undefined && data.individualDetails.dateOfBirth !== "")
					$scope.buyNow.twoWheeler.insuredDetails.DOB = data.individualDetails.dateOfBirth;
				if (data.individualDetails.buildingNoStreet !== undefined && data.individualDetails.buildingNoStreet !== "")
					$scope.buyNow.twoWheeler.insuredDetails.buildingNoStreet = data.individualDetails.buildingNoStreet;
				if (data.individualDetails.mobileNo !== undefined && data.individualDetails.mobileNo !== "")
					$scope.buyNow.twoWheeler.insuredDetails.mobileNo = data.individualDetails.mobileNo;
				if (data.individualDetails.emailId !== undefined && data.individualDetails.emailId !== "")
					$scope.buyNow.twoWheeler.insuredDetails.emailID = data.individualDetails.emailId;
				if (data.individualDetails.panNumber !== undefined && data.individualDetails.panNumber !== ""){
					$scope.buyNow.twoWheeler.insuredDetails.panNum = data.individualDetails.panNumber;
					$scope.isPanDisabled = $scope.regexPanNo.test($scope.buyNow.twoWheeler.insuredDetails.panNum);
				}
				if (data.individualDetails.eInsuranceAccountNo !== undefined && data.individualDetails.eInsuranceAccountNo !== "")
					$scope.buyNow.twoWheeler.insuredDetails.eInsAccNo = data.individualDetails.eInsuranceAccountNo;
				if (data.individualDetails.gstRegIdType !== undefined && data.individualDetails.gstRegIdType !== "") {
					$scope.buyNow.twoWheeler.insuredDetails.gstRegIdType = data.individualDetails.gstRegIdType;
				}
				/* 3712 starts
				if (data.individualDetails.clientNationality !== undefined && data.individualDetails.clientCountry !== "") {
					$scope.buyNow.twoWheeler.insuredDetails.clientNationality = data.individualDetails.clientNationality;
				}if (data.individualDetails.clientCountry !== undefined && data.individualDetails.clientCountry !== "") {
					$scope.buyNow.twoWheeler.insuredDetails.clientCountry = data.individualDetails.clientCountry;
				}
				// 3712 ends */
				if (data.individualDetails.aadhaarNo !== undefined && data.individualDetails.aadhaarNo !== "") {
					$scope.buyNow.twoWheeler.insuredDetails.aadhaarNumber1 = data.individualDetails.aadhaarNo.substr(0, 4);
					$scope.buyNow.twoWheeler.insuredDetails.aadhaarNumber2 = data.individualDetails.aadhaarNo.substr(4, 4);
					$scope.buyNow.twoWheeler.insuredDetails.aadhaarNumber3 = data.individualDetails.aadhaarNo.substr(8, 4);
				}

				if (data.individualDetails.gstin !== undefined && data.individualDetails.gstin !== "")
					$scope.buyNow.twoWheeler.insuredDetails.gstin = data.individualDetails.gstin;
				if (data.individualDetails.uin !== undefined && data.individualDetails.uin !== "")
					$scope.buyNow.twoWheeler.insuredDetails.uin = data.individualDetails.uin;
				if (data.individualDetails.state !== undefined && data.individualDetails.state !== "") {
				$scope.partyCode = data.partyCode;
					$scope.responseState = data.individualDetails.state;
					$scope.responseCity = data.individualDetails.city;
					$scope.responsepinCode = data.individualDetails.pinCode;
					$scope.stateData = { "state": "" };
					return $scope.policyDetailsObj.stateServiceCall();
				}
			}
			if ($scope.partyHolderDetails.partyType === "O") {
				if (data.organizationDetails.businessName !== undefined && data.organizationDetails.businessName !== "")
					$scope.buyNow.twoWheeler.insuredDetails.businessName = data.organizationDetails.businessName;
				if (data.organizationDetails.registrationNo !== undefined && data.organizationDetails.registrationNo !== "")
					$scope.buyNow.twoWheeler.insuredDetails.registrationNo = data.organizationDetails.registrationNo;
				if (data.organizationDetails.registrationDate !== undefined && data.organizationDetails.registrationDate !== "")
					$scope.buyNow.twoWheeler.insuredDetails.registrationDate = data.organizationDetails.registrationDate;
				if (data.organizationDetails.typeofOrganization !== undefined && data.organizationDetails.typeofOrganization !== "")
					$scope.buyNow.twoWheeler.insuredDetails.typeofOrganization = data.organizationDetails.typeofOrganization;
				if (data.organizationDetails.businessAddress1 !== undefined && data.organizationDetails.businessAddress1 !== "")
					$scope.buyNow.twoWheeler.insuredDetails.businessAddress1 = data.organizationDetails.businessAddress1;
				if (data.organizationDetails.businessAddress2 !== undefined && data.organizationDetails.businessAddress2 !== "")
					$scope.buyNow.twoWheeler.insuredDetails.businessAddress2 = data.organizationDetails.businessAddress2;
				if (data.organizationDetails.businessTelNumOff !== undefined && data.organizationDetails.businessTelNumOff !== "")
					$scope.buyNow.twoWheeler.insuredDetails.businessTelNumOff = data.organizationDetails.businessTelNumOff;
				if (data.organizationDetails.businessTelNumExtn !== undefined && data.organizationDetails.businessTelNumExtn !== "")
					$scope.buyNow.twoWheeler.insuredDetails.businessTelNumExtn = data.organizationDetails.businessTelNumExtn;
				if (data.organizationDetails.emailId !== undefined && data.organizationDetails.emailId !== "")
					$scope.buyNow.twoWheeler.insuredDetails.emailID = data.organizationDetails.emailId;
				if (data.organizationDetails.panNumber !== undefined && data.organizationDetails.panNumber !== "")
					$scope.buyNow.twoWheeler.insuredDetails.panNum = data.organizationDetails.panNumber;
				if (data.organizationDetails.mobileNo !== undefined && data.organizationDetails.mobileNo !== "")
					$scope.buyNow.twoWheeler.insuredDetails.mobileNo = data.organizationDetails.mobileNo;
				if (data.organizationDetails.gstRegIdType !== undefined && data.organizationDetails.gstRegIdType !== "") {
					$scope.buyNow.twoWheeler.insuredDetails.gstRegIdType = data.organizationDetails.gstRegIdType;
				}

				if (data.organizationDetails.gstin !== undefined && data.organizationDetails.gstin !== "")
					$scope.buyNow.twoWheeler.insuredDetails.gstin = data.organizationDetails.gstin;
				if (data.organizationDetails.uin !== undefined && data.organizationDetails.uin !== "")
					$scope.buyNow.twoWheeler.insuredDetails.uin = data.organizationDetails.uin;
				if (data.organizationDetails.state !== undefined && data.organizationDetails.state !== "") {
				$scope.partyCode = data.partyCode;
					$scope.responseState = data.organizationDetails.state;
					$scope.responseCity = data.organizationDetails.city;
					$scope.responsepinCode = data.organizationDetails.pinCode;
					$scope.stateData = { "state": "" };
					return $scope.policyDetailsObj.stateServiceCall();
				}

			}


		},
		selectPolHolId: function (data) {
			this.showSmallTbl = true;
			this.showSearchResTbl = false;
			this.existingCustomerFlag = false;
			$scope.showSmallData = data;
			this.setValue(data);

		},
		viewDetails: function (data) {
			this.newcustomerFlag = true;
			this.fieldDisable = true;
			this.showSmallTbl = false;
			this.existingCustomerBtn = false;
			setTimeout(function(){
				$('#dateOfBirth').loadCalendar({
					'enableDateRange': true,
					'enableCalendarFrom': dateOfBirthfrom,
					'enableCalendarTo': dateOfBirthTo
				});
			},2000);
			this.setValue(data);
		},
		minimizeForm: function () {
			this.showSmallTbl = true;
			this.newcustomerFlag = false;
			this.fieldDisable = false;
			this.existingCustomerBtn = true;
			$scope.partyCode = "";
		},
		deleteRow: function () {
			this.showSmallTbl = false;
			if (this.policyHolder === "newPolicyHolder") {
				this.newcustomerFlag = true;
				this.existingCustomerFlag = false;
				$scope.partyCode = "";
				$scope.buyNow.twoWheeler.insuredDetails.firstName = "";
				$scope.buyNow.twoWheeler.insuredDetails.middleName = "";
				$scope.buyNow.twoWheeler.insuredDetails.lastName = "";
				$scope.buyNow.twoWheeler.insuredDetails.gender = "";
				$scope.buyNow.twoWheeler.insuredDetails.DOB = "";
				$scope.buyNow.twoWheeler.insuredDetails.buildingNoStreet = "";
				$scope.buyNow.twoWheeler.insuredDetails.pinCode = "";
				$scope.buyNow.twoWheeler.insuredDetails.mobileNo = "";
				$scope.buyNow.twoWheeler.insuredDetails.emailID = "";
				$scope.buyNow.twoWheeler.insuredDetails.panNum = "";
				$scope.buyNow.twoWheeler.insuredDetails.eInsAccNo = "";
				$scope.buyNow.twoWheeler.insuredDetails.gstRegIdType = "";
				$scope.buyNow.twoWheeler.insuredDetails.gstin = "";
				$scope.buyNow.twoWheeler.insuredDetails.uin = "";
				$scope.buyNow.twoWheeler.insuredDetails.polHolderState = "";
				$scope.buyNow.twoWheeler.insuredDetails.polHolderCity = "";
			}
			else {
				this.existingCustomerFlag = true;
				this.newcustomerFlag = false;
			}

		},
		updateServiceCall: function () {
			var updatepolicyHolderData =
			{
				"userCode": CommonServices.getCommonData("userId"),
				"rolecode": "SUPERUSER",
				"policyHolderCode": $scope.showSmallData.partyCode,
				"mobileNo": $scope.buyNow.twoWheeler.insuredDetails.mobileNo,
				"gstRegIdType": $scope.buyNow.twoWheeler.insuredDetails.gstRegIdType !== undefined ? $scope.buyNow.twoWheeler.insuredDetails.gstRegIdType : "",
				"gstin": $scope.buyNow.twoWheeler.insuredDetails.gstin !== undefined ? $scope.buyNow.twoWheeler.insuredDetails.gstin : "",
				"uin": $scope.buyNow.twoWheeler.insuredDetails.uin !== undefined ? $scope.buyNow.twoWheeler.insuredDetails.uin : "",
				"city": $scope.buyNow.twoWheeler.insuredDetails.polHolderCity.cityCode,
				"state": $scope.buyNow.twoWheeler.insuredDetails.polHolderState.stateCode,
				"pinCode": $scope.buyNow.twoWheeler.insuredDetails.pinCode, //CR_NP_0880
				"addressLine1": $scope.buyNow.twoWheeler.insuredDetails.buildingNoStreet,
				"emailId": $scope.buyNow.twoWheeler.insuredDetails.emailID !== undefined ? $scope.buyNow.twoWheeler.insuredDetails.emailID : "",
				"panNumber": $scope.buyNow.twoWheeler.insuredDetails.panNum !== undefined ? $scope.buyNow.twoWheeler.insuredDetails.panNum.toUpperCase() : "",
				"dateOfBirth": $scope.buyNow.twoWheeler.insuredDetails.DOB !== undefined && $scope.buyNow.twoWheeler.insuredDetails.DOB !== "" ? $scope.buyNow.twoWheeler.insuredDetails.DOB : "",
				/*
				"clientNationality": $scope.buyNow.twoWheeler.insuredDetails.clientNationality,//3712
				"clientCountry": $scope.buyNow.twoWheeler.insuredDetails.clientCountry,//3712
				*/
			};

			var updatePolicyHolderContact = RestServices.postService(RestServices.urlPathsNewPortal.updatePolicyHolderContact, updatepolicyHolderData);
			updatePolicyHolderContact.then(
				function (response) { // success

					CommonServices.showLoading(false);
					if (response.data.errorCode === undefined) {
						if (response.data.pRetCode === "0") {

							$scope.partyCode = "";

							CommonServices.showAlert(response.data.pRetErr);
							$scope.policyDetailsObj.fieldDisable = false;
							/* CR_NP_594A starts*/
							$scope.dateOfBirthEmpty = false;
							/* CR_NP_594A ends*/
							$scope.policyDetailsObj.showSmallTblFunc();
							$rootScope.buyNow.twoWheeler.partyType = $scope.policyDetailsObj.category;

							if ($scope.policyDetailsObj.category === "I") {
								$rootScope.buyNow.twoWheeler.insuredDetails.individualDetails.buildingNoStreet = response.data.addressLine1;
								$rootScope.buyNow.twoWheeler.insuredDetails.individualDetails.mobileNo = response.data.mobileNo;
								$rootScope.buyNow.twoWheeler.insuredDetails.individualDetails.emailId = response.data.emailId;
								$rootScope.buyNow.twoWheeler.insuredDetails.individualDetails.gstRegIdType = response.data.gstRegIdType;
								$rootScope.buyNow.twoWheeler.insuredDetails.individualDetails.gstin = response.data.gstin;
								$rootScope.buyNow.twoWheeler.insuredDetails.individualDetails.uin = response.data.uin;
								$rootScope.buyNow.twoWheeler.insuredDetails.individualDetails.state = response.data.state;
								$rootScope.buyNow.twoWheeler.insuredDetails.individualDetails.city = response.data.city;
								$rootScope.buyNow.twoWheeler.insuredDetails.individualDetails.pinCode = response.data.pinCode;
								$rootScope.buyNow.twoWheeler.insuredDetails.individualDetails.dateOfBirth = response.data.dateOfBirth;
								/*
								$rootScope.buyNow.twoWheeler.insuredDetails.individualDetails.clientNationality = "NonIndian";  //3712 api
								$rootScope.buyNow.twoWheeler.insuredDetails.individualDetails.clientCountry = "Pakistan";	//3712 api
								*/
								var smallData = {
									"individualDetails": $rootScope.buyNow.twoWheeler.insuredDetails,
									"partyCode": CommonServices.getCommonData("smallTableData").partyCode,
									"partyType": CommonServices.getCommonData("smallTableData").partyType
								}
								$scope.showSmallData = smallData;
								CommonServices.setCommonData("smallTableData", smallData);
							}
							if ($scope.policyDetailsObj.category === "O") {
								$rootScope.buyNow.twoWheeler.insuredDetails.organizationDetails.buildingNoStreet = response.data.addressLine1;
								$rootScope.buyNow.twoWheeler.insuredDetails.organizationDetails.mobileNo = response.data.mobileNo;
								$rootScope.buyNow.twoWheeler.insuredDetails.organizationDetails.emailId = response.data.emailId;
								$rootScope.buyNow.twoWheeler.insuredDetails.organizationDetails.gstRegIdType = response.data.gstRegIdType;
								$rootScope.buyNow.twoWheeler.insuredDetails.organizationDetails.gstin = response.data.gstin;
								$rootScope.buyNow.twoWheeler.insuredDetails.organizationDetails.uin = response.data.uin;
								$rootScope.buyNow.twoWheeler.insuredDetails.organizationDetails.state = response.data.state;
								$rootScope.buyNow.twoWheeler.insuredDetails.organizationDetails.city = response.data.city;
								$rootScope.buyNow.twoWheeler.insuredDetails.organizationDetails.pinCode = response.data.pinCode;
								var smallData = {
									"organizationDetails": $rootScope.buyNow.twoWheeler.insuredDetails,
									"partyCode": CommonServices.getCommonData("smallTableData").partyCode,
									"partyType": CommonServices.getCommonData("smallTableData").partyType
								}
								$scope.showSmallData = smallData;
								CommonServices.setCommonData("smallTableData", smallData);
							}
							$scope.showSmallData.partyCode = response.data.policyHolderCode;
							$scope.showSmallData.partyType = $scope.policyDetailsObj.category;
							$rootScope.buyNow.twoWheeler.insuredDetails.partyCode = response.data.policyHolderCode;

						} else {
							CommonServices.showAlert("Please try again after some time.");
						}
					}
					else {
						CommonServices.showAlert(response.data.errorMessage);
					}

				},
				function (error) { // failure
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
				});
		},
		updateDetails: function () { // this is to update policy holder detail

			/*if(!this.compareBirthDate()){
				return false;
			}*/
			if ($scope.partyHolderDetails.organizationDetails !== undefined && $scope.partyHolderDetails.organizationDetails !== "") {
				if ($scope.partyHolderDetails.organizationDetails.mobileNo === $scope.buyNow.twoWheeler.insuredDetails.mobileNo && $scope.partyHolderDetails.organizationDetails.emailId === $scope.buyNow.twoWheeler.insuredDetails.emailID
					&& $scope.partyHolderDetails.organizationDetails.gstRegIdType === $scope.buyNow.twoWheeler.insuredDetails.gstRegIdType && $scope.partyHolderDetails.organizationDetails.gstin === $scope.buyNow.twoWheeler.insuredDetails.gstin
					&& $scope.partyHolderDetails.organizationDetails.uin === $scope.buyNow.twoWheeler.insuredDetails.uin && $scope.partyHolderDetails.organizationDetails.city === $scope.buyNow.twoWheeler.insuredDetails.polHolderCity.cityCode
					&& $scope.partyHolderDetails.organizationDetails.state === $scope.buyNow.twoWheeler.insuredDetails.polHolderState.stateCode && $scope.partyHolderDetails.organizationDetails.pinCode === $scope.buyNow.twoWheeler.insuredDetails.pinCode
					&& $scope.partyHolderDetails.organizationDetails.buildingNoStreet === $scope.buyNow.twoWheeler.insuredDetails.buildingNoStreet) {// If nothing has changed

					$scope.partyCode = "";
					this.fieldDisable = false;
					$scope.policyDetailsObj.showSmallTblFunc();

				}
				else {// if there are changes in values
					this.updateServiceCall();
				}
			}
			else if ($scope.partyHolderDetails.individualDetails !== undefined && $scope.partyHolderDetails.individualDetails !== "") {
				if ($scope.partyHolderDetails.individualDetails.mobileNo === $scope.buyNow.twoWheeler.insuredDetails.mobileNo && $scope.partyHolderDetails.individualDetails.emailId === $scope.buyNow.twoWheeler.insuredDetails.emailID
					&& $scope.partyHolderDetails.individualDetails.gstRegIdType === $scope.buyNow.twoWheeler.insuredDetails.gstRegIdType && $scope.partyHolderDetails.individualDetails.gstin === $scope.buyNow.twoWheeler.insuredDetails.gstin
					&& $scope.partyHolderDetails.individualDetails.uin === $scope.buyNow.twoWheeler.insuredDetails.uin && $scope.partyHolderDetails.individualDetails.city === $scope.buyNow.twoWheeler.insuredDetails.polHolderCity.cityCode
					&& $scope.partyHolderDetails.individualDetails.state === $scope.buyNow.twoWheeler.insuredDetails.polHolderState.stateCode && $scope.partyHolderDetails.individualDetails.pinCode === $scope.buyNow.twoWheeler.insuredDetails.pinCode
					&& $scope.partyHolderDetails.individualDetails.buildingNoStreet === $scope.buyNow.twoWheeler.insuredDetails.buildingNoStreet
					&& $scope.partyHolderDetails.individualDetails.dateOfBirth === $scope.buyNow.twoWheeler.insuredDetails.DOB
					/* 3712 Starts
					&& $scope.partyHolderDetails.individualDetails.clientNationality === this.clientNationality 
					&& $scope.partyHolderDetails.individualDetails.clientCountry === this.clientCountry.stateCode
					3712 ends */) {// If nothing has changed

					$scope.partyCode = "";
					this.fieldDisable = false;
					$scope.policyDetailsObj.showSmallTblFunc();

				}
				else {// if there are changes in values
					this.updateServiceCall();
				}
			}

		}
	};


	$scope.calIconClick = function (event) {
		angular.element("#" + event.currentTarget.children[0].id).focus();
	};

	if (CommonServices.getCommonData("backFlag") === "summarydetailsBack") {

		$scope.policyDetailsObj.showSmallTblFunc();
		//$scope.partyHolderDetails = "";
		$scope.policyDetailsObj.category = CommonServices.getCommonData("categoryval");
		if ($scope.policyDetailsObj.category === "I") {
			$scope.individualData = { "individualDetails": $rootScope.buyNow.twoWheeler.insuredDetails };
			$scope.policyDetailsObj.setValue(CommonServices.getCommonData("smallTableData"));
			//$scope.partyHolderDetails.individualDetails = CommonServices.getCommonData("smallTableData").individualDetails;
		}
		else {
			$scope.individualData = { "organizationDetails": $rootScope.buyNow.twoWheeler.insuredDetails };
			$scope.policyDetailsObj.setValue(CommonServices.getCommonData("smallTableData"));
			//$scope.partyHolderDetails.organizationDetails = CommonServices.getCommonData("smallTableData").organizationDetails;
		}
		$scope.individualData.partyCode = $rootScope.buyNow.twoWheeler.insuredDetails.partyCode;
		$scope.showSmallData = $scope.individualData;//CommonServices.getCommonData("smallTableData");
		$scope.policyDetailsObj.policyHolder = $rootScope.buyNow.twoWheeler.insuredDetails.policyHolder;

	};

	/**********************************************Only For Insured Details Screen************************************************************************/
		if (CommonServices.SQParentPolicyHistory === true) {	
			$rootScope.buyNow.twoWheeler.insuredDetails.partyCode = CommonServices.getCommonData("SQPolicyDetails").policyHolderCode;
				$scope.dateOfBirthEmpty = false;
				$rootScope.buyNow.twoWheeler.insuredDetails.policyHolder = "existingPolicyHolder";
				$scope.policyHolderData = {
					"userProfile": {
						"userId": CommonServices.getCommonData("userId"),
						"loggedInRole": "SUPERUSER"
					}, "partyDetails": { "partyCode": $rootScope.buyNow.twoWheeler.insuredDetails.partyCode }
				};
			

			var policyHolderResponse = RestServices.postService(RestServices.urlPathsNewPortal.getPolicyHolderDetail, $scope.policyHolderData);
			policyHolderResponse.then(
				function (response) { // success 
					$scope.partyresponse = '';
					CommonServices.showLoading(false);
					$scope.policyDetailsObj.showSearchResTbl = true;
					if (response.data.partyDetails !== undefined) {
						CommonServices.setCommonData("backFlag", "summarydetailsBack");
						CommonServices.setCommonData("categoryval", $scope.policyDetailsObj.category);
						/* CR_NP_594A starts*/

						if (response.data.partyDetails.individualDetails !== undefined) {
							if (response.data.partyDetails.individualDetails.dateOfBirth === undefined) {
								$scope.dateOfBirthEmpty = true;
							}
							else{
								var dt1 = response.data.partyDetails.individualDetails.dateOfBirth.split('/'),
							birthDateComp = dt1[1] + '/' + dt1[0] + '/' + dt1[2], //mm/dd/yyyy
							dt2 = $scope.buyNow.twoWheeler.additionalDetails.polStartDateTW.split('/'),
							leaveDateComp = dt2[1] + '/' + dt2[0] + '/' + dt2[2]; //mm/dd/yyyy

							birthDateComp = new Date(birthDateComp);
							leaveDateComp = new Date(leaveDateComp);

							leaveDateComp.setYear(leaveDateComp.getFullYear() - 18);

							if (birthDateComp > leaveDateComp) {
							$scope.dateOfBirthEmpty = true;
							}
							else {
							$scope.dateOfBirthEmpty = false;
							}
								
							}
							
						}

						/* CR_NP_594A ends*/
						$scope.policyDetailsObj.showSmallTblFunc();
						$scope.showSmallData = response.data.partyDetails;
						CommonServices.setCommonData("smallTableData", response.data.partyDetails);
						$rootScope.buyNow.twoWheeler.insuredDetails = $scope.showSmallData;
						$scope.policyDetailsObj.policyHolder = "existingPolicyHolder";
						if ($scope.policyDetailsObj.policyHolder === "existingPolicyHolder") {
							$scope.showSmallData.partyCode = CommonServices.getCommonData("SQPolicyDetails").policyHolderCode;;
							$rootScope.buyNow.twoWheeler.insuredDetails.policyHolder = $scope.policyDetailsObj.policyHolder;
							$rootScope.buyNow.twoWheeler.partyType = $scope.policyDetailsObj.category;
						}
					} else {
						$scope.policyDetailsObj.noRecords = "No records found";
						//CommonServices.showAlert("Please try again after some time.");
					}
				},
				function (error) { // failure
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
				});

		}

}]);

agentApp.controller('sqSummaryDetailsCtrl', ['$scope', '$rootScope', 'CommonServices', 'RestServices', 'GetSetResponseService', '$location', '$state','CartServices', function ($scope, $rootScope, CommonServices, RestServices, GetSetResponseService, $location, $state,CartServices) {
	$scope.isDiscountAvail = CommonServices.getCommonData("additionalDisc"); //CR 3868
	$scope.sqSummaryDetailsCtrl = {
		onload: function () {
			if (CommonServices.getCommonData("stakeCode") === "DEVLP-OFF") {
				if ($rootScope.buyNow.twoWheeler.relationDetails.partyCode !== undefined && $rootScope.buyNow.twoWheeler.relationDetails.partyCode !== "") {
					$scope.buyNow.twoWheeler.relationDetails = $rootScope.buyNow.twoWheeler.relationDetails;
					$scope.relationPanelEnable = true;
				}
				else {
					$scope.relationPanelEnable = false;
				}
			}
			if (CommonServices.getCommonData("stakeCode") === "DEALER") {
				$scope.buyNow.twoWheeler.relationDetails = $rootScope.buyNow.twoWheeler.relationDetails;
				$scope.dealerRelationPanelEnable = true;
			}
			else {
				$scope.dealerRelationPanelEnable = false;
			}


			if (CommonServices.fromRecentActivities === true) {

				$scope.buyNow.twoWheeler.additionalDetails.yrOfManufactureTW = {};
				$scope.buyNow.twoWheeler.quickQuote.vehicleModel = {};
				$(".back").css("display", "none");
				$("#disclaimerBuyNow-btn").css("display", "none");
				$("#disclaimerBuyNow-btnFromRA").css("display", "block");

				$scope.buyNow.twoWheeler.additionalDetails.policyStartDate = $rootScope.collectPremRecentActivities.quote.policyStartDate;
				$scope.buyNow.twoWheeler.additionalDetails.policyExpiryDate = $rootScope.collectPremRecentActivities.quote.policyExpiryDate;


				$scope.buyNow.twoWheeler.summaryDetails.quoteNumber = $rootScope.collectPremRecentActivities.quoteNo;
				$rootScope.buyNow.twoWheeler.summaryDetails.quoteNumber = $rootScope.collectPremRecentActivities.quoteNo;
				$scope.buyNow.twoWheeler.summaryDetails.netPremium = $rootScope.collectPremRecentActivities.quote.premiumDetails.netPremium;
				$rootScope.buyNow.twoWheeler.summaryDetails.netPremium = $rootScope.collectPremRecentActivities.quote.premiumDetails.netPremium;
				$scope.buyNow.twoWheeler.summaryDetails.serviceTax = $rootScope.collectPremRecentActivities.quote.premiumDetails.serviceTax;
				$scope.buyNow.twoWheeler.summaryDetails.totalPremium = $rootScope.collectPremRecentActivities.quote.premiumDetails.totalPremium;

				$scope.buyNow.twoWheeler.quickQuote.make = $rootScope.collectPremRecentActivities.quote.vehicles[0].vehicleDetails.make;
				$scope.buyNow.twoWheeler.quickQuote.vehicleModel.motorModel = $rootScope.collectPremRecentActivities.quote.vehicles[0].vehicleDetails.model;
				$scope.buyNow.twoWheeler.quickQuote.vehicleModel.motorVariant = $rootScope.collectPremRecentActivities.quote.vehicles[0].vehicleDetails.variant;
				$scope.buyNow.twoWheeler.quickQuote.insuredDeclaredValue = $rootScope.collectPremRecentActivities.quote.vehicles[0].vehicleDetails.insuredsDeclaredValue;

				$scope.buyNow.twoWheeler.additionalDetails.yrOfManufactureTW.name = $rootScope.collectPremRecentActivities.quote.vehicles[0].vehicleDetails.yearOfManufacture;
				$scope.buyNow.twoWheeler.additionalDetails.engineNumTW = $rootScope.collectPremRecentActivities.quote.vehicles[0].vehicleDetails.engineNo;
				$scope.buyNow.twoWheeler.additionalDetails.chassisNumTW = $rootScope.collectPremRecentActivities.quote.vehicles[0].vehicleDetails.chassisNo;
				$scope.buyNow.twoWheeler.additionalDetails.vehZoneTW = $rootScope.collectPremRecentActivities.quote.vehicles[0].vehicleDetails.vehicleZone;
				$scope.buyNow.twoWheeler.additionalDetails.clrRCBookTW = $rootScope.collectPremRecentActivities.quote.vehicles[0].vehicleDetails.colorAsPerRCbook;
				$scope.buyNow.twoWheeler.additionalDetails.typeOfFuelTW = $rootScope.collectPremRecentActivities.quote.vehicles[0].vehicleDetails.typeOfFuel;
				$scope.buyNow.twoWheeler.additionalDetails.wattageInKW = $rootScope.collectPremRecentActivities.quote.vehicles[0].vehicleDetails.wattage; //CR_3633
				$scope.buyNow.twoWheeler.additionalDetails.inbuiltBiFuelSysTW = $rootScope.collectPremRecentActivities.quote.vehicles[0].vehicleDetails.inBuiltBifuelSystemfitted;
				$scope.buyNow.twoWheeler.additionalDetails.valOfBiFuelSysTW = $rootScope.collectPremRecentActivities.quote.vehicles[0].vehicleDetails.valueOfBifuelsystemInRs;
				$scope.buyNow.twoWheeler.additionalDetails.polExcessTW = $rootScope.collectPremRecentActivities.quote.vehicles[0].vehicleDetails.additionalVehicleDetails.policyExcess;
				$scope.buyNow.twoWheeler.ncbDetails.ncbOnPrevPolicyTW = $rootScope.collectPremRecentActivities.quote.previousPolicyDetails.nCBfromPreviousPolicy;
				$scope.buyNow.twoWheeler.ncbDetails.ncbPercOnPrevPolicyTW = $rootScope.collectPremRecentActivities.quote.previousPolicyDetails.nCBPercentOnPreviousPolicy;
				$scope.buyNow.twoWheeler.ncbDetails.ncbClaimStatusTW = $rootScope.collectPremRecentActivities.quote.previousPolicyDetails.anyClaimPendingOrPaidOnPolicyWhichIsToBeRenewed;
				$scope.buyNow.twoWheeler.ncbDetails.ncbApplicablePerc = $rootScope.collectPremRecentActivities.quote.previousPolicyDetails.nCBApplicablePercentage;
				$scope.buyNow.twoWheeler.addCovers.ownerDriveVehOrNotTW = $rootScope.collectPremRecentActivities.quote.vehicles[0].vehicleDetails.doYouHoldValidDrivingLicense;
				$scope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner = $rootScope.collectPremRecentActivities.quote.vehicles[0].vehicleDetails.ownerDetails.licenseTypeOwnerDriver;
				$scope.buyNow.twoWheeler.addCovers.sumInsForOwnerDriver = $rootScope.collectPremRecentActivities.quote.vehicles[0].coverages[0].additionalCoverageDetails.sumInsuredForPAToOwnerDriver;
				$scope.buyNow.twoWheeler.addCovers.nameOfNominee = $rootScope.collectPremRecentActivities.quote.vehicles[0].vehicleDetails.nomineeDetails.name;
				$scope.buyNow.twoWheeler.addCovers.ageOfNominee = $rootScope.collectPremRecentActivities.quote.vehicles[0].vehicleDetails.nomineeDetails.age;
				$scope.buyNow.twoWheeler.addCovers.relnWithInsured = $rootScope.collectPremRecentActivities.quote.vehicles[0].vehicleDetails.nomineeDetails.relationshipWithInsured;
				$scope.buyNow.twoWheeler.addCovers.paCoverForUnnamedPersonTW = $rootScope.collectPremRecentActivities.quote.vehicles[0].coverages[0].additionalCoverageDetails.includePACoverForUnnamedPersonOrhirerPillionPassengers;
				$scope.buyNow.twoWheeler.addCovers.paCoverForUnnamedPersonRadioTW = $rootScope.collectPremRecentActivities.quote.vehicles[0].coverages[0].additionalCoverageDetails.numberOfUnnamedPersons;
				
				/*  cr_np_941  Start*/
				$scope.buyNow.twoWheeler.addCovers.DurationForPaOwnerDriverCover = $rootScope.collectPremRecentActivities.quote.vehicles[0].coverages[0].additionalCoverageDetails.selectPolicyDurationForPAToOwnerDriverCover;
				/*cr_np_941  End */
				/*NP_CR_3444 Start*/
		$scope.buyNow.twoWheeler.addCovers.compulsoryPACoverPolicy = $rootScope.collectPremRecentActivities.quote.vehicles[0].coverages[0].additionalCoverageDetails.standAloneCompulsoryPACover;
		$scope.buyNow.twoWheeler.addCovers.sumInsuredOfAtleast15lacs = $rootScope.collectPremRecentActivities.quote.vehicles[0].coverages[0].additionalCoverageDetails.pAPolicyWithSumInsured;
		/*$scope.buyNow.twoWheeler.addCovers.paCoverForAnyOtherVehicle = $rootScope.collectPremRecentActivities.quote.vehicles[0].coverages[0].additionalCoverageDetails.compulsoryPACoverOtherVehicle;*/ //CR_3444B
		
		/*NP_CR_3444 End*/
		/*NP_CR_0898 Start*/
				$scope.buyNow.twoWheeler.enhancementCoverages.nilDepreciation = $rootScope.collectPremRecentActivities.quote.vehicles[0].coverages[0].addOnEnhancementCoverages.nilDepreciation;
		$scope.buyNow.twoWheeler.enhancementCoverages.roadTaxCover = $rootScope.collectPremRecentActivities.quote.vehicles[0].coverages[0].addOnEnhancementCoverages.inclusionOfRoadTaxCover;
		$scope.buyNow.twoWheeler.enhancementCoverages.roadTaxAmount = $rootScope.collectPremRecentActivities.quote.vehicles[0].coverages[0].addOnEnhancementCoverages.roadTaxAmount;
		$scope.buyNow.twoWheeler.enhancementCoverages.invoiceCover = $rootScope.collectPremRecentActivities.quote.vehicles[0].coverages[0].addOnEnhancementCoverages.returnToInvoiceCover;
		$scope.buyNow.twoWheeler.enhancementCoverages.ncbProtectionCover = $rootScope.collectPremRecentActivities.quote.vehicles[0].coverages[0].addOnEnhancementCoverages.ncbProtectionCover;
		$scope.buyNow.twoWheeler.enhancementCoverages.engineProtectCover = $rootScope.collectPremRecentActivities.quote.vehicles[0].coverages[0].addOnEnhancementCoverages.engineProtectCover;
		$scope.buyNow.twoWheeler.enhancementCoverages.consumableItemsCover = $rootScope.collectPremRecentActivities.quote.vehicles[0].coverages[0].addOnEnhancementCoverages.consumableItemsCover;

		/*Np_CR_0898 End */
		
		
				
				
				/*Changed by 851587 for CR_NP_0752*/
				for (var i = 0; i < $rootScope.previousInsurersList.length; i++) {
					if ($rootScope.previousInsurersList[i].codeValue == $rootScope.collectPremRecentActivities.quote.previousPolicyDetails.nameofPreviousInsurer) {
						$scope.buyNow.twoWheeler.prevPolicyDetails.nameOfPrevIns = $rootScope.previousInsurersList[i].mnemonic;
						break;
					} else {
						$scope.buyNow.twoWheeler.prevPolicyDetails.nameOfPrevIns = "";
					}
				}
				/*CR_NP_0752 Ends*/
					
				$scope.buyNow.twoWheeler.prevPolicyDetails.prevPolNum = $rootScope.collectPremRecentActivities.quote.previousPolicyDetails.previousPolicyNo;
				$scope.buyNow.twoWheeler.prevPolicyDetails.prevPolExpDate = $rootScope.collectPremRecentActivities.quote.previousPolicyDetails.previousPolicyExpiryDate;
				$scope.buyNow.twoWheeler.financierDetails.financierName = $rootScope.collectPremRecentActivities.quote.vehicles[0].vehicleDetails.financierDetails.name;
				$scope.buyNow.twoWheeler.financierDetails.typeOfFinancier = $rootScope.collectPremRecentActivities.quote.vehicles[0].vehicleDetails.financierDetails.typeOfAgreement;
				$scope.buyNow.twoWheeler.insuredDetails.firstName = $rootScope.collectPremRecentActivities.quote.partyDetailsList[0].individualDetails.firstName;
				$scope.buyNow.twoWheeler.insuredDetails.lastName = $rootScope.collectPremRecentActivities.quote.partyDetailsList[0].individualDetails.lastName;
				$scope.buyNow.twoWheeler.insuredDetails.DOB = $rootScope.collectPremRecentActivities.quote.partyDetailsList[0].individualDetails.dateOfBirth;
				$scope.buyNow.twoWheeler.insuredDetails.gender = $rootScope.collectPremRecentActivities.quote.partyDetailsList[0].individualDetails.gender;
				$scope.buyNow.twoWheeler.insuredDetails.buildingNoStreet = $rootScope.collectPremRecentActivities.quote.partyDetailsList[0].individualDetails.buildingNoStreet;
				$scope.buyNow.twoWheeler.insuredDetails.locality = $rootScope.collectPremRecentActivities.quote.partyDetailsList[0].individualDetails.locality;
				$scope.buyNow.twoWheeler.insuredDetails.pinCode = $rootScope.collectPremRecentActivities.quote.partyDetailsList[0].individualDetails.pinCode;
				$scope.buyNow.twoWheeler.insuredDetails.mobileNo = $rootScope.collectPremRecentActivities.quote.partyDetailsList[0].individualDetails.mobileNo;
				$scope.buyNow.twoWheeler.insuredDetails.emailID = $rootScope.collectPremRecentActivities.quote.partyDetailsList[0].individualDetails.emailId;
				$scope.buyNow.twoWheeler.insuredDetails.panNum = $rootScope.collectPremRecentActivities.quote.partyDetailsList[0].individualDetails.panNumber.toUpperCase();
				$scope.buyNow.twoWheeler.insuredDetails.eInsAccNo = $rootScope.collectPremRecentActivities.quote.partyDetailsList[0].individualDetails.eInsuranceAccountNo;


				$scope.buyNow.twoWheeler.insuredDetails.gstRegIdType = $rootScope.collectPremRecentActivities.quote.partyDetailsList[0].individualDetails.gstRegIdType;
				if ($scope.buyNow.twoWheeler.insuredDetails.gstRegIdType == 'NCC') {
					$scope.buyNow.twoWheeler.insuredDetails.gstRegIdType = 'Normal, Composite, Casual';
				} else if ($scope.buyNow.twoWheeler.insuredDetails.gstRegIdType == 'UNB') {
					$scope.buyNow.twoWheeler.insuredDetails.gstRegIdType = 'UN Bodies/Embassy';
				} else if ($scope.buyNow.twoWheeler.insuredDetails.gstRegIdType == 'NRI') {
					$scope.buyNow.twoWheeler.insuredDetails.gstRegIdType = 'NRI';
				} else {
					$scope.buyNow.twoWheeler.insuredDetails.gstRegIdType = undefined;
				}


				$scope.buyNow.twoWheeler.insuredDetails.gstin = $rootScope.collectPremRecentActivities.quote.partyDetailsList[0].individualDetails.gstin;
				$scope.buyNow.twoWheeler.insuredDetails.uin = $rootScope.collectPremRecentActivities.quote.partyDetailsList[0].individualDetails.uin;

				if ($rootScope.collectPremRecentActivities.quote.partyDetailsList[0].individualDetails.state != null && $rootScope.collectPremRecentActivities.quote.partyDetailsList[0].individualDetails.state != undefined) {
					var header = {
						'Content-Type': 'application/json',
						'applicationid': 'mobile',
						'customerName': 'CUSTOMER',
						'typeOfCustomer': 'CUSTOMER'
					};
					var getStateListInput = {
						"state": "",
						"city": ""
					};
					var url = RestServices.urlConstantPortal + RestServices.urlPaths.getStateList;
					var getStateListResponse = RestServices.postService(url, getStateListInput, header);

					getStateListResponse.then(function (response) {
						CommonServices.showLoading(false);

						if (response.data.hasOwnProperty('states')) {
							for (i = 0; i < response.data.states.length; i++) {
								if (response.data.states[i].stateCode == $rootScope.collectPremRecentActivities.quote.partyDetailsList[0].individualDetails.state) {
									$scope.buyNow.twoWheeler.insuredDetails.polHolderState = response.data.states[i].state;
									populateCityFromRecAct();
								}
							}

						}
					}, function (error) {
						CommonServices.showLoading(false);
						RestServices.handleWebServiceError(error);
					});
				}/*else{
                          //State value is not present or undefined
                         // CommonServices.showAlert("State/City/PinCode values are mandatory. Please enter and save the Quote again to proceed.");
                          /*$scope.goBack();
                      }*/


				function populateCityFromRecAct() {
					if ($rootScope.collectPremRecentActivities.quote.partyDetailsList[0].individualDetails.city != null && $rootScope.collectPremRecentActivities.quote.partyDetailsList[0].individualDetails.city != undefined) {

						if ($scope.buyNow.twoWheeler.insuredDetails.polHolderState != null && $scope.buyNow.twoWheeler.insuredDetails.polHolderState != undefined) {

							var header = {
								'Content-Type': 'application/json',
								'applicationid': 'mobile',
								'customerName': 'CUSTOMER',
								'typeOfCustomer': 'CUSTOMER'
							};
							var getAllCitiesListInput = {
								"state": $scope.buyNow.twoWheeler.insuredDetails.polHolderState,
								"city": ""
							}
							var url = RestServices.urlConstantPortal + RestServices.urlPaths.getCitiesList;
							var getCitiesListResponse = RestServices.postService(url, getAllCitiesListInput, header);

							getCitiesListResponse.then(function (response) {
								CommonServices.showLoading(false);
								var citiesArr = [];
								if (response.data.hasOwnProperty('cities')) {
									for (i = 0; i < response.data.cities.length; i++) {

										if (response.data.cities[i].cityCode == $rootScope.collectPremRecentActivities.quote.partyDetailsList[0].individualDetails.city) {
											$scope.buyNow.twoWheeler.insuredDetails.polHolderCity = response.data.cities[i]; //CR880
										}
									}
								} else {
									CommonServices.showAlert("Error Occured. Please try again");
								}
							}, function (error) {
								CommonServices.showLoading(false);
								RestServices.handleWebServiceError(error);
							});
						}
					}
				}


				if ($rootScope.collectPremRecentActivities.quote.vehicles[0].vehicleDetails.newVehicle != "Y") {
					/*its for Renew*/
					$scope.buyNow.twoWheeler.additionalDetails.reg1TW = $rootScope.collectPremRecentActivities.quote.vehicles[0].vehicleDetails.registrationNo1;
					$scope.buyNow.twoWheeler.additionalDetails.reg2TW = $rootScope.collectPremRecentActivities.quote.vehicles[0].vehicleDetails.registrationNo2;
					$scope.buyNow.twoWheeler.additionalDetails.reg3TW = $rootScope.collectPremRecentActivities.quote.vehicles[0].vehicleDetails.registrationNo3;
					$scope.buyNow.twoWheeler.additionalDetails.reg4TW = $rootScope.collectPremRecentActivities.quote.vehicles[0].vehicleDetails.registrationNo4;
					$scope.buyNow.twoWheeler.additionalDetails.dateOfRegTW = $rootScope.collectPremRecentActivities.quote.vehicles[0].vehicleDetails.dateOfRegistration;
				} else {
					/*its for Buy New*/
					$scope.buyNow.twoWheeler.additionalDetails.reg1TW = '';
					$scope.buyNow.twoWheeler.additionalDetails.dateOfRegTW = date1;
				}

				if ($scope.buyNow.twoWheeler.addCovers.nameOfNominee == "NONE") {
					$scope.buyNow.twoWheeler.addCovers.nameOfNominee = "";
				}
				if ($scope.buyNow.twoWheeler.addCovers.relnWithInsured == "NONE") {
					$scope.buyNow.twoWheeler.addCovers.relnWithInsured = "";
				}
				if ($scope.buyNow.twoWheeler.addCovers.ageOfNominee == "0") {
					$scope.buyNow.twoWheeler.addCovers.ageOfNominee = "";
				}
				if ($scope.buyNow.twoWheeler.prevPolicyDetails.nameOfPrevIns == "NA") {
					$scope.buyNow.twoWheeler.prevPolicyDetails.nameOfPrevIns = "";
				}
				if ($scope.buyNow.twoWheeler.prevPolicyDetails.prevPolNum == "NA") {
					$scope.buyNow.twoWheeler.prevPolicyDetails.prevPolNum = "";
				}
				//MALE CHANGED TO Male
				if ($scope.buyNow.twoWheeler.insuredDetails.gender === "M" || $scope.buyNow.twoWheeler.insuredDetails.gender.toLowerCase === "Male") {
					$scope.buyNow.twoWheeler.insuredDetails.gender = "Male";
				} else {
					$scope.buyNow.twoWheeler.insuredDetails.gender = "Female";
				}
				if ($scope.buyNow.twoWheeler.additionalDetails.inbuiltBiFuelSysTW === "N" || $scope.buyNow.twoWheeler.additionalDetails.inbuiltBiFuelSysTW === "No") {
					$scope.buyNow.twoWheeler.additionalDetails.inbuiltBiFuelSysTW = "No";
				} else {
					$scope.buyNow.twoWheeler.additionalDetails.inbuiltBiFuelSysTW = "Yes";
				}
				if ($scope.buyNow.twoWheeler.ncbDetails.ncbOnPrevPolicyTW === "Y") {
					$scope.buyNow.twoWheeler.ncbDetails.ncbOnPrevPolicyTW = "Yes";
				} else {
					$scope.buyNow.twoWheeler.ncbDetails.ncbOnPrevPolicyTW = "No";
				}
				if ($scope.buyNow.twoWheeler.ncbDetails.ncbClaimStatusTW === "Y") {
					$scope.buyNow.twoWheeler.ncbDetails.ncbClaimStatusTW = "Yes";
				} else {
					$scope.buyNow.twoWheeler.ncbDetails.ncbClaimStatusTW = "No";
				}
				if ($scope.buyNow.twoWheeler.addCovers.ownerDriveVehOrNotTW == "Y") {
					$scope.buyNow.twoWheeler.addCovers.ownerDriveVehOrNotTW = "Yes";
				}
				else {
					$scope.buyNow.twoWheeler.addCovers.ownerDriveVehOrNotTW = "No";
				}
				if ($scope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner === "MCGEAR") {
					$scope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner = "Motor Cycle with Gear";
				} else if ($scope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner === "MCNOGEAR") {
					$scope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner = "Motor Cycle without Gear";
				} else {
					$scope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner = "";
				}
				if ($scope.buyNow.twoWheeler.addCovers.paCoverForUnnamedPersonTW == "Y") {
					$scope.buyNow.twoWheeler.addCovers.paCoverForUnnamedPersonTW = "Yes";
				}
				else {
					$scope.buyNow.twoWheeler.addCovers.paCoverForUnnamedPersonTW = "No";
				}
				if ($scope.buyNow.twoWheeler.additionalDetails.vehZoneTW === "A") {
					$scope.buyNow.twoWheeler.additionalDetails.vehZoneTW = "A (Ahmedabad, Bengaluru, Chennai, Hyderabad, Kolkata, Mumbai, New Delhi, Pune)";
				} else {
					$scope.buyNow.twoWheeler.additionalDetails.vehZoneTW = "B (Rest of India)";
				}
				$scope.otpResendCount = 0;

			} else { //New Business

				$scope.buyNow.twoWheeler.summaryDetails.quoteNumber = GetSetResponseService.getsaveQuoteResponseData()[0].quote.quoteNumber;
				$scope.buyNow.twoWheeler.summaryDetails.netPremium = GetSetResponseService.getsaveQuoteResponseData()[0].quote.premiumDetails.netPremium;
				$scope.buyNow.twoWheeler.summaryDetails.serviceTax = GetSetResponseService.getsaveQuoteResponseData()[0].quote.premiumDetails.serviceTax;
				$scope.buyNow.twoWheeler.summaryDetails.totalPremium = GetSetResponseService.getsaveQuoteResponseData()[0].quote.premiumDetails.totalPremium;

				if ($rootScope.buyNow.twoWheeler.addCovers.ownerDriveVehOrNotTW == "Y") {
					$rootScope.buyNow.twoWheeler.addCovers.ownerDriveVehOrNotTW = "Yes";
				}
				else {
					$rootScope.buyNow.twoWheeler.addCovers.ownerDriveVehOrNotTW = "No";
					/*$rootScope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner="";*/
				}

				if ($rootScope.buyNow.twoWheeler.addCovers.paCoverForUnnamedPersonTW == true) {
					$rootScope.buyNow.twoWheeler.addCovers.paCoverForUnnamedPersonTW = "Yes";
				}
				else {
					$rootScope.buyNow.twoWheeler.addCovers.paCoverForUnnamedPersonTW = "No";

				}

				if ($scope.buyNow.twoWheeler.ncbDetails.ncbOnPrevPolicyTW === "Y") {
					$scope.buyNow.twoWheeler.ncbDetails.ncbOnPrevPolicyTW = "Yes";
				} else {
					$scope.buyNow.twoWheeler.ncbDetails.ncbOnPrevPolicyTW = "No";
				}

				if ($scope.buyNow.twoWheeler.ncbDetails.ncbClaimStatusTW === "Y") {
					$scope.buyNow.twoWheeler.ncbDetails.ncbClaimStatusTW = "Yes";
				} else {
					$scope.buyNow.twoWheeler.ncbDetails.ncbClaimStatusTW = "No";
				}
				/* Added by 851587 for CR_NP_0752*/
				var prevInsurer = $scope.buyNow.twoWheeler.prevPolicyDetails.nameOfPrevIns;
				for (var i = 0; i < $rootScope.previousInsurersList.length; i++) {
					if ($rootScope.previousInsurersList[i].codeValue == prevInsurer) {
						$scope.buyNow.twoWheeler.prevPolicyDetails.nameOfPrevIns = $rootScope.previousInsurersList[i].mnemonic;
						break;
					} else {
						$scope.buyNow.twoWheeler.prevPolicyDetails.nameOfPrevIns = "";
					}
				}
				/*CR_NP_0752 ends*/
				
				/*Changed by for CR_NP_3621*/
				
				var prevInsurer = $scope.buyNow.twoWheeler.StandaloneODDetails.nameOfPrevIns;
				for (var i = 0; i < $rootScope.previousInsurersList.length; i++) {
					if ($rootScope.previousInsurersList[i].codeValue == prevInsurer) {
						$scope.buyNow.twoWheeler.StandaloneODDetails.nameOfPrevIns = $rootScope.previousInsurersList[i].mnemonic;
						break;
					} else {
						$scope.buyNow.twoWheeler.StandaloneODDetails.nameOfPrevIns = "";
					}
				}
				/*CR_NP_3621 Ends*/

				if ($scope.buyNow.twoWheeler.additionalDetails.vehZoneTW === "A") {
					$scope.buyNow.twoWheeler.additionalDetails.vehZoneTW = "A (Ahmedabad, Bengaluru, Chennai, Hyderabad, Kolkata, Mumbai, New Delhi, Pune)";
				} else {
					$scope.buyNow.twoWheeler.additionalDetails.vehZoneTW = "B (Rest of India)";
				}

				if ($rootScope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner === "MCGEAR") {

					$scope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner = "Motor Cycle with Gear";
				} else if ($rootScope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner === "MCNOGEAR") {
					$scope.buyNow.twoWheeler.addCovers.licenseTypeOfOwner = "Motor Cycle without Gear";
				}


				if ($scope.buyNow.twoWheeler.insuredDetails.partyType === "I") {
					if ($scope.buyNow.twoWheeler.insuredDetails.individualDetails.gstRegIdType == 'NCC') {
						$scope.buyNow.twoWheeler.insuredDetails.gstRegIdType = 'Normal, Composite, Casual';
					} else if ($scope.buyNow.twoWheeler.insuredDetails.individualDetails.gstRegIdType == 'UNB') {
						$scope.buyNow.twoWheeler.insuredDetails.gstRegIdType = 'UN Bodies/Embassy';
					} else if ($scope.buyNow.twoWheeler.insuredDetails.individualDetails.gstRegIdType == 'NRI') {
						$scope.buyNow.twoWheeler.insuredDetails.gstRegIdType = 'NRI';
					} else {
						$scope.buyNow.twoWheeler.insuredDetails.gstRegIdType = undefined;
					}
					if ($scope.buyNow.twoWheeler.insuredDetails.individualDetails.polHolderState !== undefined) {
						if ($scope.buyNow.twoWheeler.insuredDetails.individualDetails.polHolderState.state == undefined) {
							$scope.buyNow.twoWheeler.insuredDetails.polHolderState = $scope.buyNow.twoWheeler.insuredDetails.individualDetails.polHolderState;
						} else {
							$scope.buyNow.twoWheeler.insuredDetails.polHolderState = $scope.buyNow.twoWheeler.insuredDetails.individualDetails.polHolderState.state;
						}
					}

				}
				if ($scope.buyNow.twoWheeler.insuredDetails.partyType === "O") {
					if ($scope.buyNow.twoWheeler.insuredDetails.organizationDetails.gstRegIdType == 'NCC') {
						$scope.buyNow.twoWheeler.insuredDetails.gstRegIdType = 'Normal, Composite, Casual';
					} else if ($scope.buyNow.twoWheeler.insuredDetails.organizationDetails.gstRegIdType == 'UNB') {
						$scope.buyNow.twoWheeler.insuredDetails.gstRegIdType = 'UN Bodies/Embassy';
					} else if ($scope.buyNow.twoWheeler.insuredDetails.organizationDetails.gstRegIdType == 'NRI') {
						$scope.buyNow.twoWheeler.insuredDetails.gstRegIdType = 'NRI';
					} else {
						$scope.buyNow.twoWheeler.insuredDetails.gstRegIdType = undefined;
					}
					if ($scope.buyNow.twoWheeler.insuredDetails.organizationDetails.polHolderState !== undefined) {
						if ($scope.buyNow.twoWheeler.insuredDetails.organizationDetails.polHolderState.state == undefined) {
							$scope.buyNow.twoWheeler.insuredDetails.polHolderState = $scope.buyNow.twoWheeler.insuredDetails.organizationDetails.polHolderState;
						} else {
							$scope.buyNow.twoWheeler.insuredDetails.polHolderState = $scope.buyNow.twoWheeler.insuredDetails.organizationDetails.polHolderState.state;
						}
					}
				}


				$scope.otpResendCount = 0;
			}
		}
	};

	/**CR690 Start**/
	$rootScope.panmodalOpen = false;

	var panCardDetails = {
		"quoteNumber": GetSetResponseService.getsaveQuoteResponseData()[0].quote.quoteNumber,
		"policyHolderCode": CommonServices.getCommonData("partyCode")
	}
	CommonServices.setCommonData("panCardData", panCardDetails);
	/**CR690 End**/

	$scope.sqSummaryDetailsCtrl.onload();

	$scope.numberExpOtp = /^[\d]+$/;

	$scope.goBack = function () {


		if (CommonServices.deviceType != "NA") {
			navigator.notification.confirm("You may lose your data.Are you sure you want to navigate back to home screen ?", navigateToPolicyHolder, "Alert", ["Ok", "Cancel"]);
		}
		else {
			var vehicleDetailConfirm = confirm("You may lose your data.Are you sure you want to navigate back to home screen ?");
			if (vehicleDetailConfirm == true) {
				navigateToPolicyHolder(1);
			}
		}

	};
	$scope.viewBreakupShow = false;
	$scope.closePopup = function () {
		$scope.viewBreakupShow = false;
	};
	$scope.hideModal = function () {
		$scope.viewBreakupShow = false;
	};
	
	/******* added for CR_0805 start *******/
	
	$scope.viewBreakupShow = false;
	$scope.closePopup = function () {
		$scope.viewBreakupShow = false;
	};
	$scope.hideModal = function () {
		$scope.viewBreakupShow = false;
	};
	$scope.viewBreakup = function () {
		
		
		var viewBreakupData =
		{
			"quote": { "quoteNumber": $scope.buyNow.twoWheeler.summaryDetails.quoteNumber, "policyHolderCode": $scope.buyNow.twoWheeler.insuredDetails.partyCode },
			"userProfile": { "userId": CommonServices.getCommonData("userId"), "loggedInRole": "SUPERUSER" }
		};
		 var header = {
            'Content-Type': 'application/json',
            'applicationid': 'mobile',
            'customerName': 'CUSTOMER',
            'typeOfCustomer': 'CUSTOMER',
            'userid': CommonServices.getCommonData("userId")
            //'X-Auth-Token': GetSetResponseService.getloginResponseData()[0].token

        };
		var url="";
        if($rootScope.term1==1)
		{
		  url= RestServices.urlPathsNewPortal.getPremiumDistribution;
		   
		  
		}
		else 
	    {
		  url=RestServices.urlPathsNewPortal.getPremiumDistributionLongTerm;
		  
		}
		
		
		var viewBreakupResponse = RestServices.postService(url, viewBreakupData,header);
		viewBreakupResponse.then(
			function (response) { // success 
				CommonServices.showLoading(false);
				if ((response.data.quote !== undefined && response.data.quote !== "")||(response.data.longTermPremiumDetailList!==undefined && response.data.longTermPremiumDetailList!=="")) {
					//Will navigate to billdesk page.

					if ((response.data.longTermPremiumDetailList!==undefined && response.data.longTermPremiumDetailList!=="")) {
						$scope.viewBreakupShow = true;
						if($rootScope.term1==1)
						{
							if(response.data.quote.premiumDetails instanceof Array)
						    {
							 $scope.premiumDetails = response.data.quote.premiumDetails;
							}
							else
							{
								 $scope.premiumDetails = [];
								 $scope.premiumDetails.put(response.data.quote.premiumDetails);
							}
						}
						else
						{
							
							 $scope.premiumDetails = response.data.longTermPremiumDetailList
							
						}
							
						//$scope.premiumDetails = response.data.quote.premiumDetails;
						$scope.prepareViewBreakUpData($scope.premiumDetails);//new
					}
					
					if((response.data.quote!==undefined && response.data.quote!==""))
					{
						if ((response.data.quote.premiumDetails!==undefined && response.data.quote.premiumDetails!=="")) {
							$scope.viewBreakupShow = true;
							if($rootScope.term1==1)
							{
								if(response.data.quote.premiumDetails instanceof Array)
								{
								 $scope.premiumDetails = response.data.quote.premiumDetails;
								}
								else
								{
									 $scope.premiumDetails = [];
									 $scope.premiumDetails.push(response.data.quote.premiumDetails);
								}
							}
							else
							{
								
								 $scope.premiumDetails = response.data.longTermPremiumDetailList
								
							}
								
							//$scope.premiumDetails = response.data.quote.premiumDetails;
							$scope.prepareViewBreakUpData($scope.premiumDetails);//new
						}
					}
					
					

				} else {
					CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
				}
			},
			function (error) { // failure
				CommonServices.showLoading(false);
				RestServices.handleWebServiceError(error);
			});
	}
     
	$scope.prepareViewBreakUpData=function(data)
	{
		
   
		$scope.viewBreakupResult=data;
		var policyDuration=$rootScope.term1;
		var coverCode=$rootScope.buyNow.twoWheeler.basicPremium.coverage;
		//alert("policy durration"+ policyDuration);
		var totalPremium = 0;
		if(policyDuration > 1){
		//console.log("printing data+"+JSON.stringify($scope.viewBreakupResult));
			
		    if(policyDuration ==5 && coverCode != 'L'  && $scope.viewBreakupResult.length ==1){
				for(var temp=1;temp<policyDuration;temp++){
					$scope.viewBreakupResult[temp] ={};
					$scope.viewBreakupResult[temp].year = parseInt(temp)+1;
					if(temp == 1){
						$scope.viewBreakupResult[temp].totalTPPremium = $scope.viewBreakupResult[0].totalTPPremiumFor2ndYr;
						$scope.viewBreakupResult[temp].basicTPPremium = $scope.viewBreakupResult[0].totalTPPremiumFor2ndYr;
					}
					else if(temp == 2){
						$scope.viewBreakupResult[temp].totalTPPremium = $scope.viewBreakupResult[0].totalTPPremiumFor3rdYr;
						$scope.viewBreakupResult[temp].basicTPPremium = $scope.viewBreakupResult[0].totalTPPremiumFor3rdYr;
					}
					else if(temp == 3){
						$scope.viewBreakupResult[temp].totalTPPremium = $scope.viewBreakupResult[0].totalTPPremiumFor4thYr;
						$scope.viewBreakupResult[temp].basicTPPremium = $scope.viewBreakupResult[0].totalTPPremiumFor4thYr;
					}
					else if(temp == 4){
						$scope.viewBreakupResult[temp].totalTPPremium = $scope.viewBreakupResult[0].totalTPPremiumFor5thYr;
						$scope.viewBreakupResult[temp].basicTPPremium = $scope.viewBreakupResult[0].totalTPPremiumFor5thYr;
					}
				}
			}
						
			for(var i=0;i<$scope.viewBreakupResult.length;i++){
					
				//var year = ($scope.viewBreakupResult[i].coverCode).charAt($scope.viewBreakupResult[i].coverCode.length-1);
				//$scope.viewBreakupResult[i].year = isNaN(year)?'1':year; 
				$scope.viewBreakupResult[i].year = parseInt(i)+1;
				if($scope.viewBreakupResult[i].totalPremium != undefined){
					totalPremium += parseInt($scope.viewBreakupResult[i].totalPremium);
				}
				
			}
			$scope.viewBreakupResult[0].totalPremium = totalPremium;
		}else{
			$scope.viewBreakupResult[0].year = 1;
		}
		//console.log("printing data+"+JSON.stringify($scope.viewBreakupResult));
	};		
	
	
	/******* added for CR_0805 End *******/

	
	
	
	
	
	
	/**** commented as part of CR_0805 START******/
	/***
	$scope.viewBreakup = function () {
		var viewBreakupData =
			{
				"quote": { "quoteNumber": $scope.buyNow.twoWheeler.summaryDetails.quoteNumber, "policyHolderCode": $scope.buyNow.twoWheeler.insuredDetails.partyCode },
				"userProfile": { "userId": CommonServices.getCommonData("userId"), "loggedInRole": "SUPERUSER" }
			};

		var viewBreakupResponse = RestServices.postService(RestServices.urlPathsNewPortal.getPremiumDistribution, viewBreakupData);
		viewBreakupResponse.then(
			function (response) { // success 
				CommonServices.showLoading(false);
				if (response.data.quote !== undefined && response.data.quote !== "") {
					//Will navigate to billdesk page.

					if (response.data.quote.premiumDetails !== undefined && response.data.quote.premiumDetails !== "") {
						$scope.viewBreakupShow = true;
						$scope.premiumDetails = response.data.quote.premiumDetails;
					}

				} else {
					CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
				}
			},
			function (error) { // failure
				CommonServices.showLoading(false);
				RestServices.handleWebServiceError(error);
			});
	}

/**** commented as part of CR_0805 end******/

	function navigateToPolicyHolder(button) {
		if (button == 1) {
			$rootScope.buyNow.twoWheeler.addCovers = {};
			$rootScope.buyNow.twoWheeler.prevPolicyDetails = {};
			$rootScope.buyNow.twoWheeler.ncbDetails = {};
			$rootScope.buyNow.twoWheeler.financierDetails = {};
			CommonServices.setCommonData("backFlag", "summarydetailsBack");
			$state.go("sqcreatePolicyHolder");
		}
	}

	$scope.home = function () {
		navigator.notification.confirm("Are you sure you want to navigate back to home screen ?", navigateToHomeScreen, "Alert", ["Ok", "Cancel"]);
	};


	function navigateToHomeScreen(button) {
		if (button == 1) {
			$rootScope.buyNow.twoWheeler.newVehicle = "";
			$rootScope.buyNow.twoWheeler.quickQuote = {};
			$rootScope.buyNow.twoWheeler.basicPremium = {};
			$rootScope.buyNow.twoWheeler.additionalDetails = {};
			$rootScope.buyNow.twoWheeler.ncbDetails = {};
			$rootScope.buyNow.twoWheeler.addCovers = {};
			$rootScope.buyNow.twoWheeler.prevPolicyDetails = {};
			$rootScope.buyNow.twoWheeler.financierDetails = {};
			$rootScope.buyNow.twoWheeler.insuredDetails = {};
			$rootScope.buyNow.twoWheeler.summaryDetails = {};
			$rootScope.buyNow.twoWheeler.StandaloneODDetails = {}; //CR_3621
			CommonServices.fromRAForEditQuote = false;
			CommonServices.SQParentPolicyHistory = false;
			$scope.SQfieldDisable = false;
			$state.go("home");
		}
	}

	$scope.termsAndConditionSummaryAlert = function () {
		CommonServices.showAlert("Dear Customer,You are being re-directed to a third party site. By clicking on the check box, it is assumed that the “Payment Terms & Conditions” have been read by you and accepted the same.");
	}

	$rootScope.reCalPremium = false;
	$scope.buyNowTW = function () {
		CommonServices.setCommonData("backFlag", "");
		$rootScope.saveQuoteTW();
	}

	$scope.approveQuote = function (type = '') {
		var approvePayData =
			{
				"userProfile": { "userId": CommonServices.getCommonData("userId"), "loggedInRole": "SUPERUSER", "uiFlow": "NON_CUSTOMER" }, "quote":
					{
						"quoteNumber": $scope.buyNow.twoWheeler.summaryDetails.quoteNumber, "policyType": null, "productCode": "SQ",
						"policyStartDate": $scope.buyNow.twoWheeler.quickQuote.policyStartDate
					}
			};
			CommonServices.setCommonData("addToCart", type); // CR3546
			
			if (CommonServices.getCommonData("addToCart")==='cart') { // CR3546
				var messageSystemDate = CommonServices.getCommonData("serverDate");
				var arr = messageSystemDate.split('/');
				messageSystemDate = arr[1] + '/' + arr[0] + '/' + arr[2]; //mm/dd/yyyy

				var msg = "Do you wish to proceed with approval of quotation? Once Approved, no more changes will be made available on your quotation. Your payment should be made by " + messageSystemDate + ". Please confirm";
				CommonServices.messageModal('info', msg, false, 'Cancel', 'Confirm', function () {}, function () {
					CartServices.approveAndAddToCart(approvePayData, "SQ");
				}, 'Alert');
				return;
			}

		var approvePayResponse = RestServices.postService(RestServices.urlPathsNewPortal.approveRenewedQuote, approvePayData);
		approvePayResponse.then(
			function (response) { // success 
				CommonServices.setCommonData("productCode", "SQ");
				CommonServices.showLoading(false);
				if (response.data.userProfile.footer.errorDescription.trim() === "Proposal Approved") {
					//Will navigate to billdesk page.
					var msg = response.data.userProfile.footer.errorDescription;
						CommonServices.messageModal('info', msg, false, '', 'Ok', function () {}, function () { approvePayExitFunction(1);}, 'Alert');
					// if (CommonServices.deviceType !== "NA")
					// 	navigator.notification.confirm(response.data.userProfile.footer.errorDescription, approvePayExitFunction, "Alert", ["Ok"]);
					// else {
					// 	var approvePayment;
					// 	approvePayment = confirm(response.data.userProfile.footer.errorDescription);
					// 	if (approvePayment === true) {
					// 		approvePayExitFunction(1);
					// 	}
					// }

				} else {
					/**CR690 Start**/
					if (response.data.userProfile.footer.errorCode === "224541") {
						$rootScope.panmodalOpen = true;
						CommonServices.setCommonData("setPanMsg", response.data.userProfile.footer.errorDescription);
					}
					/**CR690 End**/
					else {
						CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
					}
				}
			},
			function (error) { // failure
				CommonServices.showLoading(false);
				RestServices.handleWebServiceError(error);
			});
	}

	function approvePayExitFunction(button) {
		CommonServices.setCommonData("CollectionPaymentDetails", GetSetResponseService.getsaveQuoteResponseData()[0].quote);
		$state.go("collectionForm");
	}

	$scope.closeOTPpopUp = function () {

		navigator.notification.confirm("Are you sure you want to close?", onCloseOTPpopUpConfirmation, "Alert", ["Ok", "Cancel"]);

	}

	function onCloseOTPpopUpConfirmation(button) {

		$scope.otpResendCount = 0;
		if (button == 1) {

			$('.reviewSummary').css("overflow", "scroll");
			$scope.summaryPageOTP = "";
			var modal = document.getElementById('summaryOTPmodal');
			modal.style.display = "none";
		}
	}


}]);
