agentApp.controller('contactDetailsController', ['$scope','RestServices','CommonServices','$state', function ($scope, RestServices,CommonServices,$state) {
	
			$scope.bodyHeight = window.innerHeight+'px';
			$scope.home = function() {
				RestServices.goHome();
			};
			var locatorListFlag = false;

			
}]);

agentApp.controller('locatorController', ['$scope','RestServices','CommonServices','$state', function ($scope, RestServices,CommonServices,$state) {
	$scope.showArrow = false;
  if(CommonServices.deviceType == "I")
    $scope.showArrow = true;
	
	$scope.back = function(){
		if($(".searchform").length > 0){
			$scope.locatorObj.data.counter = 0;
		}
		else{
			$state.go("home");
			CommonServices.setCommonData("locatorHeader", "");
		}
	}	
	var findBy = null;
	
	//Creating object for locator
	$scope.locatorObj = {
				searchBy: function($event){
					//Select by Branch, Hostpital, Garage
					$scope.locatorObj.data.searchBy = $event.target.value;
					$scope.locatorObj.data.officeType = null;
					$scope.locatorObj.data.counter++;
					if($event.target.value === 'branch'){
						$scope.locatorObj.data.officeType = 'HEAD OFFICE';
					}
				},
				locatorServiceCall: function(){
					//Service call On loactor search button
					
					if($scope.locatorObj.data.findBy.toUpperCase() === "PINCODE"){
						findBy = $scope.locatorObj.data.findByValue;
					} else {
						findBy = $scope.locatorObj.data.findByValue.toUpperCase();
					}
					RestServices.headerWithoutToken = false;
					var locatorInput ={"searchBy":$scope.locatorObj.data.searchBy.toUpperCase(),
										"findBy":$scope.locatorObj.data.findBy.toUpperCase(),
										"maxResult":250,
										"startIndex":0,
										"officeType":$scope.locatorObj.data.officeType,
										"findByValue":findBy}
					
					var locatorResponse = RestServices.postService(RestServices.urlPathsNewPortal.getLocatorDetails, locatorInput);
					locatorResponse.then(
						function(response) { // success	
							CommonServices.showLoading(false);	
							if(response.data.listLocatorResponse !== undefined){
								CommonServices.setCommonData("searchBy",$scope.locatorObj.data.searchBy.toUpperCase());
								CommonServices.setCommonData("locatorValues",response.data);
								$state.go('contactDetails.locatorList');
							} else {
								CommonServices.showAlert("No data found");
								$scope.locatorValues="";
							}
								
						},
						function(error) { // failure
							CommonServices.showLoading(false);
							RestServices.handleWebServiceError(error);
					});
				},
				searchCriteria: function(name){
				
					//Select by pincode, name, city and add
					$scope.locatorObj.data.findByValue = '';
					if(name == "pincode"){
						$scope.locatorObj.data.findBy = "pincode";
					}
					if(name == "address"){
						$scope.locatorObj.data.findBy = "address";
					}
					if(name == "city"){
						$scope.locatorObj.data.findBy = "city";
					}
					if(name == "name"){
						$scope.locatorObj.data.findBy = "name";
					}
				}
			}
			
			
			$scope.init = function() {
				// set branch, pincode and office type value on load
				$scope.locatorObj.data = {
					searchBy : 'branch',
					findBy : 'pincode',
					officeType : 'HEAD OFFICE',
					counter: 0
				};
				
				// get Office type(select box) values
				var domainInput = {"lngCode":"EN","keys":["OFFICE_TYPES","LOCATOR_TYPE","TPA_TYPES"]}; //modified for CR 0756A
				var getDomainValuesResponse = RestServices.postService(RestServices.urlPathsNewPortal.getDomainValues, domainInput);
				getDomainValuesResponse.then(
					function(response) { // success	
						CommonServices.showLoading(false);	
						$scope.domainValues = response.data.domainValues;
						$scope.tpaValues = $scope.domainValues.filter(item=>item.codeId==='TPA_TYPES'); //modified for CR 0756A
					},
					function(error) { // failure
						CommonServices.showLoading(false);
						RestServices.handleWebServiceError(error);
				});
				
				if(CommonServices.getCommonData("locatorHeader") !== "" && CommonServices.getCommonData("locatorHeader") !== undefined){
					
					$scope.locatorObj.data.counter = 1;
					if(CommonServices.getCommonData("locatorHeader") === "BRANCH"){
						$scope.locatorObj.data.searchBy ="branch";
					}
					if(CommonServices.getCommonData("locatorHeader") === "HOSPITAL"){
						$scope.locatorObj.data.searchBy ="hospital";
					}
					if(CommonServices.getCommonData("locatorHeader") === "CASHLESSGARAGE"){
						$scope.locatorObj.data.searchBy ="cashlessgarage";
					}
				}
				if(CommonServices.getCommonData("locatorHeader") === "" || CommonServices.getCommonData("locatorHeader") === undefined){
				
					$scope.locatorObj.data.counter = 0;
				}
				
			};
			
			$scope.init();
			
}]);

agentApp.controller('locatorListController', ['$scope','RestServices','CommonServices','$state', function ($scope, RestServices,CommonServices,$state) {
	
    $scope.searchBy = CommonServices.getCommonData("searchBy"); 
	$scope.back = function(){
		$state.go('contactDetails.locator');
		locatorListFlag = true;
		CommonServices.setCommonData("locatorHeader", $scope.searchBy);
	}
	
	$scope.init = function(){
		$scope.locatorValues = CommonServices.getCommonData("locatorValues");
	}
	
	$scope.init();

}]);

agentApp.controller('contactUsController', ['$scope','RestServices','CommonServices','$state','liveChat', function ($scope, RestServices,CommonServices,$state,liveChat) {
	$scope.goBack = function(){
		RestServices.goHome();
	}
		
	$scope.contactDetailsForm = function(){
		$state.go("contactDetails.contactDetailsForm");
	}
	
	var liveChatFunction = new liveChat();
	$scope.chatnow = function(){
		liveChatFunction.onClick();
	};
	
}]);

agentApp.controller('contactDetailsFormController', ['$scope','RestServices','CommonServices','$state', function ($scope, RestServices,CommonServices,$state) {
	
	$scope.goBack = function(){
		$state.go("contactDetails.contactUs");
	}
	
	$scope.contactDetailsSubmitObj ={
		contactDetailsSubmit: function(){
			$scope.contactDetailsInput ={
				"name": this.contactName,
				"emailId": this.contactEmail,
				"mobileNo": this.contactmobileNo,
				"preferredTomeToCall": this.contactpreferrdtime,
				"description": this.contactDescription
			};
			
			var contactDetailsResponse = RestServices.postService(RestServices.urlPathsNewPortal.saveCallMeDetails, $scope.contactDetailsInput);
				contactDetailsResponse.then(
					function(response) { // success	
						CommonServices.showLoading(false);	
						if(response.data.errorCode === undefined){
							CommonServices.showAlert(response.data.status);
							$state.go("contactDetails.contactUs");
						}
						else{
							CommonServices.showAlert(response.data.errorMessage);
						}
					},
					function(error) { // failure
						CommonServices.showLoading(false);
						RestServices.handleWebServiceError(error);
				});
		},
		resetContact: function(){
			$state.go("contactDetails.contactUs");
		}
	}
	
	
}]);