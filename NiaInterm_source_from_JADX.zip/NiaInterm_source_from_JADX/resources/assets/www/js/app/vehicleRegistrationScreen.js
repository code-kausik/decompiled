agentApp.controller('vehicleRegistrationScreenCtrl', ['$scope','RestServices','CommonServices','$state', function ($scope, RestServices,CommonServices,$state)
{
			
			$scope.bodyHeight = window.innerHeight+'px';
			$scope.stakevalue = CommonServices.getCommonData("stakeCode"); 
			$scope.goBack = function(){
				$state.go('home');	
				}
		$scope.regValidate = false;		
		$scope.vehicleSearchFlag=false;	
		$scope.vehicleSearchList='';
		$scope.vehicle1FocusIn = function(){

		}

		$scope.vehicle1FocusOut = function () {

			var validStateCode = $scope.vehreg.reg1TW
			var statecode = validStateCode.substring(0, 2).toUpperCase();
			var newStateCodeData = {
				"stateCode": statecode
			};
			CommonServices.showLoading(true);

			var StateCodeResponse = RestServices.postService(RestServices.urlPathsNewPortal.stateCode, newStateCodeData);

			StateCodeResponse.then(function (response) {
				CommonServices.showLoading(false);
				if (response.data.footer.errorDescription == "State code is not valid") {
					$scope.reg1ErrorMsg = 'Please enter a valid state code in Reg1';
					$scope.stateCodetrue = true;
				} else {
					$scope.stateCodetrue = false;
				}
			});
		};
		// $scope.vehicle1FocusOut = function () {
		// 	if($scope.vehreg.reg1TW === undefined || $scope.vehreg.reg1TW ==="")
		// 	{
		// 			$scope.vehreg.vehicleSearchFlag=false;
		// 	}
		// 	var validStateCode = $scope.vehreg.reg1TW;
		// 	var statecode = validStateCode.substring(0, 3).toUpperCase();
        //     if(statecode.length<=2){
		// 	var newStateCodeData = {
		// 		"stateCode": statecode
		// 	};
		// 	CommonServices.showLoading(true);

		// 	var StateCodeResponse = RestServices.postService(RestServices.urlPathsNewPortal.stateCode, newStateCodeData);

		// 	StateCodeResponse.then(function (response) {
		// 		CommonServices.showLoading(false);
		// 		if (response.data.footer.errorDescription == "State code is not valid") {
		// 			$scope.stateCodetrue = true;
		// 		} else {
		// 			$scope.stateCodetrue = false;
		// 		}
		// 	});}

		// };
		$scope.vehReg4Length = function (){
			//var validreg4 = buyNow.twoWheeler.additionalDetails.reg4TW;
			if ($scope.vehreg.reg4TW == undefined || $scope.vehreg.reg4TW.trim() == ''){
			$scope.regValidate = true;
			$scope.reg4ErrorMsg = 'This is a mandatory field';
			}else if ($scope.vehreg.reg4TW !== undefined || $scope.vehreg.reg4TW.trim() !== ''){
				$scope.regValidate = false;
			}
		};
		$scope.vehReg1Length = function () {
			$scope.stateCodetrue = false;
			if ($scope.vehreg.reg1TW == undefined || $scope.vehreg.reg1TW.trim() == '') {
				$scope.reg1ErrorMsg = 'This is a  mandatory field';
				$scope.stateCodetrue = true;

			} else if ($scope.vehreg.reg1TW !== undefined) {
				var validStateCode = $scope.vehreg.reg1TW;
				if (validStateCode.length < 2) {
					$scope.reg1ErrorMsg = 'Needs to be at least 2 characters long';
					$scope.stateCodetrue = true;
					
				} else if (validStateCode.length >= 3) {
					$scope.buyNow.twoWheeler.additionalDetails.reg2TW = "";
					$scope.buyNow.twoWheeler.additionalDetails.reg3TW = "";
					
				}
			}
		};

		$scope.vehreg={
			reg1TW: "",
			reg2TW: "",
			reg3TW: "",
			reg4TW: "",	
           vehicleSearchFlag:false,
		   vehicleSearchList:"",
		   	vehregSubmit:function()
			
			{
				
				if ($scope.vehreg.reg1TW === undefined || $scope.vehreg.reg1TW === "") {
					$scope.vehreg.reg1TW = null;
				}
				else {
					$scope.vehreg.reg1TW = $scope.vehreg.reg1TW;
				}
				if ($scope.vehreg.reg2TW === undefined || $scope.vehreg.reg2TW === "") {
					$scope.vehreg.reg2TW = null;
				}
				else {
					$scope.vehreg.reg2TW = $scope.vehreg.reg2TW;
				}
				if ($scope.vehreg.reg3TW === undefined || $scope.vehreg.reg3TW === "") {
					$scope.vehreg.reg3TW = null;
				}
				else {
					$scope.vehreg.reg3TW = $scope.vehreg.reg3TW;
				}
				if ($scope.vehreg.reg4TW === undefined || $scope.vehreg.reg4TW === "") {
					$scope.vehreg.reg4TW = null;
				}
				else {
					$scope.vehreg.reg4TW = $scope.vehreg.reg4TW;
				}
				 vehicleSearchInputData =
					{
						"userProfile":
						{"userId":"","password":""},						
						"registrationNo": 
						{
						"reg1": angular.uppercase($scope.vehreg.reg1TW),
						"reg2": angular.uppercase($scope.vehreg.reg2TW),
						"reg3": angular.uppercase($scope.vehreg.reg3TW),
						"reg4": angular.uppercase($scope.vehreg.reg4TW)
						},
						"partyDetails": 
						{
							"partyCode": CommonServices.getCommonData("userId")
							//"partyCode": "CUST199208"
						}
					}
					
			vehicleSearchResponse = RestServices.postService(RestServices.urlPathsNewPortal.vehicleSearchService, vehicleSearchInputData);
					
				vehicleSearchResponse.then(
					function (response) {
						
						CommonServices.showLoading(false);
						if (response.data === undefined) {					
								$scope.vehreg.vehicleSearchFlag=false;						
							CommonServices.showAlert(response.data.errorMessage);
									} 	
						else if (response.data.errorCode === 9041) {					
							CommonServices.showAlert("No record(s) found");
								$scope.vehreg.vehicleSearchFlag=false;
									} 										
						
						else {
							
						$scope.vehreg.vehicleSearchFlag=true;
						$scope.vehreg.vehicleSearchList= response.data.rowset.row.outerRegList.innerRegList;
								for(var i=0;i<response.data.count;i++)
								{
								if($scope.vehreg.vehicleSearchList[i].policy_INCEPTION_DATE!=null)
								{
								$scope.vehreg.vehicleSearchList[i].policy_INCEPTION_DATE=$scope.vehreg.vehicleSearchList[i].policy_INCEPTION_DATE.substring(0,10);
								}
								if($scope.vehreg.vehicleSearchList[i].policy_EXPIRY_DATE!=null)
								{
								$scope.vehreg.vehicleSearchList[i].policy_EXPIRY_DATE=$scope.vehreg.vehicleSearchList[i].policy_EXPIRY_DATE.substring(0,10);
								}
								if($scope.vehreg.vehicleSearchList[i].loss_DATE!=null)
								{
								$scope.vehreg.vehicleSearchList[i].loss_DATE=$scope.vehreg.vehicleSearchList[i].loss_DATE.substring(0,10);
								}
								if($scope.vehreg.vehicleSearchList[i].intimation_DATE!=null)
								{
								$scope.vehreg.vehicleSearchList[i].intimation_DATE=$scope.vehreg.vehicleSearchList[i].intimation_DATE.substring(0,10);
								}
								if($scope.vehreg.vehicleSearchList[i].policy_NUMBER!=null)
								{
								$scope.vehreg.vehicleSearchList[i].policy_NUMBER=$scope.vehreg.vehicleSearchList[i].policy_NUMBER.substring(0,20);
								}
								}
										
						}
					}, function (error) {
						CommonServices.showLoading(false);
						RestServices.handleWebServiceError(error);
					});
			}
			
		}
		
		
	
			
					
}]);
