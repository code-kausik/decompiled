agentApp.service('CommonServices', ['$rootScope', '$location', '$modal', '$state', function($rootScope, $location, $modal, $state) {
	// sourav CR_3618
	$rootScope.gender=[{
		"name":"Male",
		"value":"M"
	},
	{
		"name":"Female",
		"value":"F"
	},
	{
		"name":"Third Gender",
		"value":"T"
	}
	];
	this.gstIdStateCode = []; //3749
	this.noOfMembers = 0;   //3562
	this.counts = 0;		//3562
	this.countd = 0;		//3562
	this.commonData={};
	this.stateCodeValid = true;
	this.isMotor = false;
	this.checkMaxInsuredAmount = false; //sudip CR_3725
	this.isProfilePicUpdated = false; //sudip CR_3693
	this.profilePicUpdatedPath = ''; //sudip CR_3693
	/*Added by 851587 for CR_NP_0744*/
	this.initialPanNumberIsEmpty = false;
	//this.initialAadhaarNoIsEmpty = false; commented for CR_NP_0744E
	this.initialPartyCode = "";
	/*CR_NP_0744 ends*/
	var stakevalue;
	var userID ={
		"policy_type":"",
		"stakemode":""
	};
	this.chequeList = [];
	this.enableVideoUpload = true;
	$rootScope.enableVideoUpload = this.enableVideoUpload;
	this.optRoomRentRiderOption = false;
	this.processType = "";	
	this.productCode = "";
	this.saveQuoteDetailsData = {};
	this.systemDate;
    this.topUpObj ={};
    this.newIndiaPremierMediclaim ={};
    this.floaterObj = {};
    this.policyDetailsObj = {};	
	this.editQuoteHistory = false;
	this.editQuoteObj={};
	this.editQuoteFlag = false;
    this.searchPolicyHolderFunction = function(){};
    this.qrScannerData=''; // adeed for CR_60
    this.selectedLocationForDirection=''; // for CR_756 Google Map Get Direction
	this.showBreakInDisclaimerInDetails = false; //Added during CR_NP_0546C
	this.grihaSuvidhaObj = {}; //CR_MOBL_0054-GS
	this.grihaSuvidhaObj.fromBasicPremium = false; //CR_MOBL_0054-GS
	this.fcmRefreshToken = ''; // SUBHAPAM - TODO
	this.versionNo = '';
	this.deviceType = (navigator.userAgent.match(/iPad/i))  == "iPad" ? "I" : (navigator.userAgent.match(/iPhone/i))  == "iPhone" ? "I" : (navigator.userAgent.match(/Android/i)) == "Android" ? "A" : "NA";
	this.showLoading = function(loading) {
		$rootScope.loading = loading;
		};
	this.setCommonData = function(key,value) { 
		this.commonData[key] = value;
		};
	this.getCommonData = function(key) { 
		return this.commonData[key];
		};
	this.checkNetConnection = function() {
		return navigator.onLine;
	};

	this.showAlert = function(msg) { // Function for the native notification- alert
		var title = (msg.indexOf("Cannot connect to Internet") > -1) ? "No Network Connection" : "Alert";
		this.messageModal('info', msg, false, '', 'OK', function () {}, function () {}, title);
	};
	// CR-3546
	this.showAlertWithBtns = msg => {
		const title = (msg.indexOf("Cannot connect to Internet") > -1) ? "No Network Connection" : "Alert";
		this.messageModal('info', msg, false, '', 'OK', () => {}, () => {
			$state.go("showCart");
		}, title);
	}


	// function added for CR_NP_744C
	this.showConfirmForAadhaar = function (msg, onConfirm, title) {

        navigator.notification.confirm(
            msg,
            onConfirm,
            title,
            ['Ok', 'Later']
        );
    };
	
	//source indicator start
	this.getPolicySource = function(policyStatus) {
		
		var sourceIndicator;

		stakevalue = this.getCommonData("channel");
		if(policyStatus == "RENEWAL IN PROGRESS"){
			userID.policy_type = "_QR_RENEWAL";
		}
		else if(policyStatus == "RENEWED POLICY" || "APPROVED APPLICATION"){
			userID.policy_type = "_QP_ONLINE";
		}
		else {
			userID.policy_type = "";
		}
		
		if(stakevalue == "AGENT"){
			userID.stakemode = "AG";
		}
		else if(stakevalue == "DEALER"){
			userID.stakemode = "DL";
		}
		else if(stakevalue == "DEVELOPMENT OFFICER"){
			userID.stakemode = "DO";
		}
                /*start changes for CR754*/ 
                else if(stakevalue == "MISP"){
			userID.stakemode = "MS";
		}
                /*end changes for CR754*/
		else{
			userID.stakemode = "";
		}
	
		
		if (this.deviceType == "I") {
			sourceIndicator = "MOB/AP"+ userID.stakemode + userID.policy_type;
		}
		else{
			sourceIndicator = "MOB/AN"+ userID.stakemode + userID.policy_type;
		}
		
		return sourceIndicator;
	};
	
	//source indicator end
	
	//validate vehicle registration fields -- start 
	this.isVehRegFieldsValid = function() {
		
		var regx = /^[a-zA-Z0-9]*$/;
		var regxAlpha = /^[a-zA-Z]*$/;
		var regxNum = /^[0-9]*$/;
		var valid;
		if(regxAlpha.test(this.getCommonData("vehicleRegNo1")) && regx.test(this.getCommonData("vehicleRegNo2")) &&
		   regx.test(this.getCommonData("vehicleRegNo3")) && regxNum.test(this.getCommonData("vehicleRegNo4")) && 
		   regx.test(this.getCommonData("engineNo")) && regx.test(this.getCommonData("chassisNo")) && regx.test(this.getCommonData("colorAsRCBook"))) {
			valid = true;
		} else {
			valid = false;
		}
		return valid;		
	};
	/** validate vehicle registration fields end **/
	/** Manage Renewals start **/
	
	this.isManageRenewals = false;
	this.renewalsProductList = [];
	this.renewalsCount = 0;
	//this.renewalsProductPolicyList = [];
	this.renewalPolicyDetails = [];
	this.selectedProductPolicies = [];
	this.renewQuoteNo = "";
	this.RenewalsForMonth = true;
	this.renewalProductListWithRenewalNumbers = [];
	this.polStartDate ;
	this.polEndDate;
	this.renewalList = function() {
		
	}
	this.notifyRenewal = false;
	
	
	/** Manage Renewals end **/
	
	/** Appointments start **/
	this.appointList = false;
	this.appointmentsForMonth = true;
	this.appointmentsCount = 0;
	this.appointmentsEvent = [];
	this.currentAppointments = [];
	this.editAppointment = {};
	this.editEvent = false;
	this.selectedDate = "";
	this.appointmentRenewal = false;
	this.appointmentListArray = {
		"appointmentsListItems" : []
	};	
	this.appointmentSelected = 0;
	/** Appointments end **/

	/**GST Start **/
	this.sort_by = function(field, reverse, primer){
      var key = primer ?
          function(x) {
        return primer(x[field]);
      } :
        function(x) {
        return x[field];
      };
      reverse = [-1, 1][+!!reverse];
      return function (a, b) {
        a = key(a);
        b = key(b);
        return reverse * ((a > b) - (b > a));
      };
    };
	
	/**GST End **/
	
	/** CR_646C NM MC to UK Migration start **/
	
	this.NmMcProduct = false;
	/** CR_646C NM MC to UK Migration end **/
	/** upload photo  start**/
	this.uploadJson;
	this.viewDocsbreakInSearchQuote = false;
	this.searchResponseData;
	this.breakInOccured = '';
	this.breakInCanceled = false;
	this.managePolicyCollection = false;
	this.saveQuoteDetailsData = {};
	this.managePolicyDetailsData = {};
	this.managePolBreakIn = false;
	/** upload photo  end **/
	
	/**Common message Modal Controller START**/
	this.messageModal = function (type, message, headerText = false, noBtnText = "No", yesBtnText = 'Yes', noButtonAction, yesButtonAction, title = '', closeBtn = false, isSameBtnColor = false) {
		$('#messageModal').modal({
			backdrop: 'static',
			keyboard: false
		});
		
		switch (type) {
			case "success":
				$rootScope.isSuccess = true;
				$rootScope.isError = false;
				$rootScope.isNoInfo = false;
				$rootScope.title = "Success";
				break;
			case "error":
				$rootScope.isSuccess = false;
				$rootScope.isError = true;
				$rootScope.isNoInfo = false;
				$rootScope.title = "Error";
				break;
			case "info":
				$rootScope.isSuccess = false;
				$rootScope.isError = false;
				$rootScope.isNoInfo = true;
				$rootScope.title = "Try Again";
				break;
			default:
				throw new Error("Wrong modal type. Supported types: success, error, info");
		}
		$rootScope.title = (title !== '') ? title : $rootScope.title;
		$rootScope.isModalClose = closeBtn;
		$rootScope.headerText = headerText;
		$rootScope.bodyMessage = message;
		$rootScope.noBtnText = noBtnText;
		$rootScope.yesBtnText = yesBtnText;
		$rootScope.noButtonAction = noButtonAction;
		$rootScope.yesButtonAction = yesButtonAction;
		$rootScope.isSameBtnColor = isSameBtnColor;
		$rootScope.$applyAsync();
	}
	/**Common message Modal Controller END**/
	
	/**General Modal Controller START**/
	this.generalModal = function (modalObj = {}, modalSize = 'lg') {
		var modalInstance = $modal.open({
			animation: false,
			templateUrl: 'partials/general/generalModal.html',
			controller: 'generalModalController',
			windowClass: 'general-modal',
			size: modalSize,
			resolve: {
				modalData: function() {
					return modalObj
				}
			}
		});
		modalInstance.result.then(function() {
			//backdropClass: ".modal-backdrop .fade";
		});
	};
	/**General Modal Controller END**/

}]);

agentApp.service('RestServices', ['$rootScope', '$http','CommonServices','GetSetResponseService','$location','$state','$timeout', function($rootScope, $http,CommonServices,GetSetResponseService,$location,$state,$timeout) {

	var restServices=this;
	var urlgetConstant="";
	var headerWithoutToken = false;
	var customerVar ="";

	var env = 'p',

		urlConstantNewPortal,
		deviceFCMToken;
		$rootScope.environment = env;
	if (env === 's') {
		urlConstantNewPortal = "https://sitportal.newindia.co.in/BaNCSIntegrationWebComp/rest/"; // SIT
		this.serverPath = "https://sitportal.newindia.co.in/";
		this.urlBillDesk= "https://sitmob.newindia.co.in/Middleware/middleDemo.jsp";// SIT bill desk
		this.urlBillDeskServer = "https://www.billdesk.com/"; //BillDeskServer

		this.urlBillDeskFingerPrint = "b5 6b 71 e2 4d 3f 38 8a b1 24 e9 46 91 7f 7e 11 ff ff 5e 06"; //BillDeskServer Fingerprint
		this.awsURL="https://uatmobile.newindia.co.in/helplinemiddlewareapp/resources/helpline/awsVideoUpload";
		//this.deviceFCMToken = "https://sitmob.newindia.co.in/helplinemiddlewareapp/resources/helpline/sendDeviceDetails/"; //CR_3693 - sudip FCM token
		deviceFCMToken = "https://sitmob.newindia.co.in/helplinemiddlewareapp/"; //CR_3693 - sudip FCM token

	} else if (env === 'u') {
		urlConstantNewPortal = "https://uatapps.newindia.co.in/BaNCSIntegrationWebComp/rest/"; // UAT
		this.serverPath = "https://uatapps.newindia.co.in";
		this.urlBillDesk="https://uatmobile.newindia.co.in/Middleware/middleDemo.jsp";// UAT bill desk
		this.urlBillDeskServer = "https://www.billdesk.com/"; //BillDeskServer

		this.urlBillDeskFingerPrint = "‎bf 18 8a 5d 51 27 cd 53 9e b1 7f 22 1a 10 e4 a3 56 e3 91 58"; //BillDeskServer Fingerprint
		this.awsURL="https://uatmobile.newindia.co.in/helplinemiddlewareapp/resources/helpline/awsVideoUpload";
		deviceFCMToken = "https://uatmobile.newindia.co.in/helplinemiddlewareapp/"; //CR_3693 - sudip FCM token

	} else if (env === 'p') {
		urlConstantNewPortal = "https://web.newindia.co.in/BaNCSIntegrationWebComp/rest/" // PROD
		this.serverPath = "https://web.newindia.co.in";  //PRODUCTION
		this.fingerprint = "C6 C5 17 9F 76 5A C4 65 38 D1 6E 1D 33 CA AF 83 65 1E F0 1A"; //PRODUCTION //valid till 13 June, 2021
		this.urlBillDesk="https://mobile.newindia.co.in/Middleware/middleDemo.jsp";// Prod bill desk
		this.urlBillDeskServer = "https://www.billdesk.com/"; //BillDeskServer
		
		this.urlBillDeskFingerPrint = "6F 6F 67 02 D6 03 3A BA 5A 1A 88 F9 4E A5 23 94 BC 41 70 44"; //BillDeskServer Fingerprint
		this.awsURL="https://mobile.newindia.co.in/helplinemiddlewareapp/resources/helpline/awsVideoUpload";
		deviceFCMToken = "https://mobile.newindia.co.in/helplinemiddlewareapp/"; //CR_3693 - sudip FCM token

	} else if (env === 'pp') {
		//urlConstantNewPortal = "https://preprod.newindia.co.in/BaNCSIntegrationWebComp/rest/"; // preprod
		urlConstantNewPortal = "https://ltapps.newindia.co.in/BaNCSIntegrationWebComp/rest/"; // preprod
		this.serverPath = "https://web.newindia.co.in"; //PRODUCTION
        this.fingerprint = "C6 C5 17 9F 76 5A C4 65 38 D1 6E 1D 33 CA AF 83 65 1E F0 1A"; //PRODUCTION //valid till 13 June, 2021
        this.urlBillDesk="https://ltmob.newindia.co.in/Middleware/middleDemo.jsp";// UAT bill desk
        this.urlBillDeskServer = "https://www.billdesk.com/"; //BillDeskServer
        this.urlBillDeskFingerPrint = "6F 6F 67 02 D6 03 3A BA 5A 1A 88 F9 4E A5 23 94 BC 41 70 44"; //BillDeskServer Fingerprint
        this.awsURL="https://ltmob.newindia.co.in/helplinemiddlewareapp/resources/helpline/awsVideoUpload";
        deviceFCMToken = "https://ltmob.newindia.co.in/helplinemiddlewareapp/"; //CR_3693 - sudip FCM token
	}

	this.urlPathsNewPortal = {
		getVersionInfo: 'mobileApp/mobileVersionDetails',
		login: 'security/login',
		collectionModes: 'userprofile/getCollectionModes',
		getPolDetails: 'renewal/getQuickRenewalPolicyDetails',
		stateCode: 'userprofile/validateStateCode',
		generateOtpForgotPassword: 'security/generateOtpForgotPassword',
		forgotPasswordNonCustomer: 'security/forgotPasswordNonCustomer',
		changePassword: 'security/changePassword',
		getNCProfileDetails: 'party/getNCProfileDetails',
		updateNCProfileDetails: 'party/updateNCProfileDetails',
		getPolicyList: 'quotes/getPolicyList',
		getAPDBalance: 'quotes/getAPDBalance',
		getLocatorDetails: 'commoncomponent/getLocatorDetails',
		getDomainValues: 'domainValues/getDomainValues',//PA product
		eCover: 'mobileApp/eCoverDetails',
		collection: 'collectionController/collection',
		getPolicyDetails: 'commoncomponent/getPolicyDetails',
		saveRenewedHealthQuote: 'renewal/getQRHealthSaveQuote',
		saveRenewedMotorQuote: 'renewal/getQuickRenewalSaveQuote',
		saveRenewedNonMotorQuote: 'renewal/getNonMotorQRSaveQuote',
		approveRenewedQuote: 'quotes/approveQuoteGen',//BH Product & QR/QP
		getBankDetails: 'mobileApp/getBankData',
		getReferenceNoAPD: 'quotes/getReferenceNoAPD',
		logout: 'security/logout',
		claimsList: 'claims/myClaims',
		clientList: 'mobileApp/queryClientDetails',
		updateInsertClient: 'mobileApp/updateInsertClient',
		forgotUserId:'security/forgotUserId',
		calSource: 'appointments/calSource',
		getPolicyDetailsMob: 'mobileApp/getPolicyDetailsMob',
		getClaimDetail:'claims/getClaimDetail',
		fetchDocumentName: 'mobileApp/getDocument',
		getClaimList: 'claims/getClaimList',
		initiateClaim: 'claims/initiateClaim',
		getAllLobs: 'lobs/getAllLobs',
		insertAppointmentDetails: 'mobileApp/insertAppointmentDetails',
		fetchAppointmentDetails: 'mobileApp/fetchAppointmentDetails',
		updateAppointmentDetails: 'mobileApp/updateAppointmentDetails',
		deleteAppointmentDetails: 'mobileApp/deleteAppointmentDetails',
		renewalsCount: 'mobRenewals/getRenewalCount',
		searchRenewalManage: 'mobRenewals/searchRenewalManage',
		getContent: 'alfresco/getContent',
		custUploadDocuments:'claims/custUploadDocuments',
		getBrochure: 'alfresco/getBrochure',
		saveCallMeDetails:'commoncomponent/saveCallMeDetails',
		getZipcodeDetail: 'userprofile/getZipcodeDetail',
		getTravelPlanDetails:'quotespaomp/getTravelPlanDetails',//BH Product
		saveQuote:'quotespaomp/saveQuote',//BH Product
		createPolicyHolder:'quotespaomp/createPolicyHolder',//BH Product
		getPolicyHolderDetail:'party/getPolicyHolderDetail',//BH Product
		searchPolicyHolderDetails:'party/searchPolicyHolderDetails',//BH Product
		updatePolicyHolderContact:'commoncomponent/updatePolicyHolderContact',//BH Product	
		getBHBankDetails: 'domainValues/getBankDetails',//BH Product
		activatePG:'commoncomponent/activatePG',//BH Product
		getPaymentGatewayURL:'mobPaymentGateway/getPaymentGatewayURL',//BH Product
		getPaymentDetails:'mobileApp/getPaymentDetails',//BH Product
		getStateList:'party/getStateList',//BH Product
		getCitiesList:'party/getCitiesList',//BH Product
		// getZipCodesList:'party/getZipCodesList',//BH Product
		getZipCodesbyState: 'party/getZipCodesbyState', //Added for CR_NP_0880
		calcPremiumOMP:'quotespaomp/calcPremiumOMP',//BH Product
		saveQuoteDB:'quotespaomp/saveQuoteDB',//BH Product
		fetchQuoteMotor :'quotes/fetchQuoteMotor', // to fetch quote details
		validatePolicy:'quotespaomp/validatePolicy',//ES Product
		startEndorsement:'quotespaomp/startEndorsement',//ES Product
        topUpCalcPremium:'quote/health/calcPremium',
        topUpViewBreakup:'quote/health/viewBreakup',
        topUpcreatePolicyHolder:'party/health/createPolicyHolderMember',
        topUpPolicyHolderSearch:'party/searchPolicyHolderDetails',
        topUpGetPolicyHolderDetail:'party/getPolicyHolderDetail',
        topUpupdatePolicyHolderContact:'commoncomponent/updatePolicyHolderContact',
        topUpGetStateList:'party/getStateList',
        topUpGetCityList:'party/getCitiesList',
        topUpZipCodeList:'party/getZipCodesList',
        topUpSaveQuote:'quote/health/saveQuote',
        topUpGetAgentList:'party/getAgentList',
		editQuote: 'quote/health/editQuote',
		editQuoteTW:'quotes/editQuote',//CR_0054
		editQuoteGS:'quote/eproduct/editQuote',//CR_0054
		editQuoteBH:'quotespaomp/editQuote',//CR_0054
		editQuotePU:'quotespaomp/editQuote',//CR_0054
		getQRRenQuoteDetails: 'renewal/getQRRenQuoteDetails',
		breakInQuotesList: 'mobileBreakin/fetchUploadPendingQuotes',
		breakInQuoteSearch: 'mobileBreakin/fetchBreakinQuoteDetails',
		fetchUploadedBreakinDocuments: 'mobileBreakin/fetchUploadedBreakinDocuments',
		uploadDocumentsGen: 'commoncomponent/uploadDocumentsGen',
		fetchBreakinConfigData: 'commoncomponent/fetchBreakinConfigData',
		getPolicyQuoteDetails: 'quotes/getPolicyDetails',
		getServerTime: 'commoncomponent/getServerTime',
    	getConfigurationData:'commoncomponent/getConfigurationData',  //Added for CR_NP_0744
    	fetchAadharDetails:'commoncomponent/fetchAadharDetails', // added for CR_744A
	    saveAadharDetails:'commoncomponent/saveAadharDetails',	// added for CR_744A
		updatePanCard:'commoncomponent/updatePanCard',//PanCard
		getMakeList:'modelDetails/getNCMakeList',//TW Product
		getModelDetailList:'modelDetails/getModelDetailList', //TW Product
		calculateModelIDV:'modelDetails/calculateModelIDV', //TW Product
		getQuickQuoteDetail:'quotes/getQuickQuoteDetail',//TW Product
		getQuickQuoteDetailApp:'quotes/getQuickQuoteDetailApp',//TW Product
		saveTWQuoteDB:'quotes/saveQuoteDB',//TW Customer Product Service
		createPolicyHolderTW:'party/createPolicyHolder',//TW, GS and PA Product
		calcPremiumPA:'quotespaomp/calcPremium',//PA Product
		getPAPremiumDistribution:'quotespaomp/getPAPremiumDistribution', //PA Product
		getProductDomainValues:'domainValues/getProductDomainValues', //GS and PA Product
		fetchPremiumGS:'quote/eproduct/fetchPremiumGS',// GS Product fetch premium
		calcPremium:'quote/eproduct/calcPremium', // GS Calculate Premium
		saveQuoteDBGs:'quote/eproduct/saveQuoteDB', // GS send SMS and email function
		saveQuoteGs:'quote/eproduct/saveQuote',// GS Save Quote
		getAgentList:'party/getAgentList', // Agents related to DevOff
		saveQuoteTWService:'quotes/saveQuote',//TW Product
		vehicleSearchService:'quotes/getDetailsByRegNo',//CR_MOBL_0063
		getDiscountInfo:'userprofile/getDiscountInfo',//TW Product
		getPremiumDistribution:'quotes/getPremiumDistribution',//TW Product
		getPremiumDistributionLongTerm:'quotes/getPremiumDistributionLongTerm',//cr_926
		getDefaultRelation:'party/getDefaultRelation',//TW Product
		getDealerRelations:'party/getDealerRelations',
		//getUserRelationDetails:'party/getUserRelationDetails',//TW Product
		healthViewBreakup:'quote/health/viewBreakup',
		getGeoLocations: 'commoncomponent/getGeoLocations', // Google Maps
		getConfigValue :'commoncomponent/getConfigValue',
		getMISPRelations: 'party/getMISPRelations',// added for CR_NP_754
		generateOTP: 'commoncomponent/generateOTP', // Added for CR_NP_744C
		validateOTP: 'commoncomponent/validateOTP' // Added for CR_NP_744C
	       ,getRenewNoticePolicyList: 'quotes/noticePolicyList'//changes for CR_NP_675
		//noticePolicyList : 'quotes/noticePolicyList'//Added for CR 675
		,getrenewalNoticDoc : 'quotes/getRenewalNoticeDocMob'//Added for CR 675
		,paymentGatewayInput : 'mobPaymentGateway/getPaymentDetailsEasyTab'//Added for CR_NP_867
		,processEzetapResponse : 'mobPaymentGateway/processEzetapResponse'//Added for CR_NP_867
		,sendPaymentLinkCount: 'quote/health/sendPaymentLinkCount' // Added for CR_NP_779
		,sendPaymentLink: 'quote/health/sendPaymentLink' // Added for CR_NP_779
                ,cpaCalculatePremium:'quote/eproduct/calcPremium'//Added for CR_NP_3439
		,cpSaveQuote:'quote/eproduct/saveQuote'//Added for CR_NP_3439
		,getCommissionAmt: 'quotes/getCommissionAmt' // Added for CR_NP_868
		,SQgetParentPolDetails:'quotes/getParentPolDetailsSQSS'//Added for CR_NP_3621 
                ,marineStartEndorsement:'marineportal/startEndorsement'//added 3626
		  ,endorsementSaveRequest:'quotes/saveRequestDetails'//added_3626
		  ,regSaveRequest:'quotes/saveRegDetails'//added_3626
		  ,getEndorsementHistory: 'quotes/getEndorsementHistory'//added_3626
		  ,getEndorsementStatus:'quotes/getEndorsementStatus'
          ,breakInStatusUpdate:'commoncomponent/brekinStatusUpdate'	  
          ,fetchHealthMemberDetail:'quote/eproduct/fetchHealthMemberDetail'
          ,collectionCartFetch:'collectionController/collectionCartFetch' // CR3546
          ,collectionCartDelete:'collectionController/collectionCartDelete' // CR3546
		  ,getProductName:'commoncomponent/getProductName' // CR3546
		  ,getCollectionList: 'quotes/getCollectionList' //changes for CR_3546
          ,collectionCartSave:'collectionController/collectionCartSave' // CR3546
	  ,getUserProfileURL : 'commoncomponent/getUserProfileURL'	  // CR_3693 - sudip
	  ,sendDeviceDetails : 'resources/helpline/sendDeviceDetails' // CR_3693 - sudip
	  ,eProdViewBreakup:'quote/eproduct/viewBreakup'
	  ,getAddDisc: 'quotes/getAddDisc' // CR_3868
	  ,getTPAList: 'quotes/getTpaMapping' //CR_3845
	  ,lastTransactionDetails: 'paymentGateway/getTransactionDetails' //CR_3773
	}
	
	
	this.getService = function(urlPath,local) { 
	    CommonServices.showLoading(true);
		try {
			if(local=='local'){
				return $http.get(urlgetConstant+urlPath);
			}
			else {
				try {
					if(urlPath === "domainValues/getBankDetails"){
						return $http({
							url: urlConstantNewPortal+urlPath,
							method: 'GET',
							responseType: "text",
							headers: {
								"Content-Type": "application/json",
								"applicationid": "mobile",
								"customerName": customerVar,
								"typeOfCustomer": customerVar,
								"X-Auth-Token" : CommonServices.getCommonData("token"),
								"userid" : CommonServices.getCommonData("userId")
							}

						});
					}
					else{
						return $http({
								url: urlConstantNewPortal+urlPath,
								method: 'GET',
								responseType: "text",
								headers: {
									"Content-Type": "application/json",
									"applicationid": "mobile",
									"customerName": customerVar,
									"typeOfCustomer": customerVar
								}

						});
					}
									
				} catch(Exception ) {
					throw Exception;				
				}
				//return $http.get(urlConstantNewPortal+urlPath);
			}
		} catch(Exception ) {
			throw Exception;	
		}
	};
	this.postService = function(urlPath,data) {
	
		CommonServices.showLoading(true);
		if(CommonServices.checkNetConnection()) {
			
			var localjson=false; //local data true
			if(localjson){
				return $http.get("json/newPortal/"+urlPath+".json");
			}
			if(this.headerWithoutToken){ // TO BE REMOVED
				try {
					return $http({
							url: urlConstantNewPortal+urlPath,
							method: 'POST',
							data: data,
							timeout: 60000,
							responseType: "text",
							headers: {
								"Content-Type": "application/json",
								"applicationid": "mobile",
								"customerName": "AGENT",
								"typeOfCustomer": "AGENT"
							}

					});
									
				} catch(Exception ) {
					throw Exception;				
				}
			} else {
				try {
					
					if(CommonServices.getCommonData("userId").substr(0, 2) === "DL"){
						customerVar = "DEALER";
					}
					if(CommonServices.getCommonData("userId").substr(0, 2) === "DE")
					{
						customerVar = "DEVELOPMENT OFFICER";
					}
					if(CommonServices.getCommonData("userId").substr(0, 2) === "AG"){
						customerVar = "AGENT";
					}
                                        /*start chnages for CR754*/
					if(CommonServices.getCommonData("userId").substr(0, 2) === "MS"){
						customerVar = "MISP";
					}
					/*end chnages for CR754*/
					if(urlPath === "claims/getClaimDetail" || urlPath === "claims/custUploadDocuments" ||  urlPath === "commoncomponent/uploadDocumentsGen"){
						return $http({
							url: urlConstantNewPortal+urlPath,
							method: 'POST',
							data: data,
							responseType: "text",
							headers: {
								"Content-Type": "application/json",
								"applicationid": "mobile",
								"customerName":customerVar,
								"typeOfCustomer":customerVar,
								"X-Auth-Token" : CommonServices.getCommonData("token"),
								"userid" : CommonServices.getCommonData("userId")
							}

						});
					}else if(urlPath === "resources/helpline/sendDeviceDetails"){ //CR-3693 sudip
						return $http({
							url: deviceFCMToken+urlPath,
							method: 'POST',
							data: data,
							responseType: "text",
							headers: {
								"Content-Type": "application/json",
								"applicationid": "mobile",
								"customerName":customerVar,
								"typeOfCustomer":customerVar,
								"X-Auth-Token" : CommonServices.getCommonData("token"),
								"userid" : CommonServices.getCommonData("userId")
							}

						});
					}				
					else{
						return $http({
							url: urlConstantNewPortal+urlPath,
							method: 'POST',
							data: data,
							timeout: 60000,
							responseType: "text",
							headers: {
								"Content-Type": "application/json",
								"applicationid": "mobile",
								"customerName":customerVar,
								"typeOfCustomer":customerVar,
								"X-Auth-Token" : CommonServices.getCommonData("token"),
								"userid" : CommonServices.getCommonData("userId")
							}

						});
					} 
									
				} catch(Exception ) {
					throw Exception;				
				}
			}
		}  else {
			CommonServices.showAlert("Cannot connect to Internet.\nPlease check your network settings.");
			CommonServices.showLoading(false);
			return;
		}			
	};
	
	this.handleWebServiceError = function(error) {
		
		var errorData = error.data;
		var errorStatus =  error.status;
		if(errorStatus == '404') {
			CommonServices.showAlert("Could not connect to server.\nPlease check after sometime.");
		} else if( errorStatus === 400 || errorStatus === 401 || errorStatus === 403 || errorStatus === 407 || errorStatus === 415 || errorStatus === 417 ) {
			CommonServices.showAlert("Session Expired. Please try again");
			 $location.path('/');
		} else if(errorStatus == '500') {
            if((errorData == "Edited Quote is not of Draft Policies") ||
                (errorData == "Collection has been completed for this policy")) {
                CommonServices.showAlert("Error occured. Please Retry.");
                $location.path('/newRenewPolicy/getNewRenewPolicy');
            } else if(errorData.toUpperCase().indexOf("INVALID USERNAME") > -1) {

                CommonServices.showAlert("Incorrect Username/Password, please retry");
            } else if(errorData.toUpperCase().indexOf("HTML") > -1) {
				CommonServices.showLoading(false);
                CommonServices.showAlert("Could not connect to the server.\nPlease check after sometime");
            }
            else {
                CommonServices.showAlert(error.data);	
            }			
		} else {
			CommonServices.showLoading(false);
			CommonServices.showAlert("Could not connect to the server.\nPlease check after sometime");
		}
	};

	//LogOut Start
  this.logOut = function() {
	
	var msg = "Are you sure you want to Logout?";
	CommonServices.messageModal('info', msg, false, 'No', 'Yes', function () {}, function () {
		continueLogOut();
	}, 'Alert');
	
	/* if (CommonServices.deviceType !== "NA") {
		navigator.notification.confirm("Are you sure you want to Logout?", onLogoutConfirmation, "Alert", ["Ok", "Cancel"]);
		 //end of onConfirmation
	}
	else{
		var logutConfirm = confirm("Are you sure you want to Logout?");
		if (logutConfirm == true) {
			continueLogOut();
		}
	} */
	
  };
  
  function onLogoutConfirmation(button) {
			if (button == 1) {
				continueLogOut();
			}
		}
 function continueLogOut(){
		  if (CommonServices.deviceType == "I") {
			  var cacheSuccess = function(status) {
			  };
			  
			  var cacheError = function(status) {
			  };
			  
			  window.cache.clear( cacheSuccess, cacheError );
			  window.cache.cleartemp(); //
			  
		  }
		  CommonServices.isProfilePicUpdated = false; //sudip CR_3693
		  CommonServices.profilePicUpdatedPath = ''; //sudip CR_3693
		  console.log('path:'+CommonServices.profilePicUpdatedPath);                     
         var logOutResponse = restServices.postService(restServices.urlPathsNewPortal.logout,"");
        logOutResponse.then(
                    function(response) { // success
						CommonServices.showLoading(false);
                        $location.path('/');
                    },
                    function(error) { // failure
                        CommonServices.showLoading(false);
                        $location.path('/');
                    }
        );
 }
                                  
        //LogOut End



	//LogOut Start
  this.goHome = function() {
	var clickTarget = $(".back").attr("data-click");
	$(".back").removeAttr("data-click");

	if($state.current.name == "newRenewPolicy.getNewRenewPolicy"){
		if(CommonServices.isManageRenewals === true){
			$state.go('manageRenewals.renewalPolicyDetails');
			return;
		} else if(CommonServices.appointmentRenewal === true){
			$state.go('manageRenewals.renewalPolicyDetails');
			return;
		}else{
			$state.go('home');
			return;
		}
		
	}
	if($state.current.name == "manageRenewals.manageRenewalsCalendar") {
		$state.go('home');
		return;
	}
	//if (CommonServices.deviceType !== "NA") {
		if(clickTarget=="back"){
			if($state.current.name === "contactDetails.contactUs"){
				continueGoHome();
			} else if($state.current.name === "manageRenewals.manageRenewalsCalendar"){
                serviceConfirmation("Are you sure you want to exit from Manage Renewals?", goHomeConfirmation, "Alert", ["Ok", "Cancel"]);
            }else if($state.current.name === "manageRenewals.renewalProductsList"){
                  if(CommonServices.isManageRenewals === true){
                     $state.go('manageRenewals.manageRenewalsCalendar');
                  } else {
                      $state.go('appointments.appointmentsCalendar');
                  }
            }else if($state.current.name === "manageRenewals.renewalProductsPolicyList"){
                $state.go('manageRenewals.renewalProductsList');
            }else if($state.current.name === "manageRenewals.renewalPolicyDetails"){
                $state.go('manageRenewals.renewalProductsPolicyList');
            } else if($state.current.name == "newRenewPolicy.getNewRenewPolicy" || $state.current.name == "newRenewPolicy.policyDetails" || 
				$state.current.name == "newRenewPolicy.vehicleReg" || $state.current.name == "newRenewPolicy.collectionForm" || $state.current.name == "newRenewPolicy.NmMcToUkMigration" || $state.current.name == "newRenewPolicy.migrationDocUpload"){
				serviceConfirmation("Are you sure you want to exit from Quick Buy/Renewal?", goHomeConfirmation, "Alert", ["Ok", "Cancel"]);
            } else if($state.current.name === "uploadPhoto.breakInQuotesList"){
                serviceConfirmation("Are you sure you want to exit from Upload Photo?", goHomeConfirmation, "Alert", ["Ok", "Cancel"]);
            }else if($state.current.name === "uploadPhoto.uploadPhoto"){
                $state.go('uploadPhoto.breakInQuotesList');
            }else if($state.current.name === "uploadPhoto.breakInQuoteSearch"){
                $state.go('uploadPhoto.breakInQuotesList');
            } else if($state.current.name === "uploadPhoto.viewUploadedPhoto"){
                CommonServices.viewDocsbreakInSearchQuote = true;
                $state.go('uploadPhoto.breakInQuoteSearch');
            }
			else {
				serviceConfirmation("Are you sure you want to exit?", goBackConfirmation, "Alert", ["Ok", "Cancel"], 'back');
			}
			
		//end of onConfirmation
		} else {
			if($state.current.name == "newRenewPolicy.getNewRenewPolicy" || $state.current.name == "newRenewPolicy.policyDetails" || 
				$state.current.name == "newRenewPolicy.vehicleReg" || $state.current.name == "newRenewPolicy.collectionForm" || $state.current.name == "newRenewPolicy.NmMcToUkMigration" || $state.current.name == "newRenewPolicy.migrationDocUpload"){
				serviceConfirmation("Are you sure you want to exit from Quick Buy/Renewal?", goHomeConfirmation, "Alert", ["Ok", "Cancel"]);
			} else if($state.current.name == "newRenewPolicy.collectionForm"){
				if(CommonServices.managePolicyCollection){
					serviceConfirmation("Are you sure you want to exit from Quick Buy/Renewal?", goManagePolicyConfirmation, "Alert", ["Ok", "Cancel"]);
					
				} else{
					serviceConfirmation("Are you sure you want to exit from Quick Buy/Renewal?", goHomeConfirmation, "Alert", ["Ok", "Cancel"]);
				}
			} 
			else if($state.current.name == "profileUpdate.updateProfile"){
				serviceConfirmation("Are you sure you want to exit from Profile update?", goHomeConfirmation, "Alert", ["Ok", "Cancel"]);
			} else if($state.current.name === "contactDetails.contactUs"){
				continueGoHome();
			}else if($state.current.name === "managePolicies.managePolicies" || $state.current.name === "managePolicies.viewPolicyDetails" ){
				CommonServices.managePolicyCollection = false;
				serviceConfirmation("Are you sure you want to exit from Manage Policies?", goHomeConfirmation, "Alert", ["Ok", "Cancel"]);
			}else if($state.current.name === "appointments.appointmentsCalendar"){
				serviceConfirmation("Are you sure you want to exit from Appointments?", goHomeConfirmation, "Alert", ["Ok", "Cancel"]);
			}else if($state.current.name === "appointments.appointmentsList"){
				$state.go('appointments.appointmentsCalendar');
			}else if($state.current.name === "appointments.appointmentsDetails"){
				$state.go('appointments.appointmentsList');
			}else if($state.current.name === "appointments.createAppointment"){
				CommonServices.editEvent = false; 
				$state.go('appointments.appointmentsCalendar');
			}else if($state.current.name === "manageRenewals.manageRenewalsCalendar"){
				serviceConfirmation("Are you sure you want to exit from Manage Renewals?", goHomeConfirmation, "Alert", ["Ok", "Cancel"]);
			}else if($state.current.name === "manageRenewals.renewalProductsList"){
                if(CommonServices.isManageRenewals === true){
                   $state.go('manageRenewals.manageRenewalsCalendar');
                } else {
                    $state.go('appointments.appointmentsCalendar');
                }
			}else if($state.current.name === "manageRenewals.renewalProductsPolicyList"){
				$state.go('manageRenewals.renewalProductsList');
			}else if($state.current.name === "manageRenewals.renewalPolicyDetails"){
				$state.go('manageRenewals.renewalProductsPolicyList');
			}else if($state.current.name === "uploadPhoto.breakInQuotesList"){
				serviceConfirmation("Are you sure you want to exit from Upload Photo?", goHomeConfirmation, "Alert", ["Ok", "Cancel"]);
			}else if($state.current.name === "uploadPhoto.uploadPhoto"){
				$state.go('uploadPhoto.breakInQuotesList');
			}else if($state.current.name === "uploadPhoto.breakInQuoteSearch"){
				$state.go('uploadPhoto.breakInQuotesList');
			}else if($state.current.name === "uploadPhoto.viewUploadedPhoto"){
                CommonServices.viewDocsbreakInSearchQuote = true;
                $state.go('uploadPhoto.breakInQuoteSearch');
            }
		//end of onConfirmation
		}
	//}
	/*else{
		var logutConfirm;
		if($state.current.name == "newRenewPolicy.getNewRenewPolicy" || $state.current.name == "newRenewPolicy.policyDetails" || 
		$state.current.name == "newRenewPolicy.vehicleReg" || $state.current.name == "newRenewPolicy.collectionForm" || $state.current.name == "newRenewPolicy.NmMcToUkMigration" || $state.current.name == "newRenewPolicy.migrationDocUpload"){
			logutConfirm = confirm("Are you sure you want to exit from Quick Buy/Renewal?");
		} else if($state.current.name == "newRenewPolicy.collectionForm"){
			if(CommonServices.managePolicyCollection){
				var confirmVar = confirm("Are you sure you want to exit from Quick Buy/Renewal?"); 
				if(confirmVar){
					$state.go('managePolicies.managePolicies');
				}
			} else{
				logutConfirm = confirm("Are you sure you want to exit from Quick Buy/Renewal?");
			}
		}  
		else if($state.current.name == "profileUpdate.updateProfile"){
			logutConfirm = confirm("Are you sure you want to exit from Profile update?");
		}else if($state.current.name === "contactDetails.contactUs"){
			continueGoHome();
		} else if($state.current.name === "managePolicies.viewPolicyDetails" ){
			CommonServices.managePolicyCollection = false;
			logutConfirm = confirm("Are you sure you want to exit from Manage Policies?");
		} else if($state.current.name === "managePolicies.managePolicies") {
			CommonServices.managePolicyCollection = false;
			continueGoHome();
		}else if($state.current.name === "manageRenewals.manageRenewalsCalendar"){
			logutConfirm = confirm("Are you sure you want to exit from Manage Renewals?");
		}else if($state.current.name === "manageRenewals.renewalProductsList"){
            if(CommonServices.isManageRenewals === true){
                $state.go('manageRenewals.manageRenewalsCalendar');
            } else {
                $state.go('appointments.appointmentsCalendar');
            }
		}else if($state.current.name === "manageRenewals.renewalProductsPolicyList"){
			$state.go('manageRenewals.renewalProductsList');
		}else if($state.current.name === "manageRenewals.renewalPolicyDetails"){
			$state.go('manageRenewals.renewalProductsPolicyList');
		}else if($state.current.name === "appointments.appointmentsCalendar"){
			logutConfirm = confirm("Are you sure you want to exit from Appointments?");
		}else if($state.current.name === "appointments.appointmentsList"){
			$state.go('appointments.appointmentsCalendar');
		}else if($state.current.name === "appointments.appointmentsDetails"){
			$state.go('appointments.appointmentsList');
		}else if($state.current.name === "appointments.createAppointment"){
			CommonServices.editEvent = false;
			$state.go('appointments.appointmentsCalendar');
		} else if($state.current.name === "managePolicies.claims"){
			CommonServices.managePolicyCollection = false;
			continueGoHome();
		} else if($state.current.name === "uploadPhoto.breakInQuotesList"){
			logutConfirm = confirm("Are you sure you want to exit from Upload Photo?");
		}else if($state.current.name === "uploadPhoto.uploadPhoto"){
			$state.go('uploadPhoto.breakInQuotesList');
		}else if($state.current.name === "uploadPhoto.breakInQuoteSearch"){
			$state.go('uploadPhoto.breakInQuotesList');
		}else if($state.current.name === "uploadPhoto.viewUploadedPhoto"){
			CommonServices.viewDocsbreakInSearchQuote = true;
			$state.go('uploadPhoto.breakInQuoteSearch');
		}
		if (logutConfirm == true) {
			continueGoHome();
		}
	}*/
	
	
	  function serviceConfirmation (msg, functn, title, btnArr, type='') {
		CommonServices.messageModal('info', msg, false, btnArr[1], btnArr[0], function () {}, function () {
			if (type === 'back') {
				goBackConfirmation(1);
				
			} else if($state.current.name == "newRenewPolicy.collectionForm" && CommonServices.managePolicyCollection){
				goManagePolicyConfirmation(1);
			}
			else {
				goHomeConfirmation(1);
			}
			
		}, title);
	  }

  };
  function goManagePolicyConfirmation(button) {
        if (button == 1) {
        	$state.go('managePolicies.managePolicies');
        } 
    }

    function goBackConfirmation(button) {
                if (button == 1) {
                if($state.current.name == "newRenewPolicy.getNewRenewPolicy" || $state.current.name == "newRenewPolicy.policyDetails" ||
                        $state.current.name == "newRenewPolicy.vehicleReg" || $state.current.name == "newRenewPolicy.collectionForm"){
                    $state.go('newRenewPolicy.getNewRenewPolicy');
                } else {
                    continueGoHome();
                }
                }
            }
  function goHomeConfirmation(button) {
			if (button == 1) {
			if($state.current.name == "newRenewPolicy.getNewRenewPolicy" || $state.current.name == "newRenewPolicy.policyDetails" ||
            		$state.current.name == "newRenewPolicy.vehicleReg" || $state.current.name == "newRenewPolicy.collectionForm"){
            		$state.go('newRenewPolicy.getNewRenewPolicy');
            }else {
            continueGoHome();
            }
			}
		}
 function continueGoHome(){
    $state.go('home');
 }

        //goHome End
	
	this.checkVersion = function() {
		var versionData;

		if((CommonServices.versionNo === "" && CommonServices.deviceType =="NA") || (CommonServices.deviceType !=="NA" && CommonServices.versionNo !== "")) {
			if (CommonServices.deviceType == "I") {
				versionData = JSON.stringify({
					"deviceType": "I",
					"versionNo": CommonServices.versionNo,
					"userType":"AGENT"
				});
			} else{
				versionData = JSON.stringify({
					"deviceType": "A",
					"versionNo": CommonServices.versionNo,
					"userType":"AGENT"
				});
			}
			this.headerWithoutToken = true;
			var versionResponse = restServices.postService(restServices.urlPathsNewPortal.getVersionInfo, versionData);
			versionResponse.then(
				function(response) { // success
					CommonServices.setCommonData("vesionCheck",true);
					let appStore = CommonServices.deviceType == "I"? 'App-store':'Play-store';
					let updateMsg = (response.data.message && response.data.message!=="")?response.data.message:"Dear Agent, New version of Agent Application is available in the "+appStore+". Tap on Upgrade button to download.";
					if (response.data.isVersionValid == "false") {
						CommonServices.showLoading(false);
						if (CommonServices.deviceType !== "NA") {

							if (response.data.appAccess == "false") {
								CommonServices.showLoading(true);
								navigator.notification.alert(updateMsg, onForceConfirmation, "", "Upgrade");

							} else if (response.data.appAccess == "true") {
								navigator.notification.confirm(updateMsg, onUpgradeConfirmation, "", ["Upgrade", "Ignore"]);
							} //AppAccess true end
						}
					} //validVersion "false" if end
					else {
						//CommonServices.showLoading(false);
						getConfigValueQRcode();

						/** Green Marathon Start **/
						var date = response.data.systemDate;
						date = date.split(/[^0-9]+/);
						date = date[1]+"/"+date[0]+"/"+date[2];
						var sysDate = new Date(date);
						var endDate = new Date("03/05/2018");
						if(sysDate < endDate){
							CommonServices.displayMarathon = true;
							$rootScope.$broadcast("displayMarathon", {

							});
						} else {
							CommonServices.displayMarathon = false;
						}
						/** Green Marathon End **/



					}
				},
				function(error) { // failure
					if (!navigator.onLine) {
						CommonServices.showAlert("Error Message : No internet connection available. Please check your network and try again.");
						CommonServices.showLoading(true);
					}
					restServices.handleWebServiceError(error);
				}
			);
		}

	};


	    /* added for CR_MOBL_0060 */

    function getConfigValueQRcode(){
      
      var header = { 
                    'Content-Type': 'application/json',
                    'applicationid':'mobile',
                    'customerName':'CUSTOMER',
                    'typeOfCustomer':'CUSTOMER'
                };

      var getConfigValueInput = {"name":"ENABLE_QR_CODE_MOB"};

      var getConfigValueResponse = restServices.postService(restServices.urlPathsNewPortal.getConfigValue, getConfigValueInput);

            
      getConfigValueResponse.then(
        function(response){
                    CommonServices.showLoading(false);
                    $rootScope.showQRscanButton = response.data.status;

                    CommonServices.qrScannerData.showQRscanButton = response.data.status;
      },function(error){
        CommonServices.showLoading(false);
        restServices.handleWebServiceError(error);
      });

    }

    /* function ends */
     


	function onForceConfirmation(button) {
			CommonServices.showLoading(true);
			if (CommonServices.deviceType == "A") { //android play store
				//window.open("https://play.google.com/store/apps/details?id=com.tcs.nia","_blank","location=yes");
				window.open("market://details?id=com.tcs.nia","_system");
			}
			else if(CommonServices.deviceType == "I") { //ios app store
				//window.open("https://itunes.apple.com/us/app/new-india-agent/id1121895187?mt=8","_blank","location=yes");
				window.open("http://itunes.apple.com/us/app/new-india-agent/id1121895187?mt=8","_system");
			}
	} //end of onConfirmation

	function onUpgradeConfirmation(button) {
		if (button == 1) {
			CommonServices.showLoading(true);
			if (CommonServices.deviceType == "A") { //android play store
				//window.open("https://play.google.com/store/apps/details?id=com.tcs.nia","_blank","location=yes");
				window.open("market://details?id=com.tcs.nia","_system");
			}
			else if(CommonServices.deviceType == "I") { //ios app store
				//window.open("https://itunes.apple.com/us/app/new-india-agent/id1121895187?mt=8","_blank","location=yes");
				window.open("http://itunes.apple.com/us/app/new-india-agent/id1121895187?mt=8","_system");
			}
		} else if(button == 2) {
			CommonServices.setCommonData("vesionCheck",true);

		}

	} //end of onConfirmation
	
	/** Manage Renewals start**/
	this.renewalsList = function(startDate, endDate){
	
		var polStartDate = startDate.getDate()+"/"+(startDate.getMonth()+1)+"/"+startDate.getFullYear();
		var polEndDate = endDate.getDate()+"/"+(endDate.getMonth()+1)+"/"+endDate.getFullYear();
		var renewalPolicyListData =	{  
		   "userProfile":{  
			  "userId": CommonServices.getCommonData("userCode").toUpperCase(),
			  "stakeCode": CommonServices.getCommonData("stakeCode").toUpperCase(),
			  "loggedInRole": CommonServices.getCommonData("loggedInRole").toUpperCase()
		   },
		   "policyStartDate": polStartDate,
		   "policyEndDate": polEndDate,
		   "policyStatus":"05",
		   "minRowCount":"1",
		   "maxRowCount":"500"
		};
		
		var renewalsPolicyResponse = restServices.postService(restServices.urlPathsNewPortal.searchRenewalManage, renewalPolicyListData);
		 if(renewalsPolicyResponse === undefined){
		 }else{

		renewalsPolicyResponse.then(    
		function(response) { /* success */
			CommonServices.showLoading(false);
			if(response.data === ""){
				CommonServices.showLoading(false);
				CommonServices.showAlert("Could not connect to server. Please try again later.");
			} else {			
				CommonServices.renewalProductListWithRenewalNumbers = [];
				CommonServices.renewalsProductPolicyList = [];
				if(response.data.errorCode === undefined ){
					CommonServices.renewalsProductPolicyList = response.data.renewalPolicyDetails;
					$state.go("manageRenewals.renewalProductsList");
				} else{
					if(response.data.errorMessage !== undefined){
						CommonServices.showAlert(response.data.errorMessage);
					} else {
						CommonServices.showAlert("Could not connect to server. Please try again later.");
					}
				}				
			}
		},
		function(error) { /* failure */
			CommonServices.showLoading(false);
			restServices.handleWebServiceError(error);
		});
		}
	}
	
	this.updateRenewalsCount = function(startDate, endDate) {
		var polStartDate = startDate.getDate()+"/"+(startDate.getMonth()+1)+"/"+startDate.getFullYear();
		var polEndDate = endDate.getDate()+"/"+(endDate.getMonth()+1)+"/"+endDate.getFullYear();
		CommonServices.selectedDate = startDate;
		var renewalsData = {  
		   "userProfile":{  
			  "userId": CommonServices.getCommonData("userCode").toUpperCase(),
			  "stakeCode":  CommonServices.getCommonData("stakeCode").toUpperCase(),
			  "loggedInRole": CommonServices.getCommonData("loggedInRole").toUpperCase()
		   },
		   "policyStartDate": polStartDate,
		   "policyEndDate": polEndDate,
		   "policyStatus":"05",
		   "minRowCount":"1",
		   "maxRowCount":"500"
		};
		
		var renewalsCountResponse = restServices.postService(restServices.urlPathsNewPortal.renewalsCount, renewalsData); 
		if(renewalsCountResponse === undefined){
		}else{

		renewalsCountResponse.then(
        function(response) { /* success */
			CommonServices.showLoading(false);
			CommonServices.renewalsProductList  = [];			
			if(response.data === ""){
				CommonServices.showAlert("Could not connect to server. Please try again later.");
			} else {
				if(response.data.errorCode !== undefined){
					CommonServices.showAlert(response.data.errorMessage);
				} else if(response.data.totalRowCount === undefined){

				    if(CommonServices.notifyRenewal === true) {
                        $rootScope.$broadcast("renewalsCallNotify", {
                            data: 0
                        });
                    } else {
                        $rootScope.$broadcast("renewalsCount", {
                            data: 0
                        });
                    }
				} else {
					CommonServices.renewalsCount = response.data.totalRowCount;
					var productList = [];
					for(var i=0; i< response.data.renewalPolicyCounts.length; i++){
						if(response.data.renewalPolicyCounts[i].productWisRowCount === "0"){
							
						} else{
							productList.push(response.data.renewalPolicyCounts[i]);
						}
					}
					CommonServices.renewalsProductList = productList;
					if(CommonServices.notifyRenewal === true) {
						$rootScope.$broadcast("renewalsCallNotify", {
							data: response.data.totalRowCount
						});
					} else {
						$rootScope.$broadcast("renewalsCount", {
							data: response.data.totalRowCount
						});
					}
				}
			}
        },
        function(error) { /* failure */
            CommonServices.showLoading(false);
			 if(CommonServices.notifyRenewal === true) {
                $rootScope.$broadcast("renewalsCallNotify", {
                    data: 0
                });
             } else {
                $rootScope.$broadcast("renewalsCount", {
                    data: 0
                });
             }
			restServices.handleWebServiceError(error);
        });
        }
	}
	
	/** Manage Renewals end **/
	
	/** appointments Start **/
	
	this.updateAppointment = function(selectedDate) {
		CommonServices.selectedDate = selectedDate;
		CommonServices.appointmentsForMonth = false;
		CommonServices.currentAppointments = [];
		var count =0;
		var todaysDate = new Date();
		selectedDate.setHours(todaysDate.getHours(),todaysDate.getMinutes(),00);
		var currentDateString = (todaysDate.getMonth()+1) +"/"+ todaysDate.getDate() +"/"+ todaysDate.getFullYear();
		var selectedDateString = (selectedDate.getMonth()+1) +"/"+ selectedDate.getDate()+"/"+selectedDate.getFullYear(); 
		var startDate = selectedDate.getDate()+"/"+(selectedDate.getMonth()+1)+"/"+selectedDate.getFullYear();
		var appointmentData = {  
		   "userId": CommonServices.getCommonData("userCode").toUpperCase(),
		   "appointmentDetailList":[  
			  {  
				 "appointmentStartDate":startDate,
				 "appointmentEndDate":startDate
			  }
		   ]
		};
		var appointmentListResponse = restServices.postService(restServices.urlPathsNewPortal.fetchAppointmentDetails,appointmentData); 
		if(appointmentListResponse === undefined){
		}else{

		appointmentListResponse.then(
		function(response) { /* success */
		if(response.data === ""){
			CommonServices.showLoading(false);
			CommonServices.showAlert("Could not connect to server. Please try again later.");
		} else {
			CommonServices.showLoading(false); 
			if(response.data.errorCode === "1"){
                count = 0;
			} else {
				CommonServices.appointmentsEvent = [];
				var appointmentList = response.data.appointmentDetailList;
				for(var i=0; i < appointmentList.length ; i++) {
					var eventDate = appointmentList[i].appointmentEndDate.split(/[^0-9]+/); // mm/dd/yy
					eventDate =  eventDate[1] + "/"+eventDate[0]+"/"+eventDate[2];					
					eventDate = new Date(eventDate);
					eventDate.setHours(calTime(appointmentList[i].endTime).sHours,calTime(appointmentList[i].endTime).sMinutes,00);
					if(currentDateString === selectedDateString){
						if(eventDate > selectedDate){
							count++;
							CommonServices.appointmentsEvent.push(appointmentList[i]);
							CommonServices.currentAppointments.push(appointmentList[i]);
						}
					} else {
						count++;
						CommonServices.appointmentsEvent.push(appointmentList[i]);
						CommonServices.currentAppointments.push(appointmentList[i]);
					}					
				}
			}
			$rootScope.$broadcast("appointmentsCall", { 
				data: count,
				date: selectedDate
			});
			}
		},
		function(error) { /* failure */
			CommonServices.showLoading(false);
			restServices.handleWebServiceError(error);
		});
		}
	};
	function calTime(time){
        var hours = Number(time.match(/^(\d+)/)[1]);
        var minutes = Number(time.match(/:(\d+)/)[1]);
        var AMPM = time.split(":")[0] >= 12? 'PM':'AM';
        if(AMPM === "PM" && hours<12) hours = hours+12;
        if(AMPM === "AM" && hours === 12) hours = hours-12;
        var sHours = hours.toString();
        var sMinutes = minutes.toString();
        if(hours<10) sHours = "0" + sHours;
        if(minutes<10) sMinutes = "0" + sMinutes;
        return {
            sHours: sHours,
            sMinutes: sMinutes
        };
    }
	/** appointments end **/
	/**BY NOW PRODUCT START**/
	
	function productNavigation(data){
		/*Start CR 0045*/
		if(data === "AK"){
			$rootScope.productName = "AK";
			$rootScope.productHeader="Asha Kiran";
			$rootScope.productMsg="Has any person to be insured been suffering / diagnosed / under treatment for any Hypertension / diabetes / critical illness / Adverse Medical History / chronic illness / recurring illness/during any time in past?"
			$location.path("/newIndiaFloaterMediclaim");
		}	/*End CR 0045*/
		if(data === "NP"){
			$rootScope.productName = "NP";
			$rootScope.productHeader="New India Floater Mediclaim";
			$rootScope.productMsg="Has any person to be insured been suffering / diagnosed / under treatment for any Hypertension / diabetes / critical illness / Adverse Medical History / chronic illness / recurring illness during any time in past?"
			$location.path("/newIndiaFloaterMediclaim");
		}
		/*Start CR_0054*/
		if(data === "TW"){
			$rootScope.productName = "TW";
			//Product Domain Values Service Call Start
			var inputTWData = {
				"productCode": "TW", "lngCode": "EN", "keys": ["VEHICLE_COLOR", "FUEL_TYPE", "COVERAGE_TYPE",
					"COVERAGE_TYPE_SECOND_YEAR", "COVERAGE_TYPE_THIRD_YEAR", "COVERAGE_TYPE_SECOND_YEAR_CSC", "COVERAGE_TYPE_THIRD_YEAR_CSC",
					"OWN_DRIVER_LICENSE_TYPE", "VOLUNTARY_EXCESS", "LIABILITY_DURATION", "COVERAGE_TYPE_CSC"]
			};

			CommonServices.getProductDomainValues(inputTWData);
			//Product Domain Values Service Call End
			//$rootScope.productHeader="Two Wheeler";
			//$rootScope.productMsg="Has any person to be insured been suffering / diagnosed / under treatment for any Hypertension / diabetes / critical illness / Adverse Medical History / chronic illness / recurring illness during any time in past?"
			$location.path("/twQuickQuote");

			
		}

		if(data === "TU"){
			$rootScope.productName = "TU";
			$rootScope.productHeader="New India Premier Mediclaim Policy";
			$rootScope.productMsg="Has any person to be insured been suffering / diagnosed / under any treatment for any Hypertension / diabetes / critical illness / Adverse Medical History / chronic illness / recurring illness/ Psychiatric and Psychosomatic Disorder during any time in past?"
			$location.path("/topUpPremiumCalcScreen");
		}
		// CR_3725 sourav 13.10.2019
		if(data === "CJ"){
			$rootScope.productName = "CJ";
			$rootScope.productHeader="New India Cancer Guard Policy";
			$rootScope.productMsg="Do any of the proposed member hold New India Cancer Guard policy?"
			$location.path("/premiumCalculatorCJ");
		}
		if(data === "BH"){
			$rootScope.productName = "BH";
			$rootScope.productHeader="Business & Holidays";
			$rootScope.productMsg="Has any person to be insured been suffering / diagnosed / under any treatment for any Hypertension / diabetes / critical illness / Adverse Medical History / chronic illness / recurring illness/ Psychiatric and Psychosomatic Disorder during any time in past?"
				$state.go('businessHolidays.travelDetails');
		}
		if(data === "GS"){
			$rootScope.productName = "GS";
			//$rootScope.productHeader="Griha Suvidha";
			//$rootScope.productMsg="Has any person to be insured been suffering / diagnosed / under any treatment for any Hypertension / diabetes / critical illness / Adverse Medical History / chronic illness / recurring illness/ Psychiatric and Psychosomatic Disorder during any time in past?"
			$location.path("/gsLandingScreen");
		}
		if(data === "PU"){
			$rootScope.productName = "PU";
			$rootScope.productHeader="Personal Accident";
			//$rootScope.productMsg="Has any person to be insured been suffering / diagnosed / under any treatment for any Hypertension / diabetes / critical illness / Adverse Medical History / chronic illness / recurring illness/ Psychiatric and Psychosomatic Disorder during any time in past?"
			$location.path("/premiumCalculator");
		}
		if(data === "RK"){
			$rootScope.productName = "RK";
			$rootScope.productHeader="Raasta Aapatti Kavach Policy";
			$location.path("/rakPremiumCalculator");
		}
		/*End CR_0054*/
		//CR 44 Start
		if(data === "UK"){
			$rootScope.productName = "UK";
			$rootScope.productHeader="New India Mediclaim";
			$rootScope.productMsg="Has any person to be insured been suffering / diagnosed / under any treatment for any Hypertension / diabetes / critical illness / Adverse Medical History / chronic illness / recurring illness/ Psychiatric and Psychosomatic Disorder during any time in past?"
			$location.path("/newIndiaFloaterMediclaim");
		}
		//CR 44 End
        
        //CR_0052 starts
        if(data === "HN"){
            CommonServices.topUpObj ={};
            CommonServices.newIndiaPremierMediclaim ={};
            
            var parentTrue = false;
            
            for(var i=0; i<CommonServices.floaterObj.risks.length; i++){
             if(CommonServices.floaterObj.risks[i].riskDetails.relationWithPolicyHolder ==='Parents'){
                    parentTrue = true;
                   
                }
            }
            
            if(parentTrue === true){
                navigator.notification.confirm("We found there is a mismatch in 'Relationship with  policyholder' parameter. In online channel, coverage for only Proposer, Spouse and Child is allowed. Please click 'OK' to proceed", onParentDeleteConfirmation, "Alert", ["Ok", "Cancel"]);
            }else{
              $state.go("newIndiaPremierMediclaim");  
            }
            
		}
        //CR_0052 ends
		/** Added CR 4092 - Corona Kavach Policy */
		if(data === 'CZ') {
			$rootScope.productName = 'CZ';
			$location.path('/coronaKavachPremiumCalc');
		}
	}
	
    
    function onParentDeleteConfirmation(button){
        if (button == 1) {
				$state.go("newIndiaPremierMediclaim");
			}else{
                $state.go('managePolicies.managePolicies');
            }
    };
    
	CommonServices.buyProduct = function(data){
	
		if(CommonServices.editQuoteHistory === true){
			//Edit Quote Service Call Start
			var editQuoteData = {"userProfile":{"userId":CommonServices.getCommonData("userId"),"loggedInRole":"SUPERUSER"},
			"quote":{"quoteNumber":CommonServices.editQuoteObj.quoteNumber,"policyNumber":"","processType":"NB","productCode":data}};
			
			var editQuoteURL ="";
			/** 
			 * Added CR 4092 - Corona Kavach Policy 
			 */
			if(data ==="NP" || data ==="AK"  || data ==="HN"|| data ==="TU" || data ==="CJ" || data === 'CZ'){ //Only Health Products //CR_3725 cancer product editquote
				editQuoteURL = restServices.urlPathsNewPortal.editQuote;
				console.log("editQuoteURL" +editQuoteURL);
			}else if(data ==="TW"){
				editQuoteURL = restServices.urlPathsNewPortal.editQuoteTW;
			}
			else if(data ==="GS" || data ==="RK"){
				editQuoteURL = restServices.urlPathsNewPortal.editQuoteGS;
			}
			else if(data ==="BH"){
				editQuoteURL = restServices.urlPathsNewPortal.editQuoteBH;
			}
			else if(data ==="PU"){
				editQuoteURL = restServices.urlPathsNewPortal.editQuotePU;
			}
			else{
				//CR-3725 edit quote not coming
				CommonServices.showAlert("Edit Quote functionality is not available for this product");
				return;
			}
			var editQuoteResponse = restServices.postService(editQuoteURL,editQuoteData);//CR_0054
			editQuoteResponse.then(
			function(response) { // success 		
				CommonServices.showLoading(false);
						
				if(response.data !== undefined && response.data !== ""){
					if(response.data.hasOwnProperty('errorMessage')){
					   CommonServices.showAlert(response.data.errorMessage);	
					}else if(data === "NP" || data === "HN"||data ==="TU"){ //CR_3725 cancer product editquote  || data ==="CJ"
						console.log(data);
						if(data === "NP"){
							CommonServices.floaterObj.proportionateDeduction = (response.data.quote.optionalCoverINoProportionateDeduction != undefined)? response.data.quote.optionalCoverINoProportionateDeduction: undefined; 
						}
						CommonServices.floaterObj = response.data.quote;
						for(var i =0; i < CommonServices.floaterObj.partyDetailsList.length; i++){
							if(CommonServices.floaterObj.partyDetailsList[i].partyStakeCode.toUpperCase() === "AGENT"){//CR_0054
								CommonServices.floaterObj.selectedAgentDetails = CommonServices.floaterObj.partyDetailsList[i];
							}else if(CommonServices.floaterObj.partyDetailsList[i].partyStakeCode.toUpperCase() === "TPA"){//CR_3845
								CommonServices.floaterObj.selectedTPA = CommonServices.floaterObj.partyDetailsList[i].partyCode;
							}
              }
						CommonServices.editQuoteFlag = true;
						productNavigation(data);						
					}else if(data === "TW"){
						CommonServices.editQuoteBD = response.data.quote;
						for(var i =0; i < CommonServices.editQuoteBD.partyDetailsList.length; i++){
             // if(data === "TW"){
							if(CommonServices.editQuoteBD.partyDetailsList[i].stakeCode.toUpperCase() === "AGENT"){//CR_0054
								CommonServices.editQuoteBD.selectedAgentDetails = CommonServices.editQuoteBD.partyDetailsList[i];
							}
							if(CommonServices.editQuoteBD.partyDetailsList[i].stakeCode.toUpperCase() === "POLICY-HOL"){//CR_0054
								CommonServices.setCommonData("policyHolderObj",CommonServices.editQuoteBD.partyDetailsList[i]);
							}
              //}
              }
						var aaa= CommonServices.editQuoteBD.vehicles[0].vehicleDetails.cubicCapacity;
						CommonServices.setCommonData("motorCC",CommonServices.editQuoteBD.vehicles[0].vehicleDetails.cubicCapacity);
						CommonServices.setCommonData("motorCarryingCapacity",CommonServices.editQuoteBD.vehicles[0].vehicleDetails.seatingCapacityIncludingDriver);
						CommonServices.setCommonData("motorVariant",CommonServices.editQuoteBD.vehicles[0].vehicleDetails.variant);
						CommonServices.editQuoteFlag = true;
						productNavigation(data);						
					}else if(data === "BH"){
						CommonServices.businessHolidaysObj = response.data.quote;
						for(var i =0; i < CommonServices.businessHolidaysObj.partyDetailsList.length; i++){
              if(data === "BH"){
							if(CommonServices.businessHolidaysObj.partyDetailsList[i].stakeCode.toUpperCase() === "AGENT"){//CR_0054
								CommonServices.businessHolidaysObj.selectedAgentDetails = CommonServices.businessHolidaysObj.partyDetailsList[i];
							}
							if(CommonServices.businessHolidaysObj.partyDetailsList[i].stakeCode.toUpperCase() === "POLICY-HOL"){//CR_0054
								CommonServices.setCommonData("policyHolderObj",CommonServices.businessHolidaysObj.partyDetailsList[i]);
							}
              }
						}
						CommonServices.editQuoteFlag = true;
						productNavigation(data);						
					}else if(data === "PU"){
						CommonServices.personalAccidentObj = response.data.quote;
						for(var i =0; i < CommonServices.personalAccidentObj.partyDetailsList.length; i++){
              if(data === "PU"){
							if(CommonServices.personalAccidentObj.partyDetailsList[i].stakeCode.toUpperCase() === "AGENT"){//CR_0054
								CommonServices.personalAccidentObj.selectedAgentDetails = CommonServices.personalAccidentObj.partyDetailsList[i];
							}
							
							if(CommonServices.personalAccidentObj.partyDetailsList[i].stakeCode.toUpperCase() === "POLICY-HOL"){//CR_0054
								CommonServices.setCommonData("policyHolderObj",CommonServices.personalAccidentObj.partyDetailsList[i]);
							}
              }
						}
						CommonServices.editQuoteFlag = true;
						productNavigation(data);						
					}
					else if(data === "RK"){
						
						CommonServices.floaterObj = response.data.quote;
						for(var i =0; i < CommonServices.floaterObj.partyDetailsList.length; i++){
							if(CommonServices.floaterObj.partyDetailsList[i].stakeCode.toUpperCase() === "AGENT"){//CR_0054
								CommonServices.floaterObj.selectedAgentDetails = CommonServices.floaterObj.partyDetailsList[i];
							}
						
							if(CommonServices.floaterObj.partyDetailsList[i].stakeCode.toUpperCase() === "POLICY-HOL"){//CR_0054
								CommonServices.setCommonData("policyHolderObj",CommonServices.floaterObj.partyDetailsList[i]);
							}
						}
						CommonServices.editQuoteFlag = true;
						productNavigation(data);	
					}
					//CR_3725
					/** 
					 * Added CR 4092 - Corona Kavach Policy 
					 */
					else if(data === "CJ" || data === 'CZ') {
						CommonServices.floaterObj = response.data.quote;
						for(var i =0; i < CommonServices.floaterObj.partyDetailsList.length; i++){
							if(CommonServices.floaterObj.partyDetailsList[i].stakeCode.toUpperCase() === "AGENT"){//CR_0054
								CommonServices.floaterObj.selectedAgentDetails = CommonServices.floaterObj.partyDetailsList[i];
							}else if(CommonServices.floaterObj.partyDetailsList[i].partyStakeCode.toUpperCase() === "TPA"){//CR_3845
								CommonServices.floaterObj.selectedTPA = CommonServices.floaterObj.partyDetailsList[i].partyCode;
							}else if(CommonServices.floaterObj.partyDetailsList[i].stakeCode.toUpperCase() === "POLICY-HOL"){//CR_0054 check
								CommonServices.setCommonData("policyHolderObj",CommonServices.floaterObj.partyDetailsList[i]);
							}
						}
						CommonServices.editQuoteFlag = true;
						productNavigation(data);	
					}
					else {
						CommonServices.grihaSuvidhaObj = response.data.quote;
						for(var i =0; i < CommonServices.grihaSuvidhaObj.partyDetailsList.length; i++){
              if(data === "GS"){
							if(CommonServices.grihaSuvidhaObj.partyDetailsList[i].partyStakeCode.toUpperCase() === "AGENT"){//CR_0054
								CommonServices.grihaSuvidhaObj.selectedAgentDetails = CommonServices.grihaSuvidhaObj.partyDetailsList[i];
							}
              }
						}
						CommonServices.editQuoteFlag = true;
						productNavigation(data);						
					}
				}
				else{
					CommonServices.showAlert("Please try after some time");
				}	
				  
			},
			function(error) { // failure
				CommonServices.showLoading(false);
				restServices.handleWebServiceError(error);
			});
			//Edit Quote Service Call End
						
		}
		else{
			productNavigation(data);
		}
	};
	/**BY NOW PRODUCT END**/
	/**Get Domain Values Start**/
	CommonServices.getDomainValues = function(){
		/*Changed by 851587 for CR_NP_0752*/
			if ($rootScope.productName === "SQ") { /*Start Changed for CR_NP_3621*/
				var getDomainValuesData = {"lngCode":"EN","keys":["GENDER","TITLE","YES_NO","ORGANIZATION_TYPE","OCCUPATION",
		"PARTY_RELATIONSHIP","FINANCING_AGREEMENT_TYPE","NCB_PERCENT","VEHICLE_ZONE","BENEFIT_COVERAGE_TYPE","DEPENDENT_TYPE",
		"RELATIONSHIP_WITH_PROPOSER","RELATIONSHIP_WITH_THE_NOMINEE","RELATIONSHIP_WITH_THE_NOMINEE_HEALTH","OCCUPATION_HEALTH",
		"NATURE_OF_WORK","YEAR_OF_MAKE_EPRODUCT","BMB_BRANCH","BMB_RELATIONSHIP_WITH_THE_NOMINEE","GST_REG_TYPE","PREVIOUS_INSURER_NAME","PREVIOUS_INSURER_NAME_BUNDLE"]};
			} else {
				var getDomainValuesData = {"lngCode":"EN","keys":["GENDER","TITLE","YES_NO","ORGANIZATION_TYPE","OCCUPATION",
		"PARTY_RELATIONSHIP","FINANCING_AGREEMENT_TYPE","NCB_PERCENT","VEHICLE_ZONE","BENEFIT_COVERAGE_TYPE","DEPENDENT_TYPE",
		"RELATIONSHIP_WITH_PROPOSER","RELATIONSHIP_WITH_THE_NOMINEE","RELATIONSHIP_WITH_THE_NOMINEE_HEALTH","OCCUPATION_HEALTH",
		"NATURE_OF_WORK","YEAR_OF_MAKE_EPRODUCT","BMB_BRANCH","BMB_RELATIONSHIP_WITH_THE_NOMINEE","GST_REG_TYPE","PREVIOUS_INSURER_NAME"]};
			} /*End Changed for CR_NP_3621*/
		var getDomainValuesResponse = restServices.postService(restServices.urlPathsNewPortal.getDomainValues, getDomainValuesData);
		if(CommonServices.checkNetConnection()){
			
			getDomainValuesResponse.then(
				function(response) { // success 		
					CommonServices.showLoading(false);
							
					if(response.data !== undefined && response.data !== ""){
						if(response.data.hasOwnProperty('errorMessage')){
						   CommonServices.showAlert(response.data.errorMessage);	
						}else{
							CommonServices.showLoading(false);  
							CommonServices.domainValues = response.data;
							/*Start Changed for CR_NP_3621*/
							if ($rootScope.productName === "SQ"){
								getPreviousInsurersListBundle();
							}else{
								getPreviousInsurersList();
							}
							/*End Changed for CR_NP_3621*/
							/*CR_NP_0752 ends*/
						}
					}
					else{
						CommonServices.showAlert("Please try after some time");
					}	
					  
				},
				function(error) { // failure
					CommonServices.showLoading(false);
					restServices.handleWebServiceError(error);
				});

		}
		
		
	};
//CR 3749
	CommonServices.getStateDomainValues = function(){

		var stateListResponse = restServices.postService(restServices.urlPathsNewPortal.getDomainValues,{"lngCode":"EN", "keys":["STATE_GSTIN"]});
		stateListResponse.then(
			function(response) {
				CommonServices.showLoading(false);
				for(let i = 0; i< response.data.domainValues.length; i++){
						CommonServices.gstIdStateCode[response.data.domainValues[i].codeValue] = response.data.domainValues[i].description;
					}
		},
		function (error) { // failure
			CommonServices.showLoading(false);
			RestServices.handleWebServiceError(error);
		}
	);
	}
	/**Get Domain Values Ends**/
	/* Added by 851587 for CR_NP_0752*/
	function getPreviousInsurersList(){
            var listOfInsurers = [];
            $rootScope.previousInsurersList = [];
            listOfInsurers = CommonServices.domainValues.domainValues;
            if (listOfInsurers !== undefined && listOfInsurers !== "") {
                for (var i = 0; i < listOfInsurers.length; i++) {
                    if (listOfInsurers[i].codeId !== undefined && listOfInsurers[i].codeId !== "" && listOfInsurers[i].codeId === "PREVIOUS_INSURER_NAME") {
                        $rootScope.previousInsurersList.push(listOfInsurers[i]);
                    }
                }
            } else {
                CommonServices.showAlert("No Domain Values available");
            }
        }
		/*CR_NP_0752 ends*/
		
		/* Added for CR_NP_3621*/
		function getPreviousInsurersListBundle(){
            var listOfInsurers = [];
            $rootScope.previousInsurersList = [];
            listOfInsurers = CommonServices.domainValues.domainValues;
            if (listOfInsurers !== undefined && listOfInsurers !== "") {
                for (var i = 0; i < listOfInsurers.length; i++) {
                    if (listOfInsurers[i].codeId !== undefined && listOfInsurers[i].codeId !== "" && listOfInsurers[i].codeId === "PREVIOUS_INSURER_NAME" || listOfInsurers[i].codeId === "PREVIOUS_INSURER_NAME_BUNDLE") {
                        $rootScope.previousInsurersList.push(listOfInsurers[i]);
                    }
                }
            } else {
                CommonServices.showAlert("No Domain Values available");
            }
        }
		/* Added for CR_NP_3621*/
		
	/**Get Product Domain Values Start**/
	CommonServices.getProductDomainValues = function(data){
		
		var getDomainValuesResponse = restServices.postService(restServices.urlPathsNewPortal.getProductDomainValues, data);
		getDomainValuesResponse.then(
		function(response) { // success 		
			CommonServices.showLoading(false);
					
			if(response.data !== undefined && response.data !== ""){
				if(response.data.hasOwnProperty('errorMessage')){
				   CommonServices.showAlert(response.data.errorMessage);	
				}else{
					CommonServices.productDomainValues = response.data;						
				}
			}
			else{
				CommonServices.showAlert("Please try after some time");
			}	
			  
		},
		function(error) { // failure
			CommonServices.showLoading(false);
			restServices.handleWebServiceError(error);
		});
		
	};

	
	/**Get Product Domain Values Start**/
	/**CR_NP_3561 start**/
	CommonServices.getVehicleAgeCount = function(data){
		
		var configuredDataResp = restServices.postService(restServices.urlPathsNewPortal.getConfigurationData, data);
		configuredDataResp.then(
		function(response) { // success 		
			CommonServices.showLoading(false);			
			if(response.data !== undefined && response.data !== ""){
				if(response.data.hasOwnProperty('errorMessage')){
				   CommonServices.showAlert(response.data.errorMessage);	
				}else{
					CommonServices.vehicleAgeCount = response.data;						
				}
			}
			else{
				CommonServices.showAlert("Please try after some time");
			}	
			  
		},
		function(error) { // failure
			CommonServices.showLoading(false);
			restServices.handleWebServiceError(error);
		});
		
	};
	/**CR_NP_3561 end**/
    
    
    
       
    /*************CR_0052 CR_0041 topUpPolicyHolderSearchCall and saveQuote starts **************/
    
    CommonServices.topUpPolicyHolderSearchCall =  function(customerType,inputfiled){
        if(customerType === 'newCustomer'){
            CommonServices.topUpObj.PolicyHolderSearchCallInput = undefined;
        }
        
        var policyHolderSearchUppercase;
        if(CommonServices.topUpObj.PolicyHolderSearchCallInput !== undefined){
          policyHolderSearchUppercase = CommonServices.topUpObj.PolicyHolderSearchCallInput.policyHolderCode !== undefined ?CommonServices.topUpObj.PolicyHolderSearchCallInput.policyHolderCode.toUpperCase() : undefined;  
        }
         
            var policyHolderSearchInput={
                  "userProfile": {
                    "userId": CommonServices.getCommonData("userId"),
                    "loggedInRole": "SUPERUSER"
                  },
                  "partyDetails": {
                    "individualDetails": {
                      "firstName": (CommonServices.topUpObj.PolicyHolderSearchCallInput !== undefined && CommonServices.topUpObj.PolicyHolderSearchCallInput.policyHolderName !== undefined)?CommonServices.topUpObj.PolicyHolderSearchCallInput.policyHolderName.toUpperCase():undefined,
                      "lastName": (CommonServices.topUpObj.PolicyHolderSearchCallInput !== undefined && CommonServices.topUpObj.PolicyHolderSearchCallInput.policyHolderLastName !== undefined) ?CommonServices.topUpObj.PolicyHolderSearchCallInput.policyHolderLastName.toUpperCase():undefined,
                      "emailId": (CommonServices.topUpObj.PolicyHolderSearchCallInput !==undefined && CommonServices.topUpObj.PolicyHolderSearchCallInput.emailId)? CommonServices.topUpObj.PolicyHolderSearchCallInput.emailId :undefined,
                      "mobileNo": (CommonServices.topUpObj.PolicyHolderSearchCallInput !== undefined && CommonServices.topUpObj.PolicyHolderSearchCallInput.mobileNum !== undefined)? CommonServices.topUpObj.PolicyHolderSearchCallInput.mobileNum :undefined
                    },
                    "organizationDetails": {},
                    "partyCode":(customerType === 'newCustomer' && inputfiled === false)?CommonServices.topUpObj.createPolicyHolderRes.partyDetails.partyCode:((customerType === 'existingCustomer' || customerType === 'newCustomer') && (inputfiled === true))?CommonServices.topUpObj.updatePolicyHolderRes.policyHolderCode:(customerType == undefined && inputfiled === undefined)? CommonServices.floaterObj.policyHolderCode:policyHolderSearchUppercase,
                    "productCode":$rootScope.productName === "TU" ? "TU" :"HN",
                    "partyType": "I"
                  },
                  "productCode": $rootScope.productName === "TU" ? "TU" :"HN"
                };
        
     var policyHolderSearchRes = restServices.postService(restServices.urlPathsNewPortal.topUpPolicyHolderSearch, policyHolderSearchInput);
	       policyHolderSearchRes.then(
                function(response) { // success	
                        CommonServices.showLoading(false);
                        if(response.data.hasOwnProperty('footer')){
                            //alert(response.data.footer.errorDescription);
                            CommonServices.showAlert(response.data.footer.errorDescription);
                        }else{
                            
                                CommonServices.topUpObj.policyHolderSearchRes = response.data
                                $state.go("searchPolicyHolderScreen");  
                           
                        }
				    },
						function(error) { // failure
							CommonServices.showLoading(false);
							restServices.handleWebServiceError(error);
					});
           
        };
    
    
    
    
    CommonServices.saveQuoteHealth = function(){

		//CR3845
		let partyDetailsList = []; 
		if(CommonServices.getCommonData("stakeCode") ==='DEVLP-OFF' && CommonServices.topUpObj.isAgentDetails){
			partyDetailsList.push(CommonServices.topUpObj.isAgentDetails);
		}
		if(CommonServices.topUpObj && CommonServices.topUpObj.tpaDetails && (CommonServices.getCommonData("stakeCode") ==='DEVLP-OFF' || CommonServices.getCommonData("stakeCode") ==='AGENT')){
			partyDetailsList.push({
				"partyCode": CommonServices.topUpObj.tpaDetails.tpaCode,
				"partyStakeCode":"TPA",
				"partyName": CommonServices.topUpObj.tpaDetails.tpaName
			});
		}


/*********** TU editQuote Changes starts**************/         
        
         if($rootScope.productName === "TU"){
            if(CommonServices.newIndiaPremierMediclaim.memberCoveredInPolicy === false && CommonServices.topUpObj.typeOfCover === "FLOATER"){
                if(CommonServices.editQuoteFlag === true &&  CommonServices.editSaveQuote === true){
                   proposerNotCoverd = CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk[0];
                }else{
                 proposerNotCoverd = CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk[0].riskDetails;   
                }      
         	}
			
			topUpGetSaveQuoteInput = {
              "quote": {
                    "quoteNumber":CommonServices.editQuoteFlag === true ? CommonServices.floaterObj.quoteNumber: CommonServices.topUpObj.premiumCalResponse.quoteNumber,
                    "productCode": "TU",
                    "policyHolderCode": (CommonServices.editQuoteFlag === true && CommonServices.editSaveQuote === true) ?CommonServices.floaterObj.policyHolderCode  : CommonServices.topUpObj.saveQuotePolicyHolderCode,
                    "isTPARequired":null,//CommonServices.editQuoteFlag === true ? "N" : null,
					"policyBranchCode": null,
                    "policyHolderName":(CommonServices.editQuoteFlag === true && CommonServices.editSaveQuote === true) ? CommonServices.floaterObj.policyHolderName : CommonServices.topUpObj.addedMebersDetails[0].riskDetails.nameOfInsuredPerson,
                    "roomRentRider": "N",
                    "policyStartDate": CommonServices.topUpObj.policyStartDate,
                    "policyExpiryDate":CommonServices.topUpObj.policyEndDate,
					"memberCoveredInPolicy":CommonServices.newIndiaPremierMediclaim.memberCoveredInPolicy === false? "NO" : "YES",
                    "mobileNo": null,
                    "emailId": null,
                    "progressLevel": null,
					"policyHolderDetails": CommonServices.newIndiaPremierMediclaim.memberCoveredInPolicy === false ? proposerNotCoverd : undefined,
                    "typeOfCover": CommonServices.topUpObj.typeOfCover,
                    "preMedicalCheckUpDetails": null,
                    "physicianDetails": {
                      "physicianName": null,
                      "physicianAddress": null
                    },
                    "nomineeDetails": {
                      "name":(CommonServices.editQuoteFlag === true && CommonServices.editSaveQuote === true) ? CommonServices.floaterObj.nomineeDetails.name : CommonServices.topUpObj.nomineeNameSaveQuote,
                      "relationshipWithInsured":(CommonServices.editQuoteFlag === true && CommonServices.editSaveQuote === true) ? CommonServices.floaterObj.nomineeDetails.relationshipWithInsured : CommonServices.topUpObj.relationshipWithNomineSaveQuote
                    },
                    "risks":(CommonServices.editQuoteFlag === true && CommonServices.editSaveQuote ===true) ?CommonServices.newIndiaPremierMediclaim.EditSaveQuoteRisk:CommonServices.newIndiaPremierMediclaim.riskDeatilsForSaveQuote,
					"partyDetailsList":(CommonServices.getCommonData("stakeCode") ==='DEVLP-OFF' || CommonServices.getCommonData("stakeCode") ==='AGENT')?partyDetailsList:undefined
                  },
                  "userProfile": {
                    "userId": CommonServices.getCommonData("userId"),
                    "loggedInRole": "SUPERUSER"
                  }

		};
        /*********** TU editQuote Changes Ends**************/    
        }else{
            if(CommonServices.newIndiaPremierMediclaim.memberCoveredInPolicy === false){
            var proposerNotCoverd = CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk[0].riskDetails !== undefined ? CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk[0].riskDetails : CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk[0];
         }
            
     topUpGetSaveQuoteInput ={
          "quote": {
            "quoteNumber":CommonServices.editQuoteFlag === true  ? CommonServices.floaterObj.quoteNumber : CommonServices.newIndiaPremierMediclaim.premiumCalResponse.quoteNumber,
            "productCode": "HN",
            "policyHolderCode": (CommonServices.editQuoteFlag === true && CommonServices.editSaveQuote === true) ?  CommonServices.floaterObj.policyHolderCode : CommonServices.topUpObj.saveQuotePolicyHolderCode,
            "planType": CommonServices.newIndiaPremierMediclaim.planType,
            "sumInsured": CommonServices.newIndiaPremierMediclaim.sumInsured,
        	"typeOfCover": CommonServices.newIndiaPremierMediclaim.typeOfCover, //CR_3449
            "isTPARequired":CommonServices.editQuoteFlag === true ? "N" : null,
			"branchcode": null,
            "policyHolderName":(CommonServices.editQuoteFlag === true && CommonServices.editSaveQuote === true) ? CommonServices.floaterObj.policyHolderName : CommonServices.topUpObj.addedMebersDetails[0].riskDetails.nameOfInsuredPerson,
            "policyStartDate": CommonServices.newIndiaPremierMediclaim.policyStartDate,
            "policyExpiryDate":CommonServices.newIndiaPremierMediclaim.policyEndDate,
            "mobileNo": null,
            "emailId": null,
            "progressLevel": "DQ",
            "preMedicalCheckUpDetails": null,
            "premiumDetails":CommonServices.newIndiaPremierMediclaim.premium,
            "nomineeDetails": {
              "name":(CommonServices.editQuoteFlag === true && CommonServices.editSaveQuote === true) ? CommonServices.floaterObj.nomineeDetails.name : CommonServices.topUpObj.nomineeNameSaveQuote,
              "relationshipWithInsured":(CommonServices.editQuoteFlag === true && CommonServices.editSaveQuote === true) ? CommonServices.floaterObj.nomineeDetails.relationshipWithInsured : CommonServices.topUpObj.relationshipWithNomineSaveQuote
            },
            "memberCoveredInPolicy":CommonServices.newIndiaPremierMediclaim.memberCoveredInPolicy === false? "NO" : "YES",
            "policyHolderDetails": CommonServices.newIndiaPremierMediclaim.memberCoveredInPolicy === false ? proposerNotCoverd : undefined,
            "risks":(CommonServices.editQuoteFlag === true && CommonServices.editSaveQuote ===true) ?CommonServices.newIndiaPremierMediclaim.EditSaveQuoteRisk :CommonServices.newIndiaPremierMediclaim.riskDeatilsForSaveQuote,
            "partyDetailsList":(CommonServices.getCommonData("stakeCode") ==='DEVLP-OFF' || CommonServices.getCommonData("stakeCode") ==='AGENT')?partyDetailsList:undefined  
          },
          "userProfile": {
            "userId": CommonServices.getCommonData("userId"),
            "loggedInRole": "SUPERUSER"
          }
     };
            
		}

		 var topSaveQuoteResponse = restServices.postService(restServices.urlPathsNewPortal.topUpSaveQuote, topUpGetSaveQuoteInput);
	       topSaveQuoteResponse.then(
                function(response) { // success	
				        CommonServices.showLoading(false);
                            if(response.data.hasOwnProperty('errorMessage')){
                                CommonServices.showAlert(response.data.errorMessage);
                            }else{
                                if(CommonServices.editQuoteFlag === true && CommonServices.editSaveQuote === true){
                                    /****TU EditQuote starts******/
                                    if($rootScope.productName ==="HN"){
                                            CommonServices.newIndiaPremierMediclaim.premiumCalResponse = response.data.quote;
                                        
                                        if(CommonServices.newIndiaPremierMediclaim.memberCoveredInPolicy === false){
                                          var tempObj ={
                                              riskDetails: CommonServices.newIndiaPremierMediclaim.premiumCalResponse.policyHolderDetails
                                          }; 
                                        CommonServices.newIndiaPremierMediclaim.premiumCalResponse.risks.unshift(tempObj);
                                        }

                                    }else{
                                         CommonServices.topUpObj.premiumCalResponse = response.data.quote;
                                        
                                        CommonServices.topUpObj.premiumCalResponse = response.data.quote;
                                        
                                        if(CommonServices.newIndiaPremierMediclaim.memberCoveredInPolicy === false && CommonServices.floaterObj.typeOfCover !=="INDIVIDUAL" ){
                                          var tempObj ={
                                              riskDetails: CommonServices.topUpObj.premiumCalResponse.policyHolderDetails
                                          }; 
                                        CommonServices.topUpObj.premiumCalResponse.risks.unshift(tempObj);
                                        }
                                    }
  
                                    $state.go("topUpBasicPremiumScreen");
                                      /****TU EditQuote ends******/
                                }else{
                                    
                                    CommonServices.topUpObj.reviewSummaryResponse = response.data;
                                    if($rootScope.productName ==="TU"){
                                    
                                     if( CommonServices.topUpObj.reviewSummaryResponse.quote.policyHolderDetails  !== undefined){
                                         CommonServices.topUpObj.reviewSummaryResponse.tuMemberCoveredInPolicy = true;
                       
                                        }
                                        
                                    }
                                  
                                    
                                     stateServiceCall();
                                }
                               
                            }
                       
                        },
						function(error) { // failure
							CommonServices.showLoading(false);
							restServices.handleWebServiceError(error);
					});
        

    };
    
	function stateServiceCall() {
		var getStateInput = {
			"state": ""
		};

		var GetStateListResponse = restServices.postService(restServices.urlPathsNewPortal.getStateList, getStateInput);
		GetStateListResponse.then(
			function (response) { // success	
				CommonServices.showLoading(false);
				if (response.data.hasOwnProperty('states')) {
					var stateList = response.data.states;

					for (var i = 0; i < stateList.length; i++) {
						if (stateList[i].stateCode === CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.state) {
							CommonServices.topUpObj.getStateByID = stateList[i].state;
							/*CR_NP_0880 starts */
							zipCodeServiceCall();
							// cityServiceCall();

						}
					}
				}
			},
			function (error) { // failure
				CommonServices.showLoading(false);
				restServices.handleWebServiceError(error);
			}
		);

	};
	function zipCodeServiceCall() {

        var getZipCodeListInput = {
            "state": CommonServices.topUpObj.getStateByID,
            "zipCode": ""
        }

        var getZipCodeResponse = restServices.postService(restServices.urlPathsNewPortal.getZipCodesbyState, getZipCodeListInput);
        getZipCodeResponse.then(
            function (response) { // success	
                CommonServices.showLoading(false);
                if (response.data.hasOwnProperty('pincodes')) {
					var allZipCodeList = response.data.pincodes;

                    for(var i = 0; i < allZipCodeList.length; i++){
                        if(allZipCodeList[i] == CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.pinCode){
                            CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.pinCode = allZipCodeList[i];
                            cityServiceCall();
                        }

                    }
                }
            },
            function (error) { // failure
                CommonServices.showLoading(false);
                restServices.handleWebServiceError(error);
            });
    };

	function cityServiceCall() {

		var getCityInput = {
			"state": CommonServices.topUpObj.getStateByID,
			"zipCode":CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.pinCode,
			//"additionalParameter":"MOBILE",
			"city": ""
		};

		var GetCityListResponse = restServices.postService(restServices.urlPathsNewPortal.getCitiesList, getCityInput);
		GetCityListResponse.then(
			function (response) { // success	
				CommonServices.showLoading(false);
				if (response.data.hasOwnProperty('cities')) {

					var cityList = response.data.cities.sort(CommonServices.sort_by('city', response.data.cities, ''));
					for (var i = 0; i < cityList.length; i++) {
						if (cityList[i].cityCode === CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.city) {
							CommonServices.topUpObj.getCityByID = cityList[i].city;
							$state.go("toUpReviewSummaryScreen");
						}
					}
				}
			},
			function (error) { // failure
				CommonServices.showLoading(false);
				restServices.handleWebServiceError(error);
			});
	};
						//},
        
  
    
	/*************CR_0052 CR_0041 topUpPolicyHolderSearchCall  and saveQuote ends **************/

	/*CR_MOBL_0054-GS Starts */
	var grihaSuvidha = {};
	grihaSuvidha.sumInsuredList = [];

	$rootScope.getSumInsuredDetailsGS = function () {
		var getProductDomainValuesInput = {
			"productCode": "GS",
			"lngCode": "EN",
			"keys": [
				"SUM_INSURED_GS_OPTION1",
				"SUM_INSURED_GS_OPTION2",
				"SUM_INSURED_GS_OPTION3",
				"SUM_INSURED_GS_OPTION4"
			]
		};

		var getProductDomainValuesResponse = restServices.postService(restServices.urlPathsNewPortal.getProductDomainValues, getProductDomainValuesInput);
		getProductDomainValuesResponse.then(
			function (response) { //Success
				if (response.data.productDomainValues != undefined && response.data.productDomainValues != "" && response.data.productDomainValues.length > 0) {

					for (var i = 0; i < response.data.productDomainValues.length; i++) {


						if (response.data.productDomainValues[i].domainValues.codeId == "SUM_INSURED_GS_OPTION1" && response.data.productDomainValues[i].domainValues.sortOrder == "1") {
							var sumInsuredFireOption1 = response.data.productDomainValues[i].domainValues.codeValue;
						}

						if (response.data.productDomainValues[i].domainValues.codeId == "SUM_INSURED_GS_OPTION1" && response.data.productDomainValues[i].domainValues.sortOrder == "2") {
							var sumInsuredBurglaryOption1 = response.data.productDomainValues[i].domainValues.codeValue;
						}

						if (response.data.productDomainValues[i].domainValues.codeId == "SUM_INSURED_GS_OPTION1" && response.data.productDomainValues[i].domainValues.sortOrder == "3") {
							var sumInsuredJewelleryOption1 = response.data.productDomainValues[i].domainValues.codeValue;
						}

						if (response.data.productDomainValues[i].domainValues.codeId == "SUM_INSURED_GS_OPTION1" && response.data.productDomainValues[i].domainValues.sortOrder == "4") {
							var sumInsuredDomesticOption1 = response.data.productDomainValues[i].domainValues.codeValue;
						}

						if (response.data.productDomainValues[i].domainValues.codeId == "SUM_INSURED_GS_OPTION1" && response.data.productDomainValues[i].domainValues.sortOrder == "5") {
							var sumInsuredTVOption1 = response.data.productDomainValues[i].domainValues.codeValue;
						}

						if (response.data.productDomainValues[i].domainValues.codeId == "SUM_INSURED_GS_OPTION2" && response.data.productDomainValues[i].domainValues.sortOrder == "1") {
							var sumInsuredFireOption2 = response.data.productDomainValues[i].domainValues.codeValue;
						}

						if (response.data.productDomainValues[i].domainValues.codeId == "SUM_INSURED_GS_OPTION2" && response.data.productDomainValues[i].domainValues.sortOrder == "2") {
							var sumInsuredBurglaryOption2 = response.data.productDomainValues[i].domainValues.codeValue;
						}

						if (response.data.productDomainValues[i].domainValues.codeId == "SUM_INSURED_GS_OPTION2" && response.data.productDomainValues[i].domainValues.sortOrder == "3") {
							var sumInsuredJewelleryOption2 = response.data.productDomainValues[i].domainValues.codeValue;
						}

						if (response.data.productDomainValues[i].domainValues.codeId == "SUM_INSURED_GS_OPTION2" && response.data.productDomainValues[i].domainValues.sortOrder == "4") {
							var sumInsuredDomesticOption2 = response.data.productDomainValues[i].domainValues.codeValue;
						}

						if (response.data.productDomainValues[i].domainValues.codeId == "SUM_INSURED_GS_OPTION2" && response.data.productDomainValues[i].domainValues.sortOrder == "5") {
							var sumInsuredTVOption2 = response.data.productDomainValues[i].domainValues.codeValue;
						}

						if (response.data.productDomainValues[i].domainValues.codeId == "SUM_INSURED_GS_OPTION3" && response.data.productDomainValues[i].domainValues.sortOrder == "1") {
							var sumInsuredFireOption3 = response.data.productDomainValues[i].domainValues.codeValue;
						}

						if (response.data.productDomainValues[i].domainValues.codeId == "SUM_INSURED_GS_OPTION3" && response.data.productDomainValues[i].domainValues.sortOrder == "2") {
							var sumInsuredBurglaryOption3 = response.data.productDomainValues[i].domainValues.codeValue;
						}

						if (response.data.productDomainValues[i].domainValues.codeId == "SUM_INSURED_GS_OPTION3" && response.data.productDomainValues[i].domainValues.sortOrder == "3") {
							var sumInsuredJewelleryOption3 = response.data.productDomainValues[i].domainValues.codeValue;
						}

						if (response.data.productDomainValues[i].domainValues.codeId == "SUM_INSURED_GS_OPTION3" && response.data.productDomainValues[i].domainValues.sortOrder == "4") {
							var sumInsuredDomesticOption3 = response.data.productDomainValues[i].domainValues.codeValue;
						}

						if (response.data.productDomainValues[i].domainValues.codeId == "SUM_INSURED_GS_OPTION3" && response.data.productDomainValues[i].domainValues.sortOrder == "5") {
							var sumInsuredTVOption3 = response.data.productDomainValues[i].domainValues.codeValue;
						}

						if (response.data.productDomainValues[i].domainValues.codeId == "SUM_INSURED_GS_OPTION4" && response.data.productDomainValues[i].domainValues.sortOrder == "1") {
							var sumInsuredFireOption4 = response.data.productDomainValues[i].domainValues.codeValue;
						}

						if (response.data.productDomainValues[i].domainValues.codeId == "SUM_INSURED_GS_OPTION4" && response.data.productDomainValues[i].domainValues.sortOrder == "2") {
							var sumInsuredBurglaryOption4 = response.data.productDomainValues[i].domainValues.codeValue;
						}

						if (response.data.productDomainValues[i].domainValues.codeId == "SUM_INSURED_GS_OPTION4" && response.data.productDomainValues[i].domainValues.sortOrder == "3") {
							var sumInsuredJewelleryOption4 = response.data.productDomainValues[i].domainValues.codeValue;
						}

						if (response.data.productDomainValues[i].domainValues.codeId == "SUM_INSURED_GS_OPTION4" && response.data.productDomainValues[i].domainValues.sortOrder == "4") {
							var sumInsuredDomesticOption4 = response.data.productDomainValues[i].domainValues.codeValue;
						}

						if (response.data.productDomainValues[i].domainValues.codeId == "SUM_INSURED_GS_OPTION4" && response.data.productDomainValues[i].domainValues.sortOrder == "5") {
							var sumInsuredTVOption4 = response.data.productDomainValues[i].domainValues.codeValue;
						}

					}

					grihaSuvidha.sumInsuredList = [
						{
							"sumInsuredFire": sumInsuredFireOption1,
							"sumInsuredBurglary": sumInsuredBurglaryOption1,
							"sumInsuredJewellery": sumInsuredJewelleryOption1,
							"sumInsuredDomestic": sumInsuredDomesticOption1,
							"sumInsuredTV": sumInsuredTVOption1,
							"option": "Option1"
						},
						{
							"sumInsuredFire": sumInsuredFireOption2,
							"sumInsuredBurglary": sumInsuredBurglaryOption2,
							"sumInsuredJewellery": sumInsuredJewelleryOption2,
							"sumInsuredDomestic": sumInsuredDomesticOption2,
							"sumInsuredTV": sumInsuredTVOption2,
							"option": "Option2"
						},
						{
							"sumInsuredFire": sumInsuredFireOption3,
							"sumInsuredBurglary": sumInsuredBurglaryOption3,
							"sumInsuredJewellery": sumInsuredJewelleryOption3,
							"sumInsuredDomestic": sumInsuredDomesticOption3,
							"sumInsuredTV": sumInsuredTVOption3,
							"option": "Option3"
						},
						{
							"sumInsuredFire": sumInsuredFireOption4,
							"sumInsuredBurglary": sumInsuredBurglaryOption4,
							"sumInsuredJewellery": sumInsuredJewelleryOption4,
							"sumInsuredDomestic": sumInsuredDomesticOption4,
							"sumInsuredTV": sumInsuredTVOption4,
							"option": "Option4"
						}
					];

					GetSetResponseService.addProductDomainValuesGS(grihaSuvidha.sumInsuredList);

					fetchPremiumGS();
				} else {
					CommonServices.showLoading(false);
					CommonServices.showAlert("Error occured, please try after sometime");
				}


			}, function (error) { // failure
				CommonServices.showLoading(false);
				restServices.handleWebServiceError(error);
			});

		/*$state.go('gsPremiumCalculator');*/
	};

	function fetchPremiumGS() {

		var fetchPremiumGSInput = {
			"userProfile": {
				"userId": CommonServices.getCommonData("userId"),
				"loggedInRole": "SUPERUSER"
			},
			"quote": {
				"sumInsuredList": grihaSuvidha.sumInsuredList
			}
		};

		var fetchPremiumGSResponse = restServices.postService(restServices.urlPathsNewPortal.fetchPremiumGS, fetchPremiumGSInput);
		fetchPremiumGSResponse.then(
			function (response) {

				CommonServices.showLoading(false);
				if (response.data.hasOwnProperty('errorMessage')) {
					CommonServices.showAlert(response.data.errorMessage);
				} else {
					if (response.data.userProfile.footer.errorCode == "0" && response.data.quote.fetchPremiumGS.length != 0) {

						GetSetResponseService.addFetchPremiumGS(response.data.quote.fetchPremiumGS);
						//Sourav added to handle mandatory fields alert for griha subhidha
						if(CommonServices.grihaSuvidhaObj != undefined){
							console.log("in service js to handle griha error");
							CommonServices.grihaSuvidhaObj.fromBasicPremium = false;
						}
						$state.go('gsPremiumCalculator');

					} else if (response.data.userProfile.footer.errorCode == "0" && response.data.quote.fetchPremiumGS.length == 0) {
						CommonServices.showAlert("Error occured,please try again later.");
					} else if (response.data.userProfile.footer.errorCode == "1" && response.data.userProfile.footer.errorDescription == undefined) {
						CommonServices.showAlert("Error occured,please try again later.");
					} else {
						CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
					}
				}


			}, function (error) {
				CommonServices.showLoading(false);
				restServices.handleWebServiceError(error);
			});

	};
	/*CR_MOBL_0054-GS Ends */
// CR 3546
this.getOccupationList = function(o, page) {
	if (page === 'PU_policyAutoPopulate') {
		var data = CommonServices.getCommonData("OCCUPATION");
		var obj = {
			codeId: "",
			codeValue: "",
			description: "",
			domainId: '',
			lngCode: "",
			mnemonic: "",
			sortOrder: null
		};

		angular.forEach(data, function (value, key) {
			if (value.mnemonic.toLowerCase() === o.toLowerCase()) {
				obj = value;
				return;
			}
		});
		return obj;
	}
	else if(page === 'RAK_policyAutoPopulate'){
		var type = (o.length <= 3) ? 'short' : 'long';
		var data = {
			'long':[{
					mnemonic: "ACCOUNTANTS", 
					description: "ACCOUNTANTS"
				}, {
					mnemonic: "ARCHITECTS",
					description: "ARCHITECTS",
				}, {
					mnemonic: "BANKERS",
					description: "BANKERS",
				}, {
					mnemonic: "BUILDERS",
					description: "BUILDERS",
				}, {
					mnemonic: "BUSINESS",
					description: "BUSINESS",
				}, {
					mnemonic: "CASH CARRYING EMPLOYEES",
					description: "CASH CARRYING EMPLOYEES",
				}, {
					mnemonic: "CONSULTING ENGINEERS",
					description: "CONSULTING ENGINEERS",
				}, {
					mnemonic: "CONTRACTS AND ENGINEERS ENGAGED IN SUPERINTENDING FUNCTIONS ONLY",
					description: "CONTRACTS AND ENGINEERS ENGAGED IN SUPERINTENDING FUNCTIONS ONLY",
				}, {
					mnemonic: "DOCTORS",
					description: "DOCTORS",
				}, {
					mnemonic: "DRIVERS OF TRUCKS OF LORRIES AND OTHER HEAVY VEHICLES",
					description: "DRIVERS OF TRUCKS OF LORRIES AND OTHER HEAVY VEHICLES",
				}, {
					mnemonic: "GARAGE AND MOTOR MECHANICS",
					description: "GARAGE AND MOTOR MECHANICS",
				}, {
					mnemonic: "HOUSEWIFE",
					description: "HOUSEWIFE",
				}, {
					mnemonic: "LAWYERS",
					description: "LAWYERS",
				}, {
					mnemonic: "MACHINE OPERATORS",
					description: "MACHINE OPERATORS",
				}, {
					mnemonic: "PAID DRIVERS OF MOTOR CARS AND LIGHT MOTOR VEHICLES",
					description: "PAID DRIVERS OF MOTOR CARS AND LIGHT MOTOR VEHICLES",
				}, {
					mnemonic: "PERSON ENGAGED IN ADMININISTRATIVE FUNCTIONS",
					description: "PERSON ENGAGED IN ADMININISTRATIVE FUNCTIONS",
				}, {
					mnemonic: "PROFESSIONAL ATHELETS AND SPORTSMEN WORLD WORKING MECHANISTS",
					description: "PROFESSIONAL ATHELETS AND SPORTSMEN WORLD WORKING MECHANISTS",
				}, {
					mnemonic: "STUDENT",
					description: "STUDENT",
				}, {
					mnemonic: "TEACHERS",
					description: "TEACHERS",
				}, {
					mnemonic: "VETERINARY DOCTORS",
					description: "VETERINARY DOCTORS",
				}, {
					mnemonic: "WOODWORKING MACHINISTS",
					description: "WOODWORKING MACHINISTS",
				}, {
					mnemonic: "SOFTWARE/BPO/IT/CONSULTANTS/HR PROFESSIONALS",
					description: "SOFTWARE/BPO/IT/CONSULTANTS/HR PROFESSIONALS",
				}
			],
			'short': [{
				mnemonic: "ACC", 
				description: "ACCOUNTANTS"
			}, {
				mnemonic: "ARCH",
				description: "ARCHITECTS",
			}, {
				mnemonic: "BANK",
				description: "BANKERS",
			}, {
				mnemonic: "BUILD",
				description: "BUILDERS",
			}, {
				mnemonic: "BIZ",
				description: "BUSINESS",
			}, {
				mnemonic: "CASH",
				description: "CASH CARRYING EMPLOYEES",
			}, {
				mnemonic: "CONENG",
				description: "CONSULTING ENGINEERS",
			}, {
				mnemonic: "SUPER",
				description: "CONTRACTS AND ENGINEERS ENGAGED IN SUPERINTENDING FUNCTIONS ONLY",
			}, {
				mnemonic: "DOC",
				description: "DOCTORS",
			}, {
				mnemonic: "DRIH",
				description: "DRIVERS OF TRUCKS OF LORRIES AND OTHER HEAVY VEHICLES",
			}, {
				mnemonic: "MECH",
				description: "GARAGE AND MOTOR MECHANICS",
			}, {
				mnemonic: "HW",
				description: "HOUSEWIFE",
			}, {
				mnemonic: "LAW",
				description: "LAWYERS",
			}, {
				mnemonic: "MACH",
				description: "MACHINE OPERATORS",
			}, {
				mnemonic: "DRI",
				description: "PAID DRIVERS OF MOTOR CARS AND LIGHT MOTOR VEHICLES",
			}, {
				mnemonic: "ADMIN",
				description: "PERSON ENGAGED IN ADMININISTRATIVE FUNCTIONS",
			}, {
				mnemonic: "SPORT",
				description: "PROFESSIONAL ATHELETS AND SPORTSMEN WORLD WORKING MECHANISTS",
			}, {
				mnemonic: "STU",
				description: "STUDENT",
			}, {
				mnemonic: "TEA",
				description: "TEACHERS",
			}, {
				mnemonic: "VETDOC",
				description: "VETERINARY DOCTORS",
			}, {
				mnemonic: "WOOD",
				description: "WOODWORKING MACHINISTS",
			}, {
				mnemonic: "SBICH",
				description: "SOFTWARE/BPO/IT/CONSULTANTS/HR PROFESSIONALS",
			}]			
		};
		var obj = {
			codeId: "",
			codeValue: "",
			description: "",
			domainId: '',
			lngCode: "",
			mnemonic: "",
			sortOrder: null
		};
		var index;
		angular.forEach(data.short, function (value, key) {
			if (value.mnemonic.toLowerCase() === o.toLowerCase()) {
				obj = value;
				index = key;
				return;
			}
		});
		if (obj.mnemonic === "") {
			angular.forEach(data.long, function (value, key) {
				if (value.mnemonic.toLowerCase() === o.toLowerCase()) {
					obj = value;
					index = key;
					return;
				}
			});
		}
		if (obj.mnemonic !== "" && page === 'RAK_policyAutoPopulate') {
			obj = data['short'][index];
		}
		return obj;
	}	
	else {
		var type = (o.length <= 3) ? 'short' : 'long';
		var data = {
			'long': [{
					mnemonic: "BUSINESS",
					description: "Business Traders"
				}, {
					mnemonic: "CLERK",
					description: "Clerical, supervisory and related workers"
				}, {
					mnemonic: "AGRICULTUR",
					description: "Farmers and Agricultural workers"
				}, {
					mnemonic: "SUPPORT",
					description: "Hospitality and support workers"
				}, {
					mnemonic: "HOUSEWIFE",
					description: "Housewife"
				}, {
					mnemonic: "SERVICE",
					description: "Police/Para Military/Defense"
				}, {
					mnemonic: "LABOUR",
					description: "Production Workers, Skilled and non-Agricultural labourers"
				}, {
					mnemonic: "PROFESSION",
					description: "Professional/Administrative/Manager"
				}, {
					mnemonic: "RETIRED",
					description: "Retired Person"
				}, {
					mnemonic: "STUDENT",
					description: "Students-School and college"
				}, {
					mnemonic: "OTHERS",
					description: "Any others"
				}],
			'short': [{
					mnemonic: "BT",
					description: "Business Traders"
				}, {
					mnemonic: "CS",
					description: "Clerical, supervisory and related workers"
				}, {
					mnemonic: "FA",
					description: "Farmers and Agricultural workers"
				}, {
					mnemonic: "HOS",
					description: "Hospitality and support workers"
				}, {
					mnemonic: "HW",
					description: "Housewife"
				}, {
					mnemonic: "PPD",
					description: "Police/Para Military/Defense"
				}, {
					mnemonic: "PSN",
					description: "Production Workers, Skilled and non-Agricultural labourers"
				}, {
					mnemonic: "PAM",
					description: "Professional/Administrative/Manager"
				}, {
					mnemonic: "RP",
					description: "Retired Person"
				}, {
					mnemonic: "ST",
					description: "Students-School and college"
				}, {
					mnemonic: "AO",
					description: "Any others"
				}]
		};
		
		var obj = {
			codeId: "",
			codeValue: "",
			description: "",
			domainId: '',
			lngCode: "",
			mnemonic: "",
			sortOrder: null
		};
		var index;
		angular.forEach(data.short, function (value, key) {
			if (value.mnemonic.toLowerCase() === o.toLowerCase()) {
				obj = value;
				index = key;
				return;
			}
		});
		if (obj.mnemonic === "") {
			angular.forEach(data.long, function (value, key) {
				if (value.mnemonic.toLowerCase() === o.toLowerCase()) {
					obj = value;
					index = key;
					return;
				}
			});
		}
		if (obj.mnemonic !== "" && page === 'TU_policyAutoPopulate') {
			obj = data['long'][index];
		}
		return obj;
	}
}
}]);
//CommonServices Service End
//GetSetResponsiveService Service Start

agentApp.service('GetSetResponseService', function() {

  // for storing and getting login response data

  var loginResponseData = [];

  var addloginResponseData = function(newObj) {
      loginResponseData=[];
      loginResponseData.push(newObj);
  };

  var getloginResponseData = function(){
      return loginResponseData;
  };
  // for storing and getting policy list data

  var myAllPolicyResponseData = [];

  var addmyAllPolicyResponseData = function(newObj) {
      myAllPolicyResponseData=[];
      myAllPolicyResponseData.push(newObj);
  };

  var getmyAllPolicyResponseData = function(){
      return myAllPolicyResponseData;
  };

  // for storing and getting policy list data

  var validateUserResponseData = [];

  var addvalidateUserResponseData = function(newObj) {
      validateUserResponseData=[];
      validateUserResponseData.push(newObj);
  };

  var getvalidateUserResponseData = function(){
      return validateUserResponseData;
  };


  // for storing and getting linkPolicySearchDetails

  var linkPolicySearchResponseData = [];

  var addlinkPolicySearchResponseData = function(newObj) {
      linkPolicySearchResponseData=[];
      linkPolicySearchResponseData.push(newObj);
  };

  var getlinkPolicySearchResponseData = function(){
      return linkPolicySearchResponseData;
  };


  // FOR storing and getting getCustomerProfileDetails

  var CustomerProfileDetailsResponseData = [];

  var addCustomerProfileDetailsResponseData = function(newObj) {
      CustomerProfileDetailsResponseData=[];
      CustomerProfileDetailsResponseData.push(newObj);
  };

  var getCustomerProfileDetailsResponseData = function(){
      return CustomerProfileDetailsResponseData;
  };

  // FOR storing and getting getCustomerProfileDetails

  var myQuotesResponseData = [];

  var addmyQuotesResponseData = function(newObj) {
      myQuotesResponseData=[];
      myQuotesResponseData.push(newObj);
  };

  var getmyQuotesResponseData = function(){
      return myQuotesResponseData;
  };


   // FOR storing and getting makelist

  var makeListResponseData = [];

  var addMakeListResponseData = function(newObj) {
      makeListResponseData=[];
      makeListResponseData.push(newObj);
  };

  var getMakeListResponseData = function(){
      return makeListResponseData;
  };


  // FOR storing and getting getModelDetailList

  var modelDetailListResponseData = [];

  var addModelDetailListResponseData = function(newObj) {
      modelDetailListResponseData=[];
      modelDetailListResponseData.push(newObj);
  };

  var getmodelDetailListResponseData = function(){
      return modelDetailListResponseData;
  };



  // FOR storing and getting customer make city

  var customerMakeCityListResponseData = [];

  var addCustomerMakeCityListResponseData = function(newObj) {
      customerMakeCityListResponseData=[];
      customerMakeCityListResponseData.push(newObj);
  };

  var getCustomerMakeCityListResponseData = function(){
      return customerMakeCityListResponseData;
  };


    // FOR storing and getting getQuickQuoteDetail

  var getQuickQuoteDetailResponseData = [];

  var addQuickQuoteDetailResponseData = function(newObj) {
      getQuickQuoteDetailResponseData=[];
      getQuickQuoteDetailResponseData.push(newObj);
  };

  var getQuickQuoteDetailResponseData = function(){
      return getQuickQuoteDetailResponseData;
  };

  // FOR storing and getting saveQuote

  var saveQuoteResponseData = [];

  var addsaveQuoteResponseData = function(newObj) {
      saveQuoteResponseData=[];
      saveQuoteResponseData.push(newObj);
  };

  var getsaveQuoteResponseData = function(){
      return saveQuoteResponseData;
  };

  // FOR generateOTPToAuthPropForm during save quote

  var generateOTPToAuthPropForm = [];

  var addGenerateOTPToAuthPropForm = function(newObj) {
      generateOTPToAuthPropForm=[];
      generateOTPToAuthPropForm.push(newObj);
  };

  var getGenerateOTPToAuthPropForm = function(){
      return generateOTPToAuthPropForm;
  };


  // FOR approveQuoteGen after otp

  var approveQuoteGen = [];

  var addApproveQuoteGen= function(newObj) {
      generateOTPToAuthPropForm=[];
      generateOTPToAuthPropForm.push(newObj);
  };

  var getApproveQuoteGen = function(){
      return generateOTPToAuthPropForm;
  };


  // FOR policyDetails service to fetch policy details after payment screen
  var getPolicyDetails = [];

  var addGetPolicyDetails= function(newObj) {
      getPolicyDetails=[];
      getPolicyDetails.push(newObj);
  };

  var getGetPolicyDetails = function(){
      return getPolicyDetails;
  };

  
  // FOR getDocument service to fetch policy document
  var getDocument = [];

  var addGetDocument= function(newObj) {
      getDocument=[];
      getDocument.push(newObj);
  };

  var getGetDocument = function(){
      return getDocument;
  };


    // FOR getPaymentDetails

  var getPaymentDetails = [];

  var addGetPaymentDetails= function(newObj) {
      getPaymentDetails=[];
      getPaymentDetails.push(newObj);
  };

  var getGetPaymentDetails = function(){
      return getPaymentDetails;
  };

  // FOR collection

  var collectionDetails = [];

  var addCollectionDetails= function(newObj) {
      collectionDetails=[];
      collectionDetails.push(newObj);
  };

  var getCollectionDetails = function(){
      return collectionDetails;
  };
   // // for storing and getting fetchAadharDetails

  var fetchAadharDetails = [];

  var addFetchAadharDetails= function(newObj) {
      fetchAadharDetails=[];
      fetchAadharDetails.push(newObj);
  };

  var getFetchAadharDetails = function(){
      return fetchAadharDetails;
  };


  // FOR saveAadharDetails

  var saveAadharDetails = [];

  var addSaveAadharDetails= function(newObj) {
      saveAadharDetails=[];
      saveAadharDetails.push(newObj);
  };

  var getSaveAadharDetails = function(){
      return saveAadharDetails;
  };


    // FOR productDomainValuesGS

  var productDomainValuesGS = [];

  var addProductDomainValuesGS= function(newObj) {
      productDomainValuesGS=[];
      productDomainValuesGS.push(newObj);
  };

  var getProductDomainValuesGS = function(){
      return productDomainValuesGS;
  };

   // FOR fetchPremiumGS

	var fetchPremiumGS = [];
  
	var addFetchPremiumGS= function(newObj) {
      fetchPremiumGS=[];
      fetchPremiumGS.push(newObj);
	};

	var getFetchPremiumGS = function(){
      return fetchPremiumGS;
	};

	//For Calculate Premium GS
	
	var calculatePremiumGS = [];
	
	 var addCalculatePremiumGS = function(newObj){
		calculatePremiumGS = [];
		calculatePremiumGS.push(newObj);
	 };

	var getCalculatePremiumGS = function(){
		return calculatePremiumGS;
	};
	
	// FOR storing and getting saveQuote

  var saveQuoteResponseDataGS = [];

  var addsaveQuoteResponseDataGS = function(newObj) {
      saveQuoteResponseDataGS=[];
      saveQuoteResponseDataGS.push(newObj);
  };

	var getsaveQuoteResponseDataGS = function () {
		return saveQuoteResponseDataGS;
	};

	//generateOTP added for CR_NP_744C
	var generateOTP = [];

	var addGenerateOTP = function (newObj) {
		generateOTP = [];
		generateOTP.push(newObj);
	};

	var getGenerateOTP = function () {
		return generateOTP;
	};

	// // For storing and getting Relation Details
	// var addRelationDetails = [];
	// var addRelationDetailsGs = function(newObj) {
		  // addRelationDetails=[];
		  // addRelationDetails.push(newObj);
	  // };

	  // var getRelationDetailsGs = function(){
		  // return addRelationDetails;
	  // };
	
return {
	  
    addloginResponseData: addloginResponseData,
    getloginResponseData: getloginResponseData,
    addProductDomainValuesGS:addProductDomainValuesGS,
    getProductDomainValuesGS:getProductDomainValuesGS,
    addFetchPremiumGS:addFetchPremiumGS,
    getFetchPremiumGS:getFetchPremiumGS,
	addCalculatePremiumGS:addCalculatePremiumGS,
	getCalculatePremiumGS:getCalculatePremiumGS,
	addsaveQuoteResponseDataGS:addsaveQuoteResponseDataGS,
	getsaveQuoteResponseDataGS:getsaveQuoteResponseDataGS,
    addFetchAadharDetails: addFetchAadharDetails,
    getFetchAadharDetails: getFetchAadharDetails,
    addSaveAadharDetails :addSaveAadharDetails,
    getSaveAadharDetails:getSaveAadharDetails,
    addmyAllPolicyResponseData: addmyAllPolicyResponseData,
    getmyAllPolicyResponseData: getmyAllPolicyResponseData,
    addvalidateUserResponseData: addvalidateUserResponseData,
    getvalidateUserResponseData: getvalidateUserResponseData,
    addlinkPolicySearchResponseData :addlinkPolicySearchResponseData,
    getlinkPolicySearchResponseData :getlinkPolicySearchResponseData,
    addCustomerProfileDetailsResponseData : addCustomerProfileDetailsResponseData,
    getCustomerProfileDetailsResponseData : getCustomerProfileDetailsResponseData,
    addmyQuotesResponseData:addmyQuotesResponseData,
    getmyQuotesResponseData:getmyQuotesResponseData,
    addMakeListResponseData : addMakeListResponseData,
    getMakeListResponseData : getMakeListResponseData,
    addModelDetailListResponseData : addModelDetailListResponseData,
    getmodelDetailListResponseData : getmodelDetailListResponseData,
    addCustomerMakeCityListResponseData : addCustomerMakeCityListResponseData,
    getCustomerMakeCityListResponseData : getCustomerMakeCityListResponseData,
    addQuickQuoteDetailResponseData : addQuickQuoteDetailResponseData,
    getQuickQuoteDetailResponseData :getQuickQuoteDetailResponseData,
    addsaveQuoteResponseData:addsaveQuoteResponseData,
    getsaveQuoteResponseData : getsaveQuoteResponseData,
    addGenerateOTPToAuthPropForm :addGenerateOTPToAuthPropForm,
    getGenerateOTPToAuthPropForm :getGenerateOTPToAuthPropForm,
    addApproveQuoteGen : addApproveQuoteGen,
    getApproveQuoteGen : getApproveQuoteGen,
    addGetPolicyDetails : addGetPolicyDetails,
    getGetPolicyDetails : getGetPolicyDetails,
    addGetDocument : addGetDocument,
    getGetDocument : getGetDocument,
    addGetPaymentDetails : addGetPaymentDetails,
    getGetPaymentDetails : getGetPaymentDetails,
		addCollectionDetails: addCollectionDetails,
		getCollectionDetails: getCollectionDetails,
		addGenerateOTP: addGenerateOTP,
		getGenerateOTP: getGenerateOTP

  };

});

agentApp.service('CartServices', ['$rootScope', '$state', 'CommonServices', 'RestServices', '$q', function($rootScope, $state, CommonServices, RestServices, $q) {
	/***
	 * Cart Details
	 */
	// CommonServices.setCommonData("addToCart", 'cart')
	this.cartCount = 0;
	this.cartListing = [];
	this.cartPaymentListing = [];
	this.cartPaymenEnable = false;
	this.paymentCutOffTime = 20; // 8 PM
	this.maxQuoteLimit = 5; // max no of qoute that can be added in the cart
	var localCart = this;

	this.approveAndAddToCart = function(requestPlayload, productCode) {
		var cartApprove = RestServices.postService(RestServices.urlPathsNewPortal.approveRenewedQuote, requestPlayload);
		cartApprove.then(function(cResponse) { // success
			if (cResponse.data.userProfile !== undefined ) {
				if (cResponse.data.userProfile.footer.errorCode === "1") {
					CommonServices.setCommonData("validateStatus", cResponse.data.userProfile.footer.status);
					var msg = "Quote has been approved and added in the cart for payment";
					localCart.saveToCart(cResponse.data.quote.quoteNumber, msg);
										
				} else {
					CommonServices.showLoading(false);
					CommonServices.showAlert(cResponse.data.userProfile.footer.errorDescription);
				}
			}
			else {
				CommonServices.showLoading(false);
				CommonServices.showAlert(cResponse.data.errorMessage);
			}
		},
		function(error) { // failure
			CommonServices.showLoading(false);
			RestServices.handleWebServiceError(error);
		});
	};

	this.saveToCart = function (quoteNumber, msg = '') {
		if (quoteNumber !== undefined) {
			var dt = new Date();
			var params = {
				"userId": CommonServices.getCommonData("userId"),
				"createdDate": dt.getDate()+"-"+(parseInt(dt.getMonth())+1)+"-"+dt.getFullYear(), // "29-11-2019"
				"quoteNo": quoteNumber
			};
			var cartSave = RestServices.postService(RestServices.urlPathsNewPortal.collectionCartSave, params);
			cartSave.then(function(sResponse) { // success
				// condition to validate save
				if (sResponse.data.errCode === "0") {
					localCart.cartCount += 1;
					CommonServices.showLoading(false);
					msg = (msg == '') ? "Quote has been added in the cart for payment" : msg;
					CommonServices.messageModal('info', msg, false, 'Go to cart', 'Go to Dashboard', function() {
						$state.go("showCart");
					}, function () {
						$state.go("home");
					}, 'Alert', false, true);
				} else {
					CommonServices.showLoading(false);
					CommonServices.showAlertWithBtns(sResponse.data.errMessage);
				}				
			},
			function(error) { // failure
				CommonServices.showLoading(false);
				RestServices.handleWebServiceError(error);
			});
		}
	};

	this.formatAMPM = function (date) {
		var hours = date.getHours();
		var minutes = date.getMinutes();
		var ampm = hours >= 12 ? 'PM' : 'AM';
		hours = hours % 12;
		hours = hours ? hours : 12; // the hour '0' should be '12'
		minutes = minutes < 10 ? '0'+minutes : minutes;
		var strTime = hours + ':' + minutes + ' ' + ampm;
		return strTime;
	};
	
	this.cartReset = function(hardReset = false) {
		this.cartPaymentListing = [];
		this.cartPaymenEnable = false;
		CommonServices.setCommonData("addToCart", '');
		CommonServices.setCommonData("cartPaymentDetails", undefined);
		if (hardReset) {
			this.cartCount = 0;
			this.cartListing = [];
		}
	};

	this.getCartCount = function() {
		localCart.cartCount = 0;
		var defer = $q.defer();
		var cartData = {
			"userId": CommonServices.getCommonData("userCode").toUpperCase()
		};
		
		var cartListResponse = RestServices.postService(RestServices.urlPathsNewPortal.collectionCartFetch, cartData);
		cartListResponse.then(function(response) { /* success */
			if (response.data !== "" && response.data.quoteList != undefined) {
				localCart.cartCount = response.data.quoteList.length;
				defer.resolve(localCart.cartCount);
			} else {
				defer.reject(localCart.cartCount);
			}
			CommonServices.showLoading(false);
		},
		function(error) { /* failure */
			defer.reject(localCart.cartCount);
			CommonServices.showLoading(false);
			RestServices.handleWebServiceError(error);
		});
		return defer.promise;
	};

}]);


