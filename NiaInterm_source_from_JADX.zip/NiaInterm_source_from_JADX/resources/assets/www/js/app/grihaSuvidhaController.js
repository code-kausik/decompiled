agentApp.controller('landingScreenCtrlGS', ['$scope', 'RestServices', 'CommonServices', '$state', '$rootScope', 'GetSetResponseService', function ($scope, RestServices, CommonServices, $state, $rootScope, GetSetResponseService) {

	$scope.bodyHeight = window.innerHeight + 'px';
	$rootScope.policyHolderDataGs = {};

	$scope.goBack = function () {
		if(CommonServices.editQuoteFlag == true){//CR_0054
			$state.go("managePolicies.managePolicies");//CR_0054
		}else
		$state.go('buyNowSubLandingScreen');
	}

	/*CR_MOBL_0054-GS Starts */

	// $scope.grihaSuvidha = {};
	// $scope.grihaSuvidha.sumInsuredList = [];

	// $scope.getSumInsuredDetailsGS = function () {

	// 	var getProductDomainValuesInput = {
	// 		"productCode": "GS",
	// 		"lngCode": "EN",
	// 		"keys": [
	// 			"SUM_INSURED_GS_OPTION1",
	// 			"SUM_INSURED_GS_OPTION2",
	// 			"SUM_INSURED_GS_OPTION3",
	// 			"SUM_INSURED_GS_OPTION4"
	// 		]
	// 	};

	// 	var getProductDomainValuesResponse = RestServices.postService(RestServices.urlPathsNewPortal.getProductDomainValues, getProductDomainValuesInput);
	// 	getProductDomainValuesResponse.then(
	// 		function (response) { //Success
	// 			if (response.data.productDomainValues != undefined && response.data.productDomainValues != "" && response.data.productDomainValues.length > 0) {

	// 				for (var i = 0; i < response.data.productDomainValues.length; i++) {


	// 					if (response.data.productDomainValues[i].domainValues.codeId == "SUM_INSURED_GS_OPTION1" && response.data.productDomainValues[i].domainValues.sortOrder == "1") {
	// 						$scope.sumInsuredFireOption1 = response.data.productDomainValues[i].domainValues.codeValue;
	// 					}

	// 					if (response.data.productDomainValues[i].domainValues.codeId == "SUM_INSURED_GS_OPTION1" && response.data.productDomainValues[i].domainValues.sortOrder == "2") {
	// 						$scope.sumInsuredBurglaryOption1 = response.data.productDomainValues[i].domainValues.codeValue;
	// 					}

	// 					if (response.data.productDomainValues[i].domainValues.codeId == "SUM_INSURED_GS_OPTION1" && response.data.productDomainValues[i].domainValues.sortOrder == "3") {
	// 						$scope.sumInsuredJewelleryOption1 = response.data.productDomainValues[i].domainValues.codeValue;
	// 					}

	// 					if (response.data.productDomainValues[i].domainValues.codeId == "SUM_INSURED_GS_OPTION1" && response.data.productDomainValues[i].domainValues.sortOrder == "4") {
	// 						$scope.sumInsuredDomesticOption1 = response.data.productDomainValues[i].domainValues.codeValue;
	// 					}

	// 					if (response.data.productDomainValues[i].domainValues.codeId == "SUM_INSURED_GS_OPTION1" && response.data.productDomainValues[i].domainValues.sortOrder == "5") {
	// 						$scope.sumInsuredTVOption1 = response.data.productDomainValues[i].domainValues.codeValue;
	// 					}

	// 					if (response.data.productDomainValues[i].domainValues.codeId == "SUM_INSURED_GS_OPTION2" && response.data.productDomainValues[i].domainValues.sortOrder == "1") {
	// 						$scope.sumInsuredFireOption2 = response.data.productDomainValues[i].domainValues.codeValue;
	// 					}

	// 					if (response.data.productDomainValues[i].domainValues.codeId == "SUM_INSURED_GS_OPTION2" && response.data.productDomainValues[i].domainValues.sortOrder == "2") {
	// 						$scope.sumInsuredBurglaryOption2 = response.data.productDomainValues[i].domainValues.codeValue;
	// 					}

	// 					if (response.data.productDomainValues[i].domainValues.codeId == "SUM_INSURED_GS_OPTION2" && response.data.productDomainValues[i].domainValues.sortOrder == "3") {
	// 						$scope.sumInsuredJewelleryOption2 = response.data.productDomainValues[i].domainValues.codeValue;
	// 					}

	// 					if (response.data.productDomainValues[i].domainValues.codeId == "SUM_INSURED_GS_OPTION2" && response.data.productDomainValues[i].domainValues.sortOrder == "4") {
	// 						$scope.sumInsuredDomesticOption2 = response.data.productDomainValues[i].domainValues.codeValue;
	// 					}

	// 					if (response.data.productDomainValues[i].domainValues.codeId == "SUM_INSURED_GS_OPTION2" && response.data.productDomainValues[i].domainValues.sortOrder == "5") {
	// 						$scope.sumInsuredTVOption2 = response.data.productDomainValues[i].domainValues.codeValue;
	// 					}

	// 					if (response.data.productDomainValues[i].domainValues.codeId == "SUM_INSURED_GS_OPTION3" && response.data.productDomainValues[i].domainValues.sortOrder == "1") {
	// 						$scope.sumInsuredFireOption3 = response.data.productDomainValues[i].domainValues.codeValue;
	// 					}

	// 					if (response.data.productDomainValues[i].domainValues.codeId == "SUM_INSURED_GS_OPTION3" && response.data.productDomainValues[i].domainValues.sortOrder == "2") {
	// 						$scope.sumInsuredBurglaryOption3 = response.data.productDomainValues[i].domainValues.codeValue;
	// 					}

	// 					if (response.data.productDomainValues[i].domainValues.codeId == "SUM_INSURED_GS_OPTION3" && response.data.productDomainValues[i].domainValues.sortOrder == "3") {
	// 						$scope.sumInsuredJewelleryOption3 = response.data.productDomainValues[i].domainValues.codeValue;
	// 					}

	// 					if (response.data.productDomainValues[i].domainValues.codeId == "SUM_INSURED_GS_OPTION3" && response.data.productDomainValues[i].domainValues.sortOrder == "4") {
	// 						$scope.sumInsuredDomesticOption3 = response.data.productDomainValues[i].domainValues.codeValue;
	// 					}

	// 					if (response.data.productDomainValues[i].domainValues.codeId == "SUM_INSURED_GS_OPTION3" && response.data.productDomainValues[i].domainValues.sortOrder == "5") {
	// 						$scope.sumInsuredTVOption3 = response.data.productDomainValues[i].domainValues.codeValue;
	// 					}

	// 					if (response.data.productDomainValues[i].domainValues.codeId == "SUM_INSURED_GS_OPTION4" && response.data.productDomainValues[i].domainValues.sortOrder == "1") {
	// 						$scope.sumInsuredFireOption4 = response.data.productDomainValues[i].domainValues.codeValue;
	// 					}

	// 					if (response.data.productDomainValues[i].domainValues.codeId == "SUM_INSURED_GS_OPTION4" && response.data.productDomainValues[i].domainValues.sortOrder == "2") {
	// 						$scope.sumInsuredBurglaryOption4 = response.data.productDomainValues[i].domainValues.codeValue;
	// 					}

	// 					if (response.data.productDomainValues[i].domainValues.codeId == "SUM_INSURED_GS_OPTION4" && response.data.productDomainValues[i].domainValues.sortOrder == "3") {
	// 						$scope.sumInsuredJewelleryOption4 = response.data.productDomainValues[i].domainValues.codeValue;
	// 					}

	// 					if (response.data.productDomainValues[i].domainValues.codeId == "SUM_INSURED_GS_OPTION4" && response.data.productDomainValues[i].domainValues.sortOrder == "4") {
	// 						$scope.sumInsuredDomesticOption4 = response.data.productDomainValues[i].domainValues.codeValue;
	// 					}

	// 					if (response.data.productDomainValues[i].domainValues.codeId == "SUM_INSURED_GS_OPTION4" && response.data.productDomainValues[i].domainValues.sortOrder == "5") {
	// 						$scope.sumInsuredTVOption4 = response.data.productDomainValues[i].domainValues.codeValue;
	// 					}

	// 				}

	// 				$scope.grihaSuvidha.sumInsuredList = [
	// 					{
	// 						"sumInsuredFire": $scope.sumInsuredFireOption1,
	// 						"sumInsuredBurglary": $scope.sumInsuredBurglaryOption1,
	// 						"sumInsuredJewellery": $scope.sumInsuredJewelleryOption1,
	// 						"sumInsuredDomestic": $scope.sumInsuredDomesticOption1,
	// 						"sumInsuredTV": $scope.sumInsuredTVOption1,
	// 						"option": "Option1"
	// 					},
	// 					{
	// 						"sumInsuredFire": $scope.sumInsuredFireOption2,
	// 						"sumInsuredBurglary": $scope.sumInsuredBurglaryOption2,
	// 						"sumInsuredJewellery": $scope.sumInsuredJewelleryOption2,
	// 						"sumInsuredDomestic": $scope.sumInsuredDomesticOption2,
	// 						"sumInsuredTV": $scope.sumInsuredTVOption2,
	// 						"option": "Option2"
	// 					},
	// 					{
	// 						"sumInsuredFire": $scope.sumInsuredFireOption3,
	// 						"sumInsuredBurglary": $scope.sumInsuredBurglaryOption3,
	// 						"sumInsuredJewellery": $scope.sumInsuredJewelleryOption3,
	// 						"sumInsuredDomestic": $scope.sumInsuredDomesticOption3,
	// 						"sumInsuredTV": $scope.sumInsuredTVOption3,
	// 						"option": "Option3"
	// 					},
	// 					{
	// 						"sumInsuredFire": $scope.sumInsuredFireOption4,
	// 						"sumInsuredBurglary": $scope.sumInsuredBurglaryOption4,
	// 						"sumInsuredJewellery": $scope.sumInsuredJewelleryOption4,
	// 						"sumInsuredDomestic": $scope.sumInsuredDomesticOption4,
	// 						"sumInsuredTV": $scope.sumInsuredTVOption4,
	// 						"option": "Option4"
	// 					}
	// 				];

	// 				GetSetResponseService.addProductDomainValuesGS($scope.grihaSuvidha.sumInsuredList);

	// 				$scope.fetchPremiumGS();
	// 			} else {
	// 				CommonServices.showLoading(false);
	// 				CommonServices.showAlert("Error occured, please try after sometime");
	// 			}


	// 		}, function (error) { // failure
	// 			CommonServices.showLoading(false);
	// 			RestServices.handleWebServiceError(error);
	// 		});

	// 	/*$state.go('gsPremiumCalculator');*/
	// };

	// $scope.fetchPremiumGS = function () {

	// 	var fetchPremiumGSInput = {
	// 		"userProfile": {
	// 			"userId": CommonServices.getCommonData("userId"),
	// 			"loggedInRole": "SUPERUSER"
	// 		},
	// 		"quote": {
	// 			"sumInsuredList": $scope.grihaSuvidha.sumInsuredList
	// 		}
	// 	};

	// 	var fetchPremiumGSResponse = RestServices.postService(RestServices.urlPathsNewPortal.fetchPremiumGS, fetchPremiumGSInput);
	// 	fetchPremiumGSResponse.then(
	// 		function (response) {

	// 			CommonServices.showLoading(false);
	// 			if (response.data.hasOwnProperty('errorMessage')) {
	// 				CommonServices.showAlert(response.data.errorMessage);
	// 			} else {
	// 				if (response.data.userProfile.footer.errorCode == "0" && response.data.quote.fetchPremiumGS.length != 0) {

	// 					GetSetResponseService.addFetchPremiumGS(response.data.quote.fetchPremiumGS);
	// 					$state.go('gsPremiumCalculator');

	// 				} else if (response.data.userProfile.footer.errorCode == "0" && response.data.quote.fetchPremiumGS.length == 0) {
	// 					CommonServices.showAlert("Error occured,please try again later.");
	// 				} else if (response.data.userProfile.footer.errorCode == "1" && response.data.userProfile.footer.errorDescription == undefined) {
	// 					CommonServices.showAlert("Error occured,please try again later.");
	// 				} else {
	// 					CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
	// 				}
	// 			}


	// 		}, function (error) {
	// 			CommonServices.showLoading(false);
	// 			RestServices.handleWebServiceError(error);
	// 		});

	// };
	/*CR_MOBL_0054-GS Ends */
}]);

agentApp.controller('premiumCalculatorScreenCtrlGS', ['$scope', '$rootScope', 'RestServices', 'CommonServices', '$state', 'GetSetResponseService', function ($scope, $rootScope, RestServices, CommonServices, $state, GetSetResponseService) {

	$scope.bodyHeight = window.innerHeight + 'px';
	$scope.isFireAndAlliedPerilsIncEarthquakeGS = false;
	$scope.fireAndPerils = {};

	$scope.goBack = function () {
		$state.go('gsLandingScreen');
	}

	$scope.onload = function () {

		$scope.gsOptions = [
			{
				optionName: 'Option1',
				value: 0,
				panelName: 'Panel 1'
			},
			{
				optionName: 'Option2',
				value: 1,
				panelName: 'Panel 2'
			},
			{
				optionName: 'Option3',
				value: 2,
				panelName: 'Panel 3'
			},
			{
				optionName: 'Option4',
				value: 3,
				panelName: 'Panel 4'
			}
		];

		$scope.productDomainValues = GetSetResponseService.getProductDomainValuesGS()[0];
		$scope.productPremiumDetails = GetSetResponseService.getFetchPremiumGS()[0];

		// console.log(JSON.stringify(CommonServices.grihaSuvidhaObj));

		/*CR_MOBL_0054-GS Starts */
		if (CommonServices.editQuoteFlag === true) {
			if ("Option1" === CommonServices.grihaSuvidhaObj.risks[0].coverage.coverType) {
				$scope.selectedOption = 0;
				CommonServices.setCommonData("selectedOptionName", "Option1");
			} else if ("Option2" === CommonServices.grihaSuvidhaObj.risks[0].coverage.coverType) {
				$scope.selectedOption = 1;
				CommonServices.setCommonData("selectedOptionName", "Option2");
			} else if ("Option3" === CommonServices.grihaSuvidhaObj.risks[0].coverage.coverType) {
				$scope.selectedOption = 2;
				CommonServices.setCommonData("selectedOptionName", "Option3");
			} else if ("Option4" === CommonServices.grihaSuvidhaObj.risks[0].coverage.coverType) {
				$scope.selectedOption = 3;
				CommonServices.setCommonData("selectedOptionName", "Option4");
			}

			if (CommonServices.grihaSuvidhaObj.risks[0].coverage.basicCover.isFireQuakeTerrorIncludingPremises === "Y") {
				$scope.isFireAndAlliedPerilsIncEarthquakeGS = true;
			} else {
				$scope.isFireAndAlliedPerilsIncEarthquakeGS = false;
			}

			$scope.fireAndPerils.sumInsuredPerils = CommonServices.grihaSuvidhaObj.risks[0].coverage.basicCover.sumInsuredFireQuakeTerrorIncludingPremises;

			// To bind Mobile Number Value
			var lognData = CommonServices.getCommonData("LoginData");
			$scope.mobileNumber = lognData.userProfile.relation.addresses[0].mobileNumber2;
			$scope.emailID = lognData.userProfile.relation.addresses[0].emailId2;
		}
		/*CR_MOBL_0054-GS Ends */

		if ($rootScope.backNavigationFromPremiumResultGs === true) {
			var bindModelDataToScope = CommonServices.getCommonData("storePremiumCalcScreenData");
			$scope.selectedOption = bindModelDataToScope.selectedOption;
			$scope.isFireAndAlliedPerilsIncEarthquakeGS = bindModelDataToScope.isFireAndAlliedPerilsIncEarthquakeGS;
			$scope.fireAndPerils.sumInsuredPerils = bindModelDataToScope.sumInsuredFireAndAliedPerilsIncPremises;
			$scope.mobileNumber = bindModelDataToScope.mobileNumber;
			$scope.emailID = bindModelDataToScope.emailID;
			$rootScope.backNavigationFromPremiumResultGs = "false";
		} else {
			$rootScope.backNavigationFromPremiumResultGs = "false";
		}
	}

	$scope.onload();
	var indexList = [0, 1, 2, 3];
	var selectedOptionsName;

	$scope.termsAndCondition = function () {
		$rootScope.enableTermsCondions = true;
		$rootScope.prodDiscOpen = true;
		$rootScope.readTermsAndCondp2 = "I understand that by providing my mobile no and e-mail id through the Online Portal, I agree to being contacted by The New India Assurance Co.Ltd. The New India Assurance Co.Ltd shall protect all such information and it shall not be utilised in any manner that will directly or indirectly result in any harm to me.";
		$rootScope.readTermsAndCondp3 = "I understand and accept that The New India Assurance Co.Ltd reserves the right to determine the eligibility and availability of any product or service.";
		$rootScope.readTermsAndCondp4 = "I understand that premium shown in the Quick Quote is only estimated premium and may be subjected to change during Detailed Quote depending on the Cover selected and other information provided by me. And I also understand that the premium shown on the Online Portal will be subjected to any changes based on the IRDAI regulations from time to time.";
	};
	$scope.closeTermsCondition = function () {
		$rootScope.enableTermsCondions = false;
		$rootScope.prodDiscOpen = false;
	};
	
	$(".premiumCalculatorOptionHeader label input").prop('checked', false);
	$scope.$parent.selectedOption = undefined;
	$scope.buttonClick = function (index, optionName='') {

		var acc = document.getElementById("accordion" + index);
		var i;
		var panel = document.getElementById("panel" + index);
		var value = $("#" + acc.id).find('input').val();
		if (panel.style.display === "block") {
			panel.style.display = "none";
			$("#" + acc.id).removeClass("panelActive");
			//$("#" + acc.id + " input").prop('checked', false);
			//$scope.$parent.selectedOption = undefined;

		} else {
			panel.style.display = "block";
			$scope.id = acc.id;
			$("#" + $scope.id).addClass("panelActive");
			$("#" + acc.id + " input").prop('checked', true);
			$scope.$parent.selectedOption = value;
		}
		for (var i in indexList) {
			if (index != indexList[i]) {
				var accIn = document.getElementById("accordion" + i);
				var panel = document.getElementById("panel" + i);
				panel.style.display = "none";
				$("#" + accIn.id).removeClass("panelActive");
			}
		}
		for (var i = 0; i < $scope.gsOptions.length; i++) {
			if ($scope.gsOptions[i].value === index) {
				selectedOptionsName = $scope.gsOptions[i].optionName;
				CommonServices.setCommonData("selectedOptionName", selectedOptionsName);

			}

		}

	};


	$scope.showFireAndPerilsIncEarthquake = function () {
		if ($scope.isFireAndAlliedPerilsIncEarthquakeGS === false) {
			$scope.isFireAndAlliedPerilsIncEarthquakeGS = true;
		} else {
			$scope.isFireAndAlliedPerilsIncEarthquakeGS = false;
			//$scope.fireAndPerils.sumInsuredPerils = "";
		}
	};

	$scope.calculatePremiumButtonClick = function () {
		var index = parseInt($scope.selectedOption);
		var sumInsuredFireAndAliedPerilsIncPremises;
		$rootScope.selectedOptionDomainValuesGs = $scope.productDomainValues[index];
		$rootScope.selectedOptionIndexGs = (parseInt($scope.selectedOption));
		$rootScope.isFireAndAlliedPerilsIncEarthquakeGS = $scope.isFireAndAlliedPerilsIncEarthquakeGS;

		if ($scope.isFireAndAlliedPerilsIncEarthquakeGS === true) {
			sumInsuredFireAndAliedPerilsIncPremises = $scope.fireAndPerils.sumInsuredPerils;
		} else {
			sumInsuredFireAndAliedPerilsIncPremises = "0";
		}

		//CommonServices.setCommonData("sumInsuredFireAndAliedPerilsIncPremises",sumInsuredFireAndAliedPerilsIncPremises);
		$rootScope.sumInsuredFireAndAliedPerilsIncPremisesGs = sumInsuredFireAndAliedPerilsIncPremises;


		$rootScope.totalSumInsuredofBuildingGs = parseInt($rootScope.sumInsuredFireAndAliedPerilsIncPremisesGs) +
			parseInt($rootScope.selectedOptionDomainValuesGs.sumInsuredJewellery) +
			parseInt($rootScope.selectedOptionDomainValuesGs.sumInsuredDomestic) +
			parseInt($rootScope.selectedOptionDomainValuesGs.sumInsuredTV) +
			parseInt($rootScope.selectedOptionDomainValuesGs.sumInsuredBurglary) +
			parseInt($rootScope.selectedOptionDomainValuesGs.sumInsuredFire);

		//Policy start and Expiry date
		var mydateStr = CommonServices.getCommonData("serverDate");
		var policyStartDate = mydateStr.split('/');		//mm/dd/yyyy
		policyStartDate = policyStartDate[1] + '/' + policyStartDate[0] + '/' + policyStartDate[2]; //dd/mm/yyyy 
		$rootScope.policyStartDateGs = policyStartDate;

		var policyExpiryDate = new Date(mydateStr);
		policyExpiryDate.setFullYear(policyExpiryDate.getFullYear() + 1);
		policyExpiryDate.setDate(policyExpiryDate.getDate() - 1);
		var dd = policyExpiryDate.getDate();
		var mm = policyExpiryDate.getMonth() + 1;
		var yyyy = policyExpiryDate.getFullYear();

		if (dd < 10) {
			dd = "0" + dd;
		}

		if (mm < 10) {
			mm = "0" + mm;
		}
		policyExpiryDate = dd + "/" + mm + "/" + yyyy;//policy start date
		$rootScope.policyExpiryDateGs = policyExpiryDate;

		//Below added for testing purpose
		console.log(GetSetResponseService.getCalculatePremiumGS().quote);
		console.log("CommonServices.editQuoteFlag"+CommonServices.editQuoteFlag);
		console.log("CommonServices.grihaSuvidhaObj.fromBasicPremium"+CommonServices.grihaSuvidhaObj.fromBasicPremium);
		//console.log("GetSetResponseService.getCalculatePremiumGS()[0].quote.quoteNumber"+GetSetResponseService.getCalculatePremiumGS()[0].quote.quoteNumber);
		var calculatePremiumGSInput = {
			"quote": {
				"isMobileDisabled": false,
				"isEmailDisabled": false,
				"risks": [
					{
						"coverage": {
							"jewelleryCover": {
								"totalSumInsured": $rootScope.selectedOptionDomainValuesGs.sumInsuredJewellery
							},
							"applianceCovers": [
								{
									"totalSumInsured": $rootScope.selectedOptionDomainValuesGs.sumInsuredDomestic,
									"applianceType": "DOMESTIC"
								},
								{
									"totalSumInsured": $rootScope.selectedOptionDomainValuesGs.sumInsuredTV,
									"applianceType": "TV"
								}
							],
							"basicCover": {
								"isFireQuakeTerrorIncludingPremises": $rootScope.isFireAndAlliedPerilsIncEarthquakeGS === true ? "Y" : "N",
								"sumInsuredFireQuakeTerrorIncludingPremises": $rootScope.sumInsuredFireAndAliedPerilsIncPremisesGs,
								"totalSumInsuredForBurglary": $rootScope.selectedOptionDomainValuesGs.sumInsuredBurglary,
								"sumInsuredFireQuakeTerrorExcludingJewellery": $rootScope.selectedOptionDomainValuesGs.sumInsuredFire,
								"totalSumInsuredofBuilding": $rootScope.totalSumInsuredofBuildingGs
							},
							"coverType": CommonServices.getCommonData("selectedOptionName")
						}
					}
				],
				"policyStartDate": $rootScope.policyStartDateGs,
				"policyExpiryDate": $rootScope.policyExpiryDateGs,
				"acceptdeclaration": true,
				"mobileNo": $scope.mobileNumber,
				"emailId": $scope.emailID,
				"product": "GS",
				"quoteNumber": CommonServices.editQuoteFlag === true ? CommonServices.grihaSuvidhaObj.quoteNumber : CommonServices.grihaSuvidhaObj.fromBasicPremium === true ? GetSetResponseService.getCalculatePremiumGS()[0].quote.quoteNumber : "",//"",//sourav 05.11.2019 modified because when user going for griha subhidha for 2nd time or coming back from previous page it is blocking user to move as we are getting "Mandatory fields are missing" alert from service as we are sending quote no which is not correct
				"productCode": "GS"
			},
			"userProfile": {
				"userId": CommonServices.getCommonData("userId"),
				"loggedInRole": "SUPERUSER"
			}

		};
		// "quoteNumber": CommonServices.editQuoteFlag === true ? CommonServices.grihaSuvidhaObj.quoteNumber : CommonServices.grihaSuvidhaObj.fromBasicPremium === true ? GetSetResponseService.getCalculatePremiumGS()[0].quote.quoteNumber : "",

		//console.log(calculatePremiumGSInput);
		console.log(JSON.stringify(calculatePremiumGSInput));

		var calculatePremiumGSResponse = RestServices.postService(RestServices.urlPathsNewPortal.calcPremium, calculatePremiumGSInput);
		calculatePremiumGSResponse.then(
			function (response) { //success

				CommonServices.showLoading(false);
				if (response.data.hasOwnProperty('errorMessage')) {
					CommonServices.showLoading(false);
					CommonServices.showAlert(response.data.errorMessage);
				} else {
					if (response.data.userProfile.footer.errorCode == "0") {
						CommonServices.grihaSuvidhaObj.fromBasicPremium = true; //Added during CR_MOBL_0054-GS
						GetSetResponseService.addCalculatePremiumGS(response.data);
						// To set the data of Premium Calculator screen in Object and store in CommonServices before navigating to Premium result screen
						$scope.storePremiumCalcScreenData = {
							selectedOption: $scope.selectedOption,
							isFireAndAlliedPerilsIncEarthquakeGS: $scope.isFireAndAlliedPerilsIncEarthquakeGS,
							sumInsuredFireAndAliedPerilsIncPremises: sumInsuredFireAndAliedPerilsIncPremises,
							mobileNumber: $scope.mobileNumber,
							emailID: $scope.emailID
						};
						CommonServices.setCommonData("storePremiumCalcScreenData", $scope.storePremiumCalcScreenData);
						//console.log($scope.storePremiumCalcScreenData);

						$state.go('gsPremiumResult');

					} else {
						if (response.data.userProfile.footer.errorDescription != undefined) {
							CommonServices.showLoading(false);
							CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
						} else {
							CommonServices.showLoading(false);
							CommonServices.showAlert("Error occured, please try again later.");
						}

					}
				}


			}, function (error) {
				CommonServices.showLoading(false);
				RestServices.handleWebServiceError(error);
			});

	};

}]);

agentApp.controller('premiumResultScreenCtrlGS', ['$scope', '$rootScope', 'RestServices', 'CommonServices', '$state', 'GetSetResponseService', function ($scope, $rootScope, RestServices, CommonServices, $state, GetSetResponseService) {

	$scope.premCalcScrnDataInPreRes = CommonServices.getCommonData("storePremiumCalcScreenData");
	$rootScope.stakeCode = CommonServices.getCommonData("stakeCode");
	//$scope.selectedOptionIndexInPreRes = CommonServices.selectedOptionIndex;			
	//$scope.sumInsuredJewelleryInPreRes = CommonServices.selectedOptionDomainValues.sumInsuredJewellery;
	//$scope.sumInsuredDomesticInPreRes = CommonServices.selectedOptionDomainValues.sumInsuredDomestic;
	//$scope.sumInsuredTVInPreRes = CommonServices.selectedOptionDomainValues.sumInsuredTV;
	//$scope.SumInsuredBurglaryInPreRes = CommonServices.selectedOptionDomainValues.sumInsuredBurglary;
	//$scope.sumInsuredFireAlliedPerilsInPreRes = CommonServices.selectedOptionDomainValues.sumInsuredFire;
	//$scope.sumInsuredFireAndAliedPerilsIncPremisesInPreRes = CommonServices.getCommonData("sumInsuredFireAndAliedPerilsIncPremises");
	//$scope.totalSumInsuredofBuildingInPreRes = parseInt($scope.sumInsuredFireAndAliedPerilsIncPremisesInPreRes) +  parseInt($scope.sumInsuredJewelleryInPreRes) + parseInt($scope.sumInsuredDomesticInPreRes) +  parseInt($scope.sumInsuredTVInPreRes) +  parseInt($scope.SumInsuredBurglaryInPreRes) +  parseInt($scope.sumInsuredFireAlliedPerilsInPreRes);

	$scope.onload = function () {
		$scope.premiumResultGS = GetSetResponseService.getCalculatePremiumGS();
	};

	$scope.goBack = function () {
		$rootScope.backNavigationFromPremiumResultGs = true;
		$state.go('gsPremiumCalculator');
	};
	$scope.sendSMSAndMail = function () {
		//SMS and emailID service Input
		var sendSMSAndMailInput = {
			"quote": {
				"risks": [
					{
						"coverage": {
							"jewelleryCover": {
								"totalSumInsured": $rootScope.selectedOptionDomainValuesGs.sumInsuredJewellery,
								"coverDetails": []
							},
							"applianceCovers": [
								{
									"totalSumInsured": $rootScope.selectedOptionDomainValuesGs.sumInsuredDomestic,
									"applianceType": "DOMESTIC",
									"coverDetails": []
								},
								{
									"totalSumInsured": $rootScope.selectedOptionDomainValuesGs.sumInsuredTV,
									"applianceType": "TV",
									"coverDetails": []
								}
							],
							"basicCover": {
								"isFireQuakeTerrorIncludingPremises": $rootScope.isFireAndAlliedPerilsIncEarthquakeGS === true ? "Y" : "N",
								"sumInsuredFireQuakeTerrorIncludingPremises": $rootScope.sumInsuredFireAndAliedPerilsIncPremisesGs,
								"sumInsuredFireQuakeTerrorExcludingJewellery": $rootScope.selectedOptionDomainValuesGs.sumInsuredFire,
								"totalSumInsuredForBurglary": $rootScope.selectedOptionDomainValuesGs.sumInsuredBurglary,
								"totalSumInsuredofBuilding": $rootScope.totalSumInsuredofBuildingGs.toString()
							},
							"coverType": CommonServices.getCommonData("selectedOptionName")
						}
					}
				],
				"estimatedPremium": $scope.premiumResultGS[0].quote.premiumDetails.grossPremium,
				"totalPremium": $scope.premiumResultGS[0].quote.premiumDetails.netPremium,
				"policyStartDate": $rootScope.policyStartDateGs,
				"policyExpiryDate": $rootScope.policyExpiryDateGs,
				"productCode": "GS",
				"emailId": $scope.premCalcScrnDataInPreRes.emailID,
				"mobileNo": $scope.premCalcScrnDataInPreRes.mobileNumber,
				"quoteNumber": $scope.premiumResultGS[0].quote.quoteNumber,
				"totalSumInsured": $rootScope.totalSumInsuredofBuildingGs.toString(),
				"premiumDetails": {
					"grossPremium": $scope.premiumResultGS[0].quote.premiumDetails.grossPremium,
					"netPremium": $scope.premiumResultGS[0].quote.premiumDetails.netPremium
				},
				"progressLevel": "DQ"
			},
			"userProfile": {
				"userId": CommonServices.getCommonData("userId"),
				"loggedInRole": "SUPERUSER",
				"stakeCode": CommonServices.getCommonData("stakeCode")
			},
			"alfrescoInput": {
				"channel": "NonCustomer",
				"language": "English",
				// "productName": "Griha Suvidha",
				"productName": "GS"
			}
		};

		var sendSMSAndMailResponse = RestServices.postService(RestServices.urlPathsNewPortal.saveQuoteDBGs, sendSMSAndMailInput);
		sendSMSAndMailResponse.then(
			function (response) {

				CommonServices.showLoading(false);
				if (response.data.hasOwnProperty('errorMessage')) {
					CommonServices.showLoading(false);
					CommonServices.showAlert(response.data.errorMessage);
				} else {
					if (response.data.userProfile.footer.errorCode == "0") {
						if (response.data.userProfile.footer.errorCode == "0" && response.data.userProfile.footer.status === "Quotation details updated") {
							CommonServices.showAlert("SMS and Email has already been sent to " + $scope.premCalcScrnDataInPreRes.mobileNumber + " & " + $scope.premCalcScrnDataInPreRes.emailID);
						} else {
							CommonServices.showAlert("SMS and Email has been sent to " + $scope.premCalcScrnDataInPreRes.mobileNumber + " & " + $scope.premCalcScrnDataInPreRes.emailID);
						}

					} else {
						CommonServices.showAlert("Error occured, Please try again later.");
					}
				}

			}, function (error) {
				CommonServices.showLoading(false);
				RestServices.handleWebServiceError(error);
			});

	};
	$scope.proceedToAddDetails = function () {

		// Call Relations Service if logged In user is development Officer
		if ($rootScope.stakeCode === "DEVLP-OFF") {
			var relationDetailsGSInput = {
				"userProfile": {
					"userId": CommonServices.getCommonData("userId"),
					"loggedInRole": "SUPERUSER"
				},
				"partyDetails": {
					"partyType": "I"
				}
			};

			var relationDetailsGSResponse = RestServices.postService(RestServices.urlPathsNewPortal.getAgentList, relationDetailsGSInput);
			relationDetailsGSResponse.then(
				function (response) {

					CommonServices.showLoading(false);
					if (response.data.hasOwnProperty('errorMessage')) {
						CommonServices.showLoading(false);
						CommonServices.showAlert(response.data.errorMessage);
					} else {

						CommonServices.setCommonData("relationDetailsOfDevOff", response.data.partyDetailsList);
						//GetSetResponseService.addRelationDetailsGs(response.data.partyDetailsList);
						$state.go('gsAdditionalDetails');
					}


				}, function (error) {
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
				});

		} else {
			$state.go('gsAdditionalDetails');
		}
	};
	$scope.onload();

}]);

agentApp.controller('additionalDetailsCtrlGS', ['$scope', 'RestServices', 'CommonServices', '$state', '$rootScope', 'GetSetResponseService', '$filter',
	function ($scope, RestServices, CommonServices, $state, $rootScope, GetSetResponseService, $filter) {
		//$scope.showAgents = false;
		$rootScope.relationDetailsOfLoggedInDevOff = CommonServices.getCommonData("relationDetailsOfDevOff");
		//console.log($rootScope.relationDetailsOfLoggedInDevOff);
		var jewellaryMaxLength = 5;
		var jewellaryCount = 1;
		$scope.closeIcon = false;
		var applianceCount = 1;
		var applianceMaxLength = 10;
		$scope.closeApplianceIcon = false;
		var televisionCount = 1;
		var televisionMaxLength = 10;
		$scope.closeTelevisionIcon = false;
		var bankandBranchName;
		$scope.agentRequiredObj = {};
		$scope.date = new Date();
		$scope.gstinMsg = "GSTIN";
		$scope.agentRequiredObj.agentRequired = 'no';
		//$scope.jewellery = true;
		/*CR_NP_0880 starts */
		$scope.disablePinCode = true;
		$scope.disableCity = true;
		$scope.stateErr = false;
		/*$scope.countryErr = false;//3712*/
		$scope.pinCodeErr = false;
		$scope.cityErr = false;
		/*CR_MOBL_0054-GS Start */
		$rootScope.polHolRadioClick = false;
		$scope.showFirstSliderGS = true;
		/*CR_MOBL_0054-GS Start */
		if ($rootScope.backNavigationFromSummaryGs == true) {
			$scope.disablePinCode = false;
			// $scope.disableCity = true;
		}
		$scope.gsCoveredBuildingAddress = false;
		$scope.premiseIsOfBank = false;
		/*CR_NP_0880 Ends*/
		$scope.goBack = function () {
			$state.go('gsPremiumResult');
		};

		/*CR 3712 starts
		$scope.isNonIndia = false;
		// $scope.policyDetailsObj.clientNationality ="";
		$scope.onNationalityChange = function(){
			$scope.policyDetailsObj.clientCountry = '';
			if($scope.policyDetailsObj.clientNationality == "NonIndian"){
				$scope.isNonIndia = true;
			}
			else{
				$scope.isNonIndia = false;
			}
		}
		//CR_3712 ends*/

		$scope.goBack = function (type='') {
			$scope.showFirstSliderGS = false;
			$scope.showSecondSliderGS = false;
			$scope.showThirdSliderGS = false;
			$scope.showFourthSliderGS = false;
					
			if (type == 'adBack2') {
				$scope.showFirstSliderGS = true;
			} else if (type == 'adBack3') {
				$scope.showSecondSliderGS = true;
			 } 
			else if (type == 'adBack4') {
				$scope.showThirdSliderGS = true;
			} else {
				if (CommonServices.fromRAForEditQuote === true) {
					navigateBack(1);
				} else {
					$state.go('gsPremiumResult');
				}
			}
		};







		$scope.bankAndBranch = {};

		$scope.twDetailQuoteScreenCtrl = {
			onload: function () {
				// Edited By Rupa
				// setTimeout(function () {
				// 	// $('.gallery').flickity({
				// 	// 	cellAlign: 'left',
				// 	// 	contain: true,
				// 	// 	draggable: false
				// 	// });
				// 	$carousel = $('.gallery').flickity({
				// 		cellAlign: 'left',
				// 		contain: true,
				// 		draggable: false,
				// 		prevNextButtons: false,
				// 		pageDots: false
				// 	});
					
				// 	$scope.sliderNext = function () {
				// 		$carousel.flickity('next');
				// 	}

				// }, 1000);
				
				$scope.sliderNext = function (key) {
					$scope.showFirstSliderGS = false;
					$scope.showSecondSliderGS = false;
					$scope.showThirdSliderGS = false;
					$scope.showFourthSliderGS = false;
					if (key === 'first') $scope.showSecondSliderGS = true;
					if (key === 'second') $scope.showThirdSliderGS = true;
					if (key === 'third') $scope.showFourthSliderGS = true;
				}


				/* /*$scope.detailedQuoteHeaderText = "Vehicle Details";
				$("#detQuoteHeader").text("Vehicle Details");      */

				$scope.sumInsuredJewellery = $rootScope.selectedOptionDomainValuesGs.sumInsuredJewellery;
				$scope.sumInsuredDomestic = $rootScope.selectedOptionDomainValuesGs.sumInsuredDomestic;
				$scope.sumInsuredTV = $rootScope.selectedOptionDomainValuesGs.sumInsuredTV;
				$scope.sumInsuredBurglary = $rootScope.selectedOptionDomainValuesGs.sumInsuredBurglary;
				$scope.sumInsuredFireAlliedPerils = $rootScope.selectedOptionDomainValuesGs.sumInsuredFire;
				$scope.totalSumInsuredofBuilding = $rootScope.totalSumInsuredofBuildingGs;
				$scope.calcPremiumResponseInAddDetailsGS = GetSetResponseService.getCalculatePremiumGS();

				/*CR_MOBL_0054-GS Starts */

				//To Add Jewellery Fields
				$scope.items = [{
					"description": "",
					"weight": "",
					"sumInsured": ""
				}];

				//To Add Appliance Details
				$scope.applianceItems = [{
					"make": "",
					"model": "",
					"yearOfMake": ""
				}];

				//To Add Television/Desktop Details
				$scope.televisionItems = [{
					"make": "",
					"model": "",
					"yearOfMake": ""
				}];


				 if(CommonServices.editQuoteFlag === true){
				 	// Risks
			 	if(CommonServices.grihaSuvidhaObj.risks[0].coverage.jewelleryCover.coverDetails != undefined && CommonServices.grihaSuvidhaObj.risks[0].coverage.jewelleryCover.coverDetails != ""){
				 		$scope.items = CommonServices.grihaSuvidhaObj.risks[0].coverage.jewelleryCover.coverDetails;
				 	}
				 	if(CommonServices.grihaSuvidhaObj.risks[0].coverage.applianceCovers[0].coverDetails != undefined && CommonServices.grihaSuvidhaObj.risks[0].coverage.applianceCovers[0].coverDetails != ""){
				 		$scope.applianceItems = CommonServices.grihaSuvidhaObj.risks[0].coverage.applianceCovers[0].coverDetails;
				 	}
				 	if(CommonServices.grihaSuvidhaObj.risks[0].coverage.applianceCovers[1].coverDetails != undefined && CommonServices.grihaSuvidhaObj.risks[0].coverage.applianceCovers[1].coverDetails != ""){
				 		$scope.televisionItems = CommonServices.grihaSuvidhaObj.risks[0].coverage.applianceCovers[1].coverDetails;
				 	}
					

				 	//building Address Details
				 	if (CommonServices.grihaSuvidhaObj.sameAddrAsBuilding !== undefined && CommonServices.grihaSuvidhaObj.sameAddrAsBuilding !== "") {
				 		$scope.gsCoveredBuildingAddress = CommonServices.grihaSuvidhaObj.sameAddrAsBuilding;
				 		if ($scope.gsCoveredBuildingAddress === "Y") {
				 			$scope.gsCoveredBuildingAddress = true;
				 		}
				 	}
				 	if (CommonServices.grihaSuvidhaObj.addressOfProperty.buildingNoStreet !== undefined && CommonServices.grihaSuvidhaObj.addressOfProperty.buildingNoStreet !== "") {
				 		$scope.gsBuildingNo = CommonServices.grihaSuvidhaObj.addressOfProperty.buildingNoStreet;
				 	}
				 	if (CommonServices.grihaSuvidhaObj.addressOfProperty.locality !== undefined && CommonServices.grihaSuvidhaObj.addressOfProperty.locality !== "") {
				 		$scope.gsBuildingLocality = CommonServices.grihaSuvidhaObj.addressOfProperty.locality;
					}
				 	if (CommonServices.grihaSuvidhaObj.addressOfProperty.pinCode !== undefined && CommonServices.grihaSuvidhaObj.addressOfProperty.pinCode !== "") {
				 		$scope.gsBuildingPinCode = CommonServices.grihaSuvidhaObj.addressOfProperty.pinCode;
				 	}
				 	// Financier Details
				 	if (CommonServices.grihaSuvidhaObj.financierDetails.whetherPremiseHypothecatedToBank !== undefined && CommonServices.grihaSuvidhaObj.financierDetails.whetherPremiseHypothecatedToBank !== "") {
				 		$scope.premiseIsOfBank = CommonServices.grihaSuvidhaObj.financierDetails.whetherPremiseHypothecatedToBank;
				 		if ($scope.premiseIsOfBank === "Y") {
				 			$scope.premiseIsOfBank = true;
				 		}
				 	}
				 	if (CommonServices.grihaSuvidhaObj.financierDetails.nameOfBankNBranch !== undefined && CommonServices.grihaSuvidhaObj.financierDetails.nameOfBankNBranch !== "") {
				 		$scope.bankAndBranch.bankAndBranchName = CommonServices.grihaSuvidhaObj.financierDetails.nameOfBankNBranch;
				 	}

				 	// Added to get Policyholder details and then call state,pincode and city service
					
				 	// $scope.policyDetailsObj.policyHolder = "existingPolicyHolder"; // Hardcoded value just for implementation, change the value while testing.
				// 	$scope.policyDetailsObj.createdParty(CommonServices.grihaSuvidhaObj);

				 }
				/*CR_MOBL_0054-GS Ends*/
			}
		};

		$scope.twDetailQuoteScreenCtrl.onload();
		var index = parseInt($scope.selectedOption);
		$scope.selectedOptionIndex = CommonServices.setCommonData(parseInt($scope.selectedOption));

		//Additional Details Screen
		// //To Add Jewellery Fields
		// $scope.items = [{
		// 	"description": "",
		// 	"weight": "",
		// 	"sumInsured": ""
		// }];

		$scope.addJewelleryItem = function () {
			$scope.closeIcon = true;
			jewellaryCount = jewellaryCount + 1;

			if (jewellaryCount > jewellaryMaxLength) {
				jewellaryCount = jewellaryCount - 1;
				CommonServices.showAlert("You can add upto maximum of 5 jewellery items");
				// alert("You can add upto maximum of 5 jewellery items");
			} else {
				$scope.items.push({
					"description": "",
					"weight": "",
					"sumInsured": ""
				});
			}
		};

		//To Close Jewellery fields
		$scope.removeJewelleryItem = function (index) {
			$scope.items.splice(index, 1);
			jewellaryCount = jewellaryCount - 1;

			if (jewellaryCount === 1) {
				$scope.closeIcon = false;
			} else {
				$scope.closeIcon = true;
			}
		};
		//To Compare entered Jewellery Value with total Jewellery Value
		$scope.compareJewelleryValue = function (index) {
			//var indexString = index.toString();

			if ($scope.items[index].sumInsured < ($scope.sumInsuredJewellery / 10)) {
				$scope.items[index].error = true;
				$scope.jewelleryDetailsForm["jewelleryValue" + index].$setValidity("jewelleryValue", false);
			} else {
				$scope.items[index].error = false;
				$scope.jewelleryDetailsForm["jewelleryValue" + index].$setValidity("jewelleryValue", true);
			}
		};

		// //To Add Appliance Details
		// $scope.applianceItems = [{
		// 	"make": "",
		// 	"model": "",
		// 	"yearOfMake": ""
		// }];

		$scope.addApplianceItem = function () {

			$scope.closeApplianceIcon = true;
			applianceCount = applianceCount + 1;

			if (applianceCount > applianceMaxLength) {
				applianceCount = applianceCount - 1;
				CommonServices.showAlert("You can add upto maximum of 10 appliance details");
			} else {
				$scope.applianceItems.push({
					"make": "",
					"model": "",
					"yearOfMake": ""
				});
			}

		};
		// To remove Appliance details
		$scope.removeApplianceItem = function (index) {

			$scope.applianceItems.splice(index, 1);

			applianceCount = applianceCount - 1;

			if (applianceCount === 1) {
				$scope.closeApplianceIcon = false;
			} else {
				$scope.closeApplianceIcon = true;
			}

		};

		// To verify the appliance year
		var currentYear = $scope.date.getFullYear();

		$scope.aplianceYear = function (index) {
			if ($scope.applianceItems[index].yearOfMake != undefined) {
				if ($scope.applianceItems[index].yearOfMake < 1970 || $scope.applianceItems[index].yearOfMake > currentYear) {
					$scope.applianceItems[index].invalidApplianceYear = true;
					$scope.jewelleryDetailsForm["applianceYear" + index].$setValidity("applianceYear", false);
				} else {
					$scope.applianceItems[index].invalidApplianceYear = false;
					$scope.jewelleryDetailsForm["applianceYear" + index].$setValidity("applianceYear", true);
				}
			}
		};


		// //To Add Television/Desktop Details
		// $scope.televisionItems = [{
		// 	"make": "",
		// 	"model": "",
		// 	"yearOfMake": ""
		// }];

		$scope.addTelevisionItem = function () {

			$scope.closeTelevisionIcon = true;
			televisionCount = televisionCount + 1;

			if (televisionCount > televisionMaxLength) {
				televisionCount = televisionCount - 1;
				CommonServices.showAlert("You can add upto maximum of 10 Television/Desktop details");

				//alert("You can add upto maximum of 10 Television/Desktop details");
			} else {
				$scope.televisionItems.push({
					"make": "",
					"model": "",
					"yearOfMake": ""
				});
			}

		};

		// To remove Television/Desktop details
		$scope.removeTelevisionItem = function (index) {

			$scope.televisionItems.splice(index, 1);

			televisionCount = televisionCount - 1;

			if (televisionCount === 1) {
				$scope.closeTelevisionIcon = false;
			} else {
				$scope.closeTelevisionIcon = true;
			}

		};

		// To verify the year of TV
		var currentYearTV = $scope.date.getFullYear();

		$scope.telvisionYear = function (index) {
			if ($scope.televisionItems[index].yearOfMake != undefined) {
				if ($scope.televisionItems[index].yearOfMake < 1970 || $scope.televisionItems[index].yearOfMake > currentYearTV) {
					$scope.televisionItems[index].invalidTelevisionYear = true;
					$scope.jewelleryDetailsForm["televisionYear" + index].$setValidity("televisionYear", false);
				} else {
					$scope.televisionItems[index].invalidTelevisionYear = false;
					$scope.jewelleryDetailsForm["televisionYear" + index].$setValidity("televisionYear", true);
				}
			}
		};


		$scope.pinCodeModal = false;
		/*Added for CR_NP_0744*/
		$scope.regexPanNo = regexPanNoGlobal;//CR3746
		$scope.regexAadhaarInput = /^(?!\1+$)\d{4}$/;
		$scope.regexAadhaarNumber = /^(?!\1+$)\d{12}$/;
		$scope.isNIAPAN = false;//CR3746
		/*CR_NP_0744 ends*/
		var mydateStr = new Date();
		var mynewdateFrom = "";
		if (mydateStr != undefined) {
			mynewdateFrom = new Date(mydateStr);
		}
		else {
			mynewdateFrom = new Date();
		}

		//CR3746
		$scope.onPANNoChange = function () {
			if($scope.policyDetailsObj.panNo != undefined){
				$scope.policyDetailsObj.panNo = $scope.policyDetailsObj.panNo.toUpperCase();
				$scope.isNIAPAN = isNIAPANNo($scope.policyDetailsObj.panNo);
			}
			else
				$scope.isNIAPAN = false;
		};
		//CR3746

		/*Added for CR_NP_0744*/
		var configurationData = CommonServices.getCommonData("ConfigurationData");
		if (configurationData != undefined && configurationData != '') {
			if (configurationData[0].value == "Y") {
				$scope.isPanNumberMandatory = true;
			} else {
				$scope.isPanNumberMandatory = false;
			}
		}
		/*CR_NP_0744 Changes ends*/


		/**Date of Birth**/
		var dateOfBirthfrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 100));
		dateOfBirthfrom = new Date(dateOfBirthfrom.setDate(dateOfBirthfrom.getDate() + 1));
		dateOfBirthfrom = getFormattedDate(dateOfBirthfrom);

		var dateOfBirthTo = new Date(new Date().setMonth(mynewdateFrom.getMonth()));
		dateOfBirthTo = new Date(dateOfBirthTo.setDate(dateOfBirthTo.getDate()));
		dateOfBirthTo = getFormattedDate(dateOfBirthTo);
		/**Date of Birth**/


		$('#dateOfBirth').loadCalendar({
			'enableDateRange': true,
			'enableCalendarFrom': dateOfBirthfrom,
			'enableCalendarTo': dateOfBirthTo
		});

		$scope.policyDetailsObj = {
			newcustomerFlag: true,
			existingCustomerFlag: false,
			policyHolder: "newPolicyHolder",
			category: "I",
			showSearchResTbl: false,
			noRecords: null,
			showSmallTbl: false,
			fieldDisable: false,
			existingCustomerBtn: true,
			dateOfBirthErr: false,
			gstRegTypeVal: [{
				id: "NCC",
				name: "Normal,Composite,Casual"
			}, {
				id: "NRI",
				name: "NRI"
			}, {
				id: "UNB",
				name: "UN Bodies/Embassy"
			}],
			dateOfBirthFunc: function () {
				//Entered DOB
				var dt1 = this.dateOfBirth.split('/');
				birthDateComp = dt1[1] + '/' + dt1[0] + '/' + dt1[2]; //mm/dd/yyyy
				birthDateComp = new Date(birthDateComp);
				//Current date
				var dateOfBirthfrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 18));

				if (birthDateComp > dateOfBirthfrom) {
					this.dateOfBirthErr = true;
					$scope.policyDetailsObj.dateOfBirth = "";
				}
				else {
					this.dateOfBirthErr = false;
				}
			},

			policyHolderFunc: function (data) {
				this.fieldDisable = false;
				this.existingCustomerBtn = true;
				this.showSmallTbl = false;
				this.showSearchResTbl = false;
				/*CR_MOBL_0054-GS Start */
				$rootScope.polHolRadioClick = true;
				/*CR_MOBL_0054-GS Ends*/
				$scope.invalidPolicyHolderForm = false;
				if ($scope.gsCoveredBuildingAddress === true) {
					$scope.gsCoveredBuildingAddress = false;
					$scope.gsBuildingNo = "";
					$scope.gsBuildingLocality = "";
					$scope.gsBuildingPinCode = "";
				}
				if (data === "existingPolicyHolder") {
					this.existingCustomerFlag = true;
					this.newcustomerFlag = false;
					this.partyCode = "";
					this.EfirstName = "";
					this.ElastName = "";
					this.EmobileNumber = "";
					this.EemailID = "";
					// Added as Form is getting valid on select of existingPolicyHolder button
					$scope.invalidPolicyHolderForm = true;
				}
				else if (data === "newPolicyHolder") {
					$scope.partyCode = "";
					/*Added for CR_NP_0744, aadhaar commented for CR_NP_0744E*/
					this.panNoInputDisable = false;
					CommonServices.panNoInputDisable = false;
					/*CR_NP_0744 and CR_NP_0744E Ends*/
					this.newcustomerFlag = true;
					this.existingCustomerFlag = false;
					this.productTitle = "";
					this.firstName = "";
					this.middleName = "";
					this.lastName = "";
					this.gender = "";
					this.dateOfBirth = "";
					/*
					this.clientNationality ="";//3712
					this.clientCountry = "";//3712
					*/
					this.street = "";
					this.locality = "";
					this.placeOfLoss = "";
					this.mobileNumber = "";
					this.landlineNumber = "";
					this.emailID = "";
					this.panNo = "";
					/*Added for CR_NP_0744*/
					this.aadhaarNumber1 = "";
					this.aadhaarNumber2 = "";
					this.aadhaarNumber3 = "";
					/*CR_NP_0744 Ends*/
					this.accountNo = "";
					this.gstRegID = "";
					this.gstINModel = "";
					this.uinModel = "";
					this.contState = "";
					this.countryCity = "";
				}
			},

			gstIDInputChangeFunc: function () { // Onchange of GSTIN input field
				if (this.gstRegID !== undefined && this.gstRegID !== "") {

					var reg = "";

					if (this.gstINModel != undefined && this.gstINModel === 15) {
						$scope.policyHolderForm.gstIN.$invalid = false;
						$scope.policyHolderForm.$invalid = false;
					}
					else {
						$scope.policyHolderForm.gstIN.$invalid = true;
						$scope.policyHolderForm.$invalid = true;
					}

					if (this.gstRegID === "NCC") {
						reg = regexGSTidGlobal;///^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[A-Z0-9]{2}[^\s]$/;

						//UC for 3749
							// if(CommonServices.gstIdStateCode[this.gstINModel.slice(0,2)] != undefined){
							// 	if($scope.policyDetailsObj.contState.state == CommonServices.gstIdStateCode[this.gstINModel.slice(0,2)]){
							// 	$scope.policyHolderForm.gstIN.$setValidity("gstStateCode", true);
							// 	console.log("state code valid");
							// }
							// 	else{
							// 	$scope.policyHolderForm.gstIN.$setValidity("gstStateCode", false);
							// 	$scope.gstErrorMsg = "Please enter valid GSTIN. State code of GSTIN and the state mentioned in address should match.";	
							// 	}
							// }
							// else{
							// $scope.policyHolderForm.gstIN.$setValidity("gstStateCode", false);
							// $scope.gstErrorMsg = "Please enter GSTIN with a valid state code";
							// }
						}
						
					if (this.gstRegID === "NRI") {
						reg = /^[0-9]{12}N[A-Z0-9]{1}T$/;
					}
					if (this.gstRegID === "UNB") {
						reg = /^[0-9]{12}U[A-Z0-9]{1}N$/;
					}

					if (this.gstINModel !== "" || this.gstINModel !== undefined) {
						if (reg === "")
							valid = false;
						else
							valid = reg.test(this.gstINModel.toUpperCase());
					}

					if (this.gstRegID !== undefined && this.gstRegID !== "") {
						$scope.policyHolderForm.$invalid = false;
					}
					else {
						$scope.policyHolderForm.$invalid = true;
					}

					if (valid) {
						$scope.policyHolderForm.gstIN.$setValidity("gstinPattern", true);
						$scope.policyHolderForm.gstIN.$invalid = false;
						$scope.policyHolderForm.$invalid = false;
						$scope.policyHolderForm.gstIN.$setValidity("gstIN", true);
					} else {
						$scope.policyHolderForm.gstIN.$setValidity("gstinPattern", false);
						$scope.policyHolderForm.gstIN.$invalid = true;
						$scope.policyHolderForm.$invalid = true;
						$scope.policyHolderForm.gstIN.$setValidity("gstIN", false);
					}

					// ADDED BY HIMANSHU FOR CR_875
					if (this.gstRegID != undefined && this.gstRegID != '') {
						if (this.gstINModel != undefined) {
							this.gstINModel = this.gstINModel.toUpperCase();
							if (this.gstINModel.includes("AAACN4165C")) {
								$scope.policyHolderForm.gstIN.$setValidity("validateNIAPAN", false);
								$scope.policyHolderForm.$invalid = true;
							} else {
								$scope.policyHolderForm.gstIN.$setValidity("validateNIAPAN", true);
								$scope.policyHolderForm.$invalid = false;

							}
						}
					}

				}

			},
			uinInputChangeFunc: function () { // Onchange of UIN input field
				if (this.uinModel.length === 15) {
					$scope.policyHolderForm.UIN.$invalid = false;
				}
				else {
					$scope.policyHolderForm.UIN.$invalid = true;
				}
			},
			stateServiceCall: function () {// this function is service call for getting state 
				this.stateResponse = RestServices.postService(RestServices.urlPathsNewPortal.getStateList, $scope.stateData);
				return this.stateResponse.then(
					function (response) { // success

						CommonServices.showLoading(false);
						if (response.data.states !== undefined && response.data.states !== "") {
							/*CR_NP_0880 and CR_MOBL_0054-GS Starts */
							if (CommonServices.editQuoteFlag === true && ($rootScope.backNavigationFromSummaryGs == false || $rootScope.backNavigationFromSummaryGs === undefined) && $rootScope.polHolRadioClick === false) {

								console.log($rootScope.policyHolderDataGs);

								for (var i = 0; i < response.data.states.length; i++) {
									if ($rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.state === response.data.states[i].stateCode) {
										$scope.policyDetailsObj.contState = response.data.states[i];
										$rootScope.policyHolderStateIs = response.data.states[i];

										$scope.stateObj = {
											"stateObj": response.data.states[i]
										}
										angular.extend($rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails, $scope.stateObj);

										$scope.searchPincode = { "state": $scope.policyDetailsObj.contState.state, "zipCode": "" };
										$scope.policyDetailsObj.pinCodeServiceCall();
										
										$rootScope.invalidSPCErr = false;
										$scope.policyHolderForm.$invalid = false;
										// $scope.policyHolderForm.$setValidity("$invalid", false);
										return;
									} else {
										$rootScope.invalidSPCErr = true;
										$scope.policyHolderForm.$invalid = true;
										// $scope.policyHolderForm.$setValidity("$invalid", true);
									}
								}
								$scope.stateList = response.data.states;
							} /*CR_MOBL_0054-GS Ends */
							else if ($scope.partyCode !== "" && $scope.partyCode !== undefined) {// if the customer is existing customer																
								response.data.states.filter(function (b) {//this filter will compare the responseState with the response data
									if ($scope.responseState !== "" && $scope.responseState !== undefined && b.stateCode === $scope.responseState) {
										$scope.policyDetailsObj.contState = b;
										$rootScope.policyHolderStateIs = b;
										$scope.responseState = "";
										$scope.searchPincode = { "state": $scope.policyDetailsObj.contState.state, "zipCode": "" };
										$scope.policyDetailsObj.pinCodeServiceCall();
										
										$rootScope.invalidSPCErr = false;
										$scope.policyHolderForm.$invalid = false;
										// $scope.policyHolderForm.$setValidity("$invalid", false);
										return;
									} else {
										$rootScope.invalidSPCErr = true;
										$scope.policyHolderForm.$invalid = true;
										// $scope.policyHolderForm.$setValidity("$invalid", true);
									}

								});
								$scope.stateList = response.data.states;
							}
							else {// if the customer is new customer
								if ($scope.continueState !== "" && $scope.continueState !== undefined) {
									response.data.states.filter(function (b) {
										if (b.stateCode === $scope.continueState) {
											$scope.stateObj = {
												"stateObj": b
											}
										}
									});

									angular.extend($rootScope.policyHolderDataGs.savedPartyDetails.partyDetails, $scope.stateObj);
									if ($scope.stateObj !== undefined && $scope.stateObj !== "") {
										$scope.continueState = "";
										$scope.cityData = { "state": $scope.stateObj.stateObj.state, "zipCode": $scope.continuepinCode, "city": "" };
										$scope.policyDetailsObj.cityServiceCall();
									}
									else {
										CommonServices.showAlert("Please change the state you have entered.");
									}

								}
								$scope.stateData = "";
								$scope.stateList = response.data.states;
							}
							return $scope.stateList;
						} else {
							if (response.data.errorMessage !== undefined && response.data.errorMessage !== "")
								CommonServices.showAlert(response.data.errorMessage);
							else
								// CommonServices.showAlert("No Record Found");
								CommonServices.showAlert("Error Occured. Please try again later");
						}
					},
					function (error) { // failure
						CommonServices.showLoading(false);
						RestServices.handleWebServiceError(error);
					});
				/* CR_NP_0880 ends*/

			},
			pinCodeServiceCall: function () { // this function is service call for getting pincodes
				this.getZipcodeDetailResponse = RestServices.postService(RestServices.urlPathsNewPortal.getZipCodesbyState, $scope.searchPincode);
				return this.getZipcodeDetailResponse.then(
					function (response) { // success 
						/* CR_NP_0880 Starts*/
						CommonServices.showLoading(false);
						if (response.data.pincodes !== undefined && response.data.pincodes !== "") {
							/*CR_MOBL_0054-GS Starts */
							if (CommonServices.editQuoteFlag === true && ($rootScope.backNavigationFromSummaryGs == false || $rootScope.backNavigationFromSummaryGs === undefined) && $rootScope.polHolRadioClick === false) {

								console.log($rootScope.policyHolderDataGs);

								for (var i = 0; i < response.data.pincodes.length; i++) {
									if ($rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.pinCode === response.data.pincodes[i]) {
										$scope.policyDetailsObj.placeOfLoss = response.data.pincodes[i];
										$scope.cityData = { "state": ($scope.policyDetailsObj.contState.state === undefined) ? $scope.policyDetailsObj.contState : $scope.policyDetailsObj.contState.state, "zipCode": $scope.policyDetailsObj.placeOfLoss, "city": "" };
										$scope.policyDetailsObj.cityServiceCall();

										$rootScope.invalidSPCErr = false;
										$scope.policyHolderForm.$invalid = false;
										$scope.disablePinCode = true;
										// $scope.policyHolderForm.$setValidity("$invalid", false);
										return;
									} else {
										$rootScope.invalidSPCErr = true;
										$scope.policyHolderForm.$invalid = true;
										$scope.disablePinCode = false;
										// $scope.policyHolderForm.$setValidity("$invalid", true);
									}
								}
								$scope.pinCodesList = response.data.pincodes;
							} /*CR_MOBL_0054-GS Ends */

							else if ($scope.partyCode !== "" && $scope.partyCode !== undefined) { // if the cutomer is existing customer

								response.data.pincodes.filter(function (b) {//this filter will compare the responsepinCode with the response data
									if ($scope.responsepinCode !== "" && $scope.responsepinCode !== undefined && b === $scope.responsepinCode) {
										$scope.policyDetailsObj.placeOfLoss = b;
										$scope.responsepinCode = "";
										$scope.cityData = { "state": ($scope.policyDetailsObj.contState.state === undefined) ? $scope.policyDetailsObj.contState : $scope.policyDetailsObj.contState.state, "zipCode": $scope.policyDetailsObj.placeOfLoss, "city": "" };
										$scope.policyDetailsObj.cityServiceCall();

										$rootScope.invalidSPCErr = false;
										$scope.policyHolderForm.$invalid = false;
										$scope.disablePinCode = true;
										// $scope.policyHolderForm.$setValidity("$invalid", false);
										return;
									} else {
										$rootScope.invalidSPCErr = true;
										$scope.policyHolderForm.$invalid = true;
										$scope.disablePinCode = false;
										// $scope.policyHolderForm.$setValidity("$invalid", true);
									}
								});
								$scope.pinCodesList = response.data.pincodes;
								$scope.pinCodeResponseArray = response.data.pincodes;

								var pincodeMatchList = [];
								for (var i = 0; i < $scope.pinCodesList.length; i++) {
									if ($scope.pinCodesList[i].match($scope.searchPincode.zipCode)) {
										pincodeMatchList.push($scope.pinCodesList[i]);
									}
								}
								return $scope.pinCodesList = pincodeMatchList;
							} else {// if the customer is new customer
								$scope.searchPincode = "";
								$scope.pinCodesList = response.data.pincodes;
								$scope.pinCodeResponseArray = response.data.pincodes;
							}
							return $scope.pinCodesList;

						} else {
							if (response.data.errorMessage !== undefined && response.data.errorMessage !== "")
								CommonServices.showAlert(response.data.errorMessage);
							else
								// CommonServices.showAlert("Presently our services are not available. Please try after some time");
								CommonServices.showAlert("Error Occured. Please try again later");
						}
					},
					function (error) { // failure
						CommonServices.showLoading(false);
						RestServices.handleWebServiceError(error);
					});
				/* CR_NP_0880 ends*/
			},
			cityServiceCall: function () {// this function is service call for getting city
				this.cityResponse = RestServices.postService(RestServices.urlPathsNewPortal.getCitiesList, $scope.cityData);
				return this.cityResponse.then(
					function (response) { // success 

						CommonServices.showLoading(false);
						if (response.data.cities !== undefined && response.data.cities !== "") {

							/*CR_NP_0880 and CR_MOBL_0054-GS Starts */
							if (CommonServices.editQuoteFlag === true && ($rootScope.backNavigationFromSummaryGs == false || $rootScope.backNavigationFromSummaryGs === undefined) && $rootScope.polHolRadioClick === false) {

								console.log($rootScope.policyHolderDataGs);
								$scope.cityObj = { "cityObj": response.data.cities[0] }
								angular.extend($rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails, $scope.cityObj);

								$scope.policyDetailsObj.countryCity = response.data.cities[0];
								$rootScope.policyHolderCityIs = response.data.cities[0];
								$scope.cityList = response.data.cities;
								
								$rootScope.invalidSPCErr = false;
								$scope.policyHolderForm.$invalid = false;
                return;
							} /*CR_MOBL_0054-GS Ends */

							else if ($scope.partyCode !== "" && $scope.partyCode !== undefined) {// if the customer is existing customer

								response.data.cities.filter(function (b) { //this filter will compare the responseCity with the response data
									if ($scope.responseCity !== "" && $scope.responseCity !== undefined && b.cityCode === $scope.responseCity) {
										$scope.policyDetailsObj.countryCity = b;
										$rootScope.policyHolderCityIs = b;
										$scope.responseCity = "";
			
										// $scope.searchPincode = {"state":$scope.policyDetailsObj.contState.state,"city":$scope.policyDetailsObj.countryCity.city,"zipCode":""};
										// $scope.policyDetailsObj.pinCodeServiceCall();
									}
								});
								$scope.policyDetailsObj.countryCity = response.data.cities[0];
								$scope.cityList = response.data.cities;
								$rootScope.invalidSPCErr = false;
								$scope.policyHolderForm.$invalid = false;
								return;
							}
							else {// if the customer is new customer
								if ($scope.continueCity !== "" && $scope.continueCity !== undefined) {
									response.data.cities.filter(function (b) { //this filter will compare the responseCity with the response data
										if (b.cityCode === $scope.continueCity) {
											$scope.cityObj = {
												"cityObj": b
											}
										}
										angular.extend($rootScope.policyHolderDataGs.savedPartyDetails.partyDetails, $scope.cityObj);
									});
									if ($rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.stateObj !== undefined && $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.stateObj !== "" && $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.cityObj !== undefined && $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.cityObj !== "") {
										$scope.continueCity = "";
										//$state.go("businessHolidays.travellerDetails");
									}

								}
								$scope.cityData = "";
								$scope.policyDetailsObj.countryCity = response.data.cities[0];
								$scope.cityList = response.data.cities;
							}
							return $scope.cityList;
						} else {
							if (response.data.errorMessage !== undefined && response.data.errorMessage !== "")
								CommonServices.showAlert(response.data.errorMessage);
							else
								CommonServices.showAlert("Error Occured. Please try again later");
						}
					},
					function (error) { // failure
						CommonServices.showLoading(false);
						RestServices.handleWebServiceError(error);
					});
				/* CR_NP_0880 ends*/
			},

			gstFunc: function (obj, data) { // This function has the service call for getting StateList and CityList
				/*CR_NP_0880 starts */
				// $scope.policyHolderForm.$invalid = true;
				if (data === "state") { // This will give list of states
					this.placeOfLoss = "";
					this.countryCity = "";
					$scope.disablePinCode = true;
					// $scope.disableCity = true;
					$scope.stateErr = true;
					$scope.pinCodeErr = false;
					$scope.cityErr = false;

					// $scope.policyHolderForm.countryState.$invalid = true; // Commented during CR_NP_0880
					if (obj.length === 3) { // When entered value is of 3 digit
						$scope.stateData = { "state": obj.toUpperCase() };
						return this.stateServiceCall();
					} else {  // When entered value is more than 3 digit 
						if (obj.length > 3) {
							return ($filter('filter')($scope.stateList, { state: obj }));
						} else {
							$scope.stateList = {};
							return $scope.stateList;
						}

					}
				}

				if (data === 'pinCode') {
					$scope.pinCodeErr = true;
					$scope.cityErr = false;
					// $scope.disableCity = true;
					this.countryCity = "";

					if ($scope.pinCodeResponseArray != undefined && $scope.pinCodeResponseArray != "") {
						var matchList = [];
						$scope.pinCodesList = $scope.pinCodeResponseArray;
						for (var i = 0; i < $scope.pinCodesList.length; i++) {
							if ($scope.pinCodesList[i].match(obj)) {
								matchList.push($scope.pinCodesList[i]);
							}
						}
						return $scope.pinCodesList = matchList;
					} else {
						$scope.searchPincode = { "state": this.contState.state === undefined ? this.contState.toUpperCase() : this.contState.state.toUpperCase(), "zipCode": obj };
						return this.pinCodeServiceCall();
					}
				}

				if (data === "city") { // This will give list of cities
					$scope.cityErr = true;
					if (obj.length === 1) { // When entered value is of 1 digit
						$scope.cityData = { "state": this.contState.state === undefined ? this.contState.toUpperCase() : this.contState.state.toUpperCase(), "zipCode": this.placeOfLoss, "city": obj.toUpperCase() };
						return this.cityServiceCall();
					}
					else { // When entered value is more than 1 digit
						if ($scope.cityList != undefined && $scope.cityList != "") { // if cities list is available
							return ($filter('filter')($scope.cityList, { city: obj }));
						} else {
							$scope.cityData = { "state": this.contState.state === undefined ? this.contState.toUpperCase() : this.contState.state.toUpperCase(), "zipCode": this.placeOfLoss, "city": obj.toUpperCase() };
							return this.cityServiceCall();
						}
					}
				}
				/*CR_NP_0880 Ends */
				/*3712 Starts////////
				if (data === "country"){
					$scope.countryErr = true;
					if (obj.length === 3) { // When entered value is of 3 digit
						$scope.stateData = { "state": obj.toUpperCase() };
						return this.stateServiceCall();
					} else {  // When entered value is more than 3 digit 
						if (obj.length > 3) {
							return ($filter('filter')($scope.stateList, { state: obj }));
						} else {
							$scope.stateList = {};
							return $scope.stateList;
						}
					}
				}
				/// 3712 ends//////*/
			},
			/* 3712 starts
			onSelectCountry: function ($item, $model, $label) {// onchange of state input field//3712
				console.log($item);
				$scope.countryErr = false;
			},
			// 3712 ends */
			onSelectState: function ($item, $model, $label) {// onchange of state input field
				/*CR_NP_0880 starts */
				$scope.stateErr = false;
				$scope.pinCodeErr = true;
				$scope.cityErr = false;
				$scope.disablePinCode = false;
				// $scope.disableCity = true;

				$scope.policyDetailsObj.placeOfLoss = "";
				$scope.policyDetailsObj.countryCity = "";
				$scope.pinCodeResponseArray = ""; // To make Pincode response list empty
//UC for 3749
				// angular.forEach(CommonServices.gstIdStateCode,function(value,key){
				// 	if($scope.policyDetailsObj.contState.state == value){
				// 		$scope.gstinMsg = "GSTIN should start with "+key;
				// 	}
	
				// });

				// $scope.policyDetailsObj.gstIDInputChangeFunc();
			},
			onSelectPinCode: function ($item, $model, $label) {// onchange of pincode input field
				$scope.pinCodeErr = false;
				$scope.cityErr = false;
				// $scope.disableCity = true;

				$scope.cityData = { "state": ($scope.policyDetailsObj.contState.state === undefined) ? $scope.policyDetailsObj.contState.toUpperCase() : $scope.policyDetailsObj.contState.state.toUpperCase(), "zipCode": $scope.policyDetailsObj.placeOfLoss, "city": "" };
				return this.cityServiceCall();
			},
			onSelectCity: function ($item, $model, $label) {// onchange of city input field
				$scope.policyHolderForm.$invalid = false;
				$scope.cityErr = false;
			},
			/*CR_NP_0880 Ends */

			selectGstIDFunct: function (data) { // This function will validate the GSTIN values according to the changes in GSTID Type values


				if (this.gstRegID == '' || this.gstRegID == undefined) {
					this.gstINModel = "";
					$scope.policyHolderForm.gstIN.$setValidity("validateNIAPAN", true);
					$scope.policyHolderForm.gstIN.$setValidity("gstinPattern", true);
					$scope.policyHolderForm.gstIN.$invalid = false;
					$scope.policyHolderForm.$invalid = false;
					$scope.policyDetailsObj.uinModel = '';

				}

				var reg = "";

				if (this.gstINModel !== "" && this.gstINModel !== undefined) {
					if (this.gstINModel.length === 15) {
						$scope.policyHolderForm.gstIN.$invalid = false;
						$scope.policyHolderForm.$invalid = false;
					}
				}
				else {
					$scope.policyHolderForm.gstIN.$invalid = true;
					$scope.policyHolderForm.$invalid = true;
				}
				if (this.gstRegID === "NCC") {
					reg = regexGSTidGlobal;///^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[A-Z0-9]{2}[^\s]$/;
				}
				if (this.gstRegID === "NRI") {
					reg = /^[0-9]{12}N[A-Z0-9]{1}T$/;
					// $scope.policyHolderForm.gstIN.$setValidity("gstStateCode", true);//UC for 3749
				}
				if (this.gstRegID === "UNB") {
					reg = /^[0-9]{12}U[A-Z0-9]{1}N$/;
					// $scope.policyHolderForm.gstIN.$setValidity("gstStateCode", true);//UC for 3749
				}

				var valid = "";

				if (this.gstINModel !== "" || this.gstINModel !== undefined) {
					if (reg === "") {
						valid = true;
					}
					else {
						if (this.gstINModel !== undefined && this.gstINModel !== "") {
							valid = reg.test(this.gstINModel.toUpperCase());
						}
					}

				}

				if (!valid) {
					$scope.policyHolderForm.gstIN.$setValidity("gstIN", false);
					$scope.policyHolderForm.$invalid = true;
					$scope.policyHolderForm.gstIN.$invalid = true;
				}
				else {
					$scope.policyHolderForm.gstIN.$setValidity("gstIN", true);
					$scope.policyHolderForm.$invalid = false;
					$scope.policyHolderForm.gstIN.$invalid = false;
				}

			},
			saveDetails: function (data) { // On click of Create in Policy Holder Information screen

				/*Added for CR_NP_0744*/
				if (this.aadhaarNumber1 != undefined && this.aadhaarNumber1 != '' && this.aadhaarNumber2 != undefined && this.aadhaarNumber2 != '' && this.aadhaarNumber3 != undefined && this.aadhaarNumber3 != '') {
					$scope.policyDetailsObj.aadhaarNumber = this.aadhaarNumber1 + this.aadhaarNumber2 + this.aadhaarNumber3;
				} else {
					$scope.policyDetailsObj.aadhaarNumber = "";
				}

				var policyHolderDataGs = {
					"userProfile": { "userId": CommonServices.getCommonData("userId"), "loggedInRole": "SUPERUSER" },
					"partyDetails": {
						"individualDetails": {
							"firstName": this.firstName !== undefined ? this.firstName.toUpperCase() : "",
							"lastName": this.lastName !== undefined ? this.lastName.toUpperCase() : "",
							"middleName": this.middleName !== undefined ? this.middleName.toUpperCase() : "",
							"gender": this.gender,
							"dateOfBirth": this.dateOfBirth,
							/*
							"clientNationality": this.clientNationality,//3712
							"clientCountryObj": this.clientCountry,//3712
							"clientCountry": this.clientCountry.stateCode,//3712
							*/
							"buildingNoStreet": this.street !== undefined ? this.street.toUpperCase() : "",
							"pinCode": this.placeOfLoss, //CR_NP_0880
							"mobileNo": this.mobileNumber,
							"emailId": this.emailID,
							"panNumber": this.panNo !== undefined ? this.panNo.toUpperCase() : "",
							"aadhaarNo": $scope.policyDetailsObj.aadhaarNumber,
							"gstRegIdType": this.gstRegID,
							"gstin": this.gstINModel !== undefined ? this.gstINModel.toUpperCase() : "",
							"uin": this.uinModel !== undefined ? this.uinModel.toUpperCase() : "",
							"cityObj": this.countryCity,
							"stateObj": this.contState,
							"state": this.contState.stateCode,
							"city": this.countryCity.cityCode,
							"eInsuranceAccountNo": this.accountNo
						},
						"partyType": this.category
					}
				};
				/*Changes for CR_NP_0744 ends*/

				var policyHolderResponse = RestServices.postService(RestServices.urlPathsNewPortal.createPolicyHolderTW, policyHolderDataGs);
				policyHolderResponse.then(
					function (response) { // success 

						/* 3712 Starts //////
						if (response.data.partyDetails.individualDetails.clientCountry === undefined) {
							response.data.partyDetails.individualDetails.clientCountry = 'GA';
						}
						if (response.data.partyDetails.individualDetails.clientNationality === undefined) {
							response.data.partyDetails.individualDetails.clientNationality = 'NonIndian';
						}
						// 3712 ends */
						CommonServices.showLoading(false);
						if (response.data.partyDetails !== undefined) {
							CommonServices.showAlert("Policy details has been successfully submitted. Your Party Code is #" + response.data.partyDetails.partyCode);
							//alert("Policy details has been successfully submitted. Your Party Code is #" + response.data.partyDetails.partyCode);
							var otherData = {
								policyHolder: this.policyHolder
							};
							/*CR_MOBL_0054-GS Starts */
							if (CommonServices.editQuoteFlag === true && $rootScope.backNavigationFromSummaryGs === false) {
								$rootScope.policyHolderDataGs = {};
							}
							/*CR_MOBL_0054-GS Ends*/
							var partyDetails = { "savedPartyDetails": { "partyDetails": policyHolderDataGs.partyDetails } };
							partyDetails.savedPartyDetails.partyDetails.locality = otherData.locality;
							partyDetails.savedPartyDetails.partyDetails.policyHolder = otherData.policyHolder;
							partyDetails.savedPartyDetails.partyDetails.partyCode = response.data.partyDetails.partyCode;
							angular.extend($rootScope.policyHolderDataGs, partyDetails);
							/*CR_MOBL_0054-GS Start */
							if (CommonServices.editQuoteFlag === true && $rootScope.backNavigationFromSummaryGs === false) {
								$scope.policyDetailsObj.createdParty($rootScope.policyHolderDataGs);
							} else {
								$scope.policyDetailsObj.createdParty();
							}
							/*CR_MOBL_0054-GS Ends */

						} else {
							CommonServices.showAlert(response.data.errorMessage);
							//alert(response.data.errorMessage);
						}
					},
					function (error) { // failure
						CommonServices.showLoading(false);
						RestServices.handleWebServiceError(error);
					});
			},
			createdParty: function (item) { //This is to get policy holder details
				/* CR_NP_594A starts*/
				$scope.dateOfBirthEmpty = false;
				/* CR_NP_594A ends*/
				
				/*CR_MOBL_0054-GS Starts */
				// if(CommonServices.editQuoteFlag === true && $rootScope.backNavigationFromSummaryGs == undefined){ // Edit Quote New flow
				// 	$scope.policyHolderDataGs = {
				// 			"userProfile": {
				// 				"userId": CommonServices.getCommonData("userId"),
				// 				"loggedInRole": "SUPERUSER"
				// 			}, "partyDetails": { "partyCode": item.savedPartyDetails.partyDetails.partyCode }
				// 		};
				// 		$scope.partyCode = item.quote.policyHolderCode;
				// }
				if (CommonServices.editQuoteFlag === true && ($rootScope.backNavigationFromSummaryGs === false || $rootScope.backNavigationFromSummaryGs === undefined) && $rootScope.polHolRadioClick === false) { // Edit Quote from Summary
					$scope.policyHolderDataGs = {
						"userProfile": {
							"userId": CommonServices.getCommonData("userId"),
							"loggedInRole": "SUPERUSER"
						}, "partyDetails": { "partyCode": item.partyDetailsList[0].partyCode }
					};
					$scope.partyCode = item.policyHolderCode;
				} else {
					if (this.policyHolder === "existingPolicyHolder") {
						$scope.policyHolderDataGs = {
							"userProfile": {
								"userId": CommonServices.getCommonData("userId"),
								"loggedInRole": "SUPERUSER"
							}, "partyDetails": { "partyCode": item.partyCode }
						};
						$scope.partyCode = item.partyCode;
					}
					else {
						$rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.policyHolder = this.policyHolder;
						$scope.policyHolderDataGs = {
							"userProfile": {
								"userId": CommonServices.getCommonData("userId"),
								"loggedInRole": "SUPERUSER"
							}, "partyDetails": { "partyCode": $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.partyCode }
						};
					}
				}
				/*CR_MOBL_0054-GS Ends*/


				var policyHolderResponse = RestServices.postService(RestServices.urlPathsNewPortal.getPolicyHolderDetail, $scope.policyHolderDataGs);
				policyHolderResponse.then(
					function (response) { // success 
						$scope.partyresponse = '';
						CommonServices.showLoading(false);
						$scope.policyDetailsObj.showSearchResTbl = true;
						if (response.data.partyDetails !== undefined) {
							/*Added for CR_NP_0744, CR_NP_0744E starts*/
							if ($scope.policyDetailsObj.policyHolder === "existingPolicyHolder") {
								//To set the initial value of PAN and Aadhaar Numbers
								if (CommonServices.initialPartyCode != item.partyCode) { //If party code is changed
									CommonServices.initialPanNumberIsEmpty = false;
								}
								CommonServices.initialPartyCode = item.partyCode;
								//For PAN Number
								if (response.data.partyDetails.individualDetails.panNumber != undefined && response.data.partyDetails.individualDetails.panNumber != "" && $scope.regexPanNo.test(response.data.partyDetails.individualDetails.panNumber)) {
									$scope.isNIAPAN = false;
									$scope.policyDetailsObj.panNoInputDisable = true;
									if (CommonServices.initialPanNumberIsEmpty == true) {
										$scope.policyDetailsObj.panNoInputDisable = false;
										
									}
								} else {
									$scope.policyDetailsObj.panNoInputDisable = false;
									CommonServices.initialPanNumberIsEmpty = true;
								}
							} else {
								$scope.policyDetailsObj.panNoInputDisable = false;
								//   $scope.policyDetailsObj.aadhaarInputDisable = false;
							}
							/* CR_NP_594A starts*/
							if (response.data.partyDetails.individualDetails.dateOfBirth === undefined) {
								$scope.dateOfBirthEmpty = true;
							}
							/* CR_NP_594A ends*/
							/*CR_NP_0744 and CR_NP_0744E ends*/
							$scope.policyDetailsObj.showSmallTblFunc();

							/* 3712 Starts
							//Dummy Data added to response
							response.data.partyDetails.individualDetails.clientNationality = "NonIndian";
							response.data.partyDetails.individualDetails.clientCountry = "Ghana";
							// 3712 Ends */

							$scope.showSmallData = response.data.partyDetails;

							// Added as Form is made Invalid on change of existingPolicyHolder button & on tap on delete Icon in small details
							$scope.invalidPolicyHolderForm = false;

							/*CR_MOBL_0054-GS Starts */
							// if (CommonServices.editQuoteFlag === true && $rootScope.backNavigationFromSummaryGs === false) {
							if (CommonServices.editQuoteFlag === true && ($rootScope.backNavigationFromSummaryGs === false || $rootScope.backNavigationFromSummaryGs === undefined) && $rootScope.polHolRadioClick === false) {
								$rootScope.policyHolderDataGs = {};
								var partyDetails = { "savedPartyDetails": { "partyDetails": response.data.partyDetails } };
								angular.extend($rootScope.policyHolderDataGs, partyDetails);
								$scope.showSmallData.partyCode = item.policyHolderCode;
								$rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.policyHolder = $scope.policyDetailsObj.policyHolder;

								CommonServices.setCommonData("partyCode", $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.partyCode);
								 if ($rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.state !== undefined && $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.state !== "") {
								 		$scope.continueState = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.state;
										$scope.continueCity = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.city;
										$scope.continuepinCode = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.pinCode;
									$scope.responseState = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.state;
								 		$scope.responseCity = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.city;
								 		$scope.responsepinCode = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.pinCode;
								 		if ($scope.continueState !== undefined && $scope.continueState !== "") {
								 			$scope.stateData = { "state": "" };
											$scope.policyDetailsObj.stateServiceCall();
									}

									} else {
										CommonServices.showAlert("Please enter State");
								 	}

								$scope.stateData = { "state": "" };
								$scope.policyDetailsObj.stateServiceCall();

								if (CommonServices.grihaSuvidhaObj.addressOfProperty.buildingNoStreet == response.data.partyDetails.individualDetails.buildingNoStreet && CommonServices.grihaSuvidhaObj.addressOfProperty.pinCode == response.data.partyDetails.individualDetails.pinCode) {
									$scope.gsCoveredBuildingAddress = true;
								} else {
									$scope.gsCoveredBuildingAddress = false;
								}

							} else {
								if ($scope.policyDetailsObj.policyHolder === "existingPolicyHolder") {
									var partyDetails = { "savedPartyDetails": { "partyDetails": response.data.partyDetails } };
									angular.extend($rootScope.policyHolderDataGs, partyDetails);
									$scope.showSmallData.partyCode = item.partyCode;
									$rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.policyHolder = $scope.policyDetailsObj.policyHolder;

									//Continue button functions, to call State,City & Pincode service
									CommonServices.setCommonData("partyCode", $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.partyCode);
									if ($rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.state !== undefined && $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.state !== "") {
										$scope.continueState = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.state;
										$scope.continueCity = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.city;
										$scope.continuepinCode = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.pinCode;
										$scope.responseState = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.state;
										$scope.responseCity = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.city;
										$scope.responsepinCode = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.pinCode;
										if ($scope.continueState !== undefined && $scope.continueState !== "") {
											$scope.stateData = { "state": "" };
											$scope.policyDetailsObj.stateServiceCall();
										}

									} else {
										CommonServices.showAlert("Please enter State");
									}
								}
								else {
									$scope.showSmallData.partyCode = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.partyCode;
								}
							}
							angular.extend($rootScope.policyHolderDataGs, $scope.showSmallData);
						} else {
							$scope.policyDetailsObj.noRecords = "No records found";
							//CommonServices.showAlert("Please try again after some time.");
						}
						/*CR_MOBL_0054-GS Ends*/
					},
					function (error) { // failure
						CommonServices.showLoading(false);
						RestServices.handleWebServiceError(error);
					});
			},
			showSmallTblFunc: function () {
				$scope.policyDetailsObj.showSmallTbl = true;
				$scope.policyDetailsObj.showSearchResTbl = false;
				$scope.policyDetailsObj.existingCustomerFlag = false;
				$scope.policyDetailsObj.newcustomerFlag = false;
				//$scope.policyDetailsObj.existingCustomerFlag = false;
				//$scope.policyDetailsObj.policyHolder = "existingPolicyHolder";
			},
			searchDetails: function () {
				if (this.partyCode === '' && this.EfirstName === '' && this.ElastName === '' && this.EmobileNumber === '' && this.EemailID === '') {
					CommonServices.showAlert("Enter atleast 1 input parameters to proceed with the Policy Holder search.");
					return;
				}

				$scope.searchData = {
					"userProfile": { "userId": CommonServices.getCommonData("userId"), "loggedInRole": "SUPERUSER" },
					"partyDetails": {
						"individualDetails": { "firstName": "", "lastName": "", "emailId": "", "mobileNo": "" }, "organizationDetails": {},
						"partyCode": "", "productCode": "GS", "partyType": "I"
					}, "productCode": "GS"
				};


				if (this.partyCode !== undefined) {
					if (this.partyCode !== '') {
						$scope.searchData.partyDetails.partyCode = this.partyCode.toUpperCase();
					}
				}
				if (this.EfirstName !== undefined) {
					if (this.EfirstName !== '') {
						$scope.searchData.partyDetails.individualDetails.firstName = this.EfirstName.toUpperCase();
					}
				}
				if (this.ElastName !== undefined) {
					if (this.ElastName !== '') {
						$scope.searchData.partyDetails.individualDetails.lastName = this.ElastName.toUpperCase();
					}
				}
				if (this.EmobileNumber !== undefined) {
					if (this.EmobileNumber !== '') {
						$scope.searchData.partyDetails.individualDetails.mobileNo = this.EmobileNumber;
					}
				}
				if (this.EemailID !== undefined) {
					if (this.EmobileNumber !== '') {
						$scope.searchData.partyDetails.individualDetails.emailId = this.EemailID;
					}
				}


				var policyHolderResponse = RestServices.postService(RestServices.urlPathsNewPortal.searchPolicyHolderDetails, $scope.searchData);
				policyHolderResponse.then(
					function (response) { // success 

						$scope.partyresponse = '';
						CommonServices.showLoading(false);
						$scope.policyDetailsObj.showSearchResTbl = true;
						if (response.data.partyDetailsList !== undefined) {
							$scope.partyresponse = response.data.partyDetailsList;
							$scope.policyDetailsObj.noRecords = null;
							// angular.extend($rootScope.policyHolderDataGs, partyDetails);
						} else {
							$scope.policyDetailsObj.noRecords = "No records found";
							//CommonServices.showAlert("Please try again after some time.");
						}
					},
					function (error) { // failure
						CommonServices.showLoading(false);
						RestServices.handleWebServiceError(error);
					});

			},
			closePopup: function () {
				$scope.pinCodeModal = false;
			},
			setValue: function (data) { // this is to set values to the input fields at the time of edit 
				/*Added for CR_NP_0744, CR_NP_0744E start*/
				// To set the values on load of the page
				if ($scope.policyDetailsObj.panNoInputDisable == undefined || $scope.policyDetailsObj.panNoInputDisable == "") {
					$scope.policyDetailsObj.panNoInputDisable = CommonServices.panNoInputDisable;
				}
				/*CR_NP_0744 and CR_NP_0744E ends*/
				if($scope.policyHolderForm.gstIN != undefined) {
					$scope.policyHolderForm.gstIN.$invalid = false;
					$scope.policyHolderForm.gstIN.$valid = true;
				}

				var partyDetails = { "savedPartyDetails": { "partyDetails": { "individualDetails": data.individualDetails } } };
				partyDetails.savedPartyDetails.partyDetails.partyCode = data.partyCode;
				partyDetails.savedPartyDetails.partyDetails.policyHolder = this.policyHolder;
				angular.extend($rootScope.policyHolderDataGs, partyDetails);

				if (data.individualDetails.firstName !== undefined && data.individualDetails.firstName !== "")
					this.firstName = data.individualDetails.firstName;
				if (data.individualDetails.middleName !== undefined && data.individualDetails.middleName !== "")
					this.middleName = data.individualDetails.middleName;
				if (data.individualDetails.lastName !== undefined && data.individualDetails.lastName !== "")
					this.lastName = data.individualDetails.lastName;
				if (data.individualDetails.gender !== undefined && data.individualDetails.gender !== "")
					this.gender = data.individualDetails.gender;
				if (data.individualDetails.dateOfBirth !== undefined && data.individualDetails.dateOfBirth !== "")
					this.dateOfBirth = data.individualDetails.dateOfBirth;
				if (data.individualDetails.buildingNoStreet !== undefined && data.individualDetails.buildingNoStreet !== "")
					this.street = data.individualDetails.buildingNoStreet;
				if (data.individualDetails.mobileNo !== undefined && data.individualDetails.mobileNo !== "")
					this.mobileNumber = data.individualDetails.mobileNo;
				if (data.individualDetails.emailId !== undefined && data.individualDetails.emailId !== "")
					this.emailID = data.individualDetails.emailId;
				/*Changed for CR_NP_0744*/
				if (data.individualDetails.panNumber !== undefined && data.individualDetails.panNumber !== "" && $scope.regexPanNo.test(data.individualDetails.panNumber)) {
					this.panNo = data.individualDetails.panNumber;
				} else {
					this.panNo = "";
				}

				if (data.individualDetails.aadhaarNo !== undefined && data.individualDetails.aadhaarNo !== "" && $scope.regexAadhaarNumber.test(data.individualDetails.aadhaarNo)) {
					this.aadhaarNumber1 = data.individualDetails.aadhaarNo.substr(0, 4);
					this.aadhaarNumber2 = data.individualDetails.aadhaarNo.substr(4, 4);
					this.aadhaarNumber3 = data.individualDetails.aadhaarNo.substr(8, 4);
				} else {
					this.aadhaarNumber1 = "";
					this.aadhaarNumber2 = "";
					this.aadhaarNumber3 = "";
				}
				/* CR_NP_0744 ends*/
				/*///3712 Starts ///////
				if(data.individualDetails.clientNationality = "NonIndian"){
					$scope.isNonIndia = true;
				}else{
					$scope.isNonIndia = false;
				}
				if(data.individualDetails.clientNationality!=undefined && data.individualDetails.clientNationality!=''){
					$scope.isNationalityExists = true;
					this.clientNationality = data.individualDetails.clientNationality;
				}else{
					$scope.isNationalityExists = false;
				}
				if(data.individualDetails.clientCountry!=undefined && data.individualDetails.clientCountry!=''){
					$scope.isCountryExists = true;
					this.clientCountry = data.individualDetails.clientCountry;
				}else{
					$scope.isCountryExists =false;
				}
				/////3712 Ends ////////*/
				if (data.individualDetails.eInsuranceAccountNo !== undefined && data.individualDetails.eInsuranceAccountNo !== "")
					this.accountNo = data.individualDetails.eInsuranceAccountNo;
				if (data.individualDetails.gstRegIdType !== undefined && data.individualDetails.gstRegIdType !== "") {
					this.gstRegID = data.individualDetails.gstRegIdType;
				}

				if (data.individualDetails.gstin !== undefined && data.individualDetails.gstin !== "")
					this.gstINModel = data.individualDetails.gstin;
				if (data.individualDetails.uin !== undefined && data.individualDetails.uin !== "")
					this.uinModel = data.individualDetails.uin;
				if (data.individualDetails.state !== undefined && data.individualDetails.state !== "") {
					$scope.partyCode = data.partyCode;
					$scope.responseState = data.individualDetails.state;
					$scope.responseCity = data.individualDetails.city;
					$scope.responsepinCode = data.individualDetails.pinCode;
					$scope.stateData = { "state": "" };
					return $scope.policyDetailsObj.stateServiceCall();
				}

			},
			selectPolHolId: function (data) {
				this.showSmallTbl = true;
				this.showSearchResTbl = false;
				this.existingCustomerFlag = false;
				$scope.showSmallData = data;
				this.setValue(data);
			},
			viewDetails: function (data) {
				this.newcustomerFlag = true;
				this.fieldDisable = true;
				this.showSmallTbl = false;
				this.existingCustomerBtn = false;
				this.setValue(data);
			},
			minimizeForm: function (data) {
				if (data === true) {
					CommonServices.showAlert("Age cannot be less than 18 years");
				} else {
					this.showSmallTbl = true;
					this.newcustomerFlag = false;
					this.fieldDisable = false;
					this.existingCustomerBtn = true;
					$scope.partyCode = "";
				}
			},
			deleteRow: function () {

				this.showSmallTbl = false;
				// Added as Form is made Invalid on change of existingPolicyHolder button
				$scope.invalidPolicyHolderForm = true;
				/*Added for CR_NP_0744, CR_NP_0744E starts*/
				CommonServices.panNoInputDisable = false;
				// CommonServices.aadhaarInputDisable = false;
				/*CR_NP_0744 and CR_NP_0744E ends*/
				if ($scope.gsCoveredBuildingAddress === true) {
					$scope.gsCoveredBuildingAddress = false;
					$scope.gsBuildingNo = "";
					$scope.gsBuildingLocality = "";
					$scope.gsBuildingPinCode = "";
				}

				if (this.policyHolder === "newPolicyHolder") {
					/*Added for CR_NP_0744, commented for CR_NP_0744E start*/
					this.panNoInputDisable = false;
					// this.aadhaarInputDisable = false;
					/*CR_NP_0744 and CR_NP_0744E ends*/
					this.newcustomerFlag = true;
					this.existingCustomerFlag = false;
					$scope.partyCode = "";
					this.productTitle = "";
					this.firstName = "";
					this.middleName = "";
					this.lastName = "";
					this.gender = "";
					this.dateOfBirth = "";
					this.street = "";
					this.locality = "";
					this.placeOfLoss = "";
					this.mobileNumber = "";
					this.landlineNumber = "";
					this.emailID = "";
					this.panNo = "";
					/*Added for CR_NP_0744*/
					this.aadhaarNumber1 = "";
					this.aadhaarNumber2 = "";
					this.aadhaarNumber3 = "";
					/*CR_NP_0744 ends*/
					this.accountNo = "";
					this.gstRegID = "";
					this.gstINModel = "";
					this.uinModel = "";
					this.contState = "";
					this.countryCity = "";
				}
				else {
					this.existingCustomerFlag = true;
					this.newcustomerFlag = false;
				}

			},
			updateDetails: function () { // this is to update policy holder detail
				/*Changed for CR_NP_0744, commented for CR_NP_0744E start*/
				if (this.aadhaarNumber1 != undefined && this.aadhaarNumber1 != '' && this.aadhaarNumber2 != undefined && this.aadhaarNumber2 != '' && this.aadhaarNumber3 != undefined && this.aadhaarNumber3 != '') {
					$scope.policyDetailsObj.aadhaarNumber = this.aadhaarNumber1 + this.aadhaarNumber2 + this.aadhaarNumber3;
				} else {
					$scope.policyDetailsObj.aadhaarNumber = "";
				}

				if ($rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.mobileNo === this.mobileNumber
					&& $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.emailId === this.emailID
					&& $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.panNumber === this.panNo
					&& $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.gstRegIdType === this.gstRegID
					&& $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.gstin === this.gstINModel
					&& $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.uin === this.uinModel
					&& $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.city === this.countryCity.cityCode
					&& $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.state === this.contState.stateCode
					&& $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.pinCode === this.placeOfLoss
					&& $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.dateOfBirth === this.dateOfBirth
					&& $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.buildingNoStreet === this.street
					/* 3712 Starts
					&& $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.clientNationality === this.clientNationality
					&& $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.clientCountry === this.clientCountry.stateCode
					3712 Ends */) {// If nothing has changed

					$scope.partyCode = "";
					this.fieldDisable = false;
					$scope.policyDetailsObj.showSmallTblFunc();
				}
				else {// if there are changes in values
					var updatepolicyHolderDataGs =
						{
							"userCode": CommonServices.getCommonData("userId"),
							"rolecode": "SUPERUSER",
							"policyHolderCode": $scope.showSmallData.partyCode,
							"mobileNo": this.mobileNumber,
							"gstRegIdType": this.gstRegID,
							"gstin": this.gstINModel,
							"dateOfBirth": $scope.policyDetailsObj.dateOfBirth,
							/*
							"clientNationality": $scope.policyDetailsObj.clientNationality,//3712
							"clientCountry": $scope.policyDetailsObj.clientCountry.stateCode,//3712
							*/
							"uin": (this.gstRegID === "UNB") ? (this.uinModel !== undefined ? this.uinModel : "") : "",
							"city": this.countryCity.cityCode,
							"state": this.contState.stateCode,
							"buildingNoStreet": this.street !== undefined ? this.street.toUpperCase() : "",
							"pinCode": this.placeOfLoss, //CR_NP_0880
							"addressLine1": this.street,
							"emailId": this.emailID !== undefined ? this.emailID : "",
							/*Added for CR_NP_0744*/
							"panNumber": this.panNo,
							"aadhaarNo": $scope.policyDetailsObj.aadhaarNumber
							/*CR_NP_0744 ends*/
						};

					var updatePolicyHolderContact = RestServices.postService(RestServices.urlPathsNewPortal.updatePolicyHolderContact, updatepolicyHolderDataGs);
					updatePolicyHolderContact.then(
						function (response) { // success 

							CommonServices.showLoading(false);
							if (response.data.errorCode === undefined) {
								if (response.data.pRetCode === "0") {

									var updatePolicyData = {
										"savedPartyDetails": {
											"partyDetails": {
												"individualDetails": {
													"firstName": $scope.policyDetailsObj.firstName,
													"lastName": $scope.policyDetailsObj.lastName,
													"middleName": $scope.policyDetailsObj.middleName,
													"gender": $scope.policyDetailsObj.gender,
													"dateOfBirth": $scope.policyDetailsObj.dateOfBirth,
													/*
													"clientNationality": "NonIndian",//3712
													"clientCountry": "Brazil",//3712
													*/
													"buildingNoStreet": $scope.policyDetailsObj.street,
													"pinCode": $scope.policyDetailsObj.placeOfLoss,//CR_NP_0880
													"mobileNo": $scope.policyDetailsObj.mobileNumber,
													"emailId": $scope.policyDetailsObj.emailID,
													"panNumber": $scope.policyDetailsObj.panNo,
													"aadhaarNo": $scope.policyDetailsObj.aadhaarNumber,
													"eInsuranceAccountNo": $scope.policyDetailsObj.accountNo,
													"gstRegIdType": $scope.policyDetailsObj.gstRegID,
													"gstin": $scope.policyDetailsObj.gstINModel,
													"uin": $scope.policyDetailsObj.uinModel,
													"cityObj": $scope.policyDetailsObj.countryCity,
													"stateObj": $scope.policyDetailsObj.contState,
													"city": $scope.policyDetailsObj.countryCity.cityCode,
													"state": $scope.policyDetailsObj.contState.stateCode
												},
												"policyHolder": $scope.policyDetailsObj.policyHolder,
												"partyType": $scope.policyDetailsObj.category
											}
										}
									};
									/*CR_NP_0744 and CR_NP_0744E changes ends*/
									$rootScope.invalidSPCErr = false;
									$scope.partyCode = "";
									angular.extend($rootScope.policyHolderDataGs, updatePolicyData);
									CommonServices.showAlert(response.data.pRetErr);
									//alert(response.data.pRetErr);
									/*Below added during UAT */
									$rootScope.policyHolderStateIs = updatePolicyData.savedPartyDetails.partyDetails.individualDetails.stateObj;
									$rootScope.policyHolderCityIs = updatePolicyData.savedPartyDetails.partyDetails.individualDetails.cityObj;
									/*UAT changes ends */
									$scope.policyDetailsObj.fieldDisable = false;
									$scope.showSmallData = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails;
									/* CR_NP_594A starts*/
									$scope.dateOfBirthEmpty = false;
									/* CR_NP_594A ends*/
									$scope.policyDetailsObj.showSmallTblFunc();
									updatePolicyData.savedPartyDetails.partyDetails.partyCode = response.data.policyHolderCode;
									angular.extend($rootScope.policyHolderDataGs, updatePolicyData);
								} else {
									CommonServices.showAlert("Please try again after some time.");
								}
							}
							else {
								CommonServices.showAlert(response.data.errorMessage);
							}

						},
						function (error) { // failure
							CommonServices.showLoading(false);
							RestServices.handleWebServiceError(error);
						});
				}

			}
		};


		$scope.calIconClick = function (event) {
			angular.element("#" + event.currentTarget.children[0].id).focus();
		};


		/*CR_MOBL_0054-GS Starts */
		if (CommonServices.editQuoteFlag === true && ($rootScope.backNavigationFromSummaryGs === false || $rootScope.backNavigationFromSummaryGs === undefined)) {
			// Risks
			if (CommonServices.grihaSuvidhaObj.risks[0].coverage.jewelleryCover.coverDetails != undefined && CommonServices.grihaSuvidhaObj.risks[0].coverage.jewelleryCover.coverDetails != "") {
				$scope.items = CommonServices.grihaSuvidhaObj.risks[0].coverage.jewelleryCover.coverDetails;
			}
			if (CommonServices.grihaSuvidhaObj.risks[0].coverage.applianceCovers[0].coverDetails != undefined && CommonServices.grihaSuvidhaObj.risks[0].coverage.applianceCovers[0].coverDetails != "") {
				$scope.applianceItems = CommonServices.grihaSuvidhaObj.risks[0].coverage.applianceCovers[0].coverDetails;
			}
			if (CommonServices.grihaSuvidhaObj.risks[0].coverage.applianceCovers[1].coverDetails != undefined && CommonServices.grihaSuvidhaObj.risks[0].coverage.applianceCovers[1].coverDetails != "") {
				$scope.televisionItems = CommonServices.grihaSuvidhaObj.risks[0].coverage.applianceCovers[1].coverDetails;
			}

			// Added to get Policyholder details and then call state,pincode and city service

			$scope.policyDetailsObj.policyHolder = "existingPolicyHolder";
			$scope.policyDetailsObj.createdParty(CommonServices.grihaSuvidhaObj);

			//building Address Details
			if (CommonServices.grihaSuvidhaObj.addressOfProperty.buildingNoStreet !== undefined && CommonServices.grihaSuvidhaObj.addressOfProperty.buildingNoStreet !== "") {
				$scope.gsCoveredBuildingAddress = CommonServices.grihaSuvidhaObj.addressOfProperty.buildingNoStreet;
				if ($scope.gsCoveredBuildingAddress === "Y") {
					$scope.gsCoveredBuildingAddress = true;
				}
			}
			if (CommonServices.grihaSuvidhaObj.addressOfProperty.buildingNoStreet !== undefined && CommonServices.grihaSuvidhaObj.addressOfProperty.buildingNoStreet !== "") {
				$scope.gsBuildingNo = CommonServices.grihaSuvidhaObj.addressOfProperty.buildingNoStreet;
			}
			if (CommonServices.grihaSuvidhaObj.addressOfProperty.locality !== undefined && CommonServices.grihaSuvidhaObj.addressOfProperty.locality !== "") {
				$scope.gsBuildingLocality = CommonServices.grihaSuvidhaObj.addressOfProperty.locality;
			}
			if (CommonServices.grihaSuvidhaObj.addressOfProperty.pinCode !== undefined && CommonServices.grihaSuvidhaObj.addressOfProperty.pinCode !== "") {
				$scope.gsBuildingPinCode = CommonServices.grihaSuvidhaObj.addressOfProperty.pinCode;
			}
			// Financier Details
			if (CommonServices.grihaSuvidhaObj.financierDetails.whetherPremiseHypothecatedToBank !== undefined && CommonServices.grihaSuvidhaObj.financierDetails.whetherPremiseHypothecatedToBank !== "") {
				$scope.premiseIsOfBank = CommonServices.grihaSuvidhaObj.financierDetails.whetherPremiseHypothecatedToBank;
				if ($scope.premiseIsOfBank === "Y") {
					$scope.premiseIsOfBank = true;
				}
			}
			if (CommonServices.grihaSuvidhaObj.financierDetails.nameOfBankNBranch !== undefined && CommonServices.grihaSuvidhaObj.financierDetails.nameOfBankNBranch !== "") {
				$scope.bankAndBranch.bankAndBranchName = CommonServices.grihaSuvidhaObj.financierDetails.nameOfBankNBranch;
			}
			if ($scope.premiseIsOfBank !== true) {
				$scope.bankAndBranch.bankAndBranchName = "";
			}

			// Only for Development Officer login
			if ($rootScope.stakeCode === "DEVLP-OFF") {
				for(var i=0; i<CommonServices.grihaSuvidhaObj.partyDetailsList.length; i++){
					if(CommonServices.grihaSuvidhaObj.partyDetailsList[i].stakeCode === "AGENT"){
						$scope.agentRequiredObj.agentRequired = "yes";
						$scope.showRelatedAgents = true;
						// To get the  related Development Officer list
						var relatedDevOff = CommonServices.getCommonData("relationDetailsOfDevOff");
						for(var j=0; j< relatedDevOff.length; j++){
							if(CommonServices.grihaSuvidhaObj.partyDetailsList[i].partyCode == relatedDevOff[j].partyCode){
								// $scope.agentRequiredObj.selectedAgentGs = CommonServices.getCommonData("selectedAgentIndex");
								$scope.agentRequiredObj.selectedAgentGs = j;
								// $scope.agentRequiredObj.selectedAgentGs = $rootScope.relationDetailsOfLoggedInDevOff[j];
							}
						}
					}
				}
			}
		}
		/*CR_MOBL_0054-GS Ends*/


		/*CR_MOBL_0054-GS */ //Added temporarely remove this block after coding for policy holder details
		if ($rootScope.policyHolderDataGs !== "" && $rootScope.policyHolderDataGs != undefined) {
			if ($rootScope.backFlag === "travellerDetails" || $rootScope.policyHolderDataGs.savedPartyDetails !== undefined) {
				$scope.policyDetailsObj.showSmallTblFunc();
				$scope.showSmallData = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails;
				$scope.policyDetailsObj.policyHolder = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.policyHolder;
			}
		}


		// if ($rootScope.backFlag === "travellerDetails" || $rootScope.policyHolderDataGs.savedPartyDetails !== undefined) {
		// 	$scope.policyDetailsObj.showSmallTblFunc();
		// 	$scope.showSmallData = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails;
		// 	$scope.policyDetailsObj.policyHolder = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.policyHolder;
		// }

		//CR_MOBL_0054-GS Ends here

		//Financier Details - Building Address same as Insured
		$scope.buildingAddSame = function () {
			if ($scope.gsCoveredBuildingAddress === false) {
				$scope.gsBuildingNoReadOnly = false;
				$scope.gsBuildingLocalityReadOnly = false;
				$scope.gsBuildingPinCodeReadOnly = false;
				$scope.gsBuildingNo = "";
				$scope.gsBuildingLocality = "";
				$scope.gsBuildingPinCode = "";
			} else {
				if ($rootScope.policyHolderDataGs.savedPartyDetails === undefined) {
					CommonServices.showAlert("Please create or select the policy holder in policy Holder Information screen");
					//alert("Please create or select the policy holder in policy Holder Information screen");
					$scope.gsCoveredBuildingAddress = false;
				} else {
					$scope.gsBuildingNo = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.buildingNoStreet;
					$scope.gsBuildingLocality = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.locality;
					$scope.gsBuildingPinCode = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.pinCode;

					if ($scope.gsBuildingNo !== undefined && $scope.gsBuildingNo !== '') {
						$scope.gsBuildingNoReadOnly = true;
					}
					if ($scope.gsBuildingLocality !== undefined && $scope.gsBuildingLocality !== '') {
						$scope.gsBuildingLocalityReadOnly = true;
					}
					if ($scope.gsBuildingPinCode !== undefined && $scope.gsBuildingPinCode !== '') {
						$scope.gsBuildingPinCodeReadOnly = true;
					}

				}
			}

		};

		//Relations Details - for Development Officer Login
		$scope.showAgents = function () {

			if ($scope.agentRequiredObj.agentRequired == 'no') {
				$scope.showRelatedAgents = false;
				// $scope.agentRequiredObj.agentRequired = false;
			} else {
				$scope.showRelatedAgents = true;
				// $scope.agentRequiredObj.agentRequired = true;
			}

		};

		// Service call saveAndCalculatePremium
		$scope.saveAndCalculatePremium = function () {
			/*Added for CR_NP_0744, aadhaar commented for CR_NP_0744E*/
			if ($scope.policyDetailsObj.panNoInputDisable === true) {
				CommonServices.panNoInputDisable = true;
			}

			/*CR_NP_0744 and CR_NP_0744E ends*/
			$scope.gsRiskDetails = [];

			$scope.gsRiskDetails.push({
				"coverage": {
					"jewelleryCover": {
						"totalSumInsured": $scope.sumInsuredJewellery,
						"coverDetails": $scope.items
					},
					"applianceCovers": [
						{
							"totalSumInsured": $scope.sumInsuredDomestic,
							"applianceType": "DOMESTIC",
							"coverDetails": $scope.applianceItems
						},
						{
							"totalSumInsured": $scope.sumInsuredTV,
							"applianceType": "TV",
							"coverDetails": $scope.televisionItems
						}
					],
					"basicCover": {
						"isFireQuakeTerrorIncludingPremises": $rootScope.isFireAndAlliedPerilsIncEarthquakeGS === true ? "Y" : "N",
						"sumInsuredFireQuakeTerrorIncludingPremises": $rootScope.sumInsuredFireAndAliedPerilsIncPremisesGs,
						"totalSumInsuredForBurglary": $scope.sumInsuredBurglary,
						"sumInsuredFireQuakeTerrorExcludingJewellery": $scope.sumInsuredFireAlliedPerils,
						"totalSumInsuredofBuilding": $scope.totalSumInsuredofBuilding
					},
					"coverType": CommonServices.getCommonData("selectedOptionName")
				}
			});


			$scope.policyHolderName = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.firstName + " " + $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.middleName + " " + $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.lastName;

			//$scope.bankAndBranchName = $("#bankAndBranchName").val();
			if ($scope.premiseIsOfBank === true) {
				bankandBranchName = $scope.bankAndBranch.bankAndBranchName;
			} else {
				bankandBranchName = "";
			}

			var stateOfPolHolder;
			var cityOfPolHolder;
			/*CR_MOBL_0054-GS Starts */
			// if (CommonServices.editQuoteFlag === true && $rootScope.backNavigationFromSummaryGs == false) {
			if (CommonServices.editQuoteFlag === true && ($rootScope.backNavigationFromSummaryGs === false || $rootScope.backNavigationFromSummaryGs === undefined) && $rootScope.polHolRadioClick === false) {
				stateOfPolHolder = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.stateObj.state;
				cityOfPolHolder = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.cityObj.city;
				/*CR_MOBL_0054-GS Ends*/
			} else if ($rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.policyHolder === "newPolicyHolder") {
				stateOfPolHolder = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.stateObj.state;
				cityOfPolHolder = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.cityObj.city;
			} else {
				stateOfPolHolder = $rootScope.policyHolderStateIs.state;
				cityOfPolHolder = $rootScope.policyHolderCityIs.city;
			}
			$rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.policyHolderStateGs = stateOfPolHolder;
			$rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.policyHolderCityGs = cityOfPolHolder;

			// LoggedIn User Data
			var loggedInUserDetails = CommonServices.getCommonData("LoginData");
			var loggedInUserProfile = loggedInUserDetails.userProfile;
			var saveAndCalPremiumInput;
			var indexValueOFAgent;
			indexValueOFAgent = parseInt($scope.agentRequiredObj.selectedAgentGs);
			console.log(indexValueOFAgent);
			CommonServices.setCommonData("selectedAgentIndex", indexValueOFAgent);
			saveAndCalPremiumInput = {
				"quote": {
					"addressOfProperty": {
						"buildingNoStreet": $scope.gsBuildingNo,
						"locality": $scope.gsBuildingLocality,
						"pinCode": $scope.gsBuildingPinCode
					},
					"risks": $scope.gsRiskDetails,
					"financierDetails": {
						"whetherPremiseHypothecatedToBank": $scope.premiseIsOfBank === true ? "Y" : "N",
						"nameOfBankNBranch": bankandBranchName
					},
					"policyStartDate": $rootScope.policyStartDateGs,
					"premisesHypBank": $scope.premiseIsOfBank === true ? "Y" : "N",
					"sameAddrAsBuilding": $scope.gsCoveredBuildingAddress === true ? "Y" : "N",
					"policyExpiryDate": $rootScope.policyExpiryDateGs,
					"policyHolderName": $scope.policyHolderName,
					"channel": "NonCustomer",
					"stakeCode": loggedInUserProfile.stakeCode,
					"disableOnload": true,
					"expiredMotorPolicy": false,
					"gstDetails": $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.gstRegIdType === "" ? false : true,
					"actualGST": {
						"callFrom": "ONLOAD",
						"state": $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.state,
						"city": $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.city,
						"gstRegIdType": ($rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.gstRegIdType !== undefined && $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.gstRegIdType !== "") ? $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.gstRegIdType : "",
						"gstin": ($rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.gstin !== undefined && $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.gstin !== "") ? $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.gstin : "",
						"uin": ($rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.uin !== undefined && $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.uin !== "") ? $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.uin : "",
						"pinCode": $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.pinCode,
						"mobileNo": $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.mobileNo,
						"emailId": $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.emailId,
						"address1": $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.buildingNoStreet,
						"address2": $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.locality
					},
					"product": "GS",
					"quoteNumber": $scope.calcPremiumResponseInAddDetailsGS[0].quote.quoteNumber,
					"productName": "Griha Suvidha",
					"businessType": "NB",
					"isHealth": false,
					"stateList": [],
					//"mobileUpdated": 1,
					//"emailUpdated": 1,
					"policyHolderCode": $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.partyCode,
					"errorMsg": "",
					"polHolPanNo": $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.panNumber?$rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.panNumber.toUpperCase():'',
					"cityList": [],
					"pincodeList": [],
					"partyDetailsList": $rootScope.stakeCode === "DEVLP-OFF" && $scope.agentRequiredObj.agentRequired === 'yes' ? [$rootScope.relationDetailsOfLoggedInDevOff[indexValueOFAgent]] : undefined,
					"userPartyDetails": $rootScope.stakeCode === "DEVLP-OFF" && $scope.agentRequiredObj.agentRequired === 'yes' ? [$rootScope.relationDetailsOfLoggedInDevOff[indexValueOFAgent]] : undefined,
					"productCode": "GS"
				},
				"userProfile": {
					"userId": loggedInUserProfile.userId,
					"firstName": loggedInUserProfile.firstName,
					"lastName": loggedInUserProfile.lastName,
					"dob": loggedInUserProfile.dob,
					"gender": loggedInUserProfile.gender,
					"channel": loggedInUserProfile.channel,
					"stakeCode": loggedInUserProfile.stakeCode,
					"relation": loggedInUserProfile.relation,
					"footer": {
						"errorCode": "1",
						"errorDescription": "This user is not authorized to view this page"
					},

					"uiFlow": "NON_CUSTOMER",
					"loggedInRole": loggedInUserProfile.loggedInRole
				}
			};

			//console.log(JSON.stringify(saveAndCalPremiumInput));

			var saveAndCalPremiumResponse = RestServices.postService(RestServices.urlPathsNewPortal.saveQuoteGs, saveAndCalPremiumInput);
			saveAndCalPremiumResponse.then(
				function (response) { // success 

					CommonServices.showLoading(false);
					if (response.data.hasOwnProperty('errorMessage')) {
						CommonServices.showAlert(response.data.errorMessage);
					} else if (response.data != undefined) {
						if (response.data.userProfile != undefined && response.data.userProfile.footer != undefined &&
							response.data.userProfile.footer.errorCode == "0") {
							GetSetResponseService.addsaveQuoteResponseDataGS(response.data);
							console.log(response.data);

							CommonServices.setCommonData("saveQuoteInput", saveAndCalPremiumInput);
							CommonServices.setCommonData("agentRequiredValueGs", $scope.agentRequiredObj.agentRequired);
							CommonServices.setCommonData("CollectionPaymentDetails", response.data.quote);
							/*Below 1 line added during CR_MOBL_0054-GS */
							$rootScope.backNavigationFromSummaryGs = false;
							$state.go('gsSummaryDetails');

						} else if (response.data.userProfile != undefined && response.data.userProfile.footer != undefined &&
							response.data.userProfile.footer.errorCode != "0") {
							CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
						} else {
							CommonServices.showAlert("Please try again after some time.");
						}
					} else {
						CommonServices.showAlert("Please try again after some time.");
					}

				},
				function (error) { // failure
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
				});
		}

		// Fetch SaveQuote Input on Back Navigation
		if ($rootScope.backNavigationFromSummaryGs === true) {

			var bindSaveQuotedata = CommonServices.getCommonData("saveQuoteInput");

			//Additional details
			$scope.items = bindSaveQuotedata.quote.risks[0].coverage.jewelleryCover.coverDetails;
			for (i = 0; i < $scope.items.length; i++) {
				delete $scope.items[i].$$hashKey;
				delete $scope.items[i].error;
			}

			$scope.applianceItems = bindSaveQuotedata.quote.risks[0].coverage.applianceCovers[0].coverDetails;
			for (i = 0; i < $scope.applianceItems.length; i++) {
				delete $scope.applianceItems[i].$$hashKey;
				delete $scope.applianceItems[i].error;
			}
			$scope.televisionItems = bindSaveQuotedata.quote.risks[0].coverage.applianceCovers[1].coverDetails;
			for (i = 0; i < $scope.televisionItems.length; i++) {
				delete $scope.televisionItems[i].$$hashKey;
				delete $scope.televisionItems[i].error;
			}

			//building Address Details
			if (bindSaveQuotedata.quote.sameAddrAsBuilding !== undefined && bindSaveQuotedata.quote.sameAddrAsBuilding !== "") {
				$scope.gsCoveredBuildingAddress = bindSaveQuotedata.quote.sameAddrAsBuilding;
				if ($scope.gsCoveredBuildingAddress === "Y") {
					$scope.gsCoveredBuildingAddress = true;
				}
			}
			if (bindSaveQuotedata.quote.addressOfProperty.buildingNoStreet !== undefined && bindSaveQuotedata.quote.addressOfProperty.buildingNoStreet !== "") {
				$scope.gsBuildingNo = bindSaveQuotedata.quote.addressOfProperty.buildingNoStreet;
			}
			if (bindSaveQuotedata.quote.addressOfProperty.locality !== undefined && bindSaveQuotedata.quote.addressOfProperty.locality !== "") {
				$scope.gsBuildingLocality = bindSaveQuotedata.quote.addressOfProperty.locality;
			}
			if (bindSaveQuotedata.quote.addressOfProperty.pinCode !== undefined && bindSaveQuotedata.quote.addressOfProperty.pinCode !== "") {
				$scope.gsBuildingPinCode = bindSaveQuotedata.quote.addressOfProperty.pinCode;
			}
			// Financier Details
			if (bindSaveQuotedata.quote.financierDetails.whetherPremiseHypothecatedToBank !== undefined && bindSaveQuotedata.quote.financierDetails.whetherPremiseHypothecatedToBank !== "") {
				$scope.premiseIsOfBank = bindSaveQuotedata.quote.financierDetails.whetherPremiseHypothecatedToBank;
				if ($scope.premiseIsOfBank === "Y") {
					$scope.premiseIsOfBank = true;
				}
			}
			if (bindSaveQuotedata.quote.financierDetails.nameOfBankNBranch !== undefined && bindSaveQuotedata.quote.financierDetails.nameOfBankNBranch !== "") {
				$scope.bankAndBranch.bankAndBranchName = bindSaveQuotedata.quote.financierDetails.nameOfBankNBranch;
			}
			//Relation details
			if ($rootScope.stakeCode === "DEVLP-OFF") {
				$scope.agentRequiredObj.agentRequired = CommonServices.getCommonData("agentRequiredValueGs");
				if ($scope.agentRequiredObj.agentRequired === 'yes') {
					$scope.showRelatedAgents = true;
					$scope.agentRequiredObj.selectedAgentGs = CommonServices.getCommonData("selectedAgentIndex");
				} else {
					$scope.showRelatedAgents = false;
				}
			}

			// $rootScope.backNavigationFromSummaryGs = false;
		} else {
			$rootScope.backNavigationFromSummaryGs = false;
		}

	}]);


	agentApp.controller('summaryDetailsCtrlGS', ['$scope', '$rootScope', 'CommonServices', 'RestServices', 'GetSetResponseService', '$location', '$state','CartServices', function ($scope, $rootScope, CommonServices, RestServices, GetSetResponseService, $location, $state, CartServices) {

	$scope.onload = function () {
		$scope.saveQuoteResponseGS = GetSetResponseService.getsaveQuoteResponseDataGS();
		$scope.selectedOptionDomainvalue = $rootScope.selectedOptionDomainValuesGs;
		$scope.enteredData = CommonServices.getCommonData("saveQuoteInput");
		$scope.agentRequiredValueInSummary = CommonServices.getCommonData("agentRequiredValueGs")== 'yes'?true:false;
		//$scope.selectedOptionIndex = CommonServices.selectedOptionIndex;
		//console.log(JSON.stringify($scope.enteredData));

		// To get the data in Summary Screen
		//$scope.selectedJewelleryDetailsForSummary = $scope.saveQuoteResponseGS[0].quote.risks[0].coverage.jewelleryCover.coverDetails[0];

		if ($scope.saveQuoteResponseGS[0].quote.premiumDetails.serviceTax === undefined || $scope.saveQuoteResponseGS[0].quote.premiumDetails.serviceTax === "") {
			$scope.saveQuoteResponseGS[0].quote.premiumDetails.serviceTax = $scope.saveQuoteResponseGS[0].quote.premiumDetails.netPremium - $scope.saveQuoteResponseGS[0].quote.premiumDetails.grossPremium;
		}
	}

	$scope.goBack = function () {
		$rootScope.backNavigationFromSummaryGs = true;
		$state.go('gsAdditionalDetails');
	}

	/* for accordian ----------------------*/
	var acc = document.getElementsByClassName("accordion");
	var i;

	for (i = 0; i < acc.length; i++) {
		acc[i].onclick = function () {
			this.classList.toggle("active");
			var panel = this.nextElementSibling;
			if (panel.style.display === "block") {
				panel.style.display = "none";
			} else {
				panel.style.display = "block";
			}

		}
	}
	/* accordian ends ----------------------*/

	$scope.onload();

/********ADDED FOR CR_805 Start *******/

	$scope.viewBreakupShow = false;
	$scope.closePopup = function () {
		$scope.viewBreakupShow = false;
	};
	$scope.hideModal = function () {
		$scope.viewBreakupShow = false;
	};
	
	$scope.viewBreakup=function()
	{
		
		       var gsViewBreakupInput = {
                "header": null,
                "quote": {
                    "quoteNumber":$scope.saveQuoteResponseGS[0].quote.quoteNumber,
                    "productCode": "GS",
                    "policyHolderCode":$rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.partyCode
                }
            };
       
        var gsViewBreakUpResponse = RestServices.postService(RestServices.urlPathsNewPortal.topUpViewBreakup, gsViewBreakupInput);
        gsViewBreakUpResponse.then(
            function (response) { // success 

                CommonServices.showLoading(false);
                if (response.data.hasOwnProperty('errorMessage')) {
                    //alert(response.data.errorMessage);
                    CommonServices.showAlert(response.data.errorMessage);
                } else {
                    CommonServices.topUpObj.viewBreakUpResponse = response.data.quote;
					$scope.viewBrkupOvj=response.data.quote;
					$scope.viewBreakupShow = true;
                   // $state.go("topUpViewBreakupScreen");
                }
            },
            function (error) { // failure
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            });

		
	}
	
/*********ADDED FOR CR_805 End *******/
	

$scope.approveQuoteGS = function (type = '') {

		//CommonServices.deviceType = "NA";
		// if (CommonServices.deviceType !== "NA")
		// 	navigator.notification.confirm("Do you wish to proceed with approval of quotation? Once Approved, no more changes will be made available on your quotation. Your payment should be made by " + $rootScope.policyStartDateGs + " 23:59:59. Please confirm.", $scope.exitFunction, "Alert", ["Confirm", "Cancel"]);
		// else {
		// 	var approvePayment;
		// 	approvePayment = confirm("Do you wish to proceed with approval of quotation? Once Approved, no more changes will be made available on your quotation. Your payment should be made by " + $rootScope.policyStartDateGs + " 23:59:59. Please confirm.");
		// 	if (approvePayment === true) {
		// 		$scope.exitFunction(1);
		// 	}
		// }
		CommonServices.setCommonData("addToCart", type); // CR3546
		var msg = "Do you wish to proceed with approval of quotation? Once Approved, no more changes will be made available on your quotation. Your payment should be made by " + $rootScope.policyStartDateGs + " 23:59:59. Please confirm.";
		CommonServices.messageModal('info', msg, false, 'Cancel', 'Confirm', function () {}, function () { $scope.exitFunction(1);}, 'Alert');
	}

	$scope.exitFunction = function (button) {
		if (button == 1) {

			var approvePayData = {
				"userProfile": { "userId": CommonServices.getCommonData("userId"), "loggedInRole": "SUPERUSER", "uiFlow": "NON_CUSTOMER" },
				"quote": { "quoteNumber": $scope.saveQuoteResponseGS[0].quote.quoteNumber, "policyType": null, "productCode": "GS" }
			};
			
			if (CommonServices.getCommonData("addToCart")==='cart') { // CR3546
				CartServices.approveAndAddToCart(approvePayData, "GS");
				return;
			}

			var approvePayResponse = RestServices.postService(RestServices.urlPathsNewPortal.approveRenewedQuote, approvePayData);
			approvePayResponse.then(
				function (response) { // success 
					CommonServices.setCommonData("productCode", "GS");
					CommonServices.showLoading(false);
					if (response.data.userProfile.footer.errorDescription.trim() === "Proposal Approved") {
						//Will navigate to billdesk page.

						var msg = response.data.userProfile.footer.errorDescription;
						CommonServices.messageModal('info', msg, false, '', 'Ok', function () {}, function () { approvePayExitFunction(1);}, 'Alert');
						
						// if (CommonServices.deviceType !== "NA")
						// 	navigator.notification.confirm(response.data.userProfile.footer.errorDescription, approvePayExitFunction, "Alert", ["Ok"]);
						// else {
						// 	var approvePayment;
						// 	approvePayment = confirm(response.data.userProfile.footer.errorDescription);
						// 	if (approvePayment === true) {
						// 		approvePayExitFunction(1);
						// 	}
						// }

					} else {
						CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
					}
				},
				function (error) { // failure
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
				});
		}
	}
	function approvePayExitFunction(button) {
		$state.go("collectionForm");
	}

}]);

