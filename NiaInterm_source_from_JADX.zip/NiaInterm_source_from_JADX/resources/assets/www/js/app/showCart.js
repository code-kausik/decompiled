agentApp.controller('showCartCtrl', ['$scope','CartServices','RestServices','CommonServices','$state', '$stateParams', function ($scope,CartServices, RestServices,CommonServices,$state,$stateParams) {

	$scope.cartListController ={
		onload: function() {
            var cartData = {
               "userId": CommonServices.getCommonData("userCode").toUpperCase()
			};
			
            var cartListResponse = RestServices.postService(RestServices.urlPathsNewPortal.collectionCartFetch, cartData);
            cartListResponse.then(function(response) { /* success */
				if(response.data === ""){
					errorMsg("Could not connect to server. Please try again later.");
				} else if (response.data.errorCode === 959) {
					errorMsg(response.data.errorMessage);
				} else {
					$scope.cartListing = response.data.quoteList;
					CartServices.cartListing = response.data.quoteList;
					CartServices.cartCount = response.data.quoteList.length;
					if ($scope.cartListing.length === 0) {
						errorMsg("There are no quote(s) available for payment");
						return;
					}
					/* getAllLobs */
					var productListResponse = RestServices.getService(RestServices.urlPathsNewPortal.getAllLobs);
					productListResponse.then(function(pResponse) { // success
						// $scope.productList = pResponse.data;
						// CommonServices.setCommonData("productList",$scope.productList);

						angular.forEach($scope.cartListing, function(obj, key) {
							obj.isChecked = false;
							obj.showDetail = false;
							obj.productName = obj.productCode;
							var loopOut = false;
							angular.forEach(pResponse.data.lobs, function(iobj, ikey) {
								angular.forEach(iobj.products, function(jobj, jkey) {
									if (jobj.productCode === obj.productCode) {
										obj.productName = jobj.productName;
										loopOut = true;
										return;
									}
								});
								if (loopOut) return;
							});
						});

						var configData = {"keys":["COLLECTION_BULK_TIME","COLLECTION_BULK_MAX_QUOTES"]};
						var config = RestServices.postService(RestServices.urlPathsNewPortal.getConfigurationData, configData);
						config.then(function(cResponse) { // success
							CommonServices.showLoading(false);
							if (cResponse.data.configurableDatas !== undefined) {
								angular.forEach(cResponse.data.configurableDatas, function (config, i) {
									if (config.key === "COLLECTION_BULK_TIME" && config.value != "") {
										var dt = new Date();
										var res = config.value.split(":"); // "20:00:00"
										// var res = "22:00:00".split(":");
										angular.forEach(res, function (time, j) {
											time = parseInt(time);
										});
										var d = new Date(dt.getFullYear(), dt.getMonth(), dt.getDate(), res[0], res[1], res[2]);	
										CartServices.paymentCutOffTime = d; // Thu Nov 28 2019 20:00:00 GMT+0530 (India Standard Time)
									}
									if (config.key === "COLLECTION_BULK_MAX_QUOTES" && config.value != "") {
										CartServices.maxQuoteLimit = parseInt(config.value); // "20"
									}
								});
							}
						},
						function(error) { // failure
							CommonServices.showLoading(false);
							RestServices.handleWebServiceError(error);
						}); 
					},
					function(error) { // failure
						CommonServices.showLoading(false);
						RestServices.handleWebServiceError(error);
					}); 
					/* getAllLobs*/
				} 
            },
            function(error) { /* failure */
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            });
		},
		onBackFromPaymentPage: function () {
			$scope.cartListing = CartServices.cartListing;
			CartServices.cartCount = CartServices.cartListing.length;
			CartServices.cartPaymentListing = [];
			angular.forEach($scope.cartListing, function(obj, key) {
				if (obj.isChecked) $scope.selectCart(key, obj, false);
			});
			$scope.viewObj.inputSelectAll = ($scope.totalChecked === $scope.cartListing.length);
		}
	};
	$scope.viewObj = {};
	
	$scope.home = function() {
		$state.go("home");
	}
	$scope.viewCartDetails = function(i) {
		angular.forEach($scope.cartListing, function(obj, key) {
			if (key !== i) obj.showDetail = false;
		});
		$scope.cartListing[i].showDetail = !$scope.cartListing[i].showDetail;
	}
	$scope.totalCartAmount = 0;
	$scope.disablePayment = true;
	$scope.viewObj.inputSelectAll = false;
	var isAllErrMsg = false;
	$scope.selectAll = function() {
		$scope.totalCartAmount = 0;
		$scope.disablePayment = true;
		isAllErrMsg = false;
		if ($scope.viewObj.inputSelectAll) CartServices.cartPaymentListing = [];
		angular.forEach($scope.cartListing, function(obj, key) {
			obj.isChecked = $scope.viewObj.inputSelectAll;
			$scope.selectCart(key, obj, true);
		});		
	}
	$scope.selectCart = function(i, obj, isAll = false) {
		if (obj.isChecked) {
			$scope.totalCartAmount += parseFloat(obj.netPremium);
			obj.totalCartAmount = $scope.totalCartAmount;
			CartServices.cartPaymentListing.push(obj);
			$scope.disablePayment = !validateMaxQuoteLimit(isAll);

		} else if (!obj.isChecked) {
			if ($scope.totalCartAmount > 0) $scope.totalCartAmount -= parseFloat(obj.netPremium);
			i = getCorrectIndex(i);
			obj.totalCartAmount = $scope.totalCartAmount;
			CartServices.cartPaymentListing.splice(i, 1);
			$scope.disablePayment = !validateMaxQuoteLimit(isAll);
		}
		$scope.totalChecked = CartServices.cartPaymentListing.length;
		if (!isAll) {
			$scope.viewObj.inputSelectAll = (CartServices.cartPaymentListing.length === $scope.cartListing.length);
		}
	}
	function validateMaxQuoteLimit (isAll) {
		if (CartServices.cartPaymentListing.length > CartServices.maxQuoteLimit) {
			if (!isAll || (isAll && !isAllErrMsg))
				CommonServices.showAlert("Payment for maximum of " + CartServices.maxQuoteLimit + " number of quotes can be done at once");

			if (isAll && !isAllErrMsg) isAllErrMsg = true;
			return false;
		}
		return (CartServices.cartPaymentListing.length > 0);
	}
	function getCorrectIndex (i) {
		angular.forEach(CartServices.cartPaymentListing, function(obj, key) {
			if ($scope.cartListing[i].quoteNo === obj.quoteNo) {
				i = key;
				return;
			}
		});
		return i;
	}
	
	/*$rootScope.$on('$stateChangeSuccess', function (ev, to, toParams, from, fromParams) {
		if (from.name === "collectionForm") {
			$scope.cartListController.onBackFromPaymentPage();
		} else {
			$scope.cartListController.onload();
		}
	 });*/
	 if (CartServices.cartPaymentListing.length > 0) {
		$scope.cartListController.onBackFromPaymentPage();
	 } else {
		$scope.cartListController.onload();
	 }
	 
	$scope.deleteCartConfirm = function(i, obj) {
		var msg = "Are you sure you want to delete the product?";
		CommonServices.messageModal('info', msg, false, 'No', 'Yes', function() {}, function () {
			deleteCart(obj);
		}, 'Alert');
	}
	function deleteCart(obj) {
		var cartData = {
			"quoteNo": obj.quoteNo
		};
		var productListResponse = RestServices.postService(RestServices.urlPathsNewPortal.collectionCartDelete, cartData);
		productListResponse.then(function(pResponse) { // success		
			CommonServices.showLoading(false);
			if (pResponse.data.errCode == 0) {
				CommonServices.showAlert('');
				var msg = "Quote deleted successfully";
				CommonServices.messageModal('info', msg, false, '', 'Ok', function() {}, function () {
					$state.transitionTo($state.current, $stateParams, {
						reload: true,
						inherit: false,
						notify: true
					});
				}, 'Alert');			
				// $state.reload();
				// $state.go("showCart");
			}
		},
		function(error) { // failure
			CommonServices.showLoading(false);
			RestServices.handleWebServiceError(error);
		});
	}
	$scope.makePayment = function() {
		var isTimeInvalid = (validateTime());
		if (isTimeInvalid) {
			var time = CartServices.formatAMPM(CartServices.paymentCutOffTime);


			CommonServices.showAlert("Payment for approved quotes through cart is only available till " + time);
		} else {
			CartServices.cartPaymenEnable = true;
			CommonServices.setCommonData("CollectionPaymentDetails", CartServices.cartPaymentListing);
			$state.go("collectionForm");
		
			// $scope.collectionPayment = CommonServices.getCommonData("CollectionPaymentDetails");
		}
	}
	function validateTime() {
		var dt = new Date();
		// t = dt.getHours(),
		// m = dt.getMinutes(),
		// s = dt.getSeconds();
		return (dt > CartServices.paymentCutOffTime);
	}
	function errorMsg (msg) {
		CommonServices.showLoading(false);
		CommonServices.messageModal('info', msg, false, '', 'Ok', function() {}, function () {$scope.home();}, 'Alert');
	}
	
}]);
	