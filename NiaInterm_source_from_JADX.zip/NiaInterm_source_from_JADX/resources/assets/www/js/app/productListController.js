agentApp.controller('productController', ['$state', '$scope','RestServices','CommonServices', function ($state, $scope, RestServices,CommonServices) {
	
			$scope.bodyHeight = window.innerHeight+'px';
			/* getAllLobs */
			 var productListResponse = RestServices.getService(RestServices.urlPathsNewPortal.getAllLobs);
				productListResponse.then(
					function(response) { // success	
						CommonServices.showLoading(false);	
						$scope.productList = response.data;
			CommonServices.setCommonData("productList",$scope.productList);
					},
					function(error) { // failure
						CommonServices.showLoading(false);
						RestServices.handleWebServiceError(error);
				}); 
			/* getAllLobs*/
			
			$state.go('products.productList');

}]);


agentApp.controller('productListController', ['$state','$scope','RestServices','CommonServices', function ($state, $scope, RestServices,CommonServices) {
			
		$scope.productLists = CommonServices.getCommonData("productList");
	
		$scope.goHome = function () {
			$state.go('home');
		} 
		
			
			$scope.subProductList = function (id) {
				$state.go('products.productSubList', {
					id: id
				});
			}

}]);

agentApp.controller('productSubListController', ['$state','$scope','$rootScope','RestServices','CommonServices', '$stateParams', function ($state,$scope,$rootScope,RestServices,CommonServices,$stateParams) {
	
		$rootScope.prodMenuOpen = false;
		$scope.productLists = CommonServices.getCommonData("productList");
		$scope.stakevalue = CommonServices.getCommonData("stakeCode");
		
		if($stateParams.id === 'MISCELLANEOUS'){
			$scope.heading ='HOME AND ACCIDENT';
		}else if($stateParams.id === 'TRAVEL'){
			$scope.heading ='TRAVEL';
		}else{
			$scope.heading =$stateParams.id;
		}
		angular.forEach($scope.productLists.lobs, function(value, key) {
			if( $stateParams.id.toUpperCase() == value.lobName) {
				$scope.productSubList = value.products;
			}
		}); 
				
				$scope.finalList = function(value) {
					 if($stateParams.id.toUpperCase() == 'MOTOR') {
						if(value.productCode == 'CV') {
							return false;
						 }
						 else {
							 return true;
						 }
					 }
					 else if($stateParams.id.toUpperCase() == 'HEALTH') {
						 var ids = ['AK' , 'NF','NP', 'TU','NM', 'UB','HN','UK','CJ','CZ']; //CR_0044
						 if(ids.indexOf(value.productCode) !== -1) {
							return true;
						 }
						 else {
							 return false;
						 }
					 }
					 else if($stateParams.id.toUpperCase() == 'MISCELLANEOUS') {
						 if(value.productCode == 'AP' || value.productCode == 'PU' || value.productCode == 'GS') { //|| value.productCode == 'RK') {     Uncomment for CR_3547
							return true;
						 }
						 else {
							 return false;
						 }
					 }
					 else {
						 return true;
					 }
				}
				
				$scope.productMainPage = function() {
					$state.go('products.productList');
				}
				$scope.buyOnline = false;
				$scope.retrieveContent = function( productCode) {
					
					$scope.activeMenu = productCode;
					
					// if($scope.activeMenu == "TW" || $scope.activeMenu == "PC" || $scope.activeMenu == "BH" || $scope.activeMenu == "PU" || $scope.activeMenu == "GS" || $scope.activeMenu == "TU" || $scope.activeMenu == "NP" || $scope.activeMenu == "UK" || $scope.activeMenu == "AK")
					if($scope.activeMenu == "BH" || $scope.activeMenu =="TU" || $scope.activeMenu =="GS" || $scope.activeMenu =="PU" || $scope.activeMenu == "TW" || $scope.activeMenu =="NP" || $scope.activeMenu =="AK" || $scope.activeMenu =="HN"|| $scope.activeMenu =="UK" || $scope.activeMenu =="CJ" || $scope.activeMenu =="CZ") //CR_0044 // CR_3725 Jit
					{
						
						if($scope.activeMenu == "TW"){
							$scope.buyOnline = true;
						}
						else if($scope.activeMenu == "BH" || $scope.activeMenu =="PU"){
							if($scope.stakevalue === "AGENT")
								$scope.buyOnline = true;
						}
						else{
							if($scope.stakevalue === "DEVLP-OFF" || $scope.stakevalue === "AGENT")
								$scope.buyOnline = true;
						}
						
					}						
					else{
						$scope.buyOnline = false;
					}				
	
						/* getContent */
						productContentRequest = JSON.stringify({
										"alfrescoInput":{
											"typeOfContent":"PolicyKeyFeature",
											"productName":productCode,
											"process":null,
											"language":"English",
											"channel":"Public"
										}
									});
						
						
						productContentResponse = RestServices.postService(RestServices.urlPathsNewPortal.getContent, productContentRequest);
						productContentResponse.then(
							function(response) {
								CommonServices.showLoading(false);
								$scope.content = response.data.contentDataList;
							},
							function(error) {
								CommonServices.showLoading(false);
								RestServices.headerWithoutToken = false;
							});
						/* getContent */
					
						/*get Doc Url*/
					docUrlRequest = JSON.stringify({
						"alfrescoInput":{
										"typeOfContent":"Documents",
										"productName":productCode,
										"process": null,
										"language": $rootScope.productName ==="HN" ?"en":"English",
										"channel":null,
										"contentGroup":"Mobile"
									}
								});
					
					
					docUrlRequestResponse = RestServices.postService(RestServices.urlPathsNewPortal.getContent, docUrlRequest);
					docUrlRequestResponse.then(
						function(response) {
					
							CommonServices.showLoading(false);
							$scope.docContent = response.data.contentDataList;
						},
						function(error) {
							CommonServices.showLoading(false);
							RestServices.headerWithoutToken = false;
						});
					/*get Doc Url*/		
									
					$('#product-content').show();			
				}
				
				$scope.buyProduct = function(){
					if($scope.activeMenu === "BH"){
						//CR655A Start
						$rootScope.prodMenuOpen = true;
						$rootScope.productName = "BH"
						$rootScope.productMsg="Has any person suffering from pre-existing illness / disease / disability and/or had met with an accident during any time in the past?"
						//CR655A End
					}else if($scope.activeMenu === "GS"){
						$state.go("gsLandingScreen");
					}else if($scope.activeMenu === "PU"){
						$state.go("personalAccident");
					}else if($scope.activeMenu === "TW"){
						$state.go('quickQuoteTW');
					}else if($scope.activeMenu === "NP" || $scope.activeMenu === "AK" ){
						CommonServices.setCommonData("selectedProduct",'health');
						CommonServices.buyProduct($scope.activeMenu);
					}else if($scope.activeMenu === "UK"){  //CR_0044
						$rootScope.headerName="New India Mediclaim";
			            $rootScope.productName ="UK";
			            $rootScope.productMsg ="Has any person to be insured been suffering / diagnosed / under any treatment for any Hypertension / diabetes / critical illness / Adverse Medical History / chronic illness / recurring illness/ Psychiatric and Psychosomatic Disorder during any time in past ?";
			            CommonServices.topUpObj ={};
			            CommonServices.newIndiaPremierMediclaim ={};
			            $state.go("topUpMediclaimLandingScreen");
			         //CR_0044
					}else if($scope.activeMenu === "CJ"){  //Sudip CR_3725
						$rootScope.headerName="New India Cancer Guard Policy";
			            $rootScope.productName ="CJ";
			            $rootScope.productMsg ="Do any of the proposed member hold New India Cancer Guard policy?";
			            CommonServices.topUpObj ={};
						CommonServices.newIndiaPremierMediclaim ={};
						CommonServices.setCommonData("selectedProduct",'health');
						//$state.go("topUpMediclaimLandingScreen");
						$state.go("premiumCalculatorCJ");//CR_3725
			         //CR_0044
					}
					else if($scope.activeMenu === "CZ"){  
						$rootScope.headerName="Corona Kavach Policy";
			            $rootScope.productName ="CZ";
			            $rootScope.productMsg ="";
			            CommonServices.topUpObj ={};
						CommonServices.newIndiaPremierMediclaim ={};
						CommonServices.setCommonData("selectedProduct",'health');
						CommonServices.topUpObj.fromProdcutList = "CZPRODUCTLIST";
						$state.go("coronaKavachPremiumCalc");
					}
					else{
                          if($scope.activeMenu === "TU" || $scope.activeMenu === "HN"){
                               CommonServices.topUpObj ={};
                              CommonServices.newIndiaPremierMediclaim ={};
                              
                             $rootScope.headerName= $scope.activeMenu === "TU" ? "New India Top Up Mediclaim" :"New India Premier Mediclaim Policy";
                              $rootScope.productName = $scope.activeMenu === "TU" ? "TU" :"HN";
                              $rootScope.productMsg = $scope.activeMenu === "TU" ? "Has any person to be insured been suffering / diagnosed / under treatment for any Pre Existing Disease or Adverse Medical History?":"Has any person to be insured been suffering / diagnosed / under any treatment for any Hypertension / diabetes / critical illness / Adverse Medical History / chronic illness / recurring illness/ Psychiatric and Psychosomatic Disorder during any time in past?";
                            CommonServices.topUpObj.fromProdcutList = "TUPRODUCTLIST";
                           $state.go("topUpMediclaimLandingScreen"); 
                       }
                        
                    }
          
					
				};
				
				$scope.brochureDownload = function(url, docName){
				
				  try {
						 window.appRootDirName = "NIAAgentDoc";
						 window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, CommonServices.gotFS, CommonServices.fail);

						var fileTransfer = new FileTransfer();
						var url = url;
						var filePath;
						var docName = docName;


						if(navigator.userAgent.match(/iPhone|iPad|iPod/i)){
						   filePath = window.appRootDir.nativeURL +docName;
						}
						else if(navigator.userAgent.match(/Android/i)){

						   filePath = fileSystem.root.toURL() + "NIAAgentDoc/" + docName;
						}
						else{
						   filePath = false;
						}
						CommonServices.showLoading(false);

							fileTransfer.download(url, filePath, function(theFile) {
								if(navigator.userAgent.match(/iPhone|iPad|iPod/i)){
								 window.open(url , '_system', 'location=no');
								}
								else if(navigator.userAgent.match(/Android/i)){
								window.open(filePath , '_system', 'location=no');
								}
							},
							function(error) {

								 CommonServices.showAlert("Download not successful, please try again after some time");
								 CommonServices.showLoading(false);
							},
							true
						);

					} catch (err) {

						$scope.counter = false;
						CommonServices.showLoading(false);
						CommonServices.showAlert("Please insert SD Card to download documents");
					} finally {

					}
				};
}]);
