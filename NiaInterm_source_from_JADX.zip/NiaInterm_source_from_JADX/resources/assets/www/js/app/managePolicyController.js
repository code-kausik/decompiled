agentApp.controller('policyClaimController', ['$scope','RestServices','CommonServices', function ($scope, RestServices,CommonServices) {
	
	$scope.bodyHeight = window.innerHeight+'px';

}]);

agentApp.controller('managePolicyController', ['$scope','RestServices','CommonServices','$state','$rootScope', '$q', function ($scope, RestServices,CommonServices,$state,$rootScope,$q) {


/**************CR_3626_start*********/

$scope.navgEndorsMntRequest=function()
{
$state.go("newEndorsementRequest");
}


/*************CR_3626_end***********/

	CommonServices.floaterObj={};
	$scope.byCollection = false;
	if($scope.singleSelect == undefined)
		$scope.singleSelect = "";
	
	$scope.managePolicyController ={
		 onload: function(){
			 if(CommonServices.managePolicyCollection){
				 this.quotePolicyData = {
					"userProfile": {
						"userId": CommonServices.getCommonData("userId"),
						"loggedInRole": CommonServices.getCommonData("loggedInRole"),
						"searchQuote": {
							"productCode": "",
							"productName": null,
							"quoteNumber": CommonServices.managePolicyDetailsData.quoteNumber,
							"startDate": "",
							"endDate": "",
							"status": null,
							"resultSize": 5,
							"startIndex": 1,
							"totalResults": 0
						}
					}
				};
				$scope.quotePolicyNum = CommonServices.managePolicyDetailsData.quoteNumber;
				//$scope.managePolicyObj.managePolicyService();
			 } else {
				 if(CommonServices.getCommonData("polNo") == undefined) 			   	 //cr3773
					$scope.quotePolicyNum = "";
				// else if($scope.quotePolicyNum === CommonServices.getCommonData("polNo")) //cr3773
				// 	CommonServices.setCommonData("polNo", undefined);					 //cr3773
			 }
			$scope.quoteAction = "";
		 }
	 };
	 $scope.managePolicyController.onload();
	
	$scope.home = function() {
		CommonServices.managePolicyCollection = false;
		$state.go("home");
	};	
	$scope.showBreakInErrMsg = false;
	
	CommonServices.editQuoteHistory = false;
	//Creating object for manage policy

	$scope.managePolicyObj = {
		detailsFlag: true,
		invalidInput: true,
		quotePolicyData:"",
		policyFlag: false,
		breakInFlag: false,
		extendPolicy: false,
		showActions: false,
		rejectResponse:"",
		searchOptionsList : [{
			 id : 'quotes',
			 name : 'Quote No.'
		 }, {
			 id : 'policies',
			 name : 'Policy No.'
		 }],
		managePolicySubmit: function(data){
			$scope.managePolicyObj.detailsFlag = false;
			//On submit of manage policy

			if(data === "search"){
				if(($scope.quotePolicyNum === undefined || $scope.quotePolicyNum === "") && ($scope.collectionPolicyNum === undefined || $scope.collectionPolicyNum ==="")){
					$scope.policyDetails.productCode ="";
					$scope.managePolicyObj.detailsFlag = false;
					CommonServices.showAlert("Please enter 16 digit Quote / 20 digit Policy No.");
				}
				else {
					if(($scope.quotePolicyNum!= undefined && $scope.quotePolicyNum.toString().length < 16) && $scope.collectionPolicyNum.toString().length < 20){
						$scope.policyDetails.productCode = "";
						$scope.managePolicyObj.detailsFlag = false;
						CommonServices.showAlert("Please enter 16 digit Quote / 20 digit Policy No.");
						return false;
					}
					
					if($scope.quotePolicyNum != undefined && $scope.quotePolicyNum.toString().length === 16){ //validation if input value equal to 16
						if($scope.singleSelect === "policies"){
							CommonServices.showAlert("No Data Found");
							return false;
						}
						if($scope.singleSelect === "quotes"){
							this.quotePolicyData = {
								"userProfile": {
									"userId": CommonServices.getCommonData("userId"),
									"loggedInRole": CommonServices.getCommonData("loggedInRole"),
									"searchQuote": {
										"productCode": "",
										"productName": null,
										"quoteNumber": $scope.quotePolicyNum,
										"startDate": "",
										"endDate": "",
										"status": null,
										"resultSize": 5,
										"startIndex": 1,
										"totalResults": 0
									}
								}
							}
							this.policyFlag = false;
							this.managePolicyService();
							return false;
						}
					}
					
					if(($scope.quotePolicyNum != undefined && $scope.quotePolicyNum.toString().length === 20) || $scope.collectionPolicyNum.toString().length === 20){ //validation if input value equal to 20
						if($scope.singleSelect === "quotes"){
							CommonServices.showAlert("No Data Found");
							return false;
						}
						if($scope.singleSelect === "policies"){
							this.quotePolicyData = {
								"userProfile": {
									"userId": CommonServices.getCommonData("userId"),
									"loggedInRole": CommonServices.getCommonData("loggedInRole"),
									"searchQuote": {
										"productCode": "",
										"productName": null,
										"policyNumber": $scope.quotePolicyNum,
										"startDate": "",
										"endDate": "",
										"status": null,
										"resultSize": 5,
										"startIndex": 1,
										"totalResults": 0
									}
								}
							}
							this.policyFlag = true;
							this.managePolicyService();
							return false;
						}
						if($scope.byCollection){
							this.quotePolicyData = {
								"userProfile":{
									"loggedInRole": CommonServices.getCommonData("loggedInRole"),
									"userId":  CommonServices.getCommonData("userId"),
								},
								"collectionListInput":{
									"collectionNo": $scope.collectionPolicyNum,
									"stakeCode": CommonServices.getCommonData("stakeCode"),
									"userId": CommonServices.getCommonData("userId"),
								}
							}
							this.policyFlag = true;
							this.manageCollectionPolicyService();
							return false;
						}
					}
					if($scope.quotePolicyNum!=undefined && 16 < $scope.quotePolicyNum.toString().length < 20){
						$scope.policyDetails.productCode ="";
						$scope.managePolicyObj.detailsFlag = false;
						CommonServices.showAlert("Please enter 16 digit Quote / 20 digit Policy No.");
						return false;
					}
				}
					
			}
			else if(data === "viewDetails"){
				this.detailsFlag = false;
				var policyDetailsInput ={"userProfile":
				{
					"userId":CommonServices.getCommonData("userId"),
					"loggedInRole":CommonServices.getCommonData("loggedInRole")
				},
				"quote":{
					"policyNumber":$scope.managePolicyObj.policyDetails.policyNumber,
					"processType":"NB","productCode":$scope.managePolicyObj.policyDetails.productCode
				},"productCode":$scope.managePolicyObj.policyDetails.productCode}
				CommonServices.setCommonData("policyDetailsInput",policyDetailsInput);
				$state.go("managePolicies.viewPolicyDetails");
			}
			else if(data === "extendPolicy"){
				
				var validatePolicyData = {"userProfile":{"userId":CommonServices.getCommonData("userId"),"loggedInRole":"SUPERUSER"},"quote":{"policyNumber":$scope.managePolicyObj.policyDetails.policyNumber}};
	
				var validatePolicyResponse = RestServices.postService(RestServices.urlPathsNewPortal.validatePolicy, validatePolicyData);
				validatePolicyResponse.then(
				  function(response) { // success 
					
					CommonServices.showLoading(false);
					if(response.data.userProfile !== undefined){
						if(response.data.userProfile.footer.errorCode === "0"){	
							CommonServices.setCommonData("extendPolicy",response.data.quote);
							$state.go("businessHolidays.overseasMediclaim");								 
					  }else{
						  CommonServices.showAlert("Please try again after some time.");
					  }
					}
					else{
						CommonServices.showAlert(response.data.errorMessage);
					}
					  
				  },
				  function(error) { // failure
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
				  });
				
			}
								
		},
		validatePolicyStartDate: function(){
		
			var policyStartDate = $scope.managePolicyObj.policyDetails.policyStartDate;
			var logDate = CommonServices.getCommonData("serverDate");
			
			var policyStartDate = $scope.managePolicyObj.policyDetails.policyStartDate.split('/');
			policyStartDate = policyStartDate[1] + '/' + policyStartDate[0] + '/' + policyStartDate[2]; //mm/dd/yyyy
			
			policyStartDate = new Date(policyStartDate);
			
			var logDate = CommonServices.getCommonData("serverDate");
			logDate = new Date(logDate);
			
			if(policyStartDate >= logDate){
				return {
					flag: true
				};
			}
			else{
				return {
					flag: false
				};
			}
		},
		editQuote: function(data){ 
			
			CommonServices.editQuoteObj={
				"quoteNumber":$scope.managePolicyObj.policyDetails.quoteNumber,
				"productName":$scope.managePolicyObj.policyDetails.productCode
			}
			if(data === "edit"){
				if($rootScope.productName ==="AK" || $rootScope.productName ==="UK" || $rootScope.productName === "NP" || $rootScope.productName ==="TU" || $rootScope.productName ==="TW" || $rootScope.productName ==="BH" || $rootScope.productName ==="GS" || $rootScope.productName ==="PU" || $rootScope.productName ==="CJ"){  /* CR_0054 * CR_3725 Jit*/
					CommonServices.editQuoteHistory = true;
					CommonServices.buyProduct($rootScope.productName);
				}
				if($rootScope.productName ==="BH"){
					
				}
				
			}
			if(data === "collectPremium"){
				if(this.validatePolicyStartDate().flag === false){
					CommonServices.showAlert("Payment cannot be made for the previous dated approved quotes");
					return;
				}
			
				var policyDetailsInput ={"userProfile":
				{
					"userId":CommonServices.getCommonData("userId"),
					"loggedInRole":CommonServices.getCommonData("loggedInRole")
				},
				"quote":{
					"quoteNumber":$scope.managePolicyObj.policyDetails.quoteNumber,
					"processType":"NB","productCode":$scope.managePolicyObj.policyDetails.productCode
				},"productCode":$scope.managePolicyObj.policyDetails.productCode};
				
				var getpolicyListResponse = RestServices.postService(RestServices.urlPathsNewPortal.getPolicyDetails, policyDetailsInput);
				getpolicyListResponse.then(
					function(response) { // success	
					CommonServices.showLoading(false);
										  
						if(response.data.quote !== ""){
							CommonServices.setCommonData("CollectionPaymentDetails",response.data.quote);
							$state.go("collectionForm");
						}
						else{
							
						}
							
					},
					function(error) { // failure
						CommonServices.showLoading(false);
						RestServices.handleWebServiceError(error);
				});
			}
		},
		
		//Added for CR_3546
		manageCollectionPolicyService: function(){
			var quotePolicyResponse = RestServices.postService(RestServices.urlPathsNewPortal.getCollectionList, this.quotePolicyData);
			quotePolicyResponse.then(
				function(response){
					CommonServices.showLoading(false);
					if(response.data.pRetCode !== 0) {
						CommonServices.showAlert(response.data.pRetErr);
					}
					else{
						if(response.data.collectionList.length == 0)
						{
							$scope.managePolicyObj.detailsFlag = false;
							CommonServices.showAlert("No Data found. Please enter a valid quote");
						}
						else{
							$scope.managePolicyObj.detailsFlag = true;
							// console.log(response.data.collectionList[0]);
							$scope.policyDetails = [];
							angular.forEach(response.data.collectionList, function(list, i) {
								$scope.policyDetails.push({
									"quoteNumber": (list.quoteNo != undefined) ? list.quoteNo : '',
									"policyNumber": (list.policyNo != undefined) ? list.policyNo : '',
									"policyStartDate": list.startDate,
									"policyExpiryDate": list.endDate,
									"policyHolderName": list.policyHolderName,
									"productName": list.productCode,
									"currentStatus": list.polStatus,
								});
								getProductName(list.productCode).then(function (data) {
									$scope.policyDetails[i].productName = data;
								}, function (data) {
									$scope.policyDetails[i].productName = data;
								});
							});

							function getProductName (pCode) {
								var pService = RestServices.postService(RestServices.urlPathsNewPortal.getProductName, JSON.stringify({"productCode": pCode}));
								var defer = $q.defer();
								pService.then(function(response){
									CommonServices.showLoading(false);
									if(response.data.errorCode != 0) {
										defer.reject(pCode);
										CommonServices.showAlert(response.data.errorMessage);
									} else{
										defer.resolve(response.data.productName);
									}
								});
								return defer.promise;
							}
						}
					}
				}
			)
		},
		//END CR_3546

		managePolicyService: function(){
			//Service call on submit of manage policy
			CommonServices.showLoading(true);	
			var quotePolicyResponse = RestServices.postService(RestServices.urlPathsNewPortal.getPolicyList, this.quotePolicyData);
			quotePolicyResponse.then(
				function(response) { // success	
				
					//CommonServices.showAlert(response.data.userProfile.footer.status);
					CommonServices.showLoading(false);	
					if(response.data.errorCode !== undefined){
						CommonServices.showAlert(response.data.errorMessage);
					} else {
						if(response.data.quotes.length === 0){
							$scope.managePolicyObj.detailsFlag = false;
							if(response.data.message === "No record found"){
								CommonServices.showAlert("No Data found. Please enter valid Quote/Policy number.");
							}
							else{
								CommonServices.showAlert(response.data.message);
							}
						}
						else {									
							$scope.managePolicyObj.detailsFlag = true;
							$scope.policyDetails = response.data.quotes[0];
							CommonServices.setCommonData("policyDetEndr",$scope.policyDetails );//NP_CR_3626
							$scope.managePolicyObj.policyDetails = response.data.quotes[0];
							if($scope.managePolicyObj.policyDetails.productCode === "BH" || $scope.managePolicyObj.policyDetails.productCode === "ES")
								$scope.managePolicyObj.extendPolicyFunc($scope.managePolicyObj.policyDetails);
							CommonServices.managePolicyDetailsData = response.data.quotes[0];
							if(response.data.quotes[0].productCode === "TW" || response.data.quotes[0].productCode === "CV" || response.data.quotes[0].productCode === "PC" || response.data.quotes[0].productCode === "SQ" || response.data.quotes[0].productCode === "SS") { /* CR_NP_3621 */
								var breakInStatus = response.data.quotes[0].breakInStatus.split("~");
								$scope.managePolicyObj.rejectResponse = breakInStatus[1];
								/*Changed by 851587 during CR_MOBL_0053*/
								if(breakInStatus[0] === "BREAKREJ"){
									$scope.quoteAction = "Reason";								
								} else if(breakInStatus[0] === "BREAKPUP"){								
									$scope.quoteAction = "Pending Upload Photo";
								} else if(breakInStatus[0] === "BREAKPU"){
									$scope.quoteAction = "Pending Approve Break in";
								} else if(breakInStatus[0] === "BREAKAPP" && response.data.quotes[0].currentStatus !== "ACTIVE POLICY"){
									$scope.quoteAction = "Pending Collect Premium";
								} else if(breakInStatus[0] === "BREAKCRNWL" || breakInStatus[0] === "BREAKCQ"){
									$scope.quoteAction = "Renew";
								} else {
									//$scope.showBreakInErrMsg = false;
									//$scope.managePolicyObj.breakInFlag = false;	/*CR_MOBL_0053 ends*/
									if($scope.managePolicyObj.policyDetails.currentStatus === "DRAFT APPLICATION"){
										$scope.quoteAction = "Edit";
									}
									if($scope.managePolicyObj.policyDetails.currentStatus === "APPROVED APPLICATION"){
										$scope.quoteAction = "collectPremium";
									}				
								}										
							}
							else{
								if($scope.managePolicyObj.policyDetails.currentStatus === "DRAFT APPLICATION"){
									$scope.quoteAction = "Edit";
								}
								if($scope.managePolicyObj.policyDetails.currentStatus === "APPROVED APPLICATION"){
									$scope.quoteAction = "collectPremium";
								}

							}
						}
						if($scope.managePolicyObj.policyDetails != undefined)
							$rootScope.productName = $scope.managePolicyObj.policyDetails.productCode;
						
					}
				},
				function(error) { // failure
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
			});
		},
		extendPolicyFunc: function(data){
		
			var dt1 = data.policyExpiryDate.split('/'),
			extendPolicy = dt1[1] + '/' + dt1[0] + '/' + dt1[2]; //mm/dd/yyyy
			
			extendPolicy = new Date(extendPolicy);
			
			var date = new Date();
			date.setMonth(date.getMonth() - 15);
			
			if(extendPolicy > date){
				this.extendPolicy = true;
			}
			else{
				this.extendPolicy = false;
			}			 
		},
		policyChange: function(){
			var data = $("#quotePolicyNum").val();
			if(data != undefined && data.toString().length === 16){
				$scope.singleSelect = "quotes";
				$scope.byCollection = false; // added for CR3546
			}
			else if(data != undefined && data.toString().length === 20){
				$scope.singleSelect = "policies";
				$scope.byCollection = false; // added for CR3546
			}
			else{
				$scope.singleSelect = "";
				if($scope.collectionPolicyNum != undefined && $scope.collectionPolicyNum.toString().length === 20)
					$scope.byCollection = true;
				
			}
		},
		//CR_3546 Starts
		policyCollectionChange: function(){
			if($scope.collectionPolicyNum != undefined && $scope.collectionPolicyNum.toString().length === 20){
				$scope.singleSelect = "";
				$scope.byCollection = true;
				//console.log("Check CollectionCode Size");
			}
			else{
				//$scope.singleSelect = "";
				$scope.byCollection = false;
			}
		},
		//CR_3546 Ends
		intimateClaim: function(){
			CommonServices.setCommonData("policyNumber",$scope.managePolicyObj.policyDetails);
			$state.go("managePolicies.intimateClaimForm");
		},
		quoteStatus: function(quoteStatus){
			CommonServices.editQuoteObj={
				"quoteNumber":$scope.managePolicyObj.policyDetails.quoteNumber,
				"productName":$scope.managePolicyObj.policyDetails.productCode
			}
			$scope.managePolicyObj.showActions = !$scope.managePolicyObj.showActions;
			if(quoteStatus === "Pending Upload Photo") {
				CommonServices.showAlert("Vehicle's Photo uploads are pending");
			} else if(quoteStatus === "Pending Approve Break in") {
				CommonServices.showAlert("Break approval is pending with NIA office user");
			} else if(quoteStatus === "Pending Collect Premium") {
				this.collectPremium();
			} else if(quoteStatus === "Reason") {
				if($scope.managePolicyObj.rejectResponse === "NA" || $scope.managePolicyObj.rejectResponse === undefined){
					CommonServices.showAlert("Rejected by system as process is not completed within specified time");
				} else if($scope.managePolicyObj.rejectResponse !== ""){
					CommonServices.showAlert("The break in insurance approval for quote "+ $scope.managePolicyObj.policyDetails.quoteNumber +" is rejected by approver on the ground of "+ $scope.managePolicyObj.rejectResponse);
				} else{
					
				}
			} else if(quoteStatus === "Renew"){
				CommonServices.renewQuoteNo = CommonServices.managePolicyDetailsData.quoteNumber;
				CommonServices.managePolBreakIn = true;
				$state.go("newRenewPolicy.getNewRenewPolicy");
			}
			else if(quoteStatus === "collectPremium"){
				
				if(this.validatePolicyStartDate().flag === false){
					CommonServices.showAlert("Payment cannot be made for the previous dated approved quotes");
					return;
				}
			
				var policyDetailsInput ={"userProfile":
				{
					"userId":CommonServices.getCommonData("userId"),
					"loggedInRole":CommonServices.getCommonData("loggedInRole")
				},
				"quote":{
					"quoteNumber":$scope.managePolicyObj.policyDetails.quoteNumber,
					"processType":"NB","productCode":$scope.managePolicyObj.policyDetails.productCode
				},"productCode":$scope.managePolicyObj.policyDetails.productCode};
				
				var getpolicyListResponse = RestServices.postService(RestServices.urlPathsNewPortal.getPolicyDetails, policyDetailsInput);
				getpolicyListResponse.then(
					function(response) { // success	
					CommonServices.showLoading(false);
										  
						if(response.data.quote !== ""){
							CommonServices.setCommonData("CollectionPaymentDetails",response.data.quote);
							CommonServices.setCommonData("partyCode",response.data.quote.policyHolderCode); 
							$state.go("collectionForm");
						}
						else{
							
						}
							
					},
					function(error) { // failure
						CommonServices.showLoading(false);
						RestServices.handleWebServiceError(error);
				});
			}
			else if(quoteStatus === "Edit"){
				/** 
				 * Added CR 4092 - Corona Kavach Policy 
				 */
				if($rootScope.productName ==="AK" || $rootScope.productName ==="NP" || $rootScope.productName ==="UK" || $rootScope.productName ==="HN" || $rootScope.productName ==="TU" || $rootScope.productName ==="TW" || $rootScope.productName ==="BH" || $rootScope.productName ==="GS" || $rootScope.productName ==="PU" || $rootScope.productName ==="CJ" || $rootScope.productName ==="RK" || $rootScope.productName === 'CZ'){ /* CR_0054 && CR_3725 Jit*/
					CommonServices.editQuoteHistory = true;
					CommonServices.buyProduct($rootScope.productName);
				}
			}
		},
		openActionModal: function () {
			//$scope.showActions = !$scope.showActions;
			$scope.managePolicyObj.showActions = true;
		},
		editQuoteThrManageQuote: function(){
			CommonServices.showAlert("Currently Edit Quote is not available for this product through Mobile App.");
		},
		collectPremium: function(){
			var getPolicyData = {  
			   "userProfile":{  
				   "userId":CommonServices.getCommonData("userCode").toUpperCase(),
				   "loggedInRole":CommonServices.getCommonData("loggedInRole")
			   },
			   "quote":{  
				   "quoteNumber": $("#quotePolicyNum").val(),
				   "processType": "NB",
				   "productCode": CommonServices.getCommonData("productCode")
			   }
			};
			   
			var getPolicyDataResponse = RestServices.postService(RestServices.urlPathsNewPortal.getPolicyQuoteDetails, getPolicyData);
			getPolicyDataResponse.then(
			  function(response){
				CommonServices.saveQuoteDetailsData = response.data;
				var modes = CommonServices.getCommonData("disableCollectionMob");
				var chqMode = false;
				for(var i=0; i<modes.length; i++) {
					if(modes[i].code === "CHQ") {
						chqMode = true;
				   } 
			   }
			   if(chqMode){
					var domainData = {
						"lngCode":"EN",
						"keys":["CHEQUE_PO_DRAFT_TYPE"]
					};
					var getDomainResponse = "";
					getDomainResponse = RestServices.postService(RestServices.urlPathsNewPortal.getDomainValues, domainData);
					getDomainResponse.then(
						function(response){
							CommonServices.showLoading(false);
							for(var i=0; i<response.data.domainValues.length; i++){
								var chequeTypes = {
									'name': response.data.domainValues[i].mnemonic
								};
								CommonServices.chequeList.push(chequeTypes);
							}
							CommonServices.managePolicyCollection = true;
							$state.go('newRenewPolicy.collectionForm');
							
						},
						function(error){
							CommonServices.showLoading(false);
							RestServices.handleWebServiceError(error);
						});
			   } else {
				CommonServices.showLoading(false);
				CommonServices.managePolicyCollection = true;
				$state.go('newRenewPolicy.collectionForm');
			   }
			},
			function(error){
			  CommonServices.showLoading(false);
			  RestServices.handleWebServiceError(error);
			});
		}
	}	
	

	// /**************CR_3773_start*********/

	if($rootScope.isAutoManagePolicy)
	{
		$scope.quotePolicyNum = CommonServices.getCommonData("polNo");
		if($scope.quotePolicyNum.length == 16){
			$scope.singleSelect = "quotes";
			// $scope.quoteAction = "collectPremium";
		}
		else{
			$scope.singleSelect = "policies";
			// $scope.quoteAction = "Edit";

		}
		$scope.byCollection = false;
		// if($scope.policyDetails == undefined)
		// 	$scope.policyDetails = {};
		$scope.managePolicyObj.managePolicySubmit('search');
	}

	// /*************CR_3773_end***********/

}]);

/************NP_CR_3626 Start************/
agentApp.controller('endorsementRequestController', ['$scope','RestServices','CommonServices','$state','$rootScope', function ($scope, RestServices,CommonServices,$state,$rootScope) {


$scope.hidePopup=function()
{
$("#image-preview").hide();
}

$scope.showimagePopUp=function(event)
{
console.log(event.currentTarget.getAttribute("data"));

$("#image-preview").show();
//$("#v").src=event.currentTarget.getAttribute("data");

$("#v").attr("src",event.currentTarget.getAttribute("data"));

}	



var mydateStr = CommonServices.getCommonData("serverDate");
console.log(mydateStr);
var mynewdateFrom = "";


if (mydateStr != undefined) {
			mynewdateFrom = new Date(mydateStr);
		}
		else {
			mynewdateFrom = new Date();
		}
		
			var dd = mynewdateFrom.getDate();
			var mm = mynewdateFrom.getMonth() + 1;
			var yyyy = mynewdateFrom.getFullYear();

			if (dd < 10) {
				dd = "0" + dd;
			}
			if (mm < 10) {
				mm = "0" + mm;
			}
$scope.startDate = dd + "/" + mm + "/" + yyyy;





$scope.policyDetailsObj= CommonServices.getCommonData("policyDetEndr");
console.log("policy detaails data"+JSON.stringify($scope.policyDetailsObj));

var policyDetailsInput ={"userProfile":
				{
					"userId":CommonServices.getCommonData("userId"),
					"loggedInRole":CommonServices.getCommonData("loggedInRole")
				},
				"quote":{
					"policyNumber":$scope.policyDetailsObj.policyNumber,
					"processType":"NB","productCode":$scope.policyDetailsObj.productCode
				},"productCode":$scope.policyDetailsObj.productCode}



var getpolicyListResponse = RestServices.postService(RestServices.urlPathsNewPortal.getPolicyDetails, policyDetailsInput);
getpolicyListResponse.then(
	function(response) { // success	
	CommonServices.showLoading(false);
						  
		if(response.data.quote !== ""){
			
			$scope.policyInceptionDate=response.data.quote.vehicles[0].vehicleDetails.dateOfFirstPurchaseOfVehicle;
			
			console.log("policy inception date"+$scope.policyInceptionDate);
			
			
		}
		else{
			
		}
			
	},
	function(error) { // failure
		CommonServices.showLoading(false);
		RestServices.handleWebServiceError(error);
});










$scope.documentPhotoUpload={
	uploaddocsmodel : [],
	uploaddocscollection :[]
};



$scope.home = function(){
	$state.go("home");
}

$scope.hideModal = function () {
	$scope.showModal = false;
	$("#upload-options").hide();
}
$scope.endorsementObj={
"hypothecationScreen":false,
"registrationScreen":false,
"policyNumber":$scope.policyDetailsObj.policyNumber,
"policyHolder":$scope.policyDetailsObj.policyHolderName,
"policyStatus":$scope.policyDetailsObj.currentStatus,
"policyStartDate":$scope.policyDetailsObj.policyStartDate,
"policyExpiryDate":$scope.policyDetailsObj.policyExpiryDate,
"selectOption":function(opt){
if(opt=='HYPOTHECATION')
{
	
		  $scope.documentPhotoUpload.uploaddocscollection=[];
	
		 var inputData={"searchQuote":{"policyNumber":$scope.policyDetailsObj.policyNumber,"type":"ADDFINANCE"}};

		var getEndorsStatusResponse = "";
			getEndorsStatusResponse = RestServices.postService(RestServices.urlPathsNewPortal.getEndorsementStatus, inputData);
			getEndorsStatusResponse.then(
				function (response) {
					CommonServices.showLoading(false);
					
					 if(response.data.quote.errorCode =="0") {
						 
						$scope.endorsementObj.optionA="A";
						$scope.endorsementObj.optionB="X";
						$scope.endorsementObj.hypothecationScreen=true;
						$scope.endorsementObj.registrationScreen=false;
						$scope.hist=false; 
					
						
						/**********initialize delete event*****/
						 $(".photo-container").on("click",'.delete-image-icon', function(e){ 
						  e.stopPropagation();
						  var dataval = parseInt(e.currentTarget.getAttribute("dataval"));
						  $scope.loadDeletePopUp(e,dataval);

						});
				   
					 }
					   else {
						  CommonServices.showAlert(response.data.quote.message);
					   }
				 
				},
				function (error) {
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
				});
	
	

}
else
{
	
	
	$scope.documentPhotoUpload.uploaddocscollection=[];
	 var inputData={"searchQuote":{"policyNumber":$scope.policyDetailsObj.policyNumber,"type":"ADDREG"}};

		var getEndorsStatusResponse = "";
			getEndorsStatusResponse = RestServices.postService(RestServices.urlPathsNewPortal.getEndorsementStatus, inputData);
			getEndorsStatusResponse.then(
				function (response) {
					CommonServices.showLoading(false);
					
					 if(response.data.quote.errorCode =="0") {
						 
						$scope.endorsementObj.optionB="B";
						$scope.endorsementObj.optionA="X";
						$scope.endorsementObj.hypothecationScreen=false;
						$scope.endorsementObj.registrationScreen=true;
						$scope.hist=false;
					
					
				   
					 }
					   else {
						  CommonServices.showAlert(response.data.quote.message);
					   }
				 
				},
				function (error) {
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
				});
	
	
	
	
	
	
	
	
	

	
	
	function initializeCalender()
	{
		
		if (mydateStr != undefined) {
			mynewdateFrom = new Date(mydateStr);
		}
		else {
			mynewdateFrom = new Date();
		}
		
			var dd = mynewdateFrom.getDate();
			var mm = mynewdateFrom.getMonth() + 1;
			var yyyy = mynewdateFrom.getFullYear();

			if (dd < 10) {
				dd = "0" + dd;
			}
			if (mm < 10) {
				mm = "0" + mm;
			}
			$scope.startDate = dd + "/" + mm + "/" + yyyy;
			var dateArr=$scope.policyInceptionDate.split("/");
			
			var formattedDate= dateArr[1] + "/" + dateArr[0] + "/" + dateArr[2];
			var dateReg=new Date(formattedDate);
						
		/**Proposer Date of Birth**/

		var enableProposerDOBCalTo = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 51));
		
		var futuredate = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() +15));
		
		/****for loading calender*****/
	
		setTimeout(function(){
			$('#dateOfRegistration').loadCalendar({
		
				'enableDateRange': true,
				'enableCalendarFrom':dateReg,
				'enableCalendarTo': mynewdateFrom
			});
					
			$('#registrationValidityDate').loadCalendar({
			
				'enableDateRange': true,
				'enableCalendarFrom': mynewdateFrom,
				'enableCalendarTo': futuredate
			});
		}, 2000);
		
		
		

		/******loading calender end********/
		
		/**********initialize delete event*****/
		 $(".photo-container").on("click",'.delete-image-icon', function(e){ 
		  e.stopPropagation();
		  var dataval = parseInt(e.currentTarget.getAttribute("dataval"));
		  $scope.loadDeletePopUp(e,dataval);

		});
		
		
		
		
		
		
	}
	
	setTimeout(initializeCalender, 1000)
	
	/*initializing callender***/
	
	
}

},
// "optionA":"A",
// "optionB":"X",
"hypothecationSubmit":function()
{
alert("Hypothecation submit")
},
"financingAgreementType":[],
"selectedAgreementType":"",
"financerName":"",
"dateOfRegistration":"",
"registrationValidityDate":"",
"reg1TW":"",
"reg2TW":"",
"reg3TW":"",
"reg4TW":"",
"status": "",
"uploadDocumentResponse": [],
"remarks": "",
"regNo": "",
"date": "",
"agreementType":"",
"regListASBO":[],
"financeListASBO":[]	
};

$scope.vehicle1FocusOut = function () {
	   var validStateCode = $scope.endorsementObj.reg1TW;
	var statecode = validStateCode.substring(0, 2).toUpperCase();
	var newStateCodeData = {
		"stateCode": statecode
	};
	CommonServices.showLoading(true);

	var StateCodeResponse = RestServices.postService(RestServices.urlPathsNewPortal.stateCode, newStateCodeData);

	StateCodeResponse.then(function (response) {
		CommonServices.showLoading(false);
		if (response.data.footer.errorDescription == "State code is not valid") {
			$scope.reg1ErrorMsg = 'Please enter a valid state code in Reg1';
			$scope.stateCodetrue = true;
		} else {
			$scope.stateCodetrue = false;
		}
	});

};
$scope.vehReg4Length = function (){
	//var validreg4 = buyNow.twoWheeler.additionalDetails.reg4TW;
	if ($scope.endorsementObj.reg4TW == undefined || $scope.endorsementObj.reg4TW.trim() == ''){
	$scope.regValidate = true;
	$scope.reg4ErrorMsg = 'This is a mandatory field';
	}else if ($scope.endorsementObj.reg4TW !== undefined || $scope.endorsementObj.reg4TW.trim() !== ''){
		$scope.regValidate = false;
	}
};
$scope.vehReg1Length = function () {
	$scope.stateCodetrue = false;
	if ($scope.endorsementObj.reg1TW == undefined || $scope.endorsementObj.reg1TW.trim() == '') {
		$scope.reg1ErrorMsg = 'This is a  mandatory field';
		$scope.stateCodetrue = true;

	} else if ($scope.endorsementObj.reg1TW !== undefined) {
		var validStateCode = $scope.endorsementObj.reg1TW;
		if (validStateCode.length < 2) {
			$scope.reg1ErrorMsg = 'Needs to be at least 2 characters long';
			$scope.stateCodetrue = true;
			
		} else if (validStateCode.length >= 3) {
			$scope.buyNow.twoWheeler.additionalDetails.reg2TW = "";
			$scope.buyNow.twoWheeler.additionalDetails.reg3TW = "";
			$scope.reg1ErrorMsg = false;
		}
	}
};

// $scope.vehReg1Length = function () {
// 	if ($scope.endorsementObj.reg1TW !== undefined) {
		
// 		if ($scope.endorsementObj.reg1TW.length >= 3) {
// 			$scope.endorsementObj.reg2TW = "";
// 			$scope.endorsementObj.reg3TW = "";
// 			return false;
// 		}
// 	}
// };			
$scope.calIconClick= function(event)
{
angular.element("#"+ event.currentTarget.children[0].id).focus();  
};
	
$scope.validateAge=function()
{
var dateOfRegistration=$scope.endorsementObj.dateOfRegistration;
var registrationValidityDate=$scope.endorsementObj.registrationValidityDate;

var dateOfRegArray=dateOfRegistration.split("/");
var fromattedDateOfReg =dateOfRegArray[1]+"/"+dateOfRegArray[0]+"/"+dateOfRegArray[2];

var dateRegValArray= registrationValidityDate.split("/");
var formattedDateRegVal=dateRegValArray[1]+"/"+dateRegValArray[0]+"/"+dateRegValArray[2];

var sysdateOfRegistration=new Date(fromattedDateOfReg);
var sysregistrationValidityDate=new Date(formattedDateRegVal);

if(sysregistrationValidityDate.getTime()<sysdateOfRegistration.getTime())
{
CommonServices.showAlert("Registration Validity Date can't be less than Registration Date");
$scope.endorsementObj.dateOfRegistration="";
$scope.endorsementObj.registrationValidityDate="";
}

if(sysdateOfRegistration.getTime()>mynewdateFrom.getTime())
{
CommonServices.showAlert("Registration Date can't be future date");
$scope.endorsementObj.dateOfRegistration="";
}




}








$scope.loadDeletePopUp = function(event,dataval){


var id = "#"+$(event.target).parent().attr("id");

var msg = "Are you sure you want to delete?";
CommonServices.messageModal('info', msg, false, 'No', 'Yes', function () {}, function () {
	$(event.target).parent().remove();
	var myEl = angular.element( document.querySelector(id) );
	myEl.remove();   
	for(var i=0 ; i<$scope.documentPhotoUpload.uploaddocscollection.length; i++) {
		if($scope.documentPhotoUpload.uploaddocscollection[i].documentId===dataval) {
			$scope.documentPhotoUpload.uploaddocscollection.splice(i, 1);
			break;
		}
	}
	var totalImageCount=$(".photo-container img").length;
	var maxImageCount=10;
	if(totalImageCount<maxImageCount) {
		$('.uploadVehPhotoAndr').removeClass("disableCamera");
	}
	}, 'Alert');

//if(evt.currentTarget.getAttribute("class")==="tick-icon"){
//  return false;
//}else{
//   var that = this;
//   $("#popup-container").show();
//   $("#popup-content").show();
//   $("#popup-content").off().on('click',function(){
//     $scope.closePopUp();
//   });

//   $("#btn-yes").off().on('click',function(){
//     $scope.closePopUp();
// 	$(event.target).parent().remove();
//     var myEl = angular.element( document.querySelector(id) );
//     myEl.remove();   
//     for(var i=0 ; i<$scope.documentPhotoUpload.uploaddocscollection.length; i++)
//       {
//         if($scope.documentPhotoUpload.uploaddocscollection[i].documentId===dataval)
//         {
//           $scope.documentPhotoUpload.uploaddocscollection.splice(i,1);
//           break;

//         }
//       }  

//     var totalImageCount=$(".photo-container img").length;
//     var maxImageCount=10;
//     if(totalImageCount<maxImageCount){
//       $('.uploadVehPhotoAndr').removeClass("disableCamera");
//     }
//   });

//   $("#btn-no").off().on('click',function(){
//       $scope.closePopUp();
//   });
// }

};





$scope.startEndorsementSuccess=function()
{
console.log("sucess is called");
$scope.saveEndrosement();
}

$scope.saveEndorsementSuccess=function()
{
console.log("stop endrsement function is called");


	var imageCollection = $scope.documentPhotoUpload.uploaddocscollection;
	var imageCollectionLength=imageCollection.length;

	var documentsList = [];

	for (var i = 0; i < imageCollectionLength; i++) {

		if ($scope.documentPhotoUpload.uploaddocscollection[i].documentIndex === undefined) {
				  var imageList = {
					  "documentName": imageCollection[i].documentName,
					  "docByteString": imageCollection[i].docByteString,
					  "documentType": (imageCollection[i].documentType).toUpperCase()
				  };

		documentsList.push(imageList);
		imageList="";
		}
	}

	if (documentsList.length === 0) {
	   CommonServices.showAlert("No new images to submit","Alert");
	   return;
	}

	var docUploadInput ={
		"userProfile": {
			
			"claims": [
			  {
				"claimNumber": $scope.policyDetailsObj.policyNumber,
				"documentsList": documentsList
			  }
			],
			"userID": CommonServices.getCommonData("userId"),
			"surveyorStatus":"END"
		  }
	}

	var docUploadResponse = RestServices.postService(RestServices.urlPathsNewPortal.custUploadDocuments, docUploadInput);
	docUploadResponse.then(
		function(response) { // success
			CommonServices.showLoading(false);
			
			
			var model = response;

		  for(var i=0 ; i<$scope.documentPhotoUpload.uploaddocscollection.length; i++){
			for (var j = 0; j < model.data.uploadDocumentResponses.length; j++) {
			  if ($scope.documentPhotoUpload.uploaddocscollection[i].documentName == model.data.uploadDocumentResponses[j].documentname) {

				  if(model.data.uploadDocumentResponses[j].documentIndex === undefined){

				  }else{

						   $("#"+$scope.documentPhotoUpload.uploaddocscollection[i].documentId).addClass("tick-icon").removeClass("delete-image-icon");
											  $scope.documentPhotoUpload.uploaddocscollection.splice(i,1);


													var newContent={
														  imageType:model.data.uploadDocumentResponses[j].documentType,
														  documentType:model.data.uploadDocumentResponses[j].documentType,
														  documentName:model.data.uploadDocumentResponses[j].documentname,
														  documentIndex :model.data.uploadDocumentResponses[j].documentIndex,
														  docByteStringUrl:model.data.uploadDocumentResponses[j].documentUrl,
														  User_ID:CommonServices.getCommonData("userId"),
														  Claim_No: $scope.claimNumber
											  };

											  $scope.documentPhotoUpload.uploaddocscollection.push(newContent);

				  }

			  }
			}
		  }
		  
		  if($scope.endorsementObj.optionB=="B")
		  {
			   CommonServices.showAlert("Updation of registration number request has been submitted successfully");
			   $scope.home();
		  }
		  else
		  {
			  CommonServices.showAlert("Addition of Hypothecation request has been submitted successfully");
			  $scope.home();
		  }
	  
		},
		function(error) { // failure
			CommonServices.showLoading(false);
			RestServices.handleWebServiceError(error);
		});


}

$scope.hist=false;

$scope.getEndorsementHist=function()
{
$scope.documentPhotoUpload.uploaddocscollection=[];
$scope.endorsementObj.hypothecationScreen=false;
$scope.endorsementObj.registrationScreen=false;
$scope.hist=true;
var inputData = {"searchQuote":{"policyNumber":$scope.policyDetailsObj.policyNumber,
					   "userCode": CommonServices.getCommonData("userId")}}

var getEndorsHistResponse = "";
	getEndorsHistResponse = RestServices.postService(RestServices.urlPathsNewPortal.getEndorsementHistory, inputData);
	getEndorsHistResponse.then(
		function (response) {
			CommonServices.showLoading(false);
			
			 if(response.data.quote.errorCode =="0") {
				 
				 
				 "regListASBO" in response.data ?  $scope.endorsementObj.regListASBO=response.data.regListASBO : console.log('unknown key')
				 "financeListASBO" in response.data ?  $scope.endorsementObj.financeListASBO=response.data.financeListASBO: console.log('unknown key')
				
				  $(".photo-container").on("click",'img', function(event){

					var eIid=event.currentTarget.getAttribute("id");
					var eSrc=event.currentTarget.getAttribute("src");
					 $("#popup-container").show();
					$("#image-preview").show();
					$("#image-preview img").attr("src",eSrc);
					var imgTarget="#"+eIid;
					 $(document).off('click', '#popup-container');
					 $(document).on('click', '#popup-container', function(){
					   $scope.closePopUp();
					 });
				  });
				
		   
			   } else if(response.data.quote.errorCode == "1"){
				   
				   CommonServices.showAlert(response.data.quote.message);
			   } 
			   else {
				   CommonServices.showAlert(response.data.quote.message);
			   }
		 
		},
		function (error) {
			CommonServices.showLoading(false);
			RestServices.handleWebServiceError(error);
		});


}


$scope.saveEndrosement=function()
{
var inputData="";
var url=RestServices.urlPathsNewPortal.regSaveRequest;


if($scope.endorsementObj.optionB=="B")
{
//url=RestServices.urlPathsNewPortal.regSaveRequest
inputData={

		"searchQuote": {
					"type":"ADDREG",
					"policyNumber":  $scope.policyDetailsObj.policyNumber,
					"userCode": CommonServices.getCommonData("userId"),
					"reg1": $scope.endorsementObj.reg1TW,
					"reg2": $scope.endorsementObj.reg2TW,
					"reg3": $scope.endorsementObj.reg3TW,
					"reg4": $scope.endorsementObj.reg4TW,
					"regDate": $scope.endorsementObj.dateOfRegistration,
					"regValDate":$scope.endorsementObj.registrationValidityDate
					
				  }
			};

}
else
{
//url=RestServices.urlPathsNewPortal.endorsementSaveRequest;
inputData = {

		"searchQuote": {
					"type": "ADDFINANCE",
					"policyNumber":  $scope.policyDetailsObj.policyNumber,
					"userCode": CommonServices.getCommonData("userId"),
					"financiar":$scope.endorsementObj.financerName,
					"financiarType":$scope.endorsementObj.selectedAgreementType.value
				  }
			};

}



var saveEndorsementResponse = "";
	saveEndorsementResponse = RestServices.postService(url, inputData);
	saveEndorsementResponse.then(
		function (response) {
			CommonServices.showLoading(false);
			
			 if(response.data.quote.errorCode == "0") {
				 
				$scope.saveEndorsementSuccess();
		   
			   } else if(response.quote.errorCode == "1"){
				   CommonServices.showAlert(response.data.quote.errorDescription);
			   } 
			   else {
				   CommonServices.showAlert("Problem in start endorsement request. Please try again.");
			   }
		 
		},
		function (error) {
			CommonServices.showLoading(false);
			RestServices.handleWebServiceError(error);
		});


}



$scope.startEndrosement=function()
{

var inputData = {
				  "userProfile": {
					"userId":CommonServices.getCommonData("userId"),
					"loggedInRole": "SUPERUSER"
				  },
				  "quote": {
					"policyNumber": $scope.policyDetailsObj.policyNumber,
					"policyStartDate": $scope.startDate
				  }
			}
var startEndorsementResponse = "";
	startEndorsementResponse = RestServices.postService(RestServices.urlPathsNewPortal.marineStartEndorsement, inputData);
	startEndorsementResponse.then(
		function (response) {
			CommonServices.showLoading(false);
			
			 if(response.data.userProfile.footer.errorCode =="0") {
				 
				 $scope.startEndorsementSuccess();
		   
			   } else if(response.data.userProfile.footer.errorCode == "1"){
				   CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
			   } 
			   else {
				   CommonServices.showAlert("Problem in start endorsement request. Please try again.");
			   }
		 
		},
		function (error) {
			CommonServices.showLoading(false);
			RestServices.handleWebServiceError(error);
		});


}




/******fetching the domain values*******/
$scope.getFinancingAgrmntList = function () {
	  var domainData = {
		"lngCode": "EN",
		"keys": ["FINANCING_AGREEMENT_TYPE"]
	};
	var getDomainResponse = "";
	getDomainResponse = RestServices.postService(RestServices.urlPathsNewPortal.getDomainValues, domainData);
	getDomainResponse.then(
		function (response) {
			CommonServices.showLoading(false);
			for (var i = 0; i < response.data.domainValues.length; i++) {
				var agreementTypes = {
					'name': response.data.domainValues[i].mnemonic,
					'value':response.data.domainValues[i].codeValue
				};
				$scope.endorsementObj.financingAgreementType.push(agreementTypes);
			}
		   
		   
		},
		function (error) {
			CommonServices.showLoading(false);
			RestServices.handleWebServiceError(error);
		});

};


//calling service for getting domain values.
$scope.getFinancingAgrmntList();


$scope.closePopUp = function(){

$("#popup-content").hide();
$("#popup-container").hide();
$("#image-preview").hide();
$("#calendar-container").hide();
$("#timePickerSelectCntr").hide();
$("#upload-options").hide();
$("#slide-container").show();
};





$scope.chooseImageUploadOption=function(event){

// $scope.artID = $(event.target).parent().parent().attr("id");
$scope.artID = $(event.target).parent().parent().parent().attr("id");
$scope.imgCount = $('#'+$scope.artID+' img').length;
$scope.maxImageCount=9;
$scope.totalImageCount=$(".photo-container img").length;

  /**********initialize delete event*****/
		 $(".photo-container").on("click",'.delete-image-icon', function(e){ 
		  e.stopPropagation();
		  var dataval = parseInt(e.currentTarget.getAttribute("dataval"));
		  $scope.loadDeletePopUp(e,dataval);

		});

if($scope.imgCount < 3){
$scope.showModal = true;
$("#upload-options").show();
$("#popup-container").show();
$('.common-overlay').show(); 
$(document).off('click', '#capture-photo-cam');
$(document).on('click', '#capture-photo-cam', function(e) {
$('.common-overlay').hide();
e.stopPropagation();
$scope.pictureFromCam($scope.artID);
$scope.showModal = false;
}); 


$(document).off('click', '#select-photo-gallery');
$(document).on('click', '#select-photo-gallery', function(e) {
$('.common-overlay').hide();
e.stopPropagation();
$scope.pictureFromGallery($scope.artID);
$scope.showModal = false;
}); 

$(document).off('click', '#popup-container');
$(document).on('click', '#popup-container', function(){
	  $scope.closePopUp(); 
	});
}
else{
 CommonServices.showAlert("Maximum 3 document can be uploaded for "+$('#'+$scope.artID+' .doc-label').text());
return false;
}
};

$scope.pictureFromCam = function(event) {
$("#upload-options").hide();
$("#popup-container").hide();
// $('.common-overlay').hide();
$scope.capturePhoto($scope.artID,true);
$scope.showModal = false;
};


$scope.pictureFromGallery = function(event){ 
$("#upload-options").hide();
$("#popup-container").hide();
$scope.capturePhoto($scope.artID,false);
$scope.showModal = false;
};

$scope.fetchDoc = function(url, docName) {
try {
	 window.appRootDirName = "NIAAgentDoc";
	 window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, CommonServices.gotFS, CommonServices.fail);

	var fileTransfer = new FileTransfer();
	var url = url;
	var filePath;
	var docName = docName;


	if(navigator.userAgent.match(/iPhone|iPad|iPod/i)){
	   filePath = window.appRootDir.nativeURL +docName;
	}
	else if(navigator.userAgent.match(/Android/i)){

	   filePath = fileSystem.root.toURL() + "NIAAgentDoc/" + docName;
	}
	else{
	   filePath = false;
	}
	CommonServices.showLoading(false);

		fileTransfer.download(url, filePath, function(theFile) {
			if(navigator.userAgent.match(/iPhone|iPad|iPod/i)){
			 window.open(url , '_system', 'location=no');
			}
			else if(navigator.userAgent.match(/Android/i)){
			window.open(filePath , '_system', 'location=no');
			}
		},
		function(error) {

			 CommonServices.showAlert("Download not successful, please try again after some time");
			 CommonServices.showLoading(false);
		},
		true
	);

} catch (err) {

	$scope.counter = false;
	CommonServices.showLoading(false);
	CommonServices.showAlert("Please insert SD Card to download documents");
} finally {

}
};







$scope.capturePhoto = function(event,fromCam) {


if (fromCam){
  
  
if(CommonServices.deviceType == "A"){
  navigator.camera.getPicture($scope.onSuccessImageUploadAndroid,$scope.onFailImageUploadAndroid,{quality: 85,destinationType: 0,targetWidth: 2048,targetHeight: 2048 });
}else if(CommonServices.deviceType == "I"){
  navigator.camera.getPicture($scope.onSuccessImageUploadAndroid,$scope.onFailImageUploadAndroid,{quality: 50,destinationType: 0,targetWidth: 2048,targetHeight: 2048 });
} else {
	 var fileURI="/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAUDBAQEAwUEBAQFBQUGBwwIBwcHBw8LCwkMEQ8SEhEPERETFhwXExQaFRERGCEYGh0dHx8fExciJCIeJBweHx7/2wBDAQUFBQcGBw4ICA4eFBEUHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh7/wAARCASACAADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD5dRFUbcE+tOUADFAJHB5PtSgHk96x1NEhMAIelInAz1pxBIpEA/OgVhyj5e9C455oOM5OePehcA5x1osINqk7iMkVSkObvNaBPHtVCUYuVB6HihBcnUAn0qYsD8o9OtMABHHGOKVQM5PagBQDt44xTgTnk0Ee/FKoHWmNEiKeOe9XY0OzntVWHG4A85NXhgA5yaVx2CMHOGxnpUqkY5pIxnrj2p4FG4hVJHHJHY0bQWyMcUdcAZ4pFOSenFKwDgRwR16U1uhXjFISd2M8UsgB9KQzP1k7LFgOPWuewPvY61u+JSDbqg4yRWCuMGrRDQ5elOUY+WmhSV9u1SKD1AzjtVoSI7kkAD3pFGQMUsp3cEYpqjAzmkhDsHJxSjI6dKTtzS8CgBVBz0xRkY4Xkd6XBIxk4pVHagAUDHUZpOcmnIuM96cMdMipEMBx1FKMlj2oxjPOaBgnj9aoA5J9qVRgE/pQA2OMcU9AecHNAXAAkHJpU3BcZpQMqfrTckg+lAK4vPqCKaCW+nanKMrSr1IxgjvQLcjlHyFR8vrSxkBMDNJN90Fs8075ABnI4q4lIUAnvgdqBgAjvRgnnHApcAnAqwYIB05oHyggHnvQpAGP1prfeyBSEO/iGKdxzgfWmZOeOKUDPBPNAC9/pQclsnoOtHsaQD5sE/jSsA7Iz1696cOlIMAZHHagEnkcVSAByQeeKeSQcHpTSwAzkelKuTkUBEQrhST2qg27ec1oPkKe/FZ7YycdzQBLaD98D+VdR4MUN4hti5zlyPwOa5i05kJzjjFdX4Hw3iG35PGf5dKhvQEepsMHHUVyPiZDJrrRTCRQ0QKkDj0FdZqQuWsnNkyLN/CWGRXKXer6o159ludOhmlQfdAJ/Ks0UZFiqLNayQzuHEoDpuPBBr0FSdrM2CT1HvXHW1zaf2vH9q0p4biRxgldpB6Z5612ZQc7R06CqkIytJQm1lPA+c+3etKLIiXkZI61m6ZuNpKWbgyNge2TWogyir0GKzKSQ61XNxjI6ZFX+ScelUbXi43Y3HpV6STYhkbAUDmpNEMmKL3BNRlSQcgYPFZmozxSXMIW4AjbqQcc1YhtmWXzIrtvdSQQRTSEy05CKWwTgdqyoRiNgOMHNbLjCkdSBmsePBRmPOSaoRY0lc3zDHVK2FBxkd+1ZWi5N++T/B09K2ABkjFSxoYpDBsnkU5ABz3HApcJsycCjsMCkwSEVCec5pygEkDtTuNvHHHSkydx/SgBGXPC0oUjJ7GlX15zTgMNlsigYwAEcDp3xQBwTinAZJ44NOBGNo7dqAIguTvY4xTs53cnFOKk55P+NBXK454oFYjIA+YD3pwII6fpQo2dyTTsZPB70WAYfvYGeacvy/N3p+McjrRtAODigZHzksO9KmclT360o75NO7//AFqYkRhcMeMYOaCuSSTz34qROBzxikYFu/BpoQ1cjJHU8UqY2sBwaUfKSo60pXAySKYDVXdntilPGcDk0cE9aVQe1KwDAGKcjHH5UpPyYyPanDOTxkZo7YxSAOp/DrQF68jFOwd3bpSKuc9hVIBhOWA6CpAB0pGXsP0pw+U8nk0hIawLN2GKAOtOGQfTvSMegpDEAwcYz9KbsxzjtUgUAZJGfWgZLHnjFNCGqc/LS4xinDuM80jHgnFAIMAjkdqRepA7UDdnPalXIPy1IxMcc9e1ABP3h1FOAwMnAoAYsT2FG4CA5zgdKMe/SnDp05pBgcnrTSEIF79DTSpLcgcU87ipJx+dISxwVGKoQ3gHHfNKBhTS7cAs2KUDjnoRSYIYmSuKdghccc0cZwMgUYznPepSHcRMcg4xS4xgilxx9KGGfuimKw0/e4pQoAwTmjoc0AfNz0pgNUAg46UZwMDrUg28jntSHAHvQkDZHyozjrS4IB560KDltxpR19j6UxCHsBS/dUgd6MYxk5OKcM7ecUmC0G4G3JPtSdXB9BQFIb5TxTj8vTueTRYdxGbA25xxQBgc0qqM5IyaPvE88UARoSWwF4px4+XqBThnHy0AYXPfFADEwATjHHU0R5PJo5Yc0p44HJphcQ5PINKAQD+XFKuNvv3pEPJzxn1pBYaQVXPbNI2HcgnJqQ89BSPwfehAMCqDx1owQaXHy5HpRg4+nWkwSEK8Zx7U0gbSDzT+gIzSBcd8CkUNRdq574poXAyOfan478+1LkHhSeOlNCK+csc9ulPI+XGB044p5X5Cx+9TeTmmK4zaByaawXAA4GamAGAMUhUDjigLXIWyy7RSMoSPk5qVVG7I6fWmkA85NG4iIbd27GSaxfEEiJLGtxatKshCo6MMg4NbhB3Y7fyrJ8QqjWxb94jwOJI2HqBQhFPSLqT+0ks383ymRiqyg5GPQ1ur9zrWJpbS3upwTzurGBCFwuODW4B/LrTGRuuR92mjk5xyDUgGAKB9zOO9QykMbrjNMxxipece4pj9BtBGaAIsDn0pGU/41JsXZk9aRVzyTgCqTFYi2+tAAIxxT2GCSOaaVBPTtQBEw5PFNKhiMjFS45JxSMN3QdOtMViLH3hg5+lJsGM1ISTxjFIVyMcikNEWwbSCMAVGSVY/pU5GOSM5pjAlgMjGKQWIynynNN2j1qUg5wQaaygDO7n2osBFzkjjAoGcUoU8gAkGlAAzwevSmMgHOS/HNAw3JzUhA3HGfpSFAVOKAImJYkc4ppwcj86eBjrjHrTTyGAH/wBegaImGBx0poBGeM1M4+UL7daYBjjP44pgMPHY/WmkZyO9SYypyTUeOpHNAAQQee1RkADOD6CpON24nBxSE5XPoaAIhySSOvWmnGOOtSAHByRmmYBB5xQA3cM9hTTg+oNO2jGcc01xjr1JxQBGSN3FJjPtSuAM4/Sm9RkMaQhhVWyGRWAOOaglsrMqQ9tEc9flBqztwP60wjIJ6ihAZ0ui6PId32RVJ/u8VWl8L6UwJjMqH68flitcjB+U03+v6VSk0KxzsvhK2Kny7t1/3lqm3hO4AJjmibj+I4rrSQ3ykHJHemgEDsfTiqUxcpxE3hrUUJKRK4H91s5qpNpF/ENzWkuM44Gf5V6EGdCSDjFAdtoxxinzgoHmb2lwrcwyAj1UiomSQfwtgV6e7K+Q8Yb6iq8trZSDc9tGSfbFCaDlPNdrE9PzpQzA4Fd/Jo+mSE/6MFJ9+lU5fDdgc7HkU9jwadxcpxoY4PFGa6ebwvwTFe";
	 this.onSuccessImageUploadAndroid(fileURI);
}





}else{
  
	if(CommonServices.deviceType == "A"){
		 navigator.camera.getPicture($scope.onSuccessImageUploadAndroid,$scope.onFailImageUploadAndroid,{quality: 85,destinationType: 0,sourceType: 0,targetWidth: 2048,targetHeight: 2048,encodingType: Camera.EncodingType.JPEG });
}else if(CommonServices.deviceType == "I"){
 navigator.camera.getPicture($scope.onSuccessImageUploadAndroid,$scope.onFailImageUploadAndroid,{quality: 50,destinationType: 0,sourceType: 0,targetWidth: 2048,targetHeight: 2048,encodingType: Camera.EncodingType.JPEG });
} else {
	 var fileURI="/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAUDBAQEAwUEBAQFBQUGBwwIBwcHBw8LCwkMEQ8SEhEPERETFhwXExQaFRERGCEYGh0dHx8fExciJCIeJBweHx7/2wBDAQUFBQcGBw4ICA4eFBEUHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh7/wAARCASACAADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD5dRFUbcE+tOUADFAJHB5PtSgHk96x1NEhMAIelInAz1pxBIpEA/OgVhyj5e9C455oOM5OePehcA5x1osINqk7iMkVSkObvNaBPHtVCUYuVB6HihBcnUAn0qYsD8o9OtMABHHGOKVQM5PagBQDt44xTgTnk0Ee/FKoHWmNEiKeOe9XY0OzntVWHG4A85NXhgA5yaVx2CMHOGxnpUqkY5pIxnrj2p4FG4hVJHHJHY0bQWyMcUdcAZ4pFOSenFKwDgRwR16U1uhXjFISd2M8UsgB9KQzP1k7LFgOPWuewPvY61u+JSDbqg4yRWCuMGrRDQ5elOUY+WmhSV9u1SKD1AzjtVoSI7kkAD3pFGQMUsp3cEYpqjAzmkhDsHJxSjI6dKTtzS8CgBVBz0xRkY4Xkd6XBIxk4pVHagAUDHUZpOcmnIuM96cMdMipEMBx1FKMlj2oxjPOaBgnj9aoA5J9qVRgE/pQA2OMcU9AecHNAXAAkHJpU3BcZpQMqfrTckg+lAK4vPqCKaCW+nanKMrSr1IxgjvQLcjlHyFR8vrSxkBMDNJN90Fs8075ABnI4q4lIUAnvgdqBgAjvRgnnHApcAnAqwYIB05oHyggHnvQpAGP1prfeyBSEO/iGKdxzgfWmZOeOKUDPBPNAC9/pQclsnoOtHsaQD5sE/jSsA7Iz1696cOlIMAZHHagEnkcVSAByQeeKeSQcHpTSwAzkelKuTkUBEQrhST2qg27ec1oPkKe/FZ7YycdzQBLaD98D+VdR4MUN4hti5zlyPwOa5i05kJzjjFdX4Hw3iG35PGf5dKhvQEepsMHHUVyPiZDJrrRTCRQ0QKkDj0FdZqQuWsnNkyLN/CWGRXKXer6o159ludOhmlQfdAJ/Ks0UZFiqLNayQzuHEoDpuPBBr0FSdrM2CT1HvXHW1zaf2vH9q0p4biRxgldpB6Z5612ZQc7R06CqkIytJQm1lPA+c+3etKLIiXkZI61m6ZuNpKWbgyNge2TWogyir0GKzKSQ61XNxjI6ZFX+ScelUbXi43Y3HpV6STYhkbAUDmpNEMmKL3BNRlSQcgYPFZmozxSXMIW4AjbqQcc1YhtmWXzIrtvdSQQRTSEy05CKWwTgdqyoRiNgOMHNbLjCkdSBmsePBRmPOSaoRY0lc3zDHVK2FBxkd+1ZWi5N++T/B09K2ABkjFSxoYpDBsnkU5ABz3HApcJsycCjsMCkwSEVCec5pygEkDtTuNvHHHSkydx/SgBGXPC0oUjJ7GlX15zTgMNlsigYwAEcDp3xQBwTinAZJ44NOBGNo7dqAIguTvY4xTs53cnFOKk55P+NBXK454oFYjIA+YD3pwII6fpQo2dyTTsZPB70WAYfvYGeacvy/N3p+McjrRtAODigZHzksO9KmclT360o75NO7//AFqYkRhcMeMYOaCuSSTz34qROBzxikYFu/BpoQ1cjJHU8UqY2sBwaUfKSo60pXAySKYDVXdntilPGcDk0cE9aVQe1KwDAGKcjHH5UpPyYyPanDOTxkZo7YxSAOp/DrQF68jFOwd3bpSKuc9hVIBhOWA6CpAB0pGXsP0pw+U8nk0hIawLN2GKAOtOGQfTvSMegpDEAwcYz9KbsxzjtUgUAZJGfWgZLHnjFNCGqc/LS4xinDuM80jHgnFAIMAjkdqRepA7UDdnPalXIPy1IxMcc9e1ABP3h1FOAwMnAoAYsT2FG4CA5zgdKMe/SnDp05pBgcnrTSEIF79DTSpLcgcU87ipJx+dISxwVGKoQ3gHHfNKBhTS7cAs2KUDjnoRSYIYmSuKdghccc0cZwMgUYznPepSHcRMcg4xS4xgilxx9KGGfuimKw0/e4pQoAwTmjoc0AfNz0pgNUAg46UZwMDrUg28jntSHAHvQkDZHyozjrS4IB560KDltxpR19j6UxCHsBS/dUgd6MYxk5OKcM7ecUmC0G4G3JPtSdXB9BQFIb5TxTj8vTueTRYdxGbA25xxQBgc0qqM5IyaPvE88UARoSWwF4px4+XqBThnHy0AYXPfFADEwATjHHU0R5PJo5Yc0p44HJphcQ5PINKAQD+XFKuNvv3pEPJzxn1pBYaQVXPbNI2HcgnJqQ89BSPwfehAMCqDx1owQaXHy5HpRg4+nWkwSEK8Zx7U0gbSDzT+gIzSBcd8CkUNRdq574poXAyOfan478+1LkHhSeOlNCK+csc9ulPI+XGB044p5X5Cx+9TeTmmK4zaByaawXAA4GamAGAMUhUDjigLXIWyy7RSMoSPk5qVVG7I6fWmkA85NG4iIbd27GSaxfEEiJLGtxatKshCo6MMg4NbhB3Y7fyrJ8QqjWxb94jwOJI2HqBQhFPSLqT+0ks383ymRiqyg5GPQ1ur9zrWJpbS3upwTzurGBCFwuODW4B/LrTGRuuR92mjk5xyDUgGAKB9zOO9QykMbrjNMxxipece4pj9BtBGaAIsDn0pGU/41JsXZk9aRVzyTgCqTFYi2+tAAIxxT2GCSOaaVBPTtQBEw5PFNKhiMjFS45JxSMN3QdOtMViLH3hg5+lJsGM1ISTxjFIVyMcikNEWwbSCMAVGSVY/pU5GOSM5pjAlgMjGKQWIynynNN2j1qUg5wQaaygDO7n2osBFzkjjAoGcUoU8gAkGlAAzwevSmMgHOS/HNAw3JzUhA3HGfpSFAVOKAImJYkc4ppwcj86eBjrjHrTTyGAH/wBegaImGBx0poBGeM1M4+UL7daYBjjP44pgMPHY/WmkZyO9SYypyTUeOpHNAAQQee1RkADOD6CpON24nBxSE5XPoaAIhySSOvWmnGOOtSAHByRmmYBB5xQA3cM9hTTg+oNO2jGcc01xjr1JxQBGSN3FJjPtSuAM4/Sm9RkMaQhhVWyGRWAOOaglsrMqQ9tEc9flBqztwP60wjIJ6ihAZ0ui6PId32RVJ/u8VWl8L6UwJjMqH68flitcjB+U03+v6VSk0KxzsvhK2Kny7t1/3lqm3hO4AJjmibj+I4rrSQ3ykHJHemgEDsfTiqUxcpxE3hrUUJKRK4H91s5qpNpF/ENzWkuM44Gf5V6EGdCSDjFAdtoxxinzgoHmb2lwrcwyAj1UiomSQfwtgV6e7K+Q8Yb6iq8trZSDc9tGSfbFCaDlPNdrE9PzpQzA4Fd/Jo+mSE/6MFJ9+lU5fDdgc7HkU9jwadxcpxoY4PFGa6ebwvwTFe";
	 this.onSuccessImageUploadAndroid(fileURI);
}
  

}









};


$scope.onSuccessImageUploadAndroid = function(fileURI) {

var height=$("#document-upload-wrapper").height();
var fileURISize = sizeof(fileURI)/(1024*2.67);

if(fileURISize>1&&fileURISize<=500){
var that=this;
var queryString;
var fileDATAURI = fileURI;
var rId= Math.floor(Math.random() * (999 - 100 + 1)) ;
var imageType=$('#'+$scope.artID+' .doc-label').text();
var fileNamePrefix=rId;
var newFileName=imageType+"_"+fileNamePrefix+".JPG";
var newFileName1=imageType.replace(/ /g,"_")+"_"+fileNamePrefix+".JPG";
var imageId = fileNamePrefix +"-img";
var content;
var docType=$("#"+$scope.artID).attr("doc-type");
var uniqueId=fileNamePrefix+"_input"

//$scope.documentPhotoUpload.uploaddocsmodel.push(content);
if(docType=='INTERMEDIARY-DOCUMENT')
{
	
	$("#"+$scope.artID+" .photo-container").append("<div class='image-conatiner' dataval="+fileNamePrefix+" id="+newFileName1+"><img id ="+imageId+" data="+newFileName+" dataval="+fileNamePrefix+"  src='data:image/JPEG;base64,"+fileDATAURI+"' /><span class='delete-image-icon' dataval="+fileNamePrefix+" datasuccess="+newFileName+" id="+fileNamePrefix+" ></span><input ng-minlength='1' ng-maxlength='30' type='text' id="+uniqueId+" name='financerName' class='form-control'  data-ng-pattern='/^[a-zA-Z][a-zA-Z'. &\s]*$/' placeholder='Document Name' required /></div>");
	
}
else
{
	$("#"+$scope.artID+" .photo-container").append("<div class='image-conatiner' dataval="+fileNamePrefix+" id="+newFileName1+"><img id ="+imageId+" data="+newFileName+" dataval="+fileNamePrefix+"  src='data:image/JPEG;base64,"+fileDATAURI+"' /><span class='delete-image-icon' dataval="+fileNamePrefix+" datasuccess="+newFileName+" id="+fileNamePrefix+" ></span></div>");
}


//$scope.watermark(imageId);
content={
	imageType:imageType,
	documentName:newFileName1,
	documentId :fileNamePrefix,
	docByteString:$('#'+imageId).attr('src').slice(23),
	User_ID:CommonServices.getCommonData('userId'),
	documentType:docType
};
$scope.documentPhotoUpload.uploaddocscollection.push(content);
} else {
CommonServices.showAlert( "Image size should be less than 1MB" );
return false;
}
};



$scope.createEndorsementRequest=function()
{
/********validating data for others*********/
var imageCollection = $scope.documentPhotoUpload.uploaddocscollection;
var imageCollectionLength=imageCollection.length;

	var documentsList = [];
	var otherDocArray=[];

	for (var i = 0; i < imageCollectionLength; i++) {

		if ($scope.documentPhotoUpload.uploaddocscollection[i].documentIndex === undefined) {
			
			if((imageCollection[i].documentType).toUpperCase()=='INTERMEDIARY-DOCUMENT')
			{
				 
				 if($("#"+imageCollection[i].documentId+"_input").val()=="")
				 {
					 CommonServices.showAlert("Please provide name for other document type");
					 return;
				 }
				 else if($("#"+imageCollection[i].documentId+"_input").val().length>30)
				 {
					  CommonServices.showAlert("Document name must be less than 30 character.!");
					 return;
				 }
				 else
				 {
					 
					 var otherDocName=$("#"+imageCollection[i].documentId+"_input").val();
					 var isDuplicate = otherDocArray.includes(otherDocName);
					 if(isDuplicate)
					 {
						  CommonServices.showAlert("Document name cannot be same");
						  return;
					 }
					 else
					 {
						  otherDocArray.push(otherDocName);
						  imageCollection[i].documentName=$("#"+imageCollection[i].documentId+"_input").val()+".JPG";
				 }				 
			}				 
			}
		
		}
	}


if($(".photo-container img").length=== 0){
		//alert("no images");
		CommonServices.showAlert("No images to submit");
		return false;
	  }



if($scope.endorsementObj.optionB=="B")
{
	
	if ($('#reg-certificate').find("img").length == 0) { CommonServices.showAlert("Please upload the mandatory document for Registration Certificate");return false;};

}
else
{
	  if ($('#letter-of-endorsement').find("img").length == 0) { CommonServices.showAlert("Please upload the mandatory document for Insured Letter for Endorsement Request");return false;};
	
}




$scope.startEndrosement();


	


}



}]);

/*******NP_CR_3626 End************/
agentApp.controller('viewPolicyController', ['$scope','RestServices','CommonServices','$state', function ($scope, RestServices,CommonServices,$state) {
$scope.policyDetailsList = {};
var productCode = '';
$scope.init = function(){

var getPolicyListInput = CommonServices.getCommonData("policyDetailsInput");
var getpolicyListResponse = RestServices.postService(RestServices.urlPathsNewPortal.getPolicyDetails, getPolicyListInput);
getpolicyListResponse.then(
	function(response) { // success	
	CommonServices.showLoading(false);
						  
		if(response.data.quote !== ""){
			if(response.data.quote.policyDuration === "1"){
				if(response.data.quote.policyDurationUnit.toUpperCase() === "YEARS"){
					response.data.quote.policyDurationUnit = "Year";
				}
				if(response.data.quote.policyDurationUnit.toUpperCase() === "MONTHS"){
					response.data.quote.policyDurationUnit = "Month";
				}
				if(response.data.quote.policyDurationUnit.toUpperCase() === "DAYS"){
					response.data.quote.policyDurationUnit = "Day";
				}
			}
			$scope.policyDetailsList = response.data.quote;
			productCode = $scope.policyDetailsList.productCode;
			getRisks();     
			fetchDocument();
		}
		else{
			
		}
			
	},
	function(error) { // failure
		CommonServices.showLoading(false);
		RestServices.handleWebServiceError(error);
});

};

var getRisks =function(){
$scope.policyDetailsList.riskData=[];
var input1='';
var input2 ='';
if(productCode === 'PC' || productCode === 'TW' || productCode === 'CV' || productCode === 'SQ' || productCode === 'SS'){ /* CR_NP_3621 */
	var cover = $scope.policyDetailsList.vehicles[0].vehicleDetails;
	input1 = ((cover.registrationNo1)?cover.registrationNo1:'')+
	(((cover.registrationNo2) && cover.registrationNo2 !== '0')?cover.registrationNo2:'')+
	(((cover.registrationNo3) && cover.registrationNo3!=='none')?cover.registrationNo3:'')+
	((cover.registrationNo4)?cover.registrationNo4:'');

	if(!input1 || input1 === 'NEW0none0001' || input1 === 'NEW0001'){
		input1 = 'NEW VEHICLE';
	}
	input2 =  $scope.policyDetailsList.sumInsured;
	$scope.policyDetailsList.coverageCode = $scope.policyDetailsList.vehicles[0].coverages[0].coverageDetails.coverage;
	generalRiskDetails(input1,input2);
}else if(productCode === 'BH' || productCode === 'ES'){
	input1 = $scope.policyDetailsList.policyHolderName;
	input2 =  $scope.policyDetailsList.sumInsured;
	$scope.policyDetailsList.coverageCode = $scope.policyDetailsList.coverCode;
	generalRiskDetails(input1,input2);
}else if(productCode === 'SV'){
	$scope.policyDetCtrl.polDetailsObj.cover=[];
	input2 =  $scope.policyDetailsList.risks[0].riskSumInsured;
	for(var i=0;i<$scope.policyDetCtrl.polDetailsObj.risks[0].riskDetails.cargoDetails.coverageDetails.length;i++){
		$scope.policyDetCtrl.polDetailsObj.cover[i]=$scope.policyDetCtrl.polDetailsObj.risks[0].riskDetails.cargoDetails.coverageDetails[i];
	}
	generalRiskDetails(input1,input2);
}else if(productCode === 'PB'){
	input2 =  $scope.policyDetailsList.sumInsured;
	generalRiskDetails(input1,input2);
}else{
	$scope.policyDetailsList.coverageCode = $scope.policyDetailsList.coverCode;
	for(var i=0;i<$scope.policyDetailsList.risks.length;i++){
		if(($scope.policyDetailsList.risks[i].riskCode)
				|| ($scope.policyDetailsList.risks[i].riskDescription)){
			input1 = (productCode === 'PQ')?$scope.policyDetailsList.risks[i].riskCode : $scope.policyDetailsList.risks[i].riskDescription;
			input2 =  $scope.policyDetailsList.risks[i].riskSumInsured;
		}else  if(($scope.policyDetailsList.risks[i].riskDetails)){
			input1 = $scope.policyDetailsList.risks[i].riskDetails.nameOfInsuredPerson;
			if(productCode === 'PU' || productCode === 'AP'){
				input2= (($scope.policyDetailsList.risks[i].riskDetails.sumInsuredForTableA)?parseInt($scope.policyDetailsList.risks[i].riskDetails.sumInsuredForTableA):0)
				+(($scope.policyDetailsList.risks[i].riskDetails.sumInsuredForTableB)?parseInt($scope.policyDetailsList.risks[i].riskDetails.sumInsuredForTableB):0)
				+(($scope.policyDetailsList.risks[i].riskDetails.sumInsuredForTableC)?parseInt($scope.policyDetailsList.risks[i].riskDetails.sumInsuredForTableC):0)
				+(($scope.policyDetailsList.risks[i].riskDetails.sumInsuredForTableD)?parseInt($scope.policyDetailsList.risks[i].riskDetails.sumInsuredForTableD):0);
			}else{
				input2 = $scope.policyDetailsList.risks[i].riskSumInsured;
			}
		}
		generalRiskDetails(input1,input2);
	}
}

};
var generalRiskDetails = function(riskNameVal,riskSumInsuredVal){

$scope.policyDetailsList.riskData.push({
	'riskName' : riskNameVal,
	'riskSumInsured': (riskSumInsuredVal)?riskSumInsuredVal:0
});
};

$scope.refresh= function(){
fetchDocument();
}
function fetchDocument(){
	//Fetch Document Service Call
	var fetchDocumentInput = {
			"userProfile":{
				"userId":CommonServices.getCommonData("userId"),
				"loggedInRole":CommonServices.getCommonData("loggedInRole")
			},
			"quote":{
				"policyNumber": $scope.policyDetailsList.policyNumber,
				"policyId":$scope.policyDetailsList.policyId
			}
		} ;

	var fetchDocResponse = RestServices.postService(RestServices.urlPathsNewPortal.fetchDocumentName, fetchDocumentInput);
	fetchDocResponse.then(
		function(response) { // success
			CommonServices.showLoading(false);

			if(response.data.documentDeatils !== undefined){
				$scope.documentDeatils = response.data.documentDeatils;
				$scope.docFlag = false;
			}
			else{
				if(response.data.errorMessage !== undefined){
					$scope.documentmessage = response.data.errorMessage;
					CommonServices.showAlert($scope.documentmessage);
				   // $scope.documentFlag = true;
					$scope.docFlag = true;
				}
			}

		},
		function(error) { // failure
			CommonServices.showLoading(false);
			RestServices.handleWebServiceError(error);
	});
}
$scope.goBack= function(){
$state.go("managePolicies.managePolicies");
}

$scope.fetchDoc = function(url, docName) {
try {
	 window.appRootDirName = "NIAAgentDoc";
	 window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, CommonServices.gotFS, CommonServices.fail);

	var fileTransfer = new FileTransfer();
	var url = url;
	var filePath;
	var docName = docName;


	if(navigator.userAgent.match(/iPhone|iPad|iPod/i)){
	   filePath = window.appRootDir.nativeURL +docName;
	}
	else if(navigator.userAgent.match(/Android/i)){

	   filePath = fileSystem.root.toURL() + "NIAAgentDoc/" + docName;
	}
	else{
	   filePath = false;
	}
	CommonServices.showLoading(false);

		fileTransfer.download(url, filePath, function(theFile) {
			if(navigator.userAgent.match(/iPhone|iPad|iPod/i)){
			 window.open(url , '_system', 'location=no');
			}
			else if(navigator.userAgent.match(/Android/i)){
			window.open(filePath , '_system', 'location=no');
			}
		},
		function(error) {

			 CommonServices.showAlert("Download not successful, please try again after some time");
			 CommonServices.showLoading(false);
		},
		true
	);

} catch (err) {

	$scope.counter = false;
	CommonServices.showLoading(false);
	CommonServices.showAlert("Please insert SD Card to download documents");
} finally {

}
};

$scope.init();

}]);

agentApp.controller('claimListController', ['$scope','RestServices','CommonServices','$state', function ($scope, RestServices,CommonServices,$state) {

//Back Button Start
$scope.home = function(){
	$state.go("home");
}
//Back Button End
//Search Click Start
$scope.searchClick = function(){
	$scope.manageClaimObj.searchField = true;
}
//Search Click End

//Creating manage Claim Object
$scope.manageClaimObj ={
	searchField: true,
	invalidInput: true,
	claimSearch: function(){
		if(this.searchText !== "" && this.searchText !== undefined){
			var claimData = JSON.stringify({"policyNo":[this.searchText],"userId":CommonServices.getCommonData("userId")});
			var ClaimSearchResponse = RestServices.postService(RestServices.urlPathsNewPortal.getClaimList, claimData)

			ClaimSearchResponse.then(
				function(response) { // success
					CommonServices.showLoading(false);
					if(response.data !== ""){

						if(response.data.getClaimListResponses === undefined){
							if(response.data.errorMessage === "No record found" || response.data.errorMessage === undefined){
								CommonServices.showAlert("No Data found. Please enter valid Claim/Policy number.");
							}
							else{
								CommonServices.showAlert(response.data.errorMessage);
							}
							
						}
						else{
							$scope.myClaimList = response.data.getClaimListResponses;
						}
					}
										
				},
				function(error) { // failure
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
				}
			);
		}
		else{
			CommonServices.showAlert("Please enter Policy/Claim Number");
		}
	},
	policyDetails: function(item){
		CommonServices.setCommonData('claimSearchDetail',item);
		$state.go('managePolicies.claimSearchDetails'); 
	}
}

$scope.intimateClaim= function(){

		$scope.quotePolicyData = {
			"userProfile": {
				"userId": CommonServices.getCommonData("userId"),
				"loggedInRole": CommonServices.getCommonData("loggedInRole"),
				"searchQuote": {
					"productCode": "",
					"productName": null,
					"policyNumber": $scope.manageClaimObj.searchText,
					"startDate": "",
					"endDate": "",
					"status": null,
					"resultSize": 5,
					"startIndex": 1,
					"totalResults": 0
				}
			}
		}

		var quotePolicyResponse = RestServices.postService(RestServices.urlPathsNewPortal.getPolicyList, $scope.quotePolicyData);
		quotePolicyResponse.then(
			function(response) { // success

				//CommonServices.showAlert(response.data.userProfile.footer.status);
				CommonServices.showLoading(false);
				if(response.data.quotes.length === 0){
					CommonServices.showAlert(response.data.message);
				}
				else{
					CommonServices.setCommonData("policyNumber", response.data.quotes[0]);
					$state.go("managePolicies.intimateClaim");

				}

			},
			function(error) { // failure
				CommonServices.showLoading(false);
				RestServices.handleWebServiceError(error);
		});

}	
	
}]);


agentApp.controller('claimDetailsController', ['$scope','RestServices','CommonServices','$state', function ($scope, RestServices,CommonServices,$state) {
$scope.claimDetail = CommonServices.getCommonData('claimSearchDetail');

//Home Click Start
$scope.home = function(){
$state.go("managePolicies.claims");
}
//Home Click End

var claimData = JSON.stringify({"policyNo":[$scope.claimDetail.claimNumber]});
var ClaimSearchResponse = RestServices.postService(RestServices.urlPathsNewPortal.getClaimList, claimData)

ClaimSearchResponse.then(
function(response) { // success
	$scope.claimSearchDetail = response.data.getClaimListResponses;
	CommonServices.setCommonData("policyNumber",$scope.claimSearchDetail[0]);
	CommonServices.showLoading(false);
},
function(error) { // failure
	CommonServices.showLoading(false);
	RestServices.handleWebServiceError(error);
}
);

$scope.uploadDoc = function(){
$state.go("managePolicies.docUpload");
}
$scope.viewDoc= function(){
$state.go("managePolicies.viewUploadedDoc");
}

}]);

agentApp.controller('intimateClaimScrController', ['$scope','RestServices','CommonServices','$state', function ($scope, RestServices,CommonServices,$state) {

$scope.fetchClaimIntimateList = function(){
$state.go("managePolicies.intimateClaimForm");
}

$scope.home = function(){
$state.go("managePolicies.claims");
}

$scope.docUploadFunc = function(){
$state.go("managePolicies.docUpload");
}

$scope.viewUploadedDocFunc = function(){
$state.go("managePolicies.viewUploadedDoc");
}


}]);


agentApp.controller('intimateClaimFormController', ['$scope','RestServices','CommonServices','$state','$timeout', function ($scope, RestServices,CommonServices,$state,$timeout) {

$scope.policyList = CommonServices.getCommonData('policyList');

$scope.home = function(){
$state.go("managePolicies.managePolicies");
}
var policyStartdate = CommonServices.getCommonData("policyNumber").policyStartDate;

function calTime(time){

var hours = Number(time.match(/^(\d+)/)[1]);
var minutes = Number(time.match(/:(\d+)/)[1]);
var AMPM = time.match(/\s(.*)$/)[1];
if(AMPM == "PM" && hours<12) hours = hours+12;
if(AMPM == "AM" && hours==12) hours = hours-12;
var sHours = hours.toString();
var sMinutes = minutes.toString();
if(hours<10) sHours = "0" + sHours;
if(minutes<10) sMinutes = "0" + sMinutes;
return {
	sHours: sHours,
	sMinutes: sMinutes
};
}

$scope.placeOfLoss = false;

$scope.initiateClaimObj ={
policyNo: CommonServices.getCommonData("policyNumber").policyNumber,
lossType: "OD",
lossTypeVal:[{
	"value":"OD",
	"name":"Vehicle Own Damage"}],
natureLossTypeVal:[{
	"value":"FIRE",
	"name":"Fire"},{
	"value":"SELF-IG",
	"name":"Self Ignition"},{
	"value":"ACC-EXT",
	"name":"Accident External Mean"},{
	"value":"THEF-PTS",
	"name":"Theft of Part"
	},{
		"value":"THEF-EV",
		"name":"Theft of Vehicle"
	},{
			"value":"FL-TW",
			"name":"Flood"
}],
intimateFormSubmit: function(data){
	if(data === "submit"){
	
		var lossTimeVal = $("#lossTime").val();
		calTime(lossTimeVal);
		this.timeloss = calTime(lossTimeVal).sHours + ":" + calTime(lossTimeVal).sMinutes + ":" + "00" ;
		if($("#lossTime").val() === "" || $("#lossTime").val() === "undefined"){
			CommonServices.showAlert("Please enter Time of Loss");
			return false;
		}
		
			var lossDateComp = this.lossDate;
			var drr = lossDateComp.split('/');
			lossDateComp = drr[1] + '/' + drr[0] + '/' + drr[2]; //mm/dd/yyyy
			
			var policyStartDateComp = policyStartdate; 
			var srr = policyStartDateComp.split('/');
			policyStartDateComp = srr[1] + '/' + srr[0] + '/' + srr[2]; //mm/dd/yyyy
			
			lossDateComp = new Date(lossDateComp) ;
			policyStartDateComp = new Date(policyStartDateComp);

		 if(lossDateComp <= policyStartDateComp){
			CommonServices.showAlert("Date of Loss should be greater than Policy Start Date"+ "("+ policyStartdate +")");
		 }
		 else{
			
			 var intimateResponseData ={
		   "userProfile":{  
			  "userId":CommonServices.getCommonData("userId"),
			  "loggedInRole":CommonServices.getCommonData("loggedInRole"),
			  "searchQuote":{  

			  },
			  "gender":""
		   },
		   "typeOfLoss":this.lossType,
		   "dateOfLoss":this.lossDate,
		   "timeOfLoss": this.timeloss,
		   "dateOfNotification":this.intimationDate,
		   "timeOfNotification":this.intimationTime,
		   "natureOfLoss":this.natureLossType,
		   "placeOfLoss": this.placeOfLoss,
		   "policyNo":this.policyNo,
		   "extimatedLossAmount":this.estimatedAmntLoss.toString(),
		   "typeOfDamage": this.typeOfDamage === ''? 'NA': this.typeOfDamage//CR 3697_A
		}

		
		var getClaimListResponse = RestServices.postService(RestServices.urlPathsNewPortal.initiateClaim, intimateResponseData);
		getClaimListResponse.then(
			function(response) { // success	
				CommonServices.showLoading(false);
				if(response.data !== ""){
					if(response.data.footer.errorCode === "1" || response.data.footer.errorCode === "2"){
						if(response.data.claimNo !== undefined && response.data.claimNo !== ""){
							CommonServices.showAlert("Your Claim number has been successfully intimated. Your Claim Number is "+ response.data.claimNo);
							CommonServices.setCommonData("policyNumber",response.data);
							$state.go("managePolicies.docUpload");
						}
						else{
							CommonServices.showAlert("We are facing some issue please try after some time");
						}
						
					}
					else{
						CommonServices.showAlert(response.data.footer.errorDescription);
					}
				}
				
				
			},
			function(error) { // failure
				CommonServices.showLoading(false);
				RestServices.handleWebServiceError(error);
		});
		 }
		
						
	}
	if(data === "reset"){
		$scope.initiateClaimObj.lossDate ="";
		$scope.initiateClaimObj.lossTime ="";
		//$scope.initiateClaimObj.lossType =""; //CR 3697_A
		$scope.initiateClaimObj.placeOfLoss="";
		$scope.initiateClaimObj.natureLossType ="";
		$scope.initiateClaimObj.estimatedAmntLoss ="";
		$scope.initiateClaimObj.description = "";
		$scope.initiateClaimObj.typeOfDamage = "";//CR 3697_A
	}

},
pincodeCheck: function(pincode){
	
	if(pincode.length === 6){
		 var searchPincode = {
		"searchQuote": {
			"resultSize": 5,
			"startIndex": 0
		   },
		"address": {
			"addressType": null,
			"street": null,
			"locality": null,
			"city": null,
			"cityCode": null,
			"state": null,
			"stateCode": null,
			"country": null,
			"countryCode": null,
			"pincode": this.placeOfLoss,
			"mobileNumber": null,
			"emailId": null
			}
		};
		
		var getZipcodeDetailResponse = RestServices.postService(RestServices.urlPathsNewPortal.getZipcodeDetail, searchPincode);
		getZipcodeDetailResponse.then(
		  function(response) { // success 
		  
			CommonServices.showLoading(false);
			   $scope.pinCodeModal = true;
			  if(response.data.totalResult === 0){
				 $scope.noRecords = response.data.footer.errorDescription;
				 $scope.pinCodeTable = false;
				 $scope.noRecordFound = true;
				 $scope.initiateClaimObj.placeOfLoss ="";
			  }else{
				  $scope.statCodeValues = response.data.addresses;
				  $scope.pinCodeTable = true;
				  $scope.noRecordFound = false;
			  }
		  },
		  function(error) { // failure
			CommonServices.showLoading(false);
			RestServices.handleWebServiceError(error);
		});
	}
	
},
closePopup: function(){
	 $scope.pinCodeModal =false ;
}
}

var mydateStr =  new Date();
var mynewdateFrom ="";
if(mydateStr != undefined){
mynewdateFrom = new Date(mydateStr);
}
else{
mynewdateFrom = new Date();
}

var enableCalendarTo = getFormattedDate(mynewdateFrom);	

/**Date of Loss form policy Start Date till today**/

var enableRegValCalendarFrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear()));
enableRegValCalendarFrom = new Date(enableRegValCalendarFrom.setDate(enableRegValCalendarFrom.getDate() - 6));
enableRegValCalendarFrom = getFormattedDate(enableRegValCalendarFrom);

/**Date of Loss form policy Start Date till today**/
enableCalendarTo = enableCalendarTo.split(/[^0-9]+/);
var intimateYear = enableCalendarTo[2];
var intimateMon = enableCalendarTo[0];
var intimateDay = enableCalendarTo[1];
var intimateCalendarTo =  intimateDay + "/"+intimateMon+"/"+intimateYear;

$scope.initiateClaimObj.intimationDate = intimateCalendarTo;
											
											var date = new Date();
											var toDate =  new Date(date);
											toDate.setDate(toDate.getDate());
											var dayTo = toDate.getDate();
											var monthTo = toDate.getMonth() + 1;
											var yearTo = toDate.getFullYear();
											var enableLossCalendarTo = monthTo + "/" + dayTo + "/" + yearTo;
											
											var currentTime = CommonServices.getCommonData('lastLoginDate');
	  var brr = currentTime.split(' ');
	  var currentTime = brr[1];
$scope.initiateClaimObj.intimationTime = currentTime;

$("#lossDate").loadCalendar({
'enableDateRange': true,
'enableCalendarFrom': enableRegValCalendarFrom,
'enableCalendarTo': enableLossCalendarTo
});

$('#lossTime').timePickerSelect({
 containerClass: undefined,
 containerWidth: undefined,
 hoursLabel: 'Hour',
 minutesLabel: 'Minutes',
 setButtonLabel: 'Set',
 popupImage: undefined,
 onFocusDisplay: true,
 zIndex: 1000,
 onBeforeShow: undefined,
 onClose: undefined,
 timepickerIcon: true,
 highlightSelected: true
});

$scope.calIconClick= function(event)
{
angular.element("#"+ event.currentTarget.children[0].id).focus();  
};

$scope.timIconClick = function(event){
angular.element("#"+ event.currentTarget.children[0].id).focus();  
}


}]);

agentApp.controller('docUploadController', ['$scope','RestServices','CommonServices','$state', function ($scope, RestServices,CommonServices,$state) {
$scope.modalOpen = false;
$scope.home = function(){
if(CommonServices.getCommonData('claimSearchDetail') !== undefined && CommonServices.getCommonData('claimSearchDetail') !== ""){
	$state.go('managePolicies.claimSearchDetails');
}
 else{
	 $state.go('managePolicies.claims');
 }
}

$scope.docListShow = false;
$scope.policyNumber = CommonServices.getCommonData("policyNumber").policyNumber;
if(CommonServices.getCommonData("policyNumber").claimNumber !== undefined && CommonServices.getCommonData("policyNumber").claimNumber !== ""){
$scope.claimNumber = CommonServices.getCommonData("policyNumber").claimNumber;
}
else if(CommonServices.getCommonData("policyNumber").claimNo !== undefined && CommonServices.getCommonData("policyNumber").claimNo !== ""){
$scope.claimNumber = CommonServices.getCommonData("policyNumber").claimNo;
}


$scope.claimNumberOnchange= function(){

var viewUploadedDocInput = {  
	   "userProfile":{  
		  "userId":CommonServices.getCommonData("userId"),
		  "loggedInRole":CommonServices.getCommonData("loggedInRole"),
		  "searchQuote":{  

		  },
		  "gender":""
	   },
	   "claimNo":$scope.claimNumber,
	   "policyNo":CommonServices.getCommonData("policyNumber").policyNumber //"13010031160100002058"
	}

var viewDocResponse = RestServices.postService(RestServices.urlPathsNewPortal.getClaimDetail, viewUploadedDocInput);
viewDocResponse.then(
	function(response) { // success

		CommonServices.showLoading(false);	
		if(response.data.footer.errorCode === "1"){
			$scope.docList = response.data.documentList;
			$scope.docListShow = true;
		}
		else{
			CommonServices.showAlert(response.data.footer.errorMessage);
		}										
		
	},
	function(error) { // failure
		CommonServices.showLoading(false);
		RestServices.handleWebServiceError(error);
});
						
}


//Document Upload functions begin here
$scope.documentClaimIntimation={
	uploaddocsmodel : [],
	uploaddocscollection :[]
};

$scope.goBack = function (argument) {
$state.go();
}


$("#popup-container").on("click", function(){
	$(this).hide();
});


$scope.chooseImageUploadOption=function(event){

$scope.artID = $(event.target).parent().parent().attr("id");
$scope.imgCount = $('#'+$scope.artID+' img').length;
$scope.maxImageCount=10;
$scope.totalImageCount=$(".photo-container img").length;


if($scope.totalImageCount < $scope.maxImageCount){  
$("#upload-options").show();
$("#popup-container").show();
$(document).off('click', '#capture-photo-cam');
$(document).on('click', '#capture-photo-cam', function(e) {
e.stopPropagation();
$scope.pictureFromCam($scope.artID);
}); 

$(document).off('click', '#select-photo-gallery');
$(document).on('click', '#select-photo-gallery', function(e) {
e.stopPropagation();
$scope.pictureFromGallery($scope.artID);
}); 

$(document).off('click', '#popup-container');
$(document).on('click', '#popup-container', function(){
	  $scope.closePopUp(); 
	});
}
else{
CommonServices.showAlert("Maximum 10 documents can be uploaded at a time");
return false;

}

};


$scope.pictureFromCam = function(event) {
$("#upload-options").hide();
$("#popup-container").hide();
// $('.common-overlay').hide();
$scope.capturePhoto($scope.artID,true);
$scope.showModal = false;
};

$scope.pictureFromGallery = function(event){ 
$("#upload-options").hide();
$("#popup-container").hide();
$scope.capturePhoto($scope.artID,false);
$scope.showModal = false;
};

$scope.capturePhoto = function(event,fromCam) {


if (fromCam){
if(CommonServices.deviceType == "A"){
  navigator.camera.getPicture($scope.onSuccessImageUploadAndroid,$scope.onFailImageUploadAndroid,{quality: 85,destinationType: 0,targetWidth: 2048,targetHeight: 2048 });
}else{
  navigator.camera.getPicture($scope.onSuccessImageUploadAndroid,$scope.onFailImageUploadAndroid,{quality: 50,destinationType: 0,targetWidth: 2048,targetHeight: 2048 });
}
}else{
if(CommonServices.deviceType == "A"){
  navigator.camera.getPicture($scope.onSuccessImageUploadAndroid,$scope.onFailImageUploadAndroid,{quality: 85,destinationType: 0,sourceType: 0,targetWidth: 2048,targetHeight: 2048,encodingType: Camera.EncodingType.JPEG });
}else{
  navigator.camera.getPicture($scope.onSuccessImageUploadAndroid,$scope.onFailImageUploadAndroid,{quality: 50,destinationType: 0,sourceType: 0,targetWidth: 2048,targetHeight: 2048,encodingType: Camera.EncodingType.JPEG });
}
}

};


$scope.onSuccessImageUploadAndroid = function(fileURI) {


var height=$("#document-upload-wrapper").height();
var fileURISize = sizeof(fileURI)/(1024*2.67);

if(fileURISize>1&&fileURISize<1025){

//var checkMobOrTab=app.isMobile();
var that=this;
var queryString;
var fileDATAURI = fileURI;
var rId= Math.floor(Math.random() * (999 - 100 + 1)) ;
var imageType=$('#'+$scope.artID+'.doc-label').text().trim();

var fileNamePrefix=rId;
var newFileName=imageType+"_"+fileNamePrefix+".jpg";
var newFileName1=imageType.replace(/ /g,"_")+"_"+fileNamePrefix;
var imageId = fileNamePrefix +"-img";  


var documentType ='';
if(imageType==="Claim Form"){
documentType ="CLAIM FORM";
}else if(imageType==="Registration Certificate"){
documentType ="REGISTRATION CERTIFICATE";
}else if(imageType==="Driving License"){
documentType = "EXTRACT OF DL"
}else {
documentType ="Other Document";
} 


var content={
imageType:imageType,
documentType:documentType,
documentName:newFileName,
documentId :fileNamePrefix,
docByteString:fileDATAURI,
User_ID:CommonServices.getCommonData('userId'),
 Claim_No: $scope.claimNumber
};

$scope.documentClaimIntimation.uploaddocsmodel.push(content);
$("#"+$scope.artID+" .photo-container").append("<div class='image-conatiner' dataval="+fileNamePrefix+" id="+newFileName1+"><img id ="+imageId+" data="+newFileName+" dataval="+fileNamePrefix+"  src='data:image/JPEG;base64,"+fileDATAURI+"' /><span class='delete-image-icon' dataval="+fileNamePrefix+" datasuccess="+newFileName+" id="+fileNamePrefix+" ></span></div>");


$scope.documentClaimIntimation.uploaddocscollection.push(content);

}

else{
CommonServices.showAlert( "Image size should be less than 1MB" );
return false;
}
var maxImageCount=10;
var totalImageCount=$(".photo-container img").length;
if(totalImageCount==maxImageCount){
$(".uploadVehPhotoAndr").addClass("disableCamera");
}
};


$(".photo-container").on("click",'.delete-image-icon', function(e){ 
  e.stopPropagation();
  var dataval = parseInt(e.currentTarget.getAttribute("dataval"));
  $scope.loadDeletePopUp(e,dataval);

});


$(".photo-container").on("click",'img', function(event){

var eIid=event.currentTarget.getAttribute("id");
var eSrc=event.currentTarget.getAttribute("src");
$("#popup-container").show();
$("#image-preview").show();
$("#image-preview img").attr("src",eSrc);
var imgTarget="#"+eIid;
$(document).off('click', '#popup-container');
$(document).on('click', '#popup-container', function(){ 
$scope.closePopUp();
});



});

$scope.loadDeletePopUp = function(event,dataval){


var id = "#"+$(event.target).parent().attr("id");

//if(evt.currentTarget.getAttribute("class")==="tick-icon"){
//  return false;
//}else{
var that = this;
$("#popup-container").show();
$("#popup-content").show();
$("#popup-content").off().on('click',function(){
$scope.closePopUp();
});

$("#btn-yes").off().on('click',function(){
$scope.closePopUp();
var myEl = angular.element( document.querySelector(id) );
myEl.remove();   
for(var i=0 ; i<$scope.documentClaimIntimation.uploaddocscollection.length; i++)
  {
	if($scope.documentClaimIntimation.uploaddocscollection[i].documentId===dataval)
	{
	  $scope.documentClaimIntimation.uploaddocscollection.splice(i,1);
	  break;

	}
  }  

var totalImageCount=$(".photo-container img").length;
var maxImageCount=10;
if(totalImageCount<maxImageCount){
  $('.uploadVehPhotoAndr').removeClass("disableCamera");
}
});

$("#btn-no").off().on('click',function(){
  $scope.closePopUp();
});
// }

};

$scope.onFailImageUploadAndroid = function() {
app.log("Image Upload Failed");
};

$scope.closePopUp = function(){

$("#popup-content").hide();
$("#popup-container").hide();
$("#image-preview").hide();
$("#calendar-container").hide();
$("#timePickerSelectCntr").hide();
$("#upload-options").hide();
$("#slide-container").show();
};

//Document Upload Ends

$scope.docUploadSubmit = function(event){

	if($(".photo-container img").length=== 0){
		//alert("no images");
		CommonServices.showAlert("No images to submit");
		return false;
	  }

	if ($('#claim-form-article img').length === 0) { CommonServices.showAlert("Please upload the mandatory image- Claim Form");return false;};
	if ($('#other-images-article img').length === 0) { CommonServices.showAlert("Please upload the mandatory image- Registration Certificate");return false;};
	if ($('#damage-image-upload-article img').length === 0) { CommonServices.showAlert("Please upload the mandatory image- Driving License");return false;};
	
	var imageCollection = $scope.documentClaimIntimation.uploaddocscollection;
	var imageCollectionLength=imageCollection.length;

	var documentsList = [];

	for (var i = 0; i < imageCollectionLength; i++) {

		if ($scope.documentClaimIntimation.uploaddocscollection[i].documentIndex === undefined) {
				  var imageList = {
					  "documentName": imageCollection[i].documentName,
					  "docByteString": imageCollection[i].docByteString,
					  "documentType": (imageCollection[i].documentType).toUpperCase()
				  };

		documentsList.push(imageList);
		imageList="";
		}
	}

	if (documentsList.length === 0) {
	   CommonServices.showAlert("No new images to submit","Alert");
	   return;
	}

	var docUploadInput ={
		"userProfile": {
			"searchClaim": {
			  "referenceNumberPolicyClaim": CommonServices.getCommonData("policyNumber").policyNumber
			},
			"claims": [
			  {
				"claimNumber": $scope.claimNumber,
				"documentsList": documentsList
			  }
			],
			"userID": CommonServices.getCommonData("userId")
		  }
	}

	var docUploadResponse = RestServices.postService(RestServices.urlPathsNewPortal.custUploadDocuments, docUploadInput);
	docUploadResponse.then(
		function(response) { // success
			CommonServices.showLoading(false);
			var model = response;

		  for(var i=0 ; i<$scope.documentClaimIntimation.uploaddocscollection.length; i++){
			for (var j = 0; j < model.data.uploadDocumentResponses.length; j++) {
			  if ($scope.documentClaimIntimation.uploaddocscollection[i].documentName == model.data.uploadDocumentResponses[j].documentname) {

				  if(model.data.uploadDocumentResponses[j].documentIndex === undefined){

				  }else{

						   $("#"+$scope.documentClaimIntimation.uploaddocscollection[i].documentId).addClass("tick-icon").removeClass("delete-image-icon");
											  $scope.documentClaimIntimation.uploaddocscollection.splice(i,1);


													var newContent={
														  imageType:model.data.uploadDocumentResponses[j].documentType,
														  documentType:model.data.uploadDocumentResponses[j].documentType,
														  documentName:model.data.uploadDocumentResponses[j].documentname,
														  documentIndex :model.data.uploadDocumentResponses[j].documentIndex,
														  docByteStringUrl:model.data.uploadDocumentResponses[j].documentUrl,
														  User_ID:CommonServices.getCommonData("userId"),
														  Claim_No: $scope.claimNumber
											  };

											  $scope.documentClaimIntimation.uploaddocscollection.push(newContent);

				  }

			  }
			}
		  }
		},
		function(error) { // failure
			CommonServices.showLoading(false);
			RestServices.handleWebServiceError(error);
		});

}


}]);

agentApp.controller('viewUploadedDocController', ['$scope','RestServices','CommonServices','$state', function ($scope, RestServices,CommonServices,$state) {


$scope.policyNumber = CommonServices.getCommonData("policyNumber").policyNumber;

$scope.docUploadObj ={
claimForm:[],
drivingLicense:[],
regCertificate:[],
claimNumber: CommonServices.getCommonData("policyNumber").claimNumber,
closeModal: function(){
	$scope.modalOpen = false;
	$("#preview").addClass("hide");
},
viewDoc: function(url,name){

	var docName = name;
	var imgSrc = url;
	var file_type = imgSrc.substr(imgSrc.lastIndexOf('.')).toLowerCase();
	
	if (file_type  === '.pdf' || file_type === '.doc' || file_type === ".txt" || file_type ===".xls") {	
		docDownloadFunc(imgSrc,name);
	}
	else{

		$scope.modalOpen = true;
		$scope.imgurl = imgSrc;
		$scope.imgName = name;
		$("#preview").removeClass("hide");
	}
}
}

$scope.viewDoc = function(){
getdocList();
}

function getdocList(){

var viewUploadedDocInput = {
	   "userProfile":{
		  "userId":CommonServices.getCommonData("userId"),
		  "loggedInRole":CommonServices.getCommonData("loggedInRole"),
		  "searchQuote":{

		  },
		  "gender":""
	   },
	   "claimNo": CommonServices.getCommonData("policyNumber").claimNumber,
	   "policyNo":$scope.policyNumber
	}

var viewDocResponse = RestServices.postService(RestServices.urlPathsNewPortal.getClaimDetail, viewUploadedDocInput);
viewDocResponse.then(
	function(response) { // success
		$scope.docUploadObj.drivingLicense =[];
		$scope.docUploadObj.regCertificate =[];
		$scope.docUploadObj.claimForm =[];

		CommonServices.showLoading(false);
		if(response.data.footer.errorCode === "1"){
			for(var i=0; i < response.data.documentList.length; i++){
				if(response.data.documentList[i].documentType === "DRIVING LICENSE" || response.data.documentList[i].documentType === "EXTRACT OF DL"){
					$scope.docUploadObj.drivingLicense.push(response.data.documentList[i]);
				}
				if(response.data.documentList[i].documentType === "OTHER DOCUMENT" || response.data.documentList[i].documentType === "REGISTRATION CERTIFICATE"){
					$scope.docUploadObj.regCertificate.push(response.data.documentList[i]);
				}
				if(response.data.documentList[i].documentType === "CLAIM FORM"){
					$scope.docUploadObj.claimForm.push(response.data.documentList[i]);
				}
			}
			$scope.docUploadObj.docListShow = true;
		}
		else{
			CommonServices.showAlert(response.data.footer.errorMessage);
		}

	},
	function(error) { // failure
		CommonServices.showLoading(false);
		RestServices.handleWebServiceError(error);
});

}

$scope.docView = function(){
getdocList();
}

$scope.docView();

function docDownloadFunc(imgSrc,docName){

 try {
	 window.appRootDirName = "NIAAgentDoc";
	 window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, CommonServices.gotFS, CommonServices.fail);

	var fileTransfer = new FileTransfer();
	var url = url;
	var filePath;
	var docName = docName;


	if(navigator.userAgent.match(/iPhone|iPad|iPod/i)){
	   filePath = window.appRootDir.nativeURL +docName;
	}
	else if(navigator.userAgent.match(/Android/i)){

	   filePath = fileSystem.root.toURL() + "NIAAgentDoc/" + docName;
	}
	else{
	   filePath = false;
	}
	CommonServices.showLoading(false);

		fileTransfer.download(url, filePath, function(theFile) {
			if(navigator.userAgent.match(/iPhone|iPad|iPod/i)){
			 window.open(url , '_system', 'location=no');
			}
			else if(navigator.userAgent.match(/Android/i)){
			window.open(filePath , '_system', 'location=no');
			}
		},
		function(error) {

			 CommonServices.showAlert("Download not successful, please try again after some time");
			 CommonServices.showLoading(false);
		},
		true
	);

} catch (err) {

	$scope.counter = false;
	CommonServices.showLoading(false);
	CommonServices.showAlert("Please insert SD Card to download documents");
} finally {

}
}

$scope.home = function(){
	if( $(".modal").is(":visible") ){
		$scope.docUploadObj.closeModal();
	  }
	  else{
		 $state.go('managePolicies.claimSearchDetails');
	  }

}


$scope.docUploadObj.claimNumberVal=CommonServices.getCommonData('claimList');

}]);