agentApp.controller('linkYourAadharGetDetailsCtrl', ['$scope', '$rootScope', 'CommonServices', 'RestServices', 'GetSetResponseService', '$location', '$state', function ($scope, $rootScope, CommonServices, RestServices, GetSetResponseService, $location, $state) {

	$scope.goBack = function () {
		$state.go('home');
	}
	$scope.fetchAadharDetails = function () {

		//$state.go('linkYourAadharGetUserData');
		//return;


		var fetchAadharDetails = {
			"quote": {
				"policyHolderCode": $scope.customerIdForAadharLink,
				"policyNumber": $scope.policynumberForAadharLink
			},
			"userProfile": {
				"userId": CommonServices.getCommonData("userId")
			}
		};

		//var url= RestServices.urlConstantPortal + RestServices.urlPaths.fetchAadharDetails;           
		var fetchAadharDetailsResponse = RestServices.postService(RestServices.urlPathsNewPortal.fetchAadharDetails, fetchAadharDetails);

		fetchAadharDetailsResponse.then(function (response) {

			CommonServices.showLoading(false);

			if(response.data.userProfile != undefined){
				if (response.data.userProfile.footer.errorCode == "1") {

					if(response.data.quote.aadharDetails.panNum === undefined || response.data.quote.aadharDetails.panNum == null ){
						GetSetResponseService.addFetchAadharDetails(response.data);
						$state.go('linkYourAadharGetUserData');
					}else if(response.data.quote.aadharDetails.hasOwnProperty('aadhaarAuthStatus')){
						if(response.data.quote.aadharDetails.aadhaarAuthStatus.toUpperCase() == "SUCCESS"){
							CommonServices.showAlert("Your Policy/Customer ID is already linked with Aadhaar.");
							return;
						}else{
							GetSetResponseService.addFetchAadharDetails(response.data);
							$state.go('linkYourAadharGetUserData');
						}
					}else{
						GetSetResponseService.addFetchAadharDetails(response.data);
						$state.go('linkYourAadharGetUserData');
					}

				// 	if (response.data.quote.aadharDetails.panNum != null || response.data.quote.aadharDetails.panNum != ""){
				// 		if(response.data.quote.aadharDetails.hasOwnProperty('aadhaarAuthStatus')){
				// 			if(response.data.quote.aadharDetails.aadhaarAuthStatus.toUpperCase() == "SUCCESS"){
				// 				CommonServices.showAlert("Your Policy/Customer ID is already linked with Aadhaar.");
				// 				return;
				// 			}
				// 	}
				// }
					// GetSetResponseService.addFetchAadharDetails(response.data);
					// $state.go('linkYourAadharGetUserData');
				} else {
					CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
				}
			}else{
				CommonServices.showAlert("We regret for the inconvenience, presently our services are not available. Please try after sometime");
			}

		}, function (error) {
			CommonServices.showLoading(false);
			RestServices.handleWebServiceError(error);
		});


	}


}]);


agentApp.controller('linkYourAadharGetUserDataCtrl', ['$scope', '$rootScope', 'CommonServices', 'RestServices', 'GetSetResponseService', '$location', '$state', function ($scope, $rootScope, CommonServices, RestServices, GetSetResponseService, $location, $state) {

	$scope.goBack = function () {
		$state.go('linkYourAadharGetDetails');

	};

	$scope.linkYourAadharGetUserDataCtrl = {
		onload: function () {
			$scope.aadharGetUserDataObj = {};
			$scope.aadharGetUserDataObj.UIDAI_WEBSITE_URL = CommonServices.getCommonData("ConfigurationData")[1].value;
			//$scope.aadharGetUserDataObj.systemDateForAadhar = CommonServices.systemDateForAadhar;
			$scope.aadharGetUserDataObj.disableSubmitButtonForOrg = false;

			//policy number
			$scope.aadharGetUserDataObj.policyNumber = GetSetResponseService.getFetchAadharDetails()[0].quote.policyNumber
			$scope.aadharGetUserDataObj.policyHolderCode = GetSetResponseService.getFetchAadharDetails()[0].quote.policyHolderCode


			// for binding pan number if available
			if (GetSetResponseService.getFetchAadharDetails()[0].quote.aadharDetails.panNum != undefined) {
				$scope.aadharGetUserDataObj.panNumInputDisable = true;
				$scope.aadharGetUserDataObj.reEnterPanNumInputDisable = true;
				$scope.aadharGetUserDataObj.showRePanCradField = false;

				$('#panCardNosToLink').addClass('aadharPanCardInputDisabled');

				$('#panCardNosToLink').prop('type', 'text');

				$scope.aadharGetUserDataObj.panCardNosToLink = GetSetResponseService.getFetchAadharDetails()[0].quote.aadharDetails.panNum;
				$scope.aadharGetUserDataObj.renterPanCardNosToLink = GetSetResponseService.getFetchAadharDetails()[0].quote.aadharDetails.panNum;

			} else {
				$scope.aadharGetUserDataObj.panNumInputDisable = false;
				$scope.aadharGetUserDataObj.reEnterPanNumInputDisable = false;
				$scope.aadharGetUserDataObj.showRePanCradField = true;
			}

			if(GetSetResponseService.getFetchAadharDetails()[0].quote.aadharDetails.hasOwnProperty('aadhaarAuthStatus')){
				if(GetSetResponseService.getFetchAadharDetails()[0].quote.aadharDetails.aadhaarAuthStatus.toUpperCase() == "SUCCESS"){
					$scope.aadharGetUserDataObj.showAadhaarField = false
				}else{
					$scope.aadharGetUserDataObj.showAadhaarField = true;
				}
			}else{
				$scope.aadharGetUserDataObj.showAadhaarField = true;
			}
			
            $scope.aadharGetUserDataObj.enableResendOTPbtn = false;
            $scope.aadharGetUserDataObj.otpVerifiedForVID = false;
		}
	}

	$scope.linkYourAadharGetUserDataCtrl.onload();

	$scope.panExp = /^[A-Za-z]{5}[0-9]{4}[A-Za-z]{1}$/;



	$scope.cancelAadhaarLink = function () {
		$state.go('home');
	}

	$scope.resetAadhaarLink = function () {
		$scope.aadharGetUserDataObj = {};
		$state.go("linkYourAadharGetDetails");
	}


	$scope.virtualIdentificationNosChange = function(){

		if($scope.aadharGetUserData.virtualIdentificationNos.$error.pattern){
			$scope.aadharGetUserDataObj.showOTPinputField = false;
			$scope.aadharGetUserDataObj.enableResendOTPbtn = false;
			$scope.aadharGetUserDataObj.otpVerificationForVID = "";
		}
			
	}


    $scope.generateOTPforVID = function(){ 

		var header = {
			'Content-Type': 'application/json',
			'applicationid': 'mobile',
			'customerName': 'CUSTOMER',
			'typeOfCustomer': 'CUSTOMER'
		};

		var generateOTPInputData = {
			"vid":$scope.aadharGetUserDataObj.virtualIdentificationNos,
			"partyCode":$scope.aadharGetUserDataObj.policyHolderCode
			};
		
		var generateOTPResponse = RestServices.postService(RestServices.urlPathsNewPortal.generateOTP, generateOTPInputData);	
		//var url = RestServices.urlConstantPortal + RestServices.urlPaths.generateOTP;
		//var generateOTPResponse = RestServices.postService(url, generateOTPInputData, header);

		generateOTPResponse.then(function (response) {

			CommonServices.showLoading(false);

			if(response.data != undefined){
				if(response.data.errorCode == 0){
					$scope.aadharGetUserDataObj.generateOTPResponse = response.data;
					CommonServices.showAlert("An OTP will be sent to your mobile number registered with UIDAI");
					$scope.aadharGetUserDataObj.showOTPinputField = true;
					$scope.aadharGetUserDataObj.enableResendOTPbtn = true;
				}else if(response.data.errorCode === 'N-515' || response.data.errorCode === 'N-517'){
					CommonServices.showAlert('Entered VID is not valid. Please provide valid VID. If VID has expired, you can generate it again from UIDAI website.');
					return;
				}
				else{
					CommonServices.showAlert(response.data.errorMessage);
				}
			}else{
				CommonServices.showAlert("We regret for the inconvenience, presently our services are not available. Please try after sometime");
			}

		}, function (error) {
			CommonServices.showLoading(false);
			RestServices.handleWebServiceError(error);
		});
    };

    $scope.resendOTPforVID = function(){
		if($scope.aadharGetUserDataObj.otpVerificationForVID != ""){
			$scope.generateOTPforVID();
		}
	};
	

	$scope.submitUserEnteredData = function () {
		if($scope.aadharGetUserDataObj.showAadhaarField != true){
			if($scope.aadharGetUserDataObj.panNumInputDisable === false){
				$scope.submitPANAadhar();
				return; 	
			}
		}

		var header = {
			'Content-Type': 'application/json',
			'applicationid': 'mobile',
			'customerName': 'CUSTOMER',
			'typeOfCustomer': 'CUSTOMER'
		};

		var validateOTPInputData = {
			"vid":$scope.aadharGetUserDataObj.virtualIdentificationNos.toString(),
			"partyCode":$scope.aadharGetUserDataObj.policyHolderCode,
			"otp":$scope.aadharGetUserDataObj.otpVerificationForVID.toString(),
			"transactionId":$scope.aadharGetUserDataObj.generateOTPResponse.transactionId,
			"consentDecl":"CONSENT"
			};	

		if($scope.aadharGetUserDataObj.updatePanNum == "Y"){
			validateOTPInputData["panNum"] = $scope.aadharGetUserDataObj.panCardNosToLink;
		}

		var validateOTPResponse = RestServices.postService(RestServices.urlPathsNewPortal.validateOTP, validateOTPInputData);	

		//var url = RestServices.urlConstantPortal + RestServices.urlPaths.validateOTP;
		//var validateOTPResponse = RestServices.postService(url, validateOTPInputData, header);

		validateOTPResponse.then(function (response) {

			CommonServices.showLoading(false);

			if(response.data != undefined){
					if(response.data.errorCode === 'N-400'){
						CommonServices.showAlert('The entered OTP is incorrect.');
						return;
					}else if(response.data.errorCode === 'N-515' || response.data.errorCode === 'N-517'){
						CommonServices.showAlert('Entered VID is not valid. Please provide valid VID. If VID has expired, you can generate it again from UIDAI website.');
						return;
					}else if(response.data.errorCode === '0'){
						CommonServices.showAlert('Your Aadhaar is successfully linked with your policy.');		
					}else{
						CommonServices.showAlert(response.data.errorMessage);
					}

					$state.go('home');

				
			}else{
				CommonServices.showAlert("We regret for the inconvenience, presently our services are not available. Please try after sometime");
			}

		}, function (error) {
			CommonServices.showLoading(false);
			RestServices.handleWebServiceError(error);
		});
		//added 

	};

	$scope.submitPANAadhar = function(){

		if ($scope.aadharGetUserDataObj.panNumInputDisable === false) {

			if ($scope.aadharGetUserDataObj.panCardNosToLink != $scope.aadharGetUserDataObj.renterPanCardNosToLink) {
				CommonServices.showAlert("PAN Number entered in PAN Number and Re-enter PAN Number should match.", "Alert");
				return;
			}

		}


		if (GetSetResponseService.getloginResponseData()[0].userProfile === undefined) {
			$scope.userId = null;
		} else {
			$scope.userId = GetSetResponseService.getloginResponseData()[0].userProfile.userId;
		}

		// update pan yes/no
		if ($scope.aadharGetUserDataObj.panNumInputDisable === true) {
			$scope.aadharGetUserDataObj.updatePanNum = "N";
		} else {
			$scope.aadharGetUserDataObj.updatePanNum = "Y";
		}

		CommonServices.showLoading(true);
		var saveAadharDetailsInputData = {
			"quote": {
				"policyHolderCode": GetSetResponseService.getFetchAadharDetails()[0].quote.policyHolderCode,
				"policyNumber": GetSetResponseService.getFetchAadharDetails()[0].quote.policyNumber,
				"partyType": $scope.aadharGetUserDataObj.partyType,
				"aadharDetails": {
					"panNum": $scope.aadharGetUserDataObj.panCardNosToLink.toUpperCase(),
					"updatePanNum": $scope.aadharGetUserDataObj.updatePanNum.toUpperCase(),
				}
			},
			"userProfile": {
				"userId": CommonServices.getCommonData("userId")
			}
		};

		//var url= RestServices.urlConstantPortal + RestServices.urlPaths.saveAadharDetails;
		var saveAadharDetailsResponse = RestServices.postService(RestServices.urlPathsNewPortal.saveAadharDetails, saveAadharDetailsInputData);
		saveAadharDetailsResponse.then(function (response) {

			CommonServices.showLoading(false);

			if (response.data.userProfile.footer.errorCode == "1") {
				GetSetResponseService.addSaveAadharDetails(response.data);
				console.log(response.data.userProfile.footer.errorDescription);
				CommonServices.showAlert("Request has been successfully submitted.", "Alert");

				// if ($scope.aadharGetUserDataObj.partyType == "O") {
				// 	CommonServices.showAlert("Request has been successfully submitted.", "Alert");
				// } else {
				// 	CommonServices.showAlert("Dear Customer, We have received your Aadhaar number through web mode which will be authenticated by us with UIDAI. In case the authentication with UIDAI fails, an SMS will be sent to your registered mobile to contact nearest New India Branch Along with Aadhaar Card or e-Aadhaar", "Alert");
				// }

				$state.go('home');

			} else {
				CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
			}

		}, function (error) {
			CommonServices.showLoading(false);
			RestServices.handleWebServiceError(error);
		});

	}
}]);





