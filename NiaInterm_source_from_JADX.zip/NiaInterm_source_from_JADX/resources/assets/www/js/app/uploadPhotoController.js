agentApp.controller('breakInPhotoUploadCntl', ['$scope','RestServices', function ($scope,RestServices) {
	
	$scope.home = function() {
		RestServices.goHome();
	};
	$scope.quoteData = {};
	var breakInQuote = "";
	var vehRegNo = "";
	var branchCode = "";
	var selectedQuoteProductCode;
	var uploadPhotoFromList = false;
	$scope.expiredQuote = false;
	$scope.uploadedPhotoList = {};
	$scope.timeStampList = [];
}]);

/**************CR_3585 Start**********/

agentApp.controller('videoRecordingCntrl', ['$rootScope', '$scope', '$location', 'RestServices', 'CommonServices', '$state', '$timeout', '$document', function($rootScope, $scope, $location, RestServices, CommonServices, $state, $timeout, $document) {

    if (CommonServices.deviceType == "A") {

        screen.orientation.lock('landscape-primary').catch(function(error) {
            //alert(error);
            CommonServices.messageModal('info', error, false, '', 'Ok', function () {}, function () {}, 'Alert');
        });
        screen.orientation.unlock();
        console.log('Orientation is ' + screen.orientation.type);
    }

	  //$scope.isUploadDisabled="false";

    $scope.quoteNo = breakInQuote; //must change
    //$scope.quoteNo="";
    var mediaRecorder;
    var recordedBlobs;
    var fileEntryObj;
    var messages = ["First capture the wind shield from inside. Start from left to right slowly.","Start the engine and record the odometer", "Record the engine and chassis number.", "Record RC and previous year policy.","Record 360 degree video of the vehicle","Close the bonnet and record front view of the car."];
    $("#preview-div").hide();
    $("#myProgress").css("display", "none");
	$("#local-video-preview").hide();

    var mediaRecorder;
    var recordedBlobs;
    $scope.showInspectionScreenOnly = false;
    $scope.showVideo = false;
    $scope.playVideo = function() {
		//alert("coming soon");
       // $scope.showVideo = true;
	   CommonServices.messageModal('info', "Coming soon", false, '', 'Ok', function () {}, function () {}, 'Alert');
	   

    }

    $scope.backToInspection = function() {

        $scope.showVideo = false;
    }

	
	$scope.goToUpload=function()
	{
		    $scope.uploadVideoEnabled = true;
		    $("#local-video-preview").hide();
		    $("#btnVideoUpload").removeAttr("disabled");
            $("#btnVideoUpload").show();
            $('#message').html("Please upload the file");
			 
		
		//$("#preview-elem-1").get(0).src="images/86862108.mp4";
		//console.log($("#preview-elem-1").get(0).src);
	}
	
	
	$scope.reTakeVideo=function()
	{
		$("#local-video-preview").hide();
		$('#message').html("First capture the wind shield from inside. Start from left to right slowly.");
		
		 $("#doneButton").prop("disabled", false);
		 i=0;
		
		 $scope.startInspection();
		
	}
	
	
    $scope.startInspection = function() {

         /***temporary rest the value*****/
           mediaRecorder="";
           recordedBlobs="";
           fileEntryObj=""
         /***temporary rest the value end*****/


        $scope.showInspectionScreenOnly = true;
        $("#nia-video-logo").hide();
        $("#progress-slider").hide();
        $("#car-view").hide();
		/*
        CommonServices.showAlert("Keep your car Registration certificate and previous year policy ready");

        CommonServices.showAlert("Please keep the bonnet open and sit on the Driver seat. Kindly make sure all window glasses of your car are up during the video inspection process.");
		*/
		
		function openCamera() {
            $("#preview-div").show();
            navigator.mediaDevices.getUserMedia({
				'audio': false,
				'video': {
					facingMode: 'environment',
					width: {
						min: 1024,
						ideal: 1280,
						max: 1920
					},
					height: {
						min: 776,
						ideal: 720,
						max: 1080
					}
				}
			}).then(function(mediaStream) {

				//  $("#preview-div").show();

				var elem = $('#preview-elem');
				elem.get(0).srcObject = mediaStream;
				elem.get(0).play();
				elem.get(0).muted = true;

				var options = {
					mimeType: 'video/webm'
				};
				mediaRecorder = new MediaRecorder(mediaStream, options);
				mediaRecorder.onstart = function() {
					console.log('Recording Started');
				};

				mediaRecorder.ondataavailable = function(event) {
					console.log("recording data 0");
					if (event.data && event.data.size > 0) {
						// recordedBlobs.push(event.data);
						recordedBlobs = event.data;
						console.log("recording data1");
					}
				};
				mediaRecorder.start();
			});
		}
		function messageSuccesCallback() {
            //navigator.notification.confirm("Please keep the bonnet open and sit on the Driver seat, kindly make sure all window glasses of your car are up during the video inspection process",openCamera, "Alert", ["Ok"]);
			var msg = "Please keep the bonnet open and sit on the Driver seat, kindly make sure all window glasses of your car are up during the video inspection process";
			CommonServices.messageModal('info', msg, false, '', 'Ok', function () {}, function () { 
                setTimeout(function(){
                    openCamera();
                },1500);
            }, 'Alert');
		}
        //navigator.notification.confirm("Keep your car registration certificate and previous year policy ready",messageSuccesCallback, "Alert", ["Ok"]);
		var msg = "Keep your car registration certificate and previous year policy ready";
		CommonServices.messageModal('info', msg, false, '', 'Ok', function () {}, function () { 
            setTimeout(function(){
                messageSuccesCallback();
            },1500);
            
        }, 'Alert');
    }

    $scope.uploadVideoEnabled = false;
    //$scope.isFileSaved=false;
    var i = 0
    $('#message').html(messages[i]);
    $scope.nextMesasage = function() {
        i++;
        $('#message').html(messages[i]);
        if (i == 4) {

            $("#nia-video-logo").show();
            $("#progress-slider").show();
            $("#car-view").show();
            var p = 0;
            var objTimeOut = ""

            function doSomething() {
                p = p + 0.1;
                console.log(p);
                $("#progress-slider").css("margin-left", p + "%");
                if (p > 92) {
                    clearInterval(objTimeOut);
                }

            }

            objTimeOut = setInterval(doSomething, 50); // Time in milliseconds

        }



        if (i > 5) {
            $("#doneButton").attr("disabled", true);
            $("#nia-video-logo").hide();
            $("#progress-slider").hide();
            $("#preview-div").hide();
            $("#car-view").hide();
            //$scope.uploadVideoEnabled = true;
		    $("#local-video-preview").show();
			//reseting video
			$("#preview-elem-1").get(0).src="";
			$("#message-preview").html("Please wait while loading preview");

			
            /***********stoping video recording*****/
            mediaRecorder.stop();//uncoment

            mediaRecorder.onstop = function() {
                console.log('Recording Stopped');
                console.log(recordedBlobs);
                $('#message').html("Please wait while storing the recorded file");

                window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, function(fs) {

                    console.log('file system open: ' + fs.name);
                     var min=100;
                     var max=1000;
                     var random = Math.random() * (+max - +min) + +min;
                     var fileName=random+"_video.mp4";
                    fs.root.getFile(fileName, {
                        create: true,
                        exclusive: false
                    }, function(fileEntry) {

                        console.log("fileEntry is file?" + fileEntry.isFile.toString());
                        console.log("full path" + fileEntry.fullPath);
                        // fileEntry.name == 'someFile.txt'
                        // fileEntry.fullPath == '/someFile.txt'
                        writeFile(fileEntry, recordedBlobs);

                    }, onErrorCreateFile);

                }, onErrorLoadFs);

                function onErrorLoadFs() {
                    console.log("create file error");
                }

                function onErrorCreateFile() {
                    console.log("create file error");
                }


                function writeFile(fileEntry, dataObj) {
                    // Create a FileWriter object for our FileEntry (log.txt).
                    fileEntry.createWriter(function(fileWriter) {

                        fileWriter.onwriteend = function() {
                            console.log("Successful file write...");
                            // readFile(fileEntry);
                            fileEntryObj = fileEntry; //storing it in a global variable;
							
							$("#local-video-preview").show();
							$("#message-preview").html("YOUR SELF INSPECTION VIDEO PREVIEW");
							$("#preview-elem-1").get(0).src=fileEntry.toURL();
							
							 //setting url to 
							 // fileEntry.toURL();
							
							/*
							
                            $("#btnVideoUpload").removeAttr("disabled");
                            $("#btnVideoUpload").css("display", "block");

                            $('#message').html("Please upload the file");
                            //$scope.isFileSaved=true;
                             */

                        };

                        fileWriter.onerror = function(e) {
                            console.log("Failed file write: " + e.toString());
                        };

                        // If data object is not passed in,
                        // create a new Blob instead.
                        if (!dataObj) {
                            dataObj = new Blob(['some file data'], {
                                type: 'text/plain'
                            });
                        }

                        fileWriter.write(dataObj);
                    });
                }
            };
            mediaRecorder.stop();




        }


    }



    $scope.uploadVideo = function() {


        $("#myProgress").show();
        $('#message').html("Video Upload is in progress..Please Wait.....");
        upload(fileEntryObj);

        function upload(fileEntry) {
            // !! Assumes variable fileURL contains a valid URL to a text file on the device,
            var fileURL = fileEntry.toURL();
            var success = function(r) {
                $('#message').html("successfully uploaded...");
                
               // $('#message').html("Please wait while updating break in status");

                var data = {
                    "alfrescoInput": {
                        "channel": CommonServices.getCommonData("stakeCode"),
                        "language": "ENGLISH"
                    },
                    "userProfile": {
                        "userId": CommonServices.getCommonData("userId"),
                        "branchCode": branchCode,
                        "emailId": CommonServices.getCommonData("emailId"),
                        "mobileNo": CommonServices.getCommonData("mobileNo")
                    },
                    "quoteNo": breakInQuote,
                    "uploadType": "BREAKIN",
                    "registrationNo": vehRegNo,
                    "damages_noticed_and_remarks": $rootScope.breakinModel.damagesRemarks, //CR_0944 added
                    "speedometer_reading": $rootScope.breakinModel.speedometerReading.toString(), //CR_0944 added
                    "place_of_inspection": $rootScope.breakinModel.placeInspection, //CR_0944 added
                }

                var breakInStatusUpdateResponse = RestServices.postService(RestServices.urlPathsNewPortal.breakInStatusUpdate, data);
                if (breakInStatusUpdateResponse === undefined) {} else {
                    breakInStatusUpdateResponse.then(
                        function(response) {
                            CommonServices.showLoading(false);
                            if (response.data.errorCode === "0") {
                                //$('#message').html("Break In Status Update successfully...");
								//$scope.isUploadDisabled="true";
								$("#btnVideoUpload").attr("disabled",true);

                            } else {
                                CommonServices.showAlert(response.data.errorMessage);
                            }
                        },
                        function(error) {

                            CommonServices.showLoading(false);
                            RestServices.handleWebServiceError(error);

                        });
                }
                

            };

            var fail = function(error) {
                //alert("An error has occurred: Code = " + error.code);
				var msg = "An error has occurred: Code = " + error.code;
				CommonServices.messageModal('info', msg, false, '', 'Ok', function () {}, function () {}, 'Alert');
                console.log("upload error source " + error.source);
                console.log("upload error target " + error.target);
            };


            var options = new FileUploadOptions();
            options.fileKey = "file";
            options.fileName = fileURL.substr(fileURL.lastIndexOf('/') + 1);
            options.mimeType = "video/mp4";
            options.chunkedMode = false;
            options.httpMethod = "POST";

            var params = {};
            params.userID = CommonServices.getCommonData("userId");
            params.password = CommonServices.getCommonData("hash");
            params.fileName = breakInQuote + ".mp4";

            options.params = params;
            console.log("upload error target " + JSON.stringify(options));
            var ft = new FileTransfer();
            /*******progress event************/
            var p = 0;
            ft.onprogress = function(progressEvent) {
                p++
                if (progressEvent.lengthComputable) {


                    console.log("total progress" + (progressEvent.loaded / progressEvent.total) * 100);
                    setProgress((progressEvent.loaded / progressEvent.total) * 100)


                } else {

                    //loadingStatus.setProgress(p);
                }
            };
            /********progress event**********/
            ft.upload(fileURL, encodeURI(RestServices.awsURL), success, fail, options);

        };


        function setProgress(progress) {
            var elem = $("#myBar");
            var width = progress;
            // var id = setInterval(frame, 10);
            $("#myBar").css('width', width + '%');

        }


    };

    $scope.home = function() {
        screen.orientation.lock('portrait-primary').catch(function(error) {
            //alert(error);
			CommonServices.messageModal('info', error, false, '', 'Ok', function () {}, function () {}, 'Alert');
        });
        screen.orientation.unlock();

        $state.go('uploadPhoto.breakInQuotesList');
    };

    $scope.searchBreakInQuote = function() {
        CommonServices.viewDocsbreakInSearchQuote = false;
        $state.go('uploadPhoto.breakInQuoteSearch');
    };

}]);


/**************CR_3585 End**********/


agentApp.controller('breakInQuotesCntl', ['$rootScope','$scope','$location','RestServices','CommonServices','$state','$timeout', function ($rootScope,$scope,$location, RestServices,CommonServices,$state,$timeout) {
	CommonServices.uploadJson = false;
	uploadPhotoFromList = false;
    $rootScope.locatorMap = {}; //CR_0944
    CommonServices.setCommonData('locationModel', {}); //CR_0944
	var breakInQuotesData = {
		"userProfile":{
			"userId":CommonServices.getCommonData("userCode").toUpperCase()
			}
		};
	
	var breakInQuoteListResponse = RestServices.postService(RestServices.urlPathsNewPortal.breakInQuotesList, breakInQuotesData);
	if(breakInQuoteListResponse === undefined){
	}else {
	    breakInQuoteListResponse.then(
        function(response) {
            CommonServices.showLoading(false);
            if(response.data.errorCode === "0") {
                angular.extend($scope.quoteData,response.data);
                if(response.data.breakInDetailASBO === undefined){
                    CommonServices.showAlert("Break in quotes are not available");
                } else {
                    for(var i=0; i< $scope.quoteData.breakInDetailASBO.length; i++){
                        var regNo = $scope.quoteData.breakInDetailASBO[i].registrationNo;
                        regNo = regNo.split("-");
                        if(regNo[0].toUpperCase() === "NEW"){
                            $scope.quoteData.breakInDetailASBO[i].registrationNo = "NEW";
                        }
                    }
                    $scope.items = $scope.quoteData;
                }
            } else {
                CommonServices.showAlert(response.data.errorMessage);
            }
        },
        function(error) { /* failure */
            CommonServices.showLoading(false);
            RestServices.handleWebServiceError(error);

        });
	}

		
		$scope.uploadPhoto = function(index){
			
			selectedQuoteProductCode = $scope.quoteData.breakInDetailASBO[index.$index].productCode;
			var todaysDate = CommonServices.getCommonData("serverDate");
			todaysDate = new Date(todaysDate);
			var polStartDate = $scope.quoteData.breakInDetailASBO[index.$index].polStartDate;
			polStartDate = polStartDate.split(" ");
			polStartDate = polStartDate[0].split(/[^0-9]+/);
			polStartDate = polStartDate[1] +"/"+ polStartDate[2] +"/"+ polStartDate[0];
			polStartDate = new Date(polStartDate);
			if(polStartDate < todaysDate){
				CommonServices.showAlert("Rejected by system as process is not completed within specified time.");
			} else {			
				breakInQuote = $scope.quoteData.breakInDetailASBO[index.$index].quoteNo;
				vehRegNo = $scope.quoteData.breakInDetailASBO[index.$index].registrationNo;
				branchCode = $scope.quoteData.breakInDetailASBO[index.$index].officeCode;
				uploadPhotoFromList = true;
				$state.go('uploadPhoto.uploadPhoto');
			}
		};
		
		$scope.searchBreakInQuote = function(){
			CommonServices.viewDocsbreakInSearchQuote = false;
			$state.go('uploadPhoto.breakInQuoteSearch');
		};
		
}]);

agentApp.controller('breakInQuoteSearchCntl', ['$rootScope','$scope','$location','RestServices','CommonServices','$state','$timeout', function ($rootScope,$scope,$location, RestServices,CommonServices,$state,$timeout) {

	$scope.breakInSearchResult = false;
	$scope.showActionBtn = false;
	$scope.viewPhoto = false;
	if(CommonServices.viewDocsbreakInSearchQuote){
		$scope.showActionBtn = true;
		$scope.breakInSearchResult = true;
		$scope.breakInQuoteSearch =  parseInt(CommonServices.searchResponseData.quoteNo);
		breakInSearch();
	} else {
		$scope.breakInQuoteSearch = "";
	} 	
	$scope.searchBreakInQuote = function(){
		if($scope.breakInQuoteSearch === "" || $scope.breakInQuoteSearch === undefined || $scope.breakInQuoteSearch.toString().length < 16){
			$scope.breakInSearchResult = false;
			$scope.showActionBtn = false;
			$timeout(function(){
				CommonServices.showAlert("Please enter valid 16 digit quote number");
			});
		} else {
			$scope.viewPhoto = false;
			var breakInQuoteSearchData = {
				"userProfile":{
					"userId": CommonServices.getCommonData("userCode").toUpperCase()
				}, 
				"quote":{
					"quoteNumber": $scope.breakInQuoteSearch 
					}
				};
			
			CommonServices.uploadJson = false;
			var breakInQuoteSearchResponse = RestServices.postService(RestServices.urlPathsNewPortal.breakInQuoteSearch, breakInQuoteSearchData);
			if(breakInQuoteSearchResponse === undefined){
			}else{
			breakInQuoteSearchResponse.then(
            function(response) {
                CommonServices.showLoading(false);
                CommonServices.searchResponseData = "";
                if(response.data.breakInDetailASBO === undefined){
                    if(response.data.errorMessage.toUpperCase() === "NO ERROR") {
                        CommonServices.showAlert("Quote details are not available");
                    } else {
                        CommonServices.showAlert(response.data.errorMessage);
                    }
                    $scope.showActionBtn = false;
                    $scope.breakInSearchResult = false;
                } else {
                    $scope.showActionBtn = true;
                    $scope.breakInSearchResult = true;
                    CommonServices.searchResponseData = response.data.breakInDetailASBO[0];
                    breakInSearch();
                }
            },
            function(error) { /* failure */
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            });
			}

		}
	}
	
	function breakInSearch() {
		
		var searchResponseData = CommonServices.searchResponseData;
		var regNo = searchResponseData.registrationNo;
		regNo = regNo.split("-");
		if(regNo[0].toUpperCase() === "NEW"){
			searchResponseData.registrationNo = "NEW";
		}
		$scope.item = searchResponseData;
		selectedQuoteProductCode = searchResponseData.productCode;
		breakInQuote = searchResponseData.quoteNo;
		branchCode = searchResponseData.officeCode;
		var todaysDate = CommonServices.getCommonData("serverDate");
		todaysDate = new Date(todaysDate);
		var polStartDate = searchResponseData.polStartDate;
		polStartDate = polStartDate.split(/[^0-9]+/);
		polStartDate = polStartDate[1] +"/"+ polStartDate[0] +"/"+ polStartDate[2];
		polStartDate = new Date(polStartDate);
		if(polStartDate < todaysDate){
		    if(searchResponseData.quoteStatus === "ACTIVE POLICY") {
		        $scope.showActionBtn = false;
		    } else {
		        $scope.breakInSearchActionBtnText = "Reason";
                $scope.expiredQuote = true;
		    }
		} else {
			$scope.expiredQuote = false;
			if(searchResponseData.breakInFlag.toUpperCase() === "BREAKPUP"){
					$scope.breakInSearchActionBtnText = "Upload Photo";
			} else if(searchResponseData.breakInFlag.toUpperCase() === "BREAKAPP"){
				if(searchResponseData.quoteStatus.toUpperCase() === "ACTIVE POLICY"){
					$scope.showActionBtn = false;
				} else{
					$scope.breakInSearchActionBtnText = "Collect Premium";
				}
			} else if(searchResponseData.breakInFlag.toUpperCase() === "BREAKREJ"){
				 $scope.breakInSearchActionBtnText = "Reason";			  
			} else if(searchResponseData.breakInFlag.toUpperCase() === "BREAKPU"){
					$scope.viewPhoto = true;
					$scope.breakInSearchActionBtnText = "Approve Break In";
			} else{
			   $scope.showActionBtn = false;
			}
		}
	}
	
	$scope.searchQuoteBtn = function(){
		if($scope.expiredQuote) {
			CommonServices.showAlert("Rejected by system as process is not completed within specified time.");
		} else{
			if($scope.breakInSearchActionBtnText === "Collect Premium"){
				CommonServices.showAlert("Premium collection is not allowed from break in photo upload module");
			}else if($scope.breakInSearchActionBtnText === "Approve Break In"){
				CommonServices.showAlert("Break approval is pending with NIA office user");
			} else if($scope.breakInSearchActionBtnText === "Upload Photo"){
				uploadPhotoFromList = false;
				vehRegNo = CommonServices.searchResponseData.registrationNo;
				$state.go('uploadPhoto.uploadPhoto');
			}else if($scope.breakInSearchActionBtnText === "Reason"){
				CommonServices.showAlert("The break in insurance approval for quote " + CommonServices.searchResponseData.quoteNo + " is rejected by approver on the ground of " + CommonServices.searchResponseData.reason);
			} 
		}
		
	};
	
	$scope.viewUploadedPhotos = function(){
		
		var breakInQuoteUploadedDocsData = {
			"quote":{
				"quoteNumber": $scope.breakInQuoteSearch 
				}
			};
			CommonServices.uploadJson = false;
		var breakInQuoteUploadedDocsResponse = RestServices.postService(RestServices.urlPathsNewPortal.fetchUploadedBreakinDocuments, breakInQuoteUploadedDocsData);
		if(breakInQuoteUploadedDocsResponse === undefined){
		}else{
		    breakInQuoteUploadedDocsResponse.then(
            function(response) {
                CommonServices.showLoading(false);
                    if(response.data.errorCode === "0"){
                        if(response.data.documentDeatils.length === 0){
                            CommonServices.showAlert("Problem in loading documents. Please try again");
                        } else {
                            angular.extend($scope.uploadedPhotoList,response.data);
                            $state.go('uploadPhoto.viewUploadedPhoto');
                        }
                    } else{
                        CommonServices.showAlert("Could not connect to server. Please try again later.");
                    }
            },
            function(error) { /* failure */
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            });
		}

	};
	
	
	
}]);

agentApp.controller('viewUploadedPhotoCntl', ['$rootScope','$scope','$location','RestServices','CommonServices','$state','$timeout', function ($rootScope,$scope,$location, RestServices,CommonServices,$state,$timeout) {
    
    $scope.otherImageSrc = [];
	if(selectedQuoteProductCode === "TW"){
		$scope.showLeftRight = false;
	} else {
		$scope.showLeftRight = true;
	}
	for(var i=0; i< $scope.uploadedPhotoList.documentDeatils.length; i++){
	    if($scope.uploadedPhotoList.documentDeatils[i].documentIDorRefer.toUpperCase().indexOf("FRONT") > -1){
	    	if($scope.uploadedPhotoList.documentDeatils[i].documentURL === undefined) {
	    		$scope.frontImageSrc = "images/docNotFound-320x321.png";
	    	} else {
	    		$scope.frontImageSrc = $scope.uploadedPhotoList.documentDeatils[i].documentURL;
	    	}  
	    } else if($scope.uploadedPhotoList.documentDeatils[i].documentIDorRefer.toUpperCase().indexOf("REAR") > -1) {
	    	if($scope.uploadedPhotoList.documentDeatils[i].documentURL === undefined) {
	    		$scope.rearImageSrc = "images/docNotFound-320x321.png";
	    	} else {
			 	$scope.rearImageSrc = $scope.uploadedPhotoList.documentDeatils[i].documentURL;
			}
		} else if($scope.uploadedPhotoList.documentDeatils[i].documentIDorRefer.toUpperCase().indexOf("LEFT") > -1) {
			if($scope.uploadedPhotoList.documentDeatils[i].documentURL === undefined) {
	    		$scope.leftImageSrc = "images/docNotFound-320x321.png";
	    	} else {
				$scope.leftImageSrc = $scope.uploadedPhotoList.documentDeatils[i].documentURL;
			}
		} else if($scope.uploadedPhotoList.documentDeatils[i].documentIDorRefer.toUpperCase().indexOf("RIGHT") > -1) {
			if($scope.uploadedPhotoList.documentDeatils[i].documentURL === undefined) {
	    		$scope.rightImageSrc = "images/docNotFound-320x321.png";
	    	} else {
				$scope.rightImageSrc = $scope.uploadedPhotoList.documentDeatils[i].documentURL;
			}	
		} else if($scope.uploadedPhotoList.documentDeatils[i].documentIDorRefer.toUpperCase().indexOf("SPEEDO") > -1) {
			if($scope.uploadedPhotoList.documentDeatils[i].documentURL === undefined) {
	    		$scope.speedoMeterImageSrc = "images/docNotFound-320x321.png";
	    	} else {
				$scope.speedoMeterImageSrc = $scope.uploadedPhotoList.documentDeatils[i].documentURL;
			}
		} else if($scope.uploadedPhotoList.documentDeatils[i].documentIDorRefer.toUpperCase().indexOf("PREVIOUS") > -1) {
			if($scope.uploadedPhotoList.documentDeatils[i].documentURL === undefined) {
	    		$scope.previousPolicyImageSrc = "images/docNotFound-320x321.png";
	    	} else {
				$scope.previousPolicyImageSrc = $scope.uploadedPhotoList.documentDeatils[i].documentURL;
			}
        }
        else if($scope.uploadedPhotoList.documentDeatils[i].documentIDorRefer.toUpperCase().indexOf("OTHER") > -1) {
			if($scope.uploadedPhotoList.documentDeatils[i].documentURL === undefined) {
	    		$scope.otherImageSrc.push("images/docNotFound-320x321.png");
	    	} else {
				$scope.otherImageSrc.push($scope.uploadedPhotoList.documentDeatils[i].documentURL);
            }
        }
        else if($scope.uploadedPhotoList.documentDeatils[i].documentIDorRefer.toUpperCase().indexOf("CHASSIS") > -1) {
			if($scope.uploadedPhotoList.documentDeatils[i].documentURL === undefined) {
	    		$scope.chasisImageSrc = "images/docNotFound-320x321.png";
	    	} else {
				$scope.chasisImageSrc = $scope.uploadedPhotoList.documentDeatils[i].documentURL;
            }
        } 
	}
	
	$(".photo-container").on("click",'img', function(event){

    var eIid=event.currentTarget.getAttribute("id");
    var eSrc=event.currentTarget.getAttribute("src");
     $("#popup-container").show();
    $("#image-preview").show();
    $("#image-preview img").attr("src",eSrc);
    var imgTarget="#"+eIid;
     $(document).off('click touchstart', '#popup-container');
     $(document).on('click touchstart', '#popup-container', function(){
       $scope.closePopUp();
     });
  });
  
  $scope.closePopUp = function(){
		$("#popup-content").hide();
		$("#popup-container").hide();
		$("#image-preview").hide();
		$("#calendar-container").hide();
		$("#timePickerSelectCntr").hide();
		$("#upload-options").hide();
		$("#slide-container").show();
	};
	
}]);

agentApp.controller('uploadPhotoCntl', ['$rootScope','$scope','$location','RestServices','CommonServices','$state','$timeout', function ($rootScope,$scope,$location, RestServices,CommonServices,$state,$timeout) {

	$scope.quoteNo = breakInQuote;
	$scope.vehicleNo = vehRegNo;
     
    //CR_0944 starts here
    $scope.formModel = {};
    
    // $scope.checkLocation = function(){
    //     let options = {maximumAge: 60, timeout: 8000, enableHighAccuracy:true};
    //         CommonServices.showLoading(true);
    //         navigator.geolocation.getCurrentPosition(function(position){
    //             CommonServices.showLoading(false);
    //             // console.log(position);
    //         }, function(err){
    //             CommonServices.showAlert("Please activate the GPS of the device to capture the location.");
    //             CommonServices.showLoading(false);
    //         }, options);
    // }

    $scope.checkDocUpload = function(){
        
        if(($scope.formModel.damagesRemarks && $scope.formModel.damagesRemarks!="") && ($scope.formModel.speedometerReading && $scope.formModel.speedometerReading!="") && ($scope.formModel.placeInspection && $scope.formModel.placeInspection!="")){
            return true;
        }else return false;
    }

    // $scope.checkLocation();

    $scope.locationInput = document.getElementById('locatorSearchBoxInput');  
    $scope.autocomplete = new google.maps.places.Autocomplete($scope.locationInput);
    $scope.autocomplete.addListener('place_changed', function() {
        
        let place = $scope.autocomplete.getPlace();
        $scope.$apply(function() {
            $("#locatorSearchBoxInput").val(place.formatted_address);
            $scope.formModel.placeInspection = place.formatted_address;
            $rootScope.locatorMap.currentPlace = $scope.formModel.placeInspection;
        });
    });

    $scope.clearPlace = function(){
        $scope.formModel.placeInspection = "";
        $rootScope.locatorMap.currentPlace = "";
    }

    $scope.getCurrentLocation = function() {
        
        let options = {
          enableHighAccuracy: true,
          timeout: 8000,
          maximumAge: 60
        };

        CommonServices.showLoading(true);
        // if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition($scope.showPosition, $scope.showError,options);

        // } else {
        //     CommonServices.showLoading(false);
        //     CommonServices.showAlert("Please activate the GPS of the device to capture the location.");
        // }
        
    }
    
    var geocoder = new google.maps.Geocoder;
    
    $scope.showPosition = function(position) {

        
        $rootScope.locatorMap.currentLocationlat = position.coords.latitude;
        $rootScope.locatorMap.currentLocationlong = position.coords.longitude;

        var pos = {
            lat:position.coords.latitude,
            lng:position.coords.longitude
        };

        
        geocoder.geocode({'location': pos}, function(results, status) {
            CommonServices.showLoading(false);
            if (status === 'OK') {
              if (results[0]) {
                
                $scope.$apply(function() {
                    $("#locatorSearchBoxInput").val(results[0].formatted_address);
                    $scope.formModel.placeInspection = results[0].formatted_address;
                    $rootScope.locatorMap.currentPlace = $scope.formModel.placeInspection;
                });

              } else {
                $scope.formModel.placeInspection = "";
                $rootScope.locatorMap.currentPlace = "";
                CommonServices.showAlert('No results found');
              }
            } else {
                $scope.formModel.placeInspection = "";
                $rootScope.locatorMap.currentPlace = "";  
                CommonServices.showAlert('Geocoder failed due to: ' + status);
            }
        });
    };

    $scope.showError = function(error) {
        CommonServices.showLoading(false);
        switch (error.code) {
            case error.PERMISSION_DENIED:
                CommonServices.showAlert("Please activate the GPS of the device to capture the location.");
                break;
            case error.POSITION_UNAVAILABLE:
                CommonServices.showAlert("Location information is unavailable.");
                break;
            case error.TIMEOUT:
                CommonServices.showAlert("Please activate the GPS of the device to capture the location.");
                break;
            case error.UNKNOWN_ERROR:
                CommonServices.showAlert("An unknown error occurred.");
                break;
        }
    }

    // if($rootScope.locatorMap && $rootScope.locatorMap.currentPlace){
    //     $scope.formModel.placeInspection = $rootScope.locatorMap.currentPlace;
    // }else{

    //     $rootScope.locatorMap = {};
    //     $scope.getCurrentLocation();
    // }
    $scope.getCurrentLocation();
    //CR_0944 ends here


	if(selectedQuoteProductCode === "TW"){
		$scope.showLeftRight = false;
	} else {
		$scope.showLeftRight = true;
	}
	
	$scope.documentPhotoUpload={
            uploaddocsmodel : [],
            uploaddocscollection :[]
        };

	$("#popup-container").on("click", function(){
		 $(this).hide();
	});


    $scope.chooseImageUploadOption=function(event){
        
        
      $scope.artID = $(event.target).parent().parent().parent().attr("id");
      $scope.imgCount = $('#'+$scope.artID+' img').length;
      let imageCnt = $scope.artID==='others-article'?5:1; //CR_0944 added
     // $scope.maxImageCount=5;
     // $scope.totalImageCount=$(".photo-container img").length;

    if($scope.imgCount < imageCnt){
      $("#upload-options").show();
       $("#popup-container").show();
      $(document).off('click', '#capture-photo-cam');
      $(document).on('click', '#capture-photo-cam', function(e) {
        e.stopPropagation();
      });
	  $scope.pictureFromCam($scope.artID);

      // $(document).off('click', '#select-photo-gallery');
      // $(document).on('click', '#select-photo-gallery', function(e) {
        // e.stopPropagation();
        // $scope.pictureFromGallery($scope.artID);
      // });

      // $(document).off('click', '#popup-container');
      // $(document).on('click', '#popup-container', function(){
              // $scope.closePopUp();
            // });
      }
      else{
          //CR_0944 modified
        CommonServices.showAlert("Maximum "+ imageCnt +" document can be uploaded for "+$('#'+$scope.artID+' .doc-label').text());
        return false;
      }
    };
	
  $scope.pictureFromCam = function(event) {
    $("#upload-options").hide();
     $("#popup-container").hide();
    $scope.capturePhoto($scope.artID,true);
  };

  $scope.capturePhoto = function(event,fromCam) {

        if(CommonServices.deviceType == "A"){
          navigator.camera.getPicture($scope.onSuccessImageUploadAndroid,$scope.onFailImageUploadAndroid,{quality: 85,destinationType: 0,targetWidth: 2048,targetHeight: 2048 });
        }else if(CommonServices.deviceType == "I"){
          navigator.camera.getPicture($scope.onSuccessImageUploadAndroid,$scope.onFailImageUploadAndroid,{quality: 50,destinationType: 0,targetWidth: 2048,targetHeight: 2048 });
        } else {
             var fileURI="/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAUDBAQEAwUEBAQFBQUGBwwIBwcHBw8LCwkMEQ8SEhEPERETFhwXExQaFRERGCEYGh0dHx8fExciJCIeJBweHx7/2wBDAQUFBQcGBw4ICA4eFBEUHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh7/wAARCASACAADASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD5dRFUbcE+tOUADFAJHB5PtSgHk96x1NEhMAIelInAz1pxBIpEA/OgVhyj5e9C455oOM5OePehcA5x1osINqk7iMkVSkObvNaBPHtVCUYuVB6HihBcnUAn0qYsD8o9OtMABHHGOKVQM5PagBQDt44xTgTnk0Ee/FKoHWmNEiKeOe9XY0OzntVWHG4A85NXhgA5yaVx2CMHOGxnpUqkY5pIxnrj2p4FG4hVJHHJHY0bQWyMcUdcAZ4pFOSenFKwDgRwR16U1uhXjFISd2M8UsgB9KQzP1k7LFgOPWuewPvY61u+JSDbqg4yRWCuMGrRDQ5elOUY+WmhSV9u1SKD1AzjtVoSI7kkAD3pFGQMUsp3cEYpqjAzmkhDsHJxSjI6dKTtzS8CgBVBz0xRkY4Xkd6XBIxk4pVHagAUDHUZpOcmnIuM96cMdMipEMBx1FKMlj2oxjPOaBgnj9aoA5J9qVRgE/pQA2OMcU9AecHNAXAAkHJpU3BcZpQMqfrTckg+lAK4vPqCKaCW+nanKMrSr1IxgjvQLcjlHyFR8vrSxkBMDNJN90Fs8075ABnI4q4lIUAnvgdqBgAjvRgnnHApcAnAqwYIB05oHyggHnvQpAGP1prfeyBSEO/iGKdxzgfWmZOeOKUDPBPNAC9/pQclsnoOtHsaQD5sE/jSsA7Iz1696cOlIMAZHHagEnkcVSAByQeeKeSQcHpTSwAzkelKuTkUBEQrhST2qg27ec1oPkKe/FZ7YycdzQBLaD98D+VdR4MUN4hti5zlyPwOa5i05kJzjjFdX4Hw3iG35PGf5dKhvQEepsMHHUVyPiZDJrrRTCRQ0QKkDj0FdZqQuWsnNkyLN/CWGRXKXer6o159ludOhmlQfdAJ/Ks0UZFiqLNayQzuHEoDpuPBBr0FSdrM2CT1HvXHW1zaf2vH9q0p4biRxgldpB6Z5612ZQc7R06CqkIytJQm1lPA+c+3etKLIiXkZI61m6ZuNpKWbgyNge2TWogyir0GKzKSQ61XNxjI6ZFX+ScelUbXi43Y3HpV6STYhkbAUDmpNEMmKL3BNRlSQcgYPFZmozxSXMIW4AjbqQcc1YhtmWXzIrtvdSQQRTSEy05CKWwTgdqyoRiNgOMHNbLjCkdSBmsePBRmPOSaoRY0lc3zDHVK2FBxkd+1ZWi5N++T/B09K2ABkjFSxoYpDBsnkU5ABz3HApcJsycCjsMCkwSEVCec5pygEkDtTuNvHHHSkydx/SgBGXPC0oUjJ7GlX15zTgMNlsigYwAEcDp3xQBwTinAZJ44NOBGNo7dqAIguTvY4xTs53cnFOKk55P+NBXK454oFYjIA+YD3pwII6fpQo2dyTTsZPB70WAYfvYGeacvy/N3p+McjrRtAODigZHzksO9KmclT360o75NO7//AFqYkRhcMeMYOaCuSSTz34qROBzxikYFu/BpoQ1cjJHU8UqY2sBwaUfKSo60pXAySKYDVXdntilPGcDk0cE9aVQe1KwDAGKcjHH5UpPyYyPanDOTxkZo7YxSAOp/DrQF68jFOwd3bpSKuc9hVIBhOWA6CpAB0pGXsP0pw+U8nk0hIawLN2GKAOtOGQfTvSMegpDEAwcYz9KbsxzjtUgUAZJGfWgZLHnjFNCGqc/LS4xinDuM80jHgnFAIMAjkdqRepA7UDdnPalXIPy1IxMcc9e1ABP3h1FOAwMnAoAYsT2FG4CA5zgdKMe/SnDp05pBgcnrTSEIF79DTSpLcgcU87ipJx+dISxwVGKoQ3gHHfNKBhTS7cAs2KUDjnoRSYIYmSuKdghccc0cZwMgUYznPepSHcRMcg4xS4xgilxx9KGGfuimKw0/e4pQoAwTmjoc0AfNz0pgNUAg46UZwMDrUg28jntSHAHvQkDZHyozjrS4IB560KDltxpR19j6UxCHsBS/dUgd6MYxk5OKcM7ecUmC0G4G3JPtSdXB9BQFIb5TxTj8vTueTRYdxGbA25xxQBgc0qqM5IyaPvE88UARoSWwF4px4+XqBThnHy0AYXPfFADEwATjHHU0R5PJo5Yc0p44HJphcQ5PINKAQD+XFKuNvv3pEPJzxn1pBYaQVXPbNI2HcgnJqQ89BSPwfehAMCqDx1owQaXHy5HpRg4+nWkwSEK8Zx7U0gbSDzT+gIzSBcd8CkUNRdq574poXAyOfan478+1LkHhSeOlNCK+csc9ulPI+XGB044p5X5Cx+9TeTmmK4zaByaawXAA4GamAGAMUhUDjigLXIWyy7RSMoSPk5qVVG7I6fWmkA85NG4iIbd27GSaxfEEiJLGtxatKshCo6MMg4NbhB3Y7fyrJ8QqjWxb94jwOJI2HqBQhFPSLqT+0ks383ymRiqyg5GPQ1ur9zrWJpbS3upwTzurGBCFwuODW4B/LrTGRuuR92mjk5xyDUgGAKB9zOO9QykMbrjNMxxipece4pj9BtBGaAIsDn0pGU/41JsXZk9aRVzyTgCqTFYi2+tAAIxxT2GCSOaaVBPTtQBEw5PFNKhiMjFS45JxSMN3QdOtMViLH3hg5+lJsGM1ISTxjFIVyMcikNEWwbSCMAVGSVY/pU5GOSM5pjAlgMjGKQWIynynNN2j1qUg5wQaaygDO7n2osBFzkjjAoGcUoU8gAkGlAAzwevSmMgHOS/HNAw3JzUhA3HGfpSFAVOKAImJYkc4ppwcj86eBjrjHrTTyGAH/wBegaImGBx0poBGeM1M4+UL7daYBjjP44pgMPHY/WmkZyO9SYypyTUeOpHNAAQQee1RkADOD6CpON24nBxSE5XPoaAIhySSOvWmnGOOtSAHByRmmYBB5xQA3cM9hTTg+oNO2jGcc01xjr1JxQBGSN3FJjPtSuAM4/Sm9RkMaQhhVWyGRWAOOaglsrMqQ9tEc9flBqztwP60wjIJ6ihAZ0ui6PId32RVJ/u8VWl8L6UwJjMqH68flitcjB+U03+v6VSk0KxzsvhK2Kny7t1/3lqm3hO4AJjmibj+I4rrSQ3ykHJHemgEDsfTiqUxcpxE3hrUUJKRK4H91s5qpNpF/ENzWkuM44Gf5V6EGdCSDjFAdtoxxinzgoHmb2lwrcwyAj1UiomSQfwtgV6e7K+Q8Yb6iq8trZSDc9tGSfbFCaDlPNdrE9PzpQzA4Fd/Jo+mSE/6MFJ9+lU5fDdgc7HkU9jwadxcpxoY4PFGa6ebwvwTFe";
             this.onSuccessImageUploadAndroid(fileURI);
        }
    };


    $scope.onSuccessImageUploadAndroid = function(fileURI) {

        var height=$("#document-upload-wrapper").height();
        var fileURISize = sizeof(fileURI)/(1024*2.67);

        //if(fileURISize>1&&fileURISize<1025){
            if(fileURISize>1&&fileURISize<2049){ //24-06-2020 2 MB as per client suggestion
            var that=this;
            var queryString;
            var fileDATAURI = fileURI;
            var rId= Math.floor(Math.random() * (999 - 100 + 1)) ;
            var imageType=$('#'+$scope.artID+' .doc-label').text();
            if(imageType=='Previous Policy Document') imageType = ("Previous Policy").toLowerCase(); //CR_0944 added
            else if(imageType=='Other (Optional)') imageType = "Other"; //CR_0944 added
            var fileNamePrefix=rId;
            var newFileName=imageType+"_"+fileNamePrefix+".JPG";
            var newFileName1=imageType.replace(/ /g,"_")+"_"+fileNamePrefix;
            newFileName1 = newFileName1.replace(/[&\/\\#,+()$~%.'":*?<>{}]/g, ''); //CR_0944 added
            var imageId = fileNamePrefix +"-img";
            var content;
            //$scope.documentPhotoUpload.uploaddocsmodel.push(content);

            $("#"+$scope.artID+" .photo-container").append("<div class='image-conatiner' dataval="+fileNamePrefix+" id="+newFileName1+"><img id ="+imageId+" data="+newFileName+" dataval="+fileNamePrefix+"  src='data:image/JPEG;base64,"+fileDATAURI+"' /><span class='delete-image-icon' dataval="+fileNamePrefix+" datasuccess="+newFileName+" id="+fileNamePrefix+" ></span></div>");
            
            $scope.watermark(imageId);
            content={
                imageType:imageType,
                documentName:newFileName,
                documentId :fileNamePrefix,
                docByteString:$('#'+imageId).attr('src').slice(23),
                User_ID:CommonServices.getCommonData('userId'),
                imageId: imageId,
                artID: $scope.artID
            };
            $scope.documentPhotoUpload.uploaddocscollection.push(content);
        } else {
            CommonServices.showAlert( "Image size should be less than 2MB" );
            return false;
        }
    };


    $(".photo-container").on("click",'.delete-image-icon', function(e){
            e.stopPropagation();
            var dataval = parseInt(e.currentTarget.getAttribute("dataval"));
            $scope.loadDeletePopUp(e,dataval);
    });

    $scope.watermark = function(imageId) {
        var timestampResponse = RestServices.getService(RestServices.urlPathsNewPortal.getServerTime);
        timestampResponse.then(
        function(response){
            var timestamp = response.data.systemTimeStamp;
            if (response.data.systemTimeStamp != undefined) {
                var dtArr = response.data.systemTimeStamp.split(" ");
                var dateArr = dtArr[0].split("-");
                var timeArr = dtArr[1].split(":");

                var dd = +dateArr[2];
                var mm = +dateArr[1];
                var yyyy = +dateArr[0];

                var hours = +timeArr[0];
                var minutes = +timeArr[1];
                var seconds = parseInt(timeArr[2]);
                var ampm = hours >= 12 ? 'PM' : 'AM';
                hours = hours % 12;
                hours = hours ? hours : 12; // the hour '0' should be '12'
                if(dd < 10) dd='0'+dd;
                if(mm < 10) mm='0'+mm;
                hours = hours < 10 ? '0'+hours : hours;
                if(minutes.toString().length < 2)
                    minutes = '0'+minutes;
                if(seconds.toString().length < 2)
                	seconds = '0'+seconds;
                
                timestamp = dd+':'+mm+':'+yyyy + ' ' + hours + ':' + minutes + ':' + seconds + ' ' + ampm;
            }

            CommonServices.showLoading(false);
            var imageTimeStamp = {imageId, timestamp};
            $scope.timeStampList.push(imageTimeStamp);         
            $(function() {
                $('#'+imageId).watermark({
                    text: timestamp,
                    textSize: 90,
                    textWidth: 1200,
                    gravity: 'se',
                    textColor: 'red'
                });
            });
        },
        function(error){
            CommonServices.showLoading(false);
            RestServices.headerWithoutToken = false; 
        });
    }


    $(".photo-container").on("click",'img', function(event){

        var eIid=event.currentTarget.getAttribute("id");
        var eSrc=event.currentTarget.getAttribute("src");
        $("#popup-container").show();
        $("#image-preview").show();
        $("#image-preview img").attr("src",eSrc);
        var imgTarget="#"+eIid;
        $(document).off('click touchstart', '#popup-container');
        $(document).on('click touchstart', '#popup-container', function(){
        $scope.closePopUp();
        });
    });

    $scope.loadDeletePopUp = function(event,dataval){
        
        var id = "#"+$(event.target).parent().attr("id");

        $("#popup-container").show();
        $("#popup-content").show();
        $("#popup-content").off().on('click',function(){
            $scope.closePopUp();
        });

        $("#btn-yes").off().on('click',function(){
            $scope.closePopUp();
            var myEl = angular.element( document.querySelector(id) );
            myEl.remove();
            for(var i=0 ; i<$scope.documentPhotoUpload.uploaddocscollection.length; i++)
            {
                if($scope.documentPhotoUpload.uploaddocscollection[i].documentId===dataval)
                {              
                    var imageId = $scope.documentPhotoUpload.uploaddocscollection[i].documentId + "-img";
                    if($scope.timeStampList[i].imageId === imageId){
                    $scope.timeStampList.splice(i,1);
                    }
                    $scope.documentPhotoUpload.uploaddocscollection.splice(i,1);
                    break;
                }
            }		
            var totalImageCount=$(".photo-container img").length;
            var maxImageCount=10;
            if(totalImageCount<maxImageCount){
            $('.uploadVehPhotoAndr').removeClass("disableCamera");
            }
        });

        $("#btn-no").off().on('click',function(){
            $scope.closePopUp();
        });

    };

    $scope.onFailImageUploadAndroid = function() {
        app.log("Image Upload Failed");
    };

    $scope.closePopUp = function(){

            $("#popup-content").hide();
            $("#popup-container").hide();
            $("#image-preview").hide();
            $("#calendar-container").hide();
            $("#timePickerSelectCntr").hide();
            $("#upload-options").hide();
            $("#slide-container").show();
    };
    
        function watermarkBeforeUpload(imageId){
            var timeStamp = "";
            for(var i=0; i< $scope.timeStampList.length;i++){
                if($scope.timeStampList[i].imageId === imageId){
                    timeStamp = $scope.timeStampList[i].timestamp;
                    break;
                }
            }
            
            $(function() {
                $('#'+imageId).watermark({
                    text: timeStamp,
                    textSize: 90,
                    textWidth: 1200,
                    gravity: 'se',
                    textColor: 'red'
                });
            });
        }

    $scope.docUploadSubmit = function(event){

        if($(".photo-container img").length=== 0){
            CommonServices.showAlert("No images to submit");
            return false;
        }
        if ($('#front-article img').length === 0) { CommonServices.showAlert("Please upload the mandatory document for Front ");return false;};
        if ($('#rear-article img').length === 0) { CommonServices.showAlert("Please upload the mandatory document for Rear");return false;};
        if(selectedQuoteProductCode === "PC" || selectedQuoteProductCode === "CV"){
            if ($('#left-article img').length === 0) { CommonServices.showAlert("Please upload the mandatory document for Left");return false;};
            if ($('#right-article img').length === 0) { CommonServices.showAlert("Please upload the mandatory document for Right");return false;};
        }
        if ($('#speedo-meter-article img').length === 0) { CommonServices.showAlert("Please upload the mandatory document for Speedo Meter");return false;};
        if ($('#chasis-article img').length === 0) { CommonServices.showAlert("Please upload the mandatory document for Chassis Number");return false;};
        
        //CR_0944 added
        if ($('#policy-article img').length === 0) { CommonServices.showAlert("Please upload the mandatory document for Previous Policy");return false;};
        
        var imageCollection = $scope.documentPhotoUpload.uploaddocscollection;
        var imageCollectionLength = imageCollection.length;
        
        for(var i=0; i < imageCollectionLength; i++){
            var imageId = $(".photo-container img")[i].id;
            watermarkBeforeUpload(imageId);
            var fileDATAURI = $('#'+imageId).attr('src').slice(23);
            $scope.documentPhotoUpload.uploaddocscollection[i].docByteString = fileDATAURI;
        }        
        var documentsList = [];

            for (var i = 0; i < imageCollectionLength; i++) {

                if ($scope.documentPhotoUpload.uploaddocscollection[i].documentIndex === undefined) {                    
                        
                var imageList = {
                    "documentName": imageCollection[i].documentName,
                    "docByteString": imageCollection[i].docByteString,
                    "documentType": "QUOTATION~SCANNED IMAGE",
                    "toBeUploadedFlag": "true",
                    "duplicateFlag": "false"
                };
                    documentsList.push(imageList);
                    imageList="";
                }
            }

            if (documentsList.length === 0) {
            CommonServices.showAlert("No new images to submit","Alert");
            return;
            }
            
            var docUploadInput = {
                "alfrescoInput": {
                    "channel": "AGENT",
                    "language": "ENGLISH"
                },
                "uploadType":"BREAKIN",
                "userProfile": {
                    "userId": CommonServices.getCommonData("userId"),
                    "branchCode": branchCode,
                    "emailId": CommonServices.getCommonData("emailId"),
                    "mobileNo": CommonServices.getCommonData("mobileNo")
                },
                "documentDetailsList":[{
                    "quoteNo": breakInQuote,
                    "uploadType":"BREAKIN",
                    "documentsDetails":	documentsList,
                    "registrationNo": vehRegNo
                }],
                "damages_noticed_and_remarks": $scope.formModel.damagesRemarks, //CR_0944 added
                "speedometer_reading": $scope.formModel.speedometerReading.toString(), //CR_0944 added
                "place_of_inspection": $scope.formModel.placeInspection, //CR_0944 added
            }; 
            
            
            var docUploadResponse = RestServices.postService(RestServices.urlPathsNewPortal.uploadDocumentsGen, docUploadInput);
            if(docUploadResponse === undefined){
            }else{
                docUploadResponse.then(
                function(response) { // success

                CommonServices.showLoading(false);
                if(response.data.errorCode === "0") {
                    /* if(CommonServices.deviceType !== "NA"){
                            navigator.notification.alert(
                                "The photos are uploaded successfully, please check with nodal office for break in approval", // message
                                photoUploadSuccess, // callback
                                "Alert", //title
                                'ok' // buttonName
                            );
                            
                        } else {
                            CommonServices.showAlert("The photos are uploaded successfully, please check with nodal office for break in approval");
                            photoUploadSuccess();
                        } */
                        var msg = "The photos are uploaded successfully, please check with nodal office for break in approval";
                        CommonServices.messageModal('info', msg, false, '', 'Ok', function () {}, function () {photoUploadSuccess();}, 'Alert');
                            
                } else if(response.data.errorCode === "1"){
                    CommonServices.showAlert(response.data.errorMessage);
                } 
                else {
                    CommonServices.showAlert("Problem in uploading photos. Please try again.");
                }

                },
                function(error) { // failure
                    CommonServices.showLoading(false);
                    RestServices.handleWebServiceError(error);
                });
            }
        }
    //CR_NP_0917
    $scope.docUploadVideoSubmit = function(event){

        $rootScope.breakinModel = {}; // CR_0944 added
        $rootScope.breakinModel = angular.copy($scope.formModel); // CR_0944 added

            $state.go('uploadVideo'); //CR_3585


            /******commented as per CR_3585
        window.plugins.launcher.canLaunch({packageName:'com.nia.inspection'}, successCallback, errorCallback);

        function successCallback()
        {
                window.plugins.launcher.launch({packageName:'com.nia.inspection'}, successCallback, errorCallback);

                            var successCallback = function(data) {

                                };
                            var errorCallback = function(errMsg) {

                                }

                photoUploadSuccess();
        };
        function errorCallback(errMsg)
        {

                if (CommonServices.deviceType == "I") {
                    window.open("https://itunes.apple.com/gb/com.nia.inspection","_system");
                }
                else{
                    window.open("https://play.google.com/store/apps/details?id=com.nia.inspection", "_system");
                }

        }

        */
    }
    //END CR_NP_0917

    function photoUploadSuccess(){
        if(uploadPhotoFromList){
        $state.go('uploadPhoto.breakInQuotesList');
        } else {
        $state.go('uploadPhoto.breakInQuoteSearch');
        }
    }

    $scope.redirectToMap = function(){
        
        let locationObj = {
            damagesRemarks: $scope.formModel.damagesRemarks,
            speedometerReading: $scope.formModel.speedometerReading,
            placeInspection: $scope.formModel.placeInspection,
            documentPhotoUpload: $scope.documentPhotoUpload
        }
        CommonServices.setCommonData('locationModel', locationObj);
        $state.go('uploadPhoto.placeOfInspection');
    }

}]);


agentApp.controller('placeOfInspectionCntl', ['$rootScope','$scope','$location','RestServices','CommonServices','$state','$timeout', function ($rootScope,$scope,$location, RestServices,CommonServices,$state,$timeout) { 

    // $scope.showMap = false;
    $scope.formModel = {};

    $scope.initPosition = function(){
        CommonServices.showLoading(true);
        let options = {maximumAge: 60, timeout: 2000, enableHighAccuracy:true};
        navigator.geolocation.getCurrentPosition(function(position){
            CommonServices.showLoading(false);
            if($rootScope.locatorMap.currentLocationlat===undefined && $rootScope.locatorMap.currentLocationlong===undefined){
                $rootScope.locatorMap.currentLocationlat = position.coords.latitude;
                $rootScope.locatorMap.currentLocationlong = position.coords.longitude;
            }
            $scope.initMap($rootScope.locatorMap.currentLocationlat,$rootScope.locatorMap.currentLocationlong);
            
        }, function(err){
            CommonServices.showLoading(false);
            var msg = "Please activate the GPS of the device to capture the location.";
            CommonServices.messageModal('info',msg,false,'','Ok',function(){},function(){$scope.goBack();},'Alert')
        }, options);
    }
    
    $scope.locationInput = document.getElementById('locatorSearchBoxInput');  
    $scope.autocomplete = new google.maps.places.Autocomplete($scope.locationInput);
    $scope.autocomplete.addListener('place_changed', function() {
        
        let place = $scope.autocomplete.getPlace();
        $scope.formModel.placeInspection = place.formatted_address;
        $scope.initMap(place.geometry.location.lat(),place.geometry.location.lng());
    });

    CommonServices.setCommonData("isPlaceOfInspection", true);

    $scope.getCurrentLocation = function(ev) {
        
        let options = {
          enableHighAccuracy: true,
          timeout: 2000,
          maximumAge: 60
        };

        CommonServices.showLoading(true);
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition($scope.showPosition, $scope.showError,options);

        } else {
            CommonServices.showLoading(false);
            CommonServices.showAlert("Please activate the GPS of the device to capture the location.");
        }
        
    }
    
    var geocoder = new google.maps.Geocoder;
    $scope.showPosition = function(position) {

        $rootScope.locatorMap.currentLocationlat = position.coords.latitude;
        $rootScope.locatorMap.currentLocationlong = position.coords.longitude;

        var pos = {
            lat:position.coords.latitude,
            lng:position.coords.longitude
        };

        
        geocoder.geocode({'location': pos}, function(results, status) {
            CommonServices.showLoading(false);
            if (status === 'OK') {
              if (results[0]) {
                
                $scope.$apply(function() {
                    $("#locatorSearchBoxInput").val(results[0].formatted_address);
                    $scope.formModel.placeInspection = results[0].formatted_address;
                });

              } else {
                CommonServices.showAlert('No results found');
              }
            } else {
              CommonServices.showAlert('Geocoder failed due to: ' + status);
            }
        });
    };

    $scope.showError = function(error) {
        CommonServices.showLoading(false);
        CommonServices.showAlert("Please activate the GPS of the device to capture the location.");
    }

    $scope.initMap = function(lat,lang) {
        
        let myLatLng = {lat: lat, lng: lang};
        let position = {
                coords : {}
            }; 
            
        position.coords.latitude = lat;
        position.coords.longitude = lang;
        $scope.showPosition(position);

        var map = new google.maps.Map(document.getElementById('map'), {
            zoom: 17,
            center: myLatLng
        });

        var marker = new google.maps.Marker({
            position: myLatLng,
            map: map,
            title: '',
            draggable:true,
            icon: 'images/location_pointer.svg',
        });

        google.maps.event.addListener(marker, 'dragend', function(marker){
            let latLng = marker.latLng;
            let position = {
                coords : {}
            }; 
            
            position.coords.latitude = latLng.lat();
            position.coords.longitude = latLng.lng();
            $scope.showPosition(position);
        }); 
    }

    $scope.initPosition();


    $scope.savePlace = function(){
        $rootScope.locatorMap.currentPlace = $scope.formModel.placeInspection;
        $state.go('uploadPhoto.uploadPhoto');
    }
    $scope.goBack = function(){
        $state.go('uploadPhoto.uploadPhoto');
    }
    
}]);
