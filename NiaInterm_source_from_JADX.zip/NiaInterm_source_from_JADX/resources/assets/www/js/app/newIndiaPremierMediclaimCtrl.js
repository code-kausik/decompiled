agentApp.controller('newIndiaPremierMediclaimCtrl', ['$scope','RestServices','CommonServices','$state','$rootScope', function ($scope, RestServices,CommonServices,$state,$rootScope) {
    
    if(CommonServices.editQuoteFlag === true){
        	$rootScope.policyDetailsObj = {};
    }
    
      $scope.goBack = function(){
          
          if(CommonServices.editQuoteFlag === true){
              $state.go("managePolicies.managePolicies");
          }else{
            CommonServices.newIndiaPremierMediclaim.fromBasicPremium = false;
        //CommonServices.topUpObj.searchBoxEnable = false;
            $state.go("topUpMediclaimLandingScreen");      
          }
    };
//
//   
    /*Start CR_3449 */
	  $scope.sumInsuredMsg = false;
    $scope.typeOfCoveChange = function () {
    	if ($scope.premiumCalcModels.typeOfCover === 'INDIVIDUAL') {
            $scope.sumInsuredMsg = true;
            $scope.sumInsuredMsgScope = 'Sum Insured amount will be Individual Limit for each member in a family.';
        } else if($scope.premiumCalcModels.typeOfCover === 'FLOATER') {
            $scope.sumInsuredMsg = true;
            $scope.sumInsuredMsgScope = 'Sum Insured will be single overall limit for entire policy.';
        }else{
        	$scope.sumInsuredMsg = false;
        }
    };
   /* End CR_3449 */
    
      $scope.planBSelected =false;
      //$scope.childAgeIsMore = false;
    
      $rootScope.prodDiscOpen = false;
    
    
      $scope.termsAndCondition = function(){
            $rootScope.enableTermsCondions = true;
            $rootScope.prodDiscOpen = true;
            $rootScope.readTermsAndCondp2="I understand that by providing my mobile no and e-mail id through the Online Portal, I agree to being contacted by The New India Assurance Co.Ltd. The New India Assurance Co.Ltd shall protect all such information and it shall not be utilised in any manner that will directly or indirectly result in any harm to me.";
            $rootScope.readTermsAndCondp3="I understand and accept that The New India Assurance Co.Ltd reserves the right to determine the eligibility and availability of any product or service.";
            $rootScope.readTermsAndCondp4="I understand that premium shown in the Quick Quote is only estimated premium and may be subjected to change during Detailed Quote depending on the Cover selected and other information provided by me. And I also understand that the premium shown on the Online Portal will be subjected to any changes based on the IRDAI regulations from time to time.";
    };
    
    $scope.closeTermsCondition = function(){
       $rootScope.enableTermsCondions = false;
        $rootScope.prodDiscOpen = false; 
    };
    
    
    $scope.basicPlanTypeChange =function(){
        if($scope.premiumCalcModels.planType ==="Plan B"){
             $scope.planBSelected =true;
                $scope.premierCalPremiumForm.basicPlanName.$setValidity("basicPlanName", false);
        }else{
          $scope.planBSelected =false;
          $scope.premierCalPremiumForm.basicPlanName.$setValidity("basicPlanName", true);
        }
        
    };
    
     $scope.premiumCalcModels = { 
         planType: "",
         sumInsured:"",
         proposerthresholdLmt:"",
         proposerSumInsured:"",
         spousethresholdLmt:"",
         spouseSumInsured:"",
         spouseDateOfBith:"",
         proposerDateOfBirth:"",
         typeOfCover:"" //CR3449
     };
//
//    
    
   $scope.premiumCalcModels.planType ="Plan A"; 
       
   var disableAddChildBtn = 0;
   var totalMember = 0;    
//    
    $scope.MemberDetails = {
        parents :"",
        children:""
    };
    
    $scope.parentDetails = [];
    $scope.childDetails =[];
    
    if(CommonServices.editQuoteFlag !== true){
       $scope.parentDetails.unshift({policyHolderRelationShip:"Proposer"});
        $scope.addPropserEnable = true;
      }
    
    
    
    $scope.addProposer = function(){
     if($scope.addPropserEnable === false){
         $scope.addPropserEnable = true;
         if(CommonServices.editQuoteFlag === true){
             $scope.parentDetails.unshift(CommonServices.floaterObj.risks[0].riskDetails);
         }else{
             $scope.parentDetails.unshift({policyHolderRelationShip : "Proposer"});
         }
         
      }
        getMembersCount();
    };
    
     $scope.closeProposer = function(proposerValue){
        $scope.disableFieldProposer = false;
         $scope.addPropserEnable = false;
         $scope.premiumCalcModels.proposerDateOfBirth ="";
         for(var i= 0; i<$scope.parentDetails.length; i++){
           if(proposerValue === ($scope.parentDetails[i].policyHolderRelationShip || $scope.parentDetails[i].relationWithPolicyHolder)){
             $scope.parentDetails.splice(i,1);
            } 
         }
         getMembersCount();   
    };
    
    
    
    $scope.addSpouse =function(){
        $scope.addSpouseEnalble = true;
        $scope.parentDetails.push({policyHolderRelationShip:"Spouse"});
         getMembersCount();
    };
    
     $scope.closeSpouse = function(spouseValue){
        $scope.addSpouseEnalble = false;
          $scope.disableFieldsSpouse = false;
         $scope.premiumCalcModels.spouseDateOfBith = "";
          for(var i= 0; i<$scope.parentDetails.length; i++){
             if(spouseValue === ($scope.parentDetails[i].policyHolderRelationShip || $scope.parentDetails[i].relationWithPolicyHolder)){
            $scope.parentDetails.splice(i,1);   
          }  
        } 
         getMembersCount();    
        
    };

    $scope.addChild= function(){
       disableAddChildBtn = disableAddChildBtn + 1; 
         $scope.childDetails.push({policyHolderRelationShip:"Child"});
        for(var i = 0;i< $scope.childDetails.length; i++){
            $scope.childDetails[i].isRequired = true;
        }
         
        if($scope.childDetails.length === 5){
             $scope.addChildDisable = true;  
        }
         getMembersCount();
        
    };
    
    
    $scope.closechild = function(index){
          $scope.childDetails.splice(index,1); 
            disableAddChildBtn = disableAddChildBtn - 1;
           $scope.addChildDisable = false;  
         getMembersCount();   
    };
    
    $scope.MemberDetails.parents = $scope.parentDetails;
    $scope.MemberDetails.children = $scope.childDetails;
    
   
    var disableAllButtons = 0;
    function getMembersCount() {
         disableAllButtons = $scope.parentDetails.length + $scope.childDetails.length;
          if(disableAllButtons >= 6){
              $scope.disableMembers = true;
            }else{
               $scope.disableMembers = false;  
          } 
    };
    
    
    
     var mydateStr = new Date();
     var mynewdateFrom ="";
	 if(mydateStr != undefined){
		 mynewdateFrom = new Date(mydateStr);
	 }else{
		 mynewdateFrom = new Date();
	  }	
     /**Proposer and Spouse date age validations**/
    
            var enableAgefrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 46));
            var enableAgeTo = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 18));
            enableAgeTo = getFormattedDate(enableAgeTo);
    
            var TodyasDateFormatToCal = CommonServices.getCommonData("serverDate");
           $scope.proposerDateOfBirtshow = function(){
             $('#proposerDateOfBirth').loadCalendar({
                'enableDateRange': true,
                'enableCalendarFrom':enableAgefrom,
                'enableCalendarTo': TodyasDateFormatToCal
            }); 
                return true;
           };
            
    
         $scope.spouseDateOfBirtshow = function(){
            $("#spouseDateOfBirth").loadCalendar({
               'enableDateRange': true,
               'enableCalendarFrom': enableAgefrom,
               'enableCalendarTo': TodyasDateFormatToCal
           });
            return true;
         };
    
    

            //var parentsAgeDiff = [];
            $scope.dateOfBirthProposerSpouse = function(member){
                var memberDateOfBirth,memberAgeCal;
                if(member ==='proposer'){
                    memberDateOfBirth = $scope.premiumCalcModels.proposerDateOfBirth;
                    memberAgeCal = $scope.premiumCalcModels.proposerDateOfBirth;
                }else{
                    memberDateOfBirth = $scope.premiumCalcModels.spouseDateOfBith; 
                    memberAgeCal = $scope.premiumCalcModels.spouseDateOfBith; 
                }
             
                var arr = memberDateOfBirth.split('/'); 
                memberDateOfBirth = arr[1] + '/' + arr[0] + '/' + arr[2]; //mm/dd/yyyy 
                memberDateOfBirth = new Date(memberDateOfBirth);
                var enableToDate = new Date(enableAgeTo);
                if(memberDateOfBirth > enableToDate){
                    if(member === 'proposer'){
                    CommonServices.showAlert("Age of the Proposer should be between 18 years to 45 Years"); 
                       $scope.premiumCalcModels.proposerDateOfBirth = '';
                    }else{
                         CommonServices.showAlert("Age of the Spouse should be between 18 years to 45 Years"); 
                       $scope.premiumCalcModels.spouseDateOfBith = ''; 
                    }
                }else{
                    
                    for(var i= 0;i< $scope.childDetails.length; i++){
                        var childDateOfBithNew =  ($scope.childDetails[i].dateOfBirth !== undefined && $scope.childDetails[i].dateOfBirth !== '') ? $scope.childDetails[i].dateOfBirth : undefined;
                        
                        if($scope.childDetails[i].dateOfBirth !== undefined && $scope.childDetails[i].dateOfBirth !== ''){
                        var crr = childDateOfBithNew.split('/'); 
                        childDateOfBithNew = crr[1] + '/' + crr[0] + '/' + crr[2]; //mm/dd/yyyy 
                         childDateOfBithNew = new Date(childDateOfBithNew);
                        }
                    
                        
                        if(childDateOfBithNew < memberDateOfBirth){
                           $scope.childDetails[i].dateOfBirth = "";
                            CommonServices.showAlert("Child age cannot be more than that of Parents");
                        }
                    }
                
                     var now = new Date();
                     var today = new Date(now.getYear(),now.getMonth(),now.getDate());

                    var yearNow = now.getYear();
                    var monthNow = now.getMonth();
                    var dateNow = now.getDate();
        
                     var Arr = memberAgeCal.split('/');
                     memberAgeCal = Arr[1] + '/' + Arr[0] + '/' + Arr[2]; //mm/dd/yyyy
        
                     var dob = new Date(memberAgeCal.substring(6,10),
                     memberAgeCal.substring(0,2)-1,                   
                     memberAgeCal.substring(3,5));
    
                      var yearDob = dob.getYear();
                      var monthDob = dob.getMonth();
                      var dateDob = dob.getDate();
                      
                      var ageString = "";
                      var yearString = "";
                      var monthString = "";
                      var dayString = "";
    
                      yearAge = yearNow - yearDob;

                  if (monthNow >= monthDob)
                    var monthAge = monthNow - monthDob;
                  else {
                    yearAge--;
                    var monthAge = 12 + monthNow -monthDob;
                  }

                  if (dateNow >= dateDob)
                    var dateAge = dateNow - dateDob;
                  else {
                    monthAge--;
                    var dateAge = 31 + dateNow - dateDob;

                    if (monthAge < 0) {
                      monthAge = 11;
                      yearAge--;
                    }
                  }
                     
                var YearsDiff,MonthsDiff,DayDiff;
                    YearsDiff = yearAge;
                    MonthsDiff = monthAge;
                    DayDiff = dateAge; 
         
             if(member ==='proposer'){
                 CommonServices.newIndiaPremierMediclaim.proposerAgeInYrs = YearsDiff.toString();
                 CommonServices.newIndiaPremierMediclaim.proposerAgeInMonths = MonthsDiff.toString();
                  CommonServices.newIndiaPremierMediclaim.proposerAgeInDays = DayDiff.toString();
             }else{
                  CommonServices.newIndiaPremierMediclaim.spouseAgeInYrs = YearsDiff.toString();
                  CommonServices.newIndiaPremierMediclaim.spouseAgeInMonths = MonthsDiff.toString();
                  CommonServices.newIndiaPremierMediclaim.spouseAgeInDays =  DayDiff.toString();
             }
                    

                    
                    if(member === 'proposer'){
                         CommonServices.setCommonData("basicProposerDateOfBith", $scope.proposerDateOfBirth);
                    }
                
                }
                
            };
    
                   
          
     
    
    /*****************child date of bith validations**********/
    
        $scope.childdatOfBirthChanged = function(index){
                  
              if($scope.childDetails[index].dateOfBirth !== undefined){
                    var now = new Date();
                     var today = new Date(now.getYear(),now.getMonth(),now.getDate());

                    var yearNow = now.getYear();
                    var monthNow = now.getMonth();
                    var dateNow = now.getDate();
            
                    var childAgeCal = $scope.childDetails[index].dateOfBirth;
                     var Crr = childAgeCal.split('/');
                     childAgeCal = Crr[1] + '/' + Crr[0] + '/' + Crr[2]; //mm/dd/yyyy
                     var childAgeCalNew = childAgeCal;
                     childAgeCalNew = new Date(childAgeCalNew);
                     
                     var dob = new Date(childAgeCal.substring(6,10),
                     childAgeCal.substring(0,2)-1,                   
                     childAgeCal.substring(3,5));
    
                      var yearDob = dob.getYear();
                      var monthDob = dob.getMonth();
                      var dateDob = dob.getDate();
                      //var childAgeDiff ={};
                      var ageString = "";
                      var yearString = "";
                      var monthString = "";
                      var dayString = "";
    
                      yearAge = yearNow - yearDob;

                  if (monthNow >= monthDob)
                    var monthAge = monthNow - monthDob;
                  else {
                    yearAge--;
                    var monthAge = 12 + monthNow -monthDob;
                  }

                  if (dateNow >= dateDob)
                    var dateAge = dateNow - dateDob;
                  else {
                    monthAge--;
                    var dateAge = 31 + dateNow - dateDob;

                    if (monthAge < 0) {
                      monthAge = 11;
                      yearAge--;
                    }
                  }

                var childAgeDiffYear, childAgeDiffMonths, childAgeDiffDays;
                    childAgeDiffYear = yearAge.toString();
                     childAgeDiffMonths = monthAge.toString();
                    childAgeDiffDays =  dateAge.toString();
                    
                    CommonServices.newIndiaPremierMediclaim.childAgeDiffYear;
                    CommonServices.newIndiaPremierMediclaim.childAgeDiffMonths;
                    CommonServices.newIndiaPremierMediclaim.childAgeDiffDays;
                  
                    if(($scope.premiumCalcModels.proposerDateOfBirth !== undefined && $scope.premiumCalcModels.proposerDateOfBirth !== '') ||($scope.premiumCalcModels.spouseDateOfBith !== undefined && $scope.premiumCalcModels.spouseDateOfBith !=='')){
                        
                        var proposerDateNew = $scope.premiumCalcModels.proposerDateOfBirth;
                        var prr = proposerDateNew.split('/'); 
                        proposerDateNew = prr[1] + '/' + prr[0] + '/' + prr[2]; //mm/dd/yyyy 
                        proposerDateNew = new Date(proposerDateNew);
                        
                        var spouseDateNew = $scope.premiumCalcModels.spouseDateOfBith;
                        var srr = spouseDateNew.split('/'); 
                        spouseDateNew = srr[1] + '/' + srr[0] + '/' + srr[2]; //mm/dd/yyyy 
                        spouseDateNew = new Date(spouseDateNew);
                        
                        
                        if(childAgeCalNew < proposerDateNew || childAgeCalNew < spouseDateNew ){
                             $scope.childDetails[index].dateOfBirth = "";
                            CommonServices.showAlert("Child age cannot be more than that of Parents"); 
                        }
                        
                        
                        
                        
                        
                    }
                    
            } 
        
        };
    
    
    var childAgeEnableToDependent = [];
    
     
    
    $scope.dependentTypeChanged = function(dependent,index){
        
        var childAge = $scope.childDetails[index].dateOfBirth;
        
        if(childAge !== undefined){
                var arr = childAge.split('/'); 
                childAge = arr[1] + '/' + arr[0] + '/' + arr[2]; //mm/dd/yyyy 
                childAge = new Date(childAge);
        } 
        
      switch (dependent) {
            case 'NA':
                 childAgeEnableToDependent[index] =  new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 19));
                    
                if(childAge < childAgeEnableToDependent[index]){
                   
                     CommonServices.showAlert("Age of the Child should be between 0 day to 18 Years");
                     $scope.childDetails[index].dateOfBirth = "";
                }
              
              
                break;
            case 'NORM':
                childAgeEnableToDependent[index] =  new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 26));
              
              if(childAge < childAgeEnableToDependent[index]){
                   
                    CommonServices.showAlert("Age of the Child should be between 0 day to 25 Years");
                     $scope.childDetails[index].dateOfBirth = "";
                }
              
                break;
            case 'MC':
            case 'UD':
               childAgeEnableToDependent[index] =  new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 46));
              
              if(childAge < childAgeEnableToDependent[index]){
                   
                    CommonServices.showAlert("Age of the Child should be between 0 day to 45  Years");
                     $scope.childDetails[index].dateOfBirth = "";
                }
              
               break;
            default:
                childAgeEnableToDependent[index] =  new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 46)); 
                break;

        } 
        
    };

    
     $scope.childDateOfBirth = function(index){
        
          $("#childrenDateOfBirth_"+index).loadCalendar({
               'enableDateRange': true,
               'enableCalendarFrom': childAgeEnableToDependent[index]  === undefined ? enableAgefrom :childAgeEnableToDependent[index],
               'enableCalendarTo': TodyasDateFormatToCal
           });
            return true;
         
               
        };
  
    
    
         /**********Policy Satart Date and End Date Validations*********/
        var policyStartDate = TodyasDateFormatToCal;
        var arr = policyStartDate.split('/');
            policyStartDate =arr[1] + '/' + arr[0] + '/' + arr[2]; //dd/mm/yyyy
    
            CommonServices.newIndiaPremierMediclaim.policyStartDate = policyStartDate;
            

            var policyEndDate =new Date(mydateStr);
            policyEndDate.setFullYear(policyEndDate.getFullYear() +1);
            policyEndDate.setDate(policyEndDate.getDate() - 1);
            var dd = policyEndDate.getDate();
            var mm = policyEndDate.getMonth() + 1;
            var yyyy = policyEndDate.getFullYear();

            if (dd < 10) {
            dd = "0" + dd;
            }

            if (mm < 10) {
            mm = "0" + mm;
            }
            policyEndDate = dd + "/" +mm + "/" + yyyy;//policy end date
            CommonServices.newIndiaPremierMediclaim.policyEndDate = policyEndDate;
    
    
   
//   
    $scope.editSaveQuoteRisk =[];
    $scope.editSaveQuoteRiskMerged = [];
    $scope.proposerNotCover = [];
    
    $scope.riskDetails = [];
     $scope.riskPlusProposerDeatils = [];
    /***********************Save and Calculate Premium *****************/
    $scope.premierSaveCalpremium = function (){
        
        
        $scope.riskDetails = [];
        $scope.riskPlusProposerDeatils = [];
        $scope.editSaveQuoteRisk =[];
        $scope.editSaveQuoteRiskMerged = [];
        $scope.proposerNotCover = [];
        
        CommonServices.newIndiaPremierMediclaim.numberOfMembers = disableAllButtons === 0 ? "1":disableAllButtons;
        CommonServices.newIndiaPremierMediclaim.sumInsured = $scope.premiumCalcModels.sumInsured;
        var numberOfMembersInt = parseInt(CommonServices.newIndiaPremierMediclaim.numberOfMembers);
        
        CommonServices.topUpObj.numberOfMembers = numberOfMembersInt;
        
        // CommonServices.topUpObj.numberOfMembers = CommonServices.newIndiaPremierMediclaim.numberOfMembers;
        
         CommonServices.newIndiaPremierMediclaim.memberCoveredInPolicy = $scope.addPropserEnable;
         CommonServices.newIndiaPremierMediclaim.planType = $scope.premiumCalcModels.planType; 
         CommonServices.newIndiaPremierMediclaim.typeOfCover = $scope.premiumCalcModels.typeOfCover; //CR_3449
        
        if($scope.addPropserEnable === true || $scope.addSpouseEnalble === true){
            CommonServices.setCommonData("basicProposerDateOfBith", $scope.premiumCalcModels.proposerDateOfBirth);
            
            if($scope.addPropserEnable === true){
                 $scope.parentsRiskDeatisl={
                    "riskDetails": {
                         "relationWithPolicyHolder": "Proposer",
                          "dateOfBirth": $scope.premiumCalcModels.proposerDateOfBirth,
                          "ageInYrs": CommonServices.newIndiaPremierMediclaim.proposerAgeInYrs,
                          "planType": $scope.premiumCalcModels.planType, //CR3449
                          "sumInsured": $scope.premiumCalcModels.sumInsured//CR3449
                     }
                };
                
                $scope.riskDetails.push($scope.parentsRiskDeatisl);  
            }
          
            if($scope.addSpouseEnalble === true){
                $scope.parentsRiskDeatisl={
                    "riskDetails": {
                         "relationWithPolicyHolder": "Spouse",
                          "dateOfBirth": $scope.premiumCalcModels.spouseDateOfBith,
                          "ageInYrs": CommonServices.newIndiaPremierMediclaim.spouseAgeInYrs,
                          "planType": $scope.premiumCalcModels.planType, //CR3449
                          "sumInsured": $scope.premiumCalcModels.typeOfCover === 'INDIVIDUAL'?$scope.premiumCalcModels.sumInsuredSpouse:"0" //CR3449
                     }
                };
                
               $scope.riskDetails.push($scope.parentsRiskDeatisl); 
            }
            
            
               for(var i =0; i< $scope.childDetails.length; i++){
                            var childAdgeCal = $scope.childDetails[i].dateOfBirth;
                            var Arr = childAdgeCal.split('/');
                            childAdgeCal = Arr[2] + '/' + Arr[1] + '/' + Arr[0]; //mm/dd/yyyy
                            var date = new Date(childAdgeCal);
                            var ageDifMs = Date.now() - date.getTime();
                            var ageDinYrs = new Date(ageDifMs); // miliseconds from epoch
                            ageDinYrs = Math.abs(ageDinYrs.getUTCFullYear() - 1970);
                            ageDinYrs = ageDinYrs.toString();
                          
                        $scope.childRiskDetails ={
                                "riskDetails": {
                                  "relationWithPolicyHolder": "Children",
                                  "dateOfBirth": $scope.childDetails[i].dateOfBirth,
                                  "ageInYrs": ageDinYrs,
                                  "dependent":$scope.childDetails[i].dependentType === "NA"?"N":"Y",
                                  "dependentType":$scope.childDetails[i].dependentType,
                                  "planType": $scope.premiumCalcModels.planType, //CR3449
                                  "sumInsured": $scope.premiumCalcModels.typeOfCover === 'INDIVIDUAL'?$scope.premiumCalcModels.sumInsuredChild:"0" //CR3449
                                }  
                        }; 
                   
                         $scope.riskDetails.push($scope.childRiskDetails);

                     }
            
                   
            /*******************local storage Items***********/
           
             if($scope.addPropserEnable === false){
                 
                 $scope.riskPlusProposerDeatils.push({"riskDetails":{
                   "relationWithPolicyHolder": "Proposer"
                 }});
                 
                 for(var i = 0; i<$scope.riskDetails.length; i++){
                   $scope.riskPlusProposerDeatils.push($scope.riskDetails[i]);  
                 }
                 
                 CommonServices.topUpObj.addedMebersDetails = $scope.riskPlusProposerDeatils;
             }else{
                CommonServices.topUpObj.addedMebersDetails = $scope.riskDetails;   
             }
            
             CommonServices.newIndiaPremierMediclaim.localStorageChildrenVal = $scope.childDetails;
             CommonServices.newIndiaPremierMediclaim.localStorageParentVal =  $scope.parentDetails;
             localStorage.setItem("planType",$scope.premiumCalcModels.planType);
             localStorage.setItem("sumInsured",$scope.premiumCalcModels.sumInsured);
             localStorage.setItem("typeOfCover",$scope.premiumCalcModels.typeOfCover);//CR3449
             localStorage.setItem("proposerTrueFalse",$scope.addPropserEnable);
             localStorage.setItem("proposerDateOfBirth",$scope.premiumCalcModels.proposerDateOfBirth);
             localStorage.setItem("spouseTrueFalse",$scope.addSpouseEnalble);
             localStorage.setItem("spousedateOfBirth",$scope.premiumCalcModels.spouseDateOfBith);
             localStorage.setItem("disableMembers",$scope.disableMembers);
             localStorage.setItem("termsAndConditions",$scope.toupTermsAndCondition);
             localStorage.setItem("addChildDisable",$scope.addChildDisable);
             localStorage.setItem("disableAddChildBtn",disableAddChildBtn);
             localStorage.setItem("disableAllButtons",disableAllButtons);
            /*******************local storage Items***********/
            
            
            if(CommonServices.editQuoteFlag === true){
                 if(CommonServices.floaterObj.policyHolderName === "PROPOSER  P"){
                    $scope.premiumCalc();  
                 }else{
                     
                    var premiumDetails = { "grossPremium":CommonServices.floaterObj.premiumDetails.grossPremium,
                        "netPremium": CommonServices.floaterObj.premiumDetails.netPremium ,
                        "noOfMembers":CommonServices.newIndiaPremierMediclaim.numberOfMembers,
                        "sumInsured": CommonServices.floaterObj.premiumDetails.sumInsured
                    };

                    CommonServices.newIndiaPremierMediclaim.premium = premiumDetails;
                     
                     
                     for(var i=0; i<$scope.parentDetails.length;i++){
                       $scope.editSaveQuoteRiskMerged.push($scope.parentDetails[i]);  
                     }
                     for(var i= 0; i<$scope.childDetails.length;i++){
                        $scope.editSaveQuoteRiskMerged.push($scope.childDetails[i]);   
                     }
                     
                     for(var i=0; i< $scope.editSaveQuoteRiskMerged.length; i++){
                       $scope.editSaveQuoteRisk.push({
                            "riskParty": $scope.editSaveQuoteRiskMerged[i].riskParty,
                            "riskDetails": {
                            "relationWithPolicyHolder": $scope.editSaveQuoteRiskMerged[i].policyHolderRelationShip === undefined ? $scope.editSaveQuoteRiskMerged[i].relationWithPolicyHolder :$scope.editSaveQuoteRiskMerged[i].policyHolderRelationShip ==='Child' ? "Children" :$scope.editSaveQuoteRiskMerged[i].policyHolderRelationShip,
                            "occupation":$scope.editSaveQuoteRiskMerged[i].occupation,
                            "dateOfBirth": $scope.editSaveQuoteRiskMerged[i].memberCoveredInPolicy === "N" ?$scope.premiumCalcModels.proposerDateOfBirth: $scope.editSaveQuoteRiskMerged[i].dateOfBirth,
                            "nameOfInsuredPerson":$scope.editSaveQuoteRiskMerged[i].nameOfInsuredPerson,
                            "ageInYrs":$scope.editSaveQuoteRiskMerged[i].ageInYrs,
                            "dependentType":$scope.editSaveQuoteRiskMerged[i].dependentType,
                            "dependent":$scope.editSaveQuoteRiskMerged[i].dependentType ==="NA"?"N":($scope.editSaveQuoteRiskMerged[i].dependentType ==="NORM" || $scope.editSaveQuoteRiskMerged[i].dependentType ==="MC" ||$scope.editSaveQuoteRiskMerged[i].dependentType ==="UD") ?"Y":undefined,
                            "sex":$scope.editSaveQuoteRiskMerged[i].sex,
                            "height": $scope.editSaveQuoteRiskMerged[i].height === "0" ? undefined :$scope.editSaveQuoteRiskMerged[i].height,
                            "weight": $scope.editSaveQuoteRiskMerged[i].weight ==="0" ? undefined :$scope.editSaveQuoteRiskMerged[i].weight ,
                            "sumInsured":$scope.editSaveQuoteRiskMerged[i].sumInsured,//CR_3449
                        "ifAnyOtherOccupation":$scope.editSaveQuoteRiskMerged[i].ifAnyOtherOccupation,
                            "natureOfId": $scope.editSaveQuoteRiskMerged[i].natureOfId,
                            "anyOtherId": $scope.editSaveQuoteRiskMerged[i].anyOtherId,
                            "iDDocNo": $scope.editSaveQuoteRiskMerged[i].iDDocNo,
                            "doYouChewTobacco": "N",
                            "doYouSmoke": "N",
                            "doYouDrinkAlcohol": "N",
                            "adverseMedicialHistory": "N",
                            "preExistingDisease": "N",
                            "document": {}
                       }
                       });  
                     }
                     
                     if(CommonServices.newIndiaPremierMediclaim.memberCoveredInPolicy === false){
                          $scope.proposerNotCover.push({
                             "relationWithPolicyHolder": "Proposer",
                              "occupation": CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk ===undefined ? undefined: CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk.occupation ,
                              "dateOfBirth": CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk === undefined ?  undefined : CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk.dateOfBirth,
                              "nameOfInsuredPerson": CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk === undefined ? undefined : CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk.nameOfInsuredPerson,
                              "ageInYrs": CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk === undefined ? undefined: CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk.ageInYrs,
                              "sex": CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk === undefined ? undefined :CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk.sex,
                              "height": CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk === undefined ? "0" : CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk.height,
                              "weight": CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk === undefined ? "0" : CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk.weight,
                              "ifAnyOtherOccupation":CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk === undefined ? undefined : CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk.ifAnyOtherOccupation === undefined ? null :CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk.ifAnyOtherOccupation,
                              "natureOfId": CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk === undefined ? undefined : CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk.natureOfId,
                              "anyOtherId": CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk === undefined ? undefined : CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk.anyOtherId === undefined ? null :CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk.anyOtherId,
                              "iDDocNo": CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk === undefined ? undefined: CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk.iDDocNo,
                              "doYouChewTobacco": "N",
                              "doYouSmoke": "N",
                              "doYouDrinkAlcohol": "N",
                              "riskParty":CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk === undefined ? undefined :CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk.riskParty,
                              "document": {}
                          });
                          CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk = $scope.proposerNotCover;
                          
                     }
                     
                     
                     
                     
                     CommonServices.newIndiaPremierMediclaim.EditSaveQuoteRisk = $scope.editSaveQuoteRisk;
                     CommonServices.editSaveQuote = true;                     
                     CommonServices.saveQuoteHealth(); 
                 }
            }else{
              $scope.premiumCalc();  
            }
               
        }else{
            if($scope.childDetails.length === 0){
               CommonServices.showAlert("Atleast one member is required to take the policy");
            }else{
                   //alert("Atleast one parent (Proposer/Spouse) should be covered in this policy");
                CommonServices.showAlert("Atleast one parent (Proposer/Spouse) should be covered in this policy");  
            }
        }        
    };
    
    $scope.premiumCalc = function(){
                  var premimuCalcInput = {
                        "quote": {
                                "risks":$scope.riskDetails,
                                "quoteNumber": CommonServices.editQuoteFlag === true ?  CommonServices.floaterObj.quoteNumber : CommonServices.newIndiaPremierMediclaim.fromBasicPremium === true ?CommonServices.newIndiaPremierMediclaim.premiumCalResponse.quoteNumber : undefined,
                                "productCode": "HN",
                                "policyStartDate": policyStartDate,
                                "policyExpiryDate": policyEndDate,
                                "mobileNo": null,
                                "emailId": null,
                                "progressLevel": null,
                                "planType": $scope.premiumCalcModels.planType,
                                "typeOfCover":$scope.premiumCalcModels.typeOfCover, //CR3449
                                "sumInsured": $scope.premiumCalcModels.sumInsured,
                                "memberCoveredInPolicy":$scope.addPropserEnable === false ? "N" : "Y"
                            },
                        "userProfile": {
                            "userId": CommonServices.getCommonData("userId"),
                            "loggedInRole": "SUPERUSER"
                        }
                    };
            
         var premiumCalResponse = RestServices.postService(RestServices.urlPathsNewPortal.topUpCalcPremium, premimuCalcInput);
			premiumCalResponse.then(
			  function(response) { // success 
				
				CommonServices.showLoading(false);
                  
                  if(response.data.hasOwnProperty('errorMessage')){
                       //alert(response.data.errorMessage);
                       CommonServices.showAlert(response.data.errorMessage);
                  }else{
                     CommonServices.newIndiaPremierMediclaim.premiumCalResponse = response.data.quote;
                       $state.go("topUpBasicPremiumScreen");  
                  }  
			  },
			  function(error) { // failure
                    CommonServices.showLoading(false);
                    RestServices.handleWebServiceError(error);
			  }); 
        
    };
    
    
       if(CommonServices.newIndiaPremierMediclaim.fromBasicPremium === true){
        
             $scope.childDetails = CommonServices.newIndiaPremierMediclaim.localStorageChildrenVal;
             $scope.parentDetails = CommonServices.newIndiaPremierMediclaim.localStorageParentVal; 
             $scope.premiumCalcModels.planType = localStorage.getItem("planType");
             $scope.premiumCalcModels.sumInsured = localStorage.getItem("sumInsured");
             $scope.premiumCalcModels.typeOfCover = localStorage.getItem("typeOfCover");//CR3449
             $scope.addPropserEnable = localStorage.getItem("proposerTrueFalse") ==="true"?true:false;
             $scope.premiumCalcModels.proposerDateOfBirth = localStorage.getItem("proposerDateOfBirth");
             $scope.addSpouseEnalble = localStorage.getItem("spouseTrueFalse") ==="true"?true:false;
             $scope.premiumCalcModels.spouseDateOfBith = localStorage.getItem("spousedateOfBirth");
             $scope.disableMembers = localStorage.getItem("disableMembers") ==="true"?true:false;
             $scope.toupTermsAndCondition = localStorage.getItem("termsAndConditions") ==="true"?true:false;
             $scope.addChildDisable = localStorage.getItem("addChildDisable") === "true"?true:false;
             disableAddChildBtn = parseInt(localStorage.getItem("disableAddChildBtn"));
             disableAllButtons =  parseInt(localStorage.getItem("disableAllButtons"));
           
    }
    
    
    if(CommonServices.editQuoteFlag === true){
         $scope.childDetails =[];
         $scope.parentDetails = [];
         var countChildren = 0;
         var parentsCount = 0;
        var editQouteTotalMembersCount;
         $scope.premiumCalcModels.planType ="Plan A"; //CR_3449
     // $scope.premiumCalcModels.planType = CommonServices.floaterObj.planType; 
      //$scope.premiumCalcModels.sumInsured = CommonServices.floaterObj.sumInsured;
        $scope.premiumCalcModels.typeOfCover=CommonServices.floaterObj.typeOfCover;// CR_3449
      //CommonServices.newIndiaPremierMediclaim.sumInsured = $scope.premiumCalcModels.sumInsured;
     
        for(var i=0; i<CommonServices.floaterObj.risks.length; i++){
            
            if(CommonServices.floaterObj.risks[i].riskDetails.relationWithPolicyHolder ==='PROPOSER' || CommonServices.floaterObj.risks[i].riskDetails.relationWithPolicyHolder ==='Proposer'){
                if(CommonServices.floaterObj.risks[i].riskDetails.memberCoveredInPolicy === "Y"){
                     $scope.parentDetails.push(CommonServices.floaterObj.risks[i].riskDetails);
                    $scope.parentDetails[i].riskParty = CommonServices.floaterObj.risks[i].riskParty;
                     $scope.premiumCalcModels.proposerDateOfBirth = CommonServices.floaterObj.risks[i].riskDetails.dateOfBirth;
                      CommonServices.newIndiaPremierMediclaim.proposerAgeInYrs = CommonServices.floaterObj.risks[i].riskDetails.ageInYrs;
                      $scope.premiumCalcModels.sumInsured=CommonServices.floaterObj.risks[i].riskDetails.sumInsured; //CR_3449
                      parentsCount = parentsCount + 1;
                     $scope.addPropserEnable = true;
                     $scope.disableFieldProposer = true;
                     $scope.proposerSumInsured=true;
                }else{
                    CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk = CommonServices.floaterObj.risks[i].riskDetails;
                    CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk.riskParty = CommonServices.floaterObj.risks[i].riskParty;
                    $scope.disableFieldProposer = false;
                   $scope.addPropserEnable = false;  
                   $scope.proposerSumInsured=false;
                }  
            }
        
            if(CommonServices.floaterObj.risks[i].riskDetails.relationWithPolicyHolder ==='Spouse'){
                 if(CommonServices.floaterObj.risks[i].riskDetails.memberCoveredInPolicy === "Y"){
                     $scope.parentDetails.push(CommonServices.floaterObj.risks[i].riskDetails);
                     for(var j=0; j<$scope.parentDetails.length;j++){
                         $scope.parentDetails[j].riskParty = CommonServices.floaterObj.risks[i].riskParty;
                        }
                      //$scope.parentDetails[i].riskParty = CommonServices.floaterObj.risks[i].riskParty;
                      $scope.addSpouseEnalble = true;
                     $scope.premiumCalcModels.spouseDateOfBith = CommonServices.floaterObj.risks[i].riskDetails.dateOfBirth;
                      CommonServices.newIndiaPremierMediclaim.spouseAgeInYrs = CommonServices.floaterObj.risks[i].riskDetails.ageInYrs; 
                      $scope.premiumCalcModels.sumInsuredSpouse=CommonServices.floaterObj.risks[i].riskDetails.sumInsured; //CR_3449
                     parentsCount = parentsCount + 1;
                      $scope.disableFieldsSpouse = true;
                 }else{
                     $scope.disableFieldsSpouse = false;
                      $scope.addSpouseEnalble = false;
                    }   
                }
            
            if(CommonServices.floaterObj.risks[i].riskDetails.relationWithPolicyHolder ==='Children'){
                countChildren = countChildren +1;
                
                if(CommonServices.floaterObj.risks[i].riskDetails.dependent ==='N'){
                    CommonServices.floaterObj.risks[i].riskDetails.dependentType ='NA';
                }
                CommonServices.floaterObj.risks[i].riskDetails.policyHolderRelationShip ="Child";
                 CommonServices.floaterObj.risks[i].riskDetails.disableFields = true;
                $scope.childDetails.push(CommonServices.floaterObj.risks[i].riskDetails);
                for(var j=0; j<$scope.childDetails.length;j++){
                      $scope.childDetails[j].riskParty = CommonServices.floaterObj.risks[i].riskParty;
                      $scope.premiumCalcModels.sumInsuredChild=CommonServices.floaterObj.risks[i].riskDetails.sumInsured; //CR_3449

                }
               
               
            }
            
            
        }
         editQouteTotalMembersCount = parentsCount + countChildren;
            disableAllButtons = editQouteTotalMembersCount.toString(); 
         $scope.toupTermsAndCondition = true;    
    }
    
     getMembersCount();
    


}]);


