agentApp.controller('ManageRenewalsCtrl', ['$scope','RestServices', function ($scope,RestServices) {
	
	$scope.home = function() {
		RestServices.goHome();
	};

}]);

agentApp.controller('ManageRenewalsCalendarCtrl', ['$rootScope','$scope','$location','RestServices','CommonServices','$state', function ($rootScope,$scope,$location, RestServices,CommonServices,$state) {
	

	$scope.renewalsLabel = "Pending For Renewals";
	var fromDate = new Date(CommonServices.getCommonData("serverDate"));
	var toDate = new Date(fromDate);
	toDate.setDate(toDate.getDate() + 29);
	
    $scope.loadEvents = function () {
		
		CommonServices.isManageRenewals = true;
		$scope.currentDate = fromDate;
		
		CommonServices.RenewalsForMonth = true;
		//RestServices.updateRenewals($scope.currentDate, toDate);
		RestServices.updateRenewalsCount(fromDate, toDate);
		$scope.totalRenewalsCount = 0;
		CommonServices.renewalsCount = 0;	       
    };

	$scope.$on("renewalsCount", function(event, args) {
		/** Renewal policy service call **/
		if(args.data === "") {
			$scope.totalRenewalsCount = 0;
		} else {
			$scope.totalRenewalsCount = args.data;
		}
		
		
	});

	$scope.renewalsProductList = function(){
		if($scope.totalRenewalsCount === 0 || $scope.totalRenewalsCount === "" || $scope.totalRenewalsCount === undefined) {
			
		} else{		
			if(CommonServices.RenewalsForMonth === false){
				var selectedDate = new Date(CommonServices.selectedDate);
				if(CommonServices.selectedDate !== undefined || CommonServices.selectedDate !== ""){
					RestServices.renewalsList(selectedDate, selectedDate);
				} else {
					CommonServices.showAlert("Please select valid date");
				}
			} else {
				RestServices.renewalsList(fromDate, toDate);
			}
						
		}		
	}
}]);

agentApp.controller('renewalProductsListCtrl', ['$scope','$location','RestServices','CommonServices','$state', function ($scope,$location, RestServices,CommonServices,$state) {
	
	CommonServices.selectedProductPolicies = [];
	
	var todaysDate;
	if(CommonServices.RenewalsForMonth === true || CommonServices.selectedDate === undefined || CommonServices.selectedDate === ""){
		todaysDate = new Date(CommonServices.getCommonData("serverDate"));
	} else {
		todaysDate = new Date(CommonServices.selectedDate);
	} 
	var monthNames = ["Jan", "Feb", "March", "April", "May", "June",
	  "July", "Aug", "Sep", "Oct", "Nov", "Dec"
	];
	var m = monthNames[todaysDate.getMonth()];
	var y = todaysDate.getFullYear();
	var d = todaysDate.getDate();
	var endDate = new Date(todaysDate);
	endDate.setDate(endDate.getDate() + 29);
	var endm = monthNames[endDate.getMonth()];
	var endy = endDate.getFullYear();
	var endd = endDate.getDate();
	
	if(CommonServices.RenewalsForMonth === true){
		$scope.renewalListDate = d + " " + m + " " + y + " to " + endd + " " + endm+" "+endy;
	} else{
		$scope.renewalListDate = d + " " + m + ", " + y ;
	}
	$scope.renewalProductCount = CommonServices.renewalsCount;
	$scope.countLabel = "Select product to continue";
	$scope.items = CommonServices.renewalsProductList;
	
	var productSelected = {};	
	$scope.pendingList = function(list){
		var listSelected = list.$index; 
		productSelected = CommonServices.renewalsProductList[listSelected];
		for(var i=0; i<CommonServices.renewalsProductPolicyList.length; i++) {
			if(productSelected.productCode === CommonServices.renewalsProductPolicyList[i].productCode){
				CommonServices.selectedProductPolicies.push(CommonServices.renewalsProductPolicyList[i]);
			}
		}
		$state.go("manageRenewals.renewalProductsPolicyList");
	}	
}]);

agentApp.controller('renewalProductsPolicyListCtrl', ['$scope','$location','RestServices','CommonServices','$state', function ($scope,$location, RestServices,CommonServices,$state) {
	
	var todaysDate;
	if(CommonServices.RenewalsForMonth === true || CommonServices.selectedDate === undefined || CommonServices.selectedDate === ""){
		todaysDate = new Date(CommonServices.getCommonData("serverDate"));
	} else {
		todaysDate = new Date(CommonServices.selectedDate);
	} 
	var monthNames = ["Jan", "Feb", "March", "April", "May", "June",
	  "July", "Aug", "Sep", "Oct", "Nov", "Dec"
	];
	var m = monthNames[todaysDate.getMonth()];
	var y = todaysDate.getFullYear();
	var d = todaysDate.getDate();
	var endDate = new Date(todaysDate);
	endDate.setDate(endDate.getDate() + 29);
	var endm = monthNames[endDate.getMonth()];
	var endy = endDate.getFullYear();
	var endd = endDate.getDate();
	
	if(CommonServices.RenewalsForMonth === true){
		$scope.renewalListDate = d + " " + m + ", " + y + " to " + endd + " " + endm+" "+endy;
	} else{
		$scope.renewalListDate = d + " " + m + ", " + y ;
	}
	$scope.countLabel = "Select policy to continue";
	$scope.renewalPolicyCount = CommonServices.selectedProductPolicies.length;
	var policyList = CommonServices.selectedProductPolicies;
	for(var i=0; i< policyList.length; i++){
		policyList[i].count = (i<9?"0":"")+(i+1);
	} 
	$scope.items = policyList;
	$scope.pendingList = function(list){
		var listSelected = list.$index; 
			CommonServices.renewalPolicyDetails = CommonServices.selectedProductPolicies[listSelected];
			$state.go("manageRenewals.renewalPolicyDetails");
	}
}]);

agentApp.controller('renewalPolicyDetailsCtrl', ['$scope','$location','RestServices','CommonServices','$state', function ($scope,$location, RestServices,CommonServices,$state) {

	var quoteStartDate = CommonServices.renewalPolicyDetails.quoteStartDate;
	var renewalDate = quoteStartDate.split(" ");
	renewalDate = renewalDate[0].split("/");
	renewalDate = renewalDate[1]+"/"+renewalDate[0]+"/"+renewalDate[2];
	var date = new Date(renewalDate);
	CommonServices.renewQuoteNo = "";
	
	$scope.policyNo = CommonServices.renewalPolicyDetails.previousPolicyNo;
	$scope.quoteNo = CommonServices.renewalPolicyDetails.renewQuoteNo;
	$scope.policyHolder = CommonServices.renewalPolicyDetails.partyName;
	$scope.renewalStartDate = date.getDate();
	$scope.renewalStartMonth = date.getMonth()+1;
	$scope.renewalStartYear = date.getFullYear();
    $scope.policyStatus =  CommonServices.renewalPolicyDetails.policyStatus; 
    $scope.quoteStatus = CommonServices.renewalPolicyDetails.quoteStatus;                                          
	$scope.renewQuote = function(){
		CommonServices.renewQuoteNo = CommonServices.renewalPolicyDetails.renewQuoteNo;
		$state.go("newRenewPolicy.getNewRenewPolicy");
	}
	
}]);
