agentApp.controller('AppointmentsCtrl', ['$scope','RestServices', 'CommonServices', function ($scope,RestServices,CommonServices) {
	
	$scope.logOut = function() {
		RestServices.logOut();
	};

	$scope.home = function() {
		RestServices.goHome();
	};
	

}]);

agentApp.controller('AppointmentsCalendarCtrl', ['$rootScope','$scope','$location','RestServices','CommonServices','$state','$timeout', function ($rootScope,$scope,$location, RestServices,CommonServices,$state,$timeout) {
	
	$scope.totalAppointmentCount = 0;
	$scope.totalRenewalsCount = 0;
	$scope.currentDate = new Date();
	var toDate = new Date($scope.currentDate);
	toDate.setDate(toDate.getDate() + 30);
	CommonServices.appointmentsEvent = [];
	$scope.appointmentLabel = "Appointments due";
	$scope.renewalsLabel = "Pending For Renewals";
	var startDate = new Date();
	var endDate = new Date(startDate);
	endDate.setDate(endDate.getDate() + 31);
	var appointmentStart = startDate.getDate()+"/"+(startDate.getMonth()+1)+"/"+startDate.getFullYear();
	var appointmentEnd = endDate.getDate()+"/"+(endDate.getMonth()+1)+"/"+endDate.getFullYear();
	CommonServices.isManageRenewals = false;
	CommonServices.appointmentRenewal = false;
	CommonServices.selectedDate = "";
    $scope.loadEvents = function () {
        CommonServices.RenewalsForMonth = true;
		var appointmentData = {  
		   "userId": CommonServices.getCommonData("userCode").toUpperCase(),
		   "appointmentDetailList":[  
			  {  
				 "appointmentStartDate":appointmentStart,
				 "appointmentEndDate":appointmentEnd
			  }
		   ]
		};
		var appointmentListResponse = RestServices.postService(RestServices.urlPathsNewPortal.fetchAppointmentDetails,appointmentData); 
		appointmentListResponse.then(    
		function(response) { /* success */
		CommonServices.showLoading(false); 
		if(response.data === ""){
			CommonServices.showAlert("Could not connect to server. Please try again later.");
		} else {         
			if(response.data.errorCode === "1"){
                $scope.totalAppointmentCount = 0;
			} else {
				CommonServices.appointmentsEvent = [];
				var appointmentList = response.data.appointmentDetailList;
				for(var i=0; i < appointmentList.length ; i++) {
					var date = appointmentList[i].appointmentEndDate;
					var eventDate = date.split(/[^0-9]+/);
					var eventYear = eventDate[2];
					var eventMon = eventDate[1];
					var eventDay = eventDate[0];
					var eventDateFormat =  eventMon + "/"+eventDay+"/"+eventYear;
					var date1 = new Date(eventDateFormat);
					date1.setHours(calTime(appointmentList[i].endTime).sHours,calTime(appointmentList[i].endTime).sMinutes,00);
					if(date1 > startDate){
						 CommonServices.appointmentsEvent.push(appointmentList[i]);
					}
				}
				$scope.eventSource = response.data.appointmentDetailList; 
				$scope.totalAppointmentCount = CommonServices.appointmentsEvent.length;
				CommonServices.appointmentsForMonth = true;
				CommonServices.renewalProductListWithRenewalNumbers = [];
				CommonServices.renewalsProductPolicyList = [];
				CommonServices.renewalsCount = 0;
			}
			renewals();
		}
		},
		function(error) { /* failure */
			CommonServices.showLoading(false);
			RestServices.handleWebServiceError(error);
		});
			
		function calTime(time){
			var hours = Number(time.match(/^(\d+)/)[1]);
			var minutes = Number(time.match(/:(\d+)/)[1]);
			var AMPM = time.split(":")[0] >= 12? 'PM':'AM';
			if(AMPM === "PM" && hours<12) hours = hours+12;
			if(AMPM === "AM" && hours === 12) hours = hours-12;
			var sHours = hours.toString();
			var sMinutes = minutes.toString();
			if(hours<10) sHours = "0" + sHours;
			if(minutes<10) sMinutes = "0" + sMinutes;
			return {
				sHours: sHours,
				sMinutes: sMinutes
			};
		}	
		function renewals(){
			
			$timeout(function(){
			    var toDate = new Date($scope.currentDate);
            	toDate.setDate(toDate.getDate() + 29);
				RestServices.updateRenewalsCount($scope.currentDate, toDate);
			});
			if (CommonServices.deviceType !== "NA") {
			cordova.plugins.notification.local.hasPermission(function (granted) {
                if(!granted){
                    cordova.plugins.notification.local.registerPermission(function (granted) {
                        notifyAppointment();
                    });
                } else{
                    notifyAppointment();
                }
            });
		}
			
		}
	};

	$scope.$on("renewalsCount", function(event, args) {
		if(args.data === "") {
			$scope.totalRenewalsCount = 0;
		} else {
			$scope.totalRenewalsCount = args.data;
		}
	});
	
	$scope.$on("appointmentsCall", function(event, args) {
		$scope.totalRenewalsCount = 0;
		if(args.data === ""){
			$scope.totalAppointmentCount = 0;
		} else {
			$scope.totalAppointmentCount = args.data;	
		}
		$timeout(function(){
			RestServices.updateRenewalsCount(args.date, args.date);
		});
	});

	$scope.appointmentsList = function(){
		
		if($scope.totalAppointmentCount === 0 || $scope.totalAppointmentCount === "" || $scope.totalAppointmentCount === undefined) {
			
		} else{
			$state.go("appointments.appointmentsList");
		}
	}
	
	$scope.renewalsList = function(){
		if($scope.totalRenewalsCount === 0 || $scope.totalRenewalsCount === "" || $scope.totalRenewalsCount === undefined) {
			
		} else{
			CommonServices.appointmentRenewal = true;

			if(CommonServices.RenewalsForMonth === false){
				var selectedDate = new Date(CommonServices.selectedDate);
				if(CommonServices.selectedDate !== undefined || CommonServices.selectedDate !== ""){
					RestServices.renewalsList(selectedDate, selectedDate);
				} else {
					CommonServices.showAlert("Please select valid date");
				}
			} else {
			    var fromDate = new Date(CommonServices.getCommonData("serverDate"));
                var toDate = new Date(fromDate);
                toDate.setDate(toDate.getDate() + 29);
				RestServices.renewalsList(fromDate, toDate);
			}
		}
	}
	CommonServices.appointList = false;
	$scope.addAppointment = function(){
		CommonServices.appointList = true;
		$state.go("appointments.createAppointment");
		
	}

	function notifyAppointment(){
	    var options = [];
		if(CommonServices.appointmentsEvent.length > 0){
			for(var i=0; i<CommonServices.appointmentsEvent.length; i++){
		    var date = CommonServices.appointmentsEvent[i].appointmentStartDate;
		    var time = CommonServices.appointmentsEvent[i].startTime;
		    time = time.split(":");
		    date = date.split("/");
		    date = date[1]+"/"+date[0]+"/"+date[2];
		    var startDate = new Date(date);
		    startDate.setHours(time[0], time[1], time[2]);
			if(CommonServices.appointmentsEvent[i].reminder !== undefined){
				startDate.setMinutes(startDate.getMinutes() - parseInt(CommonServices.appointmentsEvent[i].reminder));
			}
		    var text = "Your Appointment has been scheduled with "+CommonServices.appointmentsEvent[i].clientName+" on "+
		    CommonServices.appointmentsEvent[i].appointmentStartDate+" at "+ CommonServices.appointmentsEvent[i].startTime;

		    var option = {
		        title: "Appointment with "+ CommonServices.appointmentsEvent[i].clientName,
		        id: CommonServices.appointmentsEvent[i].appointmentId,
		        text: text,
		        at: new Date(startDate),
		        autoClear: false
		    };
		    options.push(option);
		}
        cordova.plugins.notification.local.schedule(options);
		}
    }
}]);

agentApp.controller('appointmentListController', ['$scope','$location','RestServices','CommonServices','$state','$timeout', function ($scope,$location, RestServices,CommonServices,$state,$timeout) {

	$scope.appointmentListController ={
		onload : function(){
		$scope.items = [];
		var todaysDate;
		if(CommonServices.appointmentsForMonth === true || CommonServices.selectedDate === undefined || CommonServices.selectedDate === ""){
			todaysDate = new Date();
		} else {
			todaysDate = new Date(CommonServices.selectedDate);
		} 
		var startDate;
		var endDate;
        if(CommonServices.appointmentDelete === true){
			if(CommonServices.appointmentsForMonth === true){
				startDate = new Date();
				endDate = new Date(startDate);
				endDate.setDate(endDate.getDate() + 31);
			} else {
				startDate = new Date(CommonServices.selectedDate);
				endDate = new Date(startDate);
			}
        	var appointmentStart = startDate.getDate()+"/"+(startDate.getMonth()+1)+"/"+startDate.getFullYear();
        	var appointmentEnd = endDate.getDate()+"/"+(endDate.getMonth()+1)+"/"+endDate.getFullYear();
            var appointmentData = {
               "userId": CommonServices.getCommonData("userCode").toUpperCase(),
               "appointmentDetailList":[
                  {
                     "appointmentStartDate":appointmentStart,
                     "appointmentEndDate":appointmentEnd
                  }
               ]
            };
            var appointmentListResponse = RestServices.postService(RestServices.urlPathsNewPortal.fetchAppointmentDetails,appointmentData);
            appointmentListResponse.then(
            function(response) { /* success */
			if(response.data === ""){
				CommonServices.showLoading(false);
				CommonServices.showAlert("Could not connect to server. Please try again later.");
			} else {
				CommonServices.showLoading(false);
                CommonServices.appointmentsEvent = [];
				var appointmentList = response.data.appointmentDetailList;
				for(var i=0; i < appointmentList.length ; i++) {
					var eventDate = appointmentList[i].appointmentEndDate.split(/[^0-9]+/);
					eventDate =  eventDate[1] + "/"+eventDate[0]+"/"+eventDate[2]; //mm/dd/yy
					eventDate = new Date(eventDate);
					eventDate.setHours(calTime(appointmentList[i].endTime).sHours,calTime(appointmentList[i].endTime).sMinutes,00);
					if(eventDate > todaysDate){
						 CommonServices.appointmentsEvent.push(appointmentList[i]);
					}
				}                
				CommonServices.appointmentDelete = false;
				loadAppointmentList();
			} 
            },
            function(error) { /* failure */
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            });
        } else {
			loadAppointmentList();
		}

		}
	};
 
	$scope.appointmentListController.onload();
	
	function loadAppointmentList() {
		if(CommonServices.appointmentsEvent.length > 0){
				$scope.swipeMsg = true; 
			} else {
				$scope.swipeMsg = false;
			}
		$timeout(function () { 
			
				$scope.swipeMsg = false;
		}, 3000); 
		var appointmentList;
		var todaysDate;
		if(CommonServices.appointmentsForMonth === true || CommonServices.selectedDate === undefined || CommonServices.selectedDate === ""){
			todaysDate = new Date();
		} else {
			todaysDate = new Date(CommonServices.selectedDate);
		}        
        var monthNames = ["Jan", "Feb", "March", "April", "May", "June",
          "July", "Aug", "Sep", "Oct", "Nov", "Dec"
        ];
        var m = monthNames[todaysDate.getMonth()];
        var y = todaysDate.getFullYear();
        var d = todaysDate.getDate();
        var h = todaysDate.getHours();
        var min = getMinutes(todaysDate);
        var endDate = new Date(todaysDate);
        endDate.setDate(endDate.getDate() + 31);
        var endm = monthNames[endDate.getMonth()];
        var endy = endDate.getFullYear();
        var endd = endDate.getDate();
		var ampmVal;
		if(todaysDate.getHours() >= 12){
			ampmVal = "PM";
		} else {
			ampmVal = "AM";
		}
        if(CommonServices.appointmentsForMonth === true){
            $scope.appDate = d + " " + m + ", " + y + " to " + endd + " " + endm+" "+endy+" | " + h + "." + min + " "+ ampmVal;
            appointmentList = CommonServices.appointmentsEvent;
        } else {
            $scope.appDate = d + " " + m + ", " + y + " | " + h + " . " + min + " " + ampmVal;
            appointmentList = CommonServices.currentAppointments;
        }

        $scope.appDueLabel = "Appointments Due";
        CommonServices.appointmentListArray = {
            "appointmentsListItems" : []
        };
        var nextFlag = 1;
        var next;
		if(appointmentList !== undefined){
			 for(var i=0; i < appointmentList.length ; i++) {
				var eventDate = appointmentList[i].appointmentEndDate.split(/[^0-9]+/);
				eventDate =  eventDate[1] + "/"+eventDate[0]+"/"+eventDate[2]; //mm/dd/yy
				eventDate = new Date(eventDate);
				eventDate.setHours(calTime(appointmentList[i].endTime).sHours,calTime(appointmentList[i].endTime).sMinutes,00);
				var currentDateString = (todaysDate.getMonth()+1) +"/"+ todaysDate.getDate() +"/"+ todaysDate.getFullYear();
				var eventDateString = (eventDate.getMonth()+1) +"/"+ eventDate.getDate()+"/"+eventDate.getFullYear(); 
				if(currentDateString === eventDateString) {
					if(nextFlag === 1){
						next = true;
					} else {
						next = false;
					}
					nextFlag = 0;
					var ampmVal = ampm(appointmentList[i].startTime);
					var appointmentsData = {
						"appointmentId":appointmentList[i].appointmentId,
						"name": appointmentList[i].clientName,
						"startDate": appointmentList[i].appointmentStartDate,
						"startTime": appointmentList[i].startTime,
						"ampm": ampmVal,
						"endDate": appointmentList[i].appointmentEndDate,
						"endTime": appointmentList[i].endTime,
						"title": "Appointment with " + appointmentList[i].clientName,
						"location": appointmentList[i].location,
						"notes":  appointmentList[i].notes,
						"reminder":  appointmentList[i].reminder,
						"next": next
					};
					CommonServices.appointmentListArray.appointmentsListItems.push(appointmentsData);
				} else {
					if(eventDate > todaysDate){
						if(nextFlag === 1){
							next = true;
						} else {
							next = false;
						}
						nextFlag = 0;
						var ampmVal = ampm(appointmentList[i].startTime);
						var appointmentsData = {
							"appointmentId":appointmentList[i].appointmentId,
							"name": appointmentList[i].clientName,
							"startDate": appointmentList[i].appointmentStartDate,
							"startTime": appointmentList[i].startTime,
							"ampm": ampmVal,
							"endDate": appointmentList[i].appointmentEndDate,
							"endTime": appointmentList[i].endTime,
							"title": "Appointment with " + appointmentList[i].clientName,
							"location": appointmentList[i].location,
							"notes":  appointmentList[i].notes,
							"reminder":  appointmentList[i].reminder,
							"next": next
						};
						CommonServices.appointmentListArray.appointmentsListItems.push(appointmentsData);
					}
				}
			}
		}
        CommonServices.appointmentListArray.appointmentsListItems.sort(function(a,b){
            var date = a.startDate;
            var eventDate = date.split(/[^0-9]+/);
            var eventYear = eventDate[2];
            var eventMon = eventDate[1];
            var eventDay = eventDate[0];
            var eventDateFormat =  eventMon + "/"+eventDay+"/"+eventYear;
            var date1 = new Date(eventDateFormat);
            calTime(a.startTime);
            date1.setHours(calTime(a.startTime).sHours,calTime(a.startTime).sMinutes,00);
			
            var date = b.startDate;
            var eventDate = date.split(/[^0-9]+/);
            var eventYear = eventDate[2];
            var eventMon = eventDate[1];
            var eventDay = eventDate[0];
            var eventDateFormat =  eventMon + "/"+eventDay+"/"+eventYear;
            var date2 = new Date(eventDateFormat);
            calTime(b.startTime);
            date2.setHours(calTime(b.startTime).sHours,calTime(b.startTime).sMinutes,00);
            return date1 - date2
        });

        for(var i=0; i<CommonServices.appointmentListArray.appointmentsListItems.length;i++){
            if(i === 0){
                CommonServices.appointmentListArray.appointmentsListItems[i].next = true;
            } else {
                CommonServices.appointmentListArray.appointmentsListItems[i].next = false;
            }
        }
		$scope.items = CommonServices.appointmentListArray;
        CommonServices.appointmentDelete = false;
	}
	
	function getMinutes(date){
		return (date.getMinutes()<10?'0':'') + date.getMinutes();
	}

	function ampm(startTime){
		var h = startTime.toString().split(":");
		var ampm = h[0] >= 12 ? 'PM' : 'AM';
		return ampm;
	}
	
	$scope.eventDetails = function(list) {
		CommonServices.appointmentSelected = list.$index; 
		$state.go("appointments.appointmentsDetails");
	};
	var listSelected = null;
	
	$scope.deleteAppointment = function(list) {
		listSelected = list;
	}
	
	$scope.deleteAppointmentConfirm = function(list){
		listSelected = list;
		if (CommonServices.deviceType !== "NA") {
		    var msg = "Are you sure you want to delete the appointment?";
			CommonServices.messageModal('info', msg, false, 'NO', 'YES', function () {}, function () { deleteAppointment(1);}, 'Confirm');
			//navigator.notification.confirm("Are you sure you want to delete the appointment?", deleteAppointment, "Confirm", ["YES", "NO"]);
		} else {
			var logutConfirm;
			logutConfirm = confirm("Are you sure you want to delete the appointment?");
			if (logutConfirm === true) {
				deleteAppointment(1);
			}
		}
	}
	
	
	function deleteAppointment(button){
		if(button === 1){
			if(listSelected !== null){
				CommonServices.appointmentDelete = true;
				var appointmentDelete = CommonServices.appointmentListArray.appointmentsListItems[listSelected.$index];
				 var appoinementStartDate = appointmentDelete.startDate.split(/[^0-9]+/);
				 var m = appoinementStartDate[1];
				 var y = appoinementStartDate[2];
				 var d = appoinementStartDate[0];
				 var calStartSource =  m + "/"+d+"/"+y;	 
				 var calStartDate = new Date(calStartSource);
				 
				 var appoinementEndDate = appointmentDelete.endDate.split(/[^0-9]+/);
				 var m = appoinementEndDate[1];
				 var y = appoinementEndDate[2];
				 var d = appoinementEndDate[0];
				 var calEndSource =  m + "/"+d+"/"+y;
				 var calEndDate = new Date(calEndSource);
				
				 var Starttime = appointmentDelete.startTime;
				 var Endtime = appointmentDelete.endTime;
				
				 if(Starttime !== "") {
					 calTime(Starttime);			 
					 calStartDate.setHours(calTime(Starttime).sHours,calTime(Starttime).sMinutes,00);
				 }
				 if(Endtime !== "") {
					 calTime(Endtime);
					 calEndDate.setHours(calTime(Endtime).sHours,calTime(Endtime).sMinutes,00);
				 }


				var startDate = new Date(calStartDate.getFullYear(),calStartDate.getMonth(),calStartDate.getDate(),calStartDate.getHours(),calStartDate.getMinutes(),0,0); // month 0 = january, 11 = december
				var endDate = new Date(calEndDate.getFullYear(),calEndDate.getMonth(),calEndDate.getDate(),calEndDate.getHours(),calEndDate.getMinutes(),0,0);
				var title = "Appointment with";
				var location = appointmentDelete.location;
				var notes = appointmentDelete.notes;
				var success = function(message) { };
				var error = function(message) { };

				var deleteAppointmentData = {  
				   "appointmentDetailList":[  
					  {  
						 "appointmentId": CommonServices.appointmentListArray.appointmentsListItems[listSelected.$index].appointmentId
					  }
				   ],
				   "userId":CommonServices.getCommonData("userCode").toUpperCase()
				};
				var deleteAppointmentResponse = RestServices.postService(RestServices.urlPathsNewPortal.deleteAppointmentDetails, deleteAppointmentData); 
				deleteAppointmentResponse.then(    
				function(response) {
					if(response.data === ""){
						CommonServices.showLoading(false);
						CommonServices.showAlert("Could not connect to server. Please try again later.");
					} else {
						if(response.data.errorCode === "0") {
							CommonServices.showLoading(false);
							$scope.appointmentListController.onload();
							if (CommonServices.deviceType !== "NA") {
								window.plugins.calendar.deleteEvent(title,location,notes,startDate,endDate,success,error);
								cordova.plugins.notification.local.cancel(CommonServices.appointmentListArray.appointmentsListItems[listSelected.$index].appointmentId, function() {
								});
							}
						} else {
							CommonServices.showLoading(false);
							CommonServices.showAlert("Could not delete Appointment. Please try again");
						}
					}

				 },
				function(error) { 
					CommonServices.showLoading(false);
					restServices.handleWebServiceError(error);
				}); 
			}
			
		} else {
			
		}
	}
	
	
	function calTime(time){
		var hours = Number(time.match(/^(\d+)/)[1]);
		var minutes = Number(time.match(/:(\d+)/)[1]);
		var AMPM = time.split(":")[0] >= 12? 'PM':'AM';
		if(AMPM === "PM" && hours<12) hours = hours+12;
		if(AMPM === "AM" && hours === 12) hours = hours-12;
		var sHours = hours.toString();
		var sMinutes = minutes.toString();
		if(hours<10) sHours = "0" + sHours;
		if(minutes<10) sMinutes = "0" + sMinutes;
		return {
			sHours: sHours,
			sMinutes: sMinutes
		};
	}
	CommonServices.appointList = false;
	$scope.addAppointment = function(){
		CommonServices.appointList = true;
		$state.go("appointments.createAppointment");
	}
	
}]);

agentApp.controller('appointmentsDetailsCtrl', ['$scope','$location','RestServices','CommonServices','$state', function ($scope,$location, RestServices,CommonServices,$state) {
	
	$scope.appointmentDetails = {};
	CommonServices.editAppointment = {};
	
	for(var i=0; i< CommonServices.appointmentListArray.appointmentsListItems.length; i++){
		if(i === CommonServices.appointmentSelected){
			angular.extend($scope.appointmentDetails, CommonServices.appointmentListArray.appointmentsListItems[i]);
		}
	}
	$("#name").html($scope.appointmentDetails.name);
	if($scope.appointmentDetails.location === undefined) {
		$("#location").html("-")
	} else {
		$("#location").html($scope.appointmentDetails.location);
	}
	
	$("#startTime").html($scope.appointmentDetails.startTime);
	$("#endTime").html($scope.appointmentDetails.endTime);
	$("#startDate").html($scope.appointmentDetails.startDate);
	$("#endDate").html($scope.appointmentDetails.endDate);
	if($scope.appointmentDetails.notes === undefined){
		$("#notes").html("-");
	} else{
		$("#notes").html($scope.appointmentDetails.notes);
	}
	if($scope.appointmentDetails.reminder === undefined){
		$("#reminder").html("-");
	} else{
		$("#reminder").html($scope.appointmentDetails.reminder + " Mints");
	}
	$scope.editAppointment = function(){
		CommonServices.editEvent = true;
		CommonServices.editAppointment = $scope.appointmentDetails;
		$state.go("appointments.createAppointment");
		
	}
	
}]);

agentApp.controller('CreateAppointmentCtrl', ['$scope','$location','RestServices','CommonServices','$state','$timeout', function ($scope,$location, RestServices,CommonServices,$state,$timeout) {
	
    $scope.reminderData = {
    reminder: [
      {id: '5', name: '5 Minutes'},
      {id: '10', name: '10 Minutes'},
      {id: '15', name: '15 Minutes'},
	  {id: '30', name: '30 Minutes'},
	  {id: '60', name: '1 hour'},
	  {id: '120', name: '2 hours'},
	  {id: '180', name: '3 hours'}
    ]
   };
   var oldTitle;
   var oldLocation;
   var oldNotes;
   var oldStartDate;
   var oldEndDate;
   var oldReminder;
   
   if(CommonServices.editEvent === true){
	   var appStartTime =  CommonServices.editAppointment.startTime.toString().split(":");
	   var startTime = (appStartTime[0])+":"+(appStartTime[1])+" "+(appStartTime[0]>=12?'PM':'AM');
	   var appEndTime = CommonServices.editAppointment.endTime.toString().split(":");
	    var endTime = (appEndTime[0])+":"+(appEndTime[1])+" "+(appEndTime[0]>=12?'PM':'AM');
		$scope.clientName = CommonServices.editAppointment.name;
		$scope.location = CommonServices.editAppointment.location;
		$scope.appStartTime = startTime;
		$scope.appEndTime = endTime;
		$scope.appoinementStartDate = CommonServices.editAppointment.startDate;
		$scope.appoinementEndDate =  CommonServices.editAppointment.endDate;
		$scope.notes = CommonServices.editAppointment.notes;
		var reminder;
		for(var i=0;i<$scope.reminderData.reminder.length;i++){
			if($scope.reminderData.reminder[i].id === CommonServices.editAppointment.reminder){
				reminder = i;
			}
		}
		$scope.reminder = $scope.reminderData.reminder[reminder];
   }
   
   if(CommonServices.editEvent === true){
	   $scope.newAppointment = false;
   } else {
	   var date ;
	   if(CommonServices.appointList === true && CommonServices.selectedDate !== "") {
			date = new Date(CommonServices.selectedDate);
	   } else {
			date = new Date();
	   }
	   var todayDate = date.getDate() < 10? "0"+date.getDate() : date.getDate();
	   date = todayDate+"/"+(date.getMonth() + 1 )+"/"+date.getFullYear();
	   $scope.appoinementStartDate = date;
	   $scope.newAppointment = true;
   }
  
   function previousAppointmentInfo(){
   
		oldTitle = "Appointment with "+CommonServices.editAppointment.name;
		oldLocation = CommonServices.editAppointment.location;
		oldNotes = CommonServices.editAppointment.notes;
		
		var appoinementStartDate = CommonServices.editAppointment.startDate.split(/[^0-9]+/);
		var m = appoinementStartDate[1];
		var y = appoinementStartDate[2];
		var d = appoinementStartDate[0];
		var calStartSource =  m + "/"+d+"/"+y;	 
		var calStartDate = new Date(calStartSource);

		var appoinementEndDate = CommonServices.editAppointment.endDate.split(/[^0-9]+/);
		var m = appoinementEndDate[1];
		var y = appoinementEndDate[2];
		var d = appoinementEndDate[0];
		var calEndSource =  m + "/"+d+"/"+y;
		var calEndDate = new Date(calEndSource);
		
		var appStartTime =  CommonServices.editAppointment.startTime.toString().split(":");
		var startTime = (appStartTime[0])+":"+(appStartTime[1])+" "+(appStartTime[0]>=12?'PM':'AM');
		var appEndTime = CommonServices.editAppointment.endTime.toString().split(":");
		var endTime = (appEndTime[0])+":"+(appEndTime[1])+" "+(appEndTime[0]>=12?'PM':'AM');
		
		if(startTime !== "") {
		 calTime(startTime);			 
		 calStartDate.setHours(calTime(startTime).sHours,calTime(startTime).sMinutes,00);
		}
		if(endTime !== "") {
		 calTime(endTime);
		 calEndDate.setHours(calTime(endTime).sHours,calTime(endTime).sMinutes,00);
		}
		
		oldStartDate = calStartDate;
		oldEndDate = calEndDate;
		oldReminder = CommonServices.editAppointment.reminder;
   }
   
  
    $scope.startTimeSetr  = false;
	var date = new Date();
	var fromDate = new Date(date);
	var dayFrom = fromDate.getDate();
	var monthFrom = fromDate.getMonth() + 1;
	var yearFrom = fromDate.getFullYear();
	var toDate =  new Date(date);
	toDate.setDate(toDate.getDate() + 30);
	var dayTo = toDate.getDate();
	var monthTo = toDate.getMonth() + 1;
	var yearTo = toDate.getFullYear();
	
	var enableCalendarfrom = monthFrom + "/" + dayFrom + "/" + yearFrom;
    var enableCalendarTo = monthTo + "/" + dayTo + "/" + yearTo;

    $('#cal-startdate-Newappointment').loadCalendar({
        //'disablePastDates':true,
        'enableDateRange': true,
        'enableCalendarFrom': enableCalendarfrom,
        'enableCalendarTo': enableCalendarTo
    });
	
	$('#cal-enddate-Newappointment').loadCalendar({
        //'disablePastDates':true,
        'enableDateRange': true,
        'enableCalendarFrom': enableCalendarfrom,
        'enableCalendarTo': enableCalendarTo
    });
	
	
    $('#start-time-Newappointment, #end-time-Newappointment').timePickerSelect({
                 containerClass: undefined,
                 containerWidth: undefined,
                 hoursLabel: 'Hour',
                 minutesLabel: 'Minutes',
                 setButtonLabel: 'Set',
                 popupImage: undefined,
                 onFocusDisplay: true,
                 zIndex: 1000,
                 onBeforeShow: undefined,
                 onClose: undefined,
                 timepickerIcon: true,
                 highlightSelected: true
             });
	
	var timeID;
	var timeModel;
	
	$scope.calIconClick= function(event)
	{
		angular.element("#"+ event.currentTarget.children[0].id).focus();
		
	};
	$scope.timIconClick= function(event)
	{
		angular.element("#"+ event.currentTarget.children[0].id).focus();
		timeID = event.currentTarget.children[0].id;
		timeModel = $("#"+ event.currentTarget.children[0].id).attr("data-ng-model");
	};
	$("#timePickerSelectSetCntr").on("click", function(){
		
		$scope.startTimeSetr  = true;
		var idSpan;
		idSpan = $("#IDSpan").text();
		$scope.timeModel = $("#"+idSpan).val();	
		$scope.modelVal = $("#modelSpan").text();
		
		if($scope.modelVal === "appStartTime")
		{
			$timeout(function(){
				$scope.appStartTime = $scope.timeModel;
			});
		}
		if($scope.modelVal === "appEndTime"){
			$timeout(function(){
				$scope.appEndTime = $scope.timeModel;
			});
		}
		
	});
		
	function calTime(time){
		var hours = Number(time.match(/^(\d+)/)[1]);
		var minutes = Number(time.match(/:(\d+)/)[1]);
		var AMPM = time.match(/\s(.*)$/)[1];
		if(AMPM === "PM" && hours<12) hours = hours+12;
		if(AMPM === "AM" && hours === 12) hours = hours-12;
		var sHours = hours.toString();
		var sMinutes = minutes.toString();
		if(hours<10) sHours = "0" + sHours;
		if(minutes<10) sMinutes = "0" + sMinutes;
		return {
			sHours: sHours,
			sMinutes: sMinutes
		};
	}
                                              
	$scope.createNewAppointment = function(){

		 var appoinementStartDate = $scope.appoinementStartDate.split(/[^0-9]+/);
		 var m = appoinementStartDate[1];
		 var y = appoinementStartDate[2];
		 var d = appoinementStartDate[0];
		 var calStartSource =  m + "/"+d+"/"+y;	 
		 var calStartDate = new Date(calStartSource);
		 
		 var appoinementEndDate = $scope.appoinementEndDate.split(/[^0-9]+/);
		 var m = appoinementEndDate[1];
		 var y = appoinementEndDate[2];
		 var d = appoinementEndDate[0];
		 var calEndSource =  m + "/"+d+"/"+y;
		 var calEndDate = new Date(calEndSource);
		
		 var Starttime = $("#start-time-Newappointment").val();
		 var Endtime = $("#end-time-Newappointment").val();
		 var toDate = new Date();
		 
         if(Starttime !== "") {
			 calTime(Starttime);			 
			 calStartDate.setHours(calTime(Starttime).sHours,calTime(Starttime).sMinutes,00);
		 }
		 if(Endtime !== "") {
			 calTime(Endtime);
			 calEndDate.setHours(calTime(Endtime).sHours,calTime(Endtime).sMinutes,00);
		 }
		 
		 if(calEndDate < calStartDate ) {
			 CommonServices.showAlert("Start time should be before the end of the event.");
		 } else if(calStartDate < toDate){
			 CommonServices.showAlert("Appointment cannot be created for past time.");
		 }
		 else {
			 
			var startDate = new Date(calStartDate.getFullYear(),calStartDate.getMonth(),calStartDate.getDate(),calStartDate.getHours(),calStartDate.getMinutes(),0,0); // month 0 = january, 11 = december
			var endDate = new Date(calEndDate.getFullYear(),calEndDate.getMonth(),calEndDate.getDate(),calEndDate.getHours(),calEndDate.getMinutes(),0,0);
			var title = "Appointment with " + $scope.clientName;
			var reminder = "";
			if($scope.reminder === undefined || $scope.reminder === null){
				reminder = "";
			} else {
				reminder = $scope.reminder.id;
			}
			var location = "";
			if($scope.location === undefined || $scope.location === null){
				location = "";
			} else {
				location = $scope.location;
			}
			var notes = "";
			if($scope.notes === undefined || $scope.notes === null){
				notes = "";
			} else {
				notes = $scope.notes;
			}
			var success = function(message) { };
			var error = function(message) { };

			var appointmentStart = startDate.getDate()+"/"+(startDate.getMonth()+1)+"/"+startDate.getFullYear();
			var appointmentEnd = endDate.getDate()+"/"+(endDate.getMonth()+1)+"/"+endDate.getFullYear(); 
			
			var startTime = ($("#start-time-Newappointment").val());
			var appStartTime = calTime(startTime).sHours+":"+calTime(startTime).sMinutes+":00"; 
			
			var endTime = $("#end-time-Newappointment").val();
			var appEndTime = calTime(endTime).sHours+":"+calTime(endTime).sMinutes+":00"; 

			if(CommonServices.editEvent === true){
				var appointmentData = {  
				   "appointmentDetailList":[  
					  {  
						 "appointmentId":CommonServices.editAppointment.appointmentId,
						 "clientName":$scope.clientName,
						 "location":location,
						 "startTime":appStartTime,
						 "endTime":appEndTime,
						 "appointmentStartDate":appointmentStart,
						 "appointmentEndDate":appointmentEnd,
						 "notes":notes,
						 "reminder":reminder
					  }
				   ],
				   "userId": CommonServices.getCommonData("userCode").toUpperCase()
				}
				var editAppointmentResponse = RestServices.postService(RestServices.urlPathsNewPortal.updateAppointmentDetails, appointmentData);
				editAppointmentResponse.then(
				function(response){
					if(response.data === ""){
						CommonServices.showLoading(false);
						CommonServices.showAlert("Could not connect to server. Please try again later.");
					} else {
					CommonServices.showLoading(false);
					
					if(response.data.errorCode !== "0"){
						CommonServices.showAlert(response.data.errorMessage);
					} else{
						CommonServices.editEvent = false;
						previousAppointmentInfo();
						if (CommonServices.deviceType !== "NA") {
							var newCalOptions = window.plugins.calendar.getCalendarOptions();
							newCalOptions.firstReminderMinutes = reminder;
							newCalOptions.secondReminderMinutes = null;
							newCalOptions.recurrence = null;
							newCalOptions.recurrenceEndDate = null;
							newCalOptions.calendarName = null;
							newCalOptions.calendarId = null;
							newCalOptions.url = null;
							
							var oldCalOptions = window.plugins.calendar.getCalendarOptions();
							oldCalOptions.firstReminderMinutes = oldReminder;
							oldCalOptions.secondReminderMinutes = null;
							oldCalOptions.recurrence = null;
							oldCalOptions.recurrenceEndDate = null;
							oldCalOptions.calendarName = null;
							oldCalOptions.calendarId = null;
							oldCalOptions.url = null;
							
							window.plugins.calendar.modifyEventWithOptions(oldTitle,oldLocation,oldNotes,oldStartDate,oldEndDate,title,location,notes,startDate,endDate,oldCalOptions,newCalOptions,success,error);
						}
						var text = "Your Appointment has been scheduled with "+$scope.clientName+" on "+appointmentStart+" at "+ $("#start-time-Newappointment").val();
						CommonServices.showAlert(text);
				        
						$state.go("appointments.appointmentsCalendar");
					}
				}
				},
				function(error){
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
				});
			} else {
				var appointmentData = {  
					"appointmentDetailList":[  
					{  
						"clientName":$scope.clientName,
						"location":location,
						"startTime":appStartTime,
						"endTime":appEndTime,
						"appointmentStartDate":appointmentStart,
						"appointmentEndDate":appointmentEnd,
						"notes":notes,
						"reminder":reminder
					}
					],
					"userId": CommonServices.getCommonData("userCode").toUpperCase()
				};
				
				var addAppointmentResponse = RestServices.postService(RestServices.urlPathsNewPortal.insertAppointmentDetails, appointmentData);
				addAppointmentResponse.then(
				function(response){
					if(response.data === ""){
						CommonServices.showLoading(false);
						CommonServices.showAlert("Could not connect to server. Please try again later.");
					} else {
					CommonServices.showLoading(false);
					if(response.data.errorCode !== "0"){
						CommonServices.showAlert(response.data.errorMessage);
					} else{
						if (CommonServices.deviceType !== "NA") {
							var calOptions = window.plugins.calendar.getCalendarOptions();
							calOptions.firstReminderMinutes = reminder;
							calOptions.secondReminderMinutes = null;
							calOptions.recurrence = null;
							calOptions.recurrenceEndDate = null;
							calOptions.calendarName = null;
							calOptions.calendarId = null;
							calOptions.url = null;
							window.plugins.calendar.createEventWithOptions(title,location,notes,startDate,endDate,calOptions,success,error);
						}
						var text = "Your Appointment has been scheduled with "+$scope.clientName+" on "+appointmentStart+" at "+ $("#start-time-Newappointment").val();
						CommonServices.showAlert(text);
						$state.go("appointments.appointmentsCalendar");

					}
				}
				},
				function(error){
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
				});
			}		
		 }
	}



}]);

