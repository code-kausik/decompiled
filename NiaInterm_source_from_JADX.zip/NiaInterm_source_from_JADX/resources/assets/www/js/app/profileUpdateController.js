agentApp.controller('profileUpdateController', ['$scope','RestServices','CommonServices', function ($scope, RestServices,CommonServices) {
	
			$scope.bodyHeight = window.innerHeight+'px';
			$scope.home = function() {
				RestServices.goHome();
			};	
			CommonServices.showLoading(false);
			//LogOut Start
			$scope.logOut = function() {
				RestServices.logOut();
			};
			//LogOut End

}]);

agentApp.controller('ForgotPassCtrl', ['$scope', 'CommonServices','$location', 'RestServices','$state', function($scope, CommonServices, $location, RestServices, $state) {
		
		$scope.goBack= function(){
			$location.path('/');
		}
		$scope.goBackOtp = function(){
            $scope.forgotPassobj.OTPCounter = 0;
			$scope.forgotPassobj.validateOTP = false;
		}
		
		//Creating object for Forgot Password
		$scope.forgotPassobj = {
			OTPCounter: 0,
			validateOTP:false,
			userData:{
				otpModel:"",
				userName:""
			},
			forgotpas: function(data){ 
				RestServices.headerWithoutToken = true;
				if(data == "resend" || data == " "){ // Request for resend OTP for Forgot Password
					var forgotPassData = {
					"userId": $scope.forgotPassobj.userData.userName,
					"dob":"",
					"otp":"",
					"flag":"Intermediary",
					"emailId":null,
					"mobileNo":null,
					"alfrescoInput":{
						"channel":"CUSTOMER",
						"language":"English"
						}
					}
				 var forgotPassResponse = RestServices.postService(RestServices.urlPathsNewPortal.generateOtpForgotPassword, forgotPassData);
				 
				  forgotPassResponse.then(
					function(response) { // success
					 
                    if(response.data !== ""){
                                        
                        if(response.data.emailId !== "" || response.data.emailId !== undefined){
                            if(response.data.statusCode !== "1"){
                                          
                                RestServices.headerWithoutToken = false;
                                $scope.forgotPassobj.validateOTP = true;
                                $scope.forgotPassobj.OTPCounter++;
                                CommonServices.setCommonData("forgotPassData",response.data);
                                $scope.forgotPassobj.userData.otpModel = "";
                            }
                            else{
                                CommonServices.showAlert(response.data.statusMessage);
                            }
                        }
                        else{
                            CommonServices.showAlert("Could not connect to server. Please try again later.");
                        }
                                          
                    }
						
                    else{
                        CommonServices.showAlert("Sorry,There is some error.");
                    }
						CommonServices.showLoading(false);							
						
					},
					function(error) { // failure
						RestServices.headerWithoutToken = false;
						CommonServices.showLoading(false);
						RestServices.handleWebServiceError(error);
					});
				}
				else if(data == "confirm"){ //Get OTP for Forgot Password
					RestServices.headerWithoutToken = true;
					var OTPData = {
						"userId":$scope.forgotPassobj.userData.userName,
						"dob":"",
						"otp": this.userData.otpModel,
						"flag":"Intermediary",
						"emailId":CommonServices.getCommonData("forgotPassData").emailId,
						"mobileNo":CommonServices.getCommonData("forgotPassData").mobileNo,
						"alfrescoInput":{
							"channel":"CUSTOMER",
							"language":"English"
							}
						}
						var OtpResponse = RestServices.postService(RestServices.urlPathsNewPortal.forgotPasswordNonCustomer, OTPData);
				 
					  OtpResponse.then(
						function(response) { // success
							RestServices.headerWithoutToken = false;
							  if(response.data.statusCode === "0"){
								  $scope.forgotPassobj.validateOTP = true;
								   CommonServices.showAlert("New Password has been sent to your registered mobile no. and email Id, please use it for login.");
									$location.path('/');
							  }
							  else if(response.data.statusCode === "1"){
							    CommonServices.showAlert(response.data.statusMessage);
							  }
							  else{
								  CommonServices.showAlert("Could not connect to server, please try after some time.");
							  }
							  
							  CommonServices.showLoading(false);						
							
						},
						function(error) { // failure
							RestServices.headerWithoutToken = false;
							CommonServices.showLoading(false);
							RestServices.handleWebServiceError(error);
						});
				}
				else if(data === "cancel"){ //Cancel Forgot Password
					$location.path('/');
				}
				
			},
			resetPass: function(){ //Reset Forgot Password
				$scope.forgotPassobj.validateOTP = false;
				$scope.forgotPassobj.OTPCounter =0;
			}
			
		}

}]);


agentApp.controller('changePasswordCtrl', ['$scope', 'CommonServices','$location', 'RestServices','$state', function($scope, CommonServices, $location, RestServices, $state) {
	$scope.changePasswordFlag= CommonServices.getCommonData("changePassFlag");
	
	$scope.passwordExp =/(?=.*[0-9])(?=.*[!@#$%&])(?=.*[a-z])(?=.*[A-Z])[a-zA-Z0-9!@#$%&]{8,15}$/;
	
	//Creating object for change password
	$scope.changePassobj = {
		
		changePass: function(data){	
		//RestServices.headerWithoutToken = true;
			//Submit change password data
			if(data === "submit"){
				
				var oldPassword = $scope.oldPass;
				var newPassword = $scope.newPass;
				var confirmPassword = $scope.confirmPass;
				
				if ("" == oldPassword){
					CommonServices.showAlert("Please enter old password.");
					return false;
				}
				
				if(oldPassword.indexOf(" ") !== -1 ){
					CommonServices.showAlert("Please enter valid entries as Old Password.");
					return false;
				}
				if ("" == newPassword){
					CommonServices.showAlert("Please enter new password.");
					return false;
				}
				if(newPassword.indexOf(" ") !== -1 ){
					CommonServices.showAlert("Please enter valid entries as new password.");
					return false;
				}
				if ("" == confirmPassword){
					CommonServices.showAlert("Please confirm new password.");
					return false;
				}
				
				if(confirmPassword.indexOf(" ") !== -1 ){
					CommonServices.showAlert("Please enter valid entries in Confirm new password.");
					return false;
				}
				if (confirmPassword != newPassword){
					CommonServices.showAlert("New password and confirm new password should be same.");
					return false;
				}
				if (oldPassword == newPassword){
					CommonServices.showAlert("Old password and new password should not be same.");
					return false;
				}
				if (confirmPassword.length < 8 && newPassword.length < 8){
					CommonServices.showAlert("New password should contain minimum 8 characters.");
					return false;
				}
		
				
				var changePassData = {
					"userId": CommonServices.getCommonData("userCode").toUpperCase(),//"AGUSR1",
					"oldPassword": oldPassword,
					"newPassword": newPassword
				}
				var changePassResponse = RestServices.postService(RestServices.urlPathsNewPortal.changePassword, changePassData);
				changePassResponse.then(
					function(response) { // success
					//RestServices.headerWithoutToken = false;
						if(response.data.statusCode === "0"){

							CommonServices.showAlert(response.data.statusMessage);
                             CommonServices.setCommonData("changePassFlag","false");
							$location.path("/home");
						}
						else if(response.data.statusCode === "1"){
						   CommonServices.showAlert("Invalid Credentials");
						}
						else{
						    CommonServices.showAlert("Could not connect to server, please try after some time.");
						}
												
						CommonServices.showLoading(false);											
					},
					function(error) { // failure
					//RestServices.headerWithoutToken = false;
						CommonServices.showLoading(false);
						RestServices.handleWebServiceError(error);
				});
			}
			if(data === "cancel"){
				$state.go('profileUpdate.updateProfile');
			}
			
		}
	}
	
	
}]);

agentApp.controller('profileUpdateCtrl', ['$scope', 'CommonServices','$location', 'RestServices','$state', function($scope, CommonServices, $location, RestServices, $state) {
	
	/*************Implement of CR_3693 profile pic - sudip ***********/

	$scope.stakeValue = CommonServices.getCommonData("stakeCode");
	var agentFirstName = CommonServices.getCommonData("agentFirstName");
	var agentSecondName = CommonServices.getCommonData("agentSecondName");

	CommonServices.isManageRenewals = false;
	if(agentFirstName !== undefined && agentSecondName !== undefined){
		$scope.agentName = agentFirstName + " " + agentSecondName;
	}if(agentFirstName === undefined){
		$scope.agentName = agentSecondName;
	} if(agentSecondName === undefined){
		$scope.agentName = agentFirstName;
	} 

	$scope.profilePicDetails = CommonServices.profilePicUpdatedPath;
		if($scope.stakeValue === 'AGENT' && !CommonServices.isProfilePicUpdated){
			
			var profilePicDetailsInput = {
				"userId":CommonServices.getCommonData("userId")
				}
				//getUserProfileURL
			var profilePicResponse = RestServices.postService(RestServices.urlPathsNewPortal.getUserProfileURL, profilePicDetailsInput);
			if(profilePicResponse === undefined){
				CommonServices.showAlert("Not find profile pic");
				return;
			} else{
				profilePicResponse.then(
				function(response) { // success	
					CommonServices.showLoading(false);	
					if(response.data !== ""){
						if(response.data.url === "null" || response.data.url === '' || response.data.url === undefined){
							//CommonServices.showAlert(response.data.errorMessage);
							//CommonServices.showAlert("Not able to fetch profile picture from server");
							$scope.profilePicDetails = "images/profile_icon.svg";
							return;
						}
						else{
							if(response.data.url !== undefined && response.data.url !== '' && response.data.url !== null && response.data.url !== "null"){
								$scope.profilePicDetails = response.data.url;
								CommonServices.profilePicUpdatedPath = $scope.profilePicDetails;
								CommonServices.isProfilePicUpdated = true;
								console.log("Agent profile image" +$scope.profilePicDetails);
							} else {
								//CommonServices.showAlert("Not able to fetch profile picture from server");
								$scope.profilePicDetails = "images/profile_icon.svg";
							}
						}
						
					}
					else{
						$scope.profilePicDetails = "images/profile_icon.svg";
					}
					//runOncePerDay();
				},
				function(error) { // failure
					CommonServices.showLoading(false);
					//RestServices.handleWebServiceError(error);
					$scope.profilePicDetails = "images/profile_icon.svg";
					//CommonServices.showAlert("Not able find profile pic from server");
				});
			}
		}
	/*****************Implementation CR_3693 end*****************/

	$scope.changePasswordPU= function(){
		$state.go('profileUpdate.changePassword');
	};
	
	$scope.profileDetails = CommonServices.getCommonData("profileDetailsData");
	$scope.profileDetailsAdd = CommonServices.getCommonData("profileDetailsData").userProfile.relation.addresses[0];	
	
	$scope.changeType = function(){
	  var input = angular.element(document.querySelector(".changeInputType"));
	  input.attr('type','number');
  };
	
	//Creating object for update profile
	$scope.updateProfileobj = {
		updateProfile: function(data){
			if(data === "submit"){
				//Update Profile Details on button submit
				var updateProfileInput = 
					{"userProfile":
						{
							"firstName":$scope.profileDetails.userProfile.firstName,
							"lastName":$scope.profileDetails.userProfile.lastName,
							"relation":{
								"addresses":[{
									"street":$scope.profileDetailsAdd.street,
									"pincode":$scope.profileDetailsAdd.pincode,
									"mobileNumber1":$scope.profileDetailsAdd.mobileNumber1,
									"mobileNumber2":$scope.profileDetailsAdd.mobileNumber2,
									"emailId1":$scope.profileDetailsAdd.emailId1,
									"landLineNumber1":$scope.profileDetailsAdd.landLineNumber1,
									"landLineNumber2":$scope.profileDetailsAdd.landLineNumber2,
									"branchcode":$scope.profileDetails.brancCode
								}]
							},
							"dob":CommonServices.getCommonData("LoginData").userProfile.dob,
							"name":$scope.profileDetails.userProfile.firstName +" "+ $scope.profileDetails.userProfile.lastName,
							"loginDate":CommonServices.getCommonData("LoginData").lastLoginDate,
							"userId":CommonServices.getCommonData("userId")
						}}
				var updateProfileResponse = RestServices.postService(RestServices.urlPathsNewPortal.updateNCProfileDetails, updateProfileInput);
				updateProfileResponse.then(
					function(response) { // success	
						CommonServices.showAlert(response.data.userProfile.footer.status);						
						CommonServices.showLoading(false);	
					},
					function(error) { // failure
						CommonServices.showLoading(false);
						RestServices.handleWebServiceError(error);
				});
			}
			if(data === "back"){
				RestServices.goHome();
			}
		}
	}
	
}]);
