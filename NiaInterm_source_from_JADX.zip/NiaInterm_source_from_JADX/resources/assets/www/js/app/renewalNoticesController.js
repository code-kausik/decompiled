agentApp.controller('renewalNoticesController', ['$scope','RestServices','CommonServices','$state','$rootScope','$window', function ($scope, RestServices,CommonServices,$state,$rootScope,$window) {
			
			$scope.home = function() {
				
				$state.go("home");
			};
			$scope.backToSearch = function() {
				
				$state.go("renewalNotices");
			};
			
			$scope.backToPolicy = function() {
				if($rootScope.directPolicyFlag==true)
					$state.go("renewalNotices");
				else
				    $state.go("renewalNoticesPolicyList");
			};
			
			$scope.countLabel = "Select Policy to continue";
			var mydateSt = CommonServices.getCommonData("serverDate");

		    var mynewdateFrm = new Date(mydateSt);
		    
		    mynewdateFrm.setDate(mynewdateFrm.getDate() - 30);
		    //alert(mynewdateFrm);
		    var dayFrom = mynewdateFrm.getDate();
			var monthFrom = mynewdateFrm.getMonth()+1;
			var yearFrom = mynewdateFrm.getFullYear();

			 var mynewdateTo = new Date(mydateSt);
			 mynewdateTo.setDate(mynewdateTo.getDate() + 45);

			 var dayTo = mynewdateTo.getDate();
			 var monthTo = mynewdateTo.getMonth()+1;
			 var yearTo = mynewdateTo.getFullYear();

			var enableCalendarfrom = monthFrom + "/" + dayFrom + "/" + yearFrom;
		    var enableCalendarTo = monthTo + "/" + dayTo + "/" + yearTo;

			$('#ExpDateFrom').loadCalendar({
		        'enableDateRange': true,
		       'enableCalendarFrom': enableCalendarfrom/*mynewdateFrm*/,
		        'enableCalendarTo': enableCalendarTo/*mynewdateFrm*/
		    }); 
			$('#ExpDateTo').loadCalendar({
		        'enableDateRange': true,
		       'enableCalendarFrom': enableCalendarfrom,
		        'enableCalendarTo': enableCalendarTo
		    });
			

			
			$scope.calIconClick= function(event)
			{
				angular.element("#"+ event.currentTarget.children[0].id).focus();  
			};
			
			$scope.checkDate= function()
			{
				if($scope.polExpDateFrom === undefined || $scope.polExpDateFrom === ""){
					CommonServices.showAlert("Please select Policy Expiry Date From first.");
					//return false;
				}
				else
					{
				var dateFrom = $scope.polExpDateFrom;
				var dateTo =$scope.polExpDateTo;
				
				

				var arr = dateFrom.split('/');
				var arr1 = dateTo.split('/');

		        var dateSatrt=new Date(arr[2],arr[1]-1,arr[0]);
				var dateEnd=new Date(arr1[2],arr1[1]-1,arr1[0]);
				var timeDiff = Math.abs(dateEnd.getTime() - dateSatrt.getTime());
				var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24)); 
				if(dateEnd<dateSatrt)
					{
					CommonServices.showAlert("Policy Expiry Date from should not be greater than Policy Expiry Date to.");
					$scope.polExpDateTo="";
					//return false;
					}
				
				
				else if((diffDays)>dateSatrt)
					{
					
					CommonServices.showAlert("Policy Expiry Date To should not be greater than 45 days from Policy Expiry Date From.");
					$scope.polExpDateTo="";
					//return false;
					}
					}
			
			};
			
			

			$scope.renewalNoticesController ={
	    		 onload: function(){
					/* getAllLobs */

					 var productListResponse = RestServices.getService(RestServices.urlPathsNewPortal.getAllLobs);
						productListResponse.then(
							function(response) { // success	
								CommonServices.showLoading(false);	
								$scope.productList = response.data;
								
								$scope.productsAll=[];
								angular.forEach($scope.productList.lobs, function(value, key) {
								$scope.productSubList = value.products;
								//console.log("$value.products-->"+$scope.productSubList);
								for(var i in $scope.productSubList){
									$scope.productsAll.push($scope.productSubList[i]);
								}
								
							}); 
							},
							function(error) { // failure
								CommonServices.showLoading(false);
								RestServices.handleWebServiceError(error);
						}); 
					/* getAllLobs*/
						
					
	    		 }
     		};
     		$scope.renewalNoticesController.onload();
			
			
			$scope.showBreakInErrMsg = false;
			
			CommonServices.editQuoteHistory = false;
			//Creating object for manage policy
			$scope.searchType = "bulkSearch";
			$scope.managePolicyObj = {
				detailsFlag: false,
				invalidInput: true,
				quotePolicyData:"",
				policyFlag: false,
				breakInFlag: false,
				extendPolicy: false,
				policyListFlag: false,
				rejectResponse:"",
				searchOptionsList : [{
					 id : 'quotes',
					 name : 'Renewal Quote No.'
				 }, {
					 id : 'policies',
					 name : 'Old Policy No.'
				 }],
				managePolicySubmit: function(){
                    this.detailsFlag = false;
					//On submit of manage policy
					if($scope.searchType === "search"){				
						if($scope.quotePolicyNum === undefined || $scope.quotePolicyNum === ""){
						$scope.policyDetails.productCode ="";
						    $scope.managePolicyObj.detailsFlag = false;
							CommonServices.showAlert("Please enter 16 digit Quote / 20 digit Policy No.");
						}
						else{
							if($scope.quotePolicyNum.toString().length < 16){
							$scope.policyDetails.productCode ="";
							    $scope.managePolicyObj.detailsFlag = false;
								CommonServices.showAlert("Please enter 16 digit Quote / 20 digit Policy No.");
								return false;
							}
							
							if($scope.quotePolicyNum.toString().length === 16){ //validation if input value equal to 16
								if($scope.singleSelect === "policies"){
									CommonServices.showAlert("No Data Found");
									return false;
								}
								this.quotePolicyData = {
									"userProfile": {
										"userId": CommonServices.getCommonData("userId"),
										"loggedInRole": CommonServices.getCommonData("loggedInRole"),
										"searchQuote": {
											"productCode": null,
											"productName": null,
											"quoteNumber": $scope.quotePolicyNum,
											"policyNumber":null,
											"startDate": null,
											"endDate": null,
											"status": null,
											"resultSize": 5,
											"startIndex": 1,
											"totalResults": 0
										}
											
									}
								
								}
								this.policyFlag = false;
								this.managePolicyService();
								return false;
							}
							
							if($scope.quotePolicyNum.toString().length === 20){ //validation if input value equal to 20
								if($scope.singleSelect === "quotes"){
									CommonServices.showAlert("No Data Found");
									return false;
								}
								this.quotePolicyData = {
									"userProfile": {
										"userId": CommonServices.getCommonData("userId"),
										"loggedInRole": CommonServices.getCommonData("loggedInRole"),
										"searchQuote": {
											"productCode": null,
											"productName": null,
											"policyNumber": $scope.quotePolicyNum,
											"quoteNumber": null,
											"startDate": null,
											"endDate": null,
											"status": null,
											"resultSize": 5,
											"startIndex": 1,
											"totalResults": 0
										}
										
									}
								}
								this.policyFlag = true;
								this.managePolicyService();
								return false;
							}
							if(16 < $scope.quotePolicyNum.toString().length < 20){
							$scope.policyDetails.productCode ="";
							   $scope.managePolicyObj.detailsFlag = false;
								CommonServices.showAlert("Please enter 16 digit Quote / 20 digit Policy No.");
								return false;
							}
						}
							
					}
					else {				
						if($scope.productCode === undefined || $scope.productCode === ""){
							/*$scope.policyDetails.productCode ="";
							    $scope.managePolicyObj.detailsFlag = false;*/
								CommonServices.showAlert("Please enter 16 digit Quote / 20 digit Policy No.");
							}
							else{
								
									this.quotePolicyData = {
										"userProfile": {
											"userId": CommonServices.getCommonData("userId"),
											"loggedInRole": CommonServices.getCommonData("loggedInRole"),
											"searchQuote": {
												"productCode": $scope.productCode,
												"productName": null,
												"policyNumber":"",
												"startDate": $scope.polExpDateFrom,
												"endDate": $scope.polExpDateTo,
												"status": null,
												"resultSize": 0,
												"startIndex": 0,
												"totalResults": 0
											}
												
										}
									}
									
									this.managePolicyService();
									
									return false;
								}
						}		
										
				},
				showProdName : function(model,list) {
					if(list!=undefined)
						{
		               	 for (var i = 0, n = list; i < n.length; i++) {
		               		 if (model === list[i].productCode) {
		               			 return list[i].productName;
		               		 }
		               	 }
						}
                },
				validatePolicyStartDate: function(){
				
					var policyStartDate = $scope.managePolicyObj.policyDetails.policyStartDate;
					var logDate = CommonServices.getCommonData("serverDate");
					
					var policyStartDate = $scope.managePolicyObj.policyDetails.policyStartDate.split('/');
					policyStartDate = policyStartDate[1] + '/' + policyStartDate[0] + '/' + policyStartDate[2]; //mm/dd/yyyy
					
					policyStartDate = new Date(policyStartDate);
					
					var logDate = CommonServices.getCommonData("serverDate");
					logDate = new Date(logDate);
					
					if(policyStartDate >= logDate){
						return {
							flag: true
						};
					}
					else{
						return {
							flag: false
						};
					}
				},
				managePolicyService: function(){
					//Service call on submit of manage policy
					//var quotePolicyResponse = RestServices.postService(RestServices.urlPathsNewPortal.getPolicyList, this.quotePolicyData);
					var quotePolicyResponse = RestServices.postService(RestServices.urlPathsNewPortal.getRenewNoticePolicyList, this.quotePolicyData);
					//var quotePolicyResponse = RestServices.postService("noticePolicyList", this.quotePolicyData);
					quotePolicyResponse.then(
						function(response) { // success	
						
							//CommonServices.showAlert(response.data.userProfile.footer.status);
							CommonServices.showLoading(false);	
							if(response.data.errorCode !== undefined){
								CommonServices.showAlert(response.data.errorMessage);
							} else {
								if(response.data.quotes.length === 0){
									/*$scope.managePolicyObj.detailsFlag = false;
									if(response.data.message === "No record found"){*/
										CommonServices.showAlert("No Data found. Please enter valid Quote/Policy number.");
									/*}
									else{
										CommonServices.showAlert(response.data.message);
									}*/
								}
								else{									
									
									
									
									if(response.data.quotes.length===1)
										{
										$rootScope.directPolicyFlag = true;
										$rootScope.policyDetails = response.data.quotes[0];
										//$rootScope.policyDetails.partyDetailsList[0].individualDetails.emailId="abc@mail.com";
										$scope.fetchDocument();
										$state.go("renewalNoticesPolicyDetail");
										}
									else
										{
										
										$rootScope.directPolicyFlag = false;
										var policyList=response.data.quotes;
										for(var i=0; i< policyList.length; i++){
											policyList[i].count = (i<9?"0":"")+(i+1);
										}
										$rootScope.items =policyList;
										$state.go("renewalNoticesPolicyList");
										}
									//$scope.managePolicyObj.policyDetails = response.data.quotes[0];
									//CommonServices.managePolicyDetailsData = response.data.quotes[0];
									
								}
								//$rootScope.productName = $scope.managePolicyObj.policyDetails.productCode;								
							}
								
						},
						function(error) { // failure
							CommonServices.showLoading(false);
							RestServices.handleWebServiceError(error);
					});
				},
				policyChange: function(){
					var data = $("#quotePolicyNum").val();
					if(data.toString().length === 16){
						$scope.singleSelect = "quotes";
						$scope.searchType = "search";
					}
					else if(data.toString().length === 20){
						$scope.singleSelect = "policies";
						$scope.searchType = "search";
					}
					else{
						$scope.singleSelect = "";
						$scope.searchType = "bulkSearch";
					}
				}
			}
			
			$scope.pendingList = function(list){
				var listSelected = list.$index; 
					$rootScope.policyDetails = $rootScope.items[listSelected];
					$scope.fetchDocument();
					$state.go("renewalNoticesPolicyDetail");
			}
			
			$scope.fetchDocument = function(){
		    	//Fetch Document Service Call
	            var fetchDocumentInput = {
	            		"userProfile": {
							"userId": CommonServices.getCommonData("userId"),
							"loggedInRole": CommonServices.getCommonData("loggedInRole"),
							"searchQuote": {
								"productCode": null,
								"productName": null,
								
								"startDate": null,
								"endDate": null,
								"status": null,
								"resultSize": 5,
								"startIndex": 1,
								"totalResults": 0
							}
								
						}
					,"quote":{"policyNumber":$rootScope.policyDetails.policyNumber}
	                } ;

	            var fetchDocResponse = RestServices.postService(RestServices.urlPathsNewPortal.getrenewalNoticDoc, fetchDocumentInput);
	            //var fetchDocResponse = RestServices.postService("renewalNoticDoc", fetchDocumentInput);
	            fetchDocResponse.then(
	                function(response) { // success
						CommonServices.showLoading(false);
						if(angular.isDefined(response.data)){
							//if(response.data.docList != undefined){
							if(angular.isDefined(response.data.docList)){
								if(response.data.docList[0].vDocIndex!=undefined)
	                    		{
		                    	$rootScope.policyDetails.documentDeatils = response.data.docList;
		                    	$rootScope.docFlag = false;
	                    		}
	                    	else
	                    		{
									if(response.data.errorMessage !== undefined){
									$rootScope.documentmessage = response.data.errorMessage;
								   // $scope.documentFlag = true;
	                    		$rootScope.docFlag = true;
	                    		}
									}
	                    	
	                    }
	                    else{
								$rootScope.policyDetails.docMsg = "Document not present";
	                        	$rootScope.docFlag = true;
	                        }
					}else{
					    $rootScope.policyDetails.docMsg = "Document not present";
									$rootScope.docFlag = true;
	                    }

	                },
	                function(error) { // failure
	                    CommonServices.showLoading(false);
	                    RestServices.handleWebServiceError(error);
	            });
		}
			
		//////fetchDoc	
			$scope.fetchDoc = function(url, docName) {
			      try {
			             window.appRootDirName = "NIAAgentDoc";
			             window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, CommonServices.gotFS, CommonServices.fail);

			            var fileTransfer = new FileTransfer();
			            var url = url;
			            var filePath;
			            var docName = docName;


			            if(navigator.userAgent.match(/iPhone|iPad|iPod/i)){
			               filePath = window.appRootDir.nativeURL +docName;
			            }
			            else if(navigator.userAgent.match(/Android/i)){

			               filePath = fileSystem.root.toURL() + "NIAAgentDoc/" + docName;
			            }
			            else{
			               filePath = false;
			            }
			            CommonServices.showLoading(false);

							fileTransfer.download(url, filePath, function(theFile) {
			                    if(navigator.userAgent.match(/iPhone|iPad|iPod/i)){
			                     window.open(url , '_system', 'location=no');
			                    }
			                    else if(navigator.userAgent.match(/Android/i)){
								window.open(filePath , '_system', 'location=no');
								}
							},
			                function(error) {

			                     CommonServices.showAlert("Download not successful, please try again after some time");
			                     CommonServices.showLoading(false);
			                },
			                true
			            );

					} catch (err) {

						$scope.counter = false;
						CommonServices.showLoading(false);
						CommonServices.showAlert("No Documents found");//CR_0675 msg change
					} finally {

					}
				};
		/////end
				
				$scope.mailWithWindowOpen = function () {
					var mailTo= "mailto:"+$rootScope.policyDetails.partyDetailsList[0].individualDetails.emailId;
				  $window.open(mailTo, '_self');
					
				    }

}]);
