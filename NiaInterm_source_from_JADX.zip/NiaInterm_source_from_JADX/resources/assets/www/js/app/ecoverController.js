
/*
 * Ecover Controller
 */
agentApp.controller('EcoverCtrl',  ['$scope', 'RestServices', 'CommonServices', '$location', '$window', function($scope, RestServices, CommonServices, $location, $window) {
	
	$scope.radioCash = false;
	$scope.radioCheque = false;
	$scope.collectionMessage = false;
    
    $scope.$window = $window;
    var mydateStr = CommonServices.getCommonData("serverDate");
    var mynewdateFrom = new Date(mydateStr);

    var dFrom = mynewdateFrom;
    var dayFrom = dFrom.getDate();
    var monthFrom = dFrom.getMonth() + 1;
    var yearFrom = dFrom.getFullYear();
    var yearTo = dFrom.getFullYear() + 12;

    if (dayFrom < 10) {
        dayFrom = "0" + dayFrom;
    }

    if (monthFrom < 10) {
        monthFrom = "0" + monthFrom;
    }
    var enableCalendarfrom = monthFrom + "/" + dayFrom + "/" + yearFrom;
    var enableCalendarTo = monthFrom + "/" + dayFrom + "/" + yearTo;
    
    $('#cal-date').loadCalendar({
        'enableDateRange': true,
        'enableCalendarFrom': enableCalendarfrom,
        'enableCalendarTo': enableCalendarTo
    });
	
	$scope.calIconClick= function(event)
	{
		angular.element("#"+ event.currentTarget.children[0].id).focus();
		
	};
	var agentStakeCode = CommonServices.getCommonData("stakeCode").toUpperCase();
	var agentUserCode = CommonServices.getCommonData("userCode").toUpperCase();

	var modes = CommonServices.getCommonData("disableCollectionMob");
			
	if(agentStakeCode.indexOf("DEALER") > -1) {
		$scope.radioCash = false;
	} 
	
		for(var i=0; i<modes.length; i++) {
			if(modes[i].code === "CSH") {
				$scope.radioCash = true;
			} else if(modes[i].code === "CHQ") {
				$scope.radioCheque = true;
			}	
		}
		if($scope.radioCheque == false && $scope.radioCash == false) {
			$scope.collectionMessage = true;
		}
	
		
		$scope.showBankList = false;
		$scope.bankNameLabel = 'Drawee Bank Name';
		
		$scope.date = new Date();
		var collectionMode;
		var bankName = '';
		var selectedMode = null;
		var bankCode = '';
		var chequeNo = '';
		
	$scope.home = function() {
		$location.path('/home');
    };	
		
	//LogOut Start
    $scope.logOut = function() {
			  RestServices.logOut();
    };
    //LogOut End

		$scope.generateScroll = function() {
			if(selectedMode  !== null ) {
				if(($scope.vehReg1 == "" && $scope.vehReg4 == "") || ($scope.vehReg1 == undefined && $scope.vehReg4 == undefined) ||
				(vehicleNum1 == true && vehicleNum4 == true)){
					if(selectedMode == "cheque" && $scope.bankNameLabel == 'Drawee Bank Name') {
					$scope.bankNameError = true;
				} else {
					//if collection mode is cash then set bankName, bankCode and chequeNo to empty
					if(selectedMode == "cash"){
						bankName = '';
						bankCode = '';
						chequeNo = '';
					} else if(selectedMode == "cheque") {
						chequeNo = $scope.chequeNo;	
					}
					$scope.bankNameError = false;
					var reg1 = "";
					var reg2 = "";
					var reg3 = "";
					var reg4 = "";
					
					if($scope.vehReg1 !== undefined && $scope.vehReg1 !== "") {
						reg1 = $scope.vehReg1.toUpperCase();
					}
					if($scope.vehReg4 !== undefined && $scope.vehReg4 !== "") {
						reg4 = $scope.vehReg4;
					} 
					if($scope.vehReg2 !== undefined && $scope.vehReg2 !== "") {
						if(reg1 !== "" || reg4 !== ""){
							reg2 = $scope.vehReg1.toUpperCase();
						} 
					}
					if($scope.vehReg3 !== undefined && $scope.vehReg3 !== "") {
						if(reg1 !== "" || reg4 !== ""){
							reg3 = $scope.vehReg3.toUpperCase();
						} 
					}
					
					
					var ecoverData= {
						"userCode":agentUserCode,
						"firstName":$scope.fName,
						"lastName":$scope.lName,
						"regNo1":reg1,
						"regNo2":reg2,
						"regNo3":reg3,
						"regNo4":reg4,
						"engineNo":$scope.engineNo,
						"premiumAmount":$scope.premiumAmt,
						"coverNoteSerialNo":$scope.ecoverNo,
						"chassisNo":$scope.chasisNo,
						"dateOfRiskInception":$scope.dateOfRisk,
						"collectionMode":collectionMode,
						"draweeBankName":bankName,
						"draweeBankCode":bankCode,
						"chequeNo":chequeNo
					};
					//web service call for ecover
					
					var ecoverResponse= RestServices.postService(RestServices.urlPathsNewPortal.eCover, ecoverData);
					var pRetErr;
					ecoverResponse.then(    
					function(response) {	// success 
						CommonServices.showLoading(false);
						pRetErr = response.data.pRetErr;
						if(pRetErr == "No Error") {
							CommonServices.showAlert("Token No. "+response.data.pTokenNo+" has been successfully generated for the cover note "+response.data.coverNoteSerialNo);
						} else {
							CommonServices.showAlert("Could not connect to the server.\nPlease check after sometime");
						}
					},
					function(error) {    // failure 
					  RestServices.handleWebServiceError(error);
					  CommonServices.showLoading(false);
				  });
				}
				} else {
					if($scope.vehReg1 != "" && $scope.vehReg4 == undefined) {
						$scope.vehNoError = true;
						$scope.vehicleErrorMsg = "Please enter vehicle Reg4";
					} else if($scope.vehReg1 == undefined && $scope.vehReg4 != "") {
						$scope.vehNoError = true;
						$scope.vehicleErrorMsg = "Please enter vehicle Reg1";
					}
				}
				
			} 		
		};
		 
		//Bank name
		$scope.hideModal = function(){
			$scope.showModal = false;
		};
		
        $scope.showModal = false;
		$scope.searchBank = function() {
			$scope.showModal = !$scope.showModal;
			$scope.bankSearchError = false;
			$scope.bankSearch = null;
			$scope.list = null;
		};
    
        function closeSearchWhenClickingElsewhere(event, callbackOnClose) {
      
            var clickedElement = event.target;
            if (!clickedElement) 
				return;

            var elementClasses = clickedElement.classList;
            var clickedOnSearchDrawer = elementClasses.contains('ecoverModel');
            if (!clickedOnSearchDrawer) {
                callbackOnClose();
                return;
            }

		}
		
		//Close bank modal
		$scope.closeBankModal = function(){
			$scope.showModal = false;
		};

		//cash/cheque mode selection
		 $scope.radioVal = function(){	 
			selectedMode = $scope.premiumAmtMode;
			if(selectedMode == "cheque") {
				$scope.bankNameLabel = 'Drawee Bank Name';
				collectionMode = "CHQ-Y";
				$scope.chequeNo = '';
				$scope.chequeDetails = true;
				$scope.bankNameError = false;
			} else{
				collectionMode = "CSH";
				angular.element(document.querySelector("#bankName")).attr('required', false);
				$scope.chequeDetails = false;
			}			
		 };
 
		 $scope.search = function() {

			 if($scope.bankSearch == null || $scope.bankSearch == undefined) //bank search text empty
			 {
				 $scope.list = [];
				$scope.bankSearchError = true;				
									
			 } else { // bank serach text not empty
							
				 var bankSearchData= JSON.stringify({
					"bankName":$scope.bankSearch.toUpperCase()
				 });
				var bankSearchResponse= RestServices.postService(RestServices.urlPathsNewPortal.getBankDetails, bankSearchData);
				//web service call for bank search
				bankSearchResponse.then(    
				function(response) {	// success 
					CommonServices.showLoading(false);
					$scope.bankSearchError = false;	
					$scope.showBankList = true;
					$scope.list = response.data.bankDataList;	
				},
				function(error) {    // failure 
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
				});
				
			}		 
		};
		//bank name selected 
		$scope.selectedBank = function(item) {
			$scope.showModal = false;
			$scope.bankNameLabel = item.bankName;
			bankName = item.bankName;
			bankCode = item.bankCode;
			$scope.bankNameError = false;
		};

        $scope.vehReg1Length = function() {
			if($scope.vehReg1 !== undefined) {
				if($scope.vehReg1.length >= 3) {
				  $scope.vehReg2 ="";
				  $scope.vehReg3 ="";
				  return false;
				}
			}
            
		};
		
		$scope.bankKeyPress = function(data){
			if($scope.bankSearch.length > 0)
			{
				$scope.bankSearchError = false;
			}
		};
		
		var regx = /^[a-zA-Z0-9]*$/;
		var regxAlpha = /^[a-zA-Z]*$/;
		var regxNum = /^[0-9]*$/;
		var onBlur = true;
		var veh1 = true;
		var veh2 = true;
		var veh3 = true;
		var vehicle4 = true;
		var veh4 = 0;
		var vehicleNum1 = true;
		var vehicleNum4 = true;
				
		$scope.checkValidation = function($event) {
			if(event.type == "blur") {
				onBlur = true;
			} else {
				onBlur = false;
			}
				
			if(event.currentTarget.id == "vehReg") {
				if($scope.vehReg1 == "" || $scope.vehReg1 == undefined) {
					vehicleNum1 = false;
					 validateErrorForVeh1();
									
				} else {
					vehicleNum1 = true;
					veh1 = validateVehReg1();
				}
			} else if(event.currentTarget.id == "vehReg2") {
				if($scope.vehReg2 == "" || $scope.vehReg2 == undefined) {
					 validateErrorForVeh2();
					
				} else {
					veh2 = validateVehReg2();

				}
			} else if(event.currentTarget.id == "vehReg3") {
				if($scope.vehReg3 == "" || $scope.vehReg3 == undefined) {
					 validateErrorForVeh3();
					
				} else {
					veh3 = validateVehReg3();
					
				}
			}  else if(event.currentTarget.id == "vehReg4") {
				if($scope.vehReg4 == "" || $scope.vehReg4 == undefined) {
					vehicleNum4 = false;
					 validateErrorForVeh4();
				} else {
					vehicleNum4 = true;
					vehicle4 = validateVehReg4(event.currentTarget.value);
				}
			}
	}
	
	var stateCodeValid = true;
	
	function validateVehReg1() {
		if($scope.vehReg1 == "" || $scope.vehReg1 == undefined) {
			validateErrorForVeh1();
			return true;
		} else {
			if(regxAlpha.test($scope.vehReg1) == false) {
				veh1 = false;
				$scope.vehNoError = true;
				$scope.vehicleErrorMsg = "Special characters and numbers are not allowed in Reg1";
				return false;
			} else if(onBlur) {
			
				var reg1 = $scope.vehReg1;
				if(reg1 == undefined || reg1 == "") {
					validateErrorForVeh1();
					return true;
					
				} else {
					var statecode = reg1.substring(0, 2).toUpperCase();
					var stateCodeNewPortalData = {
						"header" : null,
						"stateCode" : statecode
					};
					var stateCodeResponse = RestServices.postService(RestServices.urlPathsNewPortal.stateCode , stateCodeNewPortalData);
					stateCodeResponse.then(
						function(response) { // success
							CommonServices.showLoading(false);
							if(response.data.footer.errorDescription !== undefined) {
								veh1 = false;
								$scope.vehNoError = true;
								$scope.vehicleErrorMsg = "Please enter valid State Code in Reg1";
								stateCodeValid = false;
								$scope.invalidValue = true;
								angular.element(document.querySelector("#scrollBtn")).addClass("disableBtn");
								return false;
							} else if(response.data.footer.status !== undefined) {
								validateErrorForVeh1();
								return true;
							}
						},
						function(error) { // failure 
							CommonServices.showLoading(false);
							RestServices.handleWebServiceError(error);
							veh1 = false;
							$scope.vehNoError = true;
							$scope.vehicleErrorMsg = "Special characters and numbers are not allowed in Reg1";
							if(stateCodeValid == false) {
								$scope.vehicleErrorMsg = "Please enter valid State Code in Reg1";
							}
							$scope.invalidValue = true;
							angular.element(document.querySelector("#scrollBtn")).addClass("disableBtn");
							return false;
						});
				} 
			}else {
				if(stateCodeValid == false) {
					$scope.vehNoError = true;
					$scope.vehicleErrorMsg = "Please enter valid State Code in Reg1";
					$scope.invalidValue = true;
					angular.element(document.querySelector("#scrollBtn")).addClass("disableBtn");
					return false;
				} else {
					validateErrorForVeh1();
					return true;
				}
					
			}
		}
	}
	
	function validateErrorForVeh1() {
		veh1 = true;
		if(veh2 == false){
			$scope.vehNoError = true;
			$scope.vehicleErrorMsg = "Special characters are not allowed in Reg2";
			$scope.invalidValue = true;
			angular.element(document.querySelector("#scrollBtn")).addClass("disableBtn");
		} else if(veh3 == false ) {
			$scope.vehNoError = true;
			$scope.vehicleErrorMsg = "Special characters are not allowed in Reg3";
			$scope.invalidValue = true;
			angular.element(document.querySelector("#scrollBtn")).addClass("disableBtn");
		} else if((vehicle4 == false || $scope.vehReg4 == "" || $scope.vehReg4 == undefined) && ($scope.vehReg1 !== "" && $scope.vehReg1 !== undefined)) {
			$scope.vehNoError = true;
			$scope.vehicleErrorMsg = "Please enter 4 digit number in Reg4";
			$scope.invalidValue = true;
			angular.element(document.querySelector("#scrollBtn")).addClass("disableBtn");
		} else {
			$scope.vehNoError = false;
			stateCodeValid = true;
			$scope.invalidValue = false;
			angular.element(document.querySelector("#scrollBtn")).removeClass("disableBtn");
		} 
	}
	
	
	function validateVehReg2() {
		if($scope.vehReg2 == "" || $scope.vehReg2 == undefined) {
			validateErrorForVeh2();
			return true;
		} else {
			if(regx.test($scope.vehReg2) == false) {
				
				veh2 = false;
				$scope.vehNoError = true;
				$scope.vehicleErrorMsg = "Special characters are not allowed in Reg2";
				$scope.invalidValue = true;
				angular.element(document.querySelector("#scrollBtn")).addClass("disableBtn");
				return false;
			} else {
				validateErrorForVeh2();
				return true;
			}
		}  
	}
	
	function validateErrorForVeh2() {
		veh2 = true;
		if(veh1 == false){
			$scope.vehNoError = true;
			$scope.vehicleErrorMsg = "Special characters and numbers are not allowed in Reg1";
			if(stateCodeValid == false) {
				$scope.vehicleErrorMsg = "Please enter valid State Code in Reg1";
			}
			$scope.invalidValue = true;
			angular.element(document.querySelector("#scrollBtn")).addClass("disableBtn");
		} else if(veh3 == false ) {
			$scope.vehNoError = true;
			$scope.vehicleErrorMsg = "Special characters are not allowed in Reg3";
			$scope.invalidValue = true;
			angular.element(document.querySelector("#scrollBtn")).addClass("disableBtn");
		} else if(vehicle4 == false ) {
			$scope.vehNoError = true;
			$scope.vehicleErrorMsg = "Please enter 4 digit number in Reg4";
			$scope.invalidValue = true;
			angular.element(document.querySelector("#scrollBtn")).addClass("disableBtn");
		} else {
			$scope.vehNoError = false;
			$scope.invalidValue = false;
			angular.element(document.querySelector("#scrollBtn")).removeClass("disableBtn");
		} 
	}

	function validateVehReg3() {
		if($scope.vehReg3 == "" || $scope.vehReg3 == undefined) {
			validateErrorForVeh3();
			return true;
		} else {
			if(regx.test($scope.vehReg3) == false) {
				veh3 = false;
				$scope.vehNoError = true;
				$scope.vehicleErrorMsg = "Special characters are not allowed in Reg3";
				$scope.invalidValue = true;
				angular.element(document.querySelector("#scrollBtn")).addClass("disableBtn");
				return false;
			} else {
				validateErrorForVeh3();
				return true;
			}  
		}
	}
	
	function validateErrorForVeh3() {
		veh3 = true;
		if(veh1 == false){
			$scope.vehNoError = true;
			$scope.vehicleErrorMsg = "Special characters and numbers are not allowed in Reg1";
			if(stateCodeValid == false) {
				$scope.vehicleErrorMsg = "Please enter valid State Code in Reg1";
			}
			$scope.invalidValue = true;
			angular.element(document.querySelector("#scrollBtn")).addClass("disableBtn");
		} else if(veh2 == false ) {
			$scope.vehNoError = true;
			$scope.vehicleErrorMsg = "Special characters are not allowed in Reg2";
			$scope.invalidValue = true;
			angular.element(document.querySelector("#scrollBtn")).addClass("disableBtn");
		} else if(vehicle4 == false ) {
			$scope.vehNoError = true;
			$scope.vehicleErrorMsg = "Please enter 4 digit number in Reg4";
			$scope.invalidValue = true;
			angular.element(document.querySelector("#scrollBtn")).addClass("disableBtn");
		} else {
			$scope.vehNoError = false;
			$scope.invalidValue = false;
			angular.element(document.querySelector("#scrollBtn")).removeClass("disableBtn");
		} 
	}
	
	function validateVehReg4(vehReg4Value) {
		veh4 = vehReg4Value;
		if($scope.vehReg4 == "" || $scope.vehReg4 == undefined) {
			validateErrorForVeh4();
			return true;
		} else {
			if(regxNum.test($scope.vehReg4) == false || veh4.toString().length < 4) {
				vehicle4 = false;
				$scope.vehNoError = true;
				$scope.vehicleErrorMsg = "Please enter 4 digit number in Reg4";
				$scope.invalidValue = true;
				angular.element(document.querySelector("#scrollBtn")).addClass("disableBtn");
				return false;
			} else {
				validateErrorForVeh4();
				return true;
			} 
		}
	}

	function validateErrorForVeh4() {
		vehicle4 = true;
		if(veh1 === false || ($scope.vehReg4 !== "" && $scope.vehReg4 !== undefined )) {
			veh4 = $scope.vehReg4;
			if(veh4.toString().length === 4 && ($scope.vehReg1 == "" || $scope.vehReg1 == undefined)) {
				$scope.vehNoError = true;
				$scope.vehicleErrorMsg = "Please enter valid State Code in Reg1";
				$scope.invalidValue = true;
				angular.element(document.querySelector("#scrollBtn")).addClass("disableBtn");
			} else {
				$scope.vehNoError = false;
				$scope.invalidValue = false;
				angular.element(document.querySelector("#scrollBtn")).removeClass("disableBtn");
			}
		} else if(veh2 === false ) {
			$scope.vehNoError = true;
			$scope.vehicleErrorMsg = "Special characters are not allowed in Reg2";
			$scope.invalidValue = true;
			angular.element(document.querySelector("#scrollBtn")).addClass("disableBtn");
		} else if(veh3 === false ) {
			$scope.vehNoError = true;
			$scope.vehicleErrorMsg = "Special characters are not allowed in Reg3";
			$scope.invalidValue = true;
			angular.element(document.querySelector("#scrollBtn")).addClass("disableBtn");
		} else {
			$scope.vehNoError = false;
			$scope.invalidValue = false;
			angular.element(document.querySelector("#scrollBtn")).removeClass("disableBtn");
		} 
	}
	
	$scope.disableButton = function() {
		var disableScroll = false;
		if($scope.vehReg1 !== "") {
			if(regxAlpha.test($scope.vehReg1) == false) {
				 disableScroll = true;
			} else {
				 disableScroll = false;
			}
		}
		if($scope.vehReg2 !== "") {
			if(regx.test($scope.vehReg2) == false) {
				 disableScroll = true;
			} else {
				 disableScroll = false;
			}
		}
		
		if($scope.vehReg3 !== "") {
			if(regx.test($scope.vehReg3) == false) {
				 disableScroll = true;
			} else {
				 disableScroll = false;
			}
		}
		
		if($scope.vehReg4 !== "") {
			if(regxNum.test($scope.vehReg3) == false) {
				 disableScroll = true;
			} else {
				 disableScroll = false;
			}
		}
		if( disableScroll) {
			$scope.invalidValue = false;
			angular.element(document.querySelector("#scrollBtn")).addClass("disableBtn");
		} else {
			$scope.invalidValue = false;
			angular.element(document.querySelector("#scrollBtn")).removeClass("disableBtn");
		}
	}			
}]);
