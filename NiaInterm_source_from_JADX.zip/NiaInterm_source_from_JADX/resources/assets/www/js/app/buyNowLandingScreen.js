agentApp.controller('buyNowLandingCntrl', ['$scope','RestServices','CommonServices','$state', function ($scope, RestServices,CommonServices,$state) {
			
			$scope.bodyHeight = window.innerHeight+'px';
			$scope.stakevalue = CommonServices.getCommonData("stakeCode"); 
			$scope.goBack = function(){
				$state.go('home');
			}
			
			$scope.motorNewProducts = function(){
				CommonServices.setCommonData("selectedProduct",'motor');
				$state.go('buyNowSubLandingScreen');
			}

			$scope.healthNewProducts = function(){
				CommonServices.setCommonData("selectedProduct",'health');
				$state.go('buyNowSubLandingScreen');
			}

			$scope.overseasNewProducts = function(){
				CommonServices.setCommonData("selectedProduct",'overseas');
				$state.go('buyNowSubLandingScreen');
			}

			$scope.miscellaneousNewProducts = function(){
				CommonServices.setCommonData("selectedProduct",'miscellaneous');
				$state.go('buyNowSubLandingScreen');
			}

			//UC for 3749
			// if(CommonServices.gstIdStateCode.length == 0){
			// 	CommonServices.getStateDomainValues();}
}]);

agentApp.controller('buyNowSubLandingScreenCtrl', ['$scope','RestServices','CommonServices','$state','$rootScope', function ($scope, RestServices,CommonServices,$state,$rootScope) {
	CommonServices.floaterObj={};CommonServices.policyDetailsObj={};
	CommonServices.editQuoteHistory = false;
		if(CommonServices.getCommonData("stakeCode") === 'AGENT')
		{
			$scope.agentOnly = true;
		}
		else
		{
			$scope.agentOnly = false;
		}
	
	$scope.selectedProduct = CommonServices.getCommonData("selectedProduct");
	CommonServices.editQuoteFlag = false;
	$rootScope.prodMenuOpen = false;
	$rootScope.prodDiscOpen = false;
	$scope.stakeCode = CommonServices.getCommonData("stakeCode");
		
	$scope.goBack= function(){
		$state.go('buyNowLandingScreen');
	}
	
	$scope.buyNowTwoWheeler = function(){
		$rootScope.productName = "TW"; /* CR_NP_779 */
		$state.go('quickQuoteTW');
	}
	/*start CR3439*/
	$scope.buyNowStandaloneCPAProduct = function(){
		$state.go('standaloneCPAProduct');
	}
	/*end CR3439*/
	/*start CR_3621*/
	$scope.buyNowStandaloneODMotorTW = function(){
		$rootScope.productName = "SQ";
		$state.go('StandaloneODMotorTW');
	}
	/*end CR_3621*/
	$scope.buyNowPersonalAccident = function(){
		$rootScope.productName ="PU"; /* CR_NP_779 */
		$rootScope.resetData = true;
		$state.go('personalAccident');
	}
	$scope.buyNowBusinessAndHoliday = function(){
		//CR655A Start
		$rootScope.prodMenuOpen = true;
		$rootScope.productName = "BH";
		$rootScope.productHeader="Business & Holidays";
		$rootScope.productMsg="Has any person suffering from pre-existing illness / disease / disability and/or had met with an accident during any time in the past?"
		//CR655A End
	}
    /********** CR37A Starts ********/
	$scope.buyNowGrihaSuvidha = function(){
	    $rootScope.productName = "GS"; /* CR_NP_779 */
		$state.go('gsLandingScreen');
	}
	/********** CR37A ends ********/

		/********** CR_3547 Starts ********/
		$scope.buyNowRaastaAapattiKavachPolicy = function(){
			$rootScope.productName = "RK"; /* CR_3547  */
			$state.go('rakPremiumCalculator');
		}
		/********** CR_3547 ends ********/

    /********** CR_41 and 52New india top up mediclaim starts ********/
    $scope.buyNowTopUpMediclaim = function(data){
        
         CommonServices.topUpObj.fromProdcutList =undefined; 
        
        if(data === 'TU'){
             $rootScope.headerName="New India Top Up Mediclaim";
             $rootScope.productName ="TU";
             $rootScope.productMsg ="Has any person to be insured been suffering / diagnosed / under treatment for any Pre Existing Disease or Adverse Medical History?";
             CommonServices.topUpObj ={};
             CommonServices.newIndiaPremierMediclaim ={};
             $state.go("topUpMediclaimLandingScreen");
        }
     // satrt CR_0044
        else if(data === 'UK'){
        	$rootScope.headerName="New India Mediclaim";
            $rootScope.productName ="UK";
            $rootScope.productMsg ="Has any person to be insured been suffering / diagnosed / under any treatment for any Hypertension / diabetes / critical illness / Adverse Medical History / chronic illness / recurring illness/ Psychiatric and Psychosomatic Disorder during any time in past ?";
            CommonServices.topUpObj ={};
            CommonServices.newIndiaPremierMediclaim ={};
            $state.go("topUpMediclaimLandingScreen");
		} // end CR_0044
		// satrt CR_3725
		else if(data === 'CJ'){
        	$rootScope.headerName="NEW INDIA CANCER GUARD POLICY";
            $rootScope.productName ='CJ';
            $rootScope.productMsg ="Do any of the proposed member hold New India Cancer Guard policy?";
            CommonServices.topUpObj ={};
            CommonServices.newIndiaPremierMediclaim ={};
			//$state.go("topUpMediclaimLandingScreen");
			//New implementation of checkbox CR_3725 Sudip-->
			$state.go("premiumCalculatorCJ");
		} // end CR_3725
		else if(data === 'CZ'){
        	$rootScope.headerName="Corona Kavach Policy";
            $rootScope.productName ='CZ';
            $rootScope.productMsg ="";
            CommonServices.topUpObj ={};
            CommonServices.newIndiaPremierMediclaim ={};
			$state.go("coronaKavachPremiumCalc");
        }  

        else{
            CommonServices.editQuoteFlag = false;
            $rootScope.headerName ="New India Premier Mediclaim Policy";
            $rootScope.productName ="HN";
            $rootScope.productMsg="Has any person to be insured been suffering / diagnosed / under any treatment for any Hypertension / diabetes / critical illness / Adverse Medical History / chronic illness / recurring illness/ Psychiatric and Psychosomatic Disorder during any time in past ?"
             CommonServices.topUpObj ={};
             CommonServices.newIndiaPremierMediclaim ={};
            $state.go("topUpMediclaimLandingScreen");
        }	
		
	};
    /********** CR_41  52New india top up mediclaim ends ********/
	//CR45,44 Start
	$scope.buyNowProduct = function(data){
		CommonServices.buyProduct(data);
		
	}
	//CR45,44 Start
	
	//CR43 and 45 Start
	if(CommonServices.getCommonData("stakeCode") === 'AGENT' || CommonServices.getCommonData("stakeCode") === 'DEVLP-OFF')
	{
		$scope.agentDev = true;
	}
	else
	{
		$scope.agentDev = false;
	}
	//CR43 and 45 End
	//CR44 start
	if(CommonServices.getCommonData("stakeCode") === 'DEVLP-OFF') {
		$scope.devlpOff = true;
	} else {
		$scope.devlpOff = false;
	}
	//CR44 end
	
}]);
