agentApp.controller('toUpMediClaimLandingCtrl', ['$scope', 'RestServices', 'CommonServices', '$timeout', '$state', '$rootScope', function ($scope, RestServices, CommonServices, $timeout, $state, $rootScope) {
    //CommonServices.topUpObj.goToNomineeInfoEdit = "undefined";
    CommonServices.topUpObj.goToNomineeInfoEdit = undefined;
    CommonServices.topUpObj.navigationFrom = undefined;
    CommonServices.topUpObj.enableEditModels = undefined;
    CommonServices.topUpObj.viewBreakUpNavigation = undefined;
    CommonServices.policyHolderType = undefined;
    CommonServices.setCommonData('paPolicyAutopopulatedData', undefined);
    /*Added for CR_NP_0744*/
    $rootScope.policyDetailsObj = {};
    if ($rootScope.productName === "HN") {
        CommonServices.uploadUKFiles = undefined;
    }
    /*CR_NP_0744 ends*/
    $scope.bodyHeight = window.innerHeight + 'px';

    $rootScope.prodDiscOpen = false;
    $scope.toUpToggle = false;

    $scope.goBack = function () {
        if (CommonServices.topUpObj.fromProdcutList === "TUPRODUCTLIST") {
            $state.go("products.productList");
        } else {
            $state.go("buyNowSubLandingScreen");
        }

    };

    $scope.topUptoggleBtn = function () {
        if ($scope.toUpToggle === true) {
            $timeout(function () {
                $rootScope.prodDiscOpen = true;
                if ($rootScope.productName === "TU") {
                    $rootScope.productMsg = "People suffering/diagnosed/under any treatment for Pre existing diseases and/or Adverse Medical History or above age of 50 have to contact nearest New India office for guidance and issuance of the policy";
                }
              /* start CR_0044*/
                else if($rootScope.productName === "UK"){ //CR3738A change age from 50 to 60 years
                    $rootScope.productMsg = " People suffering/diagnosed/under any treatment for Hypertension / diabetes / critical illness / Adverse Medical History / chronic illness / recurring illness/Psychiatric and Psychosomatic Disorder or above age of 60 years cannot take the policy online. They are requested to contact nearest New India office for taking  the cover";
                }   /* END CR_0044*/
                else if($rootScope.productName === 'CJ'){ //CR 3725 - sudip
                     $rootScope.productMsg ="New India Cancer Guard policy can not be issued to the member(s) already having the same policy.";
                }
                else {
                    $rootScope.productMsg = " People suffering/diagnosed/under any treatment for Hypertension / diabetes / critical illness / Adverse Medical History / chronic illness / recurring illness/Psychiatric and Psychosomatic Disorder or above age of 45 years cannot take the policy online. They are requested to contact nearest New India office for taking  the cover";
                }
            }, 700);
        } else {
            $rootScope.prodDiscOpen = false;
        }
    };

    $scope.discMenu = function () {
        $rootScope.prodDiscOpen = false;
        $state.go("buyNowSubLandingScreen");
    };
    $scope.branchLocator = function () {
        $state.go("contactDetails.locator");
    };

    $scope.topUpPremiumCalcScreen = function () {
        if ($rootScope.productName === "TU") {
            $state.go("topUpPremiumCalcScreen");
        }else if ($rootScope.productName === "UK") { //CR_0044
            $state.go("premiumCalculatorUK");//CR_0044
        }//CR_0044 
        else if ($rootScope.productName === 'CJ') { //CR_3725
            $state.go("premiumCalculatorCJ");//CR_3725
        }
        else {
            $state.go("newIndiaPremierMediclaim");
        }
    };

}]);

agentApp.controller('topUpPremiumCalcCtrl', ['$scope', 'RestServices', 'CommonServices', '$state', '$rootScope', '$modal', function ($scope, RestServices, CommonServices, $state, $rootScope, $modal) {

    $scope.goBack = function () {
        CommonServices.topUpObj.SelfDOBPolicyHolder = undefined;
        if (CommonServices.editQuoteFlag === true) {
            $state.go('managePolicies.managePolicies');
        } else {
            CommonServices.topUpObj.fromBasicPremium = false;
            CommonServices.topUpObj.searchBoxEnable = false;
            $state.go("topUpMediclaimLandingScreen");
        }
    };


    //    $scope.spouseThreshErrorShow =false;
    $rootScope.prodDiscOpen = false;
    $scope.addPropserDisable = true;//Added as part of CR747
    $scope.addProposerBtnDisable = true;//Added as part of CR747

    $scope.termsAndCondition = function () {
        $rootScope.enableTermsCondions = true;
        $rootScope.prodDiscOpen = true;
        $rootScope.readTermsAndCondp2 = "I understand that by providing my mobile no and e-mail id through the Online Portal, I agree to being contacted by The New India Assurance Co.Ltd. The New India Assurance Co.Ltd shall protect all such information and it shall not be utilised in any manner that will directly or indirectly result in any harm to me.";
        $rootScope.readTermsAndCondp3 = "I understand and accept that The New India Assurance Co.Ltd reserves the right to determine the eligibility and availability of any product or service.";
        $rootScope.readTermsAndCondp4 = "I understand that premium shown in the Quick Quote is only estimated premium and may be subjected to change during Detailed Quote depending on the Cover selected and other information provided by me. And I also understand that the premium shown on the Online Portal will be subjected to any changes based on the IRDAI regulations from time to time.";
    };

    $scope.closeTermsCondition = function () {
        $rootScope.enableTermsCondions = false;
        $rootScope.prodDiscOpen = false;
    };

    $scope.premiumCalcModels = {
        thresholdLimit: "",
        sumInsured: "",
        proposerthresholdLmt: "",
        proposerSumInsured: "",
        spousethresholdLmt: "",
        spouseSumInsured: "",
        spouseDateOfBith: "",
        proposerDateOfBirth: ""
    };


    var disableAddChildBtn = 0;

    $scope.childrenDetails = [];

    $scope.sumInsuredMsg = true;
    $scope.minNumMsg = true;//Start Added as part of CR747
    $scope.typeOfCoveChange = function () {

        if ($scope.basciDetailsRadio === 'INDIVIDUAL') {
            $scope.sumInsuredMsg = false;
            $scope.sumInsuredMsgScope = 'Sum Insured amount will be Individual Limit for each member in a family.';
            $scope.premiumCalcModels.thresholdLimit = '';
            $scope.premiumCalcModels.sumInsured = '';
            //                    $scope.spouseThreshErrorShow = true;
            //                    $scope.spouseSumErrorShow = true;

            for (var i = 0; i < $scope.childrenDetails.length; i++) {
                $scope.childrenDetails[i].threshChildrenError = false;
                $scope.childrenDetails[i].sumChildrenError = false;
                $scope.childrenDetails[i].childthresholdLmt = '';
                $scope.childrenDetails[i].childSumInsured = '';
                //                            $scope.childrenDetails[i].dependentType = '';

            }
        } else {
            $scope.sumInsuredMsg = false;
            $scope.sumInsuredMsgScope = 'Sum Insured will be single overall limit for entire policy.';
            $scope.spouseThreshErrorShow = false;
            $scope.spouseSumErrorShow = false;
            $scope.premiumCalcModels.spousethresholdLmt = '';
            $scope.premiumCalcModels.spouseSumInsured = '';
            //                    $scope.premiumCalcModels.proposerthresholdLmt ='';
            //                    $scope.premiumCalcModels.proposerSumInsured = '';


            for (var i = 0; i < $scope.childrenDetails.length; i++) {
                $scope.childrenDetails[i].threshChildrenError = false;
                $scope.childrenDetails[i].sumChildrenError = false;
                $scope.childrenDetails[i].childthresholdLmt = '';
                $scope.childrenDetails[i].childSumInsured = '';
                //                            $scope.childrenDetails[i].dependentType = '';

            }

        }
    };
    var sumInsuredIntProposer, sumInsuredIntCustom;
    $scope.basicThresholdChange = function () {
        $scope.premiumCalcModels.sumInsured = '';
        if ($scope.premiumCalcModels.thresholdLimit === '500000') {
            $scope.sumInsuredBasic = [500000, 1000000, 1500000];
        } else {
            $scope.sumInsuredBasic = [700000, 1200000, 1700000, 2200000];

        }

    };

    $scope.proposerThresholdChange = function () {
        $scope.premiumCalcModels.proposerSumInsured = '';
        if ($scope.premiumCalcModels.proposerthresholdLmt === '500000') {
            $scope.sumInsuredProposer = [500000, 1000000, 1500000];
        } else {
            $scope.sumInsuredProposer = [700000, 1200000, 1700000, 2200000];
        }

        if ($scope.premiumCalcModels.spousethresholdLmt !== '') {
            if ($scope.premiumCalcModels.proposerthresholdLmt < $scope.premiumCalcModels.spousethresholdLmt) {
                $scope.spouseThreshErrorShow = true;
                $scope.topUpCalPremiumForm.spousethresholdLmt.$setValidity("spousethresholdLmt", false);
            } else {
                $scope.spouseThreshErrorShow = false;
                //                             $("#spousethresholdLmt").prop('required',false);
                $scope.topUpCalPremiumForm.spousethresholdLmt.$setValidity("spousethresholdLmt", true);
            }
        }

        for (var i = 0; i < $scope.childrenDetails.length; i++) {
            if ($scope.childrenDetails[i].childthresholdLmt !== '') {
                if ($scope.premiumCalcModels.proposerthresholdLmt < $scope.childrenDetails[i].childthresholdLmt) {
                    $scope.childrenDetails[i].threshChildrenError = true;
                    $scope.topUpCalPremiumForm["childthresholdLmt" + i].$setValidity("childThreshold", false);
                } else {
                    $scope.childrenDetails[i].threshChildrenError = false;
                    $scope.topUpCalPremiumForm["childthresholdLmt" + i].$setValidity("childThreshold", false);
                }
            }
        }
    };
    $scope.proposerSumInsuredChange = function () {
        if ($scope.premiumCalcModels.spouseSumInsured !== '') {
            sumInsuredIntProposer = parseInt($scope.premiumCalcModels.proposerSumInsured);
            sumInsuredIntCustom = parseInt($scope.premiumCalcModels.spouseSumInsured);
            if (sumInsuredIntProposer < sumInsuredIntCustom) {
                $scope.spouseSumErrorShow = true;
                $scope.topUpCalPremiumForm.spouseSumInsured.$setValidity("spouseSumInsured", false);
            } else {
                $scope.spouseSumErrorShow = false;
                $scope.topUpCalPremiumForm.spouseSumInsured.$setValidity("spouseSumInsured", true);
            }
        }

        for (var i = 0; i < $scope.childrenDetails.length; i++) {
            if ($scope.childrenDetails[i].childSumInsured !== '') {
                sumInsuredIntProposer = parseInt($scope.premiumCalcModels.proposerSumInsured);
                sumInsuredIntCustom = parseInt($scope.childrenDetails[i].childSumInsured);
                if (sumInsuredIntProposer < sumInsuredIntCustom) {

                    $scope.childrenDetails[i].sumChildrenError = true;

                    $scope.topUpCalPremiumForm["childSumInsured" + i].$setValidity("childSumInsured", false);
                } else {
                    $scope.childrenDetails[i].sumChildrenError = false;
                    $scope.topUpCalPremiumForm["childSumInsured" + i].$setValidity("childSumInsured", true);
                }
            }
        }
    };


    $scope.spouseThresholdChange = function () {
        $scope.premiumCalcModels.spouseSumInsured = '';
        if ($scope.premiumCalcModels.spousethresholdLmt === '500000') {
            $scope.sumInsuredSpouse = [500000, 1000000, 1500000];

        } else {
            $scope.sumInsuredSpouse = [700000, 1200000, 1700000, 2200000];
        }

        if ($scope.premiumCalcModels.proposerthresholdLmt !== '') {
            if ($scope.premiumCalcModels.proposerthresholdLmt < $scope.premiumCalcModels.spousethresholdLmt) {
                $scope.spouseThreshErrorShow = true; $scope.topUpCalPremiumForm.spousethresholdLmt.$setValidity("spousethresholdLmt", false);
            } else {
                $scope.spouseThreshErrorShow = false; $scope.topUpCalPremiumForm.spousethresholdLmt.$setValidity("spousethresholdLmt", true);
            }
        }
    };

    if ($scope.premiumCalcModels.proposerSumInsured !== '') {
        if ($scope.premiumCalcModels.proposerSumInsured < $scope.premiumCalcModels.spouseSumInsured) {
            $scope.spouseSumInsuredShow = true;
        } else {
            $scope.spouseSumInsuredShow = false;
        }
    };

    $scope.spouseSumInsuredChange = function () {
        if ($scope.premiumCalcModels.proposerSumInsured !== '') {

            sumInsuredIntProposer = parseInt($scope.premiumCalcModels.proposerSumInsured);
            sumInsuredIntCustom = parseInt($scope.premiumCalcModels.spouseSumInsured);
            if (sumInsuredIntProposer < sumInsuredIntCustom) {
                $scope.spouseSumErrorShow = true;
                $scope.topUpCalPremiumForm.spouseSumInsured.$setValidity("spouseSumInsured", false);
            } else {
                $scope.spouseSumErrorShow = false;
                $scope.topUpCalPremiumForm.spouseSumInsured.$setValidity("spouseSumInsured", true);
            }
        }
    };
    $scope.childThresholdChange = function (member, $index) {
        for (var i = 0; i < $scope.childrenDetails.length; i++) {

            if (member === i) {
                $scope.childrenDetails[i].childSumInsured = '';
                if ($scope.childrenDetails[i].childthresholdLmt === '500000') {
                    $scope.childrenDetails[i].childrenSumIndDetails = [500000, 1000000, 1500000];
                } else {
                    $scope.childrenDetails[i].childrenSumIndDetails = [700000, 1200000, 1700000, 2200000];
                }
                if ($scope.premiumCalcModels.proposerthresholdLmt !== '') {
                    if ($scope.premiumCalcModels.proposerthresholdLmt < $scope.childrenDetails[i].childthresholdLmt) {
                        $scope.childrenDetails[i].threshChildrenError = true;
                        $scope.topUpCalPremiumForm["childthresholdLmt" + i].$setValidity("childThreshold", false);


                    } else {
                        $scope.childrenDetails[i].threshChildrenError = false;
                        $scope.topUpCalPremiumForm["childthresholdLmt" + i].$setValidity("childThreshold", true);
                    }
                }


            }

        }
    };

    $scope.childSumInsuredChange = function () {

        for (var i = 0; i < $scope.childrenDetails.length; i++) {
            if ($scope.premiumCalcModels.proposerSumInsured !== '') {
                sumInsuredIntProposer = parseInt($scope.premiumCalcModels.proposerSumInsured);
                sumInsuredIntCustom = parseInt($scope.childrenDetails[i].childSumInsured);
                if (sumInsuredIntProposer < sumInsuredIntCustom) {
                    $scope.childrenDetails[i].sumChildrenError = true;
                    $scope.topUpCalPremiumForm["childSumInsured" + i].$setValidity("childSumInsured", false);


                } else {
                    $scope.childrenDetails[i].sumChildrenError = false;
                    $scope.topUpCalPremiumForm["childSumInsured" + i].$setValidity("childSumInsured", true);
                }
            }

        }
    };

    var parentsAgeDiff = [];

    $scope.numberOfmembers = 1;
    //Start Added as part of CR747 addProposerBtnDisable addSpouseBtnDisable
    $scope.addMember = function (member, type=1) { // type1 for addition via button, type 2 for other method.
        $scope.numberOfmembers = $scope.numberOfmembers + 1;
        if ($scope.numberOfmembers > 5) {
            $scope.addProposerBtnDisable = true;
            $scope.addSpouseBtnDisable = true;
            $scope.addChildDisable = true;
            if($scope.numberOfmembers > 6){
                $scope.numberOfmembers--;
                return;
            }
        } 
        if(type === 2 || ($scope.numberOfmembers<7 && type === 1)) {
            if (member === 'Proposer') {
					if(CommonServices.topUpObj.SelfDOBPolicyHolder !== undefined || CommonServices.editQuoteFlag === true){
                    enableProposerDOBCalComp = new Date(TodyasDateFormatToCal);
					//var dt1 = CommonServices.topUpObj.SelfDOBPolicyHolder.split('/');
                        var dt1;
					if(CommonServices.floaterObj.dateOfBirth!==undefined){
						dt1= CommonServices.floaterObj.dateOfBirth.split('/');
					}else{
						dt1 = CommonServices.topUpObj.SelfDOBPolicyHolder.split('/');
					}
					proposerbirthDateComp = dt1[1] + '/' + dt1[0] + '/' + dt1[2], //mm/dd/yyyy
					proposerbirthDateComp = new Date(proposerbirthDateComp);
                    var date = new Date(proposerbirthDateComp);
                    var ageDifMs = Date.now() - date.getTime();
                    var ageProposerYrs = new Date(ageDifMs); // miliseconds from epoch
                    ageProposerYrs = Math.abs(ageProposerYrs.getUTCFullYear() - 1970);
                    ageProposerYrs = ageProposerYrs.toString();
                    if (ageProposerYrs > 50) {
                        $scope.numberOfmembers = ($scope.numberOfmembers < 1) ? 0 : $scope.numberOfmembers - 1;
                        CommonServices.showAlert("Proposer/self 's age(as per policy holder's date of birth) should be between 18-50 years to add into policy online. Please contact nearest NIA branch to add member to the policy.");
                        return;
                    } else {
                        $scope.premiumCalcModels.proposerDateOfBirth = CommonServices.topUpObj.SelfDOBPolicyHolder;
                        $scope.enableProposerDOB = true;
                        CommonServices.showAlert("Proposer/Self DoB is being captured from Policy holder details, if you want to make any change please contact NIA .");
                        if(CommonServices.editQuoteFlag === true){
						$scope.premiumCalcModels.proposerDateOfBirth=CommonServices.floaterObj.dateOfBirth;
					}else{
						$scope.premiumCalcModels.proposerDateOfBirth=CommonServices.topUpObj.SelfDOBPolicyHolder;
					}
                        
					}
                } else {
                    $scope.enableProposerDOB = false;

                }
                if ($scope.addPropserDisable === false) {
                    $scope.addPropserDisable = true;
                }
                $scope.addProposerBtnDisable = true;
                if ($scope.numberOfmembers === 6) {
                    $scope.addSpouseBtnDisable = true;
                    $scope.addChildDisable = true;
                }
            }
            else if (member === 'Spouse') {
                $scope.enableSpouseDOB = false;
                $scope.addSpouseDisable = true;
                $scope.addSpouseBtnDisable = true;
                if ($scope.numberOfmembers === 6) {
                    $scope.addProposerBtnDisable = true;
                    $scope.addChildDisable = true;
                }
            }
            else {
                if ($scope.numberOfmembers > 5) {
                    $scope.addChildDisable = true;
                    $scope.addSpouseBtnDisable = true;
                    $scope.addProposerBtnDisable = true;
                }
                disableAddChildBtn = disableAddChildBtn + 1;
                $scope.childrenDetails.push({ policyHolderRelationShip: "Child" });
            }
        }
        
    };


    $scope.closeMember = function (member, index) {
        $scope.numberOfmembers = $scope.numberOfmembers - 1;
        if ($scope.numberOfmembers > 6) {
            $scope.addProposerBtnDisable = true;
            $scope.addSpouseBtnDisable = true;
            $scope.addChildDisable = true;
        }
            if (member === 'Proposer') {
                if($scope.enableProposerDOB == true){
                    $scope.numberOfmembers++;
                    return;
                }    
                $scope.enableProposerDOB = true;
                $scope.premiumCalcModels.proposerthresholdLmt = '';
                $scope.premiumCalcModels.proposerSumInsured = '';
                $scope.premiumCalcModels.proposerDateOfBirth = '';
                // $scope.addPropserDisable = false;
                // $scope.addProposerBtnDisable = false;
                CommonServices.topUpObj.proposerAgeInYrs = undefined;
                CommonServices.topUpObj.proposerAgeMonths = undefined;
                CommonServices.topUpObj.proposerAgeInDays = undefined;
                if ($scope.numberOfmembers < 6) {
                    $scope.addChildDisable = false;
                    $scope.addProposerBtnDisable = false;
                    $scope.addPropserDisable = false;
                }
					if(disableAddChildBtn === 5 && $scope.numberOfmembers === 5){
						$scope.addSpouseBtnDisable=false;
					}
                    $scope.proposerRiskDetails = undefined;
                    $scope.addedMembersPolicySearchDetails.proposer = undefined;

             
            } else if (member === 'Spouse') {
                if($scope.enableSpouseDOB === undefined || $scope.enableSpouseDOB === true){
                    $scope.numberOfmembers = $scope.numberOfmembers + 1;
                    return;
                }                    
                $scope.premiumCalcModels.spousethresholdLmt = '';
                $scope.premiumCalcModels.spouseSumInsured = '';
                $scope.premiumCalcModels.spouseDateOfBith = '';
                // $scope.addSpouseDisable = false;
                $scope.spouseThreshErrorShow = false;
                $scope.spouseSumErrorShow = false;
                CommonServices.topUpObj.spouseAgeInYrs = undefined;
                CommonServices.topUpObj.spouseAgeInMonths = undefined;
                CommonServices.topUpObj.spouseAgeInDays = undefined;
                if ($scope.numberOfmembers < 6) {
                    $scope.addChildDisable = false;
                    $scope.addSpouseBtnDisable = false;
                    $scope.addSpouseDisable = false;
                }
                if (disableAddChildBtn === 5 && $scope.numberOfmembers === 5) {
                    $scope.addProposerBtnDisable = false;
                }
                 $scope.spouseRiskDetails =undefined;
                 $scope.addedMembersPolicySearchDetails.spouse = undefined;

            } else {
                if ($scope.numberOfmembers < 6) {
                    $scope.addChildDisable = false;
                }

                $scope.childrenDetails.splice(index, 1);
                if(index < $scope.addedMembersPolicySearchDetails.children.length)
                    $scope.addedMembersPolicySearchDetails.children.splice(index, 1);
                disableAddChildBtn = disableAddChildBtn - 1;
                if (disableAddChildBtn <= 5 && $scope.numberOfmembers === 5) {
                    if ($scope.addSpouseDisable === false || $scope.addSpouseDisable===undefined) {
                        $scope.addSpouseBtnDisable = false;
                    }
                    if ($scope.addPropserDisable === false) {
                        $scope.addProposerBtnDisable = false;
                    }


                }

            }
        

    };
    //End Added as part of CR747  




    var mydateStr = new Date();
    var mynewdateFrom = "";
    if (mydateStr != undefined) {
        mynewdateFrom = new Date(mydateStr);
    } else {
        mynewdateFrom = new Date();
    };


    /**Proposer and Spouse date age validations**/

    var enableAgefrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 51));
    var enableAgeTo = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 18));
    enableAgeTo = getFormattedDate(enableAgeTo);

    var TodyasDateFormatToCal = CommonServices.getCommonData("serverDate");

    $scope.proposerDateOfBirtshow = function () {
        $('#proposerDateOfBirth').loadCalendar({
            'enableDateRange': true,
            'enableCalendarFrom': enableAgefrom,
            'enableCalendarTo': TodyasDateFormatToCal
        });
        return true;
    };

    $scope.spouseDateOfBirtshow = function () {
        $("#spouseDateOfBirth").loadCalendar({
            'enableDateRange': true,
            'enableCalendarFrom': enableAgefrom,
            'enableCalendarTo': TodyasDateFormatToCal
        });
        return true;
    };

    //var parentsAgeDiff = [];
    $scope.dateOfBirthProposerSpouse = function (member) {
        var memberDateOfBirth, memberAgeCal;
        if (member === 'proposer') {
            memberDateOfBirth = $scope.premiumCalcModels.proposerDateOfBirth;
            memberAgeCal = $scope.premiumCalcModels.proposerDateOfBirth;
        } else {
            memberDateOfBirth = $scope.premiumCalcModels.spouseDateOfBith;
            memberAgeCal = $scope.premiumCalcModels.spouseDateOfBith;
        }

        var arr = memberDateOfBirth.split('/');
        memberDateOfBirth = arr[1] + '/' + arr[0] + '/' + arr[2]; //mm/dd/yyyy 
        memberDateOfBirth = new Date(memberDateOfBirth);
        var enableToDate = new Date(enableAgeTo);
        if (memberDateOfBirth > enableToDate) {


            //alert("Age should be between 18 - 50 years");
            CommonServices.showAlert("Age should be between 18 - 50 years");

            if (member === 'proposer') {
                $scope.premiumCalcModels.proposerDateOfBirth = '';
            } else {
                $scope.premiumCalcModels.spouseDateOfBith = '';
            }
        } else {
            var now = new Date();
            var today = new Date(now.getYear(), now.getMonth(), now.getDate());

            var yearNow = now.getYear();
            var monthNow = now.getMonth();
            var dateNow = now.getDate();

            var Arr = memberAgeCal.split('/');
            memberAgeCal = Arr[1] + '/' + Arr[0] + '/' + Arr[2]; //mm/dd/yyyy

            var dob = new Date(memberAgeCal.substring(6, 10),
                memberAgeCal.substring(0, 2) - 1,
                memberAgeCal.substring(3, 5));

            var yearDob = dob.getYear();
            var monthDob = dob.getMonth();
            var dateDob = dob.getDate();

            var ageString = "";
            var yearString = "";
            var monthString = "";
            var dayString = "";

            yearAge = yearNow - yearDob;

            if (monthNow >= monthDob)
                var monthAge = monthNow - monthDob;
            else {
                yearAge--;
                var monthAge = 12 + monthNow - monthDob;
            }

            if (dateNow >= dateDob)
                var dateAge = dateNow - dateDob;
            else {
                monthAge--;
                var dateAge = 31 + dateNow - dateDob;

                if (monthAge < 0) {
                    monthAge = 11;
                    yearAge--;
                }
            }

            var YearsDiff, MonthsDiff, DayDiff;
            YearsDiff = yearAge;
            MonthsDiff = monthAge;
            DayDiff = dateAge;






            if (member === 'proposer') {
                CommonServices.topUpObj.proposerAgeInYrs = YearsDiff.toString();
                CommonServices.topUpObj.proposerAgeInMonths = MonthsDiff.toString();
                CommonServices.topUpObj.proposerAgeInDays = DayDiff.toString();
            } else {
                CommonServices.topUpObj.spouseAgeInYrs = YearsDiff.toString();
                CommonServices.topUpObj.spouseAgeInMonths = MonthsDiff.toString();
                CommonServices.topUpObj.spouseAgeInDays = DayDiff.toString();
            }



            if (member === 'proposer') {
                CommonServices.setCommonData("basicProposerDateOfBith", $scope.premiumCalcModels.proposerDateOfBirth);
            }

        }
    };


    /*****************child date of bith validations**********/

    var childAgeEnableFrom, childAgeEnableTo;
    //    childAgeEnableFrom= new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 45));
    childAgeEnableFrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 51));
    childAgeEnableTo = new Date(new Date().setFullYear(mynewdateFrom.getFullYear()));

    $scope.childDateOfBirth = function (index) {
        $("#childrenDateOfBirth_" + index).loadCalendar({
            'enableDateRange': true,
            'enableCalendarFrom': childAgeEnableFrom,
            'enableCalendarTo': childAgeEnableTo
        });
        return true;
    };

    var brr, childDateOfBith;


    $scope.dependentTypeChanged = function () {

        var AgeInMonths = new Date(new Date().setMonth(mynewdateFrom.getMonth() - 3));

        for (var i = 0; i < $scope.childrenDetails.length; i++) {

            var childAge = $scope.childrenDetails[i].childrenDateOfBirth;

            if ($scope.childrenDetails[i].childrenDateOfBirth !== undefined) {

                var arr = childAge.split('/');
                childAge = arr[1] + '/' + arr[0] + '/' + arr[2]; //mm/dd/yyyy 
                childAge = new Date(childAge);
            }

            if ($scope.childrenDetails[i].dependentType === 'NA') {

                //                    $scope.childrenDetails[i].childrenDateOfBirth = '';
                childAgeEnableFrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 18));
                $scope.childDateOfBirth = function (index) {
                    $("#childrenDateOfBirth_" + index).loadCalendar({
                        'enableDateRange': true,
                        'enableCalendarFrom': childAgeEnableFrom,
                        'enableCalendarTo': childAgeEnableTo
                    });
                    return true;
                };

                //                         if(childAge > childAgeEnableFrom){
                //                            $scope.childrenDetails[i].childrenDateOfBirth = '';    
                //                         }

                if (childAge > AgeInMonths || childAge < childAgeEnableFrom) {

                    //alert("Age of child should be between 3 months to 18 years");
                    $scope.childrenDetails[i].childrenDateOfBirth = "";
                    CommonServices.showAlert("Age of child should be between 3 months to 18 years ");
                }

            } else if ($scope.childrenDetails[i].dependentType === 'NORM') {
                //                            $scope.childrenDetails[i].childrenDateOfBirth = '';
                childAgeEnableFrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 25));

                $scope.childDateOfBirth = function (index) {
                    $("#childrenDateOfBirth_" + index).loadCalendar({
                        'enableDateRange': true,
                        'enableCalendarFrom': childAgeEnableFrom,
                        'enableCalendarTo': childAgeEnableTo
                    });
                    return true;
                };

                //                         if(childAge > childAgeEnableFrom){
                //                            $scope.childrenDetails[i].childrenDateOfBirth = "";    
                //                         }

                if (childAge > AgeInMonths || childAge < childAgeEnableFrom) {
                $scope.childrenDetails[i].childrenDateOfBirth = "";
                    //alert("Age of child should be between 3 months to 25 years");
                    CommonServices.showAlert("Age of child should be between 3 months to 25 years ");
                }

            } else {
                if ($scope.childrenDetails[i].dependentType === 'MC' || $scope.childrenDetails[i].dependentType === 'UD') {
                    //                               $scope.childrenDetails[i].childrenDateOfBirth = '';

                    childAgeEnableFrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 51));
                    $scope.childDateOfBirth = function (index) {
                        $("#childrenDateOfBirth_" + index).loadCalendar({
                            'enableDateRange': true,
                            'enableCalendarFrom': childAgeEnableFrom,
                            'enableCalendarTo': childAgeEnableTo
                        });
                        return true;
                    };

                    //                             if(childAge > childAgeEnableFrom){
                    //                                $scope.childrenDetails[i].childrenDateOfBirth = "";    
                    //                            }

                    if (childAge > AgeInMonths || childAge < childAgeEnableFrom) {
                        $scope.childrenDetails[i].childrenDateOfBirth = "";
                        //alert("Age of child should be between 3 months to 50 years");
                        CommonServices.showAlert("Age of child should be between 3 months to 50 years ");
                    }

                } else {
                    $scope.childDateOfBirth = function (index) {
                        $("#childrenDateOfBirth_" + index).loadCalendar({
                            'enableDateRange': true,
                            'enableCalendarFrom': childAgeEnableFrom,
                            'enableCalendarTo': childAgeEnableTo
                        });
                        return true;
                    };
                }

            }

            //};

        }
        /*****************child date of bith validations ends******* parents validations pending******/

    };



    /**********Policy Satart Date and End Date Validations*********/
    var policyStartDate = TodyasDateFormatToCal;
    var arr = policyStartDate.split('/');
    policyStartDate = arr[1] + '/' + arr[0] + '/' + arr[2]; //dd/mm/yyyy

    CommonServices.topUpObj.policyStartDate = policyStartDate;


    var policyEndDate = new Date(mydateStr);
    policyEndDate.setFullYear(policyEndDate.getFullYear() + 1);
    policyEndDate.setDate(policyEndDate.getDate() - 1);
    var dd = policyEndDate.getDate();
    var mm = policyEndDate.getMonth() + 1;
    var yyyy = policyEndDate.getFullYear();

    if (dd < 10) {
        dd = "0" + dd;
    }

    if (mm < 10) {
        mm = "0" + mm;
    }
    policyEndDate = dd + "/" + mm + "/" + yyyy;//policy end date
    CommonServices.topUpObj.policyEndDate = policyEndDate;




    /******* riskDetails validations*********/
    $scope.riskDetails = [];
    $scope.proposerNotCover = [];

    // save Calc premium service call
    $scope.editSaveQuoteRisk = [];

    $scope.topUpSaveCalpremium = function () {
        if($scope.numberOfmembers > 6){
           CommonServices.showAlert("Maximum 6 members allowed!");
            return;
        }
        CommonServices.setCommonData('paPolicyAutopopulatedData', $scope.addedMembersPolicySearchDetails);
        
        if ($scope.basciDetailsRadio === 'FLOATER') {
            CommonServices.topUpObj.policyHolderSelf = {
                "thresholdLimit": "500000",
                "riskSumInsured": "500000",
                "dateOfBirth": "01/01/1985",
                "ageInYrs": "33"
            };
        }
        CommonServices.newIndiaPremierMediclaim.memberCoveredInPolicy = $scope.addPropserDisable;
        CommonServices.topUpObj.numberOfMembers = $scope.numberOfmembers;
        $scope.riskDetails = [];
        $scope.editSaveQuoteRisk = [];
        $scope.proposerNotCover = [];

        if ($scope.sumInsuredMsg === true) {
            //alert("Please select type of cover");
            CommonServices.showAlert("Please select type of cover");
        } else if ($scope.numberOfmembers < 2 && $scope.basciDetailsRadio === 'FLOATER') {
            CommonServices.showAlert("Minimum of 2 members are required to be associated for this policy (including Proposer/Spouse/Child).");
        }
        else {
            if ($scope.numberOfmembers === 0 && $scope.basciDetailsRadio === 'INDIVIDUAL') {
                CommonServices.showAlert("Minimum 1 member is required to be associated for this policy");
            }
            else {
                /*******Calculating suminsured and number of members and adding it to the topUpObj*********/
                var totalSumInsured = 0;
                if ($scope.basciDetailsRadio === 'INDIVIDUAL') {

                    for (var i = 0; i < $scope.childrenDetails.length; i++) {
                        totalSumInsured = totalSumInsured + parseInt($scope.childrenDetails[i].childSumInsured);
                    }
                    if ($scope.premiumCalcModels.spouseSumInsured !== '') {
                        totalSumInsured = totalSumInsured + parseInt($scope.premiumCalcModels.spouseSumInsured);
                    }
                    if (CommonServices.newIndiaPremierMediclaim.memberCoveredInPolicy === true) {
                        totalSumInsured = totalSumInsured + parseInt($scope.premiumCalcModels.proposerSumInsured);
                    }

                    CommonServices.topUpObj.sumInsured = totalSumInsured;

                } else {
                    CommonServices.topUpObj.sumInsured = $scope.premiumCalcModels.sumInsured;

                }
                /*****************Age calculation  in years*************/
                //$scope.proposerDateOfBirth
         if(CommonServices.editQuoteFlag !== true){

                $scope.proposerRiskDetails = {
                    "riskSumInsured": $scope.basciDetailsRadio === 'INDIVIDUAL' ? $scope.premiumCalcModels.proposerSumInsured : $scope.premiumCalcModels.sumInsured,
                    "riskDetails": {
                        "thresholdLimit": $scope.basciDetailsRadio === 'INDIVIDUAL' ? $scope.premiumCalcModels.proposerthresholdLmt : $scope.premiumCalcModels.thresholdLimit,
                        "cityOfResidence": null,
                        "relationWithPolicyHolder": "SELF",
                        "dateOfBirth": $scope.premiumCalcModels.proposerDateOfBirth,
                        "ageInYrs": CommonServices.topUpObj.proposerAgeInYrs
                    }
                };
            }

        if(CommonServices.editQuoteFlag !== true){
                $scope.spouseRiskDetails = {
                    "riskSumInsured": $scope.basciDetailsRadio === 'INDIVIDUAL' ? $scope.premiumCalcModels.spouseSumInsured : "",
                    "riskDetails": {
                        "thresholdLimit": $scope.basciDetailsRadio === 'INDIVIDUAL' ? $scope.premiumCalcModels.spousethresholdLmt : "",
                        "cityOfResidence": null,
                        "relationWithPolicyHolder": "SPOUSE",
                        "dateOfBirth": $scope.premiumCalcModels.spouseDateOfBith,
                        "ageInYrs": CommonServices.topUpObj.spouseAgeInYrs
                }  
                };
        }
                    
                     
					 //Start Added as part of CR747
					 if($scope.addPropserDisable === true){
                         if(CommonServices.editQuoteFlag === true){
                             if($scope.proposerRiskDetails === undefined || CommonServices.floaterObj.policyHolderName === "PORTAL  PORTAL"){
                                 
                                $scope.proposerRiskDetails={
                                    "riskSumInsured": $scope.basciDetailsRadio === 'INDIVIDUAL'?$scope.premiumCalcModels.proposerSumInsured :$scope.premiumCalcModels.sumInsured,
                                    "riskDetails": {
                                        "thresholdLimit":$scope.basciDetailsRadio === 'INDIVIDUAL'? $scope.premiumCalcModels.proposerthresholdLmt:$scope.premiumCalcModels.thresholdLimit,
                                        "cityOfResidence": null,
                                        "relationWithPolicyHolder": "SELF",
                                        "dateOfBirth": $scope.premiumCalcModels.proposerDateOfBirth,
                                        "ageInYrs": CommonServices.topUpObj.proposerAgeInYrs
                                    }
                                };
                                 $scope.riskDetails.push($scope.proposerRiskDetails); 
                             }else{
                                $scope.proposerRiskDetails.riskSumInsured = $scope.basciDetailsRadio === 'INDIVIDUAL'?$scope.premiumCalcModels.proposerSumInsured :$scope.premiumCalcModels.sumInsured;
                                 
                                 $scope.proposerRiskDetails.riskDetails.thresholdLimit = $scope.basciDetailsRadio === 'INDIVIDUAL'? $scope.premiumCalcModels.proposerthresholdLmt:$scope.premiumCalcModels.thresholdLimit;
                                 
                                $scope.riskDetails.push($scope.proposerRiskDetails); 
                             }
                         
                         }else{
                           $scope.riskDetails.push($scope.proposerRiskDetails);  
                         } 
                        
					 } 
                    if(CommonServices.editQuoteFlag === true){
                        
                        if(CommonServices.newIndiaPremierMediclaim.memberCoveredInPolicy === false && CommonServices.floaterObj.typeOfCover !=="INDIVIDUAL"){
                       
                         $scope.proposerNotCover.push({
                        "riskParty":CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk.riskParty,
                          "riskSumInsured": CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk.riskSumInsured,
                          "relationWithPolicyHolder": CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk.riskDetails.relationWithPolicyHolder,
                          "occupation": CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk.riskDetails.occupation,
                          "ifAnyOtherOccupation": CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk.riskDetails.ifAnyOtherOccupation,
                          "dateOfBirth": CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk.riskDetails.dateOfBirth,
                          "nameOfInsuredPerson":  CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk.riskDetails.nameOfInsuredPerson,
                          "ageInYrs": CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk.riskDetails.ageInYrs,
                          "sex": CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk.riskDetails.sex,
                          "doYouChewTobacco": "N",
                          "doYouSmoke": "N",
                          "doYouDrinkAlcohol": "N",
                          "adverseMedicialHistory": "N",
                          "preExistingDisease": "N",
                          "dependent": CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk.riskDetails.dependent,
                          "dependentType": CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk.riskDetails.dependentType,
                          "thresholdLimit":CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk.riskDetails.thresholdLimit,
                          "previousPolicyDetails":CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk.riskDetails.previousPolicyDetails
                          });
                          CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk = $scope.proposerNotCover;
                        }
                    }
                //End Added as part of CR747
                   if($scope.addSpouseDisable === true){
                       if(CommonServices.editQuoteFlag === true){
                             if($scope.spouseRiskDetails === undefined || CommonServices.floaterObj.policyHolderName === "PORTAL  PORTAL"){
                                 
                                $scope.spouseRiskDetails ={
                                "riskSumInsured":$scope.basciDetailsRadio === 'INDIVIDUAL'? $scope.premiumCalcModels.spouseSumInsured:"",
                                "riskDetails": {
                                    "thresholdLimit":$scope.basciDetailsRadio === 'INDIVIDUAL'? $scope.premiumCalcModels.spousethresholdLmt:"",
                                    "cityOfResidence": null,
                                    "relationWithPolicyHolder": "SPOUSE",
                                    "dateOfBirth": $scope.premiumCalcModels.spouseDateOfBith,
                                    "ageInYrs": CommonServices.topUpObj.spouseAgeInYrs
                                 }  
                                };
                                  $scope.riskDetails.push( $scope.spouseRiskDetails);
                             }else{
                                  $scope.spouseRiskDetails.riskSumInsured = $scope.basciDetailsRadio === 'INDIVIDUAL'? $scope.premiumCalcModels.spouseSumInsured:"";
                                 $scope.spouseRiskDetails.riskDetails.thresholdLimit = $scope.basciDetailsRadio === 'INDIVIDUAL'? $scope.premiumCalcModels.spousethresholdLmt:"";
                                 
                                 $scope.riskDetails.push( $scope.spouseRiskDetails);
                             }
                         
                         }else{
                             $scope.riskDetails.push( $scope.spouseRiskDetails);
                         } 

                }

                // CommonServices.topUpObj.numberOfMembers.addedMembers =

                for (var i = 0; i < $scope.childrenDetails.length; i++) {
                    var childAdgeCal = $scope.childrenDetails[i].childrenDateOfBirth;
                    var Arr = childAdgeCal.split('/');
                    childAdgeCal = Arr[2] + '/' + Arr[1] + '/' + Arr[0]; //mm/dd/yyyy
                    var date = new Date(childAdgeCal);
                    var ageDifMs = Date.now() - date.getTime();
                    var ageDinYrs = new Date(ageDifMs); // miliseconds from epoch
                    ageDinYrs = Math.abs(ageDinYrs.getUTCFullYear() - 1970);
                    ageDinYrs = ageDinYrs.toString();

                            if(CommonServices.editQuoteFlag !== true){
                          
                        $scope.childRiskDetails ={
                               "riskSumInsured":$scope.basciDetailsRadio === 'INDIVIDUAL'? $scope.childrenDetails[i].childSumInsured:"",
                                "riskDetails": {
                                  "thresholdLimit":$scope.basciDetailsRadio === 'INDIVIDUAL'? $scope.childrenDetails[i].childthresholdLmt:"",
                                  "cityOfResidence": null,
                                  "relationWithPolicyHolder": "CHILDREN",
                                  "dateOfBirth": $scope.childrenDetails[i].childrenDateOfBirth,
                                  "ageInYrs": ageDinYrs,
                                   "dependent":$scope.childrenDetails[i].dependentType === "NA"?"N":"Y",
                                   "dependentType":$scope.childrenDetails[i].dependentType
          
                                }  
                            }; 
                            $scope.riskDetails.push($scope.childRiskDetails);
                        }

                     }
        /************TU EditQuote starts************/
             for(var i =0; i< $scope.childrenDetails.length; i++){
                 if(CommonServices.editQuoteFlag === true && CommonServices.floaterObj.policyHolderName !== "PORTAL  PORTAL"){
                             if($scope.childrenDetails[i].disableFields === true){
                            $scope.edtQuoteChildrenRisks[i].riskSumInsured = $scope.basciDetailsRadio === 'INDIVIDUAL'? $scope.childrenDetails[i].childSumInsured:"";
                             $scope.edtQuoteChildrenRisks[i].riskDetails.thresholdLimit = $scope.basciDetailsRadio === 'INDIVIDUAL'? $scope.childrenDetails[i].childthresholdLmt:"";    
                           $scope.riskDetails.push($scope.edtQuoteChildrenRisks[i]); 
                          
                         }else{
                             $scope.childRiskDetails ={
                               "riskSumInsured":$scope.basciDetailsRadio === 'INDIVIDUAL'? $scope.childrenDetails[i].childSumInsured:"",
                                "riskDetails": {
                                  "thresholdLimit":$scope.basciDetailsRadio === 'INDIVIDUAL'? $scope.childrenDetails[i].childthresholdLmt:"",
                                  "cityOfResidence": null,
                                  "relationWithPolicyHolder": "CHILDREN",
                                  "dateOfBirth": $scope.childrenDetails[i].childrenDateOfBirth,
                                  "ageInYrs": ageDinYrs,
                                   "dependent":$scope.childrenDetails[i].dependentType === "NA"?"N":"Y",
                                   "dependentType":$scope.childrenDetails[i].dependentType
          
                                }  
                            }; 
                            $scope.riskDetails.push($scope.childRiskDetails);   
           
                         }
                     
                 }
             }  
         /************TU EditQuote ends************/
                //local storage items premium calculator
                $scope.riskPlusProposerDeatils = [];
                localStorage.setItem("TypeOfCover", $scope.basciDetailsRadio);

                localStorage.setItem("threshold", $scope.premiumCalcModels.thresholdLimit);

                localStorage.setItem("sumInsured", $scope.premiumCalcModels.sumInsured);

                localStorage.setItem("ProposerDateOfBirth", $scope.premiumCalcModels.proposerDateOfBirth);
                localStorage.setItem("proposerthresholdLmt", $scope.premiumCalcModels.proposerthresholdLmt);
                localStorage.setItem("proposerSumInsured", $scope.premiumCalcModels.proposerSumInsured);
                localStorage.setItem("spouseTrueFalse", $scope.addSpouseDisable);
                localStorage.setItem("proposerBtnTrueFalse", $scope.addProposerBtnDisable);//CR747
                localStorage.setItem("spouseBtnTrueFalse", $scope.addSpouseBtnDisable);//CR747
                localStorage.setItem("spouseDateOfBirth", $scope.premiumCalcModels.spouseDateOfBith);
                localStorage.setItem("spousethresholdLmt", $scope.premiumCalcModels.spousethresholdLmt);
                localStorage.setItem("spouseSumInsured", $scope.premiumCalcModels.spouseSumInsured);
                localStorage.setItem("disableAddChildBtn", disableAddChildBtn);
                localStorage.setItem("addChildDisable", $scope.addChildDisable);
                localStorage.setItem("termsAndConditions", $scope.toupTermsAndCondition);
                CommonServices.topUpObj.localStorPremiumCalChildDetails = $scope.childrenDetails;


                //CommonServices.topUpObj.addedMebersDetails = $scope.riskDetails;
                /*CR747 START*/
                if (CommonServices.newIndiaPremierMediclaim.memberCoveredInPolicy === false && $scope.basciDetailsRadio === "FLOATER") {

                    $scope.riskPlusProposerDeatils.push({
                        "riskDetails": {
                            "relationWithPolicyHolder": "SELF",
                            "riskSumInsured": "500000",
                            "thresholdLimit": "500000"

                        }
                    });

                    for (var i = 0; i < $scope.riskDetails.length; i++) {
                        $scope.riskPlusProposerDeatils.push($scope.riskDetails[i]);
                    }

                    CommonServices.topUpObj.addedMebersDetails = $scope.riskPlusProposerDeatils;
                } else {
                    CommonServices.topUpObj.addedMebersDetails = $scope.riskDetails;
                }
                /*CR747 START*/

                     /***********TU EditQuote starts************/
                if (CommonServices.editQuoteFlag === true) {

                    if (CommonServices.floaterObj.policyHolderName === "PORTAL  PORTAL") {
                        premiumServicecall();
                    } else {
                         var premiumDetails = { "grossPremium":CommonServices.floaterObj.premiumDetails.grossPremium,
                        "netPremium": CommonServices.floaterObj.premiumDetails.netPremium ,
                        "noOfMembers":CommonServices.newIndiaPremierMediclaim.numberOfMembers,
                        "sumInsured": CommonServices.floaterObj.premiumDetails.sumInsured
                    };

                        CommonServices.newIndiaPremierMediclaim.premium = premiumDetails;
                        
                        

                        CommonServices.editSaveQuote = true;
                        CommonServices.topUpObj.typeOfCover = $scope.basciDetailsRadio;
                        CommonServices.newIndiaPremierMediclaim.EditSaveQuoteRisk = $scope.riskDetails;
                        CommonServices.saveQuoteHealth();
                    }

                } else {
                    premiumServicecall();
                }
                  /***********TU EditQuote ends *************/     

            }
        }
    };

    // premium Service call

    function premiumServicecall() {
        /******EditQuoteChanges*********/
        CommonServices.topUpObj.typeOfCover = $scope.basciDetailsRadio;
        var topUpCalPremiumInput = {
            "quote": {
                "risks": $scope.riskDetails,
                "productCode": "TU",
                "quoteNumber":CommonServices.editQuoteFlag === true ?  CommonServices.floaterObj.quoteNumber : CommonServices.topUpObj.fromBasicPremium === true ?CommonServices.topUpObj.premiumCalResponse.quoteNumber : undefined,
                "policyStartDate": policyStartDate,
                "policyExpiryDate": policyEndDate,
                "memberCoveredInPolicy": ($scope.basciDetailsRadio === "INDIVIDUAL" && $scope.addPropserDisable === false) ? undefined : $scope.addPropserDisable === false ? "N" : "Y",
                "mobileNo": null,
                "emailId": null,
                "progressLevel": null,
                "policyHolderDetails": (CommonServices.newIndiaPremierMediclaim.memberCoveredInPolicy === false && $scope.basciDetailsRadio === "FLOATER") ? CommonServices.topUpObj.policyHolderSelf : undefined,
                "typeOfCover": $scope.basciDetailsRadio
            },
            "userProfile": {
                "userId": CommonServices.getCommonData("userId"),
                "loggedInRole": "SUPERUSER"
            }

        };

        var topUpPremiumCalResponse = RestServices.postService(RestServices.urlPathsNewPortal.topUpCalcPremium, topUpCalPremiumInput);
        topUpPremiumCalResponse.then(
            function (response) { // success 

                CommonServices.showLoading(false);

                if (response.data.hasOwnProperty('errorMessage')) {
                    //alert(response.data.errorMessage);
                    CommonServices.showAlert(response.data.errorMessage);
                } else {
                    CommonServices.topUpObj.premiumCalResponse = response.data.quote;
                    $state.go("topUpBasicPremiumScreen");
                }
            },
            function (error) { // failure
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            });

    };

    if (CommonServices.topUpObj.fromBasicPremium === true) {
        if (CommonServices.newIndiaPremierMediclaim.memberCoveredInPolicy === true && CommonServices.topUpObj.SelfDOBPolicyHolder !== undefined) {
            $scope.premiumCalcModels.proposerDateOfBirth = CommonServices.topUpObj.SelfDOBPolicyHolder;
            $scope.enableProposerDOB = true;

        } else {
            $scope.premiumCalcModels.proposerDateOfBirth = localStorage.getItem("ProposerDateOfBirth");
        }

        $scope.basciDetailsRadio = localStorage.getItem("TypeOfCover");

        if (localStorage.getItem("TypeOfCover") === 'INDIVIDUAL') {
            $scope.sumInsuredMsg = false;
            $scope.sumInsuredMsgScope = 'Sum Insured amount will be Individual Limit for each member in a family.';
            /*CR 747 start */
            if (CommonServices.newIndiaPremierMediclaim.memberCoveredInPolicy === true) {
                $scope.premiumCalcModels.proposerthresholdLmt = localStorage.getItem("proposerthresholdLmt");
                $scope.premiumCalcModels.proposerSumInsured = localStorage.getItem("proposerSumInsured");

                if ($scope.premiumCalcModels.proposerthresholdLmt === '500000') {
                    $scope.sumInsuredProposer = [500000, 1000000, 1500000];
                } else {
                    $scope.sumInsuredProposer = [700000, 1200000, 1700000, 2200000];
                }
            }/*CR 747 end */

            $scope.premiumCalcModels.spousethresholdLmt = localStorage.getItem("spousethresholdLmt");
            $scope.premiumCalcModels.spouseSumInsured = localStorage.getItem("spouseSumInsured");
            if ($scope.premiumCalcModels.spousethresholdLmt === '500000') {
                $scope.sumInsuredSpouse = [500000, 1000000, 1500000];

            } else {
                $scope.sumInsuredSpouse = [700000, 1200000, 1700000, 2200000];
            }

        } else {
            $scope.sumInsuredMsg = false;
            $scope.sumInsuredMsgScope = 'Sum Insured will be single overall limit for entire policy';
            $scope.premiumCalcModels.thresholdLimit = localStorage.getItem("threshold");
            if ($scope.premiumCalcModels.thresholdLimit === '500000') {
                $scope.sumInsuredBasic = [500000, 1000000, 1500000];
            } else {
                $scope.sumInsuredBasic = [700000, 1200000, 1700000, 2200000];

            }
            $scope.premiumCalcModels.sumInsured = localStorage.getItem("sumInsured");
        }
        $scope.childrenDetails = CommonServices.topUpObj.localStorPremiumCalChildDetails;


        $scope.proposerDateOfBirth = localStorage.getItem("ProposerDateOfBirth");

        $scope.addSpouseDisable = localStorage.getItem("spouseTrueFalse") === "true" ? true : false;
        $scope.addProposerBtnDisable = localStorage.getItem("proposerBtnTrueFalse") === "true" ? true : false;//CR747
        $scope.addSpouseBtnDisable = localStorage.getItem("spouseBtnTrueFalse") === "true" ? true : false;//CR747
        $scope.premiumCalcModels.spouseDateOfBith = localStorage.getItem("spouseDateOfBirth");
        disableAddChildBtn = parseInt(localStorage.getItem("disableAddChildBtn"));
        $scope.addChildDisable = localStorage.getItem("addChildDisable") === "true" ? true : false;
        $scope.toupTermsAndCondition = localStorage.getItem("termsAndConditions") === "true" ? true : false;
        $scope.numberOfmembers = CommonServices.topUpObj.numberOfMembers;//CR747
        $scope.addPropserDisable = CommonServices.newIndiaPremierMediclaim.memberCoveredInPolicy;//CR747

    }

     /***********TU EditQuote starts *************/
    if (CommonServices.editQuoteFlag === true) {
        $scope.childrenDetails = [];
        $scope.edtQuoteChildrenRisks = [];   
        $scope.addSpouseDisable = false;
         
        $scope.basciDetailsRadio =  CommonServices.topUpObj.fromBasicPremium === true ?localStorage.getItem("TypeOfCover") : CommonServices.floaterObj.typeOfCover;
        
        $scope.sumInsuredMsg = false;
        $scope.sumInsuredMsgScope = CommonServices.floaterObj.typeOfCover === 'INDIVIDUAL' ? 'Sum Insured amount will be Individual Limit for each member in a family.' : 'Sum Insured will be single overall limit for entire policy';

        $scope.toupTermsAndCondition = true;

            var premiumDetails = { "grossPremium":CommonServices.floaterObj.premiumDetails.grossPremium,
                "netPremium": CommonServices.floaterObj.premiumDetails.netPremium ,
                "noOfMembers":CommonServices.newIndiaPremierMediclaim.numberOfMembers,
                "sumInsured": CommonServices.floaterObj.premiumDetails.sumInsured
            };

            CommonServices.newIndiaPremierMediclaim.premium = premiumDetails;
           
          $scope.numberOfmembers = CommonServices.floaterObj.risks.length;
           
           if(CommonServices.floaterObj.risks[0].riskDetails.relationWithPolicyHolder !== "SELF" && CommonServices.floaterObj.typeOfCover ==='INDIVIDUAL'  ){
//               CommonServices.topUpObj.tuMemberCoveredInPolicy = true;
                       $scope.addPropserDisable = false;
               /******EditQuoteChanges*********/
                $scope.addProposerBtnDisable =false;
               var policyHolderPartyCode;
               
               
                 
               
                angular.forEach(CommonServices.floaterObj.partyDetailsList, function (value, key) {
                   if(CommonServices.floaterObj.partyDetailsList[key].partyStakeCode ==='POLICY-HOL'){
                        policyHolderPartyCode = CommonServices.floaterObj.partyDetailsList[key].partyCode;

                    }  
                });
              
               
               var topUpGetPolicyHolderDetailInput = {
            "userProfile": {
                "userId": CommonServices.getCommonData("userId"),
                "loggedInRole": "SUPERUSER"
            },
            "partyDetails": {
                "partyCode": policyHolderPartyCode
            }
        };
        
        var topUpGetPolicyHolderDetailResponse = RestServices.postService(RestServices.urlPathsNewPortal.getPolicyHolderDetail, topUpGetPolicyHolderDetailInput);
        topUpGetPolicyHolderDetailResponse.then(
            function (response) { // success	
                CommonServices.showLoading(false);
                if(response.data.hasOwnProperty("errorMessage")){
                    CommonServices.showAlert(response.data.errorMessage);
                }else{
                  CommonServices.floaterObj.dateOfBirth = response.data.partyDetails.individualDetails.dateOfBirth;   
                } 
            },
            function (error) { // failure
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            });
               
               
        }
        var editQuoteBasicPremiumArray = [];
        
        //Basic Premium
        if(CommonServices.topUpObj.fromBasicPremium === true){
                editQuoteBasicPremiumArray = CommonServices.topUpObj;
               editQuoteBasicPremiumArray.risks = CommonServices.topUpObj.addedMebersDetails;
                $scope.numberOfmembers = editQuoteBasicPremiumArray.risks.length;
        }else{
            editQuoteBasicPremiumArray = CommonServices.floaterObj;
        }
        
        angular.forEach(editQuoteBasicPremiumArray.risks, function (value, key) {

            if (editQuoteBasicPremiumArray.risks[key].riskDetails.relationWithPolicyHolder === "SELF") {
                    editQuoteBasicPremiumArray.dateOfBirth = editQuoteBasicPremiumArray.risks[key].riskDetails.dateOfBirth;
                if (editQuoteBasicPremiumArray.typeOfCover === 'INDIVIDUAL') {

                    $scope.premiumCalcModels.proposerthresholdLmt = editQuoteBasicPremiumArray.risks[key].riskDetails.thresholdLimit;
                    $scope.premiumCalcModels.proposerSumInsured = editQuoteBasicPremiumArray.risks[key].riskSumInsured;

                    if ($scope.premiumCalcModels.proposerthresholdLmt === '500000') {
                        $scope.sumInsuredProposer = [500000, 1000000, 1500000];
                    } else {
                        $scope.sumInsuredProposer = [700000, 1200000, 1700000, 2200000];
                    }

                } else {
                    $scope.premiumCalcModels.thresholdLimit = editQuoteBasicPremiumArray.risks[key].riskDetails.thresholdLimit;

                    if ($scope.premiumCalcModels.thresholdLimit === '500000') {
                        $scope.sumInsuredBasic = [500000, 1000000, 1500000];
                    } else {
                        $scope.sumInsuredBasic = [700000, 1200000, 1700000, 2200000];

                    }
                    $scope.premiumCalcModels.sumInsured = editQuoteBasicPremiumArray.risks[key].riskSumInsured;
                }
                    CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk = editQuoteBasicPremiumArray.risks[key];
                        CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk.riskParty = editQuoteBasicPremiumArray.risks[key].riskParty;
                    
                    if(editQuoteBasicPremiumArray.risks[key].riskDetails.memberCoveredInPolicy ==="N"){
                        $scope.addPropserDisable = false;
                        $scope.addProposerBtnDisable =false;
                         $scope.numberOfmembers =  $scope.numberOfmembers-1;
                        
                    }else{
                        $scope.enableProposerDOB = true;
                        $scope.proposerRiskDetails = editQuoteBasicPremiumArray.risks[key];
                        
                         $scope.premiumCalcModels.proposerDateOfBirth = editQuoteBasicPremiumArray.risks[key].riskDetails.dateOfBirth;
           
                    }
                    
//                    if($scope.numberOfmembers === 6){
//					$scope.addProposerBtnDisable = true; 
//				}

            }
            if (editQuoteBasicPremiumArray.risks[key].riskDetails.relationWithPolicyHolder === "SPOUSE") {
                if(editQuoteBasicPremiumArray.risks[key].riskDetails.nameOfInsuredPerson !== undefined && editQuoteBasicPremiumArray.risks[key].riskDetails.nameOfInsuredPerson !=='' && editQuoteBasicPremiumArray.policyHolderName !== "PORTAL  PORTAL" ){
                    editQuoteBasicPremiumArray.risks[key].riskDetails.nameFileDisable = true;
                }
                 
                $scope.spouseRiskDetails = editQuoteBasicPremiumArray.risks[key];
                $scope.enableSpouseDOB = true;
                $scope.premiumCalcModels.spouseDateOfBith = editQuoteBasicPremiumArray.risks[key].riskDetails.dateOfBirth;
                $scope.addSpouseDisable = true;
                $scope.addSpouseBtnDisable = true;

                if (editQuoteBasicPremiumArray.typeOfCover === 'INDIVIDUAL') {

                    $scope.premiumCalcModels.spousethresholdLmt = editQuoteBasicPremiumArray.risks[key].riskDetails.thresholdLimit;

                    if ($scope.premiumCalcModels.spousethresholdLmt === '500000') {
                        $scope.sumInsuredSpouse = [500000, 1000000, 1500000];
                    } else {
                        $scope.sumInsuredSpouse = [700000, 1200000, 1700000, 2200000];

                    }


                    $scope.premiumCalcModels.spouseSumInsured = editQuoteBasicPremiumArray.risks[key].riskSumInsured;
                }
//                if($scope.numberOfmembers === 6){
//					$scope.addSpouseBtnDisable = true; 
//				}
            
            }

            if (editQuoteBasicPremiumArray.risks[key].riskDetails.relationWithPolicyHolder === "CHILDREN") {
                if(editQuoteBasicPremiumArray.risks[key].riskDetails.nameOfInsuredPerson !== undefined && editQuoteBasicPremiumArray.risks[key].riskDetails.nameOfInsuredPerson !=='' && editQuoteBasicPremiumArray.policyHolderName !== "PORTAL  PORTAL"){
                     editQuoteBasicPremiumArray.risks[key].riskDetails.nameFileDisable = true;
                }
               
                /** ginitha added**/
                
//                if($scope.numberOfmembers === 6){
//					$scope.addChildDisable = true; 
//				}
                 /** ginitha added**/
                /******EditQuoteChanges*********/
                disableAddChildBtn = disableAddChildBtn + 1;
                $scope.edtQuoteChildrenRisks.push(editQuoteBasicPremiumArray.risks[key]);

                $scope.childrenDetails.push({
                    policyHolderRelationShip: "Child",
                    childrenDateOfBirth: editQuoteBasicPremiumArray.risks[key].riskDetails.dateOfBirth,
                    childthresholdLmt: editQuoteBasicPremiumArray.risks[key].riskDetails.thresholdLimit === "0" ? undefined : editQuoteBasicPremiumArray.risks[key].riskDetails.thresholdLimit,
                    childSumInsured: editQuoteBasicPremiumArray.risks[key].riskSumInsured === "0" ? undefined : editQuoteBasicPremiumArray.risks[key].riskSumInsured,
                    dependentType:editQuoteBasicPremiumArray.risks[key].riskDetails.dependent === "Y" ? editQuoteBasicPremiumArray.risks[key].riskDetails.dependentType : "NA",
                  childrenSumIndDetails:editQuoteBasicPremiumArray.risks[key].riskDetails.thresholdLimit ==="500000"?[500000,1000000,1500000] :[700000,1200000,1700000,2200000],
                  disableFields: true

                });
            }



        });
        /******EditQuoteChanges*********/
       if($scope.numberOfmembers === 6){
					$scope.addSpouseBtnDisable = true; 
                    $scope.addProposerBtnDisable = true;
                    $scope.addChildDisable = true; 
		  }

    }
     /***********TU EditQuote ends *************/

    /* CR 3562 START */
    
    if (CommonServices.topUpObj.fromBasicPremium != undefined && CommonServices.topUpObj.fromBasicPremium === true) {
        $scope.prevNomineeDetailObj = CommonServices.getCommonData('paPolicyAutopopulatedData');
    } else {
        $scope.prevNomineeDetailObj = [];
    }

	$scope.showMobileOptn = false;
	$scope.proposerSearchResult = false;
	$scope.searchObj = {};
	$scope.getProposerDerails = function (type) {

		if (type === 'policyNumber' && ($scope.searchFromList.prevPolicyNumber.$invalid || $scope.searchObj.prevPolicyNumber === undefined || $scope.searchObj.prevPolicyNumber.trim() === '')) return;
		if (type === 'mobileNumber' && ($scope.searchFromList.mobileNumber.$invalid || $scope.searchObj.prevPolicyMobileNumber === undefined || $scope.searchObj.prevPolicyMobileNumber.trim() === '')) return;
		
		var domainInputValues = {
			"quote": {
				"policyNumber":$scope.searchObj.prevPolicyNumber.trim()
			},
			"userProfile":{
				"userId": CommonServices.getCommonData("userId"),
				"loggedInRole": "SUPERUSER"
			}
		};
		var comparedMobileNumber = $scope.searchObj.prevPolicyMobileNumber;

		RestServices.postService(RestServices.urlPathsNewPortal.fetchHealthMemberDetail, domainInputValues).then(function (response) {
            CommonServices.showLoading(false);
            
            $scope.proposerSearchResult = false;
			if (response.data.errorCode === 959) {
				CommonServices.showAlert(response.data.errorMessage);
				return;

			} else if (response.data.quote.flagPrevPortal === 1 && type === 'policyNumber') {
				var msg = "As this policy is not attached to you, in order to proceed further please enter the customer's mobile number and search again";
				CommonServices.messageModal('info', msg, false, '', 'Ok', function() {}, function() {
					$scope.showMobileOptn = true;
					// $scope.proposerSearchResult = false;
				}, 'Alert');

			} else if (response.data.quote.contactno != undefined && response.data.quote.contactno != comparedMobileNumber && type === 'mobileNumber') {
				var msg = "Mobile number entered does not match with Mobile number in policy holder details of previous health policy. Please enter correct mobile number";
					CommonServices.messageModal('info', msg, false, '', 'Ok', function() {}, function() {
						$scope.showMobileOptn = true;
						// $scope.proposerSearchResult = false;
                        //$scope.searchObj.prevPolicyNumber = ''; //To fix the issue for CR_3562 - Sudip
                        $scope.searchObj.prevPolicyMobileNumber = ''; //To fix the issue for CR_3562 - sudip
					}, 'Alert');

			} else if (response.data.quote.memberDetails === undefined) {
                var msg = "No data found";
					CommonServices.messageModal('info', msg, false, '', 'Ok', function() {}, function() {
						$scope.showMobileOptn = false;
                    }, 'Alert');
                    
            } else {
				$scope.prevNomineeDetailObj = response.data.quote.memberDetails;
				angular.forEach($scope.prevNomineeDetailObj, function (value, key) {
					value.isSelected = false;
				});
                $scope.proposerSearchResult = true; //
                // $scope.numberOfmembers = 1;
                CommonServices.noOfMembers = $scope.numberOfmembers;    
                CommonServices.counts = $scope.childrenDetails.length;
				var obj = {
					page: 'TU_policyAutoPopulate', 
					title: 'Proposer Search Result', 
					footer: true, 
					bodyMsg: 'Test',
					dataSet: $scope.prevNomineeDetailObj,
					noBtnText: 'Cancel',
					noButtonAction: $scope.searchSelectionAction,
					yesBtnText: 'Ok',
                    yesButtonAction: $scope.searchSelectionAction,
                    proposer: $scope.addProposerBtnDisable,
                    spouse: $scope.addSpouseBtnDisable,
					//chkAction: $scope.autoPopulateChkAction
				};
				openRelationalModal(obj, 'lg');
			}

		},
		function (error) {    // failure 
			CommonServices.showLoading(false);
			RestServices.handleWebServiceError(error);
		});
	}

	openRelationalModal = function (modalObj = {}, modalSize = 'lg') {
		var modalInstance = $modal.open({
			animation: false,
			templateUrl: 'partials/general/generalModal.html',
			controller: 'generalModalController',
			windowClass: 'general-modal',
			size: modalSize,
			resolve: {
				modalData: function() {
					return modalObj
				}
			}
		});
		modalInstance.result.then(function(result) {
			//backdropClass: ".modal-backdrop .fade";
			// console.log(result);
		});
	};

	var tempPolicyMaxLen = 0;
	$scope.searchObj.validatePolicyNumber = function (data, maxLen) {
		if (data !== undefined) {
			var len = data.toString().length;
			if (len > maxLen) {
				$scope.searchObj.prevPolicyNumber = tempPolicyMaxLen;
			} else {
				var result = /^\d*$/.test(data);
				if (result) {
					tempPolicyMaxLen = $scope.searchObj.prevPolicyNumber;
				}
				if (len === maxLen) {
					$scope.searchFromList.prevPolicyNumber.$invalid = false;
				} else {
					$scope.searchFromList.prevPolicyNumber.$invalid = true;
				}
			}
		}
	}
	var occupationObj = {};
	// $scope.autoPopulateChkAction = function (i, obj) {
	// 	var ret = true;
	// 	if (obj.relation.toLowerCase() === 'self' || obj.relation.toLowerCase() === 'proposer') {
	// 		if (obj.isSelected) {
    //             $scope.addMember('Proposer');
	// 			$scope.premiumCalcModels.proposerDateOfBirth = obj.dob;
	// 			$scope.dateOfBirthProposerSpouse('proposer');
	// 		} else {
    //             $scope.premiumCalcModels.proposerDateOfBirth = '';
	// 			$scope.closeMember('Proposer', i);
	// 		}
	// 	} else if (obj.relation.toLowerCase() === 'spouse') {
	// 		if (obj.isSelected) {
    //             $scope.addMember('Spouse');
	// 			$scope.premiumCalcModels.spouseDateOfBith = obj.dob;
    //             $scope.dateOfBirthProposerSpouse('spouse');
	// 		} else {
	// 			$scope.closeMember('Spouse', i);
	// 			$scope.premiumCalcModels.spouseDateOfBith = '';
	// 		}
    //     } else if (obj.relation.toLowerCase() === 'children' || obj.relation.toLowerCase() === 'son' || obj.relation.toLowerCase() === 'daughter') {
    //         if (obj.isSelected) {
    //             $scope.addMember('Child');
    //             var len = ($scope.childrenDetails.length > 0) ? ($scope.childrenDetails.length - 1) : 0;
    //             $scope.childrenDetails[len].childrenDateOfBirth = obj.dob;
    //             $scope.childrenDetails[len].dependentType = (obj.sex === 'M') ? 'NORM' : 'UD';
    //             $scope.dependentTypeChanged();

    //         } else {
    //             $scope.closeMember('Child', i);
    //         }
    //     }
        
	// 	CommonServices.setCommonData('paTotalChildAdded', $scope.childrenDetails.length);
    // }
    if(CommonServices.getCommonData('paPolicyAutopopulatedData') === undefined){
            $scope.addedMembersPolicySearchDetails = {
                proposer: undefined,
                spouse: undefined,
                children: [],
            }
    }
    else
        $scope.addedMembersPolicySearchDetails = CommonServices.getCommonData('paPolicyAutopopulatedData');

	$scope.searchSelectionAction = function (isConfirm) {
        //resetProposerDetail();
        if (isConfirm && $scope.numberOfmembers <= 6) { //OK
            let childTemp = angular.copy($scope.childrenDetails);
            $scope.childrenDetails = [];
            let childrenCompleteDetailsTemp = angular.copy($scope.addedMembersPolicySearchDetails.children);
            $scope.addedMembersPolicySearchDetails.children = [];
            angular.forEach($scope.prevNomineeDetailObj, function (obj, i) {
                if (obj.relation.toLowerCase() === 'self' || obj.relation.toLowerCase() === 'proposer') {
                    if (obj.isSelected) {
                        if($scope.addPropserDisable) $scope.closeMember('Proposer');
                        if($scope.numberOfmembers === 6)
                        {
                            CommonServices.showAlert("For New India Top Up Mediclaim, maximum 6 members can be added.")
                        }
                        else{
                            $scope.addMember('Proposer', 2);
                            $scope.addedMembersPolicySearchDetails.proposer = obj;
                            $scope.premiumCalcModels.proposerDateOfBirth = obj.dob;
                            $scope.dateOfBirthProposerSpouse('proposer');
                        }
                    } /*else {
                        $scope.premiumCalcModels.proposerDateOfBirth = '';
                        $scope.closeMember('Proposer', i);
                    }*/
                } else if (obj.relation.toLowerCase() === 'spouse') {
                    if (obj.isSelected) {
                        if($scope.addSpouseDisable) $scope.closeMember('Spouse');
                        if($scope.numberOfmembers === 6)
                        {
                            CommonServices.showAlert("For New India Top Up Mediclaim, maximum 6 members can be added.")
                        }
                        else{
                            $scope.addMember('Spouse', 2);
                            $scope.addedMembersPolicySearchDetails.spouse = obj;
                            $scope.premiumCalcModels.spouseDateOfBith = obj.dob;
                            $scope.dateOfBirthProposerSpouse('spouse');
                        }
                    } /*else {
                        $scope.closeMember('Spouse', i);
                        $scope.premiumCalcModels.spouseDateOfBith = '';
                    }*/
                } else if (obj.relation.toLowerCase() === 'children' || obj.relation.toLowerCase() === 'child' || obj.relation.toLowerCase() === 'son' || obj.relation.toLowerCase() === 'daughter') {
                    if (obj.isSelected) {
                        if($scope.numberOfmembers === 6)
                        {
                            CommonServices.showAlert("For New India Top Up Mediclaim, maximum 6 members can be added.")
                        }
                        else{
                            $scope.addMember('Child', 2);
                            //var len = ($scope.childrenDetails.length > 0) ? ($scope.childrenDetails.length - 1) : 0;
                            var len = $scope.childrenDetails.length-1;
                            $scope.childrenDetails[len].childrenDateOfBirth = obj.dob;
                            $scope.addedMembersPolicySearchDetails.children.push(obj);
                            // $scope.childrenDetails[len].dependentType = (obj.sex === 'M') ? 'NORM' : 'UD';
                            $scope.dependentTypeChanged();
                            if($scope.numberOfmembers > 5) //$scope.childrenDetails.length>3
                                $scope.addChildDisable = true;
                            else $scope.addChildDisable = false;
                        }
        
                    } /*else {
                        $scope.closeMember('Child', i);
                    }*/
                }
                CommonServices.setCommonData('paTotalChildAdded', $scope.childrenDetails.length);
            });
            $scope.childrenDetails = $scope.childrenDetails.concat(childTemp);
            $scope.addedMembersPolicySearchDetails.children = $scope.addedMembersPolicySearchDetails.children.concat(childrenCompleteDetailsTemp);
            console.log($scope.numberOfmembers);
            if($scope.numberOfmembers==6)
            {
                $scope.addChildDisable = true;
                $scope.addSpouseBtnDisable = true;
                $scope.addProposerBtnDisable = true;
            }
        }
		$scope.proposerSearchResult = false;
		$scope.showMobileOptn = false;
		// $scope.searchObj.prevPolicyNumber = ''; // removed to keep the policy nummber in the search box
		$scope.searchObj.prevPolicyMobileNumber = '';
	}
	// function resetProposerDetail () {
    //     $scope.closeMember('Proposer');
    //     $scope.closeMember('Spouse');
    //     //$scope.childrenDetails = []; //to fix the issue - Sudip
    //     $scope.addSpouseBtnDisable = false;
    //     $scope.addChildDisable = false;
    //     $scope.addProposerBtnDisable = false;
    //     $scope.numberOfmembers = 0;

    //     // angular.forEach($scope.childrenDetails, function (value, i) {
    //     //     $scope.closeMember('Child', i);
    //     // });
    //     $scope.premiumCalcModels.proposerDateOfBirth = '';
    //     $scope.premiumCalcModels.spouseDateOfBith = '';
    //    // $scope.premiumCalcModels.thresholdLimit = ''; //to fix the issue - Sudip
    //    // $scope.premiumCalcModels.sumInsured = ''; //to fix the issue - Sudip
    // }
	/* CR 3562 END */


}]);



agentApp.controller('topUpBasicPremiumCtrl', ['$scope', 'RestServices', 'CommonServices', '$state', '$rootScope', function ($scope, RestServices, CommonServices, $state, $rootScope) {


    $scope.goBack = function () {
        if ($rootScope.productName === "TU") {
            CommonServices.topUpObj.fromBasicPremium = true;
            $state.go("topUpPremiumCalcScreen");
        } else {
            CommonServices.newIndiaPremierMediclaim.fromBasicPremium = true;
            $state.go("newIndiaPremierMediclaim");
        }
    };

    if (CommonServices.editQuoteFlag === true) {
        $scope.editQuoteFlagBasicPremium = true;
    }

    $scope.basicPremium = $rootScope.productName === "TU" ? CommonServices.topUpObj : CommonServices.newIndiaPremierMediclaim;

    $scope.topUpBreakupClick = function () {
        var topUpViewBreakUPInput;
        if ($rootScope.productName === "TU") {
            topUpViewBreakUPInput = {
                "header": null,
                "quote": {
                    "quoteNumber": $scope.basicPremium.premiumCalResponse.quoteNumber,
                    "policyHolderCode": CommonServices.editQuoteFlag === true ? CommonServices.topUpObj.premiumCalResponse.policyHolderCode :""
                }
            };
        } else {
            topUpViewBreakUPInput = {
                "header": null,
                "quote": {
                    "quoteNumber": $scope.basicPremium.premiumCalResponse.quoteNumber,
                    "productCode": "HN",
                    "policyHolderCode": CommonServices.editQuoteFlag === true ? CommonServices.newIndiaPremierMediclaim.premiumCalResponse.policyHolderCode : ""
                }
            };
        }

        var topUpViewBreakUpResponse = RestServices.postService(RestServices.urlPathsNewPortal.healthViewBreakup, topUpViewBreakUPInput);
        topUpViewBreakUpResponse.then(
            function (response) { // success 

                CommonServices.showLoading(false);
                if (response.data.hasOwnProperty('errorMessage')) {
                    //alert(response.data.errorMessage);
                    CommonServices.showAlert(response.data.errorMessage);
                } else {
                    CommonServices.topUpObj.viewBreakUpResponse = response.data.quote;
                    $state.go("topUpViewBreakupScreen");
                }
            },
            function (error) { // failure
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            });

        // $state.go("topUpViewBreakupScreen");

    };
    $scope.topUpViewBreakCntBtn = function () {
        if (CommonServices.editQuoteFlag === true) {

            if($rootScope.productName ==="HN"){
            if (CommonServices.newIndiaPremierMediclaim.premiumCalResponse.premiumDetails.serviceTax === undefined || CommonServices.topUpObj.searchBoxEnable === false) {
                $state.go("policyHolderDetailsScreen");
            } else {
                CommonServices.topUpObj.PolicyHolderSearchCallInput = undefined;
                CommonServices.topUpPolicyHolderSearchCall();
            }
            }else{
                
                if(CommonServices.topUpObj.premiumCalResponse.premiumDetails.serviceTax === undefined || CommonServices.topUpObj.searchBoxEnable === false){
                 $state.go("policyHolderDetailsScreen");  
            }else{
               CommonServices.topUpObj.PolicyHolderSearchCallInput =undefined;
                CommonServices.topUpPolicyHolderSearchCall();  
            }
            }


        } else {
            if (CommonServices.topUpObj.searchBoxEnable === true) {
                $state.go("searchPolicyHolderScreen");
            } else {
                $state.go("policyHolderDetailsScreen");
            }

        }


    };



}]);

agentApp.controller('topUpViewBreakupCtrl', ['$scope', 'RestServices', 'CommonServices', '$state', '$rootScope', function ($scope, RestServices, CommonServices, $state, $rootScope) {
    //$scope.contiNueBtnShow = true;
    if (CommonServices.editSaveQuote === true) {
        $scope.editQouteFlag = true;
    }


    $scope.goBack = function () {
        if (CommonServices.topUpObj.viewBreakUpNavigation === "ViewBreakupSummary") {
            $state.go("toUpReviewSummaryScreen");

        } else {
            $state.go("topUpBasicPremiumScreen");

        }

        //$state.go("topUpBasicPremiumScreen"); 
    };

    $scope.riskPremiums = CommonServices.topUpObj.viewBreakUpResponse.risks;
    var childCount = 0;
    for (var i = 0; i < $scope.riskPremiums.length; i++) {
        if ($rootScope.productName === "TU") {

            if ($scope.riskPremiums[i].riskDetails.relationWithPolicyHolder === "CHILDREN") {
                childCount = childCount + 1;
            }

            if ($scope.riskPremiums[i].riskDetails.relationWithPolicyHolder === 'SELF') {
                $scope.riskPremiums[i].riskDetails.policyHolder = "Proposer";
            } else if ($scope.riskPremiums[i].riskDetails.relationWithPolicyHolder === 'SPOUSE') {
                $scope.riskPremiums[i].riskDetails.policyHolder = "Spouse";
            } else {
                if ($scope.riskPremiums[i].riskDetails.relationWithPolicyHolder === "CHILDREN" && childCount === 1) {
                    $scope.riskPremiums[i].riskDetails.policyHolder = "Child 1";
                } else if ($scope.riskPremiums[i].riskDetails.relationWithPolicyHolder === "CHILDREN" && childCount === 2) {
                    $scope.riskPremiums[i].riskDetails.policyHolder = "Child 2";
                } else if ($scope.riskPremiums[i].riskDetails.relationWithPolicyHolder === "CHILDREN" && childCount === 3) {
                    $scope.riskPremiums[i].riskDetails.policyHolder = "Child 3";
                } else if ($scope.riskPremiums[i].riskDetails.relationWithPolicyHolder === "CHILDREN" && childCount === 4) {
                    $scope.riskPremiums[i].riskDetails.policyHolder = "Child 4";
                }
                else if ($scope.riskPremiums[i].riskDetails.relationWithPolicyHolder === "CHILDREN" && childCount === 5) {
                    $scope.riskPremiums[i].riskDetails.policyHolder = "Child 5";
                } else {
                    $scope.riskPremiums[i].riskDetails.policyHolder = "Child 6";
                }
            }

        } else {


            if ($scope.riskPremiums[i].riskDetails.relationWithPolicyHolder === "Children") {
                childCount = childCount + 1;
            }

            if ($scope.riskPremiums[i].riskDetails.relationWithPolicyHolder === 'Proposer') {
                $scope.riskPremiums[i].riskDetails.policyHolder = "Proposer";
            } else if ($scope.riskPremiums[i].riskDetails.relationWithPolicyHolder === 'Spouse') {
                $scope.riskPremiums[i].riskDetails.policyHolder = "Spouse";
            } else {
                if ($scope.riskPremiums[i].riskDetails.relationWithPolicyHolder === "Children" && childCount === 1) {
                    $scope.riskPremiums[i].riskDetails.policyHolder = "Child 1";
                } else if ($scope.riskPremiums[i].riskDetails.relationWithPolicyHolder === "Children" && childCount === 2) {
                    $scope.riskPremiums[i].riskDetails.policyHolder = "Child 2";
                } else if ($scope.riskPremiums[i].riskDetails.relationWithPolicyHolder === "Children" && childCount === 3) {
                    $scope.riskPremiums[i].riskDetails.policyHolder = "Child 3";
                } else if ($scope.riskPremiums[i].riskDetails.relationWithPolicyHolder === "Children" && childCount === 4) {
                    $scope.riskPremiums[i].riskDetails.policyHolder = "Child 4";
                } else {
                    $scope.riskPremiums[i].riskDetails.policyHolder = "Child 5";
                }
            }

        }


    }

	   $scope.premiumDetails =	CommonServices.topUpObj.viewBreakUpResponse;
        $scope.topUpViewBreakCntBtn = function(){
            if(CommonServices.editQuoteFlag === true){
                
                if($rootScope.productName ==="HN"){
                  if(CommonServices.newIndiaPremierMediclaim.premiumCalResponse.premiumDetails.serviceTax === undefined || CommonServices.topUpObj.searchBoxEnable === false){
                     $state.go("policyHolderDetailsScreen");  
                }else{
                    CommonServices.topUpObj.PolicyHolderSearchCallInput =undefined;
                    CommonServices.topUpPolicyHolderSearchCall();  
                }  
                    
                    
                }else{
                      if(CommonServices.topUpObj.premiumCalResponse.premiumDetails.serviceTax === undefined || CommonServices.topUpObj.searchBoxEnable === false){
                $state.go("policyHolderDetailsScreen");
            } else {
                CommonServices.topUpObj.PolicyHolderSearchCallInput = undefined;
                CommonServices.topUpPolicyHolderSearchCall();
            }
                }

        } else {
            if (CommonServices.topUpObj.searchBoxEnable === true) {
                $state.go("searchPolicyHolderScreen");
            } else {
                $state.go("policyHolderDetailsScreen");
            }
        }


    };
}]);

agentApp.controller('policyHolderDetailsCtrl', ['$scope', 'RestServices', 'CommonServices', '$state', '$rootScope', function ($scope, RestServices, CommonServices, $state, $rootScope) {

    /* CR 3712 starts
	$scope.isNonIndia = false;
	// $scope.policyDetailsObj.clientNationality ="";
	$scope.onNationalityChange = function(){
		$scope.policyHolderCreate.clientCountry = '';
		if($scope.policyHolderCreate.clientNationality == "NonIndian"){
			$scope.isNonIndia = true;
		}
		else{
			$scope.isNonIndia = false;
		}
	}
	// CR_3712 ends*/

    $scope.policyHolderDetailsCtrl = {
        onload: function () {
            $scope.cityEnable = true;
            $scope.pinEnable = true;
            $scope.gstInPatternErr = true;
            $scope.isNIAPAN = false;//CR3746
            $scope.disableInputField = false;
            $scope.disableBackIcon = false;
            $scope.gstinMsg = "GSTIN";
            $scope.policyHolderRadio = 'newCustomer';
            // CommonServices.policyHolderType = "newCustomer";
            if (CommonServices.policyHolderType === "existingCustomer") {
                $scope.policyHolderRadio = "existingCustomer";
            } else {
                $scope.policyHolderRadio = "newCustomer";
            }
        }
    };

    $scope.policyHolderDetailsCtrl.onload();


    $scope.goBack = function () {
        CommonServices.topUpObj.navigationFrom = "New";
        $state.go("topUpBasicPremiumScreen");
    };

    /*CR_NP_0880 Starts*/
    $scope.disableCityInput = true;
    $scope.disablePinCodeInput = true;
    if(CommonServices.backFromPolSearch){
        $scope.disablePinCodeInput = false;
        // if(CommonServices.topUpObj.getPolicyholderDetails.cityName != undefined && CommonServices.topUpObj.getPolicyholderDetails.cityName != ""){
        //     $scope.policyHolderCreate = CommonServices.topUpObj.getPolicyholderDetails;
        // }
    }
    
   
    /*CR_NP_0880 Ends */
    
    /*Added for CR_NP_0744*/
   // $rootScope.regexPanNo = /^[A-Za-z]{5}[0-9]{4}[A-Za-z]{1}$/;
    // $rootScope.regexPanNo = /^(?!.*([A-Za-z0-9])\1{2})/;
    // $rootScope.regexPanNo = /^(?!.*([A-Za-z])\1{4})/;//only 1st 5 alphabets working

    // $rootScope.regexPanNo =  /^(?:([A-Za-z])(?!(?:[A-Za-z]*?\1){4})){5}(?:([0-9])(?!(?:[0-9]*?\2){3})){4}[A-Za-z]{1}$/;
    
     //CR3746
     $rootScope.regexPanNo = regexPanNoGlobal;
     //CR3746
         $rootScope.regexAadhaarInput = /^(?!\1+$)\d{4}$/;
    $rootScope.regexAadhaarNumber = /^(?!\1+$)\d{12}$/;

    var configurationData = CommonServices.getCommonData("ConfigurationData");
    if (configurationData != undefined && configurationData != '') {
        if (configurationData[0].value == "Y") {
            $scope.isPanNumberMandatory = true;
        } else {
            $scope.isPanNumberMandatory = false;
        }
    }

    $scope.policyHolderCreate = {};
 //CR3746
 $scope.onPANNoChange = function () {
    if($scope.policyHolderCreate.pan != undefined){
        $scope.policyHolderCreate.pan = $scope.policyHolderCreate.pan.toUpperCase();
        $scope.isNIAPAN = isNIAPANNo($scope.policyHolderCreate.pan.toUpperCase());
    }
    else
        $scope.isNIAPAN = false;
};
//CR3746


    $scope.onGstIdChange = function () {
        var valid = true;
        var regxNRI = /^[0-9]{12}[N]{1}[0-9A-Z]{1}[T]{1}$/;
        var regxUNB = /^[0-9]{12}[U]{1}[0-9A-Z]{1}[N]{1}$/;
        var regxNCC = regexGSTidGlobal;///^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[A-Z0-9]{2}[^\s]$/;
		/*if(!genCustomComponents.conversionService.objectIsEmpty($scope.quickRenewalForm)){
			$scope.quickRenewalForm.gstinInd.$setValidity('gstinExp',true);	
		}*/

        if ($scope.policyHolderCreate.gstRegistraionIdType == '' || $scope.policyHolderCreate.gstRegistraionIdType == undefined) {
            $scope.policyHolderCreate.gstin = '';
            $scope.policyHolderForm.gstin.$setValidity("validateNIAPAN", true);
            $scope.policyHolderForm.gstin.$setValidity("gstin", true);
            $scope.gstInPatternErr = false;
            $scope.policyHolderCreate.uin="";
            //return;
        }

        if ($scope.policyHolderCreate.gstRegistraionIdType !== '' && $scope.policyHolderCreate.gstRegistraionIdType !== undefined && $scope.policyHolderCreate.gstin !== "" && $scope.policyHolderCreate.gstin !== undefined) {
            if ($scope.policyHolderCreate.gstRegistraionIdType === 'NRI') {
                valid = (regxNRI.test($scope.policyHolderCreate.gstin.toUpperCase()));
                // $scope.policyHolderForm.gstin.$setValidity("gstStateCode", true);//UC for 3749
            } else if ($scope.policyHolderCreate.gstRegistraionIdType === 'UNB') {
                // $scope.policyHolderForm.gstin.$setValidity("gstStateCode", true);//UC for 3749
                valid = (regxUNB.test($scope.policyHolderCreate.gstin.toUpperCase()));
            } else if ($scope.policyHolderCreate.gstRegistraionIdType === 'NCC') {
                valid = (regxNCC.test($scope.policyHolderCreate.gstin.toUpperCase()));
        //UC for 3749
           
            // if(CommonServices.gstIdStateCode[$scope.policyHolderCreate.gstin.slice(0,2)] != undefined){
            //     if($scope.policyHolderCreate.stateName.state == CommonServices.gstIdStateCode[$scope.policyHolderCreate.gstin.slice(0,2)]){
            //         $scope.policyHolderForm.gstin.$setValidity("gstStateCode", true);
            //         console.log("state code valid");
            //     }
            //     else{
            //         $scope.policyHolderForm.gstin.$setValidity("gstStateCode", false);
            //         $scope.gstErrorMsg = "Please enter valid GSTIN. State code of GSTIN and the state mentioned in address should match.";	
            //     }
            // }
            // else{
            //     $scope.policyHolderForm.gstin.$setValidity("gstStateCode", false);
            //     $scope.gstErrorMsg = "Please enter GSTIN with a valid state code";
            // }

    }
            $scope.gstInPatternErr = valid;
            //$scope.quickRenewalForm.gstinInd.$setValidity('gstinExp',valid);
        } else if ($scope.policyHolderCreate.gstin === "" || $scope.policyHolderCreate.gstin === undefined) {
            $scope.gstInPatternErr = true;
        } else if ($scope.policyHolderCreate.gstRegistraionIdType === '' || $scope.policyHolderCreate.gstRegistraionIdType === undefined) {
            if ($scope.policyHolderCreate.gstin !== "" && $scope.policyHolderCreate.gstin !== undefined) {
                $scope.gstInPatternErr = false;
            }
        }

        if ($scope.gstInPatternErr === false) {
            $scope.policyHolderForm.gstin.$setValidity("gstin", false);
        } else {
            $scope.policyHolderForm.gstin.$setValidity("gstin", true);
        }

        //added by himanshu for CR_875
        if ($scope.policyHolderCreate.gstRegistraionIdType !== '' && $scope.policyHolderCreate.gstRegistraionIdType !== undefined && $scope.policyHolderCreate.gstin !== "" && $scope.policyHolderCreate.gstin !== undefined) {
            if ($scope.policyHolderCreate.gstin != undefined) {
                $scope.policyHolderCreate.gstin = $scope.policyHolderCreate.gstin.toUpperCase();
                if ($scope.policyHolderCreate.gstin.includes("AAACN4165C")) {
                    $scope.policyHolderForm.gstin.$setValidity("validateNIAPAN", false);
                } else {
                    $scope.policyHolderForm.gstin.$setValidity("validateNIAPAN", true);
                }
            }
        }
    };

    $scope.startsWith = function (item, viewValue) {
        return item.substr(0, viewValue.length).toLowerCase() == viewValue.toLowerCase();
    }

    var stateInputMin = 3;
    /*var countryInputMin = 3;//3712*/
    $scope.policyHolderCreate.stateName = '';
    $scope.result = '';

    $scope.textChanged = function (data/*, type*/) {//3712
        /*if(type!=undefined && type === 'state'){//3712*/
            /*CR_NP_0880 Starts */
            $scope.result = 'Please enter valid State by providing at least first 3 characters';
            $scope.showStateError = true;
            if (data != null && data.length >= stateInputMin) {
                return gstStateServiceCall(data);
            }
            /*CR_NP_0880 Ends */
        /* 3712 starts/////////////////
        }
        else if(type!=undefined && type === 'country'){
            $scope.result = 'Please enter valid Country by providing at least first 3 characters';
            $scope.showCountryError = true;
            if (data != null && data.length >= countryInputMin) {
                return gstCountryServiceCall(data);
            }
        }
        //3712 ends//////////*/
    };

    /*///// 3712 Starts /////////
    function gstCountryServiceCall(data) {
        var getStateListInput = {
            "state": data.toUpperCase()
        };
        var getStateListResponse = RestServices.postService(RestServices.urlPathsNewPortal.getStateList, getStateListInput);
        return getStateListResponse.then(function (response) { // success
            CommonServices.showLoading(false);
            $scope.showCountryError = true;
            if (response.data.hasOwnProperty('states')) {
                return $scope.stateList = response.data.states;
            } else {
                $scope.stateList = "";
                $scope.result = "No search results found";
                if (data == null) {
                    $scope.showCountryError = false;
                } else {
                    $scope.showCountryError = true;
                }
                return $scope.stateList;
            }

        }, function (error) {
            CommonServices.showLoading(false);
            RestServices.handleWebServiceError(error);
        });
    };
    ////////3712 Ends /////////*/

    function gstStateServiceCall(data) {
        /*CR_NP_0880 Starts */
        var getStateListInput = {
            "state": data.toUpperCase()
        };
        var getStateListResponse = RestServices.postService(RestServices.urlPathsNewPortal.getStateList, getStateListInput);
        return getStateListResponse.then(function(response) { // success
            CommonServices.showLoading(false);
            $scope.showStateError = true;
            if (response.data.hasOwnProperty('states')) {
                return $scope.stateList = response.data.states;
            } else {
                $scope.stateList = "";
                $scope.result = "No search results found";
                if (data == null) {
                    $scope.showStateError = false;
                } else {
                    $scope.showStateError = true;
                }
                return $scope.stateList;
                /*CR_NP_0880 Ends*/
            }

        }, function(error) {
            CommonServices.showLoading(false);
            RestServices.handleWebServiceError(error);
        });
    };

    $scope.onChange = function (data) {
        /*CR_NP_0880 Starts */

        if(data === 'state'){
            $scope.showStateError = true;
            $scope.showPincodeError = false;
            $scope.showCityError = false;
            $scope.policyHolderCreate.pinCode = "";
            $scope.policyHolderCreate.cityName = "";
            $scope.disablePinCodeInput = true; // To disable Pincode Input
            // $scope.disableCityInput = true; // To disable City Input

        } else if (data === 'pinCode'){
            $scope.showPincodeError = true;
            $scope.showCityError = false;
            $scope.policyHolderCreate.cityName = "";
            // $scope.disableCityInput = true; // To disable City Input

        } else if (data === 'city'){
            $scope.showCityError = true;
        }
        /*CR_NP_0880 Ends */
        /*/3712 starts////////
        else if(data === 'country') {
            $scope.showCountryError = true;
        }
        // 3712 ends */
    };

     /*//// 3712 Start/////////////////////
     $scope.countrySelect = function () {
        $scope.showCountryError = false;
    };
    ///// 3712 End////////////////////*/

    $scope.stateSelect = function () {
         /*CR_NP_0880 start*/
        $scope.showStateError = false;
        $scope.showPincodeError = true;
        $scope.disablePinCodeInput = false;
        $scope.policyHolderCreate.pinCode = "";
        // $scope.gstCityLocation = "";

        var getZipCodeListInput = {
            "state": $scope.policyHolderCreate.stateName.state === undefined ? $scope.policyHolderCreate.stateName : $scope.policyHolderCreate.stateName.state
        };

        var getZipCodeListResponse = RestServices.postService(RestServices.urlPathsNewPortal.getZipCodesbyState, getZipCodeListInput);
        getZipCodeListResponse.then(function(response) {
            CommonServices.showLoading(false);
             if (response.data.hasOwnProperty('pincodes')) {
                $scope.allZipCodeList = response.data.pincodes;
            }

        }, function(error) {
            CommonServices.showLoading(false);
            RestServices.handleWebServiceError(error);
        });
        /*CR_NP_0880 Ends */
//UC for 3749
        // angular.forEach(CommonServices.gstIdStateCode,function(value,key){
        //     if($scope.policyHolderCreate.stateName.state == value){
        //         $scope.gstinMsg = "GSTIN should start with "+key;
        //     }

        // });
        // $scope.onGstIdChange();
    };

     $scope.pincodeSelect = function() {
        $scope.showPincodeError = false;
        $scope.policyHolderForm.pinCode.$setValidity("parse", true);
        /*CR_NP_0880 start*/
        var getCitiesListInput = {
            "state": $scope.policyHolderCreate.stateName.state === undefined ? $scope.policyHolderCreate.stateName : $scope.policyHolderCreate.stateName.state,
            "zipCode": $scope.policyHolderCreate.pinCode,
            //"additionalParameter":"MOBILE",
            "city": ""
        };

        var getCitiesListResponse = RestServices.postService(RestServices.urlPathsNewPortal.getCitiesList, getCitiesListInput);
        getCitiesListResponse.then(function(response) {
            CommonServices.showLoading(false);
            if (response.data.hasOwnProperty('cities')) {
                $scope.cityList = response.data.cities;
                $scope.policyHolderCreate.cityName = response.data.cities[0];
            } else {
                CommonServices.showAlert("Error Occured. Please try again");
            }

        }, function(error) {
            CommonServices.showLoading(false);
            RestServices.handleWebServiceError(error);
        });
        /*CR_NP_0880 Ends */
    };
    
     $scope.citySelect = function(){
         /*CR_NP_0880 start*/
        $scope.showCityError = false;
    };
    /*CR_NP_0880 Ends */

    if ($scope.policyHolderRadio === 'newCustomer') {
        CommonServices.topUpObj.searchBoxEnable = false;
    }

    $scope.newCustomerChanging = function () {
        CommonServices.topUpObj.SelfDOBPolicyHolder = undefined;
        CommonServices.topUpObj.goToMemeberInfoEdit = "NEW";

        $scope.disableInputField = false;
        if ($scope.policyHolderRadio === 'newCustomer') {
            /*Added for CR_NP_0744 starts*/
            $rootScope.policyDetailsObj.panNoInputDisable = false;
            // $rootScope.policyDetailsObj.aadhaarInputDisable = false;
            CommonServices.panNoInputDisable = false;
            // CommonServices.aadhaarInputDisable = false;
            $rootScope.policyDetailsObj.aadhaarNumber1 = "";
            $rootScope.policyDetailsObj.aadhaarNumber2 = "";
            $rootScope.policyDetailsObj.aadhaarNumber3 = "";
            CommonServices.policyHolderType = "newCustomer";
            /*CR_NP_0744 Ends*/
            $scope.pinEnable = true;
            $scope.cityEnable = true;
            $scope.policyHolderCreate.policyHolderName = undefined;
            $scope.policyHolderCreate.policyHolderMidName = undefined;
            $scope.policyHolderCreate.policyHolderLastName = undefined;
            //   $scope.policyHolderCreate.createPolGender = false;
            $scope.policyHolderCreate.createPolGender = "";//CR_3618            $scope.policyHolderCreate.dateOfBirth = undefined;
            $scope.policyHolderCreate.dateOfBirth = undefined;
            /*
            $scope.policyHolderCreate.clientNationality = undefined;//3712
            $scope.policyHolderCreate.clientCountry = undefined;//3712
            */
            $scope.policyHolderCreate.buildingStreet = undefined;
            $scope.policyHolderCreate.gstRegistraionIdType = undefined;
            $scope.policyHolderCreate.gstin = undefined;
            $scope.policyHolderCreate.uin = undefined;
            $scope.policyHolderCreate.stateName = undefined;
            $scope.policyHolderCreate.cityName = undefined;
            $scope.policyHolderCreate.pinCode = undefined;
            $scope.policyHolderCreate.mobile = undefined;
            $scope.policyHolderCreate.email = undefined;
            $scope.policyHolderCreate.pan = undefined;
            $scope.policyHolderCreate.eInsurance = undefined;
            //policy holder got saved so policyHolderInfoEdit assigning to undefined
            CommonServices.topUpObj.policyHolderInfoEdit = undefined;
            CommonServices.topUpObj.searchBoxEnable = false;
            CommonServices.topUpObj.selectPolicyHolder = undefined;
            CommonServices.topUpObj.enableEditModels = undefined;

            // Existing policy holder (search) inputs resetting
            $scope.topUpPolicyHolderSearch.policyHolderCode = undefined;
            $scope.topUpPolicyHolderSearch.policyHolderName = undefined;
            $scope.topUpPolicyHolderSearch.policyHolderLastName = undefined;
            $scope.topUpPolicyHolderSearch.emailId = undefined;
            $scope.topUpPolicyHolderSearch.mobileNum = undefined;
        } else {
            if ($scope.policyHolderRadio === 'existingCustomer') {
                CommonServices.policyHolderType = "existingCustomer";
                CommonServices.topUpObj.policyHolderCreateText = "policyHolderDeleted";
            }

        }
    };


    var mydateStr = new Date();
    var mynewdateFrom = "";
    if (mydateStr != undefined) {
        mynewdateFrom = new Date(mydateStr);
    } else {
        mynewdateFrom = new Date();
    };

    var enableAgefrom;
    if (CommonServices.newIndiaPremierMediclaim.memberCoveredInPolicy === true && $rootScope.productName === "HN") {
        enableAgefrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 46));
    } else if (CommonServices.newIndiaPremierMediclaim.memberCoveredInPolicy === true && $rootScope.productName === "TU") {
        enableAgefrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 51));
    } else {
        enableAgefrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 101));
    }

    var enableAgeTo = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 18));
    enableAgeTo = getFormattedDate(enableAgeTo);

    var TodyasDateFormatToCal = CommonServices.getCommonData("serverDate");

    $scope.dateOfBirth = function () {
        $("#dateOfBirth").loadCalendar({
            'enableDateRange': true,
            'enableCalendarFrom': enableAgefrom,
            'enableCalendarTo': TodyasDateFormatToCal
        });
        return true;
    };

    $scope.policyHldrDateBithChange = function () {
        var policyHldrDateOfBithChanged = $scope.policyHolderCreate.dateOfBirth;
        var arr = policyHldrDateOfBithChanged.split('/');
        policyHldrDateOfBithChanged = arr[1] + '/' + arr[0] + '/' + arr[2]; //mm/dd/yyyy 
        policyHldrDateOfBithChanged = new Date(policyHldrDateOfBithChanged);
        CommonServices.topUpObj.SelfDOBPolicyHolder = $scope.policyHolderCreate.dateOfBirth;//CR747
        var enableToDate = new Date(enableAgeTo);
        if (policyHldrDateOfBithChanged > enableToDate) {
            //alert("Age should be between  18 to 50 Years");

            if (CommonServices.newIndiaPremierMediclaim.memberCoveredInPolicy === true) {//SELF  added
                if ($rootScope.productName === "TU") {
                    CommonServices.showAlert("Age should be between  18 to 50 Years");
                    $scope.policyHolderCreate.dateOfBirth = "";
                }
                else {
                    CommonServices.showAlert("Age should be between  18 to 45 Years");
                    $scope.policyHolderCreate.dateOfBirth = "";
                }

            } else {
                CommonServices.showAlert("Age should be between  18 to 100 Years");
                $scope.policyHolderCreate.dateOfBirth = "";
            }



        } else {
            if ($scope.policyHolderCreate.dateOfBirth !== CommonServices.getCommonData("basicProposerDateOfBith")) {

                if (CommonServices.newIndiaPremierMediclaim.memberCoveredInPolicy === true) {
                    //alert("There is a mismatch between the Date of Birth entered for Proposer and Policy Holder. Please note that the Date of Birth entered in the Policy holder/Personal information shall be considered");
                    CommonServices.showAlert("There is a mismatch between the Date of Birth entered for Proposer and Policy Holder. Please note that the Date of Birth entered in the Policy holder/Personal information shall be considered");
                }


            }
        }
    };

    // Service call policy holder Creation 
    $scope.policyHolderCreatefun = function () {

        if ($rootScope.policyDetailsObj.aadhaarNumber1 !== undefined && $rootScope.policyDetailsObj.aadhaarNumber1 !== "" && $rootScope.policyDetailsObj.aadhaarNumber2 !== undefined && $rootScope.policyDetailsObj.aadhaarNumber2 !== "" && $rootScope.policyDetailsObj.aadhaarNumber3 !== undefined && $rootScope.policyDetailsObj.aadhaarNumber3 !== "") {
            $rootScope.policyDetailsObj.aadhaarNumber = $rootScope.policyDetailsObj.aadhaarNumber1 + $rootScope.policyDetailsObj.aadhaarNumber2 + $rootScope.policyDetailsObj.aadhaarNumber3;
        } else {
            $rootScope.policyDetailsObj.aadhaarNumber = "";
        }
//CR_3618                     "gender": $scope.policyHolderCreate.createPolGender === true ? "F" : "M",
console.log("pol gender policyHolderCreatefun"+$scope.policyHolderCreate.createPolGender);
        var policyHolderCreateInput = {
            "userProfile": {
                "userId": CommonServices.getCommonData("userId"),
                "loggedInRole": "SUPERUSER"
            },
            "partyDetails": {
                "individualDetails": {
                    "title": "",
                    "firstName": $scope.policyHolderCreate.policyHolderName.toUpperCase(),
                    "middleName": $scope.policyHolderCreate.policyHolderMidName !== undefined ? $scope.policyHolderCreate.policyHolderMidName.toUpperCase() : $scope.policyHolderCreate.policyHolderMidName,
                    "lastName": $scope.policyHolderCreate.policyHolderLastName.toUpperCase(),
                    "gender": $scope.policyHolderCreate.createPolGender,//CR_3618 === true ? "F" : "M",
                    "dateOfBirth": $scope.policyHolderCreate.dateOfBirth,
                    /*
                    "clientNationality": $scope.policyHolderCreate.clientNationality,//3712
                    "clientCountryObj": $scope.policyHolderCreate.clientCountry,//3712
                    "clientCountry": $scope.policyHolderCreate.clientCountry.stateCode,//3712
                    */
                    "buildingNoStreet": $scope.policyHolderCreate.buildingStreet.toUpperCase(),
                    "gstRegIdType": $scope.policyHolderCreate.gstRegistraionIdType,
                    "gstin": ($scope.policyHolderCreate.gstin === "" || $scope.policyHolderCreate.gstin === undefined) ? "" : $scope.policyHolderCreate.gstin.toUpperCase(),
                    "uin": $scope.policyHolderCreate.uin,
                    "cityObj": $scope.policyHolderCreate.cityName,
                    "stateObj": $scope.policyHolderCreate.stateName,
                    "pinCode": $scope.policyHolderCreate.pinCode, //CR880
                    "mobileNo": $scope.policyHolderCreate.mobile,
                    "state": $scope.policyHolderCreate.stateName.stateCode,
                    "city": $scope.policyHolderCreate.cityName.cityCode,
                    "emailId": $scope.policyHolderCreate.email,
                    "panNumber": $scope.policyHolderCreate.pan !== undefined ? $scope.policyHolderCreate.pan.toUpperCase() : $scope.policyHolderCreate.pan,
                    "aadhaarNo": $rootScope.policyDetailsObj.aadhaarNumber,
                    "eInsuranceAccountNo": $scope.policyHolderCreate.eInsurance !== undefined ? $scope.policyHolderCreate.eInsurance.toUpperCase() : $scope.policyHolderCreate.eInsurance
                },
                "partyType": "I"
            }

        };


        var policyHolderCreateResponse = RestServices.postService(RestServices.urlPathsNewPortal.topUpcreatePolicyHolder, policyHolderCreateInput);
        policyHolderCreateResponse.then(
            function (response) { // success	
                CommonServices.showLoading(false);
                if (response.data.hasOwnProperty('errorMessage')) {
                    CommonServices.showAlert(response.data.errorMessage);
                } else {
                    CommonServices.topUpObj.createPolicyHolderRes = response.data;
                    CommonServices.topUpObj.policyHolderCreateText = "policyHolderCreated";
                    // $scope.topUpPolicyHolderSearchCall();
                    CommonServices.topUpPolicyHolderSearchCall($scope.policyHolderRadio, $scope.disableInputField);
                }

            },
            function (error) { // failure
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            });

    };

    /*************** policy hoder search details*******************/
    $scope.topUpPolicyHolderSearch = {};

    //reset Policy holder search details 
    $scope.policyHldrReset = function () {

        $scope.topUpPolicyHolderSearch.policyHolderCode = '';
        $scope.topUpPolicyHolderSearch.policyHolderName = '';
        $scope.topUpPolicyHolderSearch.policyHolderLastName = '';
        $scope.topUpPolicyHolderSearch.emailId = '';
        $scope.topUpPolicyHolderSearch.mobileNum = '';

    };

    $scope.policyHolderSearch = function () {
        if ($scope.topUpPolicyHolderSearch.policyHolderCode !== undefined || $scope.topUpPolicyHolderSearch.policyHolderName !== undefined || $scope.topUpPolicyHolderSearch.policyHolderMiddleName !== undefined || $scope.topUpPolicyHolderSearch.policyHolderLastName !== undefined || $scope.topUpPolicyHolderSearch.emailId !== undefined || $scope.topUpPolicyHolderSearch.mobileNum !== undefined) {
            //$scope.topUpPolicyHolderSearchCall();

            CommonServices.topUpObj.PolicyHolderSearchCallInput = {
                policyHolderCode: $scope.topUpPolicyHolderSearch.policyHolderCode,
                policyHolderName: $scope.topUpPolicyHolderSearch.policyHolderName,
                policyHolderMiddleName: $scope.topUpPolicyHolderSearch.policyHolderMiddleName,
                policyHolderLastName: $scope.topUpPolicyHolderSearch.policyHolderLastName,
                emailId: $scope.topUpPolicyHolderSearch.emailId,
                mobileNum: $scope.topUpPolicyHolderSearch.mobileNum
            };


            CommonServices.topUpPolicyHolderSearchCall($scope.policyHolderRadio, $scope.disableInputField);
        } else {

            //alert("Enter minimum one search input criteria.");
            CommonServices.showAlert("Enter minimum one search input criteria.");
        }

    };

   
    if (CommonServices.topUpObj.navigationFrom === "existing" || CommonServices.topUpObj.enableEditModels === "MODELSEDIT") {
        //$scope.editInfo = CommonServices.topUpObj.navigationFrom; 
        $scope.disableInputField = true;
        $scope.disableBackIcon = true;

        if (CommonServices.policyHolderType === "existingCustomer") {
            $scope.policyHolderRadio = "existingCustomer";
        } else {
            $scope.policyHolderRadio = "newCustomer";
        }

        //        if($scope.disableInputField === true){
        //           $scope.policyHolderRadio ="existingCustomer";
        //        }

        //        if(CommonServices.topUpObj.navigationFrom === "existing"){
        //            $scope.policyHolderRadio ="existingCustomer";
        //        }else{
        //             $scope.policyHolderRadio = "newCustomer";
        //            
        //        }

        /*Added for CR_NP_0744*/
        // To set the values on load of the page
        if ($rootScope.policyDetailsObj.panNoInputDisable == undefined || $rootScope.policyDetailsObj.panNoInputDisable == "") {
            $rootScope.policyDetailsObj.panNoInputDisable = CommonServices.panNoInputDisable;
        }
        /*CR_NP_0744E starts*/
        // if($rootScope.policyDetailsObj.aadhaarInputDisable == undefined || $rootScope.policyDetailsObj.aadhaarInputDisable == ""){
        // 	$rootScope.policyDetailsObj.aadhaarInputDisable = CommonServices.aadhaarInputDisable;
        // }
        /*CR_NP_0744 and CR_NP_0744E ends*/

        $scope.pinEnable = false;
        $scope.cityEnable = false;
         //CR_3618
         console.log("newindiatopupmendiclaim within CommonServices.topUpObj.navigationFrom === existing"+ CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.gender);
         //CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.gender === "F" ? true : false
        $scope.policyHolderCreate.policyHolderName = CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.firstName;
        $scope.policyHolderCreate.policyHolderMidName = CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.middleName;
        $scope.policyHolderCreate.policyHolderLastName = CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.lastName;
        $scope.policyHolderCreate.createPolGender = CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.gender;//CR_3618
        $scope.policyHolderCreate.dateOfBirth = CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.dateOfBirth;
        $scope.policyHolderCreate.buildingStreet = CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.buildingNoStreet;
        $scope.policyHolderCreate.gstRegistraionIdType = CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.gstRegIdType === '' ? undefined : CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.gstRegIdType;
        $scope.policyHolderCreate.gstin = CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.gstin === '' ? undefined : CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.gstin;
        $scope.policyHolderCreate.uin = CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.uin === '' ? undefined : CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.uin;
        $scope.policyHolderCreate.stateName = CommonServices.topUpObj.getPolicyholderDetails.stateName === undefined ? undefined : CommonServices.topUpObj.getPolicyholderDetails.stateName.state;
        $scope.policyHolderCreate.cityName = CommonServices.topUpObj.getPolicyholderDetails.cityName === undefined ? undefined : CommonServices.topUpObj.getPolicyholderDetails.cityName.city;
        $scope.policyHolderCreate.pinCode = CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.pinCode === undefined ? undefined : CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.pinCode;
        $scope.policyHolderCreate.mobile = CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.mobileNo;
        $scope.policyHolderCreate.email = CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.emailId;
        /*Changed for CR_NP_0744*/
        if (CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.panNumber !== undefined && CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.panNumber !== ""){// && $rootScope.regexPanNo.test(CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.panNumber)) {
            $scope.policyHolderCreate.pan = CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.panNumber;
        } else {
            $scope.policyHolderCreate.pan = "";
        }

        if($scope.policyHolderCreate.pan != undefined){
            $rootScope.policyDetailsObj.panNoInputDisable = $rootScope.regexPanNo.test($scope.policyHolderCreate.pan.toUpperCase());
        }


        if (CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.aadhaarNo !== undefined && CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.aadhaarNo !== "" && $rootScope.regexAadhaarNumber.test(CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.aadhaarNo)) {
            $rootScope.policyDetailsObj.aadhaarNumber1 = CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.aadhaarNo.substr(0, 4);
            $rootScope.policyDetailsObj.aadhaarNumber2 = CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.aadhaarNo.substr(4, 4);
            $rootScope.policyDetailsObj.aadhaarNumber3 = CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.aadhaarNo.substr(8, 4);
        } else {
            $rootScope.policyDetailsObj.aadhaarNumber1 = "";
            $rootScope.policyDetailsObj.aadhaarNumber2 = "";
            $rootScope.policyDetailsObj.aadhaarNumber1 = "";
        }
        /*CR_NP_0744 ends*/
        $scope.policyHolderCreate.eInsurance = CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.eInsuranceAccountNo;

        $scope.cityList = CommonServices.topUpObj.editCityRes;
        $scope.allZipCodeList = CommonServices.topUpObj.editZipRes;
        /*/3712 Starts////
        // Dummy Data // to be replaced with service response data
        $scope.policyHolderCreate.clientNationality = "NonIndian";
        $scope.policyHolderCreate.clientCountry = "Nepal";

        if($scope.policyHolderCreate.clientNationality = "NonIndian"){
            $scope.isNonIndia = true;
        }else{
            $scope.isNonIndia = false;
        }
        if($scope.policyHolderCreate.clientNationality!=undefined && $scope.policyHolderCreate.clientNationality!=''){
            $scope.isNationalityExists = true;
        }else{
            $scope.isNationalityExists = false;
        }
        if($scope.policyHolderCreate.clientCountry!=undefined && $scope.policyHolderCreate.clientCountry!=''){
            $scope.isCountryExists = true;
        }else{
            $scope.isCountryExists =false;
        }
        //////3712  Ends//////*/

    }

    // update policy holder changes
    $scope.policyHolderSave = function () {

        //CommonServices.topUpObj.saveUpdatePolicyHolder = "Save";
        /*Changed for CR_NP_0744 starts*/
        if ($rootScope.policyDetailsObj.aadhaarNumber1 !== undefined && $rootScope.policyDetailsObj.aadhaarNumber1 !== "" && $rootScope.policyDetailsObj.aadhaarNumber2 !== undefined && $rootScope.policyDetailsObj.aadhaarNumber2 !== "" && $rootScope.policyDetailsObj.aadhaarNumber3 !== undefined && $rootScope.policyDetailsObj.aadhaarNumber3 !== "") {
            $rootScope.policyDetailsObj.aadhaarNumber = $rootScope.policyDetailsObj.aadhaarNumber1 + $rootScope.policyDetailsObj.aadhaarNumber2 + $rootScope.policyDetailsObj.aadhaarNumber3;
        } else {
            $rootScope.policyDetailsObj.aadhaarNumber = "";
        }
        if ($rootScope.policyDetailsObj.panNoInputDisable === true) {
            CommonServices.panNoInputDisable = true;
        }
        // if($rootScope.policyDetailsObj.aadhaarInputDisable === true){
        // 	CommonServices.aadhaarInputDisable = true;
        // }
        /*CR_NP_0744 and CR_NP_0744E ends*/
        var updatePolicyHolderInput = {
            "userCode": CommonServices.getCommonData("userId"),
            "rolecode": "SUPERUSER",
            "policyHolderCode": CommonServices.topUpObj.policyHolderInfoEdit === "policyHolderInfoEdit" ? CommonServices.topUpObj.reviewSummaryResponse.quote.policyHolderCode : CommonServices.topUpObj.EditPolicyHolderCode,
            "mobileNo": $scope.policyHolderCreate.mobile,
            "dateOfBirth": $scope.policyHolderCreate.dateOfBirth,
            /*
            "clientNationality": $scope.policyHolderCreate.clientNationality,//3712
            //"clientCountry": $scope.policyHolderCreate.clientCountry.countryCode,//3712
            "clientCountry": "USA",//3712
            */
            "emailId": $scope.policyHolderCreate.email,
            "gstRegIdType": $scope.policyHolderCreate.gstRegistraionIdType === undefined ? '' : $scope.policyHolderCreate.gstRegistraionIdType,
            "gstin": ($scope.policyHolderCreate.gstin === undefined || $scope.policyHolderCreate.gstin === '') ? '' : $scope.policyHolderCreate.gstin.toUpperCase(),
            "uin": $scope.policyHolderCreate.uin === undefined ? '' : $scope.policyHolderCreate.uin,
            "city": $scope.policyHolderCreate.cityName.cityCode === undefined ? CommonServices.topUpObj.getPolicyholderDetails.cityName.cityCode : $scope.policyHolderCreate.cityName.cityCode,
            "state": $scope.policyHolderCreate.stateName.stateCode === undefined ? CommonServices.topUpObj.getPolicyholderDetails.stateName.stateCode : $scope.policyHolderCreate.stateName.stateCode,
            // "pinCode": $scope.policyHolderCreate.pinCode.zipCode === undefined ? $scope.policyHolderCreate.pinCode : $scope.policyHolderCreate.pinCode.zipCode,
             "pinCode": $scope.policyHolderCreate.pinCode, //CR_NP_0880
            /*Added for CR_NP_0744*/
            "panNumber": $scope.policyHolderCreate.pan,
            "aadhaarNo": $rootScope.policyDetailsObj.aadhaarNumber,
            /*CR_NP_0744 ends*/
            "addressLine1": $scope.policyHolderCreate.buildingStreet !== undefined ? $scope.policyHolderCreate.buildingStreet.toUpperCase() : $scope.policyHolderCreate.buildingStreet
        };

        var updatePolicyHolderRes = RestServices.postService(RestServices.urlPathsNewPortal.updatePolicyHolderContact, updatePolicyHolderInput);
        updatePolicyHolderRes.then(
            function (response) { // success	
                CommonServices.showLoading(false);
                if (response.data.hasOwnProperty('footer')) {
                    //alert(response.data.footer.errorDescription);
                    CommonServices.showAlert(response.data.footer.errorDescription);
                } else {

                    if (response.data.hasOwnProperty('errorMessage')) {
                        //alert(response.data.errorMessage);
                        CommonServices.showAlert(response.data.errorMessage);
                    } else {
                        CommonServices.topUpObj.updatePolicyHolderRes = response.data
                        //policy holder got saved so policyHolderInfoEdit assigning to undefined
                        CommonServices.topUpObj.policyHolderInfoEdit = undefined;
                        CommonServices.topUpObj.searchBoxEnable = false;
                        //$scope.topUpPolicyHolderSearchCall();
                        CommonServices.topUpPolicyHolderSearchCall($scope.policyHolderRadio, $scope.disableInputField);
                    }
                }
            },
            function (error) { // failure
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            });
    };

    // when user coming from the selected policy hoder radio button clicks

    if (CommonServices.topUpObj.selectPolicyHolder !== undefined) {
        $scope.policyHolderRadio = CommonServices.topUpObj.selectPolicyHolder;
    }

}]);
agentApp.controller('policyHolderSearchCtrl', ['$scope', 'RestServices', 'CommonServices', '$state', '$rootScope', function ($scope, RestServices, CommonServices, $state, $rootScope) {

    $scope.goBack = function () {
        CommonServices.topUpObj.enableEditModels = undefined;
        CommonServices.topUpObj.navigationFrom = undefined;
        CommonServices.topUpObj.goToMemeberInfoEdit = "NEW";
        CommonServices.backFromPolSearch = true; //CR_NP_0880
        $rootScope.policyDetailsObj = {};
        if (CommonServices.editQuoteFlag === true) {
            $state.go("topUpBasicPremiumScreen");
        } else {
            if (CommonServices.topUpObj.searchBoxEnable === true) {
                $state.go("topUpBasicPremiumScreen");
            } else {
                $state.go("policyHolderDetailsScreen");
            }
        }

    };


    $scope.searchBoxEnable = CommonServices.topUpObj.searchBoxEnable;
    $scope.searchHeading = CommonServices.topUpObj.policyHolderCreateText;

    if (CommonServices.editQuoteFlag === true) {
        $scope.editQouteFlag = true;
    }


    $scope.policyHolderSearchResult = CommonServices.topUpObj.policyHolderSearchRes.partyDetailsList;

    $rootScope.userClickedOnDiv = function (index) {
        CommonServices.backFromPolSearch = true; //CR_NP_0880
        if (CommonServices.topUpObj.policyHolderInfoEdit !== "policyHolderInfoEdit") {
            CommonServices.topUpObj.EditPolicyHolderCode = $scope.policyHolderSearchResult[index].partyCode;
        }

        var topUpGetPolicyHolderDetailInput = {
            "userProfile": {
                "userId": CommonServices.getCommonData("userId"),
                "loggedInRole": "SUPERUSER"
            },
            "partyDetails": {
                "partyCode": CommonServices.topUpObj.policyHolderInfoEdit === "policyHolderInfoEdit" ? CommonServices.topUpObj.reviewSummaryResponse.quote.policyHolderCode : $scope.policyHolderSearchResult[index].partyCode
            }
        };
        var topUpGetPolicyHolderDetailResponse = RestServices.postService(RestServices.urlPathsNewPortal.getPolicyHolderDetail, topUpGetPolicyHolderDetailInput);
        topUpGetPolicyHolderDetailResponse.then(
            function (response) { // success	
                CommonServices.showLoading(false);
                CommonServices.topUpObj.getPolicyholderDetails = response.data;
                /*Added for CR_NP_0744*/
                if (CommonServices.policyHolderType === "existingCustomer") {
                    /*Below line added, because for Existing Customer new customer radio button is selected.*/
                    $scope.policyHolderRadio = "existingCustomer";
                    //To set the initial value of PAN and Aadhaar Numbers
                    if ($scope.policyHolderSearchResult[index] !== undefined && $scope.policyHolderSearchResult[index] !== "") {
                        if (CommonServices.initialPartyCodeTU != $scope.policyHolderSearchResult[index].partyCode) { //If party code is changed
                            CommonServices.initialPanNumberIsEmptyTU = false;
                            /*Below line commented for CR_NP_0744E */
                            //   CommonServices.initialAadhaarNoIsEmptyTU = false;
                        }
                        CommonServices.initialPartyCodeTU = $scope.policyHolderSearchResult[index].partyCode;
                    }

                    //For PAN Number
                    if (response.data.partyDetails.individualDetails.panNumber != undefined && response.data.partyDetails.individualDetails.panNumber != "" && $rootScope.regexPanNo.test(response.data.partyDetails.individualDetails.panNumber.toUpperCase())) {
                        $rootScope.policyDetailsObj.panNoInputDisable = true;
                        if (CommonServices.initialPanNumberIsEmptyTU == true) {
                            $rootScope.policyDetailsObj.panNoInputDisable = false;
                        }
                    } else {
                        $rootScope.policyDetailsObj.panNoInputDisable = false;
                        CommonServices.initialPanNumberIsEmptyTU = true;
                    }
                    //For Aadhaar Number
                    /*CR_NP_0744E starts */
                    //   if(response.data.partyDetails.individualDetails.aadhaarNo != undefined && response.data.partyDetails.individualDetails.aadhaarNo != "" && $rootScope.regexAadhaarNumber.test(response.data.partyDetails.individualDetails.aadhaarNo)){
                    // 		$rootScope.policyDetailsObj.aadhaarInputDisable = true;
                    // 		if(CommonServices.initialAadhaarNoIsEmptyTU == true){
                    // 			$rootScope.policyDetailsObj.aadhaarInputDisable = false;
                    // 		}
                    // 	}else{
                    // 		$rootScope.policyDetailsObj.aadhaarInputDisable = false;
                    // 		CommonServices.initialAadhaarNoIsEmptyTU = true;
                    // 	}

                } else {
                    /*Below line added to set the value of Radio button*/
                    $scope.policyHolderRadio = "newCustomer";
                    CommonServices.policyHolderType = "newCustomer";
                    $rootScope.policyDetailsObj.panNoInputDisable = false;
                    //   $rootScope.policyDetailsObj.aadhaarInputDisable = false;
                }
                /*CR_NP_0744 and CR_NP_0744E ends*/
                stateServiceCall();

            },
            function (error) { // failure
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            });

        $scope.selectedPolicyHolderDetails = $scope.policyHolderSearchResult[index];
        $scope.selectedDivYes = true;
    };


    function stateServiceCall() {
        var getStateInput = {
            "state": ""
        };

        var GetStateListResponse = RestServices.postService(RestServices.urlPathsNewPortal.getStateList, getStateInput);
        GetStateListResponse.then(
            function (response) { // success	
                CommonServices.showLoading(false);
                if (response.data.hasOwnProperty('states')) {
                    $scope.stateList = response.data.states;

                    if (CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.state === undefined) {
                        //State is not saved for policy holder
                        CommonServices.topUpObj.navigationFrom = "existing";
                        $state.go("policyHolderDetails");
                    } else {
                        for (var i = 0; i < $scope.stateList.length; i++) {
                            if ($scope.stateList[i].stateCode === CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.state) {
                                CommonServices.topUpObj.getPolicyholderDetails.stateName = $scope.stateList[i];
                                /*CR_NP_0880 Starts */
                                $scope.zipCodeServiceCall();
                                // $scope.cityServicecall();
                                /*CR_NP_0880 Ends */
                            }
                        }
                    }
                }
            },
            function (error) { // failure
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            });
    };

    /*CR_NP_0880 Starts */
    $scope.zipCodeServiceCall = function () {

        var getZipCodeListInput = {
            "state": CommonServices.topUpObj.getPolicyholderDetails.stateName.state,
            // "city": CommonServices.topUpObj.getPolicyholderDetails.cityName.city,
            "zipCode": ""
        }

        var getZipCodeResponse = RestServices.postService(RestServices.urlPathsNewPortal.getZipCodesbyState, getZipCodeListInput);
        getZipCodeResponse.then(
            function (response) { // success	
                CommonServices.showLoading(false);
                if (response.data.hasOwnProperty('pincodes')) {
                    $scope.allZipCodeList = response.data.pincodes;
                    CommonServices.topUpObj.editZipRes = $scope.allZipCodeList;
                    CommonServices.topUpObj.navigationFrom = "existing";

                    for(var i = 0; i<$scope.allZipCodeList.length; i++){
                        if($scope.allZipCodeList[i] == CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.pinCode){
                            CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.pinCode = $scope.allZipCodeList[i];
                            $scope.cityServicecall();
                        }

                    }
                    // if (CommonServices.topUpObj.policyHolderInfoEdit === "policyHolderInfoEdit") {
                    //     CommonServices.topUpObj.enableEditModels = "MODELSEDIT";
                    // }
                    // console.log($rootScope.policyDetailsObj);
                    // $state.go("policyHolderDetails");

                }
            },
            function (error) { // failure
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            });
    };



    $scope.cityServicecall = function () {
        var getCityInput = {
            "state": CommonServices.topUpObj.getPolicyholderDetails.stateName.state,
            "zipCode": CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.pinCode,
            "city": ""
        };

        var GetCityListResponse = RestServices.postService(RestServices.urlPathsNewPortal.getCitiesList, getCityInput);
        GetCityListResponse.then(
            function (response) { // success	
                CommonServices.showLoading(false);
                if (response.data.hasOwnProperty('cities')) {
                    $scope.cityList = response.data.cities;
                    // $scope.cityList = response.data.cities.sort(CommonServices.sort_by('city', response.data.cities, ''));
                    CommonServices.topUpObj.editCityRes = $scope.cityList;
                    CommonServices.topUpObj.getPolicyholderDetails.cityName = response.data.cities[0];
                    CommonServices.topUpObj.navigationFrom = "existing";

                    // for (var i = 0; i < $scope.cityList.length; i++) {
                    //     if ($scope.cityList[i].cityCode === CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.city) {
                    //         CommonServices.topUpObj.getPolicyholderDetails.cityName = $scope.cityList[i];
                    //         $scope.zipCodeServiceCall();

                    //     }
                    // }

                    
                    if (CommonServices.topUpObj.policyHolderInfoEdit === "policyHolderInfoEdit") {
                        CommonServices.topUpObj.enableEditModels = "MODELSEDIT";
                    }
                    console.log($rootScope.policyDetailsObj);
                    $state.go("policyHolderDetails");

                }

            },
            function (error) { // failure
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            });
    };
    /*CR_NP_0880 Ends */

    $scope.userSelectOnDiv = function (index) {

        CommonServices.topUpObj.saveQuotePolicyHolderCode = $scope.policyHolderSearchResult[index].partyCode;
        CommonServices.setCommonData("partyCode", $scope.policyHolderSearchResult[index].partyCode);

        var topUpGetPolicyHolderDetailInput = {
            "userProfile": {
                "userId": CommonServices.getCommonData("userId"),
                "loggedInRole": "SUPERUSER"
            },
            "partyDetails": {
                "partyCode": $scope.policyHolderSearchResult[index].partyCode
            }
        };
        var topUpGetPolicyHolderDetailResponse = RestServices.postService(RestServices.urlPathsNewPortal.getPolicyHolderDetail, topUpGetPolicyHolderDetailInput);
        topUpGetPolicyHolderDetailResponse.then(
            function (response) { // success	
                CommonServices.showLoading(false);
                if (response.data.hasOwnProperty('errorMessage')) {
                    CommonServices.showAlert(response.data.errorMessage);
                } else {

                    CommonServices.topUpObj.getPolicyholderDetails = response.data;

                    if (CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.dateOfBirth !== undefined) {
                        CommonServices.topUpObj.SelfDOBPolicyHolder = CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.dateOfBirth;

                        var proposerAgeCalculation = CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.dateOfBirth;
                        var Arr = proposerAgeCalculation.split('/');
                        proposerAgeCalculation = Arr[2] + '/' + Arr[1] + '/' + Arr[0]; //mm/dd/yyyy
                        var date = new Date(proposerAgeCalculation);
                        var ageDifMs = Date.now() - date.getTime();
                        var ageDinYrs = new Date(ageDifMs); // miliseconds from epoch
                        ageDinYrs = Math.abs(ageDinYrs.getUTCFullYear() - 1970);
                        ageDinYrs = ageDinYrs.toString();

                    }

                    for (var i = 0; i < CommonServices.topUpObj.addedMebersDetails.length; i++) {
                        if (CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder === "SELF" || CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder === "Proposer") {
                            CommonServices.topUpObj.addedMebersDetails[i].riskDetails.dateOfBirth = CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.dateOfBirth;
                            CommonServices.topUpObj.addedMebersDetails[i].riskDetails.ageInYrs = ageDinYrs;
                        }
                    }

                    if (CommonServices.topUpObj.policyHolderCreateText !== "policyHolderCreated") {


                        if (CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.hasOwnProperty('dateOfBirth')) {

                            if (CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.state === undefined || CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.city === undefined || CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.pinCode === undefined) {
                                CommonServices.showAlert("Please update mandatory Policy Holder Details");
                            } else {
                                if (CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.dateOfBirth !== CommonServices.getCommonData("basicProposerDateOfBith")) {
                                    
                                        var mydateStr = new Date();
                                        var mynewdateFrom = new Date(mydateStr);
                                    
                                    if ($rootScope.productName === 'HN' ) {
                                        var enableAgefrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 46));
                                        
                                        if (date < enableAgefrom) {
                                            CommonServices.showAlert("Age of policy holder should be between 18 and 45 years.");
                                        }else{
                                           
                                             if (CommonServices.newIndiaPremierMediclaim.memberCoveredInPolicy === true) {
                                        //alert("There is a mismatch between the Date of Birth entered for Proposer and Policy Holder. Please note that the Date of Birth entered in the Policy holder/Personal information shall be considered");
                                        CommonServices.showAlert("There is a mismatch between the Date of Birth entered for Proposer and Policy Holder. Please note that the Date of Birth entered in the Policy holder/Personal information shall be considered");

                                        }
                                            $state.go("proposerDetails");  
                                            
                                            
                                        }
                                        

                                        }else{
                                            
                                          var enableAgefrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 51));
                                            
                                            var proposerEnableAgeTo = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 18));
                                              if (CommonServices.newIndiaPremierMediclaim.memberCoveredInPolicy === true) {
													if (date < enableAgefrom ) {
														CommonServices.showAlert("Age of policy holder should be between 18 and 50 years.");
													}else if(date > proposerEnableAgeTo){
														  CommonServices.showAlert("Age of policy holder should be between 18 and 50 years.");
													}
													else{
                                                     $state.go("proposerDetails");
													} 
											  }else{
                                              $state.go("proposerDetails");   
                                            }
   
                                        }
              
                                } else {
                                    $state.go("proposerDetails");
                                }

                            }

                        } else {
                            // alert("Age of policy holder should be between 18 and 50 years.");

                            if ($rootScope.productName === 'HN') {
                                CommonServices.showAlert("Age of policy holder should be between 18 and 45 years.");
                            } else {
                                CommonServices.showAlert("Age of policy holder should be between 18 and 50 years.");
                            }

                        }

                    } else {
                        $state.go("proposerDetails");
                    }
                }



            },
            function (error) { // failure
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            });

    };

    $scope.policyHolderSelected = {
        policyHldr: ""
    };


    $scope.BackTonewCustomerChanging = function () {

        CommonServices.topUpObj.goToMemeberInfoEdit = "NEW";
        CommonServices.topUpObj.navigationFrom = undefined;
        CommonServices.topUpObj.enableEditModels = undefined;
        CommonServices.topUpObj.searchBoxEnable = false;

        if ($scope.policyHolderSelected.policyHldr === 'newCustomerback') {
            CommonServices.topUpObj.selectPolicyHolder = "newCustomer";
        } else {
            CommonServices.topUpObj.selectPolicyHolder = "existingCustomer";

        }
        $state.go("policyHolderDetails");
    };


}]);


agentApp.controller('proposerDetailsCtrl', ['$scope', '$rootScope', 'RestServices', 'CommonServices', '$state', function ($scope, $rootScope, RestServices, CommonServices, $state) {
    $scope.iDDocNoRegexPattern = iDDocNoRegexGlobal;
    $scope.isNIAPAN = false;//CR3746
    $scope.isValidPAN = false;
    console.log("3746 " + !($scope.isValidPAN));

    $scope.onIDTypeSelect = function (index) {
        $scope.additionalDetailsArray[index].iDDocNo="";
                                             
        // console.log("Test 1234 " + $scope.additionalDetailsArray[index].natureOfId);

        // Uncomment for CR_3746
        // if($scope.additionalDetailsArray[index].natureOfId == "PAN" || $scope.additionalDetailsArray[index].natureOfId == "PANCard" || $scope.additionalDetailsArray[index].natureOfId == "PAN Card"){
        //     $scope.iDDocNoRegexPattern = regexPanNoGlobal;
        //     if($scope.existingPanNo != undefined && $scope.additionalDetailsArray[index].relationshipWith.toUpperCase() ==='PROPOSER'){// 3746 autopopulate starts
        //         $scope.additionalDetailsArray[index].iDDocNo = $scope.existingPanNo;
        //     }// 3746 autopopulate ends
        // }
        // else
        {
            $scope.iDDocNoRegexPattern = iDDocNoRegexGlobal;
            $scope.isNIAPAN = false;
        }
    };

    $scope.onIDDocNoChange = function (index,idNo){
        // // uncomment for 3746
        // if($scope.additionalDetailsArray[index].natureOfId == "PAN"){
        //     $scope.additionalDetailsArray[index].iDDocNo = $scope.additionalDetailsArray[index].iDDocNo!=undefined? $scope.additionalDetailsArray[index].iDDocNo.toUpperCase(): undefined;
        //     var docNo = $scope.additionalDetailsArray[index].iDDocNo;
        //     $scope.existingPanNo = undefined;// 3746 autopopulate

        //     if(docNo != undefined){
        //         if(docNo.length==10){
        //                 $scope.isValidPAN =  (regexPanNoGlobal.test(docNo.toUpperCase()));
                        
        //                 $scope.isNIAPAN = isNIAPANNo($scope.additionalDetailsArray[index].iDDocNo);
        //         }else{
        //             $scope.isValidPAN = false;
        //             $scope.isNIAPAN = false;
        //         }
        //     }else
        //     $scope.isNIAPAN = false;
        // }
        // console.log("is pan valid " +docNo+" "+ $scope.isValidPAN);
    };

    /*CR 3712 starts
	$scope.isNonIndia = false;
	// $scope.additionalDetailsArray[i].clientNationality ="";
	$scope.onNationalityChange = function(i){
		$scope.additionalDetailsArray[i].clientCountry = '';
		if($scope.additionalDetailsArray[i].clientNationality == "NonIndian"){
			$scope.isNonIndia = true;
		}
		else{
			$scope.isNonIndia = false;
		}
	}
    // CR_3712 ends*/

    $scope.onChange = function (data) {
        /*/3712 ////////
        if(data === 'country') {
            $scope.showCountryError = true;
        }
        //////3712 ends //*/
    };

    /*//// 3712 Start/////////////////////
    $scope.countrySelect = function () {
        $scope.showCountryError = false;
    };
    ///// 3712 End////////////////////*/

    /*var countryInputMin = 3;//3712*/

    $scope.textChanged = function (data/*,type*/) {//3712
       
        /*/3712 starts/////////////////
        if(type!=undefined && type === 'country'){
            $scope.result = 'Please enter valid Country by providing at least first 3 characters';
            $scope.showCountryError = true;
            if (data != null && data.length >= countryInputMin) {
                return gstCountryServiceCall(data);
            }
        }
        //3712 ends//////////*/
    };

    /*///// 3712 ///////
    function gstCountryServiceCall(data) {
        var getStateListInput = {
            "state": data.toUpperCase()
        };
        var getStateListResponse = RestServices.postService(RestServices.urlPathsNewPortal.getStateList, getStateListInput);
        return getStateListResponse.then(function (response) { // success
            CommonServices.showLoading(false);
            $scope.showCountryError = true;
            if (response.data.hasOwnProperty('states')) {
                return $scope.stateList = response.data.states;
            } else {
                $scope.stateList = "";
                $scope.result = "No search results found";
                if (data == null) {
                    $scope.showCountryError = false;
                } else {
                    $scope.showCountryError = true;
                }
                return $scope.stateList;
            }

        }, function (error) {
            CommonServices.showLoading(false);
            RestServices.handleWebServiceError(error);
        });
    };
    ////////3712 ////////*/
    $scope.valeOccupationOfProposer = function () {
        for (var i = 0; i < $scope.additionalDetailsArray.length; i++) {
            if ($rootScope.productName === "TU") {
                if ($scope.additionalDetailsArray[i].occupation !== "OTHERS") {
                    $scope.additionalDetailsArray[i].anyOther = undefined;
                }
            } else {
                if ($scope.additionalDetailsArray[i].occupation !== "AO") {
                    $scope.additionalDetailsArray[i].anyOther = undefined;
                }

            }

        }

    };

    $scope.riskDeatilsForSaveQuote = [];
    $scope.proposerDeatils = [];

    $scope.additionalDetailsArray = [];

    var proposerGender, childrenCount = 0;
    var varForLoopgen = 0;

    /**CR747 starts**/
    if($rootScope.productName === "TU"){
    if (CommonServices.newIndiaPremierMediclaim.memberCoveredInPolicy === false && CommonServices.topUpObj.typeOfCover === "FLOATER") {
        varForLoopgen = varForLoopgen + 1;
            } 
    }else{
      if(CommonServices.newIndiaPremierMediclaim.memberCoveredInPolicy === false){
               varForLoopgen = varForLoopgen +1;
            }  
    }
    /**CR747 ends**/
    //CommonServices.topUpObj.numberOfMembers = (CommonServices.topUpObj.addedMebersDetails).length;
    varForLoopgen = varForLoopgen + CommonServices.topUpObj.numberOfMembers;

    for (var i = 0; i < varForLoopgen; i++) {

        // console.log(CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.gender);
        //  console.log(CommonServices.topUpObj.addedMebersDetails[i].riskDetails);
         //console.log(CommonServices.topUpObj.reviewSummaryResponse.additionalDetailsArray[i]);
         //before third gender CR_3618
         //gender:(CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() ==='SELF' && CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.gender ==='F')?true:false,
       
        if ($rootScope.productName === "TU") {


            if (CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder === "CHILDREN") {
                childrenCount = childrenCount + 1;
            }

            $scope.additionalDetailsArray.push({
            name:CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() ==='SELF'?CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.firstName+" "+CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.lastName:(CommonServices.editQuoteFlag === true && CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder !=='SELF' && CommonServices.topUpObj.premiumCalResponse.premiumDetails.serviceTax !== undefined)?CommonServices.topUpObj.premiumCalResponse.risks[i].riskDetails.nameOfInsuredPerson:(CommonServices.editQuoteFlag === false && CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder !=='SELF' && CommonServices.topUpObj.reviewSummaryResponse !== undefined && CommonServices.topUpObj.reviewSummaryResponse.additionalDetailsArray[i] !== undefined) ? CommonServices.topUpObj.reviewSummaryResponse.additionalDetailsArray[i].name:"",
            relationshipWith:CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase(),
			occupation:(CommonServices.editQuoteFlag === true && CommonServices.topUpObj.premiumCalResponse.premiumDetails.serviceTax !== undefined)?CommonServices.topUpObj.premiumCalResponse.risks[i].riskDetails.occupation :(CommonServices.editQuoteFlag === false && CommonServices.topUpObj.reviewSummaryResponse !== undefined && CommonServices.topUpObj.reviewSummaryResponse.additionalDetailsArray[i] !== undefined)? CommonServices.topUpObj.reviewSummaryResponse.additionalDetailsArray[i].occupation:"",
            anyOther: (CommonServices.editQuoteFlag === true && CommonServices.topUpObj.premiumCalResponse.premiumDetails.serviceTax !== undefined)?CommonServices.topUpObj.premiumCalResponse.risks[i].riskDetails.ifAnyOtherOccupation :(CommonServices.editQuoteFlag === false && CommonServices.topUpObj.reviewSummaryResponse !== undefined && CommonServices.topUpObj.reviewSummaryResponse.additionalDetailsArray[i] !== undefined) ?CommonServices.topUpObj.reviewSummaryResponse.additionalDetailsArray[i].anyOther:undefined,
            gender:CommonServices.topUpObj.addedMebersDetails[i].riskDetails.dependentType ==='UD'? 'F':(CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() ==='SELF') ? CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.gender : (CommonServices.topUpObj.addedMebersDetails[i].riskDetails !== undefined) ? CommonServices.topUpObj.addedMebersDetails[i].riskDetails.sex : "",//tempGender,
            headerName:(CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() ==='SELF' && CommonServices.newIndiaPremierMediclaim.memberCoveredInPolicy === false) ? "Policy holder/Proposer details":(CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase()  ==='SELF' && CommonServices.newIndiaPremierMediclaim.memberCoveredInPolicy === true) ? "Proposer":
			CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder ==='SPOUSE'?"Spouse":
			(CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder ==="CHILDREN" && childrenCount == 1)?"Child 1":
			(CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder ==="CHILDREN" && childrenCount == 2)?"Child 2":
			(CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder ==="CHILDREN" && childrenCount == 3)?"Child 3":
			(CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder ==="CHILDREN" && childrenCount == 4)?"Child 4":
			(CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder ==="CHILDREN" && childrenCount == 5)?"Child 5":"Child 6",
            fileDisable:CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() ==='SELF'?true:CommonServices.topUpObj.addedMebersDetails[i].riskDetails.dependentType ==='UD'?true:false,
            nameFileDisable:CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() ==='SELF'?true:CommonServices.topUpObj.addedMebersDetails[i].riskDetails.nameFileDisable === true ? true : false,
            dependentType:CommonServices.topUpObj.addedMebersDetails[i].riskDetails.dependentType,
            /*
            clientNationality: undefined,//3712
            clientCountry: undefined,//3712
            isNationalityExists: false,//3712
            isCountryExists: false//3712
            */
        });
            
         //CR_3618
        //fileDisable:CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() ==='SELF'?true:CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder ==='SPOUSE'?true:CommonServices.topUpObj.addedMebersDetails[i].riskDetails.dependentType ==='UD'?true:false,

            //sourav 3618 commented as it is no longer valid after third gender
        //    if($scope.additionalDetailsArray[i].relationshipWith ==='SELF' && $scope.additionalDetailsArray[i].gender ===true){
        //      proposerGender = true;
        //   } 
        proposerGender = CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.gender;//tempGender;
        // } 

        } else {
            if (CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder === "Children") {
                childrenCount = childrenCount + 1;
            }
            /*Added for CR_NP_0744E */
            if (CommonServices.editQuoteFlag === true && CommonServices.newIndiaPremierMediclaim.premiumCalResponse.premiumDetails.serviceTax !== undefined) {
                CommonServices.newIndiaPremierMediclaim.premiumCalResponse.risks[i].riskDetails.aadhaarChangeMessage = "";
                if (CommonServices.newIndiaPremierMediclaim.premiumCalResponse.risks[i].riskDetails.natureOfId === "AADHAR") {
                    CommonServices.newIndiaPremierMediclaim.premiumCalResponse.risks[i].riskDetails.aadhaarChangeMessage = "Due to regulatory constraint Aadhaar document cannot be taken online. Please select other available ID";
                    CommonServices.newIndiaPremierMediclaim.premiumCalResponse.risks[i].riskDetails.natureOfId = "";
                    CommonServices.newIndiaPremierMediclaim.premiumCalResponse.risks[i].riskDetails.iDDocNo = "";
                }
            }
            //(CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder === 'Proposer' && CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.gender === 'F') ? true : false,
            $scope.additionalDetailsArray.push({
                name: CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder === 'Proposer' ? CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.firstName + " " + CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.lastName : (CommonServices.editQuoteFlag === true && CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder !== 'Proposer' && CommonServices.newIndiaPremierMediclaim.premiumCalResponse.premiumDetails.serviceTax !== undefined) ? CommonServices.newIndiaPremierMediclaim.premiumCalResponse.risks[i].riskDetails.nameOfInsuredPerson : (CommonServices.editQuoteFlag === false && CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder !== 'Proposer' && CommonServices.topUpObj.reviewSummaryResponse !== undefined && CommonServices.topUpObj.reviewSummaryResponse.additionalDetailsArray[i] !== undefined) ? CommonServices.topUpObj.reviewSummaryResponse.additionalDetailsArray[i].name : "", relationshipWith: CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder,
                occupation: (CommonServices.editQuoteFlag === true && CommonServices.newIndiaPremierMediclaim.premiumCalResponse.premiumDetails.serviceTax !== undefined) ? CommonServices.newIndiaPremierMediclaim.premiumCalResponse.risks[i].riskDetails.occupation : (CommonServices.editQuoteFlag === false && CommonServices.topUpObj.reviewSummaryResponse !== undefined && CommonServices.topUpObj.reviewSummaryResponse.additionalDetailsArray[i] !== undefined) ? CommonServices.topUpObj.reviewSummaryResponse.additionalDetailsArray[i].occupation : "",
                anyOther: (CommonServices.editQuoteFlag === true && CommonServices.newIndiaPremierMediclaim.premiumCalResponse.premiumDetails.serviceTax !== undefined) ? CommonServices.newIndiaPremierMediclaim.premiumCalResponse.risks[i].riskDetails.ifAnyOtherOccupation : (CommonServices.editQuoteFlag === false && CommonServices.topUpObj.reviewSummaryResponse !== undefined && CommonServices.topUpObj.reviewSummaryResponse.additionalDetailsArray[i] !== undefined) ? CommonServices.topUpObj.reviewSummaryResponse.additionalDetailsArray[i].anyOther : undefined,
                gender: CommonServices.topUpObj.addedMebersDetails[i].riskDetails.dependentType ==='UD'? 'F':(CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder === 'Proposer') ? CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.gender : (CommonServices.topUpObj.addedMebersDetails[i].riskDetails !== undefined) ? CommonServices.topUpObj.addedMebersDetails[i].riskDetails.sex : "",//tempGender,
                headerName: (CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder === 'Proposer' && CommonServices.newIndiaPremierMediclaim.memberCoveredInPolicy === false) ? "Policy holder/Proposer details" : (CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder === 'Proposer' && CommonServices.newIndiaPremierMediclaim.memberCoveredInPolicy === true) ? "Proposer" : CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder === 'Spouse' ? "Spouse" : (CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder === "Children" && childrenCount == 1) ? "Child 1" : (CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder === "Children" && childrenCount == 2) ? "Child 2" : (CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder === "Children" && childrenCount == 3) ? "Child 3" : (CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder === "Children" && childrenCount == 4) ? "Child 4" : "Child 5",
                fileDisable: CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder === 'Proposer' ? true: CommonServices.topUpObj.addedMebersDetails[i].riskDetails.dependentType === 'UD' ? true : false,
                nameFileDisable: CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder === 'Proposer' ? true : false,
                dependentType: CommonServices.topUpObj.addedMebersDetails[i].riskDetails.dependentType,
                height: (CommonServices.editQuoteFlag === true && CommonServices.newIndiaPremierMediclaim.premiumCalResponse.premiumDetails.serviceTax !== undefined) ? CommonServices.newIndiaPremierMediclaim.premiumCalResponse.risks[i].riskDetails.height : (CommonServices.editQuoteFlag === false && CommonServices.topUpObj.reviewSummaryResponse !== undefined && CommonServices.topUpObj.reviewSummaryResponse.additionalDetailsArray[i] !== undefined) ? CommonServices.topUpObj.reviewSummaryResponse.additionalDetailsArray[i].height : "",
                weight: (CommonServices.editQuoteFlag === true && CommonServices.newIndiaPremierMediclaim.premiumCalResponse.premiumDetails.serviceTax !== undefined) ? CommonServices.newIndiaPremierMediclaim.premiumCalResponse.risks[i].riskDetails.weight : (CommonServices.editQuoteFlag === false && CommonServices.topUpObj.reviewSummaryResponse !== undefined && CommonServices.topUpObj.reviewSummaryResponse.additionalDetailsArray[i] !== undefined) ? CommonServices.topUpObj.reviewSummaryResponse.additionalDetailsArray[i].weight : "",
                natureOfId: (CommonServices.editQuoteFlag === true && CommonServices.newIndiaPremierMediclaim.premiumCalResponse.premiumDetails.serviceTax !== undefined) ? CommonServices.newIndiaPremierMediclaim.premiumCalResponse.risks[i].riskDetails.natureOfId : (CommonServices.editQuoteFlag === false && CommonServices.topUpObj.reviewSummaryResponse !== undefined && CommonServices.topUpObj.reviewSummaryResponse.additionalDetailsArray[i] !== undefined) ? CommonServices.topUpObj.reviewSummaryResponse.additionalDetailsArray[i].natureOfId : "",
                anyOtherId: (CommonServices.editQuoteFlag === true && CommonServices.newIndiaPremierMediclaim.premiumCalResponse.premiumDetails.serviceTax !== undefined) ? CommonServices.newIndiaPremierMediclaim.premiumCalResponse.risks[i].riskDetails.anyOtherId : (CommonServices.editQuoteFlag === false && CommonServices.topUpObj.reviewSummaryResponse !== undefined && CommonServices.topUpObj.reviewSummaryResponse.additionalDetailsArray[i] !== undefined) ? CommonServices.topUpObj.reviewSummaryResponse.additionalDetailsArray[i].anyOtherId : "",
                iDDocNo: (CommonServices.editQuoteFlag === true && CommonServices.newIndiaPremierMediclaim.premiumCalResponse.premiumDetails.serviceTax !== undefined) ? CommonServices.newIndiaPremierMediclaim.premiumCalResponse.risks[i].riskDetails.iDDocNo : (CommonServices.editQuoteFlag === false && CommonServices.topUpObj.reviewSummaryResponse !== undefined && CommonServices.topUpObj.reviewSummaryResponse.additionalDetailsArray[i] !== undefined) ? CommonServices.topUpObj.reviewSummaryResponse.additionalDetailsArray[i].iDDocNo : "",
                aadhaarChangeMessage: (CommonServices.editQuoteFlag === true && CommonServices.newIndiaPremierMediclaim.premiumCalResponse.premiumDetails.serviceTax !== undefined) ? CommonServices.newIndiaPremierMediclaim.premiumCalResponse.risks[i].riskDetails.aadhaarChangeMessage : "",
                /*
                clientNationality: undefined,//3712
                clientCountry: undefined,//3712
                isNationalityExists: false,//3712
                isCountryExists: false//3712
                */
            });
            /*CR_NP_0744E ends */

            // if ($scope.additionalDetailsArray[i].relationshipWith === 'Proposer' && $scope.additionalDetailsArray[i].gender === true) {
            //     proposerGender = true;
            // }
            proposerGender = CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.gender;


 	/* Start of CR 3746 autopopulate*/  //Uncomment for CR_3746
 	// if(CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder === 'Proposer' || CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder === 'Self'){
    // 		$scope.existingPanNo = CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.panNumber;
	// }
	/* End of CR 3746 autopopulate*/

        }
        /*/////// 3712 starts/////
        if(CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SELF' || CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'PROPOSER'){
            //Dummy data
            CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.clientNationality = 'NonIndian';
            CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.clientCountry = 'Bhutan';

            //enabling nationality and country fields
            $scope.additionalDetailsArray[i].isNationalityExists = false;
            $scope.additionalDetailsArray[i].isCountryExists = false;

            if(CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.clientNationality!=undefined && CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.clientNationality!=""){
                //disabling nationality fields
                $scope.additionalDetailsArray[i].isNationalityExists = true;
            }

            if(CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.clientCountry!=undefined && CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.clientCountry!=""){
                //disabling country fields
                $scope.additionalDetailsArray[i].isCountryExists = true;
            }

            $scope.additionalDetailsArray[i].clientNationality = CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.clientNationality;
            $scope.additionalDetailsArray[i].clientCountry = CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.clientCountry;

        }else{
            //enabling nationality and country fields
            $scope.additionalDetailsArray[i].isNationalityExists = false;
            $scope.additionalDetailsArray[i].isCountryExists = false;
        }
        //////// 3712 Ends ////*/
    }
    /** CR747 STARTS**/
    if (CommonServices.topUpObj.typeOfCover === "INDIVIDUAL" && CommonServices.newIndiaPremierMediclaim.memberCoveredInPolicy === false) {
        proposerGender = CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.gender === 'F' ? true : false;

    }
    /**CR747 ENDS**/

    // for (var i = 0; i < $scope.additionalDetailsArray.length; i++) {
    //     if ($rootScope.productName === "TU") {

    //         if ($scope.additionalDetailsArray[i].relationshipWith === 'SPOUSE') {
    //             if (proposerGender === true) {
    //                 $scope.additionalDetailsArray[i].gender = false;
    //             } else {
    //                 $scope.additionalDetailsArray[i].gender = true;
    //             }
    //         }

    //         if ($scope.additionalDetailsArray[i].dependentType === 'UD') {
    //             $scope.additionalDetailsArray[i].gender = true;
    //         }

    //     } else {

    //         if ($scope.additionalDetailsArray[i].relationshipWith === 'Spouse') {
    //             if (proposerGender === true) {
    //                 $scope.additionalDetailsArray[i].gender = false;
    //             } else {
    //                 $scope.additionalDetailsArray[i].gender = true;
    //             }
    //         }

    //         if ($scope.additionalDetailsArray[i].dependentType === 'UD') {
    //             $scope.additionalDetailsArray[i].gender = true;
    //         }

    //     }
    // }
    CommonServices.topUpObj.additionalArray = $scope.additionalDetailsArray;

    console.log($scope.additionalDetailsArray);
    console.log(CommonServices.topUpObj);

    // };      
    $scope.direction = 'right';
    $scope.currentIndex = 0;

    $scope.setCurrentSlideIndex = function (index) {
        $scope.direction = (index > $scope.currentIndex) ? 'left' : 'right';
        $scope.currentIndex = index;
    };

    $scope.isCurrentSlideIndex = function (index) {
        return $scope.currentIndex === index;
    };

    $scope.prevSlide = function (index) {
        $scope.direction = 'left';
        //            $scope.currentIndex = ($scope.currentIndex < $scope.additionalDetailsArray.length - 1) ? ++$scope.currentIndex : 0;
        if (index > 0) {
            $scope.currentIndex = index - 1;
        } else {
            //$scope.additionalDetailsArray = [];
            CommonServices.topUpObj.searchBoxEnable = true;
            // $state.go("searchPolicyHolderScreen");
            CommonServices.topUpObj.PolicyHolderSearchCallInput = undefined;
            CommonServices.floaterObj.policyHolderCode = CommonServices.topUpObj.saveQuotePolicyHolderCode;
            CommonServices.topUpPolicyHolderSearchCall();
        }
    };

    $scope.nextSlide = function (index) {
        $scope.direction = 'right';
        //            $scope.currentIndex = ($scope.currentIndex > 0) ? --$scope.currentIndex : $scope.additionalDetailsArray.length - 1;
        $scope.currentIndex = index + 1;

        if ($scope.currentIndex === $scope.additionalDetailsArray.length) {
            for (var i = 0; i < CommonServices.topUpObj.addedMebersDetails.length; i++) {
                if ($rootScope.productName === "TU") {
                    /*CR747 start*/
                    if ($scope.additionalDetailsArray[i].headerName === "Policy holder/Proposer details" && CommonServices.topUpObj.typeOfCover !== "INDIVIDUAL") {
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder = "SELF";
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.nameOfInsuredPerson = $scope.additionalDetailsArray[i].name.toUpperCase();
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.occupation = $scope.additionalDetailsArray[i].occupation;
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.ifAnyOtherOccupation = $scope.additionalDetailsArray[i].anyOther;
						/* CommonServices.topUpObj.addedMebersDetails[i].riskDetails.riskSumInsured=;
						CommonServices.topUpObj.addedMebersDetails[i].riskDetails.dateOfBirth=;
						CommonServices.topUpObj.addedMebersDetails[i].riskDetails.ageInYrs=;
						CommonServices.topUpObj.addedMebersDetails[i].riskDetails.thresholdLimit=; */
                       // CommonServices.topUpObj.addedMebersDetails[i].riskDetails.sex = $scope.additionalDetailsArray[i].gender === true ? "F" : "M";
                       CommonServices.topUpObj.addedMebersDetails[i].riskDetails.sex = $scope.additionalDetailsArray[i].gender;
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.riskParty = CommonServices.topUpObj.saveQuotePolicyHolderCode,
                            CommonServices.topUpObj.addedMebersDetails[i].riskDetails.dependent = "N";
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.startDtOfMember = null;
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.dependentType = "NORM";
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.doYouChewTobacco = "N";
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.doYouSmoke = "N";
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.doYouDrinkAlcohol = "N";
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.adverseMedicialHistory = "N";
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.previousPolicyDetails = {
                            "whetherYouHadAHealthPolicyInThePast": "N",
                            "previousClaimOrHospitalisation": null,
                            "claimAmountReceived": null
                        }
                        $scope.proposerDeatils.push(CommonServices.topUpObj.addedMebersDetails[i]);
                        CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk = $scope.proposerDeatils;

                    }
                    /*CR747 end*/
				 else
				{
							if(CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder ==='SELF' && CommonServices.topUpObj.typeOfCover === "INDIVIDUAL" && CommonServices.newIndiaPremierMediclaim.memberCoveredInPolicy === false){
							CommonServices.topUpObj.addedMebersDetails[i].riskParty = CommonServices.topUpObj.saveQuotePolicyHolderCode;  
							CommonServices.topUpObj.addedMebersDetails[i].riskDetails.dependent="N";
							CommonServices.topUpObj.addedMebersDetails[i].riskDetails.dependentType="NORM";

                        }

                        if (CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder === 'SPOUSE') {

                            CommonServices.topUpObj.addedMebersDetails[i].riskDetails.dependent = "N";
                            CommonServices.topUpObj.addedMebersDetails[i].riskDetails.dependentType = "NORM";

                        }

                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.nameOfInsuredPerson = $scope.additionalDetailsArray[i].name.toUpperCase();
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.occupation = $scope.additionalDetailsArray[i].occupation;
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.ifAnyOtherOccupation = $scope.additionalDetailsArray[i].anyOther;
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.sex = $scope.additionalDetailsArray[i].gender;// === true ? "F" : "M";
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.areYouEarningHeadOfFamily = "N";
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.doYouChewTobacco = "N";
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.doYouSmoke = "N";
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.doYouDrinkAlcohol = "N";
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.adverseMedicialHistory = "N";
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.previousPolicyDetails = {
                            "whetherYouHadAHealthPolicyInThePast": "N",
                            "previousClaimOrHospitalisation": null,
                            "claimAmountReceived": null
                        }
                        $scope.riskDeatilsForSaveQuote.push(CommonServices.topUpObj.addedMebersDetails[i]);

                        CommonServices.newIndiaPremierMediclaim.riskDeatilsForSaveQuote = $scope.riskDeatilsForSaveQuote;
                    }

                } else {

                    if ($scope.additionalDetailsArray[i].headerName === "Policy holder/Proposer details") {

                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.nameOfInsuredPerson = $scope.additionalDetailsArray[i].name.toUpperCase();
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.occupation = $scope.additionalDetailsArray[i].occupation;
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.ifAnyOtherOccupation =
                            $scope.additionalDetailsArray[i].occupation === "AO" ? $scope.additionalDetailsArray[i].anyOther : null;
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.sex = $scope.additionalDetailsArray[i].gender === true ? "F" : "M";
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.height = "0";
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.weight = "0";
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.natureOfId = $scope.additionalDetailsArray[i].natureOfId;
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.anyOtherId =
                            $scope.additionalDetailsArray[i].natureOfId === "OTHER" ? $scope.additionalDetailsArray[i].anyOtherId : null;
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.iDDocNo = $scope.additionalDetailsArray[i].iDDocNo;
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.riskParty = CommonServices.topUpObj.saveQuotePolicyHolderCode,


                            //CommonServices.topUpObj.addedMebersDetails[i].riskDetails.preExistingDisease ="N";
                            CommonServices.topUpObj.addedMebersDetails[i].riskDetails.doYouChewTobacco = "N";
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.doYouSmoke = "N";
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.doYouDrinkAlcohol = "N";
                        //                  CommonServices.topUpObj.addedMebersDetails[i].riskDetails.adverseMedicialHistory ="N";
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.document = {};

                        $scope.proposerDeatils.push(CommonServices.topUpObj.addedMebersDetails[i]);
                        CommonServices.newIndiaPremierMediclaim.proposerDeatislRisk = $scope.proposerDeatils;

                    } else {
                        if (CommonServices.topUpObj.addedMebersDetails[i].riskDetails.relationWithPolicyHolder === 'Proposer') {
                            CommonServices.topUpObj.addedMebersDetails[i].riskParty = CommonServices.topUpObj.saveQuotePolicyHolderCode;
                        }

                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.nameOfInsuredPerson = $scope.additionalDetailsArray[i].name.toUpperCase();
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.occupation = $scope.additionalDetailsArray[i].occupation;
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.ifAnyOtherOccupation =
                            $scope.additionalDetailsArray[i].occupation === "AO" ? $scope.additionalDetailsArray[i].anyOther : null;
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.sex = $scope.additionalDetailsArray[i].gender;// === true ? "F" : "M";
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.height = $scope.additionalDetailsArray[i].height;
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.weight = $scope.additionalDetailsArray[i].weight;
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.natureOfId = $scope.additionalDetailsArray[i].natureOfId;
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.anyOtherId =
                            $scope.additionalDetailsArray[i].natureOfId === "OTHER" ? $scope.additionalDetailsArray[i].anyOtherId : null;
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.iDDocNo = $scope.additionalDetailsArray[i].iDDocNo;

                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.preExistingDisease = "N";
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.doYouChewTobacco = "N";
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.doYouSmoke = "N";
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.doYouDrinkAlcohol = "N";
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.adverseMedicialHistory = "N";
                        CommonServices.topUpObj.addedMebersDetails[i].riskDetails.document = {};

                        $scope.riskDeatilsForSaveQuote.push(CommonServices.topUpObj.addedMebersDetails[i]);

                        CommonServices.newIndiaPremierMediclaim.riskDeatilsForSaveQuote = $scope.riskDeatilsForSaveQuote;

                    }


                }

            }

            CommonServices.topUpObj.localStorageVAlues = $scope.additionalDetailsArray;

            $state.go("policyPeriodAndNomineeDetails");
        }
    };


    if (CommonServices.topUpObj.goToMemeberInfoEdit === "proposerDetailsEdit") {
        $scope.additionalDetailsArray = CommonServices.topUpObj.localStorageVAlues;

    }

    //BMI calculation

    $scope.weightKgChange = function (index) {
        var BMI = 0.0;
        var height = 0.0;
        var weight = 0.0;

        if ($scope.additionalDetailsArray[index].height != undefined && $scope.additionalDetailsArray[index].height != '' && $scope.additionalDetailsArray[index].weight !== undefined && $scope.additionalDetailsArray[index].weight !== '') {

            height = parseFloat($scope.additionalDetailsArray[index].height);
            weight = parseFloat($scope.additionalDetailsArray[index].weight);

            BMI = weight/(height * height);

           //BMI = weight / BMI;
        }

        if (BMI > 32) {
            $scope.additionalDetailsArray[index].errorWeight = true;
            //          $scope[proposerDetailsForm]["weight"+index].$setValidity("weight", false);
        } else {
            $scope.additionalDetailsArray[index].errorWeight = false;
            //          $scope[proposerDetailsForm]["weight"+index].$setValidity("weight", true);
        }


    };

 /*CR 3562 START*/
 $scope.prevNomineeDetailObj = CommonServices.getCommonData('paPolicyAutopopulatedData');
 var occupationObj = {};
 if ($rootScope.productName === "TU" && $scope.prevNomineeDetailObj != undefined) {
     var tempCopy = angular.copy($scope.additionalDetailsArray);
     var tempPrevNomineeDetailObj = angular.copy($scope.prevNomineeDetailObj.children);
    //  angular.forEach($scope.additionalDetailsArray, function(value, i) 
    {
        let i =0;
        
            
            if (($scope.additionalDetailsArray[i].relationshipWith.toUpperCase() === 'PROPOSER') || ($scope.additionalDetailsArray[i].relationshipWith.toUpperCase() === 'SELF')){ 
                $scope.additionalDetailsArray[i].relationshipWith = 'SELF'; 
                $scope.additionalDetailsArray[i].name = $scope.prevNomineeDetailObj.proposer!= undefined? $scope.prevNomineeDetailObj.proposer.name: $scope.additionalDetailsArray[i].name;
                $scope.additionalDetailsArray[i].gender = $scope.prevNomineeDetailObj.proposer!= undefined? $scope.prevNomineeDetailObj.proposer.sex: $scope.additionalDetailsArray[i].gender;
                $scope.additionalDetailsArray[i].occupation =  $scope.prevNomineeDetailObj.proposer!= undefined? $scope.prevNomineeDetailObj.proposer.occupation: $scope.additionalDetailsArray[i].occupation;
                i++;
            }
            if ((i < $scope.additionalDetailsArray.length) && ($scope.additionalDetailsArray[i].relationshipWith.toUpperCase() === 'SPOUSE')){ 
                $scope.additionalDetailsArray[i].relationshipWith = 'SPOUSE'; 
                $scope.additionalDetailsArray[i].name = $scope.prevNomineeDetailObj.spouse!=undefined? $scope.prevNomineeDetailObj.spouse.name: $scope.additionalDetailsArray[i].name;
                $scope.additionalDetailsArray[i].gender = $scope.prevNomineeDetailObj.spouse!=undefined? $scope.prevNomineeDetailObj.spouse.sex: $scope.additionalDetailsArray[i].gender;
                $scope.additionalDetailsArray[i].occupation =  $scope.prevNomineeDetailObj.spouse!=undefined? $scope.prevNomineeDetailObj.spouse.occupation: $scope.additionalDetailsArray[i].occupation;
                i++;
            }
            angular.forEach(tempPrevNomineeDetailObj, function(obj, j) {
            if (obj.relation.toUpperCase() === 'CHILD' || obj.relation.toUpperCase() === 'CHILDREN') obj.relation = 'CHILDREN';
             if (tempCopy[i+j].assigned === undefined && obj.assigned === undefined && obj.isSelected && $scope.additionalDetailsArray[i+j].relationshipWith === obj.relation) {
                 $scope.additionalDetailsArray[i+j].occupation = obj.occupation;
                 $scope.additionalDetailsArray[i+j].name = obj.name;
                 if($scope.additionalDetailsArray[i+j].dependentType != "UD")
                    $scope.additionalDetailsArray[i+j].gender = obj.sex;
                 tempCopy[i+j].assigned = true;
                 obj.assigned = true;
                 return;
             }
         });
     }
    //  );
 }
 /*CR 3562 END*/

}]);


agentApp.controller('policyPeriodAndNomineeDetailsCtrl', ['$scope', 'RestServices', 'CommonServices', '$state', '$rootScope', function ($scope, RestServices, CommonServices, $state, $rootScope) {

    $scope.goBack = function () {
        CommonServices.topUpObj.goToMemeberInfoEdit = "proposerDetailsEdit";
        $state.go("proposerDetails");
    };
    $scope.nomineeDtls = {
        relationshipWithNominee: ""
    }

    $scope.typeOfLogin = CommonServices.getCommonData("stakeCode");

    var policyStartDate = $rootScope.productName === "TU" ? CommonServices.topUpObj.policyStartDate : CommonServices.newIndiaPremierMediclaim.policyStartDate;
    $scope.policyEndDate = $rootScope.productName === "TU" ? CommonServices.topUpObj.policyEndDate : CommonServices.newIndiaPremierMediclaim.policyEndDate;



    var arr = policyStartDate.split('/');
    policyStartDate = arr[0] + '/' + arr[1] + '/' + arr[2]; //dd/mm/yyyy
    $scope.policyStartDate = policyStartDate;



    // var saveQuoteInpuCollections = CommonServices.topUpObj;

    //CR 3845
    $scope.getTPAList = function(){
        
        let reqData = {
            "userCode": CommonServices.getCommonData("userId"),
            "stakeCode": CommonServices.getCommonData("stakeCode").toUpperCase(),
            // "stateCode" : CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.state,
            branchCode: CommonServices.getCommonData("LoginData").branchCode,
            "quoteNumber" : null
        }

        let getTPAListResponse = RestServices.postService(RestServices.urlPathsNewPortal.getTPAList, reqData);
        getTPAListResponse.then(
            function (response) { //success
                $scope.tpaList = [];
                CommonServices.showLoading(false);
                if (response.data.hasOwnProperty('errorMessage')) {
                    CommonServices.showLoading(false);
                    CommonServices.showAlert(response.data.errorMessage);
                } else {
                   $scope.tpaList = response.data.tpaList;
                   if(CommonServices.floaterObj && CommonServices.floaterObj.selectedTPA){
                       $scope.nomineeDtls.tpaDetails = CommonServices.floaterObj.selectedTPA;
                   }else{
                        $scope.tpaList.forEach(item=>{
                            if(item.indicator==='Y') $scope.nomineeDtls.tpaDetails = item.tpaCode;
                        });
                   }
                }

            }, function (error) { //failure
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            }
        );

    }
    $scope.getTPAList();

    $rootScope.saveQuote = function () {
        CommonServices.editSaveQuote = false;
        var topUpGetSaveQuoteInput;
        CommonServices.topUpObj.nomineeNameSaveQuote = $scope.nomineeDetalisName.toUpperCase();
        CommonServices.topUpObj.relationshipWithNomineSaveQuote = $scope.nomineeDtls.relationshipWithNominee;
        CommonServices.topUpObj.tpaDetails = $scope.tpaList.filter(item=> item.tpaCode===$scope.nomineeDtls.tpaDetails)[0]; //CR3845
        CommonServices.floaterObj.selectedTPA = CommonServices.topUpObj.tpaDetails.tpaCode;
        if ($rootScope.productName === "HN") {

            var premiumDetails = {
                "grossPremium": CommonServices.newIndiaPremierMediclaim.premiumCalResponse.premiumDetails.grossPremium !== undefined ? CommonServices.newIndiaPremierMediclaim.premiumCalResponse.premiumDetails.grossPremium : undefined,
                "netPremium": CommonServices.newIndiaPremierMediclaim.premiumCalResponse.premiumDetails.netPremium !== undefined ? CommonServices.newIndiaPremierMediclaim.premiumCalResponse.premiumDetails.netPremium : undefined,
                "noOfMembers": CommonServices.newIndiaPremierMediclaim.numberOfMembers,
                "sumInsured": CommonServices.newIndiaPremierMediclaim.sumInsured
            };

            CommonServices.newIndiaPremierMediclaim.premium = premiumDetails;

        }

        localStorage.setItem("NomineeName", $scope.nomineeDetalisName);
        localStorage.setItem("relationshipWithNominee", $scope.nomineeDtls.relationshipWithNominee);
        CommonServices.topUpObj.goToNomineeInfoEdit = "policyPeriodAndNomineeEdit";

        CommonServices.saveQuoteHealth();


    };


    $scope.nextBtnPolicyPeriods = function () {
        localStorage.setItem("NomineeName", $scope.nomineeDetalisName);
        localStorage.setItem("relationshipWithNominee", $scope.nomineeDtls.relationshipWithNominee);
        CommonServices.topUpObj.goToNomineeInfoEdit = "policyPeriodAndNomineeEdit";
        $state.go("topUpRelationalDetails");
    };

    if (CommonServices.topUpObj.goToNomineeInfoEdit === "policyPeriodAndNomineeEdit") {
        $scope.nomineeDetalisName = localStorage.getItem("NomineeName");
        $scope.nomineeDtls.relationshipWithNominee = localStorage.getItem("relationshipWithNominee");
    }

    if($rootScope.productName ==="HN"){
        
        if(CommonServices.editQuoteFlag === true && CommonServices.newIndiaPremierMediclaim.premiumCalResponse.premiumDetails.serviceTax !== undefined){
            $scope.nomineeDetalisName = CommonServices.floaterObj.nomineeDetails.name;  
            if(CommonServices.floaterObj.nomineeDetails.relationshipWithInsured === 'SPOUSE' || CommonServices.floaterObj.nomineeDetails.relationshipWithInsured ==='FATHER' || CommonServices.floaterObj.nomineeDetails.relationshipWithInsured ==='MOTHER' || CommonServices.floaterObj.nomineeDetails.relationshipWithInsured ==='DAUGHTER' || CommonServices.floaterObj.nomineeDetails.relationshipWithInsured ==='SON'){
            $scope.nomineeDtls.relationshipWithNominee = CommonServices.floaterObj.nomineeDetails.relationshipWithInsured;
            }else{
            $scope.nomineeDtls.relationshipWithNominee = undefined;
            }
        }
        
    }else{
        
        if(CommonServices.editQuoteFlag === true && CommonServices.topUpObj.premiumCalResponse.premiumDetails.serviceTax !== undefined){
            $scope.nomineeDetalisName = CommonServices.floaterObj.nomineeDetails.name;  
            if(CommonServices.floaterObj.nomineeDetails.relationshipWithInsured === 'spouse' || CommonServices.floaterObj.nomineeDetails.relationshipWithInsured ==='father' || CommonServices.floaterObj.nomineeDetails.relationshipWithInsured ==='mother' || CommonServices.floaterObj.nomineeDetails.relationshipWithInsured ==='daughter' || CommonServices.floaterObj.nomineeDetails.relationshipWithInsured ==='son' || CommonServices.floaterObj.nomineeDetails.relationshipWithInsured ==='others'){
            $scope.nomineeDtls.relationshipWithNominee = CommonServices.floaterObj.nomineeDetails.relationshipWithInsured;
            }else{
            $scope.nomineeDtls.relationshipWithNominee = undefined;
            }
        }
        
    }

}]);




agentApp.controller('topUpRelationDetailsCtrl', ['$scope', 'RestServices', 'CommonServices', '$state', '$rootScope', function ($scope, RestServices, CommonServices, $state, $rootScope) {

    $scope.agentModels = {};

    $scope.isAgentRequired = true;

    $scope.goBack = function () {
        $state.go("policyPeriodAndNomineeDetails");
    };

    $scope.selectedRadioYes = false; // popup variable

    //service call
    $scope.topUpAgentList = function (index) {

        var getAgentListTUInput = {
            "userProfile": {
                "userId": CommonServices.getCommonData("userId"),
                "loggedInRole": "SUPERUSER"
            },
            partyDetails: {
                partyType: "I"
            }
        };


        var getAgentListTUResponse = RestServices.postService(RestServices.urlPathsNewPortal.getAgentList, getAgentListTUInput);
        getAgentListTUResponse.then(
            function (response) { //success

                CommonServices.showLoading(false);
                if (response.data.hasOwnProperty('errorMessage')) {
                    CommonServices.showLoading(false);
                    CommonServices.showAlert(response.data.errorMessage);
                } else {
                    $scope.relatedAgentsOfLoggedInDevOffTU = response.data.partyDetailsList;
                    //CommonServices.setCommonData("topUpAgentSearchResults", response.data.partylist);
                    //$state.go('gsAdditionalDetails');
                }

            }, function (error) { //failure
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            }
        );
    };

    $scope.agentRequiredRadio = function (index) {
        $scope.selectedAgentPartyCode = $scope.relatedAgentsOfLoggedInDevOffTU[index].partyCode;
        $scope.selectedAgentPartyName = $scope.relatedAgentsOfLoggedInDevOffTU[index].partyName;
        $scope.selectedAgentAddress = $scope.relatedAgentsOfLoggedInDevOffTU[index].address;
        $scope.selectedRadioYes = true;
    };



    $scope.agentRequired = function () {
        if ($scope.agentModels.topUpRelationalDetailsRadio === 'yes') {
            $scope.isAgentRequired = false;
        } else {
            $scope.isAgentRequired = true;
        }
    }


    $scope.topUpRelationalDetailsEdit = function () {
        $scope.isAgentRequired = false;
        $scope.agentModels.topUpRelationalDetailsRadio = 'yes';
        $scope.topUpAgentList();
        $scope.selectedRadioYes = false;
    };

    $scope.relationSearchClose = function () {
        $scope.selectedAgentPartyCode = undefined;
        $scope.selectedRadioYes = false;
        $scope.agentModels.topUpRelationalDetailsRadio = false;
        //$scope.isAgentRequired = true;
        $scope.agentModels.topUpRelationalDetailsRadio = 'no';
    };

    $scope.saveQuote = function () {
        $scope.isAgentDetails = [];

        $scope.isAgentDetails.push({
            "partyCode": $scope.selectedAgentPartyCode,
            "partyStakeCode": "AGENT",
            "partyName": $scope.selectedAgentPartyName,
            "address": $scope.selectedAgentAddress
        });

        CommonServices.topUpObj.isAgentDetails = $scope.selectedAgentPartyCode === undefined ? undefined : $scope.isAgentDetails;
        //localStorage.setItem();
        $rootScope.saveQuote();


    };
    if (CommonServices.topUpObj.goToRelationInfoEdit === "relationInfoEdit") {

        if (CommonServices.topUpObj.reviewSummaryResponse.quote.partyDetailsList === undefined) {
            $scope.selectedRadioYes = false;
            $scope.agentModels.topUpRelationalDetailsRadio = false;
            //$scope.isAgentRequired = true;
            $scope.agentModels.topUpRelationalDetailsRadio = 'no';
            $scope.selectedAgentPartyCode = undefined;

        } else {
            $scope.selectedAgentPartyCode = CommonServices.topUpObj.reviewSummaryResponse.quote.partyDetailsList[0].partyCode;
            $scope.selectedAgentPartyName = CommonServices.topUpObj.reviewSummaryResponse.quote.partyDetailsList[0].partyName;
            $scope.selectedAgentAddress = CommonServices.topUpObj.reviewSummaryResponse.quote.partyDetailsList[0].address;

            //$scope.isAgentRequired = false;
            //$scope.agentModels.topUpRelationalDetailsRadio ='yes';
            //$scope.topUpAgentList();
            $scope.selectedRadioYes = true;
        }


    }

    if (CommonServices.editQuoteFlag === true) {

        var checkSateCodeAgent = false;

        for (var i = 0; i < CommonServices.floaterObj.partyDetailsList.length; i++) {
            if (CommonServices.floaterObj.partyDetailsList[i].stakeCode === "AGENT") {
                $scope.selectedAgentPartyCode = CommonServices.floaterObj.partyDetailsList[i].partyCode;
                $scope.selectedAgentPartyName = CommonServices.floaterObj.partyDetailsList[i].partyName;
                $scope.selectedAgentAddress = CommonServices.floaterObj.partyDetailsList[i].address;
                checkSateCodeAgent = true;
            }
        }

        if (checkSateCodeAgent === true) {
            $scope.selectedRadioYes = true;
        } else {
            $scope.selectedRadioYes = false;
        }

    }

}]);


agentApp.controller('reviewSummaryCtrl', ['$scope', 'RestServices', 'CommonServices', '$state', '$rootScope', 'CartServices', function ($scope, RestServices, CommonServices, $state, $rootScope, CartServices) {


    //    $scope.goBack=function(){
    //        
    //        if(CommonServices.getCommonData("stakeCode") ==='DEVLP-OFF'){
    //                $state.go("topUpRelationalDetails");
    //        }else{
    //            CommonServices.topUpObj.goToNomineeInfoEdit = "policyPeriodAndNomineeEdit"
    //            $state.go("policyPeriodAndNomineeDetails");   
    //        }
    //        
    //    };



    $scope.typeOfLogin = CommonServices.getCommonData("stakeCode");



    $scope.policyStartDate = $rootScope.productName === "TU" ? CommonServices.topUpObj.policyStartDate : CommonServices.topUpObj.reviewSummaryResponse.quote.policyStartDate;
    $scope.poliyEndDate = $rootScope.productName === "TU" ? CommonServices.topUpObj.policyEndDate : CommonServices.topUpObj.reviewSummaryResponse.quote.policyExpiryDate;

    $scope.topUpBreakupClickSummary = function () {

        var topUpViewBreakUPInput = {
            "header": null,
            "quote": {
                "quoteNumber": CommonServices.topUpObj.reviewSummaryResponse.quote.quoteNumber,
                "policyHolderCode": CommonServices.topUpObj.reviewSummaryResponse.quote.policyHolderCode,
                "productCode": $rootScope.productName === "HN" ? $rootScope.productName : undefined
            }
        };

        var topUpViewBreakUpResponse = RestServices.postService(RestServices.urlPathsNewPortal.healthViewBreakup, topUpViewBreakUPInput);
        topUpViewBreakUpResponse.then(
            function (response) { // success 

                CommonServices.showLoading(false);

                CommonServices.topUpObj.viewBreakUpResponse = response.data.quote;
                CommonServices.topUpObj.viewBreakUpNavigation = "ViewBreakupSummary";
                $state.go("topUpViewBreakupScreen");
            },
            function (error) { // failure
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            });
    };

    $scope.reviewSummaryObj = {};


    $scope.reviewSummaryObj = CommonServices.topUpObj.reviewSummaryResponse;
    $scope.reviewSummaryObj.selectedPolicyHolderInfo = CommonServices.topUpObj.getPolicyholderDetails;
    $scope.reviewSummaryObj.additionalDetailsArray = CommonServices.topUpObj.additionalArray;
    $scope.reviewSummaryObj.otherTopUpObj = CommonServices.topUpObj;
    $scope.reviewSummaryObj.tpaDetails = CommonServices.topUpObj.tpaDetails;
    $scope.reviewSummaryObj.agentdetails = CommonServices.topUpObj.reviewSummaryResponse.quote.partyDetailsList;
    /*
    $scope.reviewSummaryObj.selectedPolicyHolderInfo.partyDetails.individualDetails.clientNationality = 'NonIndian'; //3712
    $scope.reviewSummaryObj.selectedPolicyHolderInfo.partyDetails.individualDetails.clientCountry = 'Australia'; //3712
    */
    /* Starts 3712 ///
    for (var i = 0; i < $scope.reviewSummaryObj.quote.risks.length; i++) {
        $scope.reviewSummaryObj.quote.risks[i].riskDetails.clientNationality = 'NonIndian'+i;
        $scope.reviewSummaryObj.quote.risks[i].riskDetails.clientCountry = 'Australia'+i;
    }
    /// Ends 3712 */

    var childCount = 0;
    for (var i = 0; i < $scope.reviewSummaryObj.quote.risks.length; i++) {

        if ($scope.reviewSummaryObj.quote.risks[i].riskDetails.relationWithPolicyHolder === "CHILDREN" || $scope.reviewSummaryObj.quote.risks[i].riskDetails.relationWithPolicyHolder === "Children") {
            childCount = childCount + 1;
        }

        if ($scope.reviewSummaryObj.quote.risks[i].riskDetails.relationWithPolicyHolder === 'SELF' || $scope.reviewSummaryObj.quote.risks[i].riskDetails.relationWithPolicyHolder === 'Proposer') {
            $scope.reviewSummaryObj.quote.risks[i].riskDetails.policyHolder = "Proposer";
        } else if ($scope.reviewSummaryObj.quote.risks[i].riskDetails.relationWithPolicyHolder === 'SPOUSE' || $scope.reviewSummaryObj.quote.risks[i].riskDetails.relationWithPolicyHolder === 'Spouse') {
            $scope.reviewSummaryObj.quote.risks[i].riskDetails.policyHolder = "Spouse";
        } else {
            if (($scope.reviewSummaryObj.quote.risks[i].riskDetails.relationWithPolicyHolder === "CHILDREN" || $scope.reviewSummaryObj.quote.risks[i].riskDetails.relationWithPolicyHolder === "Children") && (childCount === 1)) {
                $scope.reviewSummaryObj.quote.risks[i].riskDetails.policyHolder = "Child 1";
            } else if (($scope.reviewSummaryObj.quote.risks[i].riskDetails.relationWithPolicyHolder === "CHILDREN" || $scope.reviewSummaryObj.quote.risks[i].riskDetails.relationWithPolicyHolder === "Children") && (childCount === 2)) {
                $scope.reviewSummaryObj.quote.risks[i].riskDetails.policyHolder = "Child 2";
            } else if (($scope.reviewSummaryObj.quote.risks[i].riskDetails.relationWithPolicyHolder === "CHILDREN" || $scope.reviewSummaryObj.quote.risks[i].riskDetails.relationWithPolicyHolder === "Children") && (childCount === 3)) {
                $scope.reviewSummaryObj.quote.risks[i].riskDetails.policyHolder = "Child 3";
            } else if (($scope.reviewSummaryObj.quote.risks[i].riskDetails.relationWithPolicyHolder === "CHILDREN" || $scope.reviewSummaryObj.quote.risks[i].riskDetails.relationWithPolicyHolder === "Children") && (childCount === 4)) {
                $scope.reviewSummaryObj.quote.risks[i].riskDetails.policyHolder = "Child 4";
            }
            else if (($scope.reviewSummaryObj.quote.risks[i].riskDetails.relationWithPolicyHolder === "CHILDREN" || $scope.reviewSummaryObj.quote.risks[i].riskDetails.relationWithPolicyHolder === "Children") && (childCount === 5)) {
                $scope.reviewSummaryObj.quote.risks[i].riskDetails.policyHolder = "Child 5";
            }
            else {
                $scope.reviewSummaryObj.quote.risks[i].riskDetails.policyHolder = "Child 6";
            }
        }
    }



    $scope.approvePay = function (type = '') {
        var messageSystemDate = CommonServices.getCommonData("serverDate");
        var arr = messageSystemDate.split('/');
        messageSystemDate = arr[1] + '/' + arr[0] + '/' + arr[2]; //mm/dd/yyyy 
        CommonServices.setCommonData("addToCart", type); // CR3546         

        var msg = "Do you wish to proceed with approval of quotation? Once Approved, no more changes will be made available on your quotation. Your payment should be made by " + messageSystemDate + ". Please confirm";
		CommonServices.messageModal('info', msg, false, 'Cancel', 'Confirm', function () {
			paymentExitFunction(2);
		}, function () {
			paymentExitFunction(1);
		}, 'Alert');
		
		/* if (CommonServices.deviceType !== "NA") {
            navigator.notification.confirm("Do you wish to proceed with approval of quotation? Once Approved, no more changes will be made available on your quotation. Your payment should be made by" + messageSystemDate + ". Please confirm.", paymentExitFunction, "Alert", ["Confirm", "Cancel"]);
        } else {
            var approvePayment;
            approvePayment = confirm("Do you wish to proceed with approval of quotation? Once Approved, no more changes will be made available on your quotation. Your payment should be made by " + messageSystemDate + ". Please confirm");
            if (approvePayment === true) {
                paymentExitFunction(1);
            } else {
                paymentExitFunction(2);
            }
        } */


    };


    function paymentExitFunction(button) {
        if (button == 1) {
            if ($rootScope.productName === "TU") {
                approvePolicy();
            } else {
                CommonServices.floaterObj.addedMemberDetails = CommonServices.topUpObj.addedMebersDetails;

                $state.go("docUpload");
            }

        } else {
            CommonServices.topUpObj.goToMemeberInfoEdit = "proposerDetailsEdit";
            $state.go("proposerDetails");
        }
    }


    function approvePolicy() {
        var approveQuoteInput = {
            "userProfile": {
                "userId": CommonServices.getCommonData("userId"),
                "loggedInRole": "SUPERUSER",
                "uiFlow": "NON_CUSTOMER"
            },
            "quote": {
                "quoteNumber": $scope.reviewSummaryObj.quote.quoteNumber,
                "policyType": null,
                "productCode": "TU"
            }
        };
        if (CommonServices.getCommonData("addToCart")==='cart') { // CR3546
            CartServices.approveAndAddToCart(approveQuoteInput, "TU");
            return;
        }

        var TopUpapproveQuoteGen = RestServices.postService(RestServices.urlPathsNewPortal.approveRenewedQuote, approveQuoteInput);
        TopUpapproveQuoteGen.then(
            function (response) { // success 

                CommonServices.showLoading(false);

                CommonServices.topUpObj.TopUpapproveQuoteRes = response.data.quote; CommonServices.setCommonData("CollectionPaymentDetails", CommonServices.topUpObj.reviewSummaryResponse.quote);
                //CommonServices.showLoading(false);
                if (response.data.userProfile.footer.errorDescription.trim() === "Proposal Approved") {
                    $state.go("collectionForm");
                } else {
                    CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
                }

            },
            function (error) { // failure
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            });

    };


    $scope.goToPolicyHolderInfoEdit = function () {

        CommonServices.topUpObj.policyHolderInfoEdit = "policyHolderInfoEdit";
        CommonServices.topUpObj.viewBreakUpNavigation = undefined;
        $rootScope.userClickedOnDiv();

    };

    $scope.goToMemeberInfoEdit = function () {

        CommonServices.topUpObj.goToMemeberInfoEdit = "proposerDetailsEdit";
        CommonServices.topUpObj.viewBreakUpNavigation = undefined;
        $state.go("proposerDetails");

    };



    $scope.goToNomineeInfoEdit = function () {
        //CommonServices.topUpObj.goToNomineeInfoEdit = "policyPeriodAndNomineeEdit";
        CommonServices.topUpObj.viewBreakUpNavigation = undefined;
        $state.go("policyPeriodAndNomineeDetails");
    };

    $scope.goToRelationInfoEdit = function () {
        CommonServices.topUpObj.goToRelationInfoEdit = "relationInfoEdit";
        CommonServices.topUpObj.viewBreakUpNavigation = undefined;
        $state.go("topUpRelationalDetails");
    };

}]);

agentApp.directive('floatingLabel', function () {
    return {
        require: 'ngModel',
        link: function (scope, element, attrs, model) {

            element.on('focus', function () {
                element.parent().addClass('focused');
                //              $($event.target).parent().addClass('focused');  
            });

            scope.$watch(attrs.ngModel, function (newValue) {

                setTimeout(function () {

                    if (element.val().length === 0) {
                        //                   $($event.target).parent().removeClass('focused');
                        element.parent().removeClass('focused');
                    }
                    else {
                        element.parent().addClass('focused');
                        //                     $($event.target).parent().addClass('focused');   
                    }
                }, 0);


            });



        }


    };

});
