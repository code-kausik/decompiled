agentApp.controller('coronaKavachPremiumCalcCtrl', ['$scope', 'RestServices', 'CommonServices', '$state', '$rootScope', '$modal', function ($scope, RestServices, CommonServices, $state, $rootScope, $modal) {

    $rootScope.policyDetailsObj = {}
    $rootScope.termsCondOpen = false;

    var payloadCZDomainValues = {
        "productCode": "CZ",
        "lngCode": "EN",
        "keys": [
            "POLICY_DURATION",
            "TYPE_OF_COVER",
            "SUM_INSURED",
            "RELATIONSHIP_WITH_PROPOSER",
            "RELATIONSHIP_WITH_NOMINEE",
            "NATURE_OF_ID",
            "OCCUPATION",
            "OCCUPATION_CHILDREN"
        ],
    };
    CommonServices.getProductDomainValues(payloadCZDomainValues);

    $scope.goBack = function () {
        $rootScope.backFlag = '';
        if (CommonServices.editQuoteFlag === true)
            $state.go("managePolicies.managePolicies");
        else if (CommonServices.topUpObj.fromProdcutList === "CZPRODUCTLIST")
            $state.go('products.productList');
        else
            $state.go('buyNowSubLandingScreen');
    }

    $scope.openTermsAndCondition = function () {
        $rootScope.termsCondOpen = true;
        $rootScope.readTermsAndCondp2 = "I understand that by providing my mobile no and e-mail id through the Online Portal, I agree to being contacted by The New India Assurance Co.Ltd. The New India Assurance Co.Ltd shall protect all such information and it shall not be utilised in any manner that will directly or indirectly result in any harm to me.";
        $rootScope.readTermsAndCondp3 = "I understand and accept that The New India Assurance Co.Ltd reserves the right to determine the eligibility and availability of any product or service.";
        $rootScope.readTermsAndCondp4 = "I understand that premium shown in the Quick Quote is only estimated premium and may be subjected to change during Detailed Quote depending on the Cover selected and other information provided by me. And I also understand that the premium shown on the Online Portal will be subjected to any changes based on the IRDAI regulations from time to time.";
    };

    $scope.premiumCalcModels = {
        policyDetails: {
            policyDuration: '',
            policyStartDate: '',
            policyEndDate: ''
        },
        typeOfCover: '',
        healthcareWorker: '',
        sumInsured: '',
        hospCashBenefit: '',
        numberOfMembers: 1,
        proposerDetails: {
            dateOfBirth: '',
            sumInsured: '',
            sex: '',
            preMorbid: ''
        },
        spouseDetails: null,
        childrenDetails: [],
        parentDetails: [],
        parentInLawDetails: [],
        comorbidityConditions: false,
        conditionLoadingAmt: false,
        termsConditions: false
    };

    $scope.CoverTypes = {
        INDIVIDUAL: 'INDV',
        FLOATER: 'FLOAT'
    };

    $scope.MemberTypes = {
        PROPOSER: 'SELF',
        SPOUSE: 'SPOUSE',
        CHILD: 'CHILD',
        PARENT: 'PARENT',
        PARENT_IN_LAW: 'PARINLAW'
    }

    $scope.sumInsuredBasic = [50000, 100000, 150000, 200000, 250000, 300000, 350000, 400000, 450000, 500000];
    $scope.canAddMembers = {
        [$scope.MemberTypes.PROPOSER]: false,
        [$scope.MemberTypes.SPOUSE]: true,
        [$scope.MemberTypes.CHILD]: true,
        [$scope.MemberTypes.PARENT]: true,
        [$scope.MemberTypes.PARENT_IN_LAW]: true
    }

    /** Set Min and Max dates for proposer, spouse, parent, parent-in-law DOB */
    var date66YearsOld = new Date(new Date().setFullYear(new Date().getFullYear() - 66));
    var enableDOBCalMin = resetTime(new Date(date66YearsOld.setDate(date66YearsOld.getDate() + 1))); /** Age <= 65 */
    var date18YearsOld = new Date(new Date().setFullYear(new Date().getFullYear() - 18));
    var enableDOBCalMax = resetTime(date18YearsOld); /** Age >= 18 */
    /** Set Min and Max dates for child DOB */
    var enableChildDOBCalMin = enableDOBCalMin;
    var enableChildDOBCalMax = resetTime(new Date(new Date().setDate(new Date().getDate() - 1))); /** Age >= 1 */
    /** Set Calender range for proposer, spouse, child and parent, parent-in-law **/
    /**Proposer DOB**/
    $('#proposerDateOfBirth').loadCalendar({
        'enableDateRange': true,
        'enableCalendarFrom': enableDOBCalMin,
        'enableCalendarTo': resetTime(new Date())
    });
    /**Spouse DOB**/
    $scope.spouseDateOfBirth = function () {
        $('#spouseDateOfBirth').loadCalendar({
            'enableDateRange': true,
            'enableCalendarFrom': enableDOBCalMin,
            'enableCalendarTo': resetTime(new Date())
        });
        return true;
    }

    /**Child DOB**/
    $scope.childDateOfBirth = function (index) {
        $("#childDateOfBirth" + index).loadCalendar({
            'enableDateRange': true,
            'enableCalendarFrom': enableChildDOBCalMin,
            'enableCalendarTo': resetTime(new Date())
        });
        return true;
    };
    /**Parent DOB**/
    $scope.parentDateOfBirth = function (index) {
        $("#parentDateOfBirth" + index).loadCalendar({
            'enableDateRange': true,
            'enableCalendarFrom': enableDOBCalMin,
            'enableCalendarTo': resetTime(new Date())
        });
        return true;
    };
    /**Parent-in-law DOB**/
    $scope.parentInLawDateOfBirth = function (index) {
        $("#parentInLawDateOfBirth" + index).loadCalendar({
            'enableDateRange': true,
            'enableCalendarFrom': enableDOBCalMin,
            'enableCalendarTo': resetTime(new Date())
        });
        return true;
    };

    $scope.onPolicyDurationChange = function () {
        if ($scope.premiumCalcModels.policyDetails.policyDuration) {
            var policyStartDate = resetTime(new Date());
            var policyDuration = parseInt($scope.premiumCalcModels.policyDetails.policyDuration) - 1;
            var policyExpiryDate = new Date(policyStartDate.setDate(policyStartDate.getDate() + policyDuration));
            $scope.premiumCalcModels.policyDetails.policyStartDate = getCurrentDate();
            $scope.premiumCalcModels.policyDetails.policyEndDate = convertDateToText(policyExpiryDate);
        } else {
            $scope.premiumCalcModels.policyDetails.policyStartDate = '';
            $scope.premiumCalcModels.policyDetails.policyEndDate = '';
        }
    }

    $scope.typeOfCoverChange = function () {
        if ($scope.premiumCalcModels.typeOfCover === $scope.CoverTypes.INDIVIDUAL) {
            $scope.sumInsuredMsg = 'Sum Insured amount will be Individual Limit for each member in a family';
            $scope.premiumCalcModels.sumInsured = '';
        } else if ($scope.premiumCalcModels.typeOfCover === $scope.CoverTypes.FLOATER) {
            $scope.sumInsuredMsg = 'Sum Insured will be single overall limit for entire policy.';
            // Reset individual Sum Insured
            $scope.premiumCalcModels.proposerDetails.sumInsured = '';
            if (!!$scope.premiumCalcModels.spouseDetails) {
                $scope.premiumCalcModels.spouseDetails.sumInsured = '';
            }
            for (var i = 0; i < $scope.premiumCalcModels.childrenDetails.length; i++) {
                $scope.premiumCalcModels.childrenDetails[i].sumInsured = '';
            }
            for (var i = 0; i < $scope.premiumCalcModels.parentDetails.length; i++) {
                $scope.premiumCalcModels.parentDetails[i].sumInsured = '';
            }
            for (var i = 0; i < $scope.premiumCalcModels.parentInLawDetails.length; i++) {
                $scope.premiumCalcModels.parentInLawDetails[i].sumInsured = '';
            }
        }
    };

    $scope.addMember = function (memberType) {
        $scope.premiumCalcModels.numberOfMembers += 1;
        if (memberType === $scope.MemberTypes.SPOUSE) {
            addSpouse();
            updateCanAddMembers();
        } else if (memberType === $scope.MemberTypes.PARENT) {
            addParent();
            updateCanAddMembers();
        } else if (memberType === $scope.MemberTypes.PARENT_IN_LAW) {
            addParentInLaw();
            updateCanAddMembers();
        } else if (memberType === $scope.MemberTypes.CHILD) {
            addChild();
            updateCanAddMembers();
        }
    }

    function addSpouse() {
        $scope.premiumCalcModels.spouseDetails = {
            dateOfBirth: '',
            sumInsured: '',
            sex: '',
            preMorbid: ''
        };
    }

    function addChild() {
        $scope.premiumCalcModels.childrenDetails
            .push({
                dateOfBirth: '',
                sumInsured: '',
                dependentType: '',
                sex: '',
                preMorbid: '',
            });
    }

    function addParent() {
        $scope.premiumCalcModels.parentDetails
            .push({
                dateOfBirth: '',
                sumInsured: '',
                sex: '',
                preMorbid: ''
            });
    }

    function addParentInLaw() {
        $scope.premiumCalcModels.parentInLawDetails
            .push({
                dateOfBirth: '',
                sumInsured: '',
                sex: '',
                preMorbid: ''
            });
    }

    $scope.removeMember = function (memberType, index) {
        $scope.premiumCalcModels.numberOfMembers -= 1;
        if (memberType === $scope.MemberTypes.SPOUSE) {
            $scope.premiumCalcModels.spouseDetails = null;
            updateCanAddMembers();
        } else if (memberType === $scope.MemberTypes.PARENT) {
            $scope.premiumCalcModels.parentDetails.splice(index, 1);
            updateCanAddMembers();
        } else if (memberType === $scope.MemberTypes.PARENT_IN_LAW) {
            $scope.premiumCalcModels.parentInLawDetails.splice(index, 1);
            updateCanAddMembers();
        } else if (memberType === $scope.MemberTypes.CHILD) {
            $scope.premiumCalcModels.childrenDetails.splice(index, 1);
            updateCanAddMembers();
        }
    }

    $scope.validateDateOfBirth = function (memberType, index) {
        if (memberType === $scope.MemberTypes.PROPOSER) {
            var proposerDOB = convertTextToDate($scope.premiumCalcModels.proposerDetails.dateOfBirth);
            if (proposerDOB && (proposerDOB < enableDOBCalMin || proposerDOB > enableDOBCalMax)) {
                $scope.premiumCalcModels.proposerDetails.dateOfBirth = '';
                CommonServices.showAlert("Age of the Proposer should be between 18 years to 65 Years");
            }
        } else if (memberType === $scope.MemberTypes.SPOUSE) {
            var spouseDOB = convertTextToDate($scope.premiumCalcModels.spouseDetails.dateOfBirth);
            if (spouseDOB && (spouseDOB < enableDOBCalMin || spouseDOB > enableDOBCalMax)) {
                $scope.premiumCalcModels.spouseDetails.dateOfBirth = '';
                CommonServices.showAlert("Age of the Spouse should be between 18 years to 65 Years");
            }
        } else if (memberType === $scope.MemberTypes.PARENT && $scope.premiumCalcModels.parentDetails[index]) {
            var parentDOB = convertTextToDate($scope.premiumCalcModels.parentDetails[index].dateOfBirth);
            if (parentDOB && (parentDOB < enableDOBCalMin || parentDOB > enableDOBCalMax)) {
                $scope.premiumCalcModels.parentDetails[index].dateOfBirth = '';
                CommonServices.showAlert("Age of the Parent should be between 18 years to 65 Years");
            }
        } else if (memberType === $scope.MemberTypes.PARENT_IN_LAW && $scope.premiumCalcModels.parentInLawDetails[index]) {
            var parentInLawDOB = convertTextToDate($scope.premiumCalcModels.parentInLawDetails[index].dateOfBirth);
            if (parentInLawDOB && (parentInLawDOB < enableDOBCalMin || parentInLawDOB > enableDOBCalMax)) {
                $scope.premiumCalcModels.parentInLawDetails[index].dateOfBirth = '';
                CommonServices.showAlert("Age of the Parent-in-law should be between 18 years to 65 Years");
            }
        } else if (memberType === $scope.MemberTypes.CHILD && $scope.premiumCalcModels.childrenDetails[index]) {
            var childDOB = convertTextToDate($scope.premiumCalcModels.childrenDetails[index].dateOfBirth);
            if ($scope.premiumCalcModels.childrenDetails[index].dependentType === 'NA') {
                if (childDOB && (childDOB < enableChildDOBCalMin || childDOB > enableChildDOBCalMax)) {
                    $scope.premiumCalcModels.childrenDetails[index].dateOfBirth = '';
                    CommonServices.showAlert("Age of the child should be between 1 Day to 18 Years");
                }
            } else if ($scope.premiumCalcModels.childrenDetails[index].dependentType === 'NORM') {
                if (childDOB && (childDOB < enableChildDOBCalMin || childDOB > enableChildDOBCalMax)) {
                    $scope.premiumCalcModels.childrenDetails[index].dateOfBirth = '';
                    CommonServices.showAlert("Age of the child should be between 1 Day to 25 Years");
                }
            } else if ($scope.premiumCalcModels.childrenDetails[index].dependentType === 'MC' || $scope.premiumCalcModels.childrenDetails[index].dependentType === 'UD') {
                if (childDOB && (childDOB < enableChildDOBCalMin || childDOB > enableChildDOBCalMax)) {
                    $scope.premiumCalcModels.childrenDetails[index].dateOfBirth = '';
                    CommonServices.showAlert("Age of the child should be between 1 Day to 65 Years");
                }
            }
        }
    }

    $scope.dependentTypeChanged = function (index) {

        if (!$scope.premiumCalcModels.childrenDetails[index]) { return; }
        if ($scope.premiumCalcModels.childrenDetails[index].dependentType === 'NA') {
            enableChildDOBCalMin = new Date(enableDOBCalMax);
            enableChildDOBCalMin = resetTime(new Date(enableChildDOBCalMin.setDate(enableChildDOBCalMin.getDate() + 1))); /** Age < 18 */
            $scope.validateDateOfBirth($scope.MemberTypes.CHILD, index);
        } else if ($scope.premiumCalcModels.childrenDetails[index].dependentType === 'NORM') {
            var date26YearsOld = new Date(new Date().setFullYear(new Date().getFullYear() - 26));
            enableChildDOBCalMin = resetTime(new Date(date26YearsOld.setDate(date26YearsOld.getDate() + 1))); /** Age <= 25 */
            $scope.validateDateOfBirth($scope.MemberTypes.CHILD, index);
        } else if ($scope.premiumCalcModels.childrenDetails[index].dependentType === 'MC' || $scope.premiumCalcModels.childrenDetails[index].dependentType === 'UD') {
            if($scope.premiumCalcModels.childrenDetails[index].dependentType === 'UD'){
                $scope.premiumCalcModels.childrenDetails[index].sex = "F";
            }
            enableChildDOBCalMin = enableDOBCalMin;
            $scope.validateDateOfBirth($scope.MemberTypes.CHILD, index);
        } else { enableChildDOBCalMin = enableDOBCalMin; }
        $scope.childDateOfBirth(index);
    }

    function getTotalNonChildMembersCount() {
        return 1 + (!!$scope.premiumCalcModels.spouseDetails ? 1 : 0) + $scope.premiumCalcModels.parentDetails.length + $scope.premiumCalcModels.parentInLawDetails.length;
    }

    function updateCanAddMembers() {
        var maxMembersCount = 10;
        var maxMembersLimitNotReached = $scope.premiumCalcModels.numberOfMembers < maxMembersCount;
        var maxChildLimit = maxMembersCount - getTotalNonChildMembersCount();
        $scope.canAddMembers = {
            [$scope.MemberTypes.PROPOSER]: false,
            [$scope.MemberTypes.SPOUSE]: maxMembersLimitNotReached && !$scope.premiumCalcModels.spouseDetails,
            [$scope.MemberTypes.CHILD]: maxMembersLimitNotReached && $scope.premiumCalcModels.childrenDetails.length < maxChildLimit,
            [$scope.MemberTypes.PARENT]: maxMembersLimitNotReached && $scope.premiumCalcModels.parentDetails.length < 2,
            [$scope.MemberTypes.PARENT_IN_LAW]: maxMembersLimitNotReached && $scope.premiumCalcModels.parentInLawDetails.length < 2
        }
    }

    $scope.checkComorbity = function () {
        if ($scope.premiumCalcModels.proposerDetails.preMorbid === 'NO' || ($scope.premiumCalcModels.spouseDetails &&
            $scope.premiumCalcModels.spouseDetails.preMorbid === 'NO')) {
            return true;
        }
        for (let i = 0; i < $scope.premiumCalcModels.childrenDetails.length; i++) {
            if ($scope.premiumCalcModels.childrenDetails[i].preMorbid === 'NO') return true;
        }
        for (let i = 0; i < $scope.premiumCalcModels.parentDetails.length; i++) {
            if ($scope.premiumCalcModels.parentDetails[i].preMorbid === 'NO') return true;
        }
        for (let i = 0; i < $scope.premiumCalcModels.parentInLawDetails.length; i++) {
            if ($scope.premiumCalcModels.parentInLawDetails[i].preMorbid === 'NO') return true;
        }
        return false;
    }

    function calculateTotalSumInsured() {
        if ($scope.premiumCalcModels.typeOfCover === $scope.CoverTypes.INDIVIDUAL) {
            var totalSumInsured = parseInt($scope.premiumCalcModels.proposerDetails.sumInsured);
            if ($scope.premiumCalcModels.spouseDetails) {
                totalSumInsured = totalSumInsured + parseInt($scope.premiumCalcModels.spouseDetails.sumInsured);
            }
            for (var i = 0; i < $scope.premiumCalcModels.childrenDetails.length; i++) {
                totalSumInsured = totalSumInsured + parseInt($scope.premiumCalcModels.childrenDetails[i].sumInsured);
            }
            for (var i = 0; i < $scope.premiumCalcModels.parentDetails.length; i++) {
                totalSumInsured = totalSumInsured + parseInt($scope.premiumCalcModels.parentDetails[i].sumInsured);
            }
            for (var i = 0; i < $scope.premiumCalcModels.parentInLawDetails.length; i++) {
                totalSumInsured = totalSumInsured + parseInt($scope.premiumCalcModels.parentInLawDetails[i].sumInsured);
            }
            CommonServices.floaterObj.sumInsured = totalSumInsured;
            return;
        }
        CommonServices.floaterObj.sumInsured = $scope.premiumCalcModels.sumInsured;
    }

    function setRiskDetails() {
        $scope.risks = [];
        CommonServices.floaterObj.addedMemberDetails = [];
        CommonServices.floaterObj.risks = [];

        var proposerRiskDetails = {
            "riskDetails": {
                "relationWithPolicyHolder": $scope.MemberTypes.PROPOSER,
                "dateOfBirth": $scope.premiumCalcModels.proposerDetails.dateOfBirth,
                "ageInYrs": calculateAge($scope.premiumCalcModels.proposerDetails.dateOfBirth).toString(),
                "sex": $scope.premiumCalcModels.proposerDetails.sex,
                "preMorbid": $scope.premiumCalcModels.proposerDetails.preMorbid,
                "sumInsured": $scope.premiumCalcModels.typeOfCover === $scope.CoverTypes.INDIVIDUAL ? $scope.premiumCalcModels.proposerDetails.sumInsured : 'SELECT'
            }
        };
        $scope.risks.push($.extend(true, {}, proposerRiskDetails));
        if (CommonServices.editQuoteFlag === true || $rootScope.backFlag === "premCal") {
            proposerRiskDetails.riskDetails = $.extend(true, {}, $scope.premiumCalcModels.proposerDetails, proposerRiskDetails.riskDetails);
        }
        CommonServices.floaterObj.addedMemberDetails.push(proposerRiskDetails);
        CommonServices.floaterObj.risks.push(proposerRiskDetails);

        if (!!$scope.premiumCalcModels.spouseDetails) {
            var spouseRiskDetails = {
                "riskDetails": {
                    "relationWithPolicyHolder": $scope.MemberTypes.SPOUSE,
                    "dateOfBirth": $scope.premiumCalcModels.spouseDetails.dateOfBirth,
                    "ageInYrs": calculateAge($scope.premiumCalcModels.spouseDetails.dateOfBirth).toString(),
                    "sex": $scope.premiumCalcModels.spouseDetails.sex,
                    "preMorbid": $scope.premiumCalcModels.spouseDetails.preMorbid,
                    "sumInsured": $scope.premiumCalcModels.typeOfCover === $scope.CoverTypes.INDIVIDUAL ? $scope.premiumCalcModels.spouseDetails.sumInsured : 'SELECT'
                }
            };
            $scope.risks.push($.extend(true, {}, spouseRiskDetails));
            if (CommonServices.editQuoteFlag === true || $rootScope.backFlag === "premCal") {
                spouseRiskDetails.riskDetails = $.extend(true, {}, $scope.premiumCalcModels.spouseDetails, spouseRiskDetails.riskDetails);
            }
            CommonServices.floaterObj.addedMemberDetails.push(spouseRiskDetails);
            CommonServices.floaterObj.risks.push(spouseRiskDetails);
        }

        for (var i = 0; i < $scope.premiumCalcModels.childrenDetails.length; i++) {
            var childRiskDetails = {
                "riskDetails": {
                    "relationWithPolicyHolder": $scope.MemberTypes.CHILD,
                    "dateOfBirth": $scope.premiumCalcModels.childrenDetails[i].dateOfBirth,
                    "ageInYrs": calculateAge($scope.premiumCalcModels.childrenDetails[i].dateOfBirth).toString(),
                    "dependent": $scope.premiumCalcModels.childrenDetails[i].dependentType === 'NA' ? 'N' : 'Y',
                    "dependentType": $scope.premiumCalcModels.childrenDetails[i].dependentType,
                    "sex": $scope.premiumCalcModels.childrenDetails[i].sex,
                    "preMorbid": $scope.premiumCalcModels.childrenDetails[i].preMorbid,
                    "sumInsured": $scope.premiumCalcModels.typeOfCover === $scope.CoverTypes.INDIVIDUAL ? $scope.premiumCalcModels.childrenDetails[i].sumInsured : 'SELECT'
                }
            };
            $scope.risks.push($.extend(true, {}, childRiskDetails));
            if (CommonServices.editQuoteFlag === true || $rootScope.backFlag === "premCal") {
                childRiskDetails.riskDetails = $.extend(true, {}, $scope.premiumCalcModels.childrenDetails[i], childRiskDetails.riskDetails);
            }
            CommonServices.floaterObj.addedMemberDetails.push(childRiskDetails);
            CommonServices.floaterObj.risks.push(childRiskDetails);
        }

        for (var i = 0; i < $scope.premiumCalcModels.parentDetails.length; i++) {
            var parentRiskDetails = {
                "riskDetails": {
                    "relationWithPolicyHolder": $scope.MemberTypes.PARENT,
                    "dateOfBirth": $scope.premiumCalcModels.parentDetails[i].dateOfBirth,
                    "ageInYrs": calculateAge($scope.premiumCalcModels.parentDetails[i].dateOfBirth).toString(),
                    "sex": $scope.premiumCalcModels.parentDetails[i].sex,
                    "preMorbid": $scope.premiumCalcModels.parentDetails[i].preMorbid,
                    "sumInsured": $scope.premiumCalcModels.typeOfCover === $scope.CoverTypes.INDIVIDUAL ? $scope.premiumCalcModels.parentDetails[i].sumInsured : 'SELECT'
                }
            };
            $scope.risks.push($.extend(true, {}, parentRiskDetails));
            if (CommonServices.editQuoteFlag === true || $rootScope.backFlag === "premCal") {
                parentRiskDetails.riskDetails = $.extend(true, {}, $scope.premiumCalcModels.parentDetails[i], parentRiskDetails.riskDetails);
            }
            CommonServices.floaterObj.addedMemberDetails.push(parentRiskDetails);
            CommonServices.floaterObj.risks.push(parentRiskDetails);
        }

        for (var i = 0; i < $scope.premiumCalcModels.parentInLawDetails.length; i++) {
            var parentInLawRiskDetails = {
                "riskDetails": {
                    "relationWithPolicyHolder": $scope.MemberTypes.PARENT_IN_LAW,
                    "dateOfBirth": $scope.premiumCalcModels.parentInLawDetails[i].dateOfBirth,
                    "ageInYrs": calculateAge($scope.premiumCalcModels.parentInLawDetails[i].dateOfBirth).toString(),
                    "sex": $scope.premiumCalcModels.parentInLawDetails[i].sex,
                    "preMorbid": $scope.premiumCalcModels.parentInLawDetails[i].preMorbid,
                    "sumInsured": $scope.premiumCalcModels.typeOfCover === $scope.CoverTypes.INDIVIDUAL ? $scope.premiumCalcModels.parentInLawDetails[i].sumInsured : 'SELECT'
                }
            };
            $scope.risks.push($.extend(true, {}, parentInLawRiskDetails));
            if (CommonServices.editQuoteFlag === true || $rootScope.backFlag === "premCal") {
                parentInLawRiskDetails.riskDetails = $.extend(true, {}, $scope.premiumCalcModels.parentInLawDetails[i], parentInLawRiskDetails.riskDetails);
            }
            CommonServices.floaterObj.addedMemberDetails.push(parentInLawRiskDetails);
            CommonServices.floaterObj.risks.push(parentInLawRiskDetails);
        }
    }

    /** Save and calculate premium */
    $scope.saveAndCalculatePremium = function () {
        if (!$scope.premiumCalcModels.typeOfCover) {
            CommonServices.showAlert("Please select type of cover");
            return;
        }
        if ($scope.premiumCalcModels.numberOfMembers < 2 && $scope.premiumCalcModels.typeOfCover === $scope.CoverTypes.FLOATER) {
            CommonServices.showAlert("For Floater policy, minimum 2 members should be covered");
            return;
        }

        calculateTotalSumInsured();
        setRiskDetails();

        /** Update and save state in global shared objects */
        CommonServices.newIndiaPremierMediclaim.memberCoveredInPolicy = true;
        CommonServices.floaterObj.numberOfMembers = $scope.premiumCalcModels.numberOfMembers;
        CommonServices.floaterObj.policyExpiryDate = $scope.premiumCalcModels.policyDetails.policyEndDate;
        CommonServices.floaterObj.policyStartDate = $scope.premiumCalcModels.policyDetails.policyStartDate;
        CommonServices.floaterObj.premiumCalcModel = $scope.premiumCalcModels;
        CommonServices.floaterObj.typeOfCover = $scope.premiumCalcModels.typeOfCover;

        calcPremiumServiceCall();
    };

    /** Invoke calcPremium API */
    function calcPremiumServiceCall() {
        var quoteNumber = (CommonServices.editQuoteFlag === true || $rootScope.backFlag === "premCal") ? CommonServices.floaterObj.quoteNumber : undefined;
        var payload = {
            "quote": {
                "risks": $scope.risks,
                "productCode": 'CZ',
                "quoteNumber": quoteNumber,
                "policyStartDate": $scope.premiumCalcModels.policyDetails.policyStartDate,
                "policyExpiryDate": $scope.premiumCalcModels.policyDetails.policyEndDate,
                "typeOfCover": $scope.premiumCalcModels.typeOfCover,
                "healthcareWorker": $scope.premiumCalcModels.healthcareWorker,
                "hospCashBenefit": $scope.premiumCalcModels.hospCashBenefit,
                "policyDuration": $scope.premiumCalcModels.policyDetails.policyDuration,
                "sumInsured": $scope.premiumCalcModels.typeOfCover === $scope.CoverTypes.INDIVIDUAL ? '0' : $scope.premiumCalcModels.sumInsured,
                "memberCoveredInPolicy": 'Y',
                "mobileNo": null,
                "emailId": null,
                "progressLevel": null
            },
            "userProfile": {
                "userId": CommonServices.getCommonData("userId"),
                "loggedInRole": "SUPERUSER"
            }
        };

        var coronaKavachPremiumCalResponse = RestServices.postService(RestServices.urlPathsNewPortal.topUpCalcPremium, payload);
        coronaKavachPremiumCalResponse.then(
            function (response) { // success 
                CommonServices.showLoading(false);
                if (response.data !== undefined && response.data !== "") {
                    if (response.data.hasOwnProperty('errorMessage')) {
                        CommonServices.showAlert(response.data.errorMessage);
                    } else {
                        CommonServices.floaterObj.premiumDetails = response.data.quote.premiumDetails;
                        CommonServices.floaterObj.quoteNumber = response.data.quote.quoteNumber;
                        CommonServices.floaterObj.premiumDetails.sumInsured = CommonServices.floaterObj.sumInsured;
                        $state.go("floaterBasicPremium");
                    }
                } else {
                    CommonServices.showAlert("Something went wrong. Please try after some time");
                }
            },
            function (error) { // failure
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            });
    };

    function handleChangeAndValidateData() {
        $scope.onPolicyDurationChange();
        $scope.typeOfCoverChange();
        updateCanAddMembers();
        $scope.validateDateOfBirth($scope.MemberTypes.PROPOSER);
        if (!!$scope.premiumCalcModels.spouseDetails) {
            $scope.validateDateOfBirth($scope.MemberTypes.SPOUSE);
        }
        for (var i = 0; i < $scope.premiumCalcModels.childrenDetails.length; i++) {
            $scope.dependentTypeChanged(i);
        }
        for (var i = 0; i < $scope.premiumCalcModels.parentDetails.length; i++) {
            $scope.validateDateOfBirth($scope.MemberTypes.PARENT, i);
        }
        for (var i = 0; i < $scope.premiumCalcModels.parentInLawDetails.length; i++) {
            $scope.validateDateOfBirth($scope.MemberTypes.PARENT_IN_LAW, i);
        }
    }

    /** Back flow auto-populate data */
    if ($rootScope.backFlag === "premCal") {
        $scope.premiumCalcModels = CommonServices.floaterObj.premiumCalcModel;
        $scope.premiumCalcModels.childrenDetails = [];
        $scope.premiumCalcModels.parentDetails = [];
        $scope.premiumCalcModels.parentInLawDetails = [];
        for (var i = 0; i < CommonServices.floaterObj.addedMemberDetails.length; i++) {
            switch (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder) {
                case $scope.MemberTypes.PROPOSER:
                    $scope.premiumCalcModels.proposerDetails = CommonServices.floaterObj.addedMemberDetails[i].riskDetails;
                    break;
                case $scope.MemberTypes.SPOUSE:
                    $scope.premiumCalcModels.spouseDetails = CommonServices.floaterObj.addedMemberDetails[i].riskDetails;
                    break;
                case $scope.MemberTypes.CHILD:
                    $scope.premiumCalcModels.childrenDetails.push(CommonServices.floaterObj.addedMemberDetails[i].riskDetails);
                    break;
                case $scope.MemberTypes.PARENT:
                    $scope.premiumCalcModels.parentDetails.push(CommonServices.floaterObj.addedMemberDetails[i].riskDetails);
                    break;
                case $scope.MemberTypes.PARENT_IN_LAW:
                    $scope.premiumCalcModels.parentInLawDetails.push(CommonServices.floaterObj.addedMemberDetails[i].riskDetails);
                    break;
            }
        }
        $scope.premiumCalcModels.comorbidityConditions = false;
        $scope.premiumCalcModels.conditionLoadingAmt = false;
        $scope.premiumCalcModels.termsConditions = false;
        handleChangeAndValidateData();
        return;
    }

    /** Edit quote flow; Auto-populate data */
    if (CommonServices.editQuoteFlag === true) {
        CommonServices.floaterObj = CommonServices.floaterObj || {};
        $scope.premiumCalcModels = {
            policyDetails: {
                policyDuration: CommonServices.floaterObj.policyDuration || '',
                policyStartDate: CommonServices.floaterObj.policyStartDate || '',
                policyEndDate: CommonServices.floaterObj.policyExpiryDate || ''
            },
            typeOfCover: CommonServices.floaterObj.typeOfCover || '',
            healthcareWorker: CommonServices.floaterObj.healthcareWorker || '',
            sumInsured: (CommonServices.floaterObj.sumInsured && CommonServices.floaterObj.sumInsured !== '0') ? CommonServices.floaterObj.sumInsured : '',
            hospCashBenefit: CommonServices.floaterObj.hospCashBenefit || '',
            numberOfMembers: CommonServices.floaterObj.risks ? (CommonServices.floaterObj.risks.length || 1) : 1,
            proposerDetails: {
                dateOfBirth: '',
                sumInsured: '',
                sex: '',
                preMorbid: ''
            },
            spouseDetails: null,
            childrenDetails: [],
            parentDetails: [],
            parentInLawDetails: [],
            comorbidityConditions: false,
            conditionLoadingAmt: false,
            termsConditions: false
        };

        if (CommonServices.floaterObj.risks) {
            for (var i = 0; i < CommonServices.floaterObj.risks.length; i++) {
                var riskObj = CommonServices.floaterObj.risks[i];
                var riskDetails = riskObj && riskObj.riskDetails;

                if (riskDetails && riskDetails.relationWithPolicyHolder === $scope.MemberTypes.PROPOSER) {
                    var proposerDetailsObj = {
                        dateOfBirth: (riskDetails.dateOfBirth && riskDetails.dateOfBirth !== '0') ? riskDetails.dateOfBirth : '',
                        sumInsured: (riskObj.riskSumInsured && riskObj.riskSumInsured !== '0') ? riskObj.riskSumInsured : '',
                        sex: riskDetails.sex || '',
                        preMorbid: riskDetails.preMorbid || ''
                    };
                    $scope.premiumCalcModels.proposerDetails = $.extend(true, {}, riskDetails, proposerDetailsObj);
                } else if (riskDetails && riskDetails.relationWithPolicyHolder === $scope.MemberTypes.SPOUSE) {
                    var spouseDetailsObj = {
                        dateOfBirth: (riskDetails.dateOfBirth && riskDetails.dateOfBirth !== '0') ? riskDetails.dateOfBirth : '',
                        sumInsured: (riskObj.riskSumInsured && riskObj.riskSumInsured !== '0') ? riskObj.riskSumInsured : '',
                        sex: riskDetails.sex || '',
                        preMorbid: riskDetails.preMorbid || ''
                    };
                    $scope.premiumCalcModels.spouseDetails = $.extend(true, {}, riskDetails, spouseDetailsObj);
                } else if (riskDetails && riskDetails.relationWithPolicyHolder === $scope.MemberTypes.CHILD) {
                    var childDetailsObj = {
                        dateOfBirth: (riskDetails.dateOfBirth && riskDetails.dateOfBirth !== '0') ? riskDetails.dateOfBirth : '',
                        sumInsured: (riskObj.riskSumInsured && riskObj.riskSumInsured !== '0') ? riskObj.riskSumInsured : '',
                        dependentType: riskDetails.dependentType || '',
                        sex: riskDetails.sex || '',
                        preMorbid: riskDetails.preMorbid || ''
                    };
                    $scope.premiumCalcModels.childrenDetails.push($.extend(true, {}, riskDetails, childDetailsObj));
                } else if (riskDetails && riskDetails.relationWithPolicyHolder === $scope.MemberTypes.PARENT) {
                    var parentDetailsObj = {
                        dateOfBirth: (riskDetails.dateOfBirth && riskDetails.dateOfBirth !== '0') ? riskDetails.dateOfBirth : '',
                        sumInsured: (riskObj.riskSumInsured && riskObj.riskSumInsured !== '0') ? riskObj.riskSumInsured : '',
                        sex: riskDetails.sex || '',
                        preMorbid: riskDetails.preMorbid || ''
                    };
                    $scope.premiumCalcModels.parentDetails.push($.extend(true, {}, riskDetails, parentDetailsObj));
                } else if (riskDetails && riskDetails.relationWithPolicyHolder === $scope.MemberTypes.PARENT_IN_LAW) {
                    var parentInLawDetailsObj = {
                        dateOfBirth: (riskDetails.dateOfBirth && riskDetails.dateOfBirth !== '0') ? riskDetails.dateOfBirth : '',
                        sumInsured: (riskObj.riskSumInsured && riskObj.riskSumInsured !== '0') ? riskObj.riskSumInsured : '',
                        sex: riskDetails.sex || '',
                        preMorbid: riskDetails.preMorbid || ''
                    };
                    $scope.premiumCalcModels.parentInLawDetails.push($.extend(true, {}, riskDetails, parentInLawDetailsObj));
                }
            }
        }
        handleChangeAndValidateData();
    }
}]);

agentApp.controller('coronaKavachViewBreakupCtrl', ['$scope', 'RestServices', 'CommonServices', '$state', '$rootScope', function ($scope, RestServices, CommonServices, $state, $rootScope) {
    //$scope.contiNueBtnShow = true;
    if (CommonServices.editSaveQuote === true) {
        $scope.editQuoteFlag = true;
    }
    if (CommonServices.floaterObj.viewBreakUpNavigation === "ViewBreakupSummary")
        $scope.isNotNavigatedFromReviewSummary = false;
    else
        $scope.isNotNavigatedFromReviewSummary = true;


    $scope.goBack = function () {
        if ($scope.isNotNavigatedFromReviewSummary) {
            $state.go("floaterBasicPremium");
        } else {
            $state.go("reviewSummaryScreen");
        }
    };

    $scope.riskPremiums = CommonServices.floaterObj.viewBreakUpResponse.risks;
    var childCount = 0;
    var parnetCount = 0;
    var parentInLawCount = 0;
    $scope.hospCashLoadingPrem = 0;
    $scope.healthCareWorkerDiscount = 0;
    $scope.floaterDiscount = 0;
    $scope.totalBasicPrem = 0;
    for (var i = 0; i < $scope.riskPremiums.length; i++) {
        if ($scope.riskPremiums[i].riskDetails.relationWithPolicyHolder === "Children")
            childCount = childCount + 1;

        if ($scope.riskPremiums[i].riskDetails.relationWithPolicyHolder === 'SELF')
            $scope.riskPremiums[i].riskDetails.policyHolder = "Proposer";
        else if ($scope.riskPremiums[i].riskDetails.relationWithPolicyHolder.toUpperCase() === 'SPOUSE')
            $scope.riskPremiums[i].riskDetails.policyHolder = "Spouse";
        else if ($scope.riskPremiums[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILD") {
            childCount++;
            $scope.riskPremiums[i].riskDetails.policyHolder = "Child " + childCount;
        }
        else if ($scope.riskPremiums[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "PARENT") {
            parnetCount++;
            $scope.riskPremiums[i].riskDetails.policyHolder = "Parent " + parnetCount;
        }
        else if ($scope.riskPremiums[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "PARINLAW") {
            parentInLawCount++;
            $scope.riskPremiums[i].riskDetails.policyHolder = "Parent-in-law " + parentInLawCount;
        }
        $scope.hospCashLoadingPrem += parseInt($scope.riskPremiums[i].hospCashLoadingPrem);
        $scope.healthCareWorkerDiscount += parseInt($scope.riskPremiums[i].healthCareWorkerDiscount);
        $scope.floaterDiscount += parseInt($scope.riskPremiums[i].floaterDiscount);
        $scope.totalBasicPrem += parseInt($scope.riskPremiums[i].basicPremiumRate);
    }

    $scope.premiumDetails = CommonServices.floaterObj.viewBreakUpResponse.premiumDetails;
    $scope.discount = parseInt($scope.healthCareWorkerDiscount) + parseInt($scope.floaterDiscount);

    /************   servivce Tax valriable not used untill now ***********************/
    // $scope.serviceTax = $scope.premiumDetails.netPremium - (parseInt($scope.premiumDetails.grossPremium) + $scope.healthCareWorkerDiscount +$scope.discount);

    $scope.healthViewBreakCntBtn = function () {
        CommonServices.policyDetailsObj.enableEditModels = "";
        $rootScope.searchLength = 0;
        $state.go("policyHolderInformation");
    };
}]);

