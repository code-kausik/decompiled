agentApp.controller('personalAccidentController', ['$scope', '$rootScope', 'RestServices', function ($scope, $rootScope, RestServices) {
	$scope.home = function () {
		RestServices.goHome();

	};
	$rootScope.policyHolderDataPu= {};//CR_0054
	//objects 

	$scope.addSpouseDisable = false;
	$scope.personalAccidentController = {
		onload: function () {
			$scope.closeViewBreakUp = false;
			$rootScope.resetData = true;
			$rootScope.maxTwo = false;
			$rootScope.backData = "";
			$scope.claimNoModal = false;
			$scope.spouserow = false;
			$scope.spouserowe = false;
			$scope.selectedRow = false;
			$scope.detailNoModal = false;
			$scope.zipCodeDetail = false;
			$scope.policyDataModal = false;
			$scope.pinCodeDataModal = false;
			$scope.itemsModal = false;
			$scope.slideshowModal1 = false;
			$scope.slideshowModal2 = false;
			$scope.slideshowModal3 = false;
			$scope.slideshowModal4 = false;
			$scope.SaveCalculatePremiumModala = false;
			$scope.SaveCalculatePremiumModal1b = false;
			$scope.NextScreenModal = false;
			$scope.SaveCalculatePremiumModal2bs1 = false;
			$scope.SaveCalculatePremiumModal2bs2 = false;
			$scope.SaveCalculatePremiumModal2as1 = false;
			$scope.SaveCalculatePremiumModal2as2 = false;
			$scope.spouseDetails = true;
			$scope.sonDetails = true;
			$scope.daughterDetails = true;
			$scope.SecondDaughter = false;
			$scope.SecondSon = false;

		}
	};

	$scope.personalAccidentController.onload();
	$scope.buyNow.personalAccident.saveQuoteRes = {};
	var quoteNo, showData, netPremium, serviceTax, totalPremium, str, numberOfChildren, spouse, count, counts, countd, self, code, todaysDate, futureDateCal, medicalcheck, incomeselfb, incomeselfc, bdate, name, occupation, cs, cd, ce, cf, fullName, quoteNoSelf, netPremiumSelf, serviceTaxSelf, totalPremiumSelf, noOfChildren, birthdates2, birthdates1, birthdated1, birthdated2, birthdate, nomineeName, insuredName, relationNominee, SpouseEarning;
}]);

agentApp.controller('personalAccidentCtrl', ['$scope', '$rootScope', '$location', 'RestServices', 'CommonServices', '$state', function ($scope, $rootScope, $location, RestServices, CommonServices, $state) {
	$rootScope.PAView = false;
	CommonServices.setCommonData('paPolicyAutopopulatedData', undefined);
	CommonServices.setCommonData("insuredNameSpouse", undefined);
	CommonServices.setCommonData("InsuredNameSon1", undefined);
	CommonServices.setCommonData("InsuredNameSon2", undefined);
	CommonServices.setCommonData("insuredNameDaught1", undefined);
	CommonServices.setCommonData("insuredNameDaught2", undefined);
	$scope.back = function () {
		$rootScope.backData = "";
		$rootScope.resetData = true;
		$state.go('buyNowSubLandingScreen');
	};
	$rootScope.resetData = true;
	$rootScope.backData = "";
	$scope.hideMe = function () {
		$scope.checked = false;
		$state.go('buyNowSubLandingScreen');
	};

	$scope.premiumCalculatorScreen = function () {

		$state.go('premiumCalculator');

	};
	$scope.showTable = function () {
		$scope.claimNoModal = true;
	};
	$scope.close = function () {
		$scope.claimNoModal = false;
	};
	$(document).ready(function () {
		$('.sp').first().addClass('active');
		$('.sp').hide();
		$('.active').show();

		$('#button-next').click(function () {

			$('.active').removeClass('active').addClass('oldActive');
			if ($('.oldActive').is(':last-child')) {
				$('.sp').first().addClass('active');
			}
			else {
				$('.oldActive').next().addClass('active');
			}
			$('.oldActive').removeClass('oldActive');
			$('.sp').fadeOut();
			$('.active').fadeIn();
		});
		$('#button-previous').click(function () {
			$('.active').removeClass('active').addClass('oldActive');
			if ($('.oldActive').is(':first-child')) {
				$('.sp').last().addClass('active');
			}
			else {
				$('.oldActive').prev().addClass('active');
			}
			$('.oldActive').removeClass('oldActive');
			$('.sp').fadeOut();
			$('.active').fadeIn();
		});
	});
}]);


agentApp.controller('premiumCalculatorCtrl', ['$scope', '$rootScope', '$location', 'RestServices', 'CommonServices', '$state', '$modal', function ($scope, $rootScope, $location, RestServices, CommonServices, $state, $modal) {
	var countsp = 0;
	$scope.buyNow.personalAccident.premiumCalculator = {};
	$scope.buyNow.personalAccident.saveQuoteRes = {};
	$scope.addDaughterDisable = false;
	$scope.addSonDisable = false;
	$scope.addSpouseDisable = false;
	var domainInputValues = {
		"productCode": "PU",
		"lngCode": "EN",
		"keys": ["OCCUPATION", "RELATIONSHIP_WITH_PROPOSER", "RELATIONSHIP_WITH_NOMINEE"]
	};

	var domainInputValuesResponse = RestServices.postService(RestServices.urlPathsNewPortal.getProductDomainValues, domainInputValues);
	domainInputValuesResponse.then(
		function (response) {
			CommonServices.showLoading(false);
			$scope.occpDataArray = [];
			CommonServices.setCommonData("RELATIONSHIP_WITH_NOMINEE", $scope.occpDataArray);


			$scope.childNomiee = [];
			CommonServices.setCommonData("OCCUPATION", $scope.occpDataArray);
			for (var i = 0; i < response.data.productDomainValues.length; i++) {
				$scope.domainvalues = response.data.productDomainValues[i].domainValues;
				$scope.occpDataArray.push($scope.domainvalues);

				if (response.data.productDomainValues[i].domainValues.codeId === "RELATIONSHIP_WITH_NOMINEE") {
					if (response.data.productDomainValues[i].domainValues.mnemonic.toUpperCase() === "FATHER" || response.data.productDomainValues[i].domainValues.mnemonic.toUpperCase() === "MOTHER") {
						$scope.childNomiee.push($scope.domainvalues);
					}
				}



			}
			CommonServices.setCommonData("childNominee", $scope.childNomiee);
		},
		function (error) {    // failure 
			CommonServices.showLoading(false);
			RestServices.handleWebServiceError(error);
		});

//CR_0054
if(CommonServices.editQuoteHistory === true){		
		console.log("CommonServices.personalAccidentObj :"+JSON.stringify(CommonServices.personalAccidentObj));
		var domainInputValues = {
				"productCode": "PU",
				"lngCode": "EN",
				"keys": ["OCCUPATION", "RELATIONSHIP_WITH_PROPOSER", "RELATIONSHIP_WITH_NOMINEE"]
			};
			var domainInputValuesResponse = RestServices.postService(RestServices.urlPathsNewPortal.getProductDomainValues, domainInputValues);
			domainInputValuesResponse.then(
				function (response) {
					CommonServices.showLoading(false);
					$scope.occpDataArray = [];
					CommonServices.setCommonData("RELATIONSHIP_WITH_NOMINEE", $scope.occpDataArray);
					$scope.childNomiee = [];
					CommonServices.setCommonData("OCCUPATION", $scope.occpDataArray);
					for (var i = 0; i < response.data.productDomainValues.length; i++) {
						$scope.domainvalues = response.data.productDomainValues[i].domainValues;
						$scope.occpDataArray.push($scope.domainvalues);
						if (response.data.productDomainValues[i].domainValues.codeId === "RELATIONSHIP_WITH_NOMINEE") {
							if (response.data.productDomainValues[i].domainValues.mnemonic.toUpperCase() === "FATHER" || response.data.productDomainValues[i].domainValues.mnemonic.toUpperCase() === "MOTHER") {
								$scope.childNomiee.push($scope.domainvalues);
							}
						}
					}
					CommonServices.setCommonData("childNominee", $scope.childNomiee);
				},
				function (error) {    // failure 
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
				});			
		$scope.buyNow.personalAccident.premiumCalculator.occupationself=CommonServices.personalAccidentObj.risks[0].riskDetails.occupation;
		$scope.buyNow.personalAccident.premiumCalculator.dateOfBirthself=CommonServices.personalAccidentObj.risks[0].riskDetails.dateOfBirth;
		$scope.buyNow.personalAccident.insuredDetails.nomineeName=CommonServices.personalAccidentObj.risks[0].riskDetails.nomineeName;
		$scope.buyNow.personalAccident.insuredDetails.relationshipself=CommonServices.personalAccidentObj.risks[0].riskDetails.relationWithNominee;
		/*$scope.buyNow.personalAccident.premiumCalculator.occupationSpouse=CommonServices.personalAccidentObj;
		$scope.buyNow.personalAccident.premiumCalculator.dateOfBirthspouse=CommonServices.personalAccidentObj;
		$scope.buyNow.personalAccident.premiumCalculator.dateOfBirthdaughter1=CommonServices.personalAccidentObj;
		$scope.buyNow.personalAccident.premiumCalculator.dateOfBirthdaughter2=CommonServices.personalAccidentObj;
		$scope.buyNow.personalAccident.premiumCalculator.dateOfBirthSon1=CommonServices.personalAccidentObj;
		$scope.buyNow.personalAccident.premiumCalculator.dateOfBirthSon2=CommonServices.personalAccidentObj;*/		
	}
//CR_0054
	var username = CommonServices.getCommonData("userCode");
	$sumInsuredB = false;
	var bt1;
	$scope.back = function () {
		if(CommonServices.editQuoteFlag === true){//CR_0054
			$state.go("managePolicies.managePolicies");
		}else
		$state.go('personalAccident');
	};

	//Date picker
	$scope.calIconClick = function (event) {
		angular.element("#" + event.currentTarget.children[0].id).focus();
	};

	var mydateStr = CommonServices.getCommonData("serverDate");

	var mynewdateFrom = new Date(mydateStr);

	var dd = mynewdateFrom.getDate();
	var mm = mynewdateFrom.getMonth() + 1;
	var yyyy = mynewdateFrom.getFullYear();

	if (dd < 10) {
		dd = "0" + dd;
	}

	if (mm < 10) {
		mm = "0" + mm;
	}
	todaysDate = dd + "/" + mm + "/" + yyyy;//policy start date
	var systemDate = mm + "/" + dd + "/" + yyyy;// mm/dd/yyyy
	//1 month to todays date

	futureDateCal = new Date(mydateStr);
	futureDateCal.setFullYear(futureDateCal.getFullYear() + 1);
	futureDateCal.setDate(futureDateCal.getDate() - 1);
	var dd = futureDateCal.getDate();
	var mm = futureDateCal.getMonth() + 1;
	var yyyy = futureDateCal.getFullYear();

	if (dd < 10) {
		dd = "0" + dd;
	}

	if (mm < 10) {
		mm = "0" + mm;
	}
	futureDateCal = dd + "/" + mm + "/" + yyyy;//policy start date

	var enableCalendarfrom = getFormattedDate(mynewdateFrom)
	//past 69 years
	var enableRegCalendarfrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 70));
	enableRegCalendarfrom = getFormattedDate(enableRegCalendarfrom);

	//past 18 years
	var enableRegValCalendarTo = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 18));
	enableRegValCalendarTo = getFormattedDate(enableRegValCalendarTo);
	//1 year from todays date
	var enableOneYearCalendarTo = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() + 1));
	enableOneYearCalendarTo = new Date(enableOneYearCalendarTo.setDate(enableOneYearCalendarTo.getDate() + 1));
	enableOneYearCalendarTo = getFormattedDate(enableOneYearCalendarTo);

	$('#birthdateself').loadCalendar({
		'enableDateRange': true,
		'enableCalendarFrom': enableRegCalendarfrom,
		'enableCalendarTo': systemDate
	});

	$('#birthdatespouse').loadCalendar({
		'enableDateRange': true,
		'enableCalendarFrom': enableRegCalendarfrom,
		'enableCalendarTo': systemDate
	});
	var enableRegCalendarfrm = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 25));
	enableRegCalendarfrm = new Date(enableRegCalendarfrm.setDate(enableRegCalendarfrm.getDate() + 1));
	enableRegCalendarfrm = getFormattedDate(enableRegCalendarfrm);

	//past 5 years
	var enableValCalendarTo = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 5));
	enableValCalendarTo = new Date(enableValCalendarTo.setDate(enableValCalendarTo.getDate() + 1));
	enableValCalendarTo = getFormattedDate(enableValCalendarTo);

	$('#birthdatedaught1').loadCalendar({
		'enableDateRange': true,
		'enableCalendarFrom': enableRegCalendarfrm,
		'enableCalendarTo': systemDate
	});
	$('#birthdatedaught2').loadCalendar({
		'enableDateRange': true,
		'enableCalendarFrom': enableRegCalendarfrm,
		'enableCalendarTo': systemDate
	});
	$('#birthdateson1').loadCalendar({
		'enableDateRange': true,
		'enableCalendarFrom': enableRegCalendarfrm,
		'enableCalendarTo': systemDate
	});
	$('#birthdateson2').loadCalendar({
		'enableDateRange': true,
		'enableCalendarFrom': enableRegCalendarfrm,
		'enableCalendarTo': systemDate
	});


	// validate only number
	$scope.numberexp = /^[\d]+$/;

	// validates 10 digit mobile no. expression starting with 5,6,7,8,or9
	$scope.mobileNumExp = /^([56789])(?!\1+$)\d{9}$/;

	// validates email id expression ex:a@b.com, a@b.co.in
	$scope.emailIdExp = /\b^[a-zA-Z0-9][a-zA-Z0-9._-]*@[a-zA-Z0-9-]+(\.[a-zA-Z]{2,4}){1,3}\b$/;

	//to validate Date of Birth Spouse
	$scope.checkSelfDob = function () {
		var rgValDt = $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthself; // dd/mm/yyyy
		var rgValDtArr = rgValDt.split("/");
		rgValDt = rgValDtArr[1] + "/" + rgValDtArr[0] + "/" + rgValDtArr[2]; // mm/dd/yyyy
		rgValDtVal = new Date(rgValDt);
		var enableRegVal = new Date(enableRegValCalendarTo);
		if (rgValDtVal > enableRegVal) {
			CommonServices.showAlert("Proposer age should be >=18 years and less than 70 years on the date of generating the quote");
			$scope.buyNow.personalAccident.premiumCalculator.dateOfBirthself = "";
		}
	};

	//click on submit button
	$scope.premiumResultScreen = function () {
		if((counts+countd)>2)
		{
			CommonServices.showAlert("Only 2 daughters and 2 sons allowed");
			return;
		}
		//to set data
		// CommonServices.setCommonData('paPolicyAutopopulatedData', $scope.prevNomineeDetailObj);
		CommonServices.setCommonData('paPolicyAutopopulatedData', $scope.autoPopulateDetails);
		$rootScope.resetData = true;

		$rootScope.countOfSon = counts;
		$rootScope.countOfDaughter = countd;
		CommonServices.setCommonData("occupationOfself", $scope.buyNow.personalAccident.premiumCalculator.occupationself);
		CommonServices.setCommonData("dateOfBirthOfself", $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthself);
		CommonServices.setCommonData("occupationOfspouse", $scope.buyNow.personalAccident.premiumCalculator.occupationSpouse);
		CommonServices.setCommonData("dateOfBirthOfspouse", $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthspouse);
		medicalcheck = jQuery('#medical').is(':checked') ? 'Y' : 'N';
		numberOfChildren = $('tr:visible').children(".datc").length;//to find number of children
		noOfChildren = numberOfChildren.toString();
		var numOfRelations = $('tr:visible').children("#relation").length;//to get relation values
		birthdates2 = $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthSon2;
		birthdates1 = $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthSon1;
		birthdated1 = $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthdaughter1;
		birthdated2 = $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthdaughter2;
		CommonServices.setCommonData("dateOfBirthSon1", $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthSon1);
		CommonServices.setCommonData("dateOfBirthSon2", $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthSon2);
		CommonServices.setCommonData("dateOfBirthdaughter1", $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthdaughter1);
		CommonServices.setCommonData("dateOfBirthdaughter2", $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthdaughter2);
		var arr = [];
		//class="JqRow"
		//$('#insuredinfo .rowc:visible').children("#relation").map(function () {
			$('#insuredinfo .JqRow:visible').children("#relation").map(function () {
			var res = $(this).text();
			arr.push(res);
		});

		if (arr.length == 1) {
			str = arr.join('');
		}
		else {
			str = arr.join('/');
		}
		var riskDetails1, coverDetails, riskDetails2;
		var coverDetails = {
			"medicalCoverReq": medicalcheck
		};


		var cover = "";
		if (str == "Self/Spouse") {
			cover = "Self/Spouse";
		}
		else if (str == "Self/Spouse" && str == "Self/Spouse/Son/Daughter" || str == "Self/Spouse/Son" || str == "Self/Spouse/Daughter" || str == "Self/Spouse/Son1/Son2" || str == "Self/Spouse/Daughter1/Daughter2") {
			cover = "Self/Spouse/Child";
		}
		else if (str == "Self/Daughter" || str == "Self/Son" || str == "Self/Son1/Son2" || str == "Self/Daughter1/Daughter2" || str == "Self/Son/Daughter") {
			cover = "Self/Child";
		}
		else {
			cover = "Self";
		}


		var PremiumData = {
			"userProfile": {
				"userId": username.toUpperCase(),
				"loggedInRole": "SUPERUSER"
			},
			"quote": {
				"isAddOnPA": "N",
				"quoteNumber": "",
				"policyHolderCode": "",
				"partyDetailsList": [],
				"productCode": "PU",
				"product": "PU",
				"policyStartDate": todaysDate,
				"policyExpiryDate": futureDateCal,
				"term": 1,
				"termUnit": "G",
				"eventDate": todaysDate,
				"coverage": cover,
				"numChildrenToCover": noOfChildren,
				"risks": []
			}
		};
		if(CommonServices.editQuoteFlag === true){//CR_0054
			PremiumData.quote.quoteNumber=CommonServices.personalAccidentObj.quoteNumber;
			}
		var premDataArray = [];
		for (var i = 0; i <= 1; i++) {

			if (i == 0)//self
			{
				spouse = false;
				self = true;
				numberOfChildren = 0;
				incomeselfc = "500000";
				incomeselfb = "500000";
				$scope.relation = "SELF";
				bdate = $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthself;
				occupation = $scope.buyNow.personalAccident.premiumCalculator.occupationself;
			}
			if (i == 1)//spouse
			{
				if (str == "Self/Spouse" || str == "Self/Spouse/Son/Daughter" || str == "Self/Spouse/Son" || str == "Self/Spouse/Daughter" || str == "Self/Spouse/Son1/Son2" || str == "Self/Spouse/Daughter1/Daughter2") {
					spouse = true;
					// SpouseEarning = jQuery('.switch-input').is(':checked') ? 'yes' : 'no';
					
					if ($scope.spouserowe) {
						incomeselfc = "500000";
						incomeselfb = "500000";
					}
					else {
						incomeselfc = "250000";
						incomeselfb = "250000";
					}
					$scope.relation = "SPOUSE";
					bdate = $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthspouse;
					occupation = $scope.buyNow.personalAccident.premiumCalculator.occupationSpouse;
					var name = "";
				}
				else {
					continue;
				}

			}
			var premData = {
				"coverages": [{
					"coverDetails": { "medicalCoverReq": medicalcheck }
				}],
				"riskDetails": {
					"sumInsuredForTableA": 0,
					"sumInsuredForTableB": incomeselfb,
					"sumInsuredForTableC": incomeselfc,
					"sumInsuredForTableD": 0,
					"relationWithNominee": "",
					"nomineeName": "",
					"monthlyIncome": "",
					"dateOfBirth": bdate,
					"relationWithPolicyHolder": $scope.relation,
					"nameOfInsuredPerson": name,
					"occupation": occupation
				}
			};
			premDataArray.push(premData);
		}
		var cs1 = 0, cs2 = 0, cd1 = 0, cd2 = 0;
		for (var i = 0; i < count; i++) {   				//CHILD

			var res, bdate;
			incomeselfc = "125000";
			incomeselfb = "125000";
			var birthdateson1, birthdateson2, birthdated1, birthdated2;
			$('#insuredinfo #sonrow1:visible').children("#relation").map(function () {
				cs1++;
			});
			$('#insuredinfo #sonrow2:visible').children("#relation").map(function () {
				cs2++;
				res = $(this).text();
				$scope.relation = "res";
			});

			$('#insuredinfo #daughterrow1:visible').children("#relation").map(function () {
				cd1++;
				res = $(this).html();
				$scope.relation = res;
			});
			$('#insuredinfo #daughterrow2:visible').children("#relation").map(function () {
				cd2++;
				res = $(this).text();

				$scope.relation = res;
			});
			var reltionWithPh;
			if (cs1 == 1) {
				bdate = birthdates1;
				cs2 = 0;
				cd1 = 0;
				cd2 = 0;
				reltionWithPh = "SON";
			}
			else if (cs2 == 1) {
				bdate = birthdates2;
				cs1 = 0;
				cd1 = 0;
				cd2 = 0;
				reltionWithPh = "SON";
			}
			else if (cd1 == 1) {
				bdate = birthdated1;
				cs1 = 0;
				cs2 = 0;
				cd2 = 0;
				reltionWithPh = "DAUTER";
			}
			else {
				bdate = birthdated2;
				cs1 = 0;
				cs2 = 0;
				cd1 = 0;
				reltionWithPh = "DAUTER";
			}
			var premDataChild = {
				"coverages": [{
					"coverDetails": { "medicalCoverReq": medicalcheck }
				}],
				"riskDetails": {
					"sumInsuredForTableA": "0",
					"sumInsuredForTableB": incomeselfb,
					"sumInsuredForTableC": incomeselfc,
					"sumInsuredForTableD": "0",
					"relationWithNominee": "",
					"nomineeName": "",
					"monthlyIncome": "0",
					"dateOfBirth": bdate,
					"relationWithPolicyHolder": reltionWithPh,
					"nameOfInsuredPerson": "",
					"occupation": "STU",
					"anyPhysicalDefects": "N",
					"anyPreviousClaim": "N"
				}
			};
			premDataArray.push(premDataChild);
		}
		PremiumData.quote.risks = premDataArray;
			$rootScope.memberLenghtPU = PremiumData.quote.risks.length; 
		var PremiumDataResponse = RestServices.postService(RestServices.urlPathsNewPortal.calcPremiumPA, PremiumData);
		//web service call for PremiumData
		PremiumDataResponse.then(
			function (response) {

				// success 

				CommonServices.showLoading(false);
				if (response.data.errorCode != undefined) {
					CommonServices.showAlert(response.data.errorMessage);
				}
				else {
					quoteNo = response.data.quote.quoteNumber;
					netPremium = response.data.quote.premiumDetails.netPremium;
					serviceTax = response.data.quote.premiumDetails.serviceTax;
					totalPremium = response.data.quote.premiumDetails.totalPremium;
					$state.go('premiumResult');
				}
			},
			function (error) {    // failure 
				CommonServices.showLoading(false);
				RestServices.handleWebServiceError(error);
			});
	};
	function close() {
		var elem = document.getElementById('rowspouse');
		elem.style.display = "none";
	}

	/** child controller **/

	count = 0;
	countd = 0;
	counts = 0;
	$scope.clickFunc = function (child, isAutoPopulate = false) {
		count += 1;
		var btns = document.querySelector('.btnson');

		var btnd = document.querySelector('.btndaughter');


		if (count == 1 && child == 'Son') {
			$scope.son1Required = true;
			$scope.son1Close = false;//added now
			counts += 1;
			document.getElementById('dynamicloads1').style.display = "flex";//SON1
			document.getElementById('sonrow1').style.display = "";
		}
		if (count == 1 && child == 'daughter') {
			$scope.daughter1 = true;
			$scope.daughter1close = false;//added now
			countd += 1;
			document.getElementById('dynamicload1').style.display = "flex";//DAUGHTER 1
			document.getElementById('daughterrow1').style.display = "";
		}
		if (count == 2 && child == 'Son') {
			counts += 1;
			if (countd == 1) {
				$scope.son1Close = false;//ADDED NOW
				document.getElementById('dynamicloads1').style.display = "flex";//SON1
				document.getElementById('sonrow1').style.display = "";
				$scope.son1Required = true;
			} else {
				if ($scope.son1Close == true) {
					$scope.son1Close = false;
					document.getElementById('dynamicloads1').style.display = "flex";//SON 2
					document.getElementById('sonrow1').style.display = "";
				} else {
					document.getElementById('dynamicloads2').style.display = "flex";//SON 2
					document.getElementById('sonrow2').style.display = "";
				}
				$scope.son2Required = true;
			}
		}
		if (count == 2 && child == 'daughter') {
			countd += 1;
			if (counts == 1) {
				$scope.daughter1 = true;
				$scope.daughter1close = false;//added now
				document.getElementById('dynamicload1').style.display = "flex";//DAUGHTER 1
				document.getElementById('daughterrow1').style.display = "";
			} else {
				$scope.daughter2 = true;
				if ($scope.daughter1close == true) {
					$scope.daughter1close = false;
					document.getElementById('dynamicload1').style.display = "flex";//DAUGHTER 1
					document.getElementById('daughterrow1').style.display = "";
				} else {
					document.getElementById('dynamicload2').style.display = "flex";//DAUGHTER 2
					document.getElementById('daughterrow2').style.display = "";
				}
			}
		}
		if (countd == 1 && counts == 1) {
			document.getElementById("click3").innerHTML = "";
			document.getElementById("click2").innerHTML = "";
			document.getElementById("clk3").innerHTML = "";
			document.getElementById("clk2").innerHTML = "";
		}
		if (counts == 1 && countd == 1) {
			document.getElementById("click1").innerHTML = "";
			document.getElementById("click4").innerHTML = "";
			document.getElementById("clk1").innerHTML = "";
			document.getElementById("clk4").innerHTML = "";
		}
		if (countd == 1 && counts != 1) {
			document.getElementById("click3").innerHTML = "";
			document.getElementById("clk3").innerHTML = "";
		}
		if (countd == 2) {
			document.getElementById("click3").innerHTML = 1;
			document.getElementById("click4").innerHTML = 2;
			document.getElementById("clk3").innerHTML = 1;
			document.getElementById("clk4").innerHTML = 2;

		}
		if (counts == 1 && countd != 1) {
			document.getElementById("click1").innerHTML = "";
			document.getElementById("clk1").innerHTML = "";
		}

		if (counts == 2) {
			document.getElementById("click2").innerHTML = 2;
			document.getElementById("click1").innerHTML = 1;
			document.getElementById("clk2").innerHTML = 2;
			document.getElementById("clk1").innerHTML = 1;
		}
		if (count === 2) {
			$scope.addDaughterDisable = true;
			$scope.addSonDisable = true;
		}
		if (count > 2) {
			$scope.addDaughterDisable = true;
			$scope.addSonDisable = true;
			$rootScope.maxTwo = true;
			// $scope.proposerSearchResult = isAutoPopulate;
			count -= 1;
			if (!$scope.proposerSearchResult) {
				CommonServices.showAlert("Max two child can be added. i.e. either 2 son or 2 daughter or 1 son and 1 daughter");
			}
			return false;
		}
		return true;
	}

	var set = 0;
	$scope.clicksp = function () {
		//disable save button on click of spouse button

		$scope.spouseSelected = true;
		$rootScope.spouseChosen = true;
		$rootScope.addSpouseDisable = true;

		$scope.spouserow = true;
		$scope.spouserowe = false;
		$scope.checked = ($scope.spouserowe);

		countsp += 1;
		var btnsp = document.querySelector('.btn-spouse');

		if (countsp == 1) {
			$rootScope.countOfSpouse = 1;
			$scope.addSpouseDisable = true;
			document.getElementById('selfandspouse').style.display = "flex";
		}
		if (countsp >= 1) {
			countsp = 0;
			btnsp.disabled = true;
			$scope.addSpouseDisable = true;
		}

	}
	$scope.closespouse = function (fromChk = true) {
		$rootScope.countOfSpouse = 0;
		$scope.spouseSelected = false;//to check if the fields are filled or not
		$rootScope.spouseChosen = false;
		$scope.spouserow = false;
		$scope.spouserowe = false;
		$scope.buyNow.personalAccident.premiumCalculator.dateOfBirthspouse = "";
		$scope.autoPopulateDetails.spouse = undefined;
		$('#occsp').prop('selectedIndex', "");
		$scope.checked = false;
		document.getElementById('spbtn').disabled = false;
		var elem = document.getElementById('selfandspouse');
		elem.style.display = "none";
		$scope.buyNow.personalAccident.premiumCalculator.occupationSpouse = '';
		onCloseProposerDetails('sp', fromChk);
		CommonServices.setCommonData("insuredNameSpouse", "");
	}
	$scope.closedaughter1 = function (fromChk = true) {
		if(countd > 1){
			$scope.buyNow.personalAccident.premiumCalculator.dateOfBirthdaughter1 = $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthdaughter2;
			if($scope.autoPopulateDetails != undefined){
				$scope.autoPopulateDetails.daughter1 = $scope.autoPopulateDetails.daughter2;
			}
			CommonServices.setCommonData("insuredNameDaught1", CommonServices.getCommonData("insuredNameDaught2"));
			CommonServices.setCommonData("insuredNameDaught2", undefined);
			$scope.closedaughter2();
		}
		else{
			$rootScope.maxTwo = false;
			$scope.daughter1close = true;
			$scope.daughter1 = false;
			$scope.buyNow.personalAccident.premiumCalculator.dateOfBirthdaughter1 = "";
			$scope.autoPopulateDetails.daughter1 =  undefined;
			$scope.addDaughterDisable = false;
			$scope.addSonDisable = false;
			if (countd > 0) countd -= 1;
			if (count > 0) count -= 1;
			var elem = document.getElementById('dynamicload1');
			elem.style.display = "none";
			var elem1 = document.getElementById('daughterrow1');
			elem1.style.display = "none";
			if (countd == 1 && counts != 1) {
				document.getElementById("click4").innerHTML = "";
				document.getElementById("clk4").innerHTML = "";
			}
			if (count == 0) {

			}
			onCloseProposerDetails('d1', fromChk);
		}
	}
	$scope.closedaughter2 = function (fromChk = true) {
		$rootScope.maxTwo = false;
		$scope.daughter2close = true;
		$scope.daughter2 = false;
		$scope.buyNow.personalAccident.premiumCalculator.dateOfBirthdaughter2 = "";
		$scope.autoPopulateDetails.daughter2 =  undefined;
		$scope.addDaughterDisable = false;
		$scope.addSonDisable = false;
		if (countd > 0) countd -= 1;
		if (count > 0) count -= 1;
		var elem = document.getElementById('dynamicload2');
		elem.style.display = "none";
		var elem2 = document.getElementById('daughterrow2');
		elem2.style.display = "none";
		if (countd == 1 && counts != 1) {
			document.getElementById("click3").innerHTML = "";
			document.getElementById("clk3").innerHTML = "";
		}
		if (count == 0) {

		}
		onCloseProposerDetails('d2', fromChk);
	}
	$scope.closeson1 = function (fromChk = true) {
		if(counts > 1){
			$scope.buyNow.personalAccident.premiumCalculator.dateOfBirthSon1 = $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthSon2;
			if($scope.autoPopulateDetails != undefined){
				$scope.autoPopulateDetails.son1 = $scope.autoPopulateDetails.son2;
			}
			CommonServices.setCommonData("InsuredNameSon1", CommonServices.getCommonData("InsuredNameSon2"));
			CommonServices.setCommonData("InsuredNameSon2", undefined);
			$scope.closeson2();
		}
		else {
			$rootScope.maxTwo = false;
			$scope.son1Close = true;
			$scope.son1Required = false;
			$scope.addDaughterDisable = false;
			$scope.addSonDisable = false;
			if (counts > 0) counts -= 1;
			if (count > 0) count -= 1;
			$scope.buyNow.personalAccident.premiumCalculator.dateOfBirthSon1 = "";
			if($scope.autoPopulateDetails != undefined){
				$scope.autoPopulateDetails.son1 =  undefined;
			}		
			var elem = document.getElementById('dynamicloads1');
			elem.style.display = "none";
			var ele1 = document.getElementById('sonrow1');
			ele1.style.display = "none";
			if (counts == 1 && countd != 1) {
				document.getElementById("click2").innerHTML = "";
				document.getElementById("clk2").innerHTML = "";
			}
			if (count == 0) {

			}
			onCloseProposerDetails('s1', fromChk);
		}
	}
	$scope.closeson2 = function (fromChk = true) {
		$rootScope.maxTwo = false;
		$scope.son2Close = true;
		$scope.son2Required = false;
		$scope.addDaughterDisable = false;
		$scope.addSonDisable = false;
		if (counts > 0) counts -= 1;
		if (count > 0) count -= 1;
		$scope.buyNow.personalAccident.premiumCalculator.dateOfBirthSon2 = "";
		$scope.autoPopulateDetails.son2 =  undefined;
		var elem = document.getElementById('dynamicloads2');
		elem.style.display = "none";
		var ele2 = document.getElementById('sonrow2');
		ele2.style.display = "none";
		if (counts == 1 && countd != 1) {
			document.getElementById("click1").innerHTML = "";
			document.getElementById("clk1").innerHTML = "";
		}
		if (count == 0) {
		}
		onCloseProposerDetails('s2', fromChk);
	}
	function onCloseProposerDetails(type, fromChk) {
		//if ($scope.proposerSearchResult && fromChk) {
		// if (fromChk) {
		// 	angular.forEach($scope.prevNomineeDetailObj, function (obj, i) {
		// 		if (obj.isSelected && 
		// 			((type === 'sp' && obj.relation === 'SPOUSE') || 
		// 			(type === 's1' && obj.relation === 'CHILDREN' && obj.sex === 'M') || 
		// 			(type === 's2' && obj.relation === 'CHILDREN' && obj.sex === 'M') || 
		// 			(type === 'd1' && obj.relation === 'CHILDREN' && obj.sex === 'F') || 
		// 			(type === 'd2' && obj.relation === 'CHILDREN' && obj.sex === 'F'))) {

		// 			obj.isSelected = false;
		// 		}
		// 	});
		// }
	}

	var result;
	$scope.spouseEarningCheck = function () {
		var SpouseEarning = $scope.checked;
		if (SpouseEarning == true) {
			$rootScope.spEarning = "yes";
			$scope.spouserowe = true;
			$scope.spouserow = false;
		}
		else {
			$rootScope.spEarning = "no";
			$scope.spouserow = true;
			$scope.spouserowe = false;
		}
	};

	var numOfChildren = 0;

	//service data

	$scope.condition1 = function () {
		var returnValue = false;
		var result = jQuery('.switch-input').is(':checked') ? 'yes' : 'no';
		if (result == "yes") {
			returnValue = true;
			$scope.isRequired = returnValue;
		}

		return returnValue;
	};
	$scope.checkifselected = function () {
		$scope.isRequired = true;
	};
	$scope.change = function () {
		var rgValDt = $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthspouse; // dd/mm/yyyy
		var rgValDtArr = rgValDt.split("/");
		rgValDt = rgValDtArr[1] + "/" + rgValDtArr[0] + "/" + rgValDtArr[2]; // mm/dd/yyyy
		rgValDtVal = new Date(rgValDt);
		var enableRegVal = new Date(enableRegValCalendarTo);
		if (rgValDtVal > enableRegVal) {
			CommonServices.showAlert("Spouse age should be >=18 years and less than 70 years on the date of generating the quote");
			$scope.buyNow.personalAccident.premiumCalculator.dateOfBirthspouse = "";
			return false;
		}
		return true;

	};
	$scope.change1 = function () {
		var rgValDt = $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthdaughter1; // dd/mm/yyyy
		var rgValDtArr = rgValDt.split("/");
		rgValDt = rgValDtArr[1] + "/" + rgValDtArr[0] + "/" + rgValDtArr[2]; // mm/dd/yyyy
		rgValDtVal = new Date(rgValDt);
		var enableRegVal = new Date(enableValCalendarTo);
		if (rgValDtVal > enableRegVal) {
			CommonServices.showAlert("Child age should be >=5 years and less than 25 years on the date of generating the quote");
			$scope.buyNow.personalAccident.premiumCalculator.dateOfBirthdaughter1 = "";
		}
	};
	$scope.change2 = function () {
		var rgValDt = $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthdaughter2; // dd/mm/yyyy
		var rgValDtArr = rgValDt.split("/");
		rgValDt = rgValDtArr[1] + "/" + rgValDtArr[0] + "/" + rgValDtArr[2]; // mm/dd/yyyy
		rgValDtVal = new Date(rgValDt);
		var enableRegVal = new Date(enableValCalendarTo);
		if (rgValDtVal > enableRegVal) {
			CommonServices.showAlert("Child age should be >=5 years and less than 25 years on the date of generating the quote");
			$scope.buyNow.personalAccident.premiumCalculator.dateOfBirthdaughter2 = "";
		}
	};
	$scope.change3 = function () {
		var rgValDt = $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthSon1; // dd/mm/yyyy
		var rgValDtArr = rgValDt.split("/");
		rgValDt = rgValDtArr[1] + "/" + rgValDtArr[0] + "/" + rgValDtArr[2]; // mm/dd/yyyy
		rgValDtVal = new Date(rgValDt);
		var enableRegVal = new Date(enableValCalendarTo);
		if (rgValDtVal > enableRegVal) {
			CommonServices.showAlert("Child age should be >=5 years and less than 25 years on the date of generating the quote");
			$scope.buyNow.personalAccident.premiumCalculator.dateOfBirthSon1 = "";
		}
	};
	$scope.change4 = function () {
		var rgValDt = $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthSon2; // dd/mm/yyyy
		var rgValDtArr = rgValDt.split("/");
		rgValDt = rgValDtArr[1] + "/" + rgValDtArr[0] + "/" + rgValDtArr[2]; // mm/dd/yyyy
		rgValDtVal = new Date(rgValDt);
		var enableRegVal = new Date(enableValCalendarTo);
		if (rgValDtVal > enableRegVal) {
			CommonServices.showAlert("Child age should be >=5 years and less than 25 years on the date of generating the quote");
			$scope.buyNow.personalAccident.premiumCalculator.dateOfBirthSon2 = "";
		}
	};
	$scope.medicalChange = function () {
		$rootScope.medicalCoverSelected = $scope.switch;

	}
	//to store data
	if ($rootScope.backData === "premiumCalculatorPage") {
		$scope.buyNow.personalAccident.premiumCalculator.occupationself = CommonServices.getCommonData("occupationOfself");
		$scope.buyNow.personalAccident.premiumCalculator.dateOfBirthself = CommonServices.getCommonData("dateOfBirthOfself");
		if ($rootScope.countOfSpouse == 1) {
			$scope.addSpouseDisable = true;
			document.getElementById('selfandspouse').style.display = "flex";
			$scope.buyNow.personalAccident.premiumCalculator.occupationSpouse = CommonServices.getCommonData("occupationOfspouse");
			$scope.buyNow.personalAccident.premiumCalculator.dateOfBirthspouse = CommonServices.getCommonData("dateOfBirthOfspouse");
		}
		if ($rootScope.spEarning == "yes" && $rootScope.spouseChosen == true) {
			$scope.checked = true;
			$scope.spouserowe = true;
			$scope.spouserow = false;
		}
		else if ($rootScope.spouseChosen == true) {
			$scope.checked = false;
			$scope.spouserow = true;
			$scope.spouserowe = false;
		}
		else if ($rootScope.spouseChosen == false) {
			$scope.spouserow = false;
			$scope.spouserowe = false;
		}
		else {

		}
		if ($rootScope.medicalCoverSelected == true) {
			$scope.switch = true;

		}
		if ($rootScope.countOfSon == 1 && $rootScope.countOfDaughter != 1) {
			counts = 1;
			count = 1;
			document.getElementById("click1").innerHTML = "";
			document.getElementById("clk1").innerHTML = "";
			document.getElementById('dynamicloads1').style.display = "flex";//SON1
			document.getElementById('sonrow1').style.display = "";

		}
		if ($rootScope.countOfSon == 2) {
			counts = 2;
			count = 2;
			if ($rootScope.maxTwo == true) {
				$scope.addDaughterDisable = true;
				$scope.addSonDisable = true;
			}
			document.getElementById("click2").innerHTML = 2;
			document.getElementById("click1").innerHTML = 1;
			document.getElementById("clk2").innerHTML = 2;
			document.getElementById("clk1").innerHTML = 1;
			document.getElementById('dynamicloads1').style.display = "flex";//SON1
			document.getElementById('sonrow1').style.display = "";
			document.getElementById('dynamicloads2').style.display = "flex";//SON 2
			document.getElementById('sonrow2').style.display = "";

		}
		if ($rootScope.countOfDaughter == 2) {

			countd = 2;
			count = 2;
			if ($rootScope.maxTwo == true) {
				$scope.addDaughterDisable = true;
				$scope.addSonDisable = true;
			}
			document.getElementById("click3").innerHTML = 1;
			document.getElementById("click4").innerHTML = 2;
			document.getElementById("clk3").innerHTML = 1;
			document.getElementById("clk4").innerHTML = 2;
			document.getElementById('dynamicload1').style.display = "flex";//DAUGHTER 1
			document.getElementById('daughterrow1').style.display = "";
			document.getElementById('dynamicload2').style.display = "flex";//DAUGHTER 1
			document.getElementById('daughterrow2').style.display = "";
		}
		if ($rootScope.countOfDaughter == 1 && $rootScope.countOfSon != 1) {

			countd = 1;
			count = 1;
			document.getElementById("click3").innerHTML = "";
			document.getElementById("clk3").innerHTML = "";
			document.getElementById('dynamicload1').style.display = "flex";//DAUGHTER 1
			document.getElementById('daughterrow1').style.display = "";
		}
		if ($rootScope.countOfDaughter == 1 && $rootScope.countOfSon == 1) {
			counts = 1;
			countd = 1;
			count = 2;
			if ($rootScope.maxTwo == true) {
				$scope.addDaughterDisable = true;
				$scope.addSonDisable = true;
			}
			document.getElementById("click3").innerHTML = "";
			document.getElementById("click1").innerHTML = "";
			document.getElementById("clk3").innerHTML = "";
			document.getElementById("clk1").innerHTML = "";
			document.getElementById('dynamicload1').style.display = "flex";//DAUGHTER 1
			document.getElementById('daughterrow1').style.display = "";
			document.getElementById('dynamicloads1').style.display = "flex";//SON1
			document.getElementById('sonrow1').style.display = "";
		}
	}
	if ($rootScope.resetData == true) {
		$scope.buyNow.personalAccident.premiumCalculator.dateOfBirthSon1 = "";
		$scope.buyNow.personalAccident.premiumCalculator.dateOfBirthSon2 = "";
		$scope.buyNow.personalAccident.premiumCalculator.dateOfBirthdaughter1 = "";
		$scope.buyNow.personalAccident.premiumCalculator.dateOfBirthdaughter2 = "";
	}
	else {
		$scope.buyNow.personalAccident.premiumCalculator.dateOfBirthSon1 = CommonServices.getCommonData("dateOfBirthSon1");
		$scope.buyNow.personalAccident.premiumCalculator.dateOfBirthSon2 = CommonServices.getCommonData("dateOfBirthSon2");
		$scope.buyNow.personalAccident.premiumCalculator.dateOfBirthdaughter1 = CommonServices.getCommonData("dateOfBirthdaughter1");
		$scope.buyNow.personalAccident.premiumCalculator.dateOfBirthdaughter2 = CommonServices.getCommonData("dateOfBirthdaughter2");
	}

	/* CR 3562 START */
	if ($rootScope.resetData != undefined && !$rootScope.resetData && $rootScope.backData != undefined && $rootScope.backData == "premiumCalculatorPage") {
        $scope.prevNomineeDetailObj = CommonServices.getCommonData('paPolicyAutopopulatedData');
    } else {
        $scope.prevNomineeDetailObj = [];
    }
	$scope.showMobileOptn = false;
	$scope.proposerSearchResult = false;
	$scope.searchObj = {};
	$scope.getProposerDerails = function (type) {

		if (type === 'policyNumber' && ($scope.searchFromList.prevPolicyNumber.$invalid || $scope.searchObj.prevPolicyNumber === undefined || $scope.searchObj.prevPolicyNumber.trim() === '')) return;
		if (type === 'mobileNumber' && ($scope.searchFromList.mobileNumber.$invalid || $scope.searchObj.prevPolicyMobileNumber === undefined || $scope.searchObj.prevPolicyMobileNumber.trim() === '')) return;
		
		var domainInputValues = {
			"quote": {
				"policyNumber":$scope.searchObj.prevPolicyNumber.trim()
			},
			"userProfile":{
				"userId": CommonServices.getCommonData("userId"),
				"loggedInRole": "SUPERUSER"
			}
		};
		var comparedMobileNumber = $scope.searchObj.prevPolicyMobileNumber;

		RestServices.postService(RestServices.urlPathsNewPortal.fetchHealthMemberDetail, domainInputValues).then(function (response) {
			CommonServices.showLoading(false);

			if (response.data.errorCode === 959) {
				CommonServices.showAlert(response.data.errorMessage);
				return;

			} else if (response.data.quote.flagPrevPortal === 1 && type === 'policyNumber') {
				var msg = "As this policy is not attached to you, in order to proceed further please enter the customer's mobile number and search again";
				CommonServices.messageModal('info', msg, false, '', 'Ok', function() {}, function() {
					$scope.showMobileOptn = true;
					// $scope.proposerSearchResult = false;
				}, 'Alert');

			} else if (response.data.quote.contactno != undefined && response.data.quote.contactno != comparedMobileNumber && type === 'mobileNumber') {
				var msg = "Mobile number entered does not match with Mobile number in policy holder details of previous health policy. Please enter correct mobile number";
					CommonServices.messageModal('info', msg, false, '', 'Ok', function() {}, function() {
						$scope.showMobileOptn = true;
						// $scope.proposerSearchResult = false;
						//$scope.searchObj.prevPolicyNumber = ''; //To fix the issue for CR_3562 - Sudip
                        $scope.searchObj.prevPolicyMobileNumber = ''; //To fix the issue for CR_3562 - sudip
					}, 'Alert');

			} else if (response.data.quote.memberDetails === undefined) {
                var msg = "No data found";
					CommonServices.messageModal('info', msg, false, '', 'Ok', function() {}, function() {
						$scope.showMobileOptn = false;
                    }, 'Alert');
                    
            } else {
				$scope.prevNomineeDetailObj = response.data.quote.memberDetails;
				angular.forEach($scope.prevNomineeDetailObj, function (value, key) {
					value.isSelected = false;
				});
				$scope.proposerSearchResult = true; //
				CommonServices.noOfMembers = (counts + countd + 1 + ($scope.addSpouseDisable?1:0));
				CommonServices.counts = counts;
				CommonServices.countd = countd;
				var obj = {
					page: 'PU_policyAutoPopulate', 
					title: 'Proposer Search Result', 
					footer: true, 
					bodyMsg: 'Test',
					dataSet: $scope.prevNomineeDetailObj,
					noBtnText: 'Cancel',
					noButtonAction: $scope.searchSelectionAction,
					yesBtnText: 'Ok',
					yesButtonAction: $scope.searchSelectionAction,
					proposer: true,
					spouse: $scope.addSpouseDisable,
					// chkAction: $scope.autoPopulateChkAction
				};
				openRelationalModal(obj, 'lg');
			}

		},
		function (error) {    // failure 
			CommonServices.showLoading(false);
			RestServices.handleWebServiceError(error);
		});
	}

	openRelationalModal = function (modalObj = {}, modalSize = 'lg') {
		var modalInstance = $modal.open({
			animation: false,
			templateUrl: 'partials/general/generalModal.html',
			controller: 'generalModalController',
			windowClass: 'general-modal',
			size: modalSize,
			resolve: {
				modalData: function() {
					return modalObj
				}
			}
		});
		modalInstance.result.then(function(result) {
			//backdropClass: ".modal-backdrop .fade";
			// console.log(result);
		});
	};

	var tempPolicyMaxLen = 0;
	$scope.searchObj.validatePolicyNumber = function (data, maxLen) {
		if (data !== undefined) {
			var len = data.toString().length;
			if (len > maxLen) {
				$scope.searchObj.prevPolicyNumber = tempPolicyMaxLen;
			} else {
				var result = /^\d*$/.test(data);
				if (result) {
					tempPolicyMaxLen = $scope.searchObj.prevPolicyNumber;
				}
				if (len === maxLen) {
					$scope.searchFromList.prevPolicyNumber.$invalid = false;
				} else {
					$scope.searchFromList.prevPolicyNumber.$invalid = true;
				}
			}
		}
	}
	var occupationObj = {};
	$scope.autoPopulateChkAction = function (i, obj) {
		var ret = true;
		if (obj.relation.toLowerCase() === 'self' || obj.relation.toLowerCase() === 'proposer') {
			if (obj.isSelected) {
				occupationObj = getSelectedOccupationObj(obj.occupation);
				$scope.buyNow.personalAccident.premiumCalculator.occupationself = occupationObj.codeValue;
				$scope.buyNow.personalAccident.premiumCalculator.dateOfBirthself = obj.dob;
				$scope.checkSelfDob();

			} 
			// else {
			// 	$scope.buyNow.personalAccident.premiumCalculator.occupationself = '';
			// 	$scope.buyNow.personalAccident.premiumCalculator.dateOfBirthself = '';
			// 	// $scope.closespouse(false);
			// 	// $scope.closeson2(false);
			// 	// $scope.closeson1(false);
			// 	// $scope.closedaughter2(false);
			// 	// $scope.closedaughter1(false);
			// }
		} else if (obj.relation.toLowerCase() === 'spouse') {
			if (obj.isSelected) {
				$scope.clicksp();
				occupationObj = getSelectedOccupationObj(obj.occupation);
				$scope.buyNow.personalAccident.premiumCalculator.occupationSpouse = occupationObj.codeValue;
				$scope.checkifselected();
				$scope.buyNow.personalAccident.premiumCalculator.dateOfBirthspouse = obj.dob;
				if($scope.change())
					$scope.autoPopulateDetails.spouse = obj;
			} 
			// else {
			// 	$scope.closespouse(false);
			// 	$scope.buyNow.personalAccident.premiumCalculator.occupationSpouse = '';
			// 	$scope.buyNow.personalAccident.premiumCalculator.dateOfBirthspouse = '';
			// }
		} else if ((obj.relation.toLowerCase() === 'children' || obj.relation.toLowerCase() === 'son') && obj.sex === 'M') {
			if (obj.isSelected) {
				ret = $scope.clickFunc('Son', true);
				if (ret) {
					var model = "dateOfBirthSon"+(counts);
					$scope.buyNow.personalAccident.premiumCalculator[model] = obj.dob;
					if (counts ===0) $scope.change3();
					else if (counts === 1) $scope.change4();
				} else {
					//obj.isSelected = false;
				}
			} else {
				if (counts === 1) $scope.closeson1(false);
				else if (counts === 2) $scope.closeson2(false);
			}
		} else if ((obj.relation.toLowerCase() === 'children' || obj.relation.toLowerCase() === 'daughter') && obj.sex === 'F') {
			if (obj.isSelected) {
				ret = $scope.clickFunc('daughter', true);
				if (ret) {
					var model = "dateOfBirthdaughter"+countd;
					$scope.buyNow.personalAccident.premiumCalculator[model] = obj.dob;
					if (countd === 0) $scope.change1();
					else if (countd === 1) $scope.change2();
				} else {
					//obj.isSelected = false;
				}
			} else {
				if (countd === 1) $scope.closedaughter1(false);
				else if (countd === 2) $scope.closedaughter2(false);
			}
		}
		CommonServices.setCommonData('paTotalChildAdded', count);
	}
	$scope.searchSelectionAction_bkp = function (isConfirm) {
		if (!isConfirm) { //Cancel
			$scope.closespouse();
			$scope.closedaughter1();
			$scope.closedaughter2();
			$scope.closeson1();
			$scope.closeson2();
			
			$scope.buyNow.personalAccident.premiumCalculator.occupationself = '';
			$scope.buyNow.personalAccident.premiumCalculator.dateOfBirthself = '';
			$scope.buyNow.personalAccident.premiumCalculator.occupationSpouse = '';
			$scope.buyNow.personalAccident.premiumCalculator.dateOfBirthspouse = '';
			if ($scope.buyNow.personalAccident.premiumCalculator.dateOfBirthSon1 != undefined) $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthSon1 = '';
			if ($scope.buyNow.personalAccident.premiumCalculator.dateOfBirthSon2 != undefined) $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthSon2 = '';
			if ($scope.buyNow.personalAccident.premiumCalculator.dateOfBirthdaughter1 != undefined) $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthdaughter1 = '';
			if ($scope.buyNow.personalAccident.premiumCalculator.dateOfBirthdaughter2 != undefined) $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthdaughter2 = '';
		}
		$scope.proposerSearchResult = false;
		$scope.showMobileOptn = false;
		$scope.searchObj.prevPolicyNumber = '';
		$scope.searchObj.prevPolicyMobileNumber = '';
	}
	if(CommonServices.getCommonData('paPolicyAutopopulatedData') != undefined)
		$scope.autoPopulateDetails = CommonServices.getCommonData('paPolicyAutopopulatedData');
	else
		$scope.autoPopulateDetails = {
			self: undefined,
			spouse: undefined,
			son1: undefined,
			son2: undefined,
			daughter1: undefined,
			daughter2: undefined,
		}
	$scope.searchSelectionAction = function (isConfirm) {
		//resetProposerDetail();
		let tempDate = "";
		let tempObj = undefined;
		let flag = "";
		if(counts > 0 && countd < 1){
			tempDate = $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthSon1;
			tempObj = $scope.autoPopulateDetails.son1;
			flag = "s";
		}
		else if(countd > 0 && counts < 1){
			tempDate = $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthdaughter1;
			tempObj = $scope.autoPopulateDetails.daughter1;
			flag= "d";
		}
        if (isConfirm && count <= 2) { //OK
            angular.forEach($scope.prevNomineeDetailObj, function (obj, i) {
                if (obj.relation.toLowerCase() === 'self' || obj.relation.toLowerCase() === 'proposer') {
                    if (obj.isSelected) {
                        occupationObj = getSelectedOccupationObj(obj.occupation);
						$scope.buyNow.personalAccident.premiumCalculator.occupationself = occupationObj.codeValue;
						$scope.buyNow.personalAccident.premiumCalculator.dateOfBirthself = obj.dob;
						$scope.autoPopulateDetails.self = obj;
						$scope.checkSelfDob();
                    }
                } else if (obj.relation.toLowerCase() === 'spouse') {
                    if (obj.isSelected) {
                        $scope.clicksp();
						occupationObj = getSelectedOccupationObj(obj.occupation);
						$scope.buyNow.personalAccident.premiumCalculator.occupationSpouse = occupationObj.codeValue;
						$scope.checkifselected();
						$scope.buyNow.personalAccident.premiumCalculator.dateOfBirthspouse = obj.dob;
						CommonServices.setCommonData("insuredNameSpouse", obj.name);
						$scope.autoPopulateDetails.spouse = obj;
						$scope.change();
                    }
				}
				// else if (obj.isSelected && ((counts + countd) == 2)) {
				// 	CommonServices.showAlert("For Personal Accident, maximum 2 children can be added.");
				// 	return;
				// }
				 else if ((obj.relation.toLowerCase() === 'children' || obj.relation.toLowerCase() === 'child' || obj.relation.toLowerCase() === 'son') && obj.sex === 'M') {
					if (obj.isSelected) {
						// if(resetflag==0){
						// 	resetProposerDetail();
						// 	resetFlag = 1;
						// }
						ret = $scope.clickFunc('Son', true);
						if (ret) {
							var model = "dateOfBirthSon"+(counts);
							$scope.buyNow.personalAccident.premiumCalculator[model] = obj.dob;
							if (counts === 1) {
								$scope.change3();
								$scope.autoPopulateDetails.son1 = obj;
								CommonServices.setCommonData("InsuredNameSon1", obj.name);
							}
							else if (counts === 2) {
								$scope.change4();
								$scope.autoPopulateDetails.son2 = obj;
							}
						}
						if(counts == 2 && flag=="s"){
							$scope.buyNow.personalAccident.premiumCalculator.dateOfBirthSon1 = $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthSon2;
							$scope.buyNow.personalAccident.premiumCalculator.dateOfBirthSon2 = tempDate;
							$scope.autoPopulateDetails.son1 = $scope.autoPopulateDetails.son2;
							$scope.autoPopulateDetails.son2 = tempObj;
							CommonServices.setCommonData("InsuredNameSon1", $scope.autoPopulateDetails.son1.name);
							CommonServices.setCommonData("InsuredNameSon2", $scope.autoPopulateDetails.son2.name);

						}
					}
				} else if ((obj.relation.toLowerCase() === 'children' || obj.relation.toLowerCase() === 'child' || obj.relation.toLowerCase() === 'daughter') && obj.sex === 'F') {
					if (obj.isSelected) {
						// if(resetflag==0){
						// 	resetProposerDetail();
						// 	resetFlag = 1;
						// }
						ret = $scope.clickFunc('daughter', true);
						if (ret) {
							var model = "dateOfBirthdaughter"+countd;
							$scope.buyNow.personalAccident.premiumCalculator[model] = obj.dob;
							if (countd === 1) {
								$scope.change1();
								$scope.autoPopulateDetails.daughter1 = obj;
								CommonServices.setCommonData("insuredNameDaught1", obj.name);
							}
							else if (countd === 2) {
								$scope.change2();
								$scope.autoPopulateDetails.daughter2 = obj;
								if(flag==="")	
									$scope.buyNow.personalAccident.daughterDetails.InsuredNamed1=obj.name;
							}
						}
						if(countd == 2 && flag=="d"){
							$scope.buyNow.personalAccident.premiumCalculator.dateOfBirthdaughter1 = $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthdaughter2;
							$scope.buyNow.personalAccident.premiumCalculator.dateOfBirthdaughter2 = tempDate;
							$scope.autoPopulateDetails.daughter1 = $scope.autoPopulateDetails.daughter2;
							$scope.autoPopulateDetails.daughter2 = tempObj;
							CommonServices.setCommonData("insuredNameDaught1", $scope.autoPopulateDetails.daughter1.name);
							CommonServices.setCommonData("insuredNameDaught2", $scope.autoPopulateDetails.daughter2.name);
						}
					}
				}
				CommonServices.setCommonData('paTotalChildAdded', count);
            });
        }
		$scope.proposerSearchResult = false;
		$scope.showMobileOptn = false;
		// $scope.searchObj.prevPolicyNumber = ''; // removed to keep the policy nummber in the search box
		$scope.searchObj.prevPolicyMobileNumber = '';
	}
	// function resetProposerDetail () {
	// 	// $scope.closespouse();
	// 	$scope.closedaughter1(); //to fix the issue - Sudip
	// 	$scope.closedaughter2(); //to fix the issue - Sudip
	// 	$scope.closeson1(); //to fix the issue - Sudip
	// 	$scope.closeson2(); //to fix the issue - Sudip
	// 	// $scope.buyNow.personalAccident.premiumCalculator.occupationself = '';
	// 	// $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthself = '';
	// 	// $scope.buyNow.personalAccident.premiumCalculator.occupationSpouse = '';
	// 	// $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthspouse = '';
	// 	// Commented  for 3562: Ayush
	// 	if ($scope.buyNow.personalAccident.premiumCalculator.dateOfBirthSon1 != undefined) $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthSon1 = '';
	// 	if ($scope.buyNow.personalAccident.premiumCalculator.dateOfBirthSon2 != undefined) $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthSon2 = '';
	// 	if ($scope.buyNow.personalAccident.premiumCalculator.dateOfBirthdaughter1 != undefined) $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthdaughter1 = '';
	// 	if ($scope.buyNow.personalAccident.premiumCalculator.dateOfBirthdaughter2 != undefined) $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthdaughter2 = '';
    // }


	function getSelectedOccupationObj (o) {
		var obj = {
			codeId: "",
			codeValue: "",
			description: "",
			domainId: '',
			lngCode: "",
			mnemonic: "",
			sortOrder: null
		};
		angular.forEach(CommonServices.getCommonData("OCCUPATION"), function (value, key) {
			if (value.mnemonic.toLowerCase() === o.toLowerCase()) {
				obj = value;
				return;
			}
		});
		return obj;
	}
	/* CR 3562 END */

}]);

agentApp.controller('premiumResultCtrl', ['$scope', '$rootScope', '$location', 'RestServices', 'CommonServices', '$state', function ($scope, $rootScope, $location, RestServices, CommonServices, $state) {
	if ($scope.buyNow.personalAccident.saveQuoteRes.netPremium === undefined) {
		$rootScope.PAView = false;
	}
	$rootScope.polHolderDetails=false;
	$scope.quoteNo = quoteNo;
	$scope.totalPremium = totalPremium;
	$scope.serviceTax = serviceTax;
	$scope.netPremium = netPremium;
	$scope.viewBreakLink = true;
	var viewCountDaught = 0, viewCountSon = 0;
	var username = CommonServices.getCommonData("userCode");
	//view break up  srevice call
	$scope.showBreakTable = function () {
		var viewBreakInput = {
			"quote": {
				"quoteNumber": quoteNo,
				"policyHolderCode": $rootScope.PAView === true ? showData : ""
			},
			"userProfile": {
				"userId": username.toUpperCase(),
				"loggedInRole": "SUPERUSER"
			}
		};
		var viewBreakResponse = RestServices.postService(RestServices.urlPathsNewPortal.getPAPremiumDistribution, viewBreakInput);
		viewBreakResponse.then(
			function (response) {// success 
				CommonServices.showLoading(false);
				if (response.data.userProfile.footer.errorCode === "0") {
					$scope.viewBreakUpData = response.data.quote;
					$scope.viewBreakUpRisks = response.data.quote.risks;
					for (i = 0; i < response.data.quote.risks.length; i++) {
						if (response.data.quote.risks[i].paDistributionDTOs.relation == "DAUGHTER") {
							viewCountDaught++;
						}
						if (response.data.quote.risks[i].paDistributionDTOs.relation == "SON") {
							viewCountSon++;
						} if (countd === 1 || counts == 1) {

						}
						else {
							if (response.data.quote.risks[i].paDistributionDTOs.relation == "DAUGHTER" && viewCountDaught === 1) {
								$scope.viewBreakUpRisks[i].paDistributionDTOs.relation = "DAUGHTER 1";
							}
							else if (response.data.quote.risks[i].paDistributionDTOs.relation == "DAUGHTER" && viewCountDaught === 2) {
								$scope.viewBreakUpRisks[i].paDistributionDTOs.relation = "DAUGHTER 2";
							} else if (response.data.quote.risks[i].paDistributionDTOs.relation == "SON" && viewCountSon === 1) {
								$scope.viewBreakUpRisks[i].paDistributionDTOs.relation = "SON 1";
							} else if (response.data.quote.risks[i].paDistributionDTOs.relation == "SON" && viewCountSon === 2) {
								$scope.viewBreakUpRisks[i].paDistributionDTOs.relation = "SON 2";
							} else {

							}
						}
					}
					$scope.papViewBreak = true;
				}
				$scope.viewBreakLink = false;
			},
			function (error) {    // failure 
				CommonServices.showLoading(false);
				RestServices.handleWebServiceError(error);
			});

	};
	$scope.closeViewBreak = function () {
		$scope.papViewBreak = false;
	}

	$scope.back = function () {
		$rootScope.backData = "premiumCalculatorPage";
		$rootScope.resetData = false;
		$state.go('premiumCalculator');
	};

	$scope.InsuredDetailsScreen = function () {
		$state.go('InsuredDetails');
	};

}]);

agentApp.controller('InsuredDetailsCtrl', ['$scope', '$filter', '$rootScope', '$location', 'RestServices', 'CommonServices', '$state', function ($scope, $filter, $rootScope, $location, RestServices, CommonServices, $state) {
	$scope.buyNow.personalAccident.insuredDetails = {};
	$scope.buyNow.personalAccident.individualDetails = {};
	$scope.memberLength = $rootScope.memberLenghtPU;
	$rootScope.insuredData = {};
	$scope.polNoData = false;
	$scope.redirectInsuredDetails = false;
	$scope.gstinMsg = "GSTIN";
	var username = CommonServices.getCommonData("userCode");
	$scope.selfNextModal = false;
	/*Added for CR_NP_0744*/
	$scope.regexPanNo = regexPanNoGlobal;//CR3746
	$scope.isNIAPAN = false; //CR3746
	$scope.regexAadhaarInput = /^(?!\1+$)\d{4}$/;
	$scope.regexAadhaarNumber = /^(?!\1+$)\d{12}$/;
	/*CR_NP_0880 starts */
	$scope.disablePinCode = true;
	$scope.disableCity = true;
	$scope.stateErr = false;
	/*$scope.countryErr = false;//3712*/
	$scope.pinCodeErr = false;
	$scope.cityErr = false;
	if ($rootScope.backFlag == "travellerDetails") {
		$scope.disablePinCode = false;
		// $scope.disableCity = true;
	}
	/*CR_NP_0744 and CR_NP_0880 Ends*/
	/* //CR 3712 starts ////
	$scope.isNonIndia = false;
	// $scope.policyDetailsObj.clientNationality ="";
	$scope.onNationalityChange = function(){
		$scope.policyDetailsObj.clientCountry = '';
		if($scope.policyDetailsObj.clientNationality == "NonIndian"){
			$scope.isNonIndia = true;
		}
		else{
			$scope.isNonIndia = false;
		}
	}
	//  CR_3712 ends*/
	//CR3746
    	$scope.onPANNoChange = function () {
		if($scope.policyDetailsObj.panNo != undefined){
			$scope.policyDetailsObj.panNo = $scope.policyDetailsObj.panNo.toUpperCase();
			$scope.isNIAPAN = isNIAPANNo($scope.policyDetailsObj.panNo.toUpperCase());
		}
		else
			$scope.isNIAPAN = false;
    	};
    	//CR3746

	if (spouse == true) {
		$scope.selfNextModal = true;
		$scope.slideshowModal = true;
		$scope.slideshowModal1 = true;
		$scope.slideshowModal2 = true;

		$scope.DetailsScreen = function () {
			CommonServices.setCommonData("policyHolder", $scope.policyDetailsObj.policyHolder);
			$scope.policyDetailsObj.panDisableFunc();
			CommonServices.setCommonData("nomineeNameSelf", $scope.buyNow.personalAccident.insuredDetails.nomineeName);
			CommonServices.setCommonData("relationshipSelf", $scope.buyNow.personalAccident.insuredDetails.relationshipself);
			var fullName = $scope.showSmallData.individualDetails.firstName + " " + $scope.showSmallData.individualDetails.lastName;
			CommonServices.setCommonData("Name", fullName);
			$state.go('SpouseDetails');
		};
		if (countd == 1 && counts == 1) {
			$scope.slideshowModal3 = true;
			$scope.slideshowModal4 = true;
		} else if (countd == 2 && counts == 0) {
			$scope.slideshowModal4 = true;
			$scope.SaveCalculatePremiumModal2b = true;
		} else if (counts == 2 && countd == 0) {
			$scope.slideshowModal3 = true;
		} else if (counts == 1) {
			$scope.slideshowModal3 = true;
		} else if (countd == 1) {
			$scope.slideshowModal4 = true;
			$scope.SaveCalculatePremiumModal2a = true;
		} else {
			$scope.SaveCalculatePremiumModal1 = true;
		}
	}
	else if (spouse == false) {
		$scope.selfNextModal = true;
		$scope.slideshowModal = true;
		$scope.slideshowModal1 = true;
		$scope.slideshowModal2 = false;
		if (countd == 1 && counts == 1) {
			$scope.slideshowModal3 = true;
			$scope.slideshowModal4 = true;
			$scope.SaveCalculatePremiumModal2a = true;
			$scope.DetailsScreen = function () {
				CommonServices.setCommonData("policyHolder", $scope.policyDetailsObj.policyHolder);
				$scope.policyDetailsObj.panDisableFunc();
				CommonServices.setCommonData("nomineeNameSelf", $scope.buyNow.personalAccident.insuredDetails.nomineeName);
				CommonServices.setCommonData("relationshipSelf", $scope.buyNow.personalAccident.insuredDetails.relationshipself);
				var fullName = $scope.showSmallData.individualDetails.firstName + " " + $scope.showSmallData.individualDetails.lastName;
				CommonServices.setCommonData("Name", fullName);
				$state.go('SonDetails');
			};
		}
		else if (countd == 2 && counts == 0) {
			$scope.slideshowModal4 = true;
			$scope.SaveCalculatePremiumModal2b = true;
			$scope.DetailsScreen = function () {
				CommonServices.setCommonData("policyHolder", $scope.policyDetailsObj.policyHolder);
				$scope.policyDetailsObj.panDisableFunc();
				CommonServices.setCommonData("nomineeNameSelf", $scope.buyNow.personalAccident.insuredDetails.nomineeName);
				CommonServices.setCommonData("relationshipSelf", $scope.buyNow.personalAccident.insuredDetails.relationshipself);
				var fullName = $scope.showSmallData.individualDetails.firstName + " " + $scope.showSmallData.individualDetails.lastName;
				CommonServices.setCommonData("Name", fullName);
				$state.go('DaughterDetails');
			};
		} else if (countd == 0 && counts == 2) {
			$scope.slideshowModal3 = true;
			$scope.DetailsScreen = function () {
				CommonServices.setCommonData("policyHolder", $scope.policyDetailsObj.policyHolder);
				$scope.policyDetailsObj.panDisableFunc();
				CommonServices.setCommonData("nomineeNameSelf", $scope.buyNow.personalAccident.insuredDetails.nomineeName);
				CommonServices.setCommonData("relationshipSelf", $scope.buyNow.personalAccident.insuredDetails.relationshipself);
				var fullName = $scope.showSmallData.individualDetails.firstName + " " + $scope.showSmallData.individualDetails.lastName;
				CommonServices.setCommonData("Name", fullName);
				$state.go('SonDetails');
			};
		} else if (counts == 1) {
			$scope.slideshowModal3 = true;
			$scope.DetailsScreen = function () {
				CommonServices.setCommonData("policyHolder", $scope.policyDetailsObj.policyHolder);
				$scope.policyDetailsObj.panDisableFunc();
				CommonServices.setCommonData("nomineeNameSelf", $scope.buyNow.personalAccident.insuredDetails.nomineeName);
				CommonServices.setCommonData("relationshipSelf", $scope.buyNow.personalAccident.insuredDetails.relationshipself);
				var fullName = $scope.showSmallData.individualDetails.firstName + " " + $scope.showSmallData.individualDetails.lastName;
				CommonServices.setCommonData("Name", fullName);
				$state.go('SonDetails');
			};
		} else if (countd == 1) {
			$scope.slideshowModal4 = true;
			$scope.SaveCalculatePremiumModal2a = true;
			$scope.DetailsScreen = function () {
				CommonServices.setCommonData("policyHolder", $scope.policyDetailsObj.policyHolder);
				$scope.policyDetailsObj.panDisableFunc();
				CommonServices.setCommonData("nomineeNameSelf", $scope.buyNow.personalAccident.insuredDetails.nomineeName);
				CommonServices.setCommonData("relationshipSelf", $scope.buyNow.personalAccident.insuredDetails.relationshipself);
				var fullName = $scope.showSmallData.individualDetails.firstName + " " + $scope.showSmallData.individualDetails.lastName;
				CommonServices.setCommonData("Name", fullName);
				$state.go('DaughterDetails');
			};
		}
		else {
			$scope.slideshowModal = false;
			$scope.SaveCalculatePremiumModal = true;
			$scope.selfNextModal = false;

		}

	}


	//pinCode
	$scope.selectPinCode = function (pincode) {
		$scope.buyNow.personalAccident.insuredDetails.pincode = pincode;
		$scope.pinCodeDataModal = false;
	}
	$scope.checkExistingCustomer = function () {
		$scope.pinCodeDataModal = false;
	}
	//save and calculate function
	var username = CommonServices.getCommonData("userCode");



	$scope.calculatePremium = function () {
		CommonServices.setCommonData("policyHolder", $scope.policyDetailsObj.policyHolder);
		$scope.policyDetailsObj.panDisableFunc();
		if ($scope.buyNow.personalAccident.insuredDetails.firstName !== undefined && $scope.buyNow.personalAccident.insuredDetails.firstName !== "") {
			$scope.buyNow.personalAccident.insuredDetails.firstName = $scope.buyNow.personalAccident.insuredDetails.firstName;
		}
		else {
			$scope.buyNow.personalAccident.insuredDetails.firstName = "";
		}
		if ($scope.buyNow.personalAccident.insuredDetails.lastName !== undefined && $scope.buyNow.personalAccident.insuredDetails.lastName !== "") {
			$scope.buyNow.personalAccident.insuredDetails.lastName = $scope.buyNow.personalAccident.insuredDetails.lastName;
		}
		else {
			$scope.buyNow.personalAccident.insuredDetails.lastName = "";
		}
		var fullName = $scope.showSmallData.individualDetails.firstName + " " + $scope.showSmallData.individualDetails.lastName;
		CommonServices.setCommonData("Name", fullName);
		CommonServices.setCommonData("nomineeNameSelf", $scope.buyNow.personalAccident.insuredDetails.nomineeName);
		CommonServices.setCommonData("relationshipSelf", $scope.buyNow.personalAccident.insuredDetails.relationshipself);
		var selfSaveQuoteInput = {

			"userProfile": {
				"userId": username.toUpperCase(),
				"loggedInRole": "SUPERUSER"
			},
			"quote": {
				"isAddOnPA": "N",
				"quoteNumber": quoteNo,
				"policyHolderCode": $scope.showSmallData.partyCode,
				"partyDetailsList": [],
				"productCode": "PU",
				"product": "PU",
				"policyHolderName": fullName.toUpperCase().trim(),
				"policyStartDate": todaysDate,
				"policyExpiryDate": futureDateCal,
				"term": 1,
				"termUnit": "G",
				"eventDate": todaysDate,
				"coverage": str,
				"numChildrenToCover": "0",
				"risks": [{
					"coverages": [{
						"coverDetails": {
							"medicalCoverReq": medicalcheck
						}
					}],
					"riskDetails": {
						"sumInsuredForTableA": 0,
						"sumInsuredForTableB": "500000",
						"sumInsuredForTableC": "500000",
						"sumInsuredForTableD": 0,
						"relationWithNominee": $scope.buyNow.personalAccident.insuredDetails.relationshipself,
						"nomineeName": $scope.buyNow.personalAccident.insuredDetails.nomineeName,
						"monthlyIncome": "",
						"dateOfBirth": $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthself,
						"relationWithPolicyHolder": "SELF",
						"nameOfInsuredPerson": fullName.toUpperCase().trim(),
						"occupation": $scope.buyNow.personalAccident.premiumCalculator.occupationself
					}
				}]
			}
		}
		var saveQuoteResponse = RestServices.postService(RestServices.urlPathsNewPortal.saveQuote, selfSaveQuoteInput);

		saveQuoteResponse.then(

			function (response) { // success 

				CommonServices.showLoading(false);
				if (response.data.errorCode === 959) {
					CommonServices.showAlert(response.data.errorMessage);
				}
				else if (response.data.errorMessage !== undefined && response.data.errorMessage !== "") {
					CommonServices.showAlert(response.data.errorMessage);
				}
				else {
					if (response.data.userProfile.footer.errorCode === "1") {
						$scope.buyNow.personalAccident.saveQuoteRes = response.data.quote.premiumDetails;
						quoteNoSelf = response.data.quote.quoteNumber;
						netPremiumSelf = response.data.quote.premiumDetails.netPremium;
						serviceTaxSelf = response.data.quote.premiumDetails.serviceTax;
						totalPremiumSelf = response.data.quote.premiumDetails.totalPremium;
						CommonServices.setCommonData("CollectionPaymentDetails", response.data.quote);
						$rootScope.PAView = true;
						$state.go('PaymentDetails');
					}

					else
						CommonServices.showAlert("Presently our services are not available. Please try after some time");
				}

			},
			function (error) {    // failure 
				CommonServices.showLoading(false);
				RestServices.handleWebServiceError(error);
			});
	};

	$scope.back = function () {
		$state.go('premiumResult');
	};

	$scope.calIconClick = function (event) {
		angular.element("#" + event.currentTarget.children[0].id).focus();
	};
	$scope.onlyalph = /^[a-zA-Z. ']*$/;

	var mydateSt = CommonServices.getCommonData("serverDate");

	var mynewdateFrm = new Date(mydateSt);

	var dd = mynewdateFrm.getDate();
	var mm = mynewdateFrm.getMonth() + 1;
	var yyyy = mynewdateFrm.getFullYear();

	//var enableCalendarfrom = getFormattedDate(mynewdateFrom);
	//past 69 years
	var enableRegCalendarfrom = new Date(new Date().setFullYear(mynewdateFrm.getFullYear() - 70));
	enableRegCalendarfrom = getFormattedDate(enableRegCalendarfrom);

	var mydateStr = CommonServices.getCommonData("serverDate");

	var mynewdateFrom = new Date(mydateStr);

	var dd = mynewdateFrom.getDate();
	var mm = mynewdateFrom.getMonth() + 1;
	var yyyy = mynewdateFrom.getFullYear();

	if (dd < 10) {
		dd = "0" + dd;
	}

	if (mm < 10) {
		mm = "0" + mm;
	}
	todaysDate = dd + "/" + mm + "/" + yyyy;//policy start date
	var systemDate = mm + "/" + dd + "/" + yyyy;// mm/dd/yyyy

	//past 18 years
	var enableRegValCalendarTo = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 18));
	enableRegValCalendarTo = getFormattedDate(enableRegValCalendarTo);

	$('#birthdate').loadCalendar({
		'enableDateRange': true,
		'enableCalendarFrom': enableRegCalendarfrom,
		'enableCalendarTo': systemDate
	});

	/*Added by 851587 for CR_NP_0744*/
	var configurationData = CommonServices.getCommonData("ConfigurationData");
	if (configurationData != undefined && configurationData != '') {
		if (configurationData[0].value == "Y") {
			$scope.isPanNumberMandatory = true;
		} else {
			$scope.isPanNumberMandatory = false;
		}
		/*Below block Commented by 851587 for CR_NP_0744E */
		//  if(configurationData[1].value == "Y"){
		// 	 $scope.isAadhaarNumberMandatory = true;
		//  }else{
		// 	  $scope.isAadhaarNumberMandatory = false;
		//  }
		/*CR_NP_0744E ends*/
	}
	/*CR_NP_0744 Changes ends*/

	/**Added by 851587 for CR_NP_0744, below block commented for CR_NP_0744E**/
	// $(".aadhaarInput").keyup(function () {
	// 	if (this.value.length == 4) {
	// 		$(this).next('.aadhaarInput').focus();
	// 	}
	// 	if (this.value.length < 1) {
	// 	  $(this).prev('.aadhaarInput').focus();
	// 	}
	// });

	// $scope.aadhaarNoField = function(){
	// 	if(($scope.policyDetailsObj.aadhaarNumber1 != undefined && $scope.policyDetailsObj.aadhaarNumber1 !='')||($scope.policyDetailsObj.aadhaarNumber2 != undefined && $scope.policyDetailsObj.aadhaarNumber2 !='')||($scope.policyDetailsObj.aadhaarNumber3 != undefined && $scope.policyDetailsObj.aadhaarNumber3 !='')){
	// 		$scope.aadharFieldIsRequired = true;
	// 		if(($scope.policyDetailsObj.aadhaarNumber1 != undefined && $scope.policyDetailsObj.aadhaarNumber1 !='') && ($scope.policyDetailsObj.aadhaarNumber2 != undefined && $scope.policyDetailsObj.aadhaarNumber2 !='') && ($scope.policyDetailsObj.aadhaarNumber3 != undefined && $scope.policyDetailsObj.aadhaarNumber3 !='')){
	// 			$scope.aadharFieldIsRequired = false;
	// 		}
	// 	}else{
	// 		$scope.aadharFieldIsRequired = false;
	// 	}
	// };
	/**CR_NP_0744 and CR_NP_0744E Changes End**/


	$scope.getPolicyDetails = function (partycode) {
		/* CR_NP_594A starts*/
		$rootScope.dateOfBirthEmpty = false;
		/* CR_NP_594A ends*/
		var PolicyHolderData =
			{
				"userProfile": {
					"userId": username.toUpperCase(),
					"loggedInRole": "SUPERUSER"
				},
				"partyDetails": {
					"partyCode": partycode
				}
			};
		var PolicyHolderDataResponse = RestServices.postService(RestServices.urlPathsNewPortal.getPolicyHolderDetail, PolicyHolderData);

		PolicyHolderDataResponse.then(
			function (response) {	// success 
				CommonServices.showLoading(false);
				/* 3712 Starts ///
				//Dummy Data added to response
				response.data.partyDetails.individualDetails.clientNationality = "NonIndian";
				response.data.partyDetails.individualDetails.clientCountry = "Ghana";
				// 3712 Ends */
				$scope.showSmallData = { "partyCode": partycode, "individualDetails": response.data.partyDetails.individualDetails };
				//added today
				var partyHoldersDetails = { "savedPartyDetails": { "partyDetails": response.data.partyDetails } };
				angular.extend($rootScope.insuredData, partyHoldersDetails);
				/*Added by 851587 for CR_NP_0744*/
				if ($scope.policyDetailsObj.policyHolder === "existingPolicyHolder") {
					//To set the initial value of PAN and Aadhaar Numbers
					if (CommonServices.initialPartyCode != $scope.showSmallData.partyCode) { //If party code is changed
						CommonServices.initialPanNumberIsEmpty = false;
						/*Below line commented for CR_NP_0744E */
						//   CommonServices.initialAadhaarNoIsEmpty = false;
					}
					CommonServices.initialPartyCode = $scope.showSmallData.partyCode;
					//For PAN Number
					if (response.data.partyDetails.individualDetails.panNumber != undefined && response.data.partyDetails.individualDetails.panNumber != "" && $scope.regexPanNo.test(response.data.partyDetails.individualDetails.panNumber)) {
						$scope.policyDetailsObj.panNoInputDisable = true;
						if (CommonServices.initialPanNumberIsEmpty == true) {
							$scope.policyDetailsObj.panNoInputDisable = false;
						}
					} else {
						$scope.policyDetailsObj.panNoInputDisable = false;
						CommonServices.initialPanNumberIsEmpty = true;
					}
					//For Aadhaar Number, below block commented for CR_NP_0744E
					//   if(response.data.partyDetails.individualDetails.aadhaarNo != undefined && response.data.partyDetails.individualDetails.aadhaarNo != "" && $scope.regexAadhaarNumber.test(response.data.partyDetails.individualDetails.aadhaarNo)){
					// 		$scope.policyDetailsObj.aadhaarInputDisable = true;
					// 		if(CommonServices.initialAadhaarNoIsEmpty == true){
					// 			$scope.policyDetailsObj.aadhaarInputDisable = false;
					// 		}
					// 	}else{
					// 		$scope.policyDetailsObj.aadhaarInputDisable = false;
					// 		CommonServices.initialAadhaarNoIsEmpty = true;
					// 	}
				} else {
					$scope.policyDetailsObj.panNoInputDisable = false;
					//   $scope.policyDetailsObj.aadhaarInputDisable = false;
				}
				/*CR_NP_0744 and CR_NP_0744E ends*/

				/* CR_NP_594A starts*/
				if (response.data.partyDetails.individualDetails.dateOfBirth === undefined) {
					$rootScope.dateOfBirthEmpty = true;
				}
				/* CR_NP_594A ends*/
				showData = $scope.showSmallData.partyCode;
				CommonServices.setCommonData("partyHoldersCode", $scope.showSmallData.partyCode);
				$scope.buyNow.personalAccident.individualDetails = $scope.showSmallData;
				$scope.policyDetailsObj.showSmallTbl = true;//to display created data
				$scope.policyDetailsObj.newcustomerFlag = false;//to hide existing page
				$scope.partyCode = partyCode;
				$scope.detailNoModal = true;
				$scope.policyDataModal = false;
				//if response has sate and City	
				if ($scope.buyNow.personalAccident.individualDetails.individualDetails.hasOwnProperty('state')) {
					getStateName();
				}

			},
			function (error) {    // failure 
				CommonServices.showLoading(false);
				RestServices.handleWebServiceError(error);
			});

	}
	// getStateList service call
	function getStateName() {
		var stateListInput = {
			state: "",
			city: ""
		};
		var PolicyHolderDataResponse = RestServices.postService(RestServices.urlPathsNewPortal.getStateList, stateListInput);
		PolicyHolderDataResponse.then(
			function (response) {	// success 
				CommonServices.showLoading(false);
				if (response.data.hasOwnProperty('states')) {
					for (i = 0; i < response.data.states.length; i++) {
						if ($scope.buyNow.personalAccident.individualDetails.individualDetails.state === response.data.states[i].stateCode) {
							$scope.buyNow.personalAccident.individualDetails.individualDetails.stateName = response.data.states[i].state;
							getCityName();
						}
					}
				}

			},
			function (error) {    // failure 
				CommonServices.showLoading(false);
				RestServices.handleWebServiceError(error);
			});
	};



	function getCityName() {

		var cityListInput = {
			state: $scope.buyNow.personalAccident.individualDetails.individualDetails.stateName,
			city: ""
		};
		var PolicyHolderDataResponse = RestServices.postService(RestServices.urlPathsNewPortal.getCitiesList, cityListInput);
		PolicyHolderDataResponse.then(
			function (response) {	// success 
				CommonServices.showLoading(false);
				if (response.data.hasOwnProperty('cities')) {
					for (i = 0; i < response.data.cities.length; i++) {
						if ($scope.buyNow.personalAccident.individualDetails.individualDetails.city === response.data.cities[i].cityCode) {
							$scope.buyNow.personalAccident.individualDetails.individualDetails.cityName = response.data.cities[i].city;
						}
					}
				}

			},
			function (error) {    // failure 
				CommonServices.showLoading(false);
				RestServices.handleWebServiceError(error);
			});

	};

	var partyCode;
	var firstName, lastName, dateOfBirth, mobileNo, gender, buildingNoStreet, pinCode, emailId, eInsuranceAccountNo, panNumber, title;
	var gender = jQuery('#gender').is(':checked') ? 'F' : 'M';
	$scope.create = function () {
		/*Added by 851587 for CR_NP_0744 */
		if ($scope.policyDetailsObj.aadhaarNumber1 != undefined && $scope.policyDetailsObj.aadhaarNumber1 != '' && $scope.policyDetailsObj.aadhaarNumber2 != undefined && $scope.policyDetailsObj.aadhaarNumber2 != '' && $scope.policyDetailsObj.aadhaarNumber3 != undefined && $scope.policyDetailsObj.aadhaarNumber3 != '') {
			$scope.policyDetailsObj.aadhaarNumber = $scope.policyDetailsObj.aadhaarNumber1 + $scope.policyDetailsObj.aadhaarNumber2 + $scope.policyDetailsObj.aadhaarNumber3;
		} else {
			$scope.policyDetailsObj.aadhaarNumber = "";
		}

		var customerData = {      //create
			"userProfile": {
				"userId": username.toUpperCase(),
				"loggedInRole": "SUPERUSER"
			},
			"partyDetails": {
				"individualDetails": {
					"firstName": $scope.buyNow.personalAccident.insuredDetails.fName.toUpperCase(),
					"middleName": $scope.buyNow.personalAccident.insuredDetails.mName !== undefined ? $scope.buyNow.personalAccident.insuredDetails.mName.toUpperCase() : "",
					"lastName": $scope.buyNow.personalAccident.insuredDetails.lName.toUpperCase(),
					"gender": $scope.buyNow.personalAccident.insuredDetails.gender.toUpperCase(),
					"dateOfBirth": $scope.buyNow.personalAccident.insuredDetails.dateOfBirth.toUpperCase(),
					/*
					"clientNationality": $scope.buyNow.personalAccident.insuredDetails.clientNationality,//3712
					"clientCountryObj": $scope.buyNow.personalAccident.insuredDetails.clientCountry,//3712
					"clientCountry": $scope.buyNow.personalAccident.insuredDetails.clientCountry.stateCode,//3712
					*/
					"buildingNoStreet": $scope.buyNow.personalAccident.insuredDetails.buildNo.toUpperCase(),
					"gstRegIdType": $scope.policyDetailsObj.gstRegID !== undefined ? $scope.policyDetailsObj.gstRegID.toUpperCase() : "",
					"gstin": $scope.policyDetailsObj.gstINModel !== undefined ? $scope.policyDetailsObj.gstINModel.toUpperCase() : "",
					"cityObj": $scope.policyDetailsObj.countryCity,
					"stateObj": $scope.policyDetailsObj.contState,
					"state": $scope.policyDetailsObj.contState.stateCode.toUpperCase(),
					"uin": $scope.policyDetailsObj.uinModel !== undefined ? $scope.policyDetailsObj.uinModel.toUpperCase() : "",
					"city": $scope.policyDetailsObj.countryCity.cityCode.toUpperCase(),
					"pinCode": $scope.policyDetailsObj.placeOfLoss.toUpperCase(), //CR_NP_0880
					"mobileNo": $scope.buyNow.personalAccident.insuredDetails.mobileNo.toUpperCase(),
					"emailId": $scope.buyNow.personalAccident.insuredDetails.mailId,
					"panNumber": $scope.policyDetailsObj.panNo !== undefined ? $scope.policyDetailsObj.panNo.toUpperCase() : "",
					"aadhaarNo": $scope.policyDetailsObj.aadhaarNumber,
					"eInsuranceAccountNo": $scope.buyNow.personalAccident.insuredDetails.eAsuuranceAccountNo !== undefined ? $scope.buyNow.personalAccident.insuredDetails.eAsuuranceAccountNo.toUpperCase() : ""
				},
				partyType: "I"
			}
		};

		var customerDataResponse = RestServices.postService(RestServices.urlPathsNewPortal.createPolicyHolderTW, customerData);

		customerDataResponse.then(
			function (response) {	// success 
				CommonServices.showLoading(false);
				if (response.data.errorCode === 959) {
					CommonServices.showAlert(response.data.errorMessage);
				} else if (response.data.errorMessage !== undefined && response.data.errorMessage !== "") {
					CommonServices.showAlert(response.data.errorMessage);
				} else {
					partyCode = response.data.partyDetails.partyCode;
					$scope.getPolicyDetails(partyCode);
				}
			},
			function (error) {    // failure 
				CommonServices.showLoading(false);
				RestServices.handleWebServiceError(error);
			});

	};
	$scope.additionalDetails = function (data) {
		$scope.policyDetailsObj.newcustomerFlag = true;
		$scope.policyDetailsObj.fieldDisable = true;
		$scope.policyDetailsObj.showSmallTbl = false;
		$scope.policyDetailsObj.existingCustomerBtn = false;
		$scope.policyDetailsObj.setValue(data);
	};

	$scope.closeadditionalDetails = function () {
		/*Added by 851587 for CR_NP_0744, aadhaar commented for CR_NP_0744E*/
		CommonServices.panNoInputDisable = false;
		// CommonServices.aadhaarInputDisable = false;
		/*CR_NP_0744 and CR_NP_0744E ends*/
		$scope.detailNoModal = false;
		$scope.redirectInsuredDetails = false;
		$scope.policyDetailsObj.showSmallTbl = false;
		$scope.policyDetailsObj.existingCustomerFlag = true;
		$scope.policyDetailsObj.policyHolder = "existingPolicyHolder";

		$scope.buyNow.personalAccident.insuredDetails.fName = "";
		$scope.buyNow.personalAccident.insuredDetails.lName = "";
		$scope.buyNow.personalAccident.insuredDetails.mName = "";
		$scope.buyNow.personalAccident.insuredDetailsdateOfBirth = "";
		/*
		$scope.buyNow.personalAccident.clientNationality = "";//3712
		$scope.buyNow.personalAccident.clientCountryObj = "";//3712
		$scope.buyNow.personalAccident.clientCountry = "";//3712
		*/
		$scope.buyNow.personalAccident.insuredDetails.mobileNo = "";
		$scope.buyNow.personalAccident.insuredDetails.gender = "";
		$scope.buyNow.personalAccident.insuredDetails.buildNo = "";
		$scope.buyNow.personalAccident.insuredDetails.pincode = "";
		$scope.buyNow.personalAccident.insuredDetails.mailId = "";
		$scope.buyNow.personalAccident.insuredDetails.eAsuuranceAccountNo = "";
		$scope.policyDetailsObj.panNo = "";
		$scope.buyNow.personalAccident.insuredDetails.title = "";
		$scope.buyNow.personalAccident.insuredDetails.policyCode = "";
		$scope.buyNow.personalAccident.insuredDetails.mobNo = "";
		$scope.buyNow.personalAccident.insuredDetails.emailId = "";
		/*Added by 851587 for CR_NP_0744*/
		this.aadhaarNumber1 = "";
		this.aadhaarNumber2 = "";
		this.aadhaarNumber3 = "";
		/*CR_NP_0744 ends*/
		$scope.buyNow.personalAccident.insuredDetails.lastName = "";

		$scope.buyNow.personalAccident.insuredDetailspolicyCode = "";
		$scope.buyNow.personalAccident.insuredDetails.firstName = "";
		$scope.buyNow.personalAccident.insuredDetails.lastName = "";
		$scope.buyNow.personalAccident.insuredDetails.mobNo = "";
		$scope.buyNow.personalAccident.insuredDetails.emailId = "";
	};

	//search function
	$scope.search = function () {
		if ($scope.buyNow.personalAccident.insuredDetails.firstName == undefined && $scope.buyNow.personalAccident.insuredDetails.lastName == undefined && $scope.buyNow.personalAccident.insuredDetails.emailId == undefined && $scope.buyNow.personalAccident.insuredDetails.mobNo == undefined && $scope.buyNow.personalAccident.insuredDetails.policyCode == undefined) {
			CommonServices.showAlert("Enter atleast 1 input parameter to proceed with the Policy Holder search.");
		}
		else {
			$scope.Code;
			//storing value in field
			if ($scope.buyNow.personalAccident.insuredDetails.policyCode == undefined) {
				$scope.Code = "";
			}
			else {
				$scope.Code = $scope.buyNow.personalAccident.insuredDetails.policyCode;
			}
			var searchData = {
				"userProfile": {
					"userId": username.toUpperCase(),
					"loggedInRole": "SUPERUSER"
				},
				"partyDetails": {
					"individualDetails": {
						"firstName": $scope.buyNow.personalAccident.insuredDetails.firstName !== undefined ? $scope.buyNow.personalAccident.insuredDetails.firstName.toUpperCase() : "",
						"lastName": $scope.buyNow.personalAccident.insuredDetails.lastName !== undefined ? $scope.buyNow.personalAccident.insuredDetails.lastName.toUpperCase() : "",
						"emailId": $scope.buyNow.personalAccident.insuredDetails.emailId,
						"mobileNo": $scope.buyNow.personalAccident.insuredDetails.mobNo !== undefined ? $scope.buyNow.personalAccident.insuredDetails.mobNo.toUpperCase() : ""
					},
					"organizationDetails": {},
					"partyCode": $scope.Code,
					"productCode": "PU",
					"partyType": "I"

				},
				"productCode": "PU"

			};
			var SearchDataResponse = RestServices.postService(RestServices.urlPathsNewPortal.searchPolicyHolderDetails, searchData);
			//web service call for PremiumData searchPolicyHolderDetails
			SearchDataResponse.then(
				function (response) {	// success 
					CommonServices.showLoading(false);
					var polDataArray = [];
					$scope.polDataArray = polDataArray;
					if (response.data.hasOwnProperty('footer')) {
						$scope.policyDetailsObj.showSearchResTbl = true;
						$scope.polNoData = true;
					} else {
						$scope.policyDetailsObj.showSearchResTbl = true;

						for (var i = 0; i < response.data.partyDetailsList.length; i++) {
							var num = i;
							num++;
							var lastName = response.data.partyDetailsList[i].individualDetails.lastName;
							var mobNo = response.data.partyDetailsList[i].individualDetails.mobileNo;
							var emailId = response.data.partyDetailsList[i].individualDetails.emailId;
							code = response.data.partyDetailsList[i].partyCode;
							var firstName = response.data.partyDetailsList[i].individualDetails.firstName;
							var policyResponseData = {
								"SrNo": num,
								"PolicyHolderCode": code,
								"FirstName": firstName,
								"LastName": lastName,
								"EmailID": emailId,
								"MobileNo": mobNo
							};
							polDataArray.push(policyResponseData);
						}
						$scope.polNoData = false;
						$scope.policyDataModal = true;
						$scope.SelectPolicyId = function (items) {
							$scope.policyDetailsObj.showSearchResTbl = true;
							$scope.policyDetailsObj.showSmallTblFunc();
							$scope.getPolicyDetails(items.PolicyHolderCode);
						};
					}


				},
				function (error) {    // failure 
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
				});
		}//added
	};

	$scope.DaughterDetails = function () {
		$state.go('DaughterDetails');
	};
	$scope.SpouseDetails = function () {
		$state.go('SpouseDetails');
	};
	$scope.SonDetails = function () {

		$state.go('SonDetails');
	};

	$scope.RelationshipWithNominee = CommonServices.getCommonData("RELATIONSHIP_WITH_NOMINEE");
	$scope.redirectInsuredDetails = CommonServices.getCommonData("redirectInsuredDetails");
	$scope.existingCustomer = CommonServices.getCommonData("existingCustomer");
	$scope.checkIfTrue = function () {    //to hide detail box
		if ($scope.redirectInsuredDetails == true) {
			$scope.detailNoModal = false;
			$scope.redirectInsuredDetails = false;
		}
	}

	var policyHolderDetailsRes = CommonServices.getCommonData("storeDetails");
	$scope.nomineeName = CommonServices.getCommonData("nomineeNameself");
	$scope.relationshipself = CommonServices.getCommonData("relationshipself");
	if ($scope.redirectInsuredDetails == true) {
		$scope.firstName = policyHolderDetailsRes.firstName;
		$scope.lastName = policyHolderDetailsRes.lastName;
		$scope.emailId = policyHolderDetailsRes.emailId;
		$scope.dateOfBirth = policyHolderDetailsRes.dateOfBirth;
		$scope.mobileNo = policyHolderDetailsRes.mobileNo;
		$scope.gender = policyHolderDetailsRes.gender;
		$scope.buildingNoStreet = policyHolderDetailsRes.buildingNoStreet;
		$scope.pinCode = policyHolderDetailsRes.pinCode;
		$scope.eInsuranceAccountNo = policyHolderDetailsRes.eInsuranceAccountNo;
		$scope.panNumber = policyHolderDetailsRes.panNumber;
		$scope.title = policyHolderDetailsRes.title;
		$scope.partyCode = CommonServices.getCommonData("partycode");
	}


	//GST Code Start Here
	$scope.policyDetailsObj = {
		newcustomerFlag: true,
		existingCustomerFlag: false,
		showSearchResTbl: false,
		policyHolder: "newPolicyHolder",
		existingCustomerBtn: true,
		selectState: false,
		selectCity: false,
		fieldDisable: false,
		showSmallTbl: false,
		gstRegTypeVal: [{
			id: "NCC",
			name: "Normal,Composite,Casual"
		}, {
			id: "NRI",
			name: "NRI"
		}, {
			id: "UNB",
			name: "UN Bodies/Embassy"
		}],
		/*CR_NP_0880 starts */
		// pincodeCheck: function(obj){// Onchange of pincode input field
		// 	$scope.InsuredDetails.$invalid = true;
		// 	$scope.InsuredDetails.placeOfLoss.$invalid = true;
		// 	if(obj.length === 1){
		// 	    if($scope.searchPincode === "" || $scope.searchPincode === undefined){
		//             $scope.searchPincode= {"state":this.contState.state.toUpperCase(),"city":this.countryCity.city.toUpperCase(),"zipCode":obj};
		//             return this.pinCodeServiceCall();
		//         }
		// 	}
		// 	else{
		// 		this.pinCodeErr= true;
		// 		return  ($filter('filter')($scope.pinCodesList, {zipCode: obj}));
		// 	}

		// },
		/*CR_NP_0880 Ends */
		gstIDInputChangeFunc: function () { // Onchange of GSTIN input field
			if (this.gstRegID !== undefined && this.gstRegID !== "") {
				var reg = "";

				if (this.gstINModel != undefined && this.gstINModel === 15) {
					$scope.InsuredDetails.gstIN.$invalid = false;
					$scope.InsuredDetails.$invalid = false;
				}
				else {
					$scope.InsuredDetails.gstIN.$invalid = true;
					$scope.InsuredDetails.$invalid = true;
				}

				if (this.gstRegID === "NCC") {
					reg = regexGSTidGlobal;

					//UC for CR 3749
					// if(CommonServices.gstIdStateCode[this.gstINModel.slice(0,2)] != undefined){
					// 	if($scope.policyDetailsObj.contState.state == CommonServices.gstIdStateCode[this.gstINModel.slice(0,2)]){
					// 		$scope.InsuredDetails.gstIN.$setValidity("gstStateCode", true);
					// 		console.log("state code valid");
					// 	}
					// 	else{
					// 	$scope.InsuredDetails.gstIN.$setValidity("gstStateCode", false);
					// 	$scope.gstErrorMsg = "Please enter valid GSTIN. State code of GSTIN and the state mentioned in address should match.";	
					// 	}
					// }
					// else{
					// $scope.InsuredDetails.gstIN.$setValidity("gstStateCode", false);
					// $scope.gstErrorMsg = "Please enter GSTIN with a valid state code";
					// }
				}
				if (this.gstRegID === "NRI") {
					reg = /^[0-9]{12}[N]{1}[0-9A-Z]{1}[T]{1}$/;
				}
				if (this.gstRegID === "UNB") {
					reg = /^[0-9]{12}[U]{1}[0-9A-Z]{1}[N]{1}$/;
				}

				if (this.gstINModel !== "" || this.gstINModel !== undefined) {

					if (reg === "")
						valid = true;
					else
						valid = reg.test(this.gstINModel.toUpperCase());
				}


				if (this.gstRegID !== undefined && this.gstRegID !== "") {
					$scope.InsuredDetails.$invalid = false;
				}
				else {
					$scope.InsuredDetails.$invalid = true;
				}


				if (valid) {
					$scope.InsuredDetails.gstIN.$setValidity("gstinPattern", true);
					$scope.InsuredDetails.gstIN.$invalid = false;
					$scope.InsuredDetails.$invalid = false;
					$scope.InsuredDetails.gstIN.$setValidity("gstIN", true);
				} else {
					$scope.InsuredDetails.gstIN.$setValidity("gstinPattern", false);
					$scope.InsuredDetails.gstIN.$invalid = true;
					$scope.InsuredDetails.$invalid = true;
					$scope.InsuredDetails.gstIN.$setValidity("gstIN", false);
				}


				// ADDED BY HIMANSHU FOR CR_875
				if (this.gstRegID != undefined && this.gstRegID != '') {
					if (this.gstINModel != undefined) {
						this.gstINModel = this.gstINModel.toUpperCase();
						if (this.gstINModel.includes("AAACN4165C")) {
							$scope.InsuredDetails.gstIN.$setValidity("validateNIAPAN", false);
							$scope.InsuredDetails.$invalid = true;
						} else {
							$scope.InsuredDetails.gstIN.$setValidity("validateNIAPAN", true);
							$scope.InsuredDetails.$invalid = false;

						}
					}
				}

			}
		},
		uinInputChangeFunc: function () { // Onchange of UIN input field
			if (this.uinModel.length === 15) {
				$scope.InsuredDetails.UIN.$invalid = false;
			}
			else {
				$scope.InsuredDetails.UIN.$invalid = true;
			}
		},
		stateServiceCall: function () {// this function is service call for getting state 
			this.stateResponse = RestServices.postService(RestServices.urlPathsNewPortal.getStateList, $scope.stateData);
			return this.stateResponse.then(
				function (response) { // success 

					CommonServices.showLoading(false);
					if (response.data.states !== undefined && response.data.states !== "") {
						/*CR_NP_0880 starts */
						if ($scope.partyCode !== "" && $scope.partyCode !== undefined) {// if the cutomer is existing customer
							response.data.states.filter(function (b) {//this filter will compare the responseState with the response data
								if ($scope.responseState !== "" && $scope.responseState !== undefined && b.stateCode === $scope.responseState) {
									$scope.policyDetailsObj.contState = b;
									$rootScope.policyHolderStateIs = b;
									$scope.responseState = "";

									$scope.searchPincode = { "state": $scope.policyDetailsObj.contState.state, "zipCode": "" };
									$scope.policyDetailsObj.pinCodeServiceCall();

									// $rootScope.invalidSPCErr = false;
								} else {
									// $rootScope.invalidSPCErr = true;
								}
							});
							$scope.stateList = response.data.states;
						}
						else {// if the cutomer is new customer
							$scope.stateData = "";
							$scope.stateList = response.data.states;
						}
						return $scope.stateList;
					} else {
						if (response.data.errorMessage !== undefined && response.data.errorMessage !== "")
							CommonServices.showAlert(response.data.errorMessage);
						else
							// CommonServices.showAlert("Presently our services are not available. Please try after some time");
							CommonServices.showAlert("Error Occured. Please try again later");
					}
				},
				function (error) { // failure
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
				});
			/* CR_NP_0880 ends*/
		},
		 /*///// 3712 Starts /////////
		  countryServiceCall: function(data) {
			var getStateListInput = {
				"state": data.toUpperCase()
			};
			var getStateListResponse = RestServices.postService(RestServices.urlPathsNewPortal.getStateList, getStateListInput);
			return getStateListResponse.then(function (response) { // success
				CommonServices.showLoading(false);
				$scope.countryErr = true;
				if (response.data.hasOwnProperty('states')) {
					return $scope.stateList = response.data.states;
				} else {
					$scope.stateList = "";
					$scope.result = "No search results found";
					if (data == null) {
						$scope.countryErr = false;
					} else {
						$scope.countryErr = true;
					}
					return $scope.stateList;
				}
	
			}, function (error) {
				CommonServices.showLoading(false);
				RestServices.handleWebServiceError(error);
			});
		},
		////////3712 Ends /////////*/
		pinCodeServiceCall: function () { // this function is service call for getting pincodes
			this.getZipcodeDetailResponse = RestServices.postService(RestServices.urlPathsNewPortal.getZipCodesbyState, $scope.searchPincode);
			return this.getZipcodeDetailResponse.then(
				function (response) { // success 
					/* CR_NP_0880 Starts*/
					CommonServices.showLoading(false);
					if (response.data.pincodes !== undefined && response.data.pincodes !== "") {
						if ($scope.partyCode !== "" && $scope.partyCode !== undefined) { // if the cutomer is existing customer

							response.data.pincodes.filter(function (b) {//this filter will compare the responsepinCode with the response data
								if ($scope.responsepinCode !== "" && $scope.responsepinCode !== undefined && b === $scope.responsepinCode) {
									$scope.policyDetailsObj.placeOfLoss = b;
									$scope.responsepinCode = "";
									$scope.cityData = { "state": ($scope.policyDetailsObj.contState.state === undefined) ? $scope.policyDetailsObj.contState : $scope.policyDetailsObj.contState.state, "zipCode": $scope.policyDetailsObj.placeOfLoss, "city": "" };
									$scope.policyDetailsObj.cityServiceCall();

									// $rootScope.invalidSPCErr = false;
									$scope.disablePinCode = true;
								} else {
									// $rootScope.invalidSPCErr = true;
									$scope.disablePinCode = false;
								}
							});
							// $scope.searchPincode="";
							$scope.pinCodesList = response.data.pincodes;
							$scope.pinCodeResponseArray = response.data.pincodes;

							var pincodeMatchList = [];
							for (var i = 0; i < $scope.pinCodesList.length; i++) {
								if ($scope.pinCodesList[i].match($scope.searchPincode.zipCode)) {
									pincodeMatchList.push($scope.pinCodesList[i]);
								}
							}
							return $scope.pinCodesList = pincodeMatchList;
						}
						else {// if the customer is new customer
							$scope.searchPincode = "";
							$scope.pinCodesList = response.data.pincodes;
							$scope.pinCodeResponseArray = response.data.pincodes;
						}
						return $scope.pinCodesList;

					} else {
						if (response.data.errorMessage !== undefined && response.data.errorMessage !== "")
							CommonServices.showAlert(response.data.errorMessage);
						else
							// CommonServices.showAlert("Presently our services are not available. Please try after some time");
							CommonServices.showAlert("Error Occured. Please try again later");
					}
				},
				function (error) { // failure
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
				});
			/* CR_NP_0880 ends*/
		},
		cityServiceCall: function () {// this function is service call for getting city
			this.cityResponse = RestServices.postService(RestServices.urlPathsNewPortal.getCitiesList, $scope.cityData);
			return this.cityResponse.then(
				function (response) { // success 
					/* CR_NP_0880 Starts*/
					CommonServices.showLoading(false);
					if (response.data.cities !== undefined && response.data.cities !== "") {
						if ($scope.partyCode !== "" && $scope.partyCode !== undefined) {// if the cutomer is existing customer

							response.data.cities.filter(function (b) { //this filter will compare the responseCity with the response data
								if ($scope.responseCity !== "" && $scope.responseCity !== undefined && b.cityCode === $scope.responseCity) {
									$scope.policyDetailsObj.countryCity = b;
									$scope.responseCity = "";
									// $scope.searchPincode = {"state":$scope.policyDetailsObj.contState.state,"city":$scope.policyDetailsObj.countryCity.city,"zipCode":""};
									// $scope.policyDetailsObj.pinCodeServiceCall();
								}
							});
							$scope.policyDetailsObj.countryCity = response.data.cities[0];
							// $scope.cityData="";
							$scope.cityList = response.data.cities;
						}
						else {// if the cutomer is new customer
							$scope.cityData = "";
							$scope.policyDetailsObj.countryCity = response.data.cities[0];
							$scope.cityList = response.data.cities;
						}
						return $scope.cityList;
					} else {
						if (response.data.errorMessage !== undefined && response.data.errorMessage !== "")
							CommonServices.showAlert(response.data.errorMessage);
						else
							// CommonServices.showAlert("Presently our services are not available. Please try after some time");
							CommonServices.showAlert("Error Occured. Please try again later");
					}
				},
				function (error) { // failure
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
				});
			/* CR_NP_0880 ends*/
		},
		gstFunc: function (obj, data) { // This function has the service call for getting StateList and CityList
			/*CR_NP_0880 starts */
			if (data === "state") { // This will give list of states
				this.placeOfLoss = "";
				this.countryCity = "";
				$scope.disablePinCode = true;
				// $scope.disableCity = true;
				$scope.stateErr = true;
				$scope.pinCodeErr = false;
				$scope.cityErr = false;

				if (obj.length === 3) { // When entered value is of 3 digit
					$scope.stateData = { "state": obj.toUpperCase() };
					return this.stateServiceCall();
				} else {  // When entered value is more than 3 digit 
					if (obj.length > 3) {
						return ($filter('filter')($scope.stateList, { state: obj }));
					} else {
						$scope.stateList = {};
						return $scope.stateList;
					}
				}
			}

			if (data === 'pinCode') {
				$scope.pinCodeErr = true;
				$scope.cityErr = false;
				// $scope.disableCity = true;
				this.countryCity = "";

				if ($scope.pinCodeResponseArray != undefined && $scope.pinCodeResponseArray != "") {
					var matchList = [];
					$scope.pinCodesList = $scope.pinCodeResponseArray;
					for (var i = 0; i < $scope.pinCodesList.length; i++) {
						if ($scope.pinCodesList[i].match(obj)) {
							matchList.push($scope.pinCodesList[i]);
						}
					}
					return $scope.pinCodesList = matchList;
				} else { // New Customer when there is no pincode list
					$scope.searchPincode = { "state": this.contState.state === undefined ? this.contState.toUpperCase() : this.contState.state.toUpperCase(), "zipCode": obj };
					return this.pinCodeServiceCall();
				}
			}

			if (data === "city") { // This will give list of cities
				$scope.cityErr = true;
				if (obj.length === 1) { // When entered value is of 1 digit
					$scope.cityData = { "state": this.contState.state === undefined ? this.contState.toUpperCase() : this.contState.state.toUpperCase(), "zipCode": this.placeOfLoss, "city": obj.toUpperCase() };
					return this.cityServiceCall();
				}
				else { // When entered value is more than 1 digit
					if ($scope.cityList != undefined && $scope.cityList != "") { // if cities list is available
						return ($filter('filter')($scope.cityList, { city: obj }));
					} else {
						$scope.cityData = { "state": this.contState.state === undefined ? this.contState.toUpperCase() : this.contState.state.toUpperCase(), "zipCode": this.placeOfLoss, "city": obj.toUpperCase() };
						return this.cityServiceCall();
					}

				}
			}
			/*CR_NP_0880 Ends */
			/*/3712 Starts////////
			if (data === "country"){
				$scope.countryErr = true;
				//$scope.InsuredDetails.clientCountry.$setValidity("clientCountry", false);
				// $scope.policyHolderForm.invalid = true;
				if (obj.length === 3) { // When entered value is of 3 digit
					$scope.stateData = { "state": obj.toUpperCase() };
					return this.countryServiceCall(obj);
				} else {  // When entered value is more than 3 digit 
					if (obj.length > 3) {
						return ($filter('filter')($scope.stateList, { state: obj }));
					} else {
						$scope.stateList = {};
						return $scope.stateList;
					}
				}
			}
			/// 3712 ends//////*/
		},
		/*/3712 starts //
		onSelectCountry: function ($item, $model, $label) {// onchange of state input field//3712
			console.log($item);
			$scope.countryErr = false;
			// $scope.policyHolderForm.$invalid = false;
			//$scope.InsuredDetails.clientCountry.$setValidity("clientCountry", true);
		},
		// 3712 ends */
		onSelectState: function ($item, $model, $label) {// onchange of state input field
			/*CR_NP_0880 starts */
			$scope.stateErr = false;
			$scope.pinCodeErr = true;
			$scope.cityErr = false;
			$scope.disablePinCode = false;
			// $scope.disableCity = true;

			$scope.policyDetailsObj.placeOfLoss = "";
			$scope.policyDetailsObj.countryCity = "";
			$scope.pinCodeResponseArray = ""; // To make Pincode response list empty
//UC for CR3749
			// angular.forEach(CommonServices.gstIdStateCode,function(value,key){
			// 	if($scope.policyDetailsObj.contState.state == value){
			// 		$scope.gstinMsg = "GSTIN should start with "+key;
			// 	}

			// });

			// $scope.policyDetailsObj.gstIDInputChangeFunc();
		},
		onSelectPinCode: function ($item, $model, $label) {// onchange of pincode input field
			$scope.pinCodeErr = false;
			$scope.cityErr = false;
			// $scope.disableCity = true;

			$scope.cityData = { "state": ($scope.policyDetailsObj.contState.state === undefined) ? $scope.policyDetailsObj.contState.toUpperCase() : $scope.policyDetailsObj.contState.state.toUpperCase(), "zipCode": $scope.policyDetailsObj.placeOfLoss, "city": "" };
			return this.cityServiceCall();
		},
		onSelectCity: function ($item, $model, $label) {// onchange of city input field
			$scope.policyHolderForm.$invalid = false;
			$scope.cityErr = false;
		},
		/*CR_NP_0880 Ends */

		selectGstIDFunct: function (data) { // This function will validate the GSTIN values according to the changes in GSTID Type values

			if (this.gstRegID == '' || this.gstRegID == undefined) {
				this.gstINModel = "";
				$scope.InsuredDetails.gstIN.$setValidity("validateNIAPAN", true);
				$scope.InsuredDetails.gstIN.$setValidity("gstinPattern", true);
				$scope.InsuredDetails.gstIN.$invalid = false;
				$scope.InsuredDetails.$invalid = false;
				$scope.policyDetailsObj.uinModel ='';

			}

			var reg = "";


			if (this.gstINModel !== "" && this.gstINModel !== undefined) {
				if (this.gstINModel.length === 15) {
					$scope.InsuredDetails.gstIN.$invalid = false;
					$scope.InsuredDetails.$invalid = false;
				}
			}
			else {
				$scope.InsuredDetails.gstIN.$invalid = true;
				$scope.InsuredDetails.$invalid = true;
			}
			if (this.gstRegID === "NCC") {
				reg = regexGSTidGlobal;///^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[A-Z0-9]{2}[^\s]$/;
			}
			if (this.gstRegID === "NRI") {
				reg = /^[0-9]{12}N[A-Z0-9]{1}T$/;
				$scope.InsuredDetails.gstIN.$setValidity("gstStateCode", true);
			}
			if (this.gstRegID === "UNB") {
				reg = /^[0-9]{12}U[A-Z0-9]{1}N$/;
				$scope.InsuredDetails.gstIN.$setValidity("gstStateCode", true);
			}

			var valid = "";

			if (this.gstINModel !== "" || this.gstINModel !== undefined) {
				if (reg === "") {
					valid = true;
				}
				else {
					if (this.gstINModel !== undefined && this.gstINModel !== "") {
						valid = reg.test(this.gstINModel.toUpperCase());
					}
				}

			}


			if (!valid) {
				$scope.InsuredDetails.gstIN.$setValidity("gstIN", false);
				$scope.InsuredDetails.$invalid = true;
				$scope.InsuredDetails.gstIN.$invalid = true;
			}
			else {
				$scope.InsuredDetails.gstIN.$setValidity("gstIN", true);
				$scope.InsuredDetails.$invalid = false;
				$scope.InsuredDetails.gstIN.$invalid = false;
			}

		},
		dateOfBirthFunc: function () {
			var rgValDt = $scope.buyNow.personalAccident.insuredDetails.dateOfBirth; // dd/mm/yyyy
			var rgValDtArr = rgValDt.split("/");
			rgValDt = rgValDtArr[1] + "/" + rgValDtArr[0] + "/" + rgValDtArr[2]; // mm/dd/yyyy
			rgValDtVal = new Date(rgValDt);
			var enableRegVal = new Date(enableRegValCalendarTo);
			if (rgValDtVal > enableRegVal) {
				CommonServices.showAlert(" Age should be greater than or equal to 18 years and less than 70 years on the date of generating the quote");
				$scope.buyNow.personalAccident.insuredDetails.dateOfBirth = "";
			}
			else
				this.compareBirthDate();
		},
		//compare Premium Calculator date with insured Details DOB
		compareBirthDate: function () {// this will compare the date entered in travel details screen and policy holder screen
			if ($scope.buyNow.personalAccident.insuredDetails.dateOfBirth !== undefined && $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthself !== undefined) {

				var lossDateComp = $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthself;
				var drr = lossDateComp.split('/');
				lossDateComp = drr[1] + '/' + drr[0] + '/' + drr[2]; //mm/dd/yyyy

				var policyStartDateComp = $scope.buyNow.personalAccident.insuredDetails.dateOfBirth;
				var srr = policyStartDateComp.split('/');
				policyStartDateComp = srr[1] + '/' + srr[0] + '/' + srr[2]; //mm/dd/yyyy

				lossDateComp = new Date(lossDateComp);
				policyStartDateComp = new Date(policyStartDateComp);
				if (lossDateComp.getTime() === policyStartDateComp.getTime()) {

				}
				else {
					CommonServices.showAlert("There is a mismatch between the Date of Birth entered for Proposer and Policy Holder which may cause changes in premium. Please note that the Date of Birth entered in the Policy holder/Personal information shall be considered for premium calculation ");

				}

			}
			return true;

		},

		policyHolderFunc: function (data) {
			this.fieldDisable = false;
			this.existingCustomerBtn = true;
			this.showSmallTbl = false;
			this.showSearchResTbl = false;
			$rootScope.polHolderDetails=true;
			if (data === "existingPolicyHolder") {
				this.existingCustomerFlag = true;
				this.newcustomerFlag = false;
				$scope.buyNow.personalAccident.insuredDetailspolicyCode = "";
				$scope.buyNow.personalAccident.insuredDetails.firstName = "";
				$scope.buyNow.personalAccident.insuredDetails.lastName = "";
				$scope.buyNow.personalAccident.insuredDetails.mobNo = "";
				$scope.buyNow.personalAccident.insuredDetails.emailId = "";
			}
			else if (data === "newPolicyHolder") {
				$scope.partyCode = "";
				this.newcustomerFlag = true;
				this.existingCustomerFlag = false;
				/*Added by 851587 for CR_NP_0744, and aadhaar commented for CR_NP_0744E*/
				this.panNoInputDisable = false;
				// this.aadhaarInputDisable = false;
				CommonServices.panNoInputDisable = false;
				// CommonServices.aadhaarInputDisable = false;
				/*CR_NP_0744 Ends*/
				//this.productTitle = "";
				$scope.buyNow.personalAccident.insuredDetails.fName = "";
				$scope.buyNow.personalAccident.insuredDetails.mName = "";
				$scope.buyNow.personalAccident.insuredDetails.lName = "";
				$scope.buyNow.personalAccident.insuredDetails.gender = "";
				$scope.buyNow.personalAccident.insuredDetails.dateOfBirth = "";
				/*
				$scope.buyNow.personalAccident.insuredDetails.clientNationality = "";//3712
				$scope.buyNow.personalAccident.insuredDetails.clientCountry = "";//3712
				*/
				$scope.buyNow.personalAccident.insuredDetails.buildNo = "";
				//this.locality="";
				$scope.policyDetailsObj.placeOfLoss = "";
				$scope.buyNow.personalAccident.insuredDetails.mobileNo = "";
				//this.landlineNumber="";
				$scope.buyNow.personalAccident.insuredDetails.mailId = "";
				$scope.policyDetailsObj.panNo = "";
				$scope.buyNow.personalAccident.insuredDetails.eAsuuranceAccountNo = "";
				$scope.policyDetailsObj.gstRegID = "";
				$scope.policyDetailsObj.gstINModel = "";
				$scope.policyDetailsObj.uinModel = "";
				$scope.policyDetailsObj.contState = "";
				$scope.policyDetailsObj.countryCity = "";
				/*Added by 851587 for CR_NP_0744*/
				this.aadhaarNumber1 = "";
				this.aadhaarNumber2 = "";
				this.aadhaarNumber3 = "";
				/*CR_NP_0744 Ends*/
			}
		},
		showSmallTblFunc: function () {
			$scope.policyDetailsObj.showSmallTbl = true;
			$scope.policyDetailsObj.showSearchResTbl = false;
			$scope.policyDetailsObj.existingCustomerFlag = false;
			$scope.policyDetailsObj.newcustomerFlag = false;
			$scope.policyDetailsObj.existingCustomerFlag = false;
			//$scope.policyDetailsObj.policyHolder = "existingPolicyHolder";
		},
		setValue: function (data) { // this is to set values to the input fields at the time of edit 
			//$scope.InsuredDetails.gstIN.$invalid = false;
			//$scope.InsuredDetails.gstIN.$valid = true;
			/*Added by 851587 for CR_NP_0744*/
			// To set the values on load of the page
			if ($scope.policyDetailsObj.panNoInputDisable == undefined || $scope.policyDetailsObj.panNoInputDisable == "") {
				$scope.policyDetailsObj.panNoInputDisable = CommonServices.panNoInputDisable;
			}
			/*CR_NP_0744E starts */
			// if($scope.policyDetailsObj.aadhaarInputDisable == undefined || $scope.policyDetailsObj.aadhaarInputDisable == ""){
			// 	$scope.policyDetailsObj.aadhaarInputDisable = CommonServices.aadhaarInputDisable;
			// }
			/*CR_NP_0744 and CR_NP_0744E ends*/
			var partyDetails = { "savedPartyDetails": { "partyDetails": { "individualDetails": data.individualDetails } } };
			partyDetails.savedPartyDetails.partyDetails.partyCode = data.partyCode;
			partyDetails.savedPartyDetails.partyDetails.policyHolder = this.policyHolder;
			angular.extend($rootScope.insuredData, partyDetails);

			if (data.individualDetails.firstName !== undefined && data.individualDetails.firstName !== "")
				$scope.buyNow.personalAccident.insuredDetails.fName = data.individualDetails.firstName;
			if (data.individualDetails.middleName !== undefined && data.individualDetails.middleName !== "")
				$scope.buyNow.personalAccident.insuredDetails.mName = data.individualDetails.middleName;
			if (data.individualDetails.lastName !== undefined && data.individualDetails.lastName !== "")
				$scope.buyNow.personalAccident.insuredDetails.lName = data.individualDetails.lastName;
			if (data.individualDetails.gender !== undefined && data.individualDetails.gender !== "")
				$scope.buyNow.personalAccident.insuredDetails.gender = data.individualDetails.gender;
			if (data.individualDetails.dateOfBirth !== undefined && data.individualDetails.dateOfBirth !== "")
				$scope.buyNow.personalAccident.insuredDetails.dateOfBirth = data.individualDetails.dateOfBirth;
			/*//// 3712 Starts  ////////
			if(data.individualDetails.clientNationality = "NonIndian"){
				$scope.isNonIndia = true;
			}else{
				$scope.isNonIndia = false;
			}
			if(data.individualDetails.clientNationality!=undefined && data.individualDetails.clientNationality!=""){
				$scope.isNationalityExists = true;
				$scope.buyNow.personalAccident.insuredDetails.clientNationality = data.individualDetails.clientNationality;
			}else{
				$scope.isNationalityExists = false;
			}
			if(data.individualDetails.clientCountry!=undefined && data.individualDetails.clientCountry!=""){
				$scope.isCountryExists = true;
				$scope.buyNow.personalAccident.insuredDetails.clientCountry = data.individualDetails.clientCountry;
			}else{
				$scope.isCountryExists =false;
			}
			/////// 3712 Ends   ///////*/
			if (data.individualDetails.buildingNoStreet !== undefined && data.individualDetails.buildingNoStreet !== "")
				$scope.buyNow.personalAccident.insuredDetails.buildNo = data.individualDetails.buildingNoStreet;
			if (data.individualDetails.mobileNo !== undefined && data.individualDetails.mobileNo !== "")
				$scope.buyNow.personalAccident.insuredDetails.mobileNo = data.individualDetails.mobileNo;
			if (data.individualDetails.emailId !== undefined && data.individualDetails.emailId !== "")
				$scope.buyNow.personalAccident.insuredDetails.mailId = data.individualDetails.emailId;
			/*Changed by 851587 for CR_NP_0744*/
			if (data.individualDetails.panNumber !== undefined && data.individualDetails.panNumber !== "" && $scope.regexPanNo.test(data.individualDetails.panNumber)) {
				this.panNo = data.individualDetails.panNumber;
			} else {
				this.panNo = "";
			}

			if (data.individualDetails.aadhaarNo !== undefined && data.individualDetails.aadhaarNo !== "" && $scope.regexAadhaarNumber.test(data.individualDetails.aadhaarNo)) {
				this.aadhaarNumber1 = data.individualDetails.aadhaarNo.substr(0, 4);
				this.aadhaarNumber2 = data.individualDetails.aadhaarNo.substr(4, 4);
				this.aadhaarNumber3 = data.individualDetails.aadhaarNo.substr(8, 4);
			} else {
				this.aadhaarNumber1 = "";
				this.aadhaarNumber2 = "";
				this.aadhaarNumber3 = "";
			}
			/* CR_NP_0744 ends*/

			if (data.individualDetails.eInsuranceAccountNo !== undefined && data.individualDetails.eInsuranceAccountNo !== "")
				$scope.buyNow.personalAccident.insuredDetails.eAsuuranceAccountNo = data.individualDetails.eInsuranceAccountNo;
			if (data.individualDetails.gstRegIdType !== undefined && data.individualDetails.gstRegIdType !== "")
				this.gstRegID = data.individualDetails.gstRegIdType;
			if (data.individualDetails.gstin !== undefined && data.individualDetails.gstin !== "")
				this.gstINModel = data.individualDetails.gstin;
			if (data.individualDetails.uin !== undefined && data.individualDetails.uin !== "")
				this.uinModel = data.individualDetails.uin;
			if (data.individualDetails.state !== undefined && data.individualDetails.state !== "") {
			$scope.partyCode = data.partyCode;
				$scope.responseState = data.individualDetails.state;
				$scope.responseCity = data.individualDetails.city;
				$scope.responsepinCode = data.individualDetails.pinCode;
				$scope.stateData = { "state": "" };
				return $scope.policyDetailsObj.stateServiceCall();
			}

		},
		panDisableFunc: function () {
			/*Added by 851587 for CR_NP_0744, aadhaar commented for CR_NP_0744E*/
			if ($scope.policyDetailsObj.panNoInputDisable === true) {
				CommonServices.panNoInputDisable = true;
			}
			// if($scope.policyDetailsObj.aadhaarInputDisable === true){
			// CommonServices.aadhaarInputDisable = true;
			// }
			/*CR_NP_0744 and CR_NP_0744E ends*/

			/*Added by 851587 during CR_NP_0744, as PolicyHolder value is not available on editing the policyHolder and navigate back from Summary.*/
			CommonServices.setCommonData("policyHolder", $scope.policyDetailsObj.policyHolder);
		},
		minimizeForm: function () {
			this.showSmallTbl = true;
			this.newcustomerFlag = false;
			this.fieldDisable = false;
			this.existingCustomerBtn = true;
			$scope.partyCode = "";
		},
		updateDetails: function () { // this is to update policy holder detail
			/*Changed by 851587 for CR_NP_0744*/
			if (this.aadhaarNumber1 != undefined && this.aadhaarNumber1 != '' && this.aadhaarNumber2 != undefined && this.aadhaarNumber2 != '' && this.aadhaarNumber3 != undefined && this.aadhaarNumber3 != '') {
				$scope.policyDetailsObj.aadhaarNumber = this.aadhaarNumber1 + this.aadhaarNumber2 + this.aadhaarNumber3;
			} else {
				$scope.policyDetailsObj.aadhaarNumber = "";
			}

			if ($scope.buyNow.personalAccident.individualDetails.individualDetails.mobileNo === $scope.buyNow.personalAccident.insuredDetails.mobileNo
				&& $scope.buyNow.personalAccident.individualDetails.individualDetails.emailId === $scope.buyNow.personalAccident.insuredDetails.mailId
				&& $scope.buyNow.personalAccident.individualDetails.individualDetails.gstRegIdType === $scope.policyDetailsObj.gstRegID
				&& $scope.buyNow.personalAccident.individualDetails.individualDetails.gstin === $scope.policyDetailsObj.gstINModel
				/*
				&& $scope.buyNow.personalAccident.individualDetails.individualDetails.clientNationality === $scope.policyDetailsObj.clientNationality//3712
				&& $scope.buyNow.personalAccident.individualDetails.individualDetails.clientCountry === $scope.policyDetailsObj.clientCountry//3712
				*/
				&& $scope.buyNow.personalAccident.individualDetails.individualDetails.panNumber === this.panNo
				&& $scope.buyNow.personalAccident.individualDetails.individualDetails.uin === $scope.policyDetailsObj.uinModel
				&& $scope.buyNow.personalAccident.individualDetails.individualDetails.city === $scope.policyDetailsObj.countryCity.cityCode
				&& $scope.buyNow.personalAccident.individualDetails.individualDetails.state === $scope.policyDetailsObj.contState.stateCode
				&& $scope.buyNow.personalAccident.individualDetails.individualDetails.pinCode === $scope.policyDetailsObj.placeOfLoss.zipCode
				&& $scope.buyNow.personalAccident.individualDetails.individualDetails.buildingNoStreet === $scope.buyNow.personalAccident.insuredDetails.buildNo) {// If nothing has changed
				//to store values in field
				/*CR_NP_0744E Ends*/
				$scope.buyNow.personalAccident.insuredDetails.fName = "";
				$scope.buyNow.personalAccident.insuredDetails.mName = "";
				$scope.buyNow.personalAccident.insuredDetails.lName = "";
				$scope.buyNow.personalAccident.insuredDetails.gender = "";
				$scope.buyNow.personalAccident.insuredDetails.dateOfBirth = "";
				$scope.buyNow.personalAccident.insuredDetails.clientNationality = "";
				$scope.buyNow.personalAccident.insuredDetails.clientCountry = "";
				$scope.buyNow.personalAccident.insuredDetails.buildNo = "";
				$scope.policyDetailsObj.placeOfLoss = "";
				$scope.buyNow.personalAccident.insuredDetails.mobileNo = "";
				$scope.buyNow.personalAccident.insuredDetails.mailId = "";
				$scope.policyDetailsObj.panNo = "";
				$scope.buyNow.personalAccident.insuredDetails.eAsuuranceAccountNo = "";
				$scope.policyDetailsObj.gstRegID = "";
				$scope.policyDetailsObj.gstINModel = "";
				$scope.policyDetailsObj.uinModel = "";
				$scope.policyDetailsObj.contState = "";
				$scope.policyDetailsObj.countryCity = "";

				this.fieldDisable = false;
				$scope.policyDetailsObj.showSmallTblFunc();
			}
			else {// if there are changes in values
				var updatepolicyHolderData =
					{
						"userCode": username.toUpperCase(),
						"rolecode": "SUPERUSER",
						"policyHolderCode": $scope.showSmallData.partyCode,
						"mobileNo": $scope.buyNow.personalAccident.insuredDetails.mobileNo.toUpperCase(),
						"dateOfBirth": $scope.buyNow.personalAccident.insuredDetails.dateOfBirth,
						/*
						"clientNationality": $scope.policyDetailsObj.clientNationality,//3712
						"clientCountry": $scope.policyDetailsObj.clientCountry.stateCode,//3712
						*/
						"gstRegIdType": $scope.policyDetailsObj.gstRegID !== undefined ? $scope.policyDetailsObj.gstRegID.toUpperCase() : "",
						"gstin": $scope.policyDetailsObj.gstINModel !== undefined ? $scope.policyDetailsObj.gstINModel.toUpperCase() : "",
						"uin": $scope.policyDetailsObj.uinModel !== undefined ? $scope.policyDetailsObj.uinModel.toUpperCase() : "",
						"city": $scope.policyDetailsObj.countryCity.cityCode.toUpperCase(),
						"state": $scope.policyDetailsObj.contState.stateCode.toUpperCase(),
						"pinCode": $scope.policyDetailsObj.placeOfLoss.toUpperCase(), //CR_NP_0880
						"addressLine1": $scope.buyNow.personalAccident.insuredDetails.buildNo.toUpperCase(),
						"emailId": $scope.buyNow.personalAccident.insuredDetails.mailId !== undefined ? $scope.buyNow.personalAccident.insuredDetails.mailId : "",
						/*Added for CR_NP_0744*/
						"panNumber": this.panNo,
						"aadhaarNo": $scope.policyDetailsObj.aadhaarNumber
						/*CR_NP_0744 ends*/
					};

				var updatePolicyHolderContact = RestServices.postService(RestServices.urlPathsNewPortal.updatePolicyHolderContact, updatepolicyHolderData);
				updatePolicyHolderContact.then(
					function (response) { // success 

						CommonServices.showLoading(false);
						if (response.data.errorCode === undefined) {
							if (response.data.pRetCode === "0") {
								//to store data after coming back
								var updatePolicyData = {
									"savedPartyDetails": {
										"partyDetails": {
											"individualDetails": {
												"firstName": $scope.buyNow.personalAccident.insuredDetails.fName,
												"lastName": $scope.buyNow.personalAccident.insuredDetails.lName,
												"middleName": $scope.buyNow.personalAccident.insuredDetails.mName,
												"gender": $scope.buyNow.personalAccident.insuredDetails.gender,
												"dateOfBirth": $scope.buyNow.personalAccident.insuredDetails.dateOfBirth,
												/*
												"clientNationality": "NonIndian",//3712
												"clientCountry": "Brazil",//3712
												*/
												"buildingNoStreet": $scope.buyNow.personalAccident.insuredDetails.buildNo,
												"pinCode": $scope.policyDetailsObj.placeOfLoss, //CR_NP_0880
												"mobileNo": $scope.buyNow.personalAccident.insuredDetails.mobileNo,
												"emailId": $scope.buyNow.personalAccident.insuredDetails.mailId,
												"panNumber": $scope.policyDetailsObj.panNo,
												"aadhaarNo": $scope.policyDetailsObj.aadhaarNumber,
												"eInsuranceAccountNo": $scope.buyNow.personalAccident.insuredDetails.eAsuuranceAccountNo,
												"gstRegIdType": $scope.policyDetailsObj.gstRegID,
												"gstin": $scope.policyDetailsObj.gstINModel,
												"uin": $scope.policyDetailsObj.uinModel,
												"city": $scope.policyDetailsObj.countryCity.cityCode,
												"state": $scope.policyDetailsObj.contState.stateCode
											},
											"partyType": $scope.buyNow.personalAccident.insuredDetails.partyType
										}
									}
								};
                	/* CR_NP_594A starts*/
								$rootScope.dateOfBirthEmpty = false;
								/* CR_NP_594A ends*/
/*CR_NP_0880*/
								$scope.buyNow.personalAccident.individualDetails.individualDetails.state = $scope.policyDetailsObj.contState.state;
								$scope.buyNow.personalAccident.individualDetails.individualDetails.pinCode = $scope.policyDetailsObj.placeOfLoss;
								$scope.buyNow.personalAccident.individualDetails.individualDetails.city = $scope.policyDetailsObj.countryCity.city;
								$scope.partyCode = "";
								angular.extend($rootScope.insuredData, updatePolicyData);
								CommonServices.showAlert(response.data.pRetErr);
								$scope.policyDetailsObj.fieldDisable = false;
								$scope.showSmallData = $rootScope.insuredData.savedPartyDetails.partyDetails;
								$scope.policyDetailsObj.showSmallTblFunc();
								updatePolicyData.savedPartyDetails.partyDetails.partyCode = response.data.policyHolderCode;
								//$scope.buyNow.personalAccident.insuredDetails.mobileNo = response.data.mobileNo;//updating input field
								CommonServices.setCommonData("partyHoldersCode", $scope.showSmallData.partyCode);
								$scope.getPolicyDetails($scope.showSmallData.partyCode);
								angular.extend($rootScope.insuredData, updatePolicyData);
							} else {
								CommonServices.showAlert("Please try again after some time.");
							}
						}
						else {
							CommonServices.showAlert(response.data.errorMessage);
						}

					},
					function (error) { // failure
						CommonServices.showLoading(false);
						RestServices.handleWebServiceError(error);
					});
			}

		}
	}
	//GST Code End

	//Retrive data on click of back
	if ($rootScope.backData === "insuredDetailsPage") {
		$scope.policyDetailsObj.policyHolder = CommonServices.getCommonData("policyHolder");
		$scope.policyDetailsObj.showSmallTblFunc();
		var code = CommonServices.getCommonData("partyHoldersCode");
		$scope.getPolicyDetails(code);
		$scope.policyDetailsObj.showSmallTbl = true;//to display created data
		$scope.policyDetailsObj.newcustomerFlag = false;//to hide existing page
	}


	if ($rootScope.resetData == true) {
		$scope.buyNow.personalAccident.insuredDetails.nomineeName = "";
		$scope.buyNow.personalAccident.insuredDetails.relationshipself = "";
	}
//CR_0054
	else if(CommonServices.editQuoteFlag === true){
		$scope.buyNow.personalAccident.insuredDetails.nomineeName=CommonServices.personalAccidentObj.risks[0].riskDetails.nomineeName;
		$scope.buyNow.personalAccident.insuredDetails.relationshipself=CommonServices.personalAccidentObj.risks[0].riskDetails.relationWithNominee;
	}
	else {
		$scope.buyNow.personalAccident.insuredDetails.nomineeName = CommonServices.getCommonData("nomineeNameSelf");
		$scope.buyNow.personalAccident.insuredDetails.relationshipself = CommonServices.getCommonData("relationshipSelf");
	}
//CR_0054
	if(CommonServices.editQuoteFlag === true){
		$scope.buyNow.personalAccident.insuredDetails.nomineeName=CommonServices.personalAccidentObj.risks[0].riskDetails.nomineeName;
		$scope.buyNow.personalAccident.insuredDetails.relationshipself=CommonServices.personalAccidentObj.risks[0].riskDetails.relationWithNominee;
	}
}]);
agentApp.controller('SpouseDetailsCtrl', ['$scope', '$rootScope', '$location', 'RestServices', 'CommonServices', '$state', function ($scope, $rootScope, $location, RestServices, CommonServices, $state) {
	/*$scope.countryErr = false;//3712*/
	$scope.buyNow.personalAccident.spouseDetails = {};
	$scope.RelationshipWithNominee = CommonServices.getCommonData("RELATIONSHIP_WITH_NOMINEE");
	/*CR 3562 START*/
	$scope.prevNomineeDetailObj = CommonServices.getCommonData('paPolicyAutopopulatedData');
	if ($scope.prevNomineeDetailObj != undefined) {
		// angular.forEach($scope.prevNomineeDetailObj, function(obj, i) {
		// 	if (obj.isSelected && obj.relation.toLowerCase() === 'spouse') {
		// 		$scope.buyNow.personalAccident.spouseDetails.InsuredName = obj.name;
		// 		CommonServices.setCommonData("insuredNameSpouse", obj.name);
		// 	}
		// });
		if($scope.prevNomineeDetailObj.spouse != undefined)
			$scope.buyNow.personalAccident.spouseDetails.InsuredName = $scope.prevNomineeDetailObj.spouse.name;
	}
	/*CR 3562 END*/
	/*CR 3712 starts //
	$scope.isNonIndia = false;
	// $scope.policyDetailsObj.clientNationality ="";
	$scope.onNationalityChange = function(){
		$scope.buyNow.personalAccident.spouseDetails.clientCountry = '';
		if($scope.buyNow.personalAccident.spouseDetails.clientNationality == "NonIndian"){
			$scope.isNonIndia = true;
		}
		else{
			$scope.isNonIndia = false;
		}
	}
	//  CR_3712 ends*/
	$scope.back = function () {
		$rootScope.backData = "insuredDetailsPage";
		$rootScope.resetData = false;
		$state.go('InsuredDetails');

	};
	if (spouse == true) {
		$scope.slideshowModal = true;
		$scope.slideshowModal1 = true;
		$scope.slideshowModal2 = true;
		$scope.spouseDetails = true;
		$scope.SaveCalculatePremiumModal1b = true;
		if (countd == 1 && counts == 1) {
			$scope.slideshowModal3 = true;
			$scope.slideshowModal4 = true;
			$scope.sonDetails = true;
			$scope.daughterDetails = true;
			$scope.DetailsScreenSpouse = function () {
				// $scope.prevNomineeDetailObj.spouse.name = $scope.buyNow.personalAccident.spouseDetails.InsuredName
				CommonServices.setCommonData("insuredNameSpouse", $scope.buyNow.personalAccident.spouseDetails.InsuredName);
				CommonServices.setCommonData("nomineeNameSpouse", $scope.buyNow.personalAccident.spouseDetails.nomineeName);
				CommonServices.setCommonData("relationshipSpouse", $scope.buyNow.personalAccident.spouseDetails.relationship);
				/*
				CommonServices.setCommonData("clientNationality", $scope.buyNow.personalAccident.spouseDetails.clientNationality);//3712
				CommonServices.setCommonData("clientCountry", $scope.buyNow.personalAccident.spouseDetails.clientCountry);//3712
				*/
				$state.go('SonDetails');
			};
		} else if (countd == 2 && counts == 0) {
			$scope.slideshowModal4 = true;
			$scope.daughterDetails = true;
			$scope.SaveCalculatePremiumModal1b = true;
			$scope.DetailsScreenSpouse = function () {
				// $scope.prevNomineeDetailObj.spouse.name = $scope.buyNow.personalAccident.spouseDetails.InsuredName
				CommonServices.setCommonData("insuredNameSpouse", $scope.buyNow.personalAccident.spouseDetails.InsuredName);
				CommonServices.setCommonData("nomineeNameSpouse", $scope.buyNow.personalAccident.spouseDetails.nomineeName);
				CommonServices.setCommonData("relationshipSpouse", $scope.buyNow.personalAccident.spouseDetails.relationship);
				/*
				CommonServices.setCommonData("clientNationality", $scope.buyNow.personalAccident.spouseDetails.clientNationality);//3712
				CommonServices.setCommonData("clientCountry", $scope.buyNow.personalAccident.spouseDetails.clientCountry);//3712
				*/
				$state.go('DaughterDetails');
			};
		} else if (counts == 2 && countd == 0) {
			$scope.slideshowModal3 = true;
			$scope.sonDetails = true;
			$scope.SaveCalculatePremiumModal1b = true;
			$scope.DetailsScreenSpouse = function () {
				// $scope.prevNomineeDetailObj.spouse.name = $scope.buyNow.personalAccident.spouseDetails.InsuredName
				CommonServices.setCommonData("insuredNameSpouse", $scope.buyNow.personalAccident.spouseDetails.InsuredName);
				CommonServices.setCommonData("nomineeNameSpouse", $scope.buyNow.personalAccident.spouseDetails.nomineeName);
				CommonServices.setCommonData("relationshipSpouse", $scope.buyNow.personalAccident.spouseDetails.relationship);
				/*
				CommonServices.setCommonData("clientNationality", $scope.buyNow.personalAccident.spouseDetails.clientNationality);//3712
				CommonServices.setCommonData("clientCountry", $scope.buyNow.personalAccident.spouseDetails.clientCountry);//3712
				*/
				$state.go('SonDetails');
			};
		} else if (counts == 1) {
			$scope.slideshowModal3 = true;
			$scope.SaveCalculatePremiumModal1b = true;
			$scope.sonDetails = true;
			$scope.DetailsScreenSpouse = function () {
				// $scope.prevNomineeDetailObj.spouse.name = $scope.buyNow.personalAccident.spouseDetails.InsuredName
				CommonServices.setCommonData("insuredNameSpouse",  $scope.buyNow.personalAccident.spouseDetails.InsuredName);
				CommonServices.setCommonData("nomineeNameSpouse", $scope.buyNow.personalAccident.spouseDetails.nomineeName);
				CommonServices.setCommonData("relationshipSpouse", $scope.buyNow.personalAccident.spouseDetails.relationship);
				/*
				CommonServices.setCommonData("clientNationality", $scope.buyNow.personalAccident.spouseDetails.clientNationality);//3712
				CommonServices.setCommonData("clientCountry", $scope.buyNow.personalAccident.spouseDetails.clientCountry);//3712
				*/
				$state.go('SonDetails');
			};
		} else if (countd == 1) {
			$scope.slideshowModal4 = true;
			$scope.SaveCalculatePremiumModal1b = true;
			$scope.daughterDetails = true;
			$scope.DetailsScreenSpouse = function () {
				// $scope.prevNomineeDetailObj.spouse.name = $scope.buyNow.personalAccident.spouseDetails.InsuredName
				CommonServices.setCommonData("insuredNameSpouse", $scope.buyNow.personalAccident.spouseDetails.InsuredName);
				CommonServices.setCommonData("nomineeNameSpouse", $scope.buyNow.personalAccident.spouseDetails.nomineeName);
				CommonServices.setCommonData("relationshipSpouse", $scope.buyNow.personalAccident.spouseDetails.relationship);
				/*
				CommonServices.setCommonData("clientNationality", $scope.buyNow.personalAccident.spouseDetails.clientNationality);//3712
				CommonServices.setCommonData("clientCountry", $scope.buyNow.personalAccident.spouseDetails.clientCountry);//3712
				*/
				$state.go('DaughterDetails');
			};
		} else {
			$scope.SaveCalculatePremiumModal1a = true;
			$scope.SaveCalculatePremiumModal1b = false;
			$scope.DetailsScreenSpouse = function () {
				// $scope.prevNomineeDetailObj.spouse.name = $scope.buyNow.personalAccident.spouseDetails.InsuredName
				CommonServices.setCommonData("insuredNameSpouse", $scope.buyNow.personalAccident.spouseDetails.InsuredName);
				CommonServices.setCommonData("nomineeNameSpouse", $scope.buyNow.personalAccident.spouseDetails.nomineeName);
				CommonServices.setCommonData("relationshipSpouse", $scope.buyNow.personalAccident.spouseDetails.relationship);
				/*
				CommonServices.setCommonData("clientNationality", $scope.buyNow.personalAccident.spouseDetails.clientNationality);//3712
				CommonServices.setCommonData("clientCountry", $scope.buyNow.personalAccident.spouseDetails.clientCountry);//3712
				*/
				$state.go('PaymentDetails');
			};
		}
	} else if (spouse == false) {
		$scope.slideshowModal = true;
		$scope.slideshowModal1 = true;
		$scope.slideshowModal2 = false;
		if (countd == 1 && counts == 1) {
			$scope.slideshowModal3 = true;
			$scope.slideshowModal4 = true;
		} else if (countd == 2 && counts == 0) {
			$scope.slideshowModal4 = true;
		} else if (countd == 0 && counts == 2) {
			$scope.slideshowModal3 = true;
		} else if (counts == 1) {
			$scope.slideshowModal3 = true;
		} else if (countd == 1) {
			$scope.slideshowModal4 = true;
		} else {
			$scope.slideshowModal = false;
			$scope.SaveCalculatePremiumModal = true;
		}
	}


	$scope.DaughterDetails = function () {
		$state.go('DaughterDetails');
	};
	$scope.SpouseDetails = function () {
		$state.go('SpouseDetails');
	};
	$scope.SonDetails = function () {
		$state.go('SonDetails');
	};
	$scope.InsuredDetailsScreen = function () {
		$rootScope.backData = "insuredDetailsPage";
		$state.go('InsuredDetails');
	};
	$scope.buyNow.personalAccident.insuredDetails.RelationshipWithNominee = CommonServices.getCommonData("RELATIONSHIP_WITH_NOMINEE");
	$scope.calculatePremiumSpouse = function () {
		CommonServices.setCommonData("insuredNameSpouse", $scope.buyNow.personalAccident.spouseDetails.InsuredName);
		CommonServices.setCommonData("nomineeNameSpouse", $scope.buyNow.personalAccident.spouseDetails.nomineeName);
		CommonServices.setCommonData("relationshipSpouse", $scope.buyNow.personalAccident.spouseDetails.relationship);
		/*
		CommonServices.setCommonData("clientNationality", $scope.buyNow.personalAccident.spouseDetails.clientNationality);//3712
		CommonServices.setCommonData("clientCountry", $scope.buyNow.personalAccident.spouseDetails.clientCountry);//3712
		*/
		var username = CommonServices.getCommonData("userCode");
		var partyCodeSelf = CommonServices.getCommonData("partycode");
		var policyHolderName = CommonServices.getCommonData("Name");
		var PremiumData = {
			"userProfile": {
				"userId": username.toUpperCase(),
				"loggedInRole": "SUPERUSER"
			},
			"quote": {
				"isAddOnPA": "N",
				"quoteNumber": quoteNo,
				"policyHolderCode": showData,
				"partyDetailsList": [],
				"productCode": "PU",
				"product": "PU",
				"policyHolderName": policyHolderName.toUpperCase(),
				"policyStartDate": todaysDate,
				"policyExpiryDate": futureDateCal,
				"term": 1,
				"termUnit": "G",
				"eventDate": todaysDate,
				"coverage": str,
				"numChildrenToCover": "0",
				"risks": []
			}
		};
		var premDataArray = [];
		for (var i = 0; i <= 1; i++) {

			if (i == 0)//self
			{
				spouse = false;
				self = true;
				numberOfChildren = 0;
				incomeselfb = "500000";
				incomeselfc = "500000";
				$scope.relation = "SELF";
				occupation = $scope.buyNow.personalAccident.premiumCalculator.occupationself;
				bdate = $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthself;
				relationWithNominee = $scope.buyNow.personalAccident.insuredDetails.relationshipself;
				nomineeName = $scope.buyNow.personalAccident.insuredDetails.nomineeName;
				name = CommonServices.getCommonData("Name");
				/*
				clientNationality = $scope.buyNow.personalAccident.insuredDetails.clientNationality;//3712
				clientCountry = $scope.buyNow.personalAccident.insuredDetails.clientCountry;//3712
				*/
			}
			if (i == 1)//spouse
			{
				if (str == "Self/Spouse" || str == "Self/Spouse/Son/Daughter" || str == "Self/Spouse/Son" || str == "Self/Spouse/Daughter") {
					spouse = true;
					// if (SpouseEarning == "yes") {
						if ($rootScope.spEarning == "yes") {
						incomeselfc = "500000";
						incomeselfb = "500000";
					}
					else {
						incomeselfc = "250000";
						incomeselfb = "250000";
					}
					$scope.relation = "SPOUSE";
					bdate = $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthspouse;
					occupation = $scope.buyNow.personalAccident.premiumCalculator.occupationSpouse;
					name = $scope.buyNow.personalAccident.spouseDetails.InsuredName;
					relationWithNominee = $scope.buyNow.personalAccident.spouseDetails.relationship;
					nomineeName = $scope.buyNow.personalAccident.spouseDetails.nomineeName;
					/*
					clientNationality = $scope.buyNow.personalAccident.spouseDetails.clientNationality;//3712
					clientCountry = $scope.buyNow.personalAccident.spouseDetails.clientCountry;//3712
					*/
				}
				else {
					continue;
				}

			}
			var premData = {
				"coverages": [{
					"coverDetails": { "medicalCoverReq": medicalcheck }
				}],
				"riskDetails": {
					"sumInsuredForTableA": 0,
					"sumInsuredForTableB": incomeselfb,
					"sumInsuredForTableC": incomeselfc,
					"sumInsuredForTableD": 0,
					"relationWithNominee": relationWithNominee,
					"nomineeName": nomineeName,
					"monthlyIncome": "",
					"dateOfBirth": bdate,
					"relationWithPolicyHolder": $scope.relation,
					"nameOfInsuredPerson": name,
					"occupation": occupation
					/*,
					"clientNationality": clientNationality,//3712
					"clientCountry": clientNationality//3712
					*/
				}
			};
			premDataArray.push(premData);

		}
		PremiumData.quote.risks = premDataArray;




		var PremiumDataResponse = RestServices.postService(RestServices.urlPathsNewPortal.saveQuote, PremiumData);
		//web service call for PremiumData
		PremiumDataResponse.then(


			function (response) { // success 

				CommonServices.showLoading(false);
				if (response.data.errorCode === 959) {
					CommonServices.showAlert(response.data.errorMessage);
				}
				else if (response.data.errorMessage !== undefined && response.data.errorMessage !== "") {
					CommonServices.showAlert(response.data.errorMessage);
				}
				else {
					if (response.data.userProfile.footer.errorCode === "1") {
						$scope.buyNow.personalAccident.saveQuoteRes = response.data.quote.premiumDetails;
						quoteNoSelf = response.data.quote.quoteNumber;
						netPremiumSelf = response.data.quote.premiumDetails.netPremium;
						serviceTaxSelf = response.data.quote.premiumDetails.serviceTax;
						totalPremiumSelf = response.data.quote.premiumDetails.totalPremium;
						CommonServices.setCommonData("CollectionPaymentDetails", response.data.quote);
						$rootScope.PAView = true;
						$state.go('PaymentDetails');
					}

					else
						CommonServices.showAlert("Presently our services are not available. Please try after some time");
				}

			},
			function (error) {    // failure 
				CommonServices.showLoading(false);
				RestServices.handleWebServiceError(error);
			});

	};
	//to store values
	if ($rootScope.resetData == true) {
		$scope.buyNow.personalAccident.spouseDetails.InsuredName = "";
		$scope.buyNow.personalAccident.spouseDetails.nomineeName = "";
		$scope.buyNow.personalAccident.spouseDetails.relationship = "";
		/*
		$scope.buyNow.personalAccident.spouseDetails.clientNationality = "";//3712
		$scope.buyNow.personalAccident.spouseDetails.clientCountry = "";//3712
		*/
	}
	else {
		$scope.buyNow.personalAccident.spouseDetails.InsuredName = CommonServices.getCommonData("insuredNameSpouse");
		$scope.buyNow.personalAccident.spouseDetails.nomineeName = CommonServices.getCommonData("nomineeNameSpouse");
		$scope.buyNow.personalAccident.spouseDetails.relationship = CommonServices.getCommonData("relationshipSpouse");
		/*
		$scope.buyNow.personalAccident.spouseDetails.clientNationality = CommonServices.getCommonData("clientNationality");//3712
		$scope.buyNow.personalAccident.spouseDetails.clientCountry = CommonServices.getCommonData("clientCountry");//3712
		*/
	}

}]);

agentApp.controller('DaughterDetailCtrl', ['$scope', '$rootScope', '$location', 'RestServices', 'CommonServices', '$state', function ($scope, $rootScope, $location, RestServices, CommonServices, $state) {
	/*$scope.countryErr = false;//3712 */
	$scope.buyNow.personalAccident.daughterDetails = {};
	$scope.childNominee = CommonServices.getCommonData("childNominee");
	$scope.RelationshipWithNominee = CommonServices.getCommonData("RELATIONSHIP_WITH_NOMINEE");

	/*CR 3562 START*/
	$scope.prevNomineeDetailObj = CommonServices.getCommonData('paPolicyAutopopulatedData');
	if ($scope.prevNomineeDetailObj != undefined) {
		var d = 0;
		// angular.forEach($scope.prevNomineeDetailObj, function(obj, i) {
		// 	if (obj.isSelected && (obj.relation.toLowerCase() === 'children' || obj.relation.toLowerCase() === 'daughter') && obj.sex === 'F' && d === 0) {
		// 		d++;
		// 		$scope.buyNow.personalAccident.daughterDetails.InsuredName = obj.name;
		// 		CommonServices.setCommonData("insuredNameDaught1", obj.name);
				
		// 	} else if (obj.isSelected && (obj.relation.toLowerCase() === 'children' || obj.relation.toLowerCase() === 'daughter') && obj.sex === 'F' && d === 1) {
		// 		d++;
		// 		$scope.buyNow.personalAccident.daughterDetails.InsuredNamed1 = obj.name;
		// 		CommonServices.setCommonData("insuredNameDaught2", obj.name);
		// 	}
		// });
		if($scope.prevNomineeDetailObj.daughter1 != undefined){
			$scope.buyNow.personalAccident.daughterDetails.InsuredName = $scope.prevNomineeDetailObj.daughter1.name;
			CommonServices.setCommonData("insuredNameDaught1", $scope.prevNomineeDetailObj.daughter1.name);
		}
		if($scope.prevNomineeDetailObj.daughter2 != undefined){
			$scope.buyNow.personalAccident.daughterDetails.InsuredName1 = $scope.prevNomineeDetailObj.daughter2.name;
			CommonServices.setCommonData("insuredNameDaught2", $scope.prevNomineeDetailObj.daughter2.name);
		}
	}
	/*CR 3562 END*/

	/*CR 3712 starts //
	$scope.isNonIndia = false;
	$scope.isNonIndiaD1 = false;
	$scope.onNationalityChange = function(){
		$scope.buyNow.personalAccident.daughterDetails.clientCountry = '';
		if($scope.buyNow.personalAccident.daughterDetails.clientNationality == "NonIndian"){
			$scope.buyNow.personalAccident.daughterDetails.isNonIndia = true;
		}
		else{
			$scope.buyNow.personalAccident.daughterDetails.isNonIndia = false;
		}
	}
	$scope.onNationalityChangeD1 = function(){
		$scope.buyNow.personalAccident.daughterDetails.clientCountrydaught1 = '';
		if($scope.buyNow.personalAccident.daughterDetails.clientNationalitydaught1 == "NonIndian"){
			$scope.isNonIndiaD1 = true;
		}
		else{
			$scope.isNonIndiaD1 = false;
		}
	}
	//  CR_3712 ends*/
	if (spouse == true) {
		$scope.slideshowModal = true;
		$scope.slideshowModal1 = true;
		$scope.slideshowModal2 = true;
		if (countd == 1 && counts == 1) {
			$scope.slideshowModal3 = true;
			$scope.slideshowModal4 = true;
			$scope.daughterDetails = true;
			$scope.sonDetails = true;
			$scope.SaveCalculatePremiumModal2ad1 = true;
			$scope.back = function () {
				$rootScope.resetData = false;
				$state.go('SonDetails');
			};
		} else if (countd == 2 && counts == 0) {
			$scope.slideshowModal4 = true;
			$scope.SecondDaughter = true;
			$scope.daughterDetails = true;
			$scope.SaveCalculatePremiumModal2bd1 = true;
			$scope.back = function () {
				$rootScope.resetData = false;
				$state.go('SpouseDetails');
			};
		} else if (counts == 2 && countd == 0) {
			$scope.slideshowModal3 = true;
			$scope.sonDetails = true;
		} else if (counts == 1) {
			$scope.slideshowModal3 = true;
			$scope.sonDetails = true;
		} else if (countd == 1) {
			$scope.slideshowModal4 = true;
			$scope.daughterDetails = true;
			$scope.SaveCalculatePremiumModal2ad1 = true;
			$scope.isRequired = false;
			$scope.back = function () {
				$rootScope.resetData = false
				$state.go('SpouseDetails');
			};
		} else {
			$scope.SaveCalculatePremiumModal1 = true;
			$scope.back = function () {
				$rootScope.resetData = false
				$state.go('SpouseDetails');
			};
		}
	} else if (spouse == false) {
		$scope.slideshowModal = true;
		$scope.slideshowModal1 = true;
		$scope.slideshowModal2 = false;
		if (countd == 1 && counts == 1) {
			$scope.slideshowModal3 = true;
			$scope.slideshowModal4 = true;
			$scope.daughterDetails = true;
			$scope.sonDetails = true;
			$scope.SaveCalculatePremiumModal2ad1 = true;
			$scope.back = function () {
				$rootScope.resetData = false;
				$state.go('SonDetails');
			};
		} else if (countd == 2 && counts == 0) {
			$scope.slideshowModal4 = true;
			$scope.SaveCalculatePremiumModal2bd1 = true;
			$scope.daughterDetails = true;
			$scope.SecondDaughter = true;
			$scope.back = function () {
				$rootScope.resetData = false;
				$rootScope.backData = "insuredDetailsPage";
				$state.go('InsuredDetails');
			};
		} else if (countd == 0 && counts == 2) {
			$scope.slideshowModal3 = true;
			$scope.daughterDetails = true;
		} else if (counts == 1) {
			$scope.slideshowModal3 = true;
			$scope.sonDetails = true;
		} else if (countd == 1) {
			$scope.slideshowModal4 = true;
			$scope.daughterDetails = true;
			$scope.SaveCalculatePremiumModal2ad1 = true;
			$scope.isRequired = false;
			$scope.back = function () {
				$rootScope.resetData = false;
				$rootScope.backData = "insuredDetailsPage";
				$state.go('InsuredDetails');
			};
		} else {
			$scope.slideshowModal = false;
			$scope.SaveCalculatePremiumModal = true;
		}
	}


	$scope.DaughterDetails = function () {
		$state.go('DaughterDetails');
	};
	$scope.SpouseDetails = function () {
		$state.go('SpouseDetails');
	};
	$scope.SonDetails = function () {
		$state.go('SonDetails');
	};
	$scope.InsuredDetailsScreen = function () {
		$state.go('InsuredDetails');
	};

	var username = CommonServices.getCommonData("userCode");
	var policyHolderName = CommonServices.getCommonData("Name");
	$scope.calculatePremium = function () {
		CommonServices.setCommonData("insuredNameDaught1", $scope.buyNow.personalAccident.daughterDetails.InsuredName);
		CommonServices.setCommonData("nomineeNameDaught1", $scope.buyNow.personalAccident.daughterDetails.nomineeName);
		CommonServices.setCommonData("relationshipDaught1", $scope.buyNow.personalAccident.daughterDetails.relationship);
		/*
		CommonServices.setCommonData("clientNationalityDaught1", $scope.buyNow.personalAccident.daughterDetails.clientNationality);//3712
		CommonServices.setCommonData("clientCountryDaught1", $scope.buyNow.personalAccident.daughterDetails.clientCountry);//3712
		*/
		CommonServices.setCommonData("insuredNameDaught2", $scope.buyNow.personalAccident.daughterDetails.InsuredNamed1);
		CommonServices.setCommonData("nomineeNameDaught2", $scope.buyNow.personalAccident.daughterDetails.nomineeNamedaught1);
		CommonServices.setCommonData("relationshipDaught2", $scope.buyNow.personalAccident.daughterDetails.relationshipdaught1);
		/*
		CommonServices.setCommonData("clientNationalityDaught2", $scope.buyNow.personalAccident.daughterDetails.clientNationalitydaught1);//3712
		CommonServices.setCommonData("clientCountryDaught2", $scope.buyNow.personalAccident.daughterDetails.clientCountrydaught1);//3712
		*/
		var PremiumData = {
			"userProfile": {
				"userId": username.toUpperCase(),
				"loggedInRole": "SUPERUSER"
			},
			"quote": {
				"isAddOnPA": "N",
				"quoteNumber": quoteNo,
				"policyHolderCode": showData,
				"partyDetailsList": [],
				"productCode": "PU",
				"product": "PU",
				"policyHolderName": policyHolderName.toUpperCase(),
				"policyStartDate": todaysDate,
				"policyExpiryDate": futureDateCal,
				"term": 1,
				"termUnit": "G",
				"eventDate": todaysDate,
				"coverage": "Self/Spouse/Child",
				"numChildrenToCover": noOfChildren,
				"risks": []
			}
		};
		var premDataArray = [];
		for (var i = 0; i <= 1; i++) {

			if (i == 0)//self
			{
				spouse = false;
				self = true;
				numberOfChildren = 0;
				incomeselfb = "500000";
				incomeselfc = "500000";
				$scope.relation = "SELF";
				occupation = $scope.buyNow.personalAccident.premiumCalculator.occupationself;
				bdate = $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthself;
				relationWithNominee = $scope.buyNow.personalAccident.insuredDetails.relationshipself;
				nomineeName = $scope.buyNow.personalAccident.insuredDetails.nomineeName;
				name = CommonServices.getCommonData("Name");
				/*
				clientNationality = $scope.buyNow.personalAccident.insuredDetails.clientNationality;//3712
				clientCountry = $scope.buyNow.personalAccident.insuredDetails.clientCountry;//3712
				*/
			}
			if (i == 1)//spouse
			{
				if (str == "Self/Spouse" || str == "Self/Spouse/Son/Daughter" || str == "Self/Spouse/Son" || str == "Self/Spouse/Daughter" || str == "Self/Spouse/Son1/Son2" || str == "Self/Spouse/Daughter1/Daughter2") {
					spouse = true;
					// if (SpouseEarning == "yes") {
						if ($rootScope.spEarning == "yes") {
						incomeselfc = "500000";
						incomeselfb = "500000";
					}
					else {
						incomeselfc = "250000";
						incomeselfb = "250000";
					}
					$scope.relation = "SPOUSE";
					bdate = $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthspouse;
					occupation = $scope.buyNow.personalAccident.premiumCalculator.occupationSpouse;
					name = $scope.buyNow.personalAccident.spouseDetails.InsuredName;
					relationWithNominee = $scope.buyNow.personalAccident.spouseDetails.relationship;
					nomineeName = $scope.buyNow.personalAccident.spouseDetails.nomineeName;
					/*
					clientNationality = $scope.buyNow.personalAccident.spouseDetails.clientNationality;//3712
					clientCountry = $scope.buyNow.personalAccident.spouseDetails.clientCountry;//3712
					*/
				}
				else {
					continue;
				}

			}
			var premData = {
				"coverages": [{
					"coverDetails": { "medicalCoverReq": medicalcheck }
				}],
				"riskDetails": {
					"sumInsuredForTableA": 0,
					"sumInsuredForTableB": incomeselfb,
					"sumInsuredForTableC": incomeselfc,
					"sumInsuredForTableD": 0,
					"relationWithNominee": relationWithNominee,
					"nomineeName": nomineeName,
					"monthlyIncome": "",
					"dateOfBirth": bdate,
					"relationWithPolicyHolder": $scope.relation,
					"nameOfInsuredPerson": name,
					"occupation": occupation
					/*
					,
					"clientNationality": clientNationality,//3712
					"clientCountry": clientNationality//3712
					*/
				}
			};
			premDataArray.push(premData);
		}
		var cs1 = 0, cs2 = 0, cd1 = 0, cd2 = 0;
		for (var i = 0; i < count; i++) {   				//CHILD

			var res;
			var reltionWithPh;

			if (i == 0) {
				if (counts == 1) {
					birthdate = $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthSon1;;
					insuredName = $scope.buyNow.personalAccident.sonDetails.InsuredName;
					nomineeName = $scope.buyNow.personalAccident.sonDetails.nomineeName;
					relationNominee = $scope.buyNow.personalAccident.sonDetails.relationship;
					/*
					clientNationality = $scope.buyNow.personalAccident.sonDetails.clientNationality;//3712
					clientCountry = $scope.buyNow.personalAccident.sonDetails.clientCountry;//3712
					*/
					reltionWithPh = "SON";

				}
				else if (countd == 2 || countd == 1) {
					birthdate = $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthdaughter1;
					nomineeName = $scope.buyNow.personalAccident.daughterDetails.nomineeName;
					insuredName = $scope.buyNow.personalAccident.daughterDetails.InsuredName;
					relationNominee = $scope.buyNow.personalAccident.daughterDetails.relationship;
					/*
					clientNationality = $scope.buyNow.personalAccident.daughterDetails.clientNationality;//3712
					clientCountry = $scope.buyNow.personalAccident.daughterDetails.clientCountry;//3712
					*/
					reltionWithPh = "DAUTER";
				}
			} else if (i == 1) {
				if (countd == 1) {
					birthdate = $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthdaughter1;
					nomineeName = $scope.buyNow.personalAccident.daughterDetails.nomineeName;
					insuredName = $scope.buyNow.personalAccident.daughterDetails.InsuredName;
					relationNominee = $scope.buyNow.personalAccident.daughterDetails.relationship;
					/*
					clientNationality = $scope.buyNow.personalAccident.daughterDetails.clientNationality;//3712
					clientCountry = $scope.buyNow.personalAccident.daughterDetails.clientCountry;//3712
					*/
					reltionWithPh = "DAUTER";
				} else if (countd == 2) {
					birthdate = $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthdaughter2;;
					nomineeName = $scope.buyNow.personalAccident.daughterDetails.nomineeNamedaught1;
					insuredName = $scope.buyNow.personalAccident.daughterDetails.InsuredNamed1;
					relationNominee = $scope.buyNow.personalAccident.daughterDetails.relationshipdaught1;
					/*
					clientNationality = $scope.buyNow.personalAccident.daughterDetails.clientNationality;//3712
					clientCountry = $scope.buyNow.personalAccident.daughterDetails.clientCountry;//3712
					*/
					reltionWithPh = "DAUTER";
				}
			}
			var premDataChild = {
				"coverages": [{
					"coverDetails": { "medicalCoverReq": medicalcheck }
				}],
				"riskDetails": {
					"sumInsuredForTableA": 0,
					"sumInsuredForTableB": "125000",
					"sumInsuredForTableC": "125000",
					"sumInsuredForTableD": 0,
					"relationWithNominee": relationNominee,
					"nomineeName": nomineeName,
					"monthlyIncome": "0",
					"dateOfBirth": birthdate,
					"relationWithPolicyHolder": reltionWithPh,
					"nameOfInsuredPerson": insuredName,
					"occupation": "STU",
					"anyPhysicalDefects": "N",
					"anyPreviousClaim": "N"
					/*
					,
					"clientNationality": clientNationality,//3712
					"clientCountry": clientCountry//3712
					*/
				}
			};
			premDataArray.push(premDataChild);
		}
		PremiumData.quote.risks = premDataArray;
		var PremiumDataResponse = RestServices.postService(RestServices.urlPathsNewPortal.saveQuote, PremiumData);
		//web service call for PremiumData
		PremiumDataResponse.then(
			function (response) { // success 

				CommonServices.showLoading(false);
				if (response.data.errorCode === 959) {
					CommonServices.showAlert(response.data.errorMessage);
				}
				else if (response.data.errorMessage !== undefined && response.data.errorMessage !== "") {
					CommonServices.showAlert(response.data.errorMessage);
				}
				else {
					if (response.data.userProfile.footer.errorCode === "1") {
						$scope.buyNow.personalAccident.saveQuoteRes = response.data.quote.premiumDetails;
						quoteNoSelf = response.data.quote.quoteNumber;
						netPremiumSelf = response.data.quote.premiumDetails.netPremium;
						serviceTaxSelf = response.data.quote.premiumDetails.serviceTax;
						totalPremiumSelf = response.data.quote.premiumDetails.totalPremium;
						CommonServices.setCommonData("CollectionPaymentDetails", response.data.quote);
						$rootScope.PAView = true;
						$state.go('PaymentDetails');
					}

					else
						CommonServices.showAlert("Presently our services are not available. Please try after some time");
				}

			},

			function (error) {    // failure 
				CommonServices.showLoading(false);
				RestServices.handleWebServiceError(error);
			});
	};
	if ($rootScope.resetData == true) {
		$scope.buyNow.personalAccident.daughterDetails.InsuredName = "";
		$scope.buyNow.personalAccident.daughterDetails.nomineeName = "";
		$scope.buyNow.personalAccident.daughterDetails.relationship = "";
		/*
		$scope.buyNow.personalAccident.daughterDetails.clientNationality = "";//3712
		$scope.buyNow.personalAccident.daughterDetails.clientCountry = "";//3712
		*/
		$scope.buyNow.personalAccident.daughterDetails.InsuredNamed1 = "";
		$scope.buyNow.personalAccident.daughterDetails.nomineeNamedaught1 = "";
		$scope.buyNow.personalAccident.daughterDetails.relationshipdaught1 = "";
		/*
		$scope.buyNow.personalAccident.daughterDetails.clientNationalitydaught1 = "";//3712
		$scope.buyNow.personalAccident.daughterDetails.clientCountrydaught1 = "";//3712
		*/

	}
	else {
		$scope.buyNow.personalAccident.daughterDetails.InsuredName = CommonServices.getCommonData("insuredNameDaught1");
		$scope.buyNow.personalAccident.daughterDetails.nomineeName = CommonServices.getCommonData("nomineeNameDaught1");
		$scope.buyNow.personalAccident.daughterDetails.relationship = CommonServices.getCommonData("relationshipDaught1");
		/*
		$scope.buyNow.personalAccident.daughterDetails.clientNationality = CommonServices.getCommonData("clientNationalityDaught1");//3712
		$scope.buyNow.personalAccident.daughterDetails.clientCountry = CommonServices.getCommonData("clientCountryDaught1");//3712
		*/
		$scope.buyNow.personalAccident.daughterDetails.InsuredNamed1 = CommonServices.getCommonData("insuredNameDaught2");
		$scope.buyNow.personalAccident.daughterDetails.nomineeNamedaught1 = CommonServices.getCommonData("nomineeNameDaught2");
		$scope.buyNow.personalAccident.daughterDetails.relationshipdaught1 = CommonServices.getCommonData("relationshipDaught2");
		/*
		$scope.buyNow.personalAccident.daughterDetails.clientNationalitydaught1 = CommonServices.getCommonData("clientNationalityDaught2");//3712
		$scope.buyNow.personalAccident.daughterDetails.clientCountrydaught1 = CommonServices.getCommonData("clientCountryDaught2");//3712
		*/
	}

}]);
agentApp.controller('SonDetailsCtrl', ['$scope', '$rootScope', '$location', 'RestServices', 'CommonServices', '$state', function ($scope, $rootScope, $location, RestServices, CommonServices, $state) {
	$scope.countryErr = false;//3712
	$scope.RelationshipWithNominee = CommonServices.getCommonData("RELATIONSHIP_WITH_NOMINEE");
	$scope.childNominee = CommonServices.getCommonData("childNominee");
	
	/*CR 3562 START*/
	$scope.prevNomineeDetailObj = CommonServices.getCommonData('paPolicyAutopopulatedData');
	if ($scope.prevNomineeDetailObj != undefined) {
		var son = 0;
		// angular.forEach($scope.prevNomineeDetailObj, function(obj, i) {
		// 	if (obj.isSelected && (obj.relation.toLowerCase() === 'children' || obj.relation.toLowerCase() === 'son') && obj.sex === 'M' && son === 0) {
		// 		son++;
		// 		$scope.buyNow.personalAccident.sonDetails.InsuredName = obj.name;
		// 		CommonServices.setCommonData("InsuredNameSon1", obj.name);
				
		// 	} else if (obj.isSelected && (obj.relation.toLowerCase() === 'children' || obj.relation.toLowerCase() === 'son') && obj.sex === 'M' && son === 1) {
		// 		son++;
		// 		$scope.buyNow.personalAccident.sonDetails.InsuredName1 = obj.name;
		// 		CommonServices.setCommonData("InsuredNameSon2", obj.name);
		// 	}
		// });
		if($scope.prevNomineeDetailObj.son1 != undefined){
			$scope.buyNow.personalAccident.sonDetails.InsuredName = $scope.prevNomineeDetailObj.son1.name;
			CommonServices.setCommonData("InsuredNameSon1", $scope.prevNomineeDetailObj.son1.name);
		}
		if($scope.prevNomineeDetailObj.son2 != undefined){
			$scope.buyNow.personalAccident.sonDetails.InsuredName1 = $scope.prevNomineeDetailObj.son2.name;
			CommonServices.setCommonData("InsuredNameSon2", $scope.prevNomineeDetailObj.son2.name);
		}
	}
	/*CR 3562 END*/

	/*CR 3712 starts ///
	$scope.isNonIndia = false;
	$scope.isNonIndiaD1 = false;
	$scope.onNationalityChange = function(){
		$scope.buyNow.personalAccident.sonDetails.clientCountry = '';
		if($scope.buyNow.personalAccident.sonDetails.clientNationality == "NonIndian"){
			$scope.isNonIndia = true;
		}
		else{
			$scope.isNonIndia = false;
		}
	}
	$scope.onNationalityChangeD1 = function(){
		$scope.buyNow.personalAccident.sonDetails.clientCountrySon1 = '';
		if($scope.buyNow.personalAccident.sonDetails.clientNationalitySon1 == "NonIndian"){
			$scope.isNonIndiaD1 = true;
		}
		else{
			$scope.isNonIndiaD1 = false;
		}
	}
	// CR_3712 ends*/
	$scope.buyNow.personalAccident.sonDetails = {};
	if (spouse == true) {
		$scope.slideshowModal = true;
		$scope.slideshowModal1 = true;
		$scope.slideshowModal2 = true;
		if (countd == 1 && counts == 1) {
			$scope.slideshowModal3 = true;
			$scope.slideshowModal4 = true;
			$scope.daughterDetails = true;
			$scope.sonDetails = true;
			$scope.SaveCalculatePremiumModal2as2 = true;
			$scope.ChildDetailsScreen = function () {
				CommonServices.setCommonData("InsuredNameSon1", $scope.buyNow.personalAccident.sonDetails.InsuredName);
				CommonServices.setCommonData("nomineeNameSon1", $scope.buyNow.personalAccident.sonDetails.nomineeName);
				CommonServices.setCommonData("relationshipSon1", $scope.buyNow.personalAccident.sonDetails.relationship);
				/*
				CommonServices.setCommonData("clientNationalitySon1", $scope.buyNow.personalAccident.sonDetails.clientNationality);//3712
				CommonServices.setCommonData("clientCountrySon1", $scope.buyNow.personalAccident.sonDetails.clientCountry);//3712
				*/
				$state.go('DaughterDetails');
			};
			$scope.back = function () {
				$rootScope.resetData = false;
				$state.go('SpouseDetails');
			};
		} else if (countd == 2 && counts == 0) {
			$scope.slideshowModal4 = true;
			$scope.daughterDetails = true;
		} else if (counts == 2 && countd == 0) {
			$scope.slideshowModal3 = true;
			$scope.sonDetails = true;
			$scope.SecondSon = true;
			$scope.SaveCalculatePremiumModal2bs1 = true;
			$scope.back = function () {
				$rootScope.resetData = false;
				$state.go('SpouseDetails');
			};
		} else if (counts == 1) {
			$scope.SaveCalculatePremiumModal2as1 = true;
			$scope.sonDetails = true;
			$scope.isRequired = false;
			$scope.ChildDetailsScreen = function () {
				CommonServices.setCommonData("InsuredNameSon1", $scope.buyNow.personalAccident.sonDetails.InsuredName);
				CommonServices.setCommonData("nomineeNameSon1", $scope.buyNow.personalAccident.sonDetails.nomineeName);
				CommonServices.setCommonData("relationshipSon1", $scope.buyNow.personalAccident.sonDetails.relationship);
				/*
				CommonServices.setCommonData("clientNationalitySon1", $scope.buyNow.personalAccident.sonDetails.clientNationality);//3712
				CommonServices.setCommonData("clientCountrySon1", $scope.buyNow.personalAccident.sonDetails.clientCountry);//3712
				*/
				$state.go('PaymentDetails');
			};
			$scope.back = function () {
				$rootScope.resetData = false;
				$state.go('SpouseDetails');
			};
		} else if (countd == 1) {
			$scope.slideshowModal4 = true;
			$scope.daughterDetails = true;
		} else {
			$scope.SaveCalculatePremiumModal1 = true;
		}
	} else if (spouse == false) {
		$scope.slideshowModal = true;
		$scope.slideshowModal1 = true;
		$scope.slideshowModal2 = false;
		if (countd == 1 && counts == 1) {
			$scope.slideshowModal3 = true;
			$scope.slideshowModal4 = true;
			$scope.daughterDetails = true;
			$scope.sonDetails = true;
			$scope.SaveCalculatePremiumModal2as2 = true;
			$scope.ChildDetailsScreen = function () {
				CommonServices.setCommonData("InsuredNameSon1", $scope.buyNow.personalAccident.sonDetails.InsuredName);
				CommonServices.setCommonData("nomineeNameSon1", $scope.buyNow.personalAccident.sonDetails.nomineeName);
				CommonServices.setCommonData("relationshipSon1", $scope.buyNow.personalAccident.sonDetails.relationship);
				/*
				CommonServices.setCommonData("clientNationalitySon1", $scope.buyNow.personalAccident.sonDetails.clientNationality);//3712
				CommonServices.setCommonData("clientCountrySon1", $scope.buyNow.personalAccident.sonDetails.clientCountry);//3712
				*/
				$state.go('DaughterDetails');
			};
			$scope.back = function () {
				$rootScope.resetData = false;
				$rootScope.backData = "insuredDetailsPage";
				$state.go('InsuredDetails');
			};
		} else if (countd == 2 && counts == 0) {
			$scope.slideshowModal4 = true;
			$scope.daughterDetails = true;
			$scope.SaveCalculatePremiumModal2b = true;
		} else if (countd == 0 && counts == 2) {
			$scope.slideshowModal3 = true;
			$scope.sonDetails = true;
			$scope.SaveCalculatePremiumModal2bs1 = true;
			$scope.SecondSon = true;
			$scope.back = function () {
				$rootScope.resetData = false;
				$rootScope.backData = "insuredDetailsPage";
				$state.go('InsuredDetails');
			};
		} else if (counts == 1) {
			$scope.SaveCalculatePremiumModal2as1 = true;
			$scope.slideshowModal3 = true;
			$scope.sonDetails = true;
			$scope.isRequired = false;
			$scope.ChildDetailsScreen = function () {
				CommonServices.setCommonData("InsuredNameSon1", $scope.buyNow.personalAccident.sonDetails.InsuredName);
				CommonServices.setCommonData("nomineeNameSon1", $scope.buyNow.personalAccident.sonDetails.nomineeName);
				CommonServices.setCommonData("relationshipSon1", $scope.buyNow.personalAccident.sonDetails.relationship);
				/*
				CommonServices.setCommonData("clientNationalitySon1", $scope.buyNow.personalAccident.sonDetails.clientNationality);//3712
				CommonServices.setCommonData("clientCountrySon1", $scope.buyNow.personalAccident.sonDetails.clientCountry);//3712
				*/
				$state.go('PaymentDetails');
			};
			$scope.back = function () {
				$rootScope.resetData = false;
				$rootScope.backData = "insuredDetailsPage";
				$state.go('InsuredDetails');
			};
		} else if (countd == 1) {
			$scope.slideshowModal4 = true;
		} else {
			$scope.slideshowModal = false;
			$scope.SaveCalculatePremiumModal = true;
		}
	}


	$scope.DaughterDetails = function () {
		$state.go('DaughterDetails');
	};
	$scope.SpouseDetails = function () {
		$state.go('SpouseDetails');
	};
	$scope.SonDetails = function () {
		$state.go('SonDetails');
	};
	$scope.InsuredDetailsScreen = function () {
		$state.go('InsuredDetails');
	};

	var username = CommonServices.getCommonData("userCode");
	var partyCodeSelf = CommonServices.getCommonData("partycode");
	var policyHolderName = CommonServices.getCommonData("Name");
	$scope.calculatePremiumSon = function () {
		CommonServices.setCommonData("InsuredNameSon1", $scope.buyNow.personalAccident.sonDetails.InsuredName);
		CommonServices.setCommonData("nomineeNameSon1", $scope.buyNow.personalAccident.sonDetails.nomineeName);
		CommonServices.setCommonData("relationshipSon1", $scope.buyNow.personalAccident.sonDetails.relationship);
		/*
		CommonServices.setCommonData("clientNationalitySon1", $scope.buyNow.personalAccident.sonDetails.clientNationality);//3712
		CommonServices.setCommonData("clientCountrySon1", $scope.buyNow.personalAccident.sonDetails.clientCountry);//3712
		*/
		CommonServices.setCommonData("InsuredNameSon2", $scope.buyNow.personalAccident.sonDetails.InsuredName1);
		CommonServices.setCommonData("nomineeNameSon2", $scope.buyNow.personalAccident.sonDetails.nomineeName1);
		CommonServices.setCommonData("relationshipSon2", $scope.buyNow.personalAccident.sonDetails.relationshipson2);
		/*
		CommonServices.setCommonData("clientNationalitySon2", $scope.buyNow.personalAccident.sonDetails.clientNationalitySon1);//3712
		CommonServices.setCommonData("clientCountrySon2", $scope.buyNow.personalAccident.sonDetails.clientCountrySon1);//3712
		*/
		var PremiumData = {
			"userProfile": {
				"userId": username.toUpperCase(),
				"loggedInRole": "SUPERUSER"
			},
			"quote": {
				"isAddOnPA": "N",
				"quoteNumber": quoteNo,
				"policyHolderCode": showData,
				"partyDetailsList": [],
				"productCode": "PU",
				"product": "PU",
				"policyHolderName": policyHolderName.toUpperCase(),
				"policyStartDate": todaysDate,
				"policyExpiryDate": futureDateCal,
				"term": 1,
				"termUnit": "G",
				"eventDate": todaysDate,
				"coverage": "Self/Spouse/Child",
				"numChildrenToCover": noOfChildren,
				"risks": []
			}
		};
		var premDataArray = [];
		for (var i = 0; i <= 1; i++) {

			if (i == 0)//self
			{
				spouse = false;
				self = true;
				numberOfChildren = 0;
				incomeselfb = "500000";
				incomeselfc = "500000";
				$scope.relation = "SELF";
				occupation = $scope.buyNow.personalAccident.premiumCalculator.occupationself;
				bdate = $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthself;
				relationWithNominee = $scope.buyNow.personalAccident.insuredDetails.relationshipself;
				nomineeName = $scope.buyNow.personalAccident.insuredDetails.nomineeName;
				/*
				clientNationality = $scope.buyNow.personalAccident.insuredDetails.clientNationality;//3712
				clientCountry = $scope.buyNow.personalAccident.insuredDetails.clientCountry;//3712
				*/
				name = CommonServices.getCommonData("Name");
			}
			if (i == 1)//spouse
			{
				if (str == "Self/Spouse" || str == "Self/Spouse/Son/Daughter" || str == "Self/Spouse/Son" || str == "Self/Spouse/Daughter" || str == "Self/Spouse/Son1/Son2" || str == "Self/Spouse/Daughter1/Daughter2") {
					spouse = true;
					// if (SpouseEarning == "yes") {
						if ($rootScope.spEarning == "yes") {
						incomeselfc = "500000";
						incomeselfb = "500000";
					}
					else {
						incomeselfc = "250000";
						incomeselfb = "250000";
					}
					$scope.relation = "SPOUSE";
					bdate = $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthspouse;
					occupation = $scope.buyNow.personalAccident.premiumCalculator.occupationSpouse;
					name = $scope.buyNow.personalAccident.spouseDetails.InsuredName;
					relationWithNominee = $scope.buyNow.personalAccident.spouseDetails.relationship;
					nomineeName = $scope.buyNow.personalAccident.spouseDetails.nomineeName;
					/*
					clientNationality = $scope.buyNow.personalAccident.insuredDetails.clientNationality;//3712
					clientCountry = $scope.buyNow.personalAccident.insuredDetails.clientCountry;//3712
					*/
				}
				else {
					continue;
				}

			}
			var premData = {
				"coverages": [{
					"coverDetails": { "medicalCoverReq": medicalcheck }
				}],
				"riskDetails": {
					"sumInsuredForTableA": 0,
					"sumInsuredForTableB": incomeselfb,
					"sumInsuredForTableC": incomeselfc,
					"sumInsuredForTableD": 0,
					"relationWithNominee": relationWithNominee,
					"nomineeName": nomineeName,
					"monthlyIncome": "",
					"dateOfBirth": bdate,
					"relationWithPolicyHolder": $scope.relation,
					"nameOfInsuredPerson": name,
					"occupation": occupation
					/*
					,
					"clientNationality": clientNationality,//3712
					"clientCountry": clientCountry//3712
					*/
				}
			};
			premDataArray.push(premData);
		}
		var cs1 = 0, cs2 = 0, cd1 = 0, cd2 = 0;
		for (var i = 0; i < count; i++) {   				//CHILD

			var res, bdate;
			/*if($sumInsuredB==true)
			{
			incomeselfb="250000";
			incomeselfc=0;
			}
			if($sumInsuredB==false)
			{
			incomeselfc="125000";
			incomeselfb=0;
			}	*/
			if (i == 0) {
				birthdate = $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthSon1;
				nomineeName = $scope.buyNow.personalAccident.sonDetails.nomineeName;
				insuredName = $scope.buyNow.personalAccident.sonDetails.InsuredName;
				relationNominee = $scope.buyNow.personalAccident.sonDetails.relationship;
				/*
				clientNationality = $scope.buyNow.personalAccident.sonDetails.clientNationality;//3712
				clientCountry = $scope.buyNow.personalAccident.sonDetails.clientCountry;//3712
				*/
			} else if (i == 1) {
				birthdate = $scope.buyNow.personalAccident.premiumCalculator.dateOfBirthSon2;
				nomineeName = $scope.buyNow.personalAccident.sonDetails.nomineeName1;
				insuredName = $scope.buyNow.personalAccident.sonDetails.InsuredName1;
				relationNominee = $scope.buyNow.personalAccident.sonDetails.relationshipson2;
				/*
				clientNationality = $scope.buyNow.personalAccident.sonDetails.clientNationalitySon1;//3712
				clientCountry = $scope.buyNow.personalAccident.sonDetails.clientCountrySon1;//3712
				*/
			}
			var premDataChild = {
				"coverages": [{
					"coverDetails": { "medicalCoverReq": medicalcheck }
				}],
				"riskDetails": {
					"sumInsuredForTableA": 0,
					"sumInsuredForTableB": "125000",
					"sumInsuredForTableC": "125000",
					"sumInsuredForTableD": 0,
					"relationWithNominee": relationNominee,
					"nomineeName": nomineeName,
					"monthlyIncome": "0",
					"dateOfBirth": birthdate,
					"relationWithPolicyHolder": "SON",
					"nameOfInsuredPerson": insuredName,
					"occupation": "STU",
					"anyPhysicalDefects": "N",
					"anyPreviousClaim": "N"
					/*
					,
					"clientNationality": clientNationality,//3712
					"clientCountry": clientCountry//3712
					*/
				}
			};
			premDataArray.push(premDataChild);
		}
		PremiumData.quote.risks = premDataArray;
		var PremiumDataResponse = RestServices.postService(RestServices.urlPathsNewPortal.saveQuote, PremiumData);
		//web service call for PremiumData
		PremiumDataResponse.then(
			function (response) { // success 
				CommonServices.showLoading(false);
				if (response.data.errorCode === 959) {
					CommonServices.showAlert(response.data.errorMessage);
				}
				else if (response.data.errorMessage !== undefined && response.data.errorMessage !== "") {
					CommonServices.showAlert(response.data.errorMessage);
				}
				else {
					if (response.data.userProfile.footer.errorCode === "1") {
						$scope.buyNow.personalAccident.saveQuoteRes = response.data.quote.premiumDetails;
						quoteNoSelf = response.data.quote.quoteNumber;
						netPremiumSelf = response.data.quote.premiumDetails.netPremium;
						serviceTaxSelf = response.data.quote.premiumDetails.serviceTax;
						totalPremiumSelf = response.data.quote.premiumDetails.totalPremium;
						CommonServices.setCommonData("CollectionPaymentDetails", response.data.quote);
						$rootScope.PAView = true;
						$state.go('PaymentDetails');
					}

					else
						CommonServices.showAlert("Presently our services are not available. Please try after some time");
				}

			},
			function (error) {    // failure 
				CommonServices.showLoading(false);
				RestServices.handleWebServiceError(error);
			});
	};
	if ($rootScope.resetData == true) {
		$scope.buyNow.personalAccident.sonDetails.InsuredName = "";
		$scope.buyNow.personalAccident.sonDetails.nomineeName = "";
		$scope.buyNow.personalAccident.sonDetails.relationship = "";
		/*
		$scope.buyNow.personalAccident.sonDetails.clientNationality = "";//3712
		$scope.buyNow.personalAccident.sonDetails.clientCountry = "";//3712
		*/
		$scope.buyNow.personalAccident.sonDetails.InsuredName1 = "";
		$scope.buyNow.personalAccident.sonDetails.nomineeName1 = "";
		$scope.buyNow.personalAccident.sonDetails.relationshipson2 = "";
		/*
		$scope.buyNow.personalAccident.sonDetails.clientNationalitySon1 = "";//3712
		$scope.buyNow.personalAccident.sonDetails.clientCountrySon1 = "";//3712
		*/
	}
	else {
		$scope.buyNow.personalAccident.sonDetails.InsuredName = CommonServices.getCommonData("InsuredNameSon1");
		$scope.buyNow.personalAccident.sonDetails.nomineeName = CommonServices.getCommonData("nomineeNameSon1");
		$scope.buyNow.personalAccident.sonDetails.relationship = CommonServices.getCommonData("relationshipSon1");
		/*
		$scope.buyNow.personalAccident.sonDetails.clientNationality = CommonServices.getCommonData("clientNationalitySon1");//3712
		$scope.buyNow.personalAccident.sonDetails.clientCountry = CommonServices.getCommonData("clientCountrySon1");//3712
		*/
		$scope.buyNow.personalAccident.sonDetails.InsuredName1 = CommonServices.getCommonData("InsuredNameSon2");
		$scope.buyNow.personalAccident.sonDetails.nomineeName1 = CommonServices.getCommonData("nomineeNameSon2");
		$scope.buyNow.personalAccident.sonDetails.relationshipson2 = CommonServices.getCommonData("relationshipSon2");
		/*
		$scope.buyNow.personalAccident.sonDetails.clientNationalitySon1 = CommonServices.getCommonData("clientNationalitySon2");//3712
		$scope.buyNow.personalAccident.sonDetails.clientCountrySon1 = CommonServices.getCommonData("clientCountrySon2");//3712
		*/
	}
}]);
agentApp.controller('PaymentDetailsCtrl', ['$scope', '$rootScope', '$location', 'RestServices', 'CommonServices', '$state','CartServices', function ($scope, $rootScope, $location, RestServices, CommonServices, $state,CartServices) {
	$scope.quoteNumber = quoteNoSelf;
	$scope.grossPremium = totalPremiumSelf;
	$scope.serviceTax = serviceTaxSelf;
	$scope.netPremium = netPremiumSelf;
	$scope.countOfson = counts;
	$scope.countOfdaughter = countd;
	$scope.spouse = spouse;
	$scope.startDate = todaysDate;
	$scope.endDate = futureDateCal;
	$scope.reviewSumaaryPA = $scope.buyNow.personalAccident;

	/**CR690 Start**/
	$rootScope.panmodalOpen = false;

	var panCardDetails = {
		"quoteNumber": $scope.quoteNumber,
		"policyHolderCode": showData
	}
	CommonServices.setCommonData("partyCode", showData);
	CommonServices.setCommonData("panCardData", panCardDetails);
	/**CR690 End**/

	/*CR 3562 START*/
	$scope.prevNomineeDetailObj = CommonServices.getCommonData('paPolicyAutopopulatedData');
	if ($scope.prevNomineeDetailObj != undefined) {
		var son = 0, d = 0;
		// angular.forEach($scope.prevNomineeDetailObj, function(obj, i) {
			if ($scope.prevNomineeDetailObj.spouse!=undefined) {
				$scope.reviewSumaaryPA.spouseDetails.InsuredName = $scope.prevNomineeDetailObj.spouse.name;
			}
			if ($scope.prevNomineeDetailObj.son1!=undefined) {
				son++;
				$scope.reviewSumaaryPA.sonDetails.InsuredName = $scope.prevNomineeDetailObj.son1.name;
			}
			if ($scope.prevNomineeDetailObj.son2 !=undefined) {
				son++;
				$scope.reviewSumaaryPA.sonDetails.InsuredName1 = $scope.prevNomineeDetailObj.son2.name;
			}
			if ($scope.prevNomineeDetailObj.daughter1 !=undefined) {
				d++;
				$scope.reviewSumaaryPA.daughterDetails.InsuredName = $scope.prevNomineeDetailObj.daughter1.name;
			}
			if ($scope.prevNomineeDetailObj.daughter2 !=undefined) {
				d++;
				$scope.reviewSumaaryPA.daughterDetails.InsuredNamed1 = $scope.prevNomineeDetailObj.daughter2.name;
			}
		// });
	}
	/*CR 3562 END*/

	$scope.InsuredDetailsScreen = function () {
		CommonServices.setCommonData("redirectInsuredDetails", true);
		CommonServices.setCommonData("existingCustomer", "checkedBoxTrue");
		$state.go('InsuredDetails');
	}
	$scope.DaughterDetails = function () {
		$state.go('DaughterDetails');
	};
	$scope.SpouseDetails = function () {
		$state.go('SpouseDetails');
	};
	$scope.SonDetails = function () {
		$state.go('SonDetails');
	};

	if (spouse == true) {
		if (countd == 1 && counts == 1) {
			$scope.back = function () {
				$rootScope.resetData = false;
				$state.go('DaughterDetails');
			};
		} else if (countd == 2 && counts == 0) {
			$scope.back = function () {
				$rootScope.resetData = false;
				$state.go('DaughterDetails');
			};
		} else if (counts == 2 && countd == 0) {
			$scope.back = function () {
				$rootScope.resetData = false;
				$state.go('SonDetails');
			};
		} else if (counts == 1) {
			$scope.back = function () {
				$rootScope.resetData = false;
				$state.go('SonDetails');
			};
		} else if (countd == 1) {
			$scope.back = function () {
				$rootScope.resetData = false;
				$state.go('DaughterDetails');
			};
		} else {
			$scope.back = function () {
				$rootScope.resetData = false;
				$state.go('SpouseDetails');
			};
		}
	} else if (spouse == false) {

		if (countd == 1 && counts == 1) {
			$scope.back = function () {
				$rootScope.resetData = false;
				$state.go('DaughterDetails');
			};
		} else if (countd == 2 && counts == 0) {
			$scope.back = function () {
				$rootScope.resetData = false;
				$state.go('DaughterDetails');
			};
		} else if (countd == 0 && counts == 2) {
			$scope.back = function () {
				$rootScope.resetData = false;
				$state.go('SonDetails');
			};
		} else if (counts == 1) {
			$scope.back = function () {
				$rootScope.resetData = false;
				$state.go('SonDetails');
			};
		} else if (countd == 1) {
			$scope.back = function () {
				$rootScope.resetData = false;
				$state.go('DaughterDetails');
			};
		} else {
			$scope.back = function () {
				$rootScope.backData = "insuredDetailsPage";
				$rootScope.resetData = false;
				$state.go('InsuredDetails');
			};
		}
	}
	var username = CommonServices.getCommonData("userCode");

	$scope.approvePay = function (type = '') {
		var PASystemDate = CommonServices.getCommonData("serverDate");
		var arr = PASystemDate.split('/');
		messageSystemDate = arr[1] + '/' + arr[0] + '/' + arr[2]; //mm/dd/yyyy 
		CommonServices.setCommonData("addToCart", type); // CR3546
		
		var msg = "Do you wish to proceed with approval of quotation? Once Approved, no more changes will be made available on your quotation. Your payment should be made by " + PASystemDate + " 23:59:59.. Please confirm";
		CommonServices.messageModal('info', msg, false, 'Cancel', 'Confirm', function () {
			exitFunction(2);
		}, function () {
			exitFunction(1);
		}, 'Alert');

		// if (CommonServices.deviceType !== "NA")
		// 	navigator.notification.confirm("Do you wish to proceed with approval of quotation? Once Approved, no more changes will be made available on your quotation. Your payment should be made by " + PASystemDate + " 23:59:59. Please confirm.", exitFunction, "Alert", ["Confirm", "Cancel"]);
		// else {
		// 	var approvePayment;
		// 	approvePayment = confirm("Do you wish to proceed with approval of quotation? Once Approved, no more changes will be made available on your quotation. Your payment should be made by " + PASystemDate + " 23:59:59. Please confirm.");
		// 	if (approvePayment === true) {
		// 		exitFunction(1);
		// 	}
		// }
	}

	$scope.buyLater = function () {

		var msg = "Are you sure you want to navigate back to home screen ? All the entered data will be lost";
		CommonServices.messageModal('info', msg, false, 'Cancel', 'Confirm', function () {
			goBack(2);
		}, function () {
			goBack(1);
		}, 'Alert');
		// if (CommonServices.deviceType !== "NA")
		// 	navigator.notification.confirm("Are you sure you want to navigate back to home screen ? All the entered data will be lost", goBack, "Alert", ["Ok", "Cancel"]);
		// else {
		// 	var approvePayment;
		// 	approvePayment = confirm("Are you sure you want to navigate back to home screen ? All the entered data will be lost");
		// 	if (approvePayment === true) {
		// 		goBack(1);
		// 	}
		// }
	}
	function goBack(button) {
		if (button == 1) {
			$state.go("home");
		}
	}
	var username = CommonServices.getCommonData("userCode");

	function exitFunction(button) {
		if (button == 1) {
			var approvePayData = {
				"userProfile":
				{
					"userId": username.toUpperCase(),
					"loggedInRole": "SUPERUSER", "uiFlow": "NON_CUSTOMER"
				},
				"quote":
				{
					"quoteNumber": quoteNo,
					"policyType": null,
					"productCode": "PU"
				}
			};
			if (CommonServices.getCommonData("addToCart")==='cart') { // CR3546
				CartServices.approveAndAddToCart(approvePayData, "PU");
				return;
			}

			var approvePayResponse = RestServices.postService(RestServices.urlPathsNewPortal.approveRenewedQuote, approvePayData);
			approvePayResponse.then(
				function (response) { // success 

					CommonServices.showLoading(false);
					if (response.data.userProfile.footer.errorDescription.trim() === "Proposal Approved") {
						//Will navigate to billdesk page.

						// if (CommonServices.deviceType !== "NA")
						// 	navigator.notification.confirm(response.data.userProfile.footer.errorDescription, approvePayExitFunction, "Alert", ["Ok"]);
						// else {
						// 	var approvePayment;
						// 	approvePayment = confirm(response.data.userProfile.footer.errorDescription);
						// 	if (approvePayment === true) {
						// 		approvePayExitFunction(1);
						// 	}
						// }

						var msg = response.data.userProfile.footer.errorDescription;
						CommonServices.messageModal('info', msg, false, '', 'Ok', function () {}, function () { approvePayExitFunction(1);}, 'Alert');
					} else {
						/**CR690 Start**/
						if (response.data.userProfile.footer.errorCode === "224541") {
							$rootScope.panmodalOpen = true;
							CommonServices.setCommonData("setPanMsg", response.data.userProfile.footer.errorDescription);
						}
						/**CR690 End**/
						else {
							CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
						}
					}
				},
				function (error) { // failure
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
				});
		}
	}

	function approvePayExitFunction(button) {
		$state.go("collectionForm");
	}
	$scope.downloadDoc = function () {
		$scope.documentData = JSON.stringify({ "alfrescoInput": { "typeOfContent": "Documents", "productName": "PU", "process": "PaymentSummary", "language": "English", "channel": "AGENT" } });
		productContentResponse = RestServices.postService(RestServices.urlPathsNewPortal.getContent, $scope.documentData);
		productContentResponse.then(
			function (response) {
				CommonServices.showLoading(false);
				$scope.content = response.data.contentDataList;
			},
			function (error) {
				CommonServices.showLoading(false);
				RestServices.headerWithoutToken = false;
			});
	}
	$scope.downloadDoc();

	$scope.download = function (url, docName) {

		try {
			window.appRootDirName = "NIAAgentDoc";
			window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, CommonServices.gotFS, CommonServices.fail);

			var fileTransfer = new FileTransfer();
			var url = url;
			var filePath;
			var docName = docName;


			if (navigator.userAgent.match(/iPhone|iPad|iPod/i)) {
				filePath = window.appRootDir.nativeURL + docName;
			}
			else if (navigator.userAgent.match(/Android/i)) {

				filePath = fileSystem.root.toURL() + "NIAAgentDoc/" + docName;
			}
			else {
				filePath = false;
			}
			CommonServices.showLoading(false);
			if (navigator.userAgent.match(/iPhone|iPad|iPod/i)) {
				window.open(url, '_system', 'location=no');
				return;
			}
			fileTransfer.download(url, filePath, function (theFile) {
				if (navigator.userAgent.match(/iPhone|iPad|iPod/i)) {
					window.open(url, '_system', 'location=no');
				}
				else if (navigator.userAgent.match(/Android/i)) {
					window.open(filePath, '_system', 'location=no');
				}
			},
				function (error) {

					CommonServices.showAlert("Download not successful, please try again after some time");
					CommonServices.showLoading(false);
				},
				true
			);

		} catch (err) {

			$scope.counter = false;
			CommonServices.showLoading(false);
			CommonServices.showAlert("Please insert SD Card to download documents");
		} finally {

		}

	}


	$scope.buyNow = false;
	$scope.buyNow = function () {
		$scope.buyNow = true;
	}

	$scope.closePopup = function () {
		$scope.PAViewBreakShow = false;
	}
	$scope.viewBreakup = function () {
		$scope.PAViewBreakShow = true;
	}
	/* for accordian ----------------------*/
	var acc = document.getElementsByClassName("accord");
	var i;

	for (i = 0; i < acc.length; i++) {
		acc[i].onclick = function () {
			this.classList.toggle("active");
			var panel = this.nextElementSibling;
			if (panel.style.display === "block") {
				panel.style.display = "none";
			} else {
				panel.style.display = "block";
			}
		}
	}
	/* accordian ends ----------------------*/


}]);
