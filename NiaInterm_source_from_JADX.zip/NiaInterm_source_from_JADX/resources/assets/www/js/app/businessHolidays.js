agentApp.controller('businessHolidaysCtrl', ['$scope', 'RestServices', 'CommonServices', '$rootScope', function ($scope, RestServices, CommonServices, $rootScope) {

	$scope.bodyHeight = window.innerHeight + 'px';
	$rootScope.travelData = {};
	$rootScope.backFlag = "";

}]);

agentApp.controller('travelDetailsCtrl', ['$scope', 'RestServices', 'CommonServices', '$state', '$rootScope', function ($scope, RestServices, CommonServices, $state, $rootScope) {


	var mydateStr = new Date();
	var mynewdateFrom = "";
	if (mydateStr != undefined) {
		mynewdateFrom = new Date(mydateStr);
	}
	else {
		mynewdateFrom = new Date();
	}

	var enableCalendarfrom = getFormattedDate(mynewdateFrom);
	/**Leave Date To**/
	var enableStartCalendarTo = new Date(new Date().setFullYear(mynewdateFrom.getFullYear()));
	enableStartCalendarTo = new Date(enableStartCalendarTo.setDate(enableStartCalendarTo.getDate() + 90));
	enableStartCalendarTo = getFormattedDate(enableStartCalendarTo);
	/**Leave Date To**/
	/**Return Date To**/
	var enableReturnCalendarTo = new Date(new Date().setFullYear(mynewdateFrom.getFullYear()));
	enableReturnCalendarTo = new Date(enableReturnCalendarTo.setDate(enableReturnCalendarTo.getDate() + 269));
	enableReturnCalendarTo = getFormattedDate(enableReturnCalendarTo);
	/**Return Date To**/


	$('#leaveDate').loadCalendar({
		'enableDateRange': true,
		'enableCalendarFrom': enableCalendarfrom,
		'enableCalendarTo': enableStartCalendarTo
	});

	$('#returnDate').loadCalendar({
		'enableDateRange': true,
		'enableCalendarFrom': enableCalendarfrom,
		'enableCalendarTo': enableReturnCalendarTo
	});




	/**Date of Birth From 60years from policy start date**/
	var dateOfBirthfrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 62));
	dateOfBirthfrom = new Date(dateOfBirthfrom.setDate(dateOfBirthfrom.getDate() + 1));
	dateOfBirthfrom = getFormattedDate(dateOfBirthfrom);
	/**Date of Birth From 60years from policy start date**/
	/**Date of Birth To 6months from policy start date**/
	var dateOfBirthTo = new Date(new Date().setFullYear(mynewdateFrom.getFullYear()));
	//dateOfBirthTo = new Date(dateOfBirthTo.setMonth(mynewdateFrom.getMonth() - 6));
	dateOfBirthTo = new Date(dateOfBirthTo.setDate(dateOfBirthTo.getDate()));
	dateOfBirthTo = getFormattedDate(dateOfBirthTo);
	/**Date of Birth To 6months from policy start date**/


	$('#dateOfBirth').loadCalendar({
		'enableDateRange': true,
		'enableCalendarFrom': dateOfBirthfrom,
		'enableCalendarTo': dateOfBirthTo
	});

	$scope.dateOfBirth = function () {
		$("#dateOfBirth").loadCalendar({
			'enableDateRange': true,
			'enableCalendarFrom': dateOfBirthfrom,
			'enableCalendarTo': dateOfBirthTo
		});
		return true;
	};
	$scope.planObj = "";

	$scope.travelDetailsObj = {
		dayDiffValid: false,
		travelPlan: false,
		travelPlanShow: false,
		dateOfBirthErr: false,
		getTravelPlanDetailsFunc: function () {

			if (this.travelPurpose !== undefined && this.destination !== undefined) {
				this.travelPlan = true;
				var planData = {
					"userProfile": { "userId": CommonServices.getCommonData("userId"), "loggedInRole": "SUPERUSER" },
					"productBenefitCoverage": { "productCode": "BH", "travelPurpose": this.travelPurpose, "travelDestination": this.destination }
				};

				var getTravelPlanDetails = RestServices.postService(RestServices.urlPathsNewPortal.getTravelPlanDetails, planData);
				getTravelPlanDetails.then(
					function (response) { // success	

						CommonServices.showLoading(false);
						if (response.data.productBenefitCoverageList !== undefined) {
							if (response.data.productBenefitCoverageList.length > 0) {
								$scope.planObj = "";
								$scope.planObj = response.data.productBenefitCoverageList;
								$scope.breakup = {
									"coverageCompemsation": response.data.productBenefitCoverageList
								}
								angular.extend($rootScope.travelData, $scope.breakup);
							}
							else {
								CommonServices.showAlert(response.data.erroMessage);
							}
						}

					},
					function (error) { // failure
						CommonServices.showLoading(false);
						RestServices.handleWebServiceError(error);
					});
			}

		},
		travelPurposeRadio: function (data) {
			//this.travelPlan = true;
			this.getTravelPlanDetailsFunc();
		},
		destinationRadio: function () {
			this.getTravelPlanDetailsFunc();
		},
		leaveDateFunc: function () {

			if (this.dateOfBirth !== undefined && this.dateOfBirth !== "") {
				this.dateOfBirthFunc();
			}

			if (this.returnDate !== "" || this.returnDate !== undefined) {
				this.dateCompare(this.leaveDate, this.returnDate);
			}
			else {
				this.dayDifference = "";
			}
		},
		returnDateFunc: function () {

			if (this.leaveDate !== "" || this.leaveDate !== undefined) {
				this.dateCompare(this.leaveDate, this.returnDate);
			}

		},
		dateCompare: function (leaveDate, returnDate) {
			if (leaveDate !== undefined && returnDate !== undefined) {
				var leaveDateComp = leaveDate;
				var drr = leaveDateComp.split('/');
				leaveDateComp = drr[1] + '/' + drr[0] + '/' + drr[2]; //mm/dd/yyyy

				var returnDateComp = returnDate;
				var srr = returnDateComp.split('/');
				returnDateComp = srr[1] + '/' + srr[0] + '/' + srr[2]; //mm/dd/yyyy

				leaveDateComp = new Date(leaveDateComp);
				returnDateComp = new Date(returnDateComp);

				this.dayDiff(leaveDate, returnDate);

			}

		},
		dayDiff: function (firstDate, secondDate) {

			var dt1 = firstDate.split('/'),
				dt2 = secondDate.split('/'),
				one = new Date(dt1[2], (dt1[1] - 1), dt1[0]),
				two = new Date(dt2[2], (dt2[1] - 1), dt2[0]);

			var millisecondsPerDay = 1000 * 60 * 60 * 24;
			var millisBetween = two.getTime() - one.getTime();
			this.dayDifference = (millisBetween / millisecondsPerDay) + 1;
			this.dayDifference = parseInt(this.dayDifference);

			if (this.dayDifference < 2 || this.dayDifference > 180) {

				this.dayDiffValid = false;
			}
			else {
				this.dayDiffValid = true;
			}

		},
		dateOfBirthFunc: function () {

			var dt1 = this.dateOfBirth.split('/'),
				birthDateComp = dt1[1] + '/' + dt1[0] + '/' + dt1[2], //mm/dd/yyyy
				dt2 = this.leaveDate.split('/'),
				leaveDateComp = dt2[1] + '/' + dt2[0] + '/' + dt2[2],
				dt3 = this.leaveDate.split('/'),
				leaveMonthComp = dt3[1] + '/' + dt3[0] + '/' + dt3[2]; //mm/dd/yyyy

			birthDateComp = new Date(birthDateComp);
			leaveDateComp = new Date(leaveDateComp);
			leaveMonthComp = new Date(leaveMonthComp);

			//var date = new Date();
			leaveDateComp.setYear(leaveDateComp.getYear() - 61);
			leaveDateComp.setDate(leaveDateComp.getDate() + 1);
			leaveMonthComp.setMonth(leaveMonthComp.getMonth() - 6);

			if (birthDateComp < leaveDateComp || birthDateComp > leaveMonthComp) {
				$scope.travelDetailsObj.dateOfBirthErr = true;
			}
			else {
				$scope.travelDetailsObj.dateOfBirthErr = false;
			}

		},
		planTypeFunc: function (data) {

			var planObj = $rootScope.travelData.coverageCompemsation;
			this.plan = data;
			$scope.planData = [];
			if (data === "B2" || data === "A2") {
				for (var i = 0; i < planObj.length; i++) {
					if (planObj[i].planOrTableType === "A2" || planObj[i].planOrTableType === "B2") {
						$scope.planData.push(planObj[i]);
					}
				}
				$scope.breakUp = { "breakup": $scope.planData };
				angular.extend($rootScope.travelData, $scope.breakUp);

			}
			if (data === "B1" || data === "A1") {
				for (var i = 0; i < planObj.length; i++) {
					if (planObj[i].planOrTableType === "A1" || planObj[i].planOrTableType === "B1") {
						$scope.planData.push(planObj[i]);
					}
				}
				$scope.breakUp = { "breakup": $scope.planData };
				angular.extend($rootScope.travelData, $scope.breakUp);
			}
		},
		planRadio: function (data) {
			//this.getTravelPlanDetailsFunc();
			$scope.planObj = $rootScope.travelData.coverageCompemsation;
			$scope.type = data;
			this.plan = data;
			$scope.planData = [];
			if (data === "B2" || data === "A2") {
				for (var i = 0; i < $scope.planObj.length; i++) {
					if ($scope.planObj[i].planOrTableType === "A2" || $scope.planObj[i].planOrTableType === "B2") {
						$scope.planData.push($scope.planObj[i]);
					}
				}

			}
			if (data === "B1" || data === "A1") {
				for (var i = 0; i < $scope.planObj.length; i++) {
					if ($scope.planObj[i].planOrTableType === "A1" || $scope.planObj[i].planOrTableType === "B1") {
						$scope.planData.push($scope.planObj[i]);
					}
				}
			}
			this.travelPlanShow = true;

		},
		closePopup: function () {
			this.travelPlanShow = false;
		},
		saveDetails: function () { // On click of Calculate Premium in Travel Details

			if ($rootScope.travelData.travellerDetailsResponse !== undefined && $rootScope.travelData.travellerDetailsResponse !== "") {
				var saveTravellerDetails =
					{
						"quote": {
							"additionalPAOMPQuoteDetails": {
							/**CR_3658: set doYouHaveMediclaim2007PolicyWithNewIndia to default "No", dependent parameters removed(not in portal too)*/						
							"doYouHaveMediclaim2007PolicyWithNewIndia": "N",
							// "policyNumber": "",
							// "policyPeriod": "",
							// "sumInsured": "100000",
							// "detailsOfPreExistingDiseases": ""
							},
							"premiumDetails": $rootScope.travelData.calPremiumQuote.premiumDetails,
							"risks": [
								{
									"riskDetails": {
										"medicalHistoryDetails": {
											"preExistingDiseaseForMediclaimMember": $rootScope.travelData.saveTravellerDetails.risks[0].riskDetails.medicalHistoryDetails.preExistingDiseaseForMediclaimMember,
											"detailsOfPreExistingDiseases": $rootScope.travelData.saveTravellerDetails.risks[0].riskDetails.medicalHistoryDetails.detailsOfPreExistingDiseases,
											"otherInformation": $rootScope.travelData.saveTravellerDetails.risks[0].riskDetails.medicalHistoryDetails.otherInformation
										},
										"financierDetails": {

										},
										"discountDetails": {

										},
										"nomineeDetails": {
											"name": $rootScope.travelData.saveTravellerDetails.risks[0].riskDetails.nomineeDetails.name,
											"relationshipWithInsured": $rootScope.travelData.saveTravellerDetails.risks[0].riskDetails.nomineeDetails.relationshipWithInsured
										},
										"occupation": $rootScope.travelData.saveTravellerDetails.risks[0].riskDetails.occupation,
										"nationality": $rootScope.travelData.saveTravellerDetails.risks[0].riskDetails.nationality,
										"passportNo": $rootScope.travelData.saveTravellerDetails.risks[0].riskDetails.passportNo,
										"passportExpiryDate": $rootScope.travelData.saveTravellerDetails.risks[0].riskDetails.passportExpiryDate,
										"visaWorkPermit": $rootScope.travelData.saveTravellerDetails.risks[0].riskDetails.visaWorkPermit,
										"proposedDateOfDeparture": this.leaveDate,
										"noOfDaysStayedOutsideIndia": this.dayDifference
									},
									"coverages": [
										{
											"coverDetails": {
												"planType": this.plan,
												"travelDestination": this.destination,
												"categoryType": this.travelPurpose
											}
										}
									]
								}
							],
							"policyHolderCode": $rootScope.travelData.savedPartyDetails.partyDetails.partyCode,
							"quoteNumber": $rootScope.travelData.calPremiumQuote.quoteNumber,
							"productCode": "BH",
							"policyStartDate": this.leaveDate,
							"policyExpiryDate": this.returnDate,
							"dateOfBirth": $rootScope.travelData.savedPartyDetails.partyDetails.individualDetails.dateOfBirth,
							"term": this.dayDifference
						},
						"userProfile": {
							"userId": CommonServices.getCommonData("userId"),
							"loggedInRole": "SUPERUSER"
						}
					};
//CR_0054
				if(CommonServices.editQuoteHistory === true){
					saveTravellerDetails.quote.quoteNumber=CommonServices.businessHolidaysObj.quoteNumber;
				}
//CR_0054
				var saveQuoteResponse = RestServices.postService(RestServices.urlPathsNewPortal.saveQuote, saveTravellerDetails);
				saveQuoteResponse.then(
					function (response) { // success 

						CommonServices.showLoading(false);
						if (response.data !== undefined && response.data !== "") {
							if (response.data.userProfile !== undefined) {
								if (response.data.userProfile.footer.errorCode === "1") {
									//CommonServices.showAlert(response.data.userProfile.footer.errorDescription);

									$scope.travelDetails = {
										destination: $scope.travelDetailsObj.destination,
										travelPurpose: $scope.travelDetailsObj.travelPurpose,
										leaveDate: $scope.travelDetailsObj.leaveDate,
										returnDate: $scope.travelDetailsObj.returnDate,
										dateOfBirth: $scope.travelDetailsObj.dateOfBirth,
										noOfDaysStayedOutsideIndia: $scope.travelDetailsObj.dayDifference,
										planType: $scope.travelDetailsObj.plan
									};
									$scope.calPremiumQuote = { "calPremiumQuote": response.data.quote };
									angular.extend($rootScope.travelData, $scope.travelDetails);
									angular.extend($rootScope.travelData, $scope.calPremiumQuote);
									$rootScope.travelData.travellerDetailsResponse = response.data.quote;
									$state.go('businessHolidays.travelSummary');


								} else {
									CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
								}
							}
							else {
								CommonServices.showAlert(response.data.errorMessage);
							}
						}
						else {
							CommonServices.showAlert("Please try after some time");
						}

					},
					function (error) { // failure
						CommonServices.showLoading(false);
						RestServices.handleWebServiceError(error);
					});
			}
			else {
				$scope.calPremiumData = {
					"quote": {
						"additionalPAOMPQuoteDetails": {}, "premiumDetails": {}, "risks": [{
							"riskDetails": {
								"medicalHistoryDetails": {}, "financierDetails": {}, "discountDetails": {}, "nomineeDetails": {},
								"proposedDateOfDeparture": this.leaveDate, "noOfDaysStayedOutsideIndia": this.dayDifference
							}, "coverages": [{
								"coverDetails":
								{ "planType": this.plan, "travelDestination": this.destination, "categoryType": this.travelPurpose }
							}]
						}], "productCode": "BH",
						"policyStartDate": this.leaveDate, "policyExpiryDate": this.returnDate, "dateOfBirth": this.dateOfBirth, "term": this.dayDifference
					},
					"userProfile": { "userId": CommonServices.getCommonData("userId"), "loggedInRole": "SUPERUSER" }, "alfrescoInput": {
						"channel": "AGENT",
						"productName": "BH", "language": "English"
					}
				}
//CR_0054
				 if(CommonServices.editQuoteHistory === true){			 
					 $scope.calPremiumData.quote.quoteNumber=CommonServices.businessHolidaysObj.quoteNumber;					
				}
//CR_0054
				var calPremium = RestServices.postService(RestServices.urlPathsNewPortal.calcPremiumOMP, $scope.calPremiumData);
				calPremium.then(
					function (response) { // success 

						CommonServices.showLoading(false);
						if (response.data.quote !== undefined && response.data.quote !== "") {
							$scope.travelDetails = {
								destination: $scope.travelDetailsObj.destination,
								travelPurpose: $scope.travelDetailsObj.travelPurpose,
								leaveDate: $scope.travelDetailsObj.leaveDate,
								returnDate: $scope.travelDetailsObj.returnDate,
								dateOfBirth: $scope.travelDetailsObj.dateOfBirth,
								noOfDaysStayedOutsideIndia: $scope.travelDetailsObj.dayDifference,
								planType: $scope.travelDetailsObj.plan
							};
							$scope.calPremiumQuote = { "calPremiumQuote": response.data.quote };
							angular.extend($rootScope.travelData, $scope.travelDetails);
							angular.extend($rootScope.travelData, $scope.calPremiumQuote);
							$state.go('businessHolidays.travelSummary');
						} else {
							if (response.data.errorMessage !== undefined && response.data.errorMessage !== "")
								CommonServices.showAlert(response.data.errorMessage);
							else
								CommonServices.showAlert("Presently our services are not available. Please try after some time");
						}
					},
					function (error) { // failure
						CommonServices.showLoading(false);
						RestServices.handleWebServiceError(error);
					});
			}

		},
		back: function () {
			if (CommonServices.getCommonData("userId") === undefined)
				$state.go("login");
			else {
				CommonServices.setCommonData("selectedProduct", 'overseas');
				$state.go('buyNowSubLandingScreen');
			}
		}
	};
//CR_0054
	if(CommonServices.editQuoteHistory === true){
		this.travelPlan = true;
		console.log("CommonServices.businessHolidaysObj :"+JSON.stringify(CommonServices.businessHolidaysObj));
		$scope.travelDetailsObj.destination=CommonServices.businessHolidaysObj.risks[0].coverages[0].coverDetails.travelDestination;
		$scope.travelDetailsObj.travelPurpose=CommonServices.businessHolidaysObj.risks[0].coverages[0].coverDetails.categoryType;
		$scope.travelDetailsObj.leaveDate=CommonServices.businessHolidaysObj.policyStartDate;
		$scope.travelDetailsObj.returnDate=CommonServices.businessHolidaysObj.policyExpiryDate;
		$scope.travelDetailsObj.dateOfBirth=CommonServices.businessHolidaysObj.risks[0].riskDetails.dateOfBirth;
		$scope.travelDetailsObj.dayDifference=CommonServices.businessHolidaysObj.risks[0].riskDetails.noOfDaysStayedOutsideIndia;
		$scope.travelDetailsObj.plan=CommonServices.businessHolidaysObj.risks[0].coverages[0].coverDetails.planType;
		$scope.travelDetailsObj.travelPlan = true;
		$scope.travelDetailsObj.dateCompare($scope.travelDetailsObj.leaveDate,$scope.travelDetailsObj.returnDate);//added for valid date comparison
	}
//CR_0054
	$scope.home = function () {
		if (CommonServices.getCommonData("userId") === undefined)
			$state.go("login");
		else if(CommonServices.editQuoteHistory === true){//CR_0054
			$state.go("managePolicies.managePolicies");//CR_0054
		}else {
			CommonServices.setCommonData("selectedProduct", 'overseas');
			$state.go('buyNowSubLandingScreen');
		}
	}

	$scope.calIconClick = function (event) {
		angular.element("#" + event.currentTarget.children[0].id).focus();
	};

	$scope.hideModal = function () {
		$scope.travelDetailsObj.travelPlanShow = false;
	};

	if ($rootScope.backFlag === "travelSummary") {
		$scope.travelDetailsObj.travelPlan = true;
		$scope.travelDetailsObj.dayDiffValid = true;
		$scope.travelDetailsObj.destination = $rootScope.travelData.destination;
		$scope.travelDetailsObj.travelPurpose = $rootScope.travelData.travelPurpose;
		$scope.travelDetailsObj.leaveDate = $rootScope.travelData.leaveDate;
		$scope.travelDetailsObj.returnDate = $rootScope.travelData.returnDate;
		$scope.travelDetailsObj.dayDifference = $rootScope.travelData.noOfDaysStayedOutsideIndia;
		$scope.travelDetailsObj.dateOfBirth = $rootScope.travelData.dateOfBirth;
		$scope.travelDetailsObj.plan = $rootScope.travelData.planType;
	}

}]);

agentApp.controller('travelSummaryCtrl', ['$scope', 'RestServices', 'CommonServices', '$state', '$rootScope', function ($scope, RestServices, CommonServices, $state, $rootScope) {
	$scope.home = function () {
		$rootScope.backFlag = "travelSummary";
		$state.go("businessHolidays.travelDetails");
	}
	$scope.travelSummary = $rootScope.travelData;

	if ($rootScope.travelData.travellerDetailsResponse !== undefined && $rootScope.travelData.travellerDetailsResponse !== "") {
		$scope.travelSummary.calPremiumQuote = $rootScope.travelData.travellerDetailsResponse;
	}
	else {
		$scope.travelSummary.calPremiumQuote = $rootScope.travelData.calPremiumQuote;
	}
	/********ADDED FOR CR_805 Start *******/
    /******** new view breakup functionality***/
	$scope.viewBreakupShow = false;
	$scope.closePopup = function () {
		$scope.viewBreakupShow = false;
	};
	$scope.hideModal = function () {
		$scope.viewBreakupShow = false;
	};
	
	$scope.viewBreakup=function()
	{
		
		       var gsViewBreakupInput = {
                "header": null,
                "quote": {
                    "quoteNumber":$scope.travelSummary.calPremiumQuote.quoteNumber,
                    "productCode": "BH",
                    "policyHolderCode":""
                }
            };
       
        var gsViewBreakUpResponse = RestServices.postService(RestServices.urlPathsNewPortal.topUpViewBreakup, gsViewBreakupInput);
        gsViewBreakUpResponse.then(
            function (response) { // success 

                CommonServices.showLoading(false);
                if (response.data.hasOwnProperty('errorMessage')) {
                    //alert(response.data.errorMessage);
                    CommonServices.showAlert(response.data.errorMessage);
                } else {
                    CommonServices.topUpObj.viewBreakUpResponse = response.data.quote;
					$scope.viewBrkupOvj=response.data.quote;
					$scope.viewBreakupShow = true;
                   // $state.go("topUpViewBreakupScreen");
                }
            },
            function (error) { // failure
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            });

		
	}
	
/*********ADDED FOR CR_805 End *******/
	
	
	$scope.travelPlanShow = false;
	$scope.viewBreakUp = false;

	$scope.viewBreakUpFunc = function () {
		$scope.viewBreakUp = true;
	}
	$scope.closePopup = function () {
		$scope.travelPlanShow = false;
		//$scope.viewBreakUp = false; //comment for CR_805
               $scope.viewBreakupShow = false;
	}
	$scope.planRadio = function () {
		$scope.travelPlanShow = true;
	}

	$scope.saveDetails = function () { // On click of save in Travel Summary
		$state.go('businessHolidays.policyHolderInfo');
	}

	var month = new Array();
	month[0] = "Jan";
	month[1] = "Feb";
	month[2] = "Mar";
	month[3] = "Apr";
	month[4] = "May";
	month[5] = "June";
	month[6] = "Jul";
	month[7] = "Aug";
	month[8] = "Sep";
	month[9] = "Oct";
	month[10] = "Nov";
	month[11] = "Dec";

	var DOB = $scope.travelSummary.dateOfBirth;
	DOB = DOB.split('/');
	DOB = DOB[1] + '/' + DOB[0] + '/' + DOB[2];
	DOB = new Date(DOB);
	var month = month[DOB.getMonth()];
	var yr = DOB.getFullYear();
	var date = DOB.getDate();
	$scope.dateOfBirth = date + "-" + month + "-" + yr;


	$scope.continueSave = function () {
		$scope.savecalPremiumData =
			{
				"quote": {
					"additionalPAOMPQuoteDetails": {}, "premiumDetails": {
						"totalPremium": $scope.travelSummary.calPremiumQuote.premiumDetails.totalPremium,
						"netPremium": $scope.travelSummary.calPremiumQuote.premiumDetails.netPremium, "stampDuty": $scope.travelSummary.calPremiumQuote.premiumDetails.stampDuty
					},
					"risks": [{
						"riskDetails": {
							"medicalHistoryDetails": {}, "financierDetails": {}, "discountDetails": {}, "nomineeDetails": {},
							"proposedDateOfDeparture": $scope.travelSummary.leaveDate, "noOfDaysStayedOutsideIndia": $scope.travelSummary.noOfDaysStayedOutsideIndia
						}, "coverages": [{
							"coverDetails": {
								"planType": $scope.travelSummary.planType,
								"travelDestination": $scope.travelSummary.destination, "categoryType": $scope.travelSummary.travelPurpose
							}
						}]
					}], "quoteNumber": $scope.travelSummary.calPremiumQuote.quoteNumber, "productCode": "BH",
					"policyStartDate": $scope.travelSummary.leaveDate, "policyExpiryDate": $scope.travelSummary.returnDate, "emailId": CommonServices.getCommonData("collectionDetails").emailID,
					"mobileNo": CommonServices.getCommonData("collectionDetails").mobileNum, "dateOfBirth": $scope.travelSummary.dateOfBirth, "term": $scope.travelSummary.noOfDaysStayedOutsideIndia
				}, "userProfile": { "userId": CommonServices.getCommonData("userId"), "loggedInRole": "SUPERUSER" }, "alfrescoInput": { "channel": "AGENT", "productName": "BH", "language": "English" }
			};

		var saveQuoteDBResponse = RestServices.postService(RestServices.urlPathsNewPortal.saveQuoteDB, $scope.savecalPremiumData);
		saveQuoteDBResponse.then(
			function (response) { // success 

				CommonServices.showLoading(false);
				if (response.data.footer.errorCode === "1") {
					CommonServices.showAlert(response.data.footer.status);
					$state.go('businessHolidays.policyHolderInfo');
				} else {
					if (response.data.errorMessage !== undefined && response.data.errorMessage !== "")
						CommonServices.showAlert(response.data.errorMessage);
					else
						CommonServices.showAlert("Presently our services are not available. Please try after some time");
				}
			},
			function (error) { // failure
				CommonServices.showLoading(false);
				RestServices.handleWebServiceError(error);
			});
	};

	$scope.hideModal = function () {
		$scope.travelPlanShow = false;
	};


}]);

agentApp.controller('policyHolderInfoCtrl', ['$scope', 'RestServices', 'CommonServices', '$state', '$rootScope', '$filter', function ($scope, RestServices, CommonServices, $state, $rootScope, $filter) {

	$scope.pinCodeModal = false;
	/*Added for CR_NP_0744*/
	$scope.regexPanNo = regexPanNoGlobal;//CR3749
	$scope.regexAadhaarInput = /^(?!\1+$)\d{4}$/;
	$scope.regexAadhaarNumber = /^(?!\1+$)\d{12}$/;
	/*CR_NP_0744 Changes ends*/
	var mydateStr = new Date();
	var mynewdateFrom = "";
	/*CR_NP_0880 starts */
	$scope.disablePinCode = true;
	$scope.disableCity = true;
	$scope.stateErr = false;
	$scope.gstinMsg = "GSTIN";
	/*$scope.countryErr = false;//3712*/
	$scope.pinCodeErr = false;
	$scope.cityErr = false;
	$scope.isNIAPAN = false;//CR3746
	if ($rootScope.backFlag == "travellerDetails") {
		$scope.disablePinCode = false;
		// $scope.disableCity = true;
	}
	/*CR_NP_0880 Ends*/

	if (mydateStr != undefined) {
		mynewdateFrom = new Date(mydateStr);
	}
	else {
		mynewdateFrom = new Date();
	}
	/*CR 3712 starts
	$scope.isNonIndia = false;
	// $scope.policyDetailsObj.clientNationality ="";
	$scope.onNationalityChange = function(){
		$scope.policyDetailsObj.clientCountry = '';
		if($scope.policyDetailsObj.clientNationality == "NonIndian"){
			$scope.isNonIndia = true;
		}
		else{
			$scope.isNonIndia = false;
		}
	}
	// CR_3712 ends*/
 //CR3746
 $scope.onPANNoChange = function () {
	if($scope.policyDetailsObj.panNo != undefined){
		$scope.policyDetailsObj.panNo = $scope.policyDetailsObj.panNo.toUpperCase();
		$scope.isNIAPAN = isNIAPANNo($scope.policyDetailsObj.panNo);
	}
	else
	$scope.isNIAPAN = false;
};
//CR3746
	/*Added for CR_NP_0744*/
	var configurationData = CommonServices.getCommonData("ConfigurationData");
	if (configurationData != undefined && configurationData != '') {
		if (configurationData[0].value == "Y") {
			$scope.isPanNumberMandatory = true;
		} else {
			$scope.isPanNumberMandatory = false;
		}
		/*Below block commented for CR_NP_0744E*/
		//  if(configurationData[1].value == "Y"){
		// 	 $scope.isAadhaarNumberMandatory = true;
		//  }else{
		// 	  $scope.isAadhaarNumberMandatory = false;
		//  }		
		/* CR_NP_0744E changes ends*/
	}
	/*CR_NP_0744 Changes ends*/

	/**Date of Birth**/
	var dateOfBirthfrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 62));
	dateOfBirthfrom = new Date(dateOfBirthfrom.setDate(dateOfBirthfrom.getDate() + 1));
	dateOfBirthfrom = getFormattedDate(dateOfBirthfrom);

	var dateOfBirthTo = new Date(new Date().setMonth(mynewdateFrom.getMonth()));
	dateOfBirthTo = new Date(dateOfBirthTo.setDate(dateOfBirthTo.getDate()));
	dateOfBirthTo = getFormattedDate(dateOfBirthTo);
	/**Date of Birth**/


	$('#dateOfBirth').loadCalendar({
		'enableDateRange': true,
		'enableCalendarFrom': dateOfBirthfrom,
		'enableCalendarTo': dateOfBirthTo
	});

	/*Added by CR_NP_0744, and Commented for CR_NP_0744E*/
	// $(".aadhaarInput").keyup(function () {
	// 	if (this.value.length == 4) {
	// 		$(this).next('.aadhaarInput').focus();
	// 	}
	// 	if (this.value.length < 1) {
	// 	  $(this).prev('.aadhaarInput').focus();
	// 	}
	// });
	// $scope.aadhaarNoField = function(){
	// 	if(($scope.policyDetailsObj.aadhaarNumber1 != undefined && $scope.policyDetailsObj.aadhaarNumber1 !='')||($scope.policyDetailsObj.aadhaarNumber2 != undefined && $scope.policyDetailsObj.aadhaarNumber2 !='')||($scope.policyDetailsObj.aadhaarNumber3 != undefined && $scope.policyDetailsObj.aadhaarNumber3 !='')){
	// 		$scope.aadharFieldIsRequired = true;
	// 		if(($scope.policyDetailsObj.aadhaarNumber1 != undefined && $scope.policyDetailsObj.aadhaarNumber1 !='') && ($scope.policyDetailsObj.aadhaarNumber2 != undefined && $scope.policyDetailsObj.aadhaarNumber2 !='') && ($scope.policyDetailsObj.aadhaarNumber3 != undefined && $scope.policyDetailsObj.aadhaarNumber3 !='')){
	// 			$scope.aadharFieldIsRequired = false;
	// 		}
	// 	}else{
	// 		$scope.aadharFieldIsRequired = false;
	// 	}
	// };
	/**CR_NP_0744 and CR_NP_0744E Changes End**/

	$scope.home = function () {
		$rootScope.backFlag = "travelSummary";
		$state.go("businessHolidays.travelSummary");
	}

	$scope.policyDetailsObj = {
		newcustomerFlag: true,
		existingCustomerFlag: false,
		policyHolder: "newPolicyHolder",
		category: "I",
		showSearchResTbl: false,
		noRecords: null,
		showSmallTbl: false,
		fieldDisable: false,
		existingCustomerBtn: true,
		dateOfBirthErr: false,
		gstRegTypeVal: [{
			id: "NCC",
			name: "Normal,Composite,Casual"
		}, {
			id: "NRI",
			name: "NRI"
		}, {
			id: "UNB",
			name: "UN Bodies/Embassy"
		}],
		dateOfBirthFunc: function () {

			var dt1 = this.dateOfBirth.split('/'),
				birthDateComp = dt1[1] + '/' + dt1[0] + '/' + dt1[2], //mm/dd/yyyy
				dt2 = $rootScope.travelData.leaveDate.split('/'),
				leaveDateComp = dt2[1] + '/' + dt2[0] + '/' + dt2[2],
				dt3 = $rootScope.travelData.leaveDate.split('/'),
				leaveMonthComp = dt3[1] + '/' + dt3[0] + '/' + dt3[2]; //mm/dd/yyyy

			birthDateComp = new Date(birthDateComp);
			leaveDateComp = new Date(leaveDateComp);
			leaveMonthComp = new Date(leaveMonthComp);

			//var date = new Date();
			leaveDateComp.setYear(leaveDateComp.getYear() - 61);
			leaveDateComp.setDate(leaveDateComp.getDate() + 1);
			leaveMonthComp.setMonth(leaveMonthComp.getMonth() - 6);

			if (birthDateComp < leaveDateComp || birthDateComp > leaveMonthComp) {
				this.dateOfBirthErr = true;
			}
			else {
				this.dateOfBirthErr = false;
			}

			this.compareBirthDate();
		},
		policyHolderFunc: function (data) {
			this.fieldDisable = false;
			this.existingCustomerBtn = true;
			this.showSmallTbl = false;
			this.showSearchResTbl = false;
			if (data === "existingPolicyHolder") {
				this.existingCustomerFlag = true;
				this.newcustomerFlag = false;
				this.partyCode = "";
				this.EfirstName = "";
				this.ElastName = "";
				this.EmobileNumber = "";
				this.EemailID = "";
			}
			else if (data === "newPolicyHolder") {
				$scope.partyCode = "";
				/*Added for CR_NP_0744, and comments during CR_NP_0744E*/
				this.panNoInputDisable = false;
				// this.aadhaarInputDisable = false;
				CommonServices.panNoInputDisable = false;
				// CommonServices.aadhaarInputDisable = false;
				/*CR_NP_0744 Ends*/
				this.newcustomerFlag = true;
				this.existingCustomerFlag = false;
				this.productTitle = "";
				this.firstName = "";
				this.middleName = "";
				this.lastName = "";
				this.gender = "";
				this.dateOfBirth = "";
				/*
				this.clientNationality = ""; //3712
				this.clientCountry = "";//3712
				*/
				this.street = "";
				this.locality = "";
				this.placeOfLoss = "";
				this.mobileNumber = "";
				this.landlineNumber = "";
				this.emailID = "";
				this.panNo = "";
				/*Added for CR_NP_0744*/
				this.aadhaarNumber1 = "";
				this.aadhaarNumber2 = "";
				this.aadhaarNumber3 = "";
				/*CR_NP_0744 Ends*/
				this.accountNo = "";
				this.gstRegID = "";
				this.gstINModel = "";
				this.uinModel = "";
				this.contState = "";
				this.countryCity = "";
			}
		},
		compareBirthDate: function () {// this will compare the date entered in travel details screen and policy holder screen
			if (this.dateOfBirth !== undefined && $rootScope.travelData.dateOfBirth !== undefined) {

				var lossDateComp = $rootScope.travelData.dateOfBirth;
				var drr = lossDateComp.split('/');
				lossDateComp = drr[1] + '/' + drr[0] + '/' + drr[2]; //mm/dd/yyyy

				var policyStartDateComp = this.dateOfBirth;
				var srr = policyStartDateComp.split('/');
				policyStartDateComp = srr[1] + '/' + srr[0] + '/' + srr[2]; //mm/dd/yyyy

				lossDateComp = new Date(lossDateComp);
				policyStartDateComp = new Date(policyStartDateComp);
				if (lossDateComp.getTime() === policyStartDateComp.getTime()) {

				}
				else {
					CommonServices.showAlert("There is a mismatch between the Date of Birth entered for Travel and Policy Holder which may cause changes in premium.Please note that the date of birth entered in the Policy holder shall be considered for premium calculation.");
				}

			}
			return true;

		},
		gstIDInputChangeFunc: function () { // Onchange of GSTIN input field
			if (this.gstRegID !== undefined && this.gstRegID !== "") {

				var reg = "";

				if (this.gstINModel != undefined && this.gstINModel === 15) {
					$scope.policyHolderForm.gstIN.$invalid = false;
					$scope.policyHolderForm.$invalid = false;
				}
				else {
					$scope.policyHolderForm.gstIN.$invalid = true;
					$scope.policyHolderForm.$invalid = true;
				}

				if (this.gstRegID === "NCC") {
					reg = regexGSTidGlobal;

					// uncomment it for 3749
				// 	if(reg){
				// 		if(CommonServices.gstIdStateCode[this.gstINModel.slice(0,2)] != undefined){
				// 			if($scope.policyDetailsObj.contState.state == CommonServices.gstIdStateCode[this.gstINModel.slice(0,2)]){
				// 			$scope.policyHolderForm.gstIN.$setValidity("gstStateCode", true);
				// 			console.log("state code valid");
				// 		}
				// 			else{
				// 			$scope.policyHolderForm.gstIN.$setValidity("gstStateCode", false);
				// 			$scope.gstErrorMsg = "Please enter valid GSTIN. State code of GSTIN and the state mentioned in address should match.";	
				// 			}
				// 		}
				// 		else{
				// 		$scope.policyHolderForm.gstIN.$setValidity("gstStateCode", false);
				// 		$scope.gstErrorMsg = "Please enter GSTIN with a valid state code";
				// 	}
				// }
			}
				if (this.gstRegID === "NRI") {
					reg = /^[0-9]{12}N[A-Z0-9]{1}T$/;
				}
				if (this.gstRegID === "UNB") {
					reg = /^[0-9]{12}U[A-Z0-9]{1}N$/;
				}

				if (this.gstINModel !== "" || this.gstINModel !== undefined) {
					if (reg === "")
						valid = false;
					else
						valid = reg.test(this.gstINModel.toUpperCase());
				}

				if (this.gstRegID !== undefined && this.gstRegID !== "") {
					$scope.policyHolderForm.$invalid = false;
				}
				else {
					$scope.policyHolderForm.$invalid = true;
				}

				if (valid) {
					$scope.policyHolderForm.gstIN.$setValidity("gstinPattern", true);
					$scope.policyHolderForm.gstIN.$invalid = false;
					$scope.policyHolderForm.$invalid = false;
					$scope.policyHolderForm.gstIN.$setValidity("gstIN", true);
				} else {
					$scope.policyHolderForm.gstIN.$setValidity("gstinPattern", false);
					$scope.policyHolderForm.gstIN.$invalid = true;
					$scope.policyHolderForm.$invalid = true;
					$scope.policyHolderForm.gstIN.$setValidity("gstIN", false);
				}


				// ADDED BY HIMANSHU FOR CR_875
				if (this.gstRegID != undefined && this.gstRegID != '') {
					if (this.gstINModel != undefined) {
						this.gstINModel = this.gstINModel.toUpperCase();
						if (this.gstINModel.includes("AAACN4165C")) {
							$scope.policyHolderForm.gstIN.$setValidity("validateNIAPAN", false);
							$scope.policyHolderForm.$invalid = true;
						} else {
							$scope.policyHolderForm.gstIN.$setValidity("validateNIAPAN", true);
							$scope.policyHolderForm.$invalid = false;

						}
					}
				}

				//console.log(detailQuoteTWScreenForm.gstIN.$error.gstinPattern);

			}
		},
		uinInputChangeFunc: function () { // Onchange of UIN input field
			if (this.uinModel.length === 15) {
				$scope.policyHolderForm.UIN.$invalid = false;
				$scope.policyHolderForm.$invalid = false;
			}
			else {
				$scope.policyHolderForm.UIN.$invalid = true;
				$scope.policyHolderForm.$invalid = true;
			}
		},
		stateServiceCall: function () {// this function is service call for getting state 
			//if(!this.stateResponse){//this condition will not allow service to get called twice
			this.stateResponse = RestServices.postService(RestServices.urlPathsNewPortal.getStateList, $scope.stateData);
			return this.stateResponse.then(
				function (response) { // success

					CommonServices.showLoading(false);
					if (response.data.states !== undefined && response.data.states !== "") {
						/*CR_NP_0880 starts */
						if ($scope.partyCode !== "" && $scope.partyCode !== undefined) {// if the customer is existing customer
							response.data.states.filter(function (b) {//this filter will compare the responseState with the response data
								if ($scope.responseState !== "" && $scope.responseState !== undefined && b.stateCode === $scope.responseState) {
									$scope.policyDetailsObj.contState = b;
									$scope.responseState = "";
									$scope.searchPincode = { "state": $scope.policyDetailsObj.contState.state, "zipCode": "" };
									$scope.policyDetailsObj.pinCodeServiceCall();
								}
							});
							$scope.stateList = response.data.states;
						}
						else {// if the customer is new customer
							if ($scope.continueState !== "" && $scope.continueState !== undefined) {
								response.data.states.filter(function (b) {
									if (b.stateCode === $scope.continueState) {
										$scope.stateObj = {
											"stateObj": b
										}
									}
								});

								angular.extend($rootScope.travelData.savedPartyDetails.partyDetails, $scope.stateObj);
								if ($scope.stateObj !== undefined && $scope.stateObj !== "") {
									$scope.continueState = "";
									$scope.cityData = { 
										"state": $scope.stateObj.stateObj.state, 
										"zipCode": $scope.continuepinCode, 
										//"additionalParameter": "MOBILE", 
										"city": "" 
									};
									$scope.policyDetailsObj.cityServiceCall();
								}
								else {
									CommonServices.showAlert("Please change the state you have entered.");
								}

							}
							$scope.stateData = "";
							$scope.stateList = response.data.states;
						}
						return $scope.stateList;
					} else {
						if (response.data.errorMessage !== undefined && response.data.errorMessage !== "")
							CommonServices.showAlert(response.data.errorMessage);
						else
							// CommonServices.showAlert("Presently our services are not available. Please try after some time");
							CommonServices.showAlert("Error Occured. Please try again later");
					}
				},
				function (error) { // failure
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
				});
			//}
			/* CR_NP_0880 ends*/
		},

		pinCodeServiceCall: function () { // this function is service call for getting pincodes
			this.getZipcodeDetailResponse = RestServices.postService(RestServices.urlPathsNewPortal.getZipCodesbyState, $scope.searchPincode);
			return this.getZipcodeDetailResponse.then(
				function (response) { // success 
					/* CR_NP_0880 Starts*/
					CommonServices.showLoading(false);
					if (response.data.pincodes !== undefined && response.data.pincodes !== "") {
						if ($scope.partyCode !== "" && $scope.partyCode !== undefined) { // if the cutomer is existing customer

							response.data.pincodes.filter(function (b) {//this filter will compare the responsepinCode with the response data
								if ($scope.responsepinCode !== "" && $scope.responsepinCode !== undefined && b === $scope.responsepinCode) {
									$scope.policyDetailsObj.placeOfLoss = b;
									$scope.responsepinCode = "";
									$scope.cityData = { 
										"state": ($scope.policyDetailsObj.contState.state === undefined) ? $scope.policyDetailsObj.contState : $scope.policyDetailsObj.contState.state, 
										"zipCode": $scope.policyDetailsObj.placeOfLoss, 
										//"additionalParameter": "MOBILE", 
										"city": "" 
									};
									$scope.policyDetailsObj.cityServiceCall();
								}
							});
							$scope.pinCodesList = response.data.pincodes;
							$scope.pinCodeResponseArray = response.data.pincodes;

							var pincodeMatchList = [];
							for (var i = 0; i < $scope.pinCodesList.length; i++) {
								if ($scope.pinCodesList[i].match($scope.searchPincode.zipCode)) {
									pincodeMatchList.push($scope.pinCodesList[i]);
								}
							}
							return $scope.pinCodesList = pincodeMatchList;
						}
						else {// if the customer is new customer
							$scope.searchPincode = "";
							$scope.pinCodesList = response.data.pincodes;
							$scope.pinCodeResponseArray = response.data.pincodes;
						}
						return $scope.pinCodesList;

					} else {
						if (response.data.errorMessage !== undefined && response.data.errorMessage !== "")
							CommonServices.showAlert(response.data.errorMessage);
						else
							// CommonServices.showAlert("Presently our services are not available. Please try after some time");
							CommonServices.showAlert("Error Occured. Please try again later");
					}
				},
				function (error) { // failure
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
				});
			//}
			/* CR_NP_0880 ends*/
		},
		cityServiceCall: function () {// this function is service call for getting city
			this.cityResponse = RestServices.postService(RestServices.urlPathsNewPortal.getCitiesList, $scope.cityData);
			return this.cityResponse.then(
				function (response) { // success 
					/* CR_NP_0880 Starts*/
					CommonServices.showLoading(false);
					if (response.data.cities !== undefined && response.data.cities !== "") {
						if ($scope.partyCode !== "" && $scope.partyCode !== undefined) {// if the customer is existing customer

							response.data.cities.filter(function (b) { //this filter will compare the responseCity with the response data
								if ($scope.responseCity !== "" && $scope.responseCity !== undefined && b.cityCode === $scope.responseCity) {
									$scope.policyDetailsObj.countryCity = b;
									$scope.responseCity = "";
								}
							});
							$scope.policyDetailsObj.countryCity = response.data.cities[0];
							$scope.cityList = response.data.cities;
						}
						else {// if the cutomer is new customer
							if ($scope.continueCity !== "" && $scope.continueCity !== undefined) {
								response.data.cities.filter(function (b) { //this filter will compare the responseCity with the response data
									if (b.cityCode === $scope.continueCity) {
										$scope.cityObj = {
											"cityObj": b
										}
									}
									angular.extend($rootScope.travelData.savedPartyDetails.partyDetails, $scope.cityObj);
								});
								if ($rootScope.travelData.savedPartyDetails.partyDetails.stateObj !== undefined && $rootScope.travelData.savedPartyDetails.partyDetails.stateObj !== "" && $rootScope.travelData.savedPartyDetails.partyDetails.cityObj !== undefined && $rootScope.travelData.savedPartyDetails.partyDetails.cityObj !== "") {
									$scope.continueCity = "";
									$state.go("businessHolidays.travellerDetails");
								}

							}
							$scope.cityData = "";
							$scope.policyDetailsObj.countryCity = response.data.cities[0];
							$scope.cityList = response.data.cities;
						}
						return $scope.cityList;
					} else {
						if (response.data.errorMessage !== undefined && response.data.errorMessage !== "")
							CommonServices.showAlert(response.data.errorMessage);
						else
							// CommonServices.showAlert("Presently our services are not available. Please try after some time");
							CommonServices.showAlert("Error Occured. Please try again later");
					}
				},
				function (error) { // failure
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
				});
			/* CR_NP_0880 ends*/
		},
		gstFunc: function (obj, data) { // This function has the service call for getting StateList and CityList
			/*CR_NP_0880 starts */
			if (data === "state") { // This will give list of states
				this.placeOfLoss = "";
				this.countryCity = "";
				$scope.disablePinCode = true;
				// $scope.disableCity = true;
				$scope.stateErr = true;
				$scope.pinCodeErr = false;
				$scope.cityErr = false;

				if (obj.length === 3) { // When entered value is of 3 digit
					$scope.stateData = { "state": obj.toUpperCase() };
					return this.stateServiceCall();
				} else {  // When entered value is more than 3 digit 
					if (obj.length > 3) {
						return ($filter('filter')($scope.stateList, { state: obj }));
					} else {
						$scope.stateList = {};
						return $scope.stateList;
					}
				}
			}

			if (data === 'pinCode') {
				$scope.pinCodeErr = true;
				$scope.cityErr = false;
				// $scope.disableCity = true;
				this.countryCity = "";

				if ($scope.pinCodeResponseArray != undefined && $scope.pinCodeResponseArray != "") {
					var matchList = [];
					$scope.pinCodesList = $scope.pinCodeResponseArray;
					for (var i = 0; i < $scope.pinCodesList.length; i++) {
						if ($scope.pinCodesList[i].match(obj)) {
							matchList.push($scope.pinCodesList[i]);
						}
					}
					return $scope.pinCodesList = matchList;
				} else { // New Customer when there is no pincode list
					$scope.searchPincode = { "state": this.contState.state === undefined ? this.contState.toUpperCase() : this.contState.state.toUpperCase(), "zipCode": obj };
					return this.pinCodeServiceCall();
				}
			}

			if (data === "city") { // This will give list of cities
				$scope.cityErr = true;
				if (obj.length === 1) { // When entered value is of 1 digit
					$scope.cityData = { "state": this.contState.state === undefined ? this.contState.toUpperCase() : this.contState.state.toUpperCase(), "zipCode": this.placeOfLoss, "city": obj.toUpperCase() };
					return this.cityServiceCall();
				}
				else { // When entered value is more than 1 digit
					if ($scope.cityList != undefined && $scope.cityList != "") { // if cities list is available
						return ($filter('filter')($scope.cityList, { city: obj }));
					} else {
						$scope.cityData = { "state": this.contState.state === undefined ? this.contState.toUpperCase() : this.contState.state.toUpperCase(), "zipCode": this.placeOfLoss, "city": obj.toUpperCase() };
						return this.cityServiceCall();
					}

				}
			}
			/*CR_NP_0880 Ends */
			/* 3712 Starts
			if (data === "country"){
				$scope.countryErr = true;
				if (obj.length === 3) { // When entered value is of 3 digit
					$scope.stateData = { "state": obj.toUpperCase() };
					return this.stateServiceCall();
				} else {  // When entered value is more than 3 digit 
					if (obj.length > 3) {
						return ($filter('filter')($scope.stateList, { state: obj }));
					} else {
						$scope.stateList = {};
						return $scope.stateList;
					}
				}
			}
			// 3712 Ends */
			
		},
		/* 3712 Starts
		onSelectCountry: function ($item, $model, $label) {// onchange of state input field//3712
			console.log($item);
			$scope.countryErr = false;
		},
		// 3712 Ends */
		onSelectState: function ($item, $model, $label) {// onchange of state input field
			/*CR_NP_0880 starts */
			$scope.stateErr = false;
			$scope.pinCodeErr = true;
			$scope.cityErr = false;
			$scope.disablePinCode = false;
			// $scope.disableCity = true;

			$scope.policyDetailsObj.placeOfLoss = "";
			$scope.policyDetailsObj.countryCity = "";
			$scope.pinCodeResponseArray = ""; // To make Pincode response list empty

			//Uncomment it for cr 3749
			// angular.forEach(CommonServices.gstIdStateCode,function(value,key){
			// 	if($scope.policyDetailsObj.contState.state == value){
			// 		$scope.gstinMsg = "GSTIN should start with "+key;
			// 	}
			// });
			// $scope.policyDetailsObj.gstIDInputChangeFunc();
		},
		onSelectPinCode: function ($item, $model, $label) {// onchange of pincode input field
			$scope.pinCodeErr = false;
			$scope.cityErr = false;
			// $scope.disableCity = true;

			$scope.cityData = { "state": ($scope.policyDetailsObj.contState.state === undefined) ? $scope.policyDetailsObj.contState.toUpperCase() : $scope.policyDetailsObj.contState.state.toUpperCase(), "zipCode": $scope.policyDetailsObj.placeOfLoss, "city": "" };
			return this.cityServiceCall();
		},
		onSelectCity: function ($item, $model, $label) {// onchange of city input field
			$scope.policyHolderForm.$invalid = false;
			$scope.cityErr = false;

			
		},
		/*CR_NP_0880 Ends */
		selectGstIDFunct: function (data) { // This function will validate the GSTIN values according to the changes in GSTID Type values

			if (this.gstRegID == '' || this.gstRegID == undefined) {
				this.gstINModel = "";
				$scope.policyHolderForm.gstIN.$setValidity("validateNIAPAN", true);
				$scope.policyHolderForm.gstIN.$setValidity("gstinPattern", true);
				$scope.policyHolderForm.gstIN.$invalid = false;
				$scope.policyHolderForm.$invalid = false;

			}

			var reg = "";
			if (this.gstINModel !== "" && this.gstINModel !== undefined) {
				if (this.gstINModel.length === 15) {
					$scope.policyHolderForm.gstIN.$invalid = false;
					$scope.policyHolderForm.$invalid = false;
				}
			}
			else {
				$scope.policyHolderForm.gstIN.$invalid = true;
				$scope.policyHolderForm.$invalid = true;
			}
			if (this.gstRegID === "NCC") {
				reg = regexGSTidGlobal;///^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[A-Z0-9]{2}[^\s]$/;
			}
			if (this.gstRegID === "NRI") {
				reg = /^[0-9]{12}N[A-Z0-9]{1}T$/;
				// $scope.policyHolderForm.gstIN.$setValidity("gstStateCode", true); //UC for 3749
			}
			if (this.gstRegID === "UNB") {
				reg = /^[0-9]{12}U[A-Z0-9]{1}N$/;
				// $scope.policyHolderForm.gstIN.$setValidity("gstStateCode", true);//UC for 3749
			}

			var valid = "";

			if (this.gstINModel !== "" || this.gstINModel !== undefined) {
				if (reg === "") {
					valid = true;
				}
				else {
					if (this.gstINModel !== undefined && this.gstINModel !== "") {
						valid = reg.test(this.gstINModel.toUpperCase());
					}
				}

			}

			if (!valid) {
				$scope.policyHolderForm.gstIN.$setValidity("gstIN", false);
				$scope.policyHolderForm.$invalid = true;
				$scope.policyHolderForm.gstIN.$invalid = true;
			}
			else {
				$scope.policyHolderForm.gstIN.$setValidity("gstIN", true);
				$scope.policyHolderForm.$invalid = false;
				$scope.policyHolderForm.gstIN.$invalid = false;
			}

		},
		saveDetails: function (data) { // On click of Create in Policy Holder Information screen

			/*Added for CR_NP_0744*/

			if (this.aadhaarNumber1 != undefined && this.aadhaarNumber1 != '' && this.aadhaarNumber2 != undefined && this.aadhaarNumber2 != '' && this.aadhaarNumber3 != undefined && this.aadhaarNumber3 != '') {
				$scope.policyDetailsObj.aadhaarNumber = this.aadhaarNumber1 + this.aadhaarNumber2 + this.aadhaarNumber3;
			} else {
				$scope.policyDetailsObj.aadhaarNumber = "";
			}

			var policyHolderData = {
				"userProfile": { "userId": CommonServices.getCommonData("userId"), "loggedInRole": "SUPERUSER" },
				"partyDetails": {
					"individualDetails": {
						"firstName": this.firstName !== undefined ? this.firstName.toUpperCase() : "",
						"middleName": this.middleName !== undefined ? this.middleName.toUpperCase() : "",
						"lastName": this.lastName !== undefined ? this.lastName.toUpperCase() : "",
						"gender": this.gender, 
						"dateOfBirth": this.dateOfBirth,
						/*// 3712 Starts
						"clientNationality": this.clientNationality,//3712
						"clientCountryObj": this.clientCountry,//3712
						"clientCountry": this.clientCountry.stateCode,//3712
						// 3712 Ends */
						"buildingNoStreet": this.street !== undefined ? this.street.toUpperCase() : "",
						"pinCode": this.placeOfLoss, // CR_NP_0880
						"mobileNo": this.mobileNumber,
						"emailId": this.emailID, "panNumber": this.panNo !== undefined ? this.panNo.toUpperCase() : "",
						"aadhaarNo": $scope.policyDetailsObj.aadhaarNumber,
						"gstRegIdType": this.gstRegID,
						"gstin": this.gstINModel !== undefined ? this.gstINModel.toUpperCase() : "",
						"uin": this.uinModel !== undefined ? this.uinModel.toUpperCase() : "",
						"cityObj": this.countryCity,
						"stateObj": this.contState, "state": this.contState.stateCode,
						"city": this.countryCity.cityCode, "eInsuranceAccountNo": this.accountNo
					}, "partyType": this.category
				}
			};
			/*Changes for CR_NP_0744 ends*/

			var policyHolderResponse = RestServices.postService(RestServices.urlPathsNewPortal.createPolicyHolder, policyHolderData);
			policyHolderResponse.then(
				function (response) { // success 

					CommonServices.showLoading(false);
					if (response.data.partyDetails !== undefined) {
						CommonServices.showAlert("Policy details has been successfully submitted. Your Party Code is #" + response.data.partyDetails.partyCode);
						var otherData = {
							policyHolder: this.policyHolder
						};

						var partyDetails = { "savedPartyDetails": { "partyDetails": policyHolderData.partyDetails } };
						partyDetails.savedPartyDetails.partyDetails.locality = otherData.locality;
						partyDetails.savedPartyDetails.partyDetails.policyHolder = otherData.policyHolder;
						partyDetails.savedPartyDetails.partyDetails.partyCode = response.data.partyDetails.partyCode;
						angular.extend($rootScope.travelData, partyDetails);
						$scope.policyDetailsObj.createdParty();

					} else {
						CommonServices.showAlert(response.data.errorMessage);
					}
				},
				function (error) { // failure
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
				});
		},
		continueFunc: function () {//On click of continue button
			/*Added for CR_NP_0744*/
			if ($scope.policyDetailsObj.panNoInputDisable === true) {
				CommonServices.panNoInputDisable = true;
			}
			/* CR_NP_0744E start*/
			// if($scope.policyDetailsObj.aadhaarInputDisable === true){
			// 	CommonServices.aadhaarInputDisable = true;
			// }
			/*CR_NP_0744 and CR_NP_0744E ends*/

			/*Added during CR_NP_0744, as PolicyHolder value is not available on editing the policyHolder and navigate back from Summary.*/
			$rootScope.travelData.savedPartyDetails.partyDetails.policyHolder = $scope.policyDetailsObj.policyHolder; //CR744

			CommonServices.setCommonData("partyCode", $rootScope.travelData.savedPartyDetails.partyDetails.partyCode);
			if ($rootScope.travelData.savedPartyDetails.partyDetails.individualDetails.state !== undefined && $rootScope.travelData.savedPartyDetails.partyDetails.individualDetails.state !== "") {
				$scope.continueState = $rootScope.travelData.savedPartyDetails.partyDetails.individualDetails.state;
				$scope.continueCity = $rootScope.travelData.savedPartyDetails.partyDetails.individualDetails.city;
				$scope.continuepinCode = $rootScope.travelData.savedPartyDetails.partyDetails.individualDetails.pinCode;
				if ($scope.continueState !== undefined && $scope.continueState !== "") {
					$scope.stateData = { "state": "" };
					$scope.policyDetailsObj.stateServiceCall();
				}

			}
			else {
				CommonServices.showAlert("Please enter State");
			}

		},
		createdParty: function (item) { //This is to get policy holder details
			/* CR_NP_594A starts*/
			$scope.dateOfBirthEmpty = false;
			/* CR_NP_594A ends*/
			if (this.policyHolder === "existingPolicyHolder") {
				$scope.policyHolderData = {
					"userProfile": {
						"userId": CommonServices.getCommonData("userId"),
						"loggedInRole": "SUPERUSER"
					}, "partyDetails": { "partyCode": item.partyCode }
				};
			}
//CR_0054
			else if (CommonServices.editQuoteHistory === true) { 
					$scope.policyHolderData = {
						"userProfile": {
							"userId": CommonServices.getCommonData("userId"),
							"loggedInRole": "SUPERUSER"
						}, "partyDetails": { "partyCode":CommonServices.businessHolidaysObj.partyDetailsList[0].partyCode }
					};
					$scope.policyDetailsObj.policyHolder = "existingPolicyHolder";
				}
//CR_0054
			else {
				$rootScope.travelData.savedPartyDetails.partyDetails.policyHolder = this.policyHolder;
				$scope.policyHolderData = {
					"userProfile": {
						"userId": CommonServices.getCommonData("userId"),
						"loggedInRole": "SUPERUSER"
					}, "partyDetails": { "partyCode": $rootScope.travelData.savedPartyDetails.partyDetails.partyCode }
				};
			}

			var policyHolderResponse = RestServices.postService(RestServices.urlPathsNewPortal.getPolicyHolderDetail, $scope.policyHolderData);
			policyHolderResponse.then(
				function (response) { // success 
					/*3712 Starts  //////
					if (response.data.partyDetails.individualDetails.clientCountry === undefined) {
						response.data.partyDetails.individualDetails.clientCountry = 'GA';
					}
					if (response.data.partyDetails.individualDetails.clientNationality === undefined) {
						response.data.partyDetails.individualDetails.clientNationality = 'NonIndian';
					}
					// 3712 Ends */
					$scope.partyresponse = '';
					CommonServices.showLoading(false);
					$scope.policyDetailsObj.showSearchResTbl = true;
					if (response.data.partyDetails !== undefined) {
						/*Added for CR_NP_0744*/
						if ($scope.policyDetailsObj.policyHolder === "existingPolicyHolder") {
							//To set the initial value of PAN and Aadhaar Numbers
							if (CommonServices.initialPartyCode != item.partyCode) { //If party code is changed
								CommonServices.initialPanNumberIsEmpty = false;
								/* Below line commented for CR_NP_0744E */
								//   CommonServices.initialAadhaarNoIsEmpty = false; 
							}
							CommonServices.initialPartyCode = item.partyCode;
							//For PAN Number
							if (response.data.partyDetails.individualDetails.panNumber != undefined && response.data.partyDetails.individualDetails.panNumber != "" && $scope.regexPanNo.test(response.data.partyDetails.individualDetails.panNumber)) {
								$scope.policyDetailsObj.panNoInputDisable = true;
								if (CommonServices.initialPanNumberIsEmpty == true) {
									$scope.policyDetailsObj.panNoInputDisable = false;
								}
							} else {
								$scope.policyDetailsObj.panNoInputDisable = false;
								CommonServices.initialPanNumberIsEmpty = true;
							}
							//For Aadhaar Number, Below block Commented for CR_NP_0744E
							//   if(response.data.partyDetails.individualDetails.aadhaarNo != undefined && response.data.partyDetails.individualDetails.aadhaarNo != "" && $scope.regexAadhaarNumber.test(response.data.partyDetails.individualDetails.aadhaarNo)){
							// 		$scope.policyDetailsObj.aadhaarInputDisable = true;
							// 		if(CommonServices.initialAadhaarNoIsEmpty == true){
							// 			$scope.policyDetailsObj.aadhaarInputDisable = false;
							// 		}
							// 	}else{
							// 		$scope.policyDetailsObj.aadhaarInputDisable = false;
							// 		CommonServices.initialAadhaarNoIsEmpty = true;
							// 	}
							/* CR_NP_0744E ends*/
						} else {
							$scope.policyDetailsObj.panNoInputDisable = false;
							/* Below line commented for CR_NP_0744E */
							//   $scope.policyDetailsObj.aadhaarInputDisable = false;
						}
						/*CR_NP_0744 ends*/
						/* CR_NP_594A starts*/
						if (response.data.partyDetails.individualDetails.dateOfBirth === undefined) {
							$scope.dateOfBirthEmpty = true;
						}
						/* CR_NP_594A ends*/
						$scope.policyDetailsObj.showSmallTblFunc();
						$scope.showSmallData = response.data.partyDetails;
						if ($scope.policyDetailsObj.policyHolder === "existingPolicyHolder") {
							var partyDetails = { "savedPartyDetails": { "partyDetails": response.data.partyDetails } };
							angular.extend($rootScope.travelData, partyDetails);
							$scope.showSmallData.partyCode = item.partyCode;
							$rootScope.travelData.savedPartyDetails.partyDetails.policyHolder = $scope.policyDetailsObj.policyHolder;
						}
						else {
							$scope.showSmallData.partyCode = $rootScope.travelData.savedPartyDetails.partyDetails.partyCode;
						}
						angular.extend($rootScope.travelData, $scope.showSmallData);
					} else {
						$scope.policyDetailsObj.noRecords = "No records found";
						//CommonServices.showAlert("Please try again after some time.");
					}
				},
				function (error) { // failure
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
				});
		},
		showSmallTblFunc: function () {
			$scope.policyDetailsObj.showSmallTbl = true;
			$scope.policyDetailsObj.showSearchResTbl = false;
			$scope.policyDetailsObj.existingCustomerFlag = false;
			$scope.policyDetailsObj.newcustomerFlag = false;
			$scope.policyDetailsObj.existingCustomerFlag = false;
			//$scope.policyDetailsObj.policyHolder = "existingPolicyHolder";
		},
		searchDetails: function () {

			if (this.partyCode === '' && this.EfirstName === '' && this.ElastName === '' && this.EmobileNumber === '' && this.EemailID === '') {
				CommonServices.showAlert("Enter atleast 1 input parameters to proceed with the Policy Holder search.");
				return;
			}

			$scope.searchData = {
				"userProfile": { "userId": CommonServices.getCommonData("userId"), "loggedInRole": "SUPERUSER" },
				"partyDetails": {
					"individualDetails": { "firstName": "", "lastName": "", "emailId": "", "mobileNo": "" }, "organizationDetails": {},
					"partyCode": "", "productCode": "BH", "partyType": "I"
				}, "productCode": "BH"
			};


			if (this.partyCode !== undefined) {
				if (this.partyCode !== '') {
					$scope.searchData.partyDetails.partyCode = this.partyCode.toUpperCase();
				}
			}
			if (this.EfirstName !== undefined) {
				if (this.EfirstName !== '') {
					$scope.searchData.partyDetails.individualDetails.firstName = this.EfirstName.toUpperCase();
				}
			}
			if (this.ElastName !== undefined) {
				if (this.ElastName !== '') {
					$scope.searchData.partyDetails.individualDetails.lastName = this.ElastName.toUpperCase();
				}
			}
			if (this.EmobileNumber !== undefined) {
				if (this.EmobileNumber !== '') {
					$scope.searchData.partyDetails.individualDetails.mobileNo = this.EmobileNumber;
				}
			}
			if (this.EemailID !== undefined) {
				if (this.EmobileNumber !== '') {
					$scope.searchData.partyDetails.individualDetails.emailId = this.EemailID;
				}
			}


			var policyHolderResponse = RestServices.postService(RestServices.urlPathsNewPortal.searchPolicyHolderDetails, $scope.searchData);
			policyHolderResponse.then(
				function (response) { // success 

					$scope.partyresponse = '';
					CommonServices.showLoading(false);
					$scope.policyDetailsObj.showSearchResTbl = true;
					if (response.data.partyDetailsList !== undefined) {
						$scope.partyresponse = response.data.partyDetailsList;
						$scope.policyDetailsObj.noRecords = null;
						// angular.extend($rootScope.travelData, partyDetails);
					} else {
						$scope.policyDetailsObj.noRecords = "No records found";
						//CommonServices.showAlert("Please try again after some time.");
					}
				},
				function (error) { // failure
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
				});

		},
		closePopup: function () {
			$scope.pinCodeModal = false;
		},
		setValue: function (data) { // this is to set values to the input fields at the time of edit 
			/*Added for CR_NP_0744*/
			// To set the values on load of the page
			if ($scope.policyDetailsObj.panNoInputDisable == undefined || $scope.policyDetailsObj.panNoInputDisable == "") {
				$scope.policyDetailsObj.panNoInputDisable = CommonServices.panNoInputDisable;
			}
			/* Below line commented for CR_NP_0744E */
			// if($scope.policyDetailsObj.aadhaarInputDisable == undefined || $scope.policyDetailsObj.aadhaarInputDisable == ""){
			// 	$scope.policyDetailsObj.aadhaarInputDisable = CommonServices.aadhaarInputDisable;
			// }
			/*CR_NP_0744 and CR_NP_0744E ends*/
			$scope.policyHolderForm.gstIN.$invalid = false;
			$scope.policyHolderForm.gstIN.$valid = true;

			var partyDetails = { "savedPartyDetails": { "partyDetails": { "individualDetails": data.individualDetails } } };
			partyDetails.savedPartyDetails.partyDetails.partyCode = data.partyCode;
			partyDetails.savedPartyDetails.partyDetails.policyHolder = this.policyHolder;
			angular.extend($rootScope.travelData, partyDetails);

			if (data.individualDetails.firstName !== undefined && data.individualDetails.firstName !== "")
				this.firstName = data.individualDetails.firstName;
			if (data.individualDetails.middleName !== undefined && data.individualDetails.middleName !== "")
				this.middleName = data.individualDetails.middleName;
			if (data.individualDetails.lastName !== undefined && data.individualDetails.lastName !== "")
				this.lastName = data.individualDetails.lastName;
			if (data.individualDetails.gender !== undefined && data.individualDetails.gender !== "")
				this.gender = data.individualDetails.gender;
			if (data.individualDetails.dateOfBirth !== undefined && data.individualDetails.dateOfBirth !== "")
				this.dateOfBirth = data.individualDetails.dateOfBirth;
			if (data.individualDetails.buildingNoStreet !== undefined && data.individualDetails.buildingNoStreet !== "")
				this.street = data.individualDetails.buildingNoStreet;
			if (data.individualDetails.mobileNo !== undefined && data.individualDetails.mobileNo !== "")
				this.mobileNumber = data.individualDetails.mobileNo;
			if (data.individualDetails.emailId !== undefined && data.individualDetails.emailId !== "")
				this.emailID = data.individualDetails.emailId;
			/*Changed for CR_NP_0744*/
			if (data.individualDetails.panNumber !== undefined && data.individualDetails.panNumber !== "" && $scope.regexPanNo.test(data.individualDetails.panNumber)) {
				this.panNo = data.individualDetails.panNumber;
			} else {
				this.panNo = "";
			}

			if (data.individualDetails.aadhaarNo !== undefined && data.individualDetails.aadhaarNo !== "" && $scope.regexAadhaarNumber.test(data.individualDetails.aadhaarNo)) {
				this.aadhaarNumber1 = data.individualDetails.aadhaarNo.substr(0, 4);
				this.aadhaarNumber2 = data.individualDetails.aadhaarNo.substr(4, 4);
				this.aadhaarNumber3 = data.individualDetails.aadhaarNo.substr(8, 4);
			} else {
				this.aadhaarNumber1 = "";
				this.aadhaarNumber2 = "";
				this.aadhaarNumber3 = "";
			}
			/* CR_NP_0744 ends*/
			/* 3712 Starts ///////
			if(data.individualDetails.clientNationality = "NonIndian"){
				$scope.isNonIndia = true;
			}else{
				$scope.isNonIndia = false;
			}
			if(data.individualDetails.clientNationality!=undefined && data.individualDetails.clientNationality!=''){
				$scope.isNationalityExists = true;
				this.clientNationality = data.individualDetails.clientNationality;
			}else{
				$scope.isNationalityExists = false;
			}
			if(data.individualDetails.clientCountry!=undefined && data.individualDetails.clientCountry!=''){
				$scope.isCountryExists = true;
				this.clientCountry = data.individualDetails.clientCountry;
			}else{
				$scope.isCountryExists =false;
			}
			/////3712 Ends */

			if (data.individualDetails.eInsuranceAccountNo !== undefined && data.individualDetails.eInsuranceAccountNo !== "")
				this.accountNo = data.individualDetails.eInsuranceAccountNo;
			if (data.individualDetails.gstRegIdType !== undefined && data.individualDetails.gstRegIdType !== "") {
				this.gstRegID = data.individualDetails.gstRegIdType;
			}

			if (data.individualDetails.gstin !== undefined && data.individualDetails.gstin !== "")
				this.gstINModel = data.individualDetails.gstin;
			if (data.individualDetails.uin !== undefined && data.individualDetails.uin !== "")
				this.uinModel = data.individualDetails.uin;
			if (data.individualDetails.state !== undefined && data.individualDetails.state !== "") {
				$scope.partyCode = data.partyCode;
				$scope.responseState = data.individualDetails.state;
				$scope.responseCity = data.individualDetails.city;
				$scope.responsepinCode = data.individualDetails.pinCode;
				$scope.stateData = { "state": "" };
				return $scope.policyDetailsObj.stateServiceCall();
			}

		},
		selectPolHolId: function (data) {
			this.showSmallTbl = true;
			this.showSearchResTbl = false;
			this.existingCustomerFlag = false;
			$scope.showSmallData = data;
			this.setValue(data);
		},
		viewDetails: function (data) {
			this.newcustomerFlag = true;
			this.fieldDisable = true;
			this.showSmallTbl = false;
			this.existingCustomerBtn = false;
			this.setValue(data);
		},
		minimizeForm: function () {
			this.showSmallTbl = true;
			this.newcustomerFlag = false;
			this.fieldDisable = false;
			this.existingCustomerBtn = true;
			$scope.partyCode = "";
		},
		deleteRow: function () {

			this.showSmallTbl = false;
			/*Added for CR_NP_0744*/
			CommonServices.panNoInputDisable = false;
			/* Below line commented for CR_NP_0744E */
			// CommonServices.aadhaarInputDisable = false;
			/*CR_NP_0744 ends*/
			if (this.policyHolder === "newPolicyHolder") {
				/*Added for CR_NP_0744 */
				this.panNoInputDisable = false;
				/* Below line commented for CR_NP_0744E */
				// this.aadhaarInputDisable = false;
				/*CR_NP_0744 ends*/
				this.newcustomerFlag = true;
				this.existingCustomerFlag = false;
				$scope.partyCode = "";
				this.productTitle = "";
				this.firstName = "";
				this.middleName = "";
				this.lastName = "";
				this.gender = "";
				this.dateOfBirth = "";
				this.street = "";
				this.locality = "";
				this.placeOfLoss = "";
				this.mobileNumber = "";
				this.landlineNumber = "";
				this.emailID = "";
				this.panNo = "";
				/*Added for CR_NP_0744 */
				this.aadhaarNumber1 = "";
				this.aadhaarNumber2 = "";
				this.aadhaarNumber3 = "";
				/*CR_NP_0744 ends*/
				this.accountNo = "";
				this.gstRegID = "";
				this.gstINModel = "";
				this.uinModel = "";
				this.contState = "";
				this.countryCity = "";
			}
			else {
				this.existingCustomerFlag = true;
				this.newcustomerFlag = false;
			}

		},
		updateDetails: function () { // this is to update policy holder detail
			/*Changed for CR_NP_0744*/
			if (this.aadhaarNumber1 != undefined && this.aadhaarNumber1 != '' && this.aadhaarNumber2 != undefined && this.aadhaarNumber2 != '' && this.aadhaarNumber3 != undefined && this.aadhaarNumber3 != '') {
				$scope.policyDetailsObj.aadhaarNumber = this.aadhaarNumber1 + this.aadhaarNumber2 + this.aadhaarNumber3;
			} else {
				$scope.policyDetailsObj.aadhaarNumber = "";
			}

			if ($rootScope.travelData.savedPartyDetails.partyDetails.individualDetails.mobileNo === this.mobileNumber && $rootScope.travelData.savedPartyDetails.partyDetails.individualDetails.emailId === this.emailID
				&& $rootScope.travelData.savedPartyDetails.partyDetails.individualDetails.panNumber === this.panNo
				&& $rootScope.travelData.savedPartyDetails.partyDetails.individualDetails.gstRegIdType === this.gstRegID && $rootScope.travelData.savedPartyDetails.partyDetails.individualDetails.gstin === this.gstINModel
				&& $rootScope.travelData.savedPartyDetails.partyDetails.individualDetails.uin === this.uinModel && $rootScope.travelData.savedPartyDetails.partyDetails.individualDetails.city === this.countryCity.cityCode
				&& $rootScope.travelData.savedPartyDetails.partyDetails.individualDetails.state === this.contState.stateCode && $rootScope.travelData.savedPartyDetails.partyDetails.individualDetails.pinCode === this.placeOfLoss
				&& $rootScope.travelData.savedPartyDetails.partyDetails.individualDetails.buildingNoStreet === this.street && 
				$rootScope.travelData.savedPartyDetails.partyDetails.individualDetails.dateOfBirth === this.dateOfBirth 
				/* 3712 Starts
				&& $rootScope.travelData.savedPartyDetails.partyDetails.individualDetails.clientNationality === this.clientNationality 
				&& $rootScope.travelData.savedPartyDetails.partyDetails.individualDetails.clientCountry === this.clientCountry.stateCode 
				3712 Ends*/) {// If nothing has changed

				$scope.partyCode = "";
				this.fieldDisable = false;
				$scope.policyDetailsObj.showSmallTblFunc();
			}
			else {// if there are changes in values
				var updatepolicyHolderData =
					{
						"userCode": CommonServices.getCommonData("userId"),
						"rolecode": "SUPERUSER",
						"policyHolderCode": $scope.showSmallData.partyCode,
						"mobileNo": this.mobileNumber,
						"gstRegIdType": this.gstRegID,
						"gstin": this.gstINModel,
						"dateOfBirth": $scope.policyDetailsObj.dateOfBirth,
						/* 3712 Starts 
						"clientNationality": $scope.policyDetailsObj.clientNationality,//3712
						"clientCountry": $scope.policyDetailsObj.clientCountry,//3712
						// 3712 Ends */
						"uin": this.uinModel !== undefined ? this.uinModel : "",
						"city": this.countryCity.cityCode,
						"state": this.contState.stateCode,
						"pinCode": this.placeOfLoss, // CR_NP_0880
						"addressLine1": this.street,
						"emailId": this.emailID !== undefined ? this.emailID : "",
						/*Added for CR_NP_0744*/
						"panNumber": this.panNo,
						"aadhaarNo": $scope.policyDetailsObj.aadhaarNumber
						/*CR_NP_0744 ends*/
					};

				var updatePolicyHolderContact = RestServices.postService(RestServices.urlPathsNewPortal.updatePolicyHolderContact, updatepolicyHolderData);
				updatePolicyHolderContact.then(
					function (response) { // success 

						CommonServices.showLoading(false);
						if (response.data.errorCode === undefined) {
							if (response.data.pRetCode === "0") {

								var updatePolicyData = {
									"savedPartyDetails": {
										"partyDetails": {
											"individualDetails": {
												"firstName": $scope.policyDetailsObj.firstName,
												"lastName": $scope.policyDetailsObj.lastName,
												"middleName": $scope.policyDetailsObj.middleName,
												"gender": $scope.policyDetailsObj.gender,
												"dateOfBirth": $scope.policyDetailsObj.dateOfBirth,
												"buildingNoStreet": $scope.policyDetailsObj.street,
												"pinCode": $scope.policyDetailsObj.placeOfLoss, // CR_NP_0880
												"mobileNo": $scope.policyDetailsObj.mobileNumber,
												"emailId": $scope.policyDetailsObj.emailID,
												"panNumber": $scope.policyDetailsObj.panNo,
												"aadhaarNo": $scope.policyDetailsObj.aadhaarNumber,
												"eInsuranceAccountNo": $scope.policyDetailsObj.accountNo,
												"gstRegIdType": $scope.policyDetailsObj.gstRegID,
												"gstin": $scope.policyDetailsObj.gstINModel,
												"uin": $scope.policyDetailsObj.uinModel,
												"city": $scope.policyDetailsObj.countryCity.cityCode,
												"state": $scope.policyDetailsObj.contState.stateCode
											},
											"partyType": $scope.policyDetailsObj.category
										}
									}
								};
								/*CR_NP_0744 changes ends*/
								$scope.partyCode = "";
								angular.extend($rootScope.travelData, updatePolicyData);
								CommonServices.showAlert(response.data.pRetErr);
								$scope.policyDetailsObj.fieldDisable = false;
								$scope.showSmallData = $rootScope.travelData.savedPartyDetails.partyDetails;
								/* CR_NP_594A starts*/
								$scope.dateOfBirthEmpty = false;
								/* CR_NP_594A ends*/
								$scope.policyDetailsObj.showSmallTblFunc();
								updatePolicyData.savedPartyDetails.partyDetails.partyCode = response.data.policyHolderCode;
								angular.extend($rootScope.travelData, updatePolicyData);
							} else {
								CommonServices.showAlert("Please try again after some time.");
							}
						}
						else {
							CommonServices.showAlert(response.data.errorMessage);
						}

					},
					function (error) { // failure
						CommonServices.showLoading(false);
						RestServices.handleWebServiceError(error);
					});
			}

		}
	};
//CR_0054
	if(CommonServices.editQuoteHistory === true){
	$scope.policyDetailsObj.showSearchResTbl = true;
	$scope.policyDetailsObj.showSmallTblFunc();
	var partyCodeObj={};
	partyCodeObj.partyCode=CommonServices.getCommonData("policyHolderObj").partyCode;
	$scope.policyDetailsObj.createdParty(partyCodeObj);
	}
//CR_0054
	$scope.calIconClick = function (event) {
		angular.element("#" + event.currentTarget.children[0].id).focus();
	};

	$scope.back = function () {
		$rootScope.backFlag = "travelSummary";
		$state.go("businessHolidays.travelSummary");
	}

	if ($rootScope.backFlag === "travellerDetails" || $rootScope.travelData.savedPartyDetails !== undefined) {
		$scope.policyDetailsObj.showSmallTblFunc();
		$scope.showSmallData = $rootScope.travelData.savedPartyDetails.partyDetails;
		$scope.policyDetailsObj.policyHolder = $rootScope.travelData.savedPartyDetails.partyDetails.policyHolder;

	}


}]);

agentApp.controller('travellerDetailsCtrl', ['$scope', 'RestServices', 'CommonServices', '$state', '$rootScope', function ($scope, RestServices, CommonServices, $state, $rootScope) {

	$scope.back = function () {
		$rootScope.backFlag = "travellerDetails";
		$state.go('businessHolidays.policyHolderInfo');
	};

	var mydateStr = new Date();
	var mynewdateFrom = "";
	if (mydateStr != undefined) {
		mynewdateFrom = new Date(mydateStr);
	}
	else {
		mynewdateFrom = new Date();
	}


	/**Passport Expiry Date**/
	var dateOfBirthfrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear()));
	dateOfBirthfrom = new Date(dateOfBirthfrom.setDate(dateOfBirthfrom.getDate()));
	dateOfBirthfrom = getFormattedDate(dateOfBirthfrom);

	var dateOfBirthTo = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() + 5000));
	dateOfBirthTo = new Date(dateOfBirthTo.setMonth(dateOfBirthTo.getMonth()));
	dateOfBirthTo = new Date(dateOfBirthTo.setDate(dateOfBirthTo.getDate()));
	dateOfBirthTo = getFormattedDate(dateOfBirthTo);
	/**Passport Expiry Date**/


	$('#passportExpiry').loadCalendar({
		'enableDateRange': true,
		'enableCalendarFrom': dateOfBirthfrom,
		'enableCalendarTo': dateOfBirthTo
	});


	$scope.dateCompare = function () {

		var dt1 = $scope.travellerDetailsObj.passportExpiry.split('/'),
			passportExpiryComp = dt1[1] + '/' + dt1[0] + '/' + dt1[2], //mm/dd/yyyy
			dt2 = $rootScope.travelData.leaveDate.split('/'),
			leaveDateComp = dt2[1] + '/' + dt2[0] + '/' + dt2[2];

		passportExpiryComp = new Date(passportExpiryComp);
		leaveDateComp = new Date(leaveDateComp);


		if (passportExpiryComp < leaveDateComp) {
			$scope.travellerDetailsObj.passportExpiryErr = true;
		}
		else {
			$scope.travellerDetailsObj.passportExpiryErr = false;
		}
	}

	$scope.rootDateCompare = function () {
		var dt1 = $rootScope.travelData.saveTravellerDetails.risks[0].riskDetails.passportExpiryDate.split('/'),
			passportExpiryComp = dt1[1] + '/' + dt1[0] + '/' + dt1[2], //mm/dd/yyyy
			dt2 = $rootScope.travelData.leaveDate.split('/'),
			leaveDateComp = dt2[1] + '/' + dt2[0] + '/' + dt2[2];

		passportExpiryComp = new Date(passportExpiryComp);
		leaveDateComp = new Date(leaveDateComp);


		if (passportExpiryComp < leaveDateComp) {
			$scope.travellerDetailsObj.passportExpiryErr = true;
		}
		else {
			$scope.travellerDetailsObj.passportExpiryErr = false;
		}
	}

	$scope.travellerDetailsObj = {
		nationality: "INDIAN",
		sufferingNoDesease: false,
		sumInsured: "100000",
		mediClaimDetails: false,
		passportExpiryErr: false,
		titleVal: [{
			id: "OTHERS",
			name: "Any Other"
		}, {
			id: "BUSINESS",
			name: "Business/ Traders"
		},
		{
			id: "CLERK",
			name: "Clerical, Supervisory and Related Workers"
		},
		{
			id: "AGRICULTUR",
			name: "Farmers and Agricultural Workers"
		},
		{
			id: "SUPPORT",
			name: "Hospitality and Support Workers"
		},
		{
			id: "HOUSEWIFE",
			name: "Housewife"
		},
		{
			id: "SERVICE",
			name: "Police / Para Military / Defense"
		},
		{
			id: "LABOUR",
			name: "Production Workers, Skilled and Non-agricultural Labourers"
		},
		{
			id: "PROFESSION",
			name: "Professional / Administrative / Managerial"
		},
		{
			id: "RETIRED",
			name: "Retired Persons"
		},
		{
			id: "STUDENT",
			name: "Students - School and College"
		}],
		relationVal: [{
			id: "SON",
			name: "Son"
		},
		{
			id: "DAUGHTER",
			name: "Daughter"
		},
		{
			id: "FATHER",
			name: "Father"
		},
		{
			id: "SPOUSE",
			name: "Spouse"
		},
		{
			id: "MOTHER",
			name: "Mother"
		},
		{
			id: "OTHERS",
			name: "Other"
		}],
		passportExpiryFunc: function () {
			$scope.dateCompare();
		},
		saveDetails: function () { // On click of save in Traveller Details


			if (this.policyNo === undefined)
				this.policyNo = "";
			if (this.policyPeriod === undefined)
				this.policyPeriod = "";
			if (this.preexistingDisease === undefined)
				this.preexistingDisease = "";

			var saveTravellerDetails =
				{
					"quote": {
						"additionalPAOMPQuoteDetails": {
						/**CR_3658: set doYouHaveMediclaim2007PolicyWithNewIndia to default "No", dependent parameters removed(not in portal too)*/								
						"doYouHaveMediclaim2007PolicyWithNewIndia": "N",
						// "policyNumber": "",
						// "policyPeriod": "",
						// "sumInsured": "100000",
						// "detailsOfPreExistingDiseases": ""
						},
						"premiumDetails": $rootScope.travelData.calPremiumQuote.premiumDetails,
						"risks": [
							{
								"riskDetails": {
									"medicalHistoryDetails": {
										"preExistingDiseaseForMediclaimMember": "N"
									},
									"financierDetails": {

									},
									"discountDetails": {

									},
									"nomineeDetails": {
										"name": this.nominee,
										"relationshipWithInsured": this.relation
									},
									"occupation": this.occupation,
									"nationality": this.nationality,
									"passportNo": this.passportNo,
									"passportExpiryDate": this.passportExpiry,
									"visaWorkPermit": this.visaType,
									"proposedDateOfDeparture": $rootScope.travelData.leaveDate,
									"noOfDaysStayedOutsideIndia": $rootScope.travelData.noOfDaysStayedOutsideIndia
								},
								"coverages": [
									{
										"coverDetails": {
											"planType": $rootScope.travelData.planType,
											"travelDestination": $rootScope.travelData.destination,
											"categoryType": $rootScope.travelData.travelPurpose
										}
									}
								]
							}
						],
						"policyHolderCode": $rootScope.travelData.savedPartyDetails.partyDetails.partyCode,
						"quoteNumber": $rootScope.travelData.calPremiumQuote.quoteNumber,
						"productCode": "BH",
						"policyStartDate": $rootScope.travelData.leaveDate,
						"policyExpiryDate": $rootScope.travelData.returnDate,
						"dateOfBirth": $rootScope.travelData.savedPartyDetails.partyDetails.individualDetails.dateOfBirth,
						"term": $rootScope.travelData.noOfDaysStayedOutsideIndia
					},
					"userProfile": {
						"userId": CommonServices.getCommonData("userId"),
						"loggedInRole": "SUPERUSER"
					}
				};

			var travellerDetails = { "saveTravellerDetails": saveTravellerDetails.quote };

			angular.extend($rootScope.travelData, travellerDetails);

			var saveQuoteResponse = RestServices.postService(RestServices.urlPathsNewPortal.saveQuote, saveTravellerDetails);
			saveQuoteResponse.then(
				function (response) { // success 
					CommonServices.setCommonData("productCode", "BH");
					CommonServices.showLoading(false);
					if (response.data !== undefined && response.data !== "") {
						if (response.data.userProfile !== undefined) {
							if (response.data.userProfile.footer.errorCode === "1") {
								//CommonServices.showAlert(response.data.userProfile.footer.errorDescription);

								var msg = response.data.userProfile.footer.errorDescription;
								CommonServices.messageModal('info', msg, false, '', 'Ok', function () {}, function () { paymentExitFunction(1);}, 'Alert');
								// if (CommonServices.deviceType !== "NA")
								// 	navigator.notification.confirm(response.data.userProfile.footer.errorDescription, paymentExitFunction, "Alert", ["Ok"]);
								// else {
								// 	var approvePayment;
								// 	approvePayment = confirm(response.data.userProfile.footer.errorDescription);
								// 	if (approvePayment === true) {
								// 		paymentExitFunction(1);
								// 	}
								// }

								var travellerDetailsResponse = { "travellerDetailsResponse": response.data.quote };
								angular.extend($rootScope.travelData, travellerDetailsResponse);
								//$rootScope.travelData.saveTravellerDetailsInput = saveTravellerDetails;// Save SaveQuote input if user will go back to travel details this has to pass in calculate premium

								CommonServices.setCommonData("CollectionPaymentDetails", $rootScope.travelData.travellerDetailsResponse);

							} else {
								CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
							}
						}
						else {
							CommonServices.showAlert(response.data.errorMessage);
						}
					}
					else {
						CommonServices.showAlert("Please try after some time");
					}

				},
				function (error) { // failure
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
				});
		},
		mediClaimFunc: function (data) {
			if (data === 'Y') {
				this.mediClaimDetails = true;
			}
			else {
				this.mediClaimDetails = false;
			}
		}
	}

	function paymentExitFunction(button) {
		if (button == 1) {
			$state.go("businessHolidays.paymentDetails");
		}
	}

	if ($scope.travellerDetailsObj.passportExpiry !== undefined && $scope.travellerDetailsObj.passportExpiry !== "") {
		$scope.dateCompare();
	}

	if ($rootScope.travelData.saveTravellerDetails !== undefined && $rootScope.travelData.saveTravellerDetails !== "") {
		if ($rootScope.travelData.saveTravellerDetails.risks[0].riskDetails.passportExpiryDate !== undefined && $rootScope.travelData.saveTravellerDetails.risks[0].riskDetails.passportExpiryDate !== "") {
			$scope.rootDateCompare();
		}
	}
	/******CR_0054*******/
	if(CommonServices.editQuoteHistory === true){
	   $scope.travellerDetailsObj.passportNo=CommonServices.businessHolidaysObj.risks[0].riskDetails.passportNo;
	   $scope.travellerDetailsObj.passportExpiry=CommonServices.businessHolidaysObj.risks[0].riskDetails.passportExpiryDate;
	   $scope.travellerDetailsObj.visaType=CommonServices.businessHolidaysObj.risks[0].riskDetails.visaWorkPermit;
	   $scope.occup=CommonServices.businessHolidaysObj.risks[0].riskDetails.occupation;
	   $scope.travellerDetailsObj.nominee=CommonServices.businessHolidaysObj.risks[0].riskDetails.nomineeDetails.name;
	   $scope.relationship=CommonServices.businessHolidaysObj.risks[0].riskDetails.nomineeDetails.relationshipWithInsured;	
	}
	/******CR_0054*******/
	$scope.calIconClick = function (event) {
		angular.element("#" + event.currentTarget.children[0].id).focus();
	};


	if ($rootScope.backFlag === "paymentDetails" || $rootScope.travelData.saveTravellerDetails !== undefined) {
		if ($rootScope.travelData.saveTravellerDetails.additionalPAOMPQuoteDetails.doYouHaveMediclaim2007PolicyWithNewIndia !== undefined && $rootScope.travelData.saveTravellerDetails.additionalPAOMPQuoteDetails.doYouHaveMediclaim2007PolicyWithNewIndia !== "")
			$scope.travellerDetailsObj.mediClaim = $rootScope.travelData.saveTravellerDetails.additionalPAOMPQuoteDetails.doYouHaveMediclaim2007PolicyWithNewIndia;
	/**CR_3658: set doYouHaveMediclaim2007PolicyWithNewIndia to default "No", Dependepnt parameters removed(not in portal too)*/	

		// if ($rootScope.travelData.saveTravellerDetails.additionalPAOMPQuoteDetails.policyNumber !== undefined && $rootScope.travelData.saveTravellerDetails.additionalPAOMPQuoteDetails.policyNumber !== "")
		// 	$scope.travellerDetailsObj.policyNo = $rootScope.travelData.saveTravellerDetails.additionalPAOMPQuoteDetails.policyNumber;
		// if ($rootScope.travelData.saveTravellerDetails.additionalPAOMPQuoteDetails.policyPeriod !== undefined && $rootScope.travelData.saveTravellerDetails.additionalPAOMPQuoteDetails.policyPeriod !== "")
		// 	$scope.travellerDetailsObj.policyPeriod = $rootScope.travelData.saveTravellerDetails.additionalPAOMPQuoteDetails.policyPeriod;
		// if ($rootScope.travelData.saveTravellerDetails.additionalPAOMPQuoteDetails.detailsOfPreExistingDiseases !== undefined && $rootScope.travelData.saveTravellerDetails.additionalPAOMPQuoteDetails.detailsOfPreExistingDiseases !== "")
		// 	$scope.travellerDetailsObj.preexistingDisease = $rootScope.travelData.saveTravellerDetails.additionalPAOMPQuoteDetails.detailsOfPreExistingDiseases;
		if ($rootScope.travelData.saveTravellerDetails.risks.length >= 0) {

			if ($rootScope.travelData.saveTravellerDetails.risks[0].riskDetails.nomineeDetails.name !== undefined && $rootScope.travelData.saveTravellerDetails.risks[0].riskDetails.nomineeDetails.name !== "")
				$scope.travellerDetailsObj.nominee = $rootScope.travelData.saveTravellerDetails.risks[0].riskDetails.nomineeDetails.name;
			if ($rootScope.travelData.saveTravellerDetails.risks[0].riskDetails.nomineeDetails.relationshipWithInsured !== undefined && $rootScope.travelData.saveTravellerDetails.risks[0].riskDetails.nomineeDetails.relationshipWithInsured !== "")
				$scope.relationship = $rootScope.travelData.saveTravellerDetails.risks[0].riskDetails.nomineeDetails.relationshipWithInsured;
			if ($rootScope.travelData.saveTravellerDetails.risks[0].riskDetails.occupation !== undefined && $rootScope.travelData.saveTravellerDetails.risks[0].riskDetails.occupation !== "")
				$scope.occup = $rootScope.travelData.saveTravellerDetails.risks[0].riskDetails.occupation;
			if ($rootScope.travelData.saveTravellerDetails.risks[0].riskDetails.passportNo !== undefined && $rootScope.travelData.saveTravellerDetails.risks[0].riskDetails.passportNo !== "")
				$scope.travellerDetailsObj.passportNo = $rootScope.travelData.saveTravellerDetails.risks[0].riskDetails.passportNo;
			if ($rootScope.travelData.saveTravellerDetails.risks[0].riskDetails.passportExpiryDate !== undefined && $rootScope.travelData.saveTravellerDetails.risks[0].riskDetails.passportExpiryDate !== "")
				$scope.travellerDetailsObj.passportExpiry = $rootScope.travelData.saveTravellerDetails.risks[0].riskDetails.passportExpiryDate;
			if ($rootScope.travelData.saveTravellerDetails.risks[0].riskDetails.visaWorkPermit !== undefined && $rootScope.travelData.saveTravellerDetails.risks[0].riskDetails.visaWorkPermit !== "")
				$scope.travellerDetailsObj.visaType = $rootScope.travelData.saveTravellerDetails.risks[0].riskDetails.visaWorkPermit;
		}

	}


}]);

agentApp.controller('paymentDetailsCtrl', ['$scope', 'RestServices', 'CommonServices', '$state', '$rootScope','CartServices', function ($scope, RestServices, CommonServices, $state, $rootScope,CartServices) {

	/**CR690 Start**/
	$rootScope.panmodalOpen = false;

	var panCardDetails = {
		"quoteNumber": $rootScope.travelData.travellerDetailsResponse.quoteNumber,
		"policyHolderCode": CommonServices.getCommonData("partyCode")
	}
	CommonServices.setCommonData("panCardData", panCardDetails);
	/**CR690 End**/

	$scope.home = function () {
		$rootScope.backFlag = "paymentDetails";
		$state.go("businessHolidays.travellerDetails");
	}
	$scope.travelSummary = $rootScope.travelData;

	$scope.editDetails = function (data) {
		if (data === "travelDetails") {
			$rootScope.backFlag = "travelSummary";
			$state.go("businessHolidays.travelDetails");
		}
		if (data === "policyHolderDetails") {
			$rootScope.backFlag = "travellerDetails";
			$state.go("businessHolidays.policyHolderInfo");
		}
		if (data === "travellerDetails") {
			$rootScope.backFlag = "paymentDetails";
			$state.go("businessHolidays.travellerDetails");
		}
	}

	$scope.closePopup = function () {
		$scope.travelPlanShow = false;
	}

	if ($rootScope.travelData !== undefined && $rootScope.travelData !== "") {
		if ($rootScope.travelData.savedPartyDetails.partyDetails.individualDetails.gstin !== undefined && $rootScope.travelData.savedPartyDetails.partyDetails.individualDetails.gstin !== "")
			$rootScope.travelData.savedPartyDetails.partyDetails.individualDetails.gstin = $rootScope.travelData.savedPartyDetails.partyDetails.individualDetails.gstin.toUpperCase();
		if ($rootScope.travelData.savedPartyDetails.partyDetails.individualDetails.uin !== undefined && $rootScope.travelData.savedPartyDetails.partyDetails.individualDetails.uin !== "")
			$rootScope.travelData.savedPartyDetails.partyDetails.individualDetails.uin = $rootScope.travelData.savedPartyDetails.partyDetails.individualDetails.uin.toUpperCase();
	}

	$scope.buyNow = false;
	$scope.buyNow = function () {
		$scope.buyNow = true;
	}


	$scope.approvePay = function (type = '') {
		var msg = "Do you wish to proceed with approval of quotation? Once Approved, no more changes will be made available on your quotation. Your payment should be made by " + $rootScope.travelData.leaveDate + " 23:59:59. Please confirm.";
		CommonServices.setCommonData("addToCart", type); // CR3546
		CommonServices.messageModal('info', msg, false, 'Cancel', 'Confirm', function () {}, function () { exitFunction(1);}, 'Alert');
		// if (CommonServices.deviceType !== "NA")
		// 	navigator.notification.confirm("Do you wish to proceed with approval of quotation? Once Approved, no more changes will be made available on your quotation. Your payment should be made by " + $rootScope.travelData.leaveDate + " 23:59:59. Please confirm.", exitFunction, "Alert", ["Confirm", "Cancel"]);
		// else {
		// 	var approvePayment;
		// 	approvePayment = confirm("Do you wish to proceed with approval of quotation? Once Approved, no more changes will be made available on your quotation. Your payment should be made by " + $rootScope.travelData.leaveDate + " 23:59:59. Please confirm.");
		// 	if (approvePayment === true) {
		// 		exitFunction(1);
		// 	}
		// }
	}

	$scope.buyLater = function () {
		var msg = "Are you sure you want to navigate back to home screen ? All the entered data will be lost";
		CommonServices.messageModal('info', msg, false, 'Cancel', 'Ok', function () {}, function () { goBack(1);}, 'Alert');

		// if (CommonServices.deviceType !== "NA")
		// 	navigator.notification.confirm("Are you sure you want to navigate back to home screen ? All the entered data will be lost", goBack, "Alert", ["Ok", "Cancel"]);
		// else {
		// 	var approvePayment;
		// 	approvePayment = confirm("Are you sure you want to navigate back to home screen ? All the entered data will be lost");
		// 	if (approvePayment === true) {
		// 		goBack(1);
		// 	}
		// }
	}
	function goBack(button) {
		if (button == 1) {
			$state.go("home");
		}
	}

	$scope.downloadDoc = function () {
		$scope.documentData = JSON.stringify({ "alfrescoInput": { "typeOfContent": "Documents", "productName": "BH", "process": "PaymentSummary", "language": "English", "channel": "AGENT" } });
		productContentResponse = RestServices.postService(RestServices.urlPathsNewPortal.getContent, $scope.documentData);
		productContentResponse.then(
			function (response) {
				CommonServices.showLoading(false);
				$scope.content = response.data.contentDataList;
			},
			function (error) {
				CommonServices.showLoading(false);
				RestServices.headerWithoutToken = false;
			});
	}

	$scope.downloadDoc();

	$scope.download = function (url, docName) {

		try {
			window.appRootDirName = "NIAAgentDoc";
			window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, CommonServices.gotFS, CommonServices.fail);

			var fileTransfer = new FileTransfer();
			var url = url;
			var filePath;
			var docName = docName;


			if (navigator.userAgent.match(/iPhone|iPad|iPod/i)) {
				filePath = window.appRootDir.nativeURL + docName;
			}
			else if (navigator.userAgent.match(/Android/i)) {

				filePath = fileSystem.root.toURL() + "NIAAgentDoc/" + docName;
			}
			else {
				filePath = false;
			}
			CommonServices.showLoading(false);
			if (navigator.userAgent.match(/iPhone|iPad|iPod/i)) {
				window.open(url, '_system', 'location=no');
				return;
			}
			fileTransfer.download(url, filePath, function (theFile) {
				if (navigator.userAgent.match(/iPhone|iPad|iPod/i)) {
					window.open(url, '_system', 'location=no');
				}
				else if (navigator.userAgent.match(/Android/i)) {
					window.open(filePath, '_system', 'location=no');
				}
			},
				function (error) {

					CommonServices.showAlert("Download not successful, please try again after some time");
					CommonServices.showLoading(false);
				},
				true
			);

		} catch (err) {

			$scope.counter = false;
			CommonServices.showLoading(false);
			CommonServices.showAlert("Please insert SD Card to download documents");
		} finally {

		}

	}

	$scope.hideModal = function () {
		$scope.travelPlanShow = false;
	};

	$scope.viewBreakup = function () {
		$scope.travelPlanShow = true;
	}

	function exitFunction(button) {
		if (button == 1) {

			var approvePayData = {
				"userProfile": { "userId": CommonServices.getCommonData("userId"), "loggedInRole": "SUPERUSER", "uiFlow": "NON_CUSTOMER" },
				"quote": { "quoteNumber": $rootScope.travelData.travellerDetailsResponse.quoteNumber, "policyType": null, "productCode": CommonServices.getCommonData("productCode") }
			};

			if (CommonServices.getCommonData("addToCart")==='cart') { // CR3546
				CartServices.approveAndAddToCart(approvePayData, CommonServices.getCommonData("productCode"));
				return;
			}

			var approvePayResponse = RestServices.postService(RestServices.urlPathsNewPortal.approveRenewedQuote, approvePayData);
			approvePayResponse.then(
				function (response) { // success 

					CommonServices.showLoading(false);
					if (response.data.userProfile.footer.errorDescription.trim() === "Proposal Approved") {
						//Will navigate to billdesk page.
						
						var msg = response.data.userProfile.footer.errorDescription;
						CommonServices.messageModal('info', msg, false, '', 'Ok', function () {}, function () { approvePayExitFunction(1);}, 'Alert');

						// if (CommonServices.deviceType !== "NA")
						// 	navigator.notification.confirm(response.data.userProfile.footer.errorDescription, approvePayExitFunction, "Alert", ["Ok"]);
						// else {
						// 	var approvePayment;
						// 	approvePayment = confirm(response.data.userProfile.footer.errorDescription);
						// 	if (approvePayment === true) {
						// 		approvePayExitFunction(1);
						// 	}
						// }

					} else {
						/**CR690 Start**/
						if (response.data.userProfile.footer.errorCode === "224541") {
							$rootScope.panmodalOpen = true;
							CommonServices.setCommonData("setPanMsg", response.data.userProfile.footer.errorDescription);
						}
						/**CR690 End**/
						else {
							CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
						}

					}
				},
				function (error) { // failure
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
				});
		}
	}

	function approvePayExitFunction(button) {
		$state.go("collectionForm");
	}

}]);

agentApp.controller('mediClaimCtrl', ['$scope', 'RestServices', 'CommonServices', '$state', '$rootScope', function ($scope, RestServices, CommonServices, $state, $rootScope) {

	$scope.back = function () {
		$state.go('managePolicies.managePolicies');
	}

	var mydateStr = new Date();
	var mynewdateFrom = "";
	if (mydateStr != undefined) {
		mynewdateFrom = new Date(mydateStr);
	}
	else {
		mynewdateFrom = new Date();
	}

	/**Passport Expiry Date**/
	var dateOfBirthfrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear()));
	dateOfBirthfrom = new Date(dateOfBirthfrom.setDate(dateOfBirthfrom.getDate()));
	dateOfBirthfrom = getFormattedDate(dateOfBirthfrom);

	var dateOfBirthTo = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() + 61));
	dateOfBirthTo = new Date(dateOfBirthTo.setMonth(dateOfBirthTo.getMonth()));
	dateOfBirthTo = new Date(dateOfBirthTo.setDate(dateOfBirthTo.getDate()));
	dateOfBirthTo = getFormattedDate(dateOfBirthTo);
	/**Passport Expiry Date**/


	$('#monthsExtension').loadCalendar({
		'enableDateRange': true,
		'enableCalendarFrom': dateOfBirthfrom,
		'enableCalendarTo': dateOfBirthTo
	});



	$scope.mediclaimObj = {
		dateDiff: false,
		calculate: false,
		dayBHExtensionErr: false,
		dateCompare: function (leaveDate, returnDate) {
			if (leaveDate !== undefined && returnDate !== undefined) {
				var leaveDateComp = leaveDate;
				var drr = leaveDateComp.split('/');
				leaveDateComp = drr[1] + '/' + drr[0] + '/' + drr[2]; //mm/dd/yyyy

				var returnDateComp = returnDate;
				var srr = returnDateComp.split('/');
				returnDateComp = srr[1] + '/' + srr[0] + '/' + srr[2]; //mm/dd/yyyy

				leaveDateComp = new Date(leaveDateComp);
				returnDateComp = new Date(returnDateComp);

				this.dayDiff(leaveDate, returnDate);
				this.dateDiff = true;
			}

		},
		extensionVal: [{
			id: "1",
			name: "1"
		}, {
			id: "2",
			name: "2"
		}, {
			id: "3",
			name: "3"
		}, {
			id: "4",
			name: "4"
		}, {
			id: "5",
			name: "5"
		}, {
			id: "6",
			name: "6"
		}, {
			id: "7",
			name: "7"
		}, {
			id: "8",
			name: "8"
		}, {
			id: "9",
			name: "9"
		}, {
			id: "10",
			name: "10"
		}, {
			id: "11",
			name: "11"
		}, {
			id: "12",
			name: "12"
		}],
		dayDiff: function (firstDate, secondDate) {

			var dt1 = firstDate.split('/'),
				dt2 = secondDate.split('/'),
				one = new Date(dt1[2], (dt1[1] - 1), dt1[0]),
				two = new Date(dt2[2], (dt2[1] - 1), dt2[0]);

			var millisecondsPerDay = 1000 * 60 * 60 * 24;
			var millisBetween = two.getTime() - one.getTime();
			if (this.dateDiff === true) {
				this.dayExten = (millisBetween / millisecondsPerDay) + 1;
				this.dayExten = parseInt(this.dayExten);
				if (this.dayExten < 1) {
					this.dayDiffValid = false;
				}
				else {
					this.dayDiffValid = true;
				}
			}
			else {
				this.dayDifference = (millisBetween / millisecondsPerDay);
				this.dayDifference = parseInt(this.dayDifference);
				if (this.dayDifference < 1) {
					this.dayDiffValid = false;
				}
				else {
					this.dayDiffValid = true;
				}
			}

		},
		monthDiff: function (d1, d2) {
			return d2.getMonth() - d1.getMonth() + (12 * (d2.getFullYear() - d1.getFullYear()));
		},
		monthsExtensionFunc: function () {

			if ($scope.mediclaimObj.policyResult.productCode === "ES") {
				var leaveDateComp = $scope.mediclaimObj.policyResult.policyStartDate,
					drr = leaveDateComp.split('/');
				leaveDateComp = drr[1] + '/' + drr[0] + '/' + drr[2]; //mm/dd/yyyy

				var returnDateComp = $scope.mediclaimObj.policyResult.policyExpiryDate,
					drr1 = returnDateComp.split('/');
				returnDateComp = drr1[1] + '/' + (drr1[0] - 1) + '/' + drr1[2]; //mm/dd/yyyy

				var date2 = new Date(leaveDateComp);
				$scope.date1 = new Date(returnDateComp);
				$scope.date1.setMonth($scope.date1.getMonth() + parseInt(this.monthsExtension));

				$scope.month = this.monthDiff(new Date(date2.getFullYear(), date2.getMonth(), date2.getDate()), new Date($scope.date1.getFullYear(), $scope.date1.getMonth(), $scope.date1.getDate()));

				if ($scope.month < 13) {
					this.policyDuration = parseInt(this.monthsExtension);
				}

			}
			if ($scope.mediclaimObj.policyResult.productCode === "BH") {
				this.dateDiff = false;
				this.dateCompare($scope.mediclaimObj.policyResult.policyExpiryDate, this.monthsExtension);
				this.dayDiff($scope.mediclaimObj.policyResult.policyStartDate, this.monthsExtension);
				this.daysExtension = this.dayDifference;
				this.policyDuration = this.dayExten;
				if (this.daysExtension < 1) {
					this.dayBHExtensionErr = true;
					$scope.employmentForm1.$invalid = true;
				}
				else {
					this.dayBHExtensionErr = false;
					$scope.employmentForm1.$invalid = false;
				}
			}

		},
		healthRadio: function (data) {
			if (data === "yes")
				$scope.healthVal = "Y";
			else {
				CommonServices.showAlert("Policy cannot be extended as the insured is currently not in good health. Please contact nearest NIA office for extension");
				$scope.healthVal = "N";
			}

		},
		calPremium: function () {
			if ($scope.mediclaimObj.policyResult.productCode === "BH") {
				if (this.daysExtension < 1) {
					return;
				}

			}

			if ($scope.healthVal === "N") {
				this.calculate = false;
				CommonServices.showAlert("Policy cannot be extended as the insured is currently not in good health. Please contact nearest NIA office for extension");
				return false;
			}
			else {

				var policyExtensionData = {
					"userProfile": { "userId": CommonServices.getCommonData("userId"), "loggedInRole": "SUPERUSER" },
					"quote": {
						"policyNumber": $scope.mediclaimObj.policyResult.policyNumber, "policyStartDate": $scope.mediclaimObj.policyResult.policyStartDate,
						"currentStatus": $scope.mediclaimObj.policyResult.status, "risks": [{
							"riskDetails": {
								"healthStatus": $scope.healthVal,
								"policyExtensionDate": "", "policyExtensionPeriod": ""
							}
						}]
					}
				};

				if ($scope.mediclaimObj.policyResult.productCode === "BH") {
					policyExtensionData.quote.risks[0].riskDetails.policyExtensionDate = this.monthsExtension;
					policyExtensionData.quote.risks[0].riskDetails.policyExtensionPeriod = this.daysExtension;

				}
				if ($scope.mediclaimObj.policyResult.productCode === "ES") {
					var date1 = $scope.date1,
						getdate = $scope.date1.getDate(),
						getmonth = $scope.date1.getMonth() + 1
					getyear = $scope.date1.getFullYear();
					if (getmonth < 10) {
						getmonth = "0" + getmonth.toString();
					}
					date1 = getdate + '/' + getmonth + '/' + getyear; //mm/dd/yyyy
					policyExtensionData.quote.risks[0].riskDetails.policyExtensionDate = date1.toString();
					policyExtensionData.quote.risks[0].riskDetails.policyExtensionPeriod = this.monthsExtension;
				}

				var policyExtensionResponse = RestServices.postService(RestServices.urlPathsNewPortal.startEndorsement, policyExtensionData);
				policyExtensionResponse.then(
					function (response) {
						CommonServices.showLoading(false);
						if (response.data.userProfile !== undefined) {
							if (response.data.userProfile.footer.errorCode !== "0") {
								CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
							}
							else {
								CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
								$scope.extendAmt = response.data.quote.premiumDetails.extendedPremium;
								if ($scope.extendAmt !== "0") {
									$scope.mediclaimObj.calculate = true;
								}

								$scope.travellerDetailsResponse = {
									"travellerDetailsResponse": {
										"quoteNumber": response.data.quote.quoteNumber,
										"premiumDetails": response.data.quote.premiumDetails
									}
								};
								CommonServices.setCommonData("productCode", $scope.mediclaimObj.policyResult.productCode);
								CommonServices.setCommonData("validateStatus", response.data.userProfile.footer.status);
							}
						}
						else {
							CommonServices.showAlert(response.data.errorMessage);
						}


					},
					function (error) {
						CommonServices.showLoading(false);
						RestServices.headerWithoutToken = false;
					});
			}


		},
		confirmFunc: function () {
			if (this.calculate) {
				angular.extend($rootScope.travelData, $scope.travellerDetailsResponse);
				CommonServices.setCommonData("esExtension", "esExtension");
				CommonServices.setCommonData("esPolicyNum", $scope.mediclaimObj.policyResult.policyNumber);
				CommonServices.setCommonData("CollectionPaymentDetails", $rootScope.travelData.travellerDetailsResponse);
				$state.go("collectionForm");
			}

		}
	}

	$scope.mediclaimObj.policyResult = CommonServices.getCommonData("extendPolicy");


	$scope.calIconClick = function (event) {
		angular.element("#" + event.currentTarget.children[0].id).focus();
	};


}]);

agentApp.controller('acknowledgementCtrl', ['$scope', 'RestServices', 'CommonServices', '$state', '$rootScope','CartServices', function ($scope, RestServices, CommonServices, $state, $rootScope,CartServices) {


	if (CommonServices.getCommonData("paymentMode") === "billdesk") {
		$scope.quoteNumber = CommonServices.getCommonData("billdeskQuote");
		$scope.billdeskResponse = CommonServices.getCommonData("billdeskResponse");
	}
	/*Start changes for CR_NP_867*/
	else if(CommonServices.getCommonData("paymentMode") === "ezetap"){
	    $scope.quoteNumber = CommonServices.getCommonData("ezetapQuote");
        $scope.ezetapResponse = CommonServices.getCommonData("ezetapResponse");
        
	}
	/*End changes for CR_NP_867*/
	else {
		$scope.paymentConfirmation = CommonServices.getCommonData("paymentConfirmation").paymentConfirmation.quote;
		$scope.errorCode = CommonServices.getCommonData("paymentConfirmation").paymentConfirmation.userProfile.footer.errorCode;
		$scope.errorDescription = CommonServices.getCommonData("paymentConfirmation").paymentConfirmation.userProfile.footer.errorDescription;
	}


	if (CommonServices.getCommonData("responseFlag") !== undefined && CommonServices.getCommonData("responseFlag") !== "") {
		$scope.netBankingResponse = CommonServices.getCommonData("responseFlag");
	}
	/*Start changes for CR_NP_867*/
	if (CommonServices.getCommonData("ezetapResponseFlag") !== undefined && CommonServices.getCommonData("ezetapResponseFlag") !== "") {
    		$scope.ezetapResponseFlag = CommonServices.getCommonData("ezetapResponseFlag");
    }
	/*End changes for CR_NP_867*/
	if (CommonServices.getCommonData('collectionPaymentFlag') !== undefined && CommonServices.getCommonData('collectionPaymentFlag') !== "") {
		$scope.collectionPaymentFlag = CommonServices.getCommonData("collectionPaymentFlag");
	}
	/*Start changes for CR_NP_867*/
	if (CommonServices.getCommonData('ezetapCollectionPaymentFlag') !== undefined && CommonServices.getCommonData('ezetapCollectionPaymentFlag') !== "") {
    		$scope.ezetapCollectionPaymentFlag = CommonServices.getCommonData("ezetapCollectionPaymentFlag");

    	}
	/*End changes for CR_NP_867*/

/*Start changes for CR_3546*/
	$scope.isCartPaymenEnabled = false;
	if (CommonServices.getCommonData('cartPaymentDetails') !== undefined && CommonServices.getCommonData('cartPaymentDetails') !== "") {
		$scope.cartPaymentDetails = CommonServices.getCommonData("cartPaymentDetails");
		$scope.isCartPaymenEnabled = CartServices.cartPaymenEnable;
		// CommonServices.setCommonData("cartPaymentDetails", {
		// 	'quoteNumberArr': $scope.quoteNumberArr,
		// 	'netPremium': $scope.netPremium
		// });
	}
	/*End changes for CR_3546*/

	$scope.closeAck = function () {
		CommonServices.setCommonData("paymentMode", "");
		CommonServices.setCommonData("responseFlag", "");
		$state.go('home');
	};
}]);

agentApp.controller('commonCollectionCtrl', ['$scope', '$location', 'RestServices', 'CommonServices', '$rootScope', '$state','CartServices', function ($scope, $location, RestServices, CommonServices, $rootScope, $state,CartServices) {
	var agentStakeCode = CommonServices.getCommonData("stakeCode").toUpperCase();
	var disableCollectionMob = CommonServices.getCommonData("disableCollectionMob");
	$scope.cashCollection = false;
	$scope.chequeCollection = false;
	$scope.apdCollection = false;
	$scope.collectionMessage = false;
	var submitCollection = true;
	$scope.excessAmountDraft = false;
	/*Added for CR_MOBL_0066 start*/
	$scope.excessAmount=0;
	$scope.multiple=false;
	/*Added for CR_MOBL_0066 end*/

	CommonServices.topUpObj.fromBasicPremium = false;
	CommonServices.topUpObj.searchBoxEnable = false;
	$scope.collectionPayment = CommonServices.getCommonData("CollectionPaymentDetails");
	$scope.quoteNumber = $scope.collectionPayment.quoteNumber;

	/* CR_NP_779 Start */
	$scope.buttonText = "Send Payment Link";
	$scope.CountReSendPaymntLink = 0;
	$scope.SPLtermFlag = false;
	/* CR_NP_779 End */
	
	/**CR690 Start**/
	$rootScope.panmodalOpen = false;

	var panCardDetails = {
		"quoteNumber": $scope.quoteNumber,
		"policyHolderCode": CommonServices.getCommonData("partyCode")
	}
	CommonServices.setCommonData("panCardData", panCardDetails);
	/*Start changes for CR_NP_867*/
	$scope.policyHolderCode= CommonServices.getCommonData("partyCode");
	//$scope.policyHolderName= $scope.collectionPayment.policyHolderName;
	/*End changes for CR_NP_867*/
	/**CR690 End**/

	var extension = CommonServices.getCommonData("esExtension");
	$scope.isCartPaymenEnabled = CartServices.cartPaymenEnable; // CR 3546

	if (extension === "esExtension") {
		$scope.netPremium = $scope.collectionPayment.premiumDetails.extendedPremium;
		$scope.ompextn = "Y";
		$scope.oldPolicy = CommonServices.getCommonData("esPolicyNum");
		CommonServices.setCommonData("esExtension", "");

	} else if ($scope.isCartPaymenEnabled) { // CR 3546
		$scope.quoteNumberArr = [];
		var totalCartAmount = 0;
		angular.forEach(CartServices.cartPaymentListing, function(cart, i) {
			$scope.quoteNumberArr.push(cart.quoteNo);
			totalCartAmount = cart.totalCartAmount;
		});
		$scope.quoteNumber = $scope.collectionPayment.quoteNumber;
		$scope.netPremium = totalCartAmount.toString();
		$scope.ompextn = "N";
		$scope.oldPolicy = "NA";
	}
	else {
		$scope.netPremium = $scope.collectionPayment.premiumDetails.netPremium;
		$scope.ompextn = "N";
		$scope.oldPolicy = "NA";
	}


	if ($scope.netPremium.indexOf('.') > 0)
		$scope.netPreAmt = $scope.netPremium.substring(0, $scope.netPremium.indexOf('.'));
	else
		$scope.netPreAmt = $scope.netPremium;

	$scope.home = function () {
		if ($scope.isCartPaymenEnabled) { // CR 3546
			$state.go("showCart");
			// var msg = "Changes that you made may not be saved.";
			// CommonServices.messageModal('info', msg, false, 'Stay', 'Leave', function () {}, function () { exitFunction('cart');}, 'Alert');
		} else {
		var msg = "Changes that you made may not be saved.";
		CommonServices.messageModal('info', msg, false, 'Stay', 'Leave', function () {}, function () { exitFunction(1);}, 'Alert');
	}
}

	function exitFunction(button) {
		if (button == 1) {
			$state.go("home");
		} else if (button === 'cart') {
			$state.go("showCart");
		}
	}

	$scope.init = function () {
		CommonServices.chequeList = [];
		//Get Collection Modes Start
		if ($scope.isCartPaymenEnabled) { // CR 3546
			$scope.collectionModesList = [
				{"mode":"Cash","code":"CSH"},
				{"mode":"Cheque","code":"CHQ"},
				{"mode":"APD","code":"APD"},
				{"mode":"Net Banking","code":"NB"}
			];
		} else {
		var collectionModeData = { "userProfile": { "userId": CommonServices.getCommonData("userId"), "channel": "AGENT" } };

		var collectionModeResponse = RestServices.postService(RestServices.urlPathsNewPortal.collectionModes, collectionModeData);
		collectionModeResponse.then(
			function (response) { // success 

				CommonServices.showLoading(false);
				if (response.data.collectionModesList.length > "0") {
					$scope.collectionModesList = response.data.collectionModesList;
				} else {
					CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
				}
			},
			function (error) { // failure
				CommonServices.showLoading(false);
				RestServices.handleWebServiceError(error);
			});
		}
		//Get Collection Modes End

		//Get Domain Values Start
		var domainData = {
			"lngCode": "EN",
			"keys": ["CHEQUE_PO_DRAFT_TYPE"]
		};
		var getDomainResponse = "";
		getDomainResponse = RestServices.postService(RestServices.urlPathsNewPortal.getDomainValues, domainData);
		getDomainResponse.then(
			function (response) {

				CommonServices.showLoading(false);
				for (var i = 0; i < response.data.domainValues.length; i++) {
					var chequeTypes = {
						'name': response.data.domainValues[i].mnemonic
					};

					CommonServices.chequeList.push(chequeTypes);
				}
			},
			function (error) {
				CommonServices.showLoading(false);
				RestServices.handleWebServiceError(error);
			});
		//Get Domain Values End
		//Get Bank Details Start

		var bankSearchResponse = RestServices.getService(RestServices.urlPathsNewPortal.getBHBankDetails);
		//web service call for bank search
		bankSearchResponse.then(
			function (response) {	// success 
				CommonServices.showLoading(false);
				$scope.bankList = response.data.listofBankDetails;

			},
			function (error) {    // failure 
				CommonServices.showLoading(false);
				RestServices.handleWebServiceError(error);
			});
		//Get Bank Details End
	}

	$scope.init();

	$scope.refresh = function () {
		$scope.init();
	}

	var modes = disableCollectionMob;
	for (var i = 0; i < modes.length; i++) {

		if (modes[i].code === "CSH") {
			$scope.cashCollection = true;
		} else if (modes[i].code === "CHQ") {
			$scope.chequeCollection = true;
		} else if (modes[i].code === "APD") {
			$scope.apdCollection = true;
		}
	}
	if ($scope.cashCollection == false && $scope.chequeCollection == false && $scope.apdCollection == false) {
		$scope.collectionMessage = true;
		submitCollection = false;
	}

	$scope.count = 0;
	$scope.show = function (e) {
		  if ($scope.isCartPaymenEnabled && $scope.count >= 1){
          return;
		}// CR 3546
		
		if ($scope.cashCollection == false && $scope.chequeCollection == false && $scope.apdCollection == false) {
			$scope.showModes = false;
		}
		else if ($scope.excessAmountDraft === true) {
			$scope.showModes = false;
			CommonServices.showAlert("There is already an excess amount in the instrument amount.You are not allowed to add new collection modes.")
		}
		else {
			$scope.showModes = !$scope.showModes;
		}

	};
	$scope.collectionFormData = {
		apdFormData: [],
		chequeFormData: [],
		cashFormData: [],
		demandDraftFormData: [],
		postalFormData: [],
		netBankingFormData: []
		,ezetapFormData: []// changes for CR_NP_867
		,SendPaymentLinkFormData: [] /* CR_NP_779 */
	};

	$scope.chequeTypesModal = function ($event, data) {
		$scope.chequeModal = true;
		$scope.clickedsec_id = $event;
		$scope.collectType = data;
	};

	$scope.chequeList = CommonServices.chequeList;

	$scope.getChequeValue = function (listPassed) {
		var id = $scope.clickedsec_id;
		if ($scope.collectType === "cheque") {
			$scope.collectionFormData.chequeFormData[id].chequeType = listPassed;
		}
		if ($scope.collectType === "po") {
			$scope.collectionFormData.postalFormData[id].chequeType = listPassed;
		}
		if ($scope.collectType === "dd") {
			$scope.collectionFormData.demandDraftFormData[id].chequeType = listPassed;
		}
		$scope.chequeModal = false;
	};
	//APD Functionality Start

	$scope.removeApdRow = function (index) {
		$scope.count = 0;
		$scope.showModes = false;
		$scope.collectionFormData.apdFormData.splice(index, 1);
	};

	$scope.removeNBRow = function (index) {
		$scope.count = 0;
		$scope.showModes = false;
		$scope.collectionFormData.netBankingFormData.splice(index, 1);
		if ($scope.termFlag) {
			$scope.termFlag = false;
		}

	}
	/*start changes for CR867*/
	$scope.removeEzeRow = function (index) {
		$scope.count = 0;
		$scope.showModes = false;
		$scope.collectionFormData.ezetapFormData.splice(index, 1);
		if ($scope.termFlagEze) {
			$scope.termFlagEze = false;
		}

	}
	/*end changes for CR867*/

	/* CR_NP_779 Start*/
	$scope.removeSPLRow = function (index) {
		$scope.count = 0;
		$scope.showModes = false;
		$scope.collectionFormData.SendPaymentLinkFormData.splice(index, 1);
		if ($scope.SPLtermFlag) {    
			$scope.SPLtermFlag = false;
		}
	}
	/* CR_NP_779 End*/

	$scope.getSubCode = function ($event) {
		var stakevalue = CommonServices.getCommonData("stakeCode");
		$scope.clickedsub_id = $event;

		var postSubCode = {
			"userProfile": {
				"userId": CommonServices.getCommonData("userCode").toUpperCase(),
				"loggedInRole": CommonServices.getCommonData("loggedInRole")
			},
			"quote": {
				"payment": {
					"paymentDetailsList": [{
						"collectionMode": "APD"
					}]
				}
			}
		}

		var PolicyResponse = RestServices.postService(RestServices.urlPathsNewPortal.getAPDBalance, postSubCode);

		PolicyResponse.then(
			function (response) { // success 
				// Added since if APD balance is not fetched from the service there was error
				if (response.data.quote.payment.paymentDetailsList[0] !== undefined && response.data.quote.payment.paymentDetailsList[0] !== "") {
					$scope.subCodeModel = true;
					$scope.subCodeList = response.data.quote.payment.paymentDetailsList;
					CommonServices.showLoading(false);
				} else {
					CommonServices.showAlert("No APD Balance available");
					CommonServices.showLoading(false);
				}
			},
			function (error) { // failure 
				CommonServices.showLoading(false);
				RestServices.handleWebServiceError(error);
			});
	};

	$scope.getSubCodeValue = function (listPassed) {
		var id = $scope.clickedsub_id;
		$scope.collectionFormData.apdFormData[id].subCode = listPassed;
		$scope.subCodeModel = false;
		$scope.collectionFormData.apdFormData[id].referenceNumber = '';
	};

	$scope.getReferenceNoAPD = function ($event) {
		$scope.clickedrefer_id = $event;
		var subcode = $scope.collectionFormData.apdFormData[$event].subCode;
		if (subcode == '') {
			CommonServices.showAlert("Please Select Subcode");
		}
		else {
			var postReferenceCode = {
				"userProfile": {
					"userId": CommonServices.getCommonData("userCode").toUpperCase(),
					"loggedInRole": CommonServices.getCommonData("loggedInRole")
				},
				"quote": {
					"payment": {
						"paymentDetailsList": [{
							"collectionMode": "APD",
							"subCode": subcode
						}]
					}
				}
			};

			var PolicyResponse = RestServices.postService(RestServices.urlPathsNewPortal.getReferenceNoAPD, postReferenceCode);

			PolicyResponse.then(
				function (response) { // success 
					CommonServices.showLoading(false);
					if (response.data.quote !== undefined && response.data.quote !== "") {

						if (response.data.quote.payment.paymentDetailsList.length > 0) {
							$scope.referenceModel = true;
							$scope.referenceList = response.data.quote.payment.paymentDetailsList;
						}
						else {
							CommonServices.showAlert("No records found");
						}
					}

				},
				function (error) { // failure 
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
				});
		}
	};

	$scope.getreferenceValue = function (listPassed) {
		var id = $scope.clickedrefer_id;
		$scope.collectionFormData.apdFormData[id].referenceNumber = listPassed;
		$scope.referenceModel = false;
	};
	//APD Functionality End

	//Cheque Functionality Start

	$scope.removeChequeRow = function (index) {
		$scope.count = 0;
		$scope.showModes = false;
		$scope.multiple = false;		/*Added for CR_MOBL_0066 */
		$scope.excessAmountDraft = false;     /*Added for CR_MOBL_0066 */
		$scope.collectionFormData.chequeFormData.splice(index, 1);
		
		if ($scope.isCartPaymenEnabled) {
			$scope.collectionForm.$invalid = false;
			$scope.instrumentNameCheck = false;
		}
	};

	$scope.removeddRow = function (index) {
		$scope.count = 0;
		$scope.showModes = false;
		$scope.multiple = false;		/*Added for CR_MOBL_0066 */
		$scope.excessAmountDraft = false;     /*Added for CR_MOBL_0066 */
		$scope.collectionFormData.demandDraftFormData.splice(index, 1);
	}

	$scope.removepostalRow = function (index) {
		$scope.count = 0;
		$scope.showModes = false;
		$scope.multiple = false;	/*Added for CR_MOBL_0066 */
		$scope.collectionFormData.postalFormData.splice(index, 1);
	}

	$scope.handleSelection = function (data, index) {
		$scope.collectionFormData.postalFormData[index].draweeBankName = data;
	}

	var mydateStr = new Date();
	var mynewdateFrom = "";
	if (mydateStr != undefined) {
		mynewdateFrom = new Date(mydateStr);
	}
	else {
		mynewdateFrom = new Date();
	}

	var enableCalendarTo = getFormattedDate(mynewdateFrom);

	/**Payment Date form past 60 days Start Date till today**/

	var enableCalendarfrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear()));
	enableCalendarfrom = new Date(enableCalendarfrom.setDate(enableCalendarfrom.getDate() - 60));
	enableCalendarfrom = getFormattedDate(enableCalendarfrom);

	var date = new Date();
	var toDate = new Date(date);
	toDate.setDate(toDate.getDate());
	var dayTo = toDate.getDate();
	var monthTo = toDate.getMonth() + 1;
	var yearTo = toDate.getFullYear();
	var enableChequeCalTo = monthTo + "/" + dayTo + "/" + yearTo;

	$scope.chequeDateValidation = function (index) {

		$("#chequeDate_" + index).loadCalendar({
			'enableDateRange': true,
			'enableCalendarFrom': enableCalendarfrom,
			'enableCalendarTo': enableChequeCalTo
		});
		$("#ddDate_" + index).loadCalendar({
			'enableDateRange': true,
			'enableCalendarFrom': enableCalendarfrom,
			'enableCalendarTo': enableChequeCalTo
		});
		$("#poDate_" + index).loadCalendar({
			'enableDateRange': true,
			'enableCalendarFrom': enableCalendarfrom,
			'enableCalendarTo': enableChequeCalTo
		});
		return true;
	};
	$scope.calIconClick = function (event) {
		angular.element("#" + event.currentTarget.children[0].id).focus();

	};


	//Cheque Functionality End
	//Cash Functionality Start
	$scope.cashClick = function (data) {
		$scope.count = ($scope.isCartPaymenEnabled) ? 1 : 0; // CR 3546
		$scope.SPLtermFlag = false; /* CR_NP_779 */	
		if (data === "APD") {
			if ($scope.collectionFormData.cashFormData.length > 0) {
				CommonServices.showAlert("APD cannot be combined with cash mode");
				$scope.showModes = false;
			} else if ($scope.collectionFormData.chequeFormData.length > 0) {
				CommonServices.showAlert("APD cannot be combined with cheque mode");
				$scope.showModes = false;
			} else if ($scope.collectionFormData.netBankingFormData.length > 0) {
				CommonServices.showAlert("APD cannot be combined with Net Banking mode");
				$scope.showModes = false;
			} else if ($scope.collectionFormData.demandDraftFormData.length > 0) {
				CommonServices.showAlert("APD cannot be combined with Demand Draft mode");
				$scope.showModes = false;
			} else if ($scope.collectionFormData.postalFormData.length > 0) {
				CommonServices.showAlert("APD cannot be combined with Postal Order mode");
				$scope.showModes = false;
			}
            else if ($scope.collectionFormData.ezetapFormData.length  > 0) {
				CommonServices.showAlert("APD cannot be combined with Ezetap mode");
				$scope.showModes = false;
			}
			/* CR_NP_779 Start */
			else if ($scope.collectionFormData.SendPaymentLinkFormData.length > 0) {
				CommonServices.showAlert("APD cannot be combined with Send Payment Link mode");
				$scope.showModes = false;
				$scope.SPLtermFlag = true;
			}
			/* CR_NP_779 End */
			else {
				$scope.collectionFormData.apdFormData
					.unshift({
						accountCode: '',
						quoteNo: '',
						collectionMode: 'APD',
						subCode: '',
						scrollNo: '',
						collectionAmount: ''
					});
				$scope.showModes = false;

			}
		}
		if (data === "NB") {
			if ($scope.collectionFormData.cashFormData.length > 0) {
				CommonServices.showAlert("Net Banking cannot be combined with cash mode");
				$scope.showModes = false;
			} else if ($scope.collectionFormData.chequeFormData.length > 0) {
				CommonServices.showAlert("Net Banking cannot be combined with cheque mode");
				$scope.showModes = false;
			} else if ($scope.collectionFormData.apdFormData.length > 0) {
				CommonServices.showAlert("Net Banking cannot be combined with Net Banking mode");
				$scope.showModes = false;
			} else if ($scope.collectionFormData.demandDraftFormData.length > 0) {
				CommonServices.showAlert("Net Banking cannot be combined with Demand Draft mode");
				$scope.showModes = false;
			} else if ($scope.collectionFormData.postalFormData.length > 0) {
				CommonServices.showAlert("Net Banking cannot be combined with Postal Order mode");
				$scope.showModes = false;
			} 
			else if ($scope.collectionFormData.ezetapFormData.length  > 0) {
				CommonServices.showAlert("Net Banking cannot be combined with Ezetap mode");
				$scope.showModes = false;
			}
			else if ($scope.collectionFormData.netBankingFormData.length > 0) {
				CommonServices.showAlert("Net Banking mode has already been added");
				$scope.showModes = false;
			}
			/* CR_NP_779 Start*/
			else if ($scope.collectionFormData.SendPaymentLinkFormData.length > 0) {
				CommonServices.showAlert("Net Banking cannot be combined with Send Payment Link mode");
				$scope.showModes = false;
				$scope.SPLtermFlag = true;
			}
			/* CR_NP_779 End*/
				else if ($scope.collectionFormData.ezetapFormData.length  > 0) {
				CommonServices.showAlert("Net Banking cannot be combined with Ezetap mode");
				$scope.showModes = false;
			} else {
				$scope.collectionFormData.netBankingFormData
					.unshift({
						collectionMode: 'NB',
						collectionAmount: ''
					});
				$scope.showModes = false;
				$scope.collectionFormData.netBankingFormData[0].collectionAmount = $scope.netPreAmt;
			}
		}
		/*start changes for CR867*/
		if (data === "EZE" && CommonServices.deviceType == "A") { //Change in code merge & to handle in ihone
			if ($scope.collectionFormData.cashFormData.length > 0) {
				CommonServices.showAlert("Ezetap cannot be combined with cash mode");
				$scope.showModes = false;
			} else if ($scope.collectionFormData.chequeFormData.length > 0) {
				CommonServices.showAlert("Ezetap cannot be combined with cheque mode");
				$scope.showModes = false;
			} else if ($scope.collectionFormData.apdFormData.length > 0) {
				CommonServices.showAlert("Ezetap cannot be combined with Net Banking mode");
				$scope.showModes = false;
			} else if ($scope.collectionFormData.demandDraftFormData.length > 0) {
				CommonServices.showAlert("Ezetap cannot be combined with Demand Draft mode");
				$scope.showModes = false;
			} else if ($scope.collectionFormData.postalFormData.length > 0) {
				CommonServices.showAlert("Ezetap cannot be combined with Postal Order mode");
				$scope.showModes = false;
			} else if ($scope.collectionFormData.netBankingFormData.length > 0) {
				CommonServices.showAlert("Ezetap cannot be combined with Net Banking mode");
				$scope.showModes = false;
			}else if ($scope.collectionFormData.ezetapFormData.length > 0) {
				CommonServices.showAlert("Ezetap mode has already been added");
				$scope.showModes = false;
			}
			else if ($scope.collectionFormData.SendPaymentLinkFormData.length > 0) {
            				CommonServices.showAlert("Ezetap cannot be combined with Send Payment Link mode");
            				$scope.showModes = false;
            				$scope.SPLtermFlag = true;
            			}
			 else {
				$scope.collectionFormData.ezetapFormData
					.unshift({
						collectionMode: 'EZE',
						collectionAmount: ''
					});
				$scope.showModes = false;
				$scope.collectionFormData.ezetapFormData[0].collectionAmount = $scope.netPreAmt;
			}
		}else if(data === "EZE" && CommonServices.deviceType == "I"){ //Change in code merge & to handle in ihone
			CommonServices.showAlert("Ezetap Payment option is not available for iphone or ipad");
		}
		/*end changes for CR867*/
		if (data === "CSH") {
			if ($scope.collectionFormData.apdFormData.length > 0) {
				CommonServices.showAlert('APD cannot be combined with Cash mode');
				$scope.showModes = false;
			} else if ($scope.collectionFormData.cashFormData.length > 0) {
				CommonServices.showAlert("Cash mode has already been added");
				$scope.showModes = false;
			} else if ($scope.collectionFormData.netBankingFormData.length > 0) {
				CommonServices.showAlert("Net Banking cannot be combined with Cash mode");
				$scope.showModes = false;
			}
			else if ($scope.collectionFormData.ezetapFormData.length > 0) {
				CommonServices.showAlert("Ezetap mode cannot be combined with Cash mode");
				$scope.showModes = false;
			}
			/* CR_NP_779 Start*/
			else if ($scope.collectionFormData.SendPaymentLinkFormData.length > 0) {
				CommonServices.showAlert("Cash mode cannot be combined with Send Payment Link mode");
				$scope.showModes = false;
				$scope.SPLtermFlag = true;
			}
			/* CR_NP_779 End*/	
			 else {
				 /*Added for CR_MOBL_0066 start*/
				 if($scope.collectionFormData.chequeFormData.length > 0 || $scope.collectionFormData.demandDraftFormData.length > 0)
					 $scope.multiple = true;
				 /*Added for CR_MOBL_0066  end*/
				$scope.collectionFormData.cashFormData
					.push({
						cashAmount: ''
					});
				$scope.showModes = false;
			}
		}
		if (data === "CHQ") {
			if ($scope.collectionFormData.chequeFormData.length > 0) {
				CommonServices.showAlert("Cheque mode has already been added");
				$scope.showModes = false;
			} else if ($scope.collectionFormData.apdFormData.length > 0) {
				CommonServices.showAlert("APD cannot be combined with cheque mode");
				$scope.showModes = false;
			} else if ($scope.collectionFormData.netBankingFormData.length > 0) {
				CommonServices.showAlert("Net Banking cannot be combined with Cheque mode");
				$scope.showModes = false;
			}
			else if ($scope.collectionFormData.ezetapFormData.length > 0) {
				CommonServices.showAlert("Ezetap mode cannot be combined with Cheque mode");
				$scope.showModes = false;
			}
			/* CR_NP_779 Start*/
			else if ($scope.collectionFormData.SendPaymentLinkFormData.length > 0) {
				CommonServices.showAlert("Send Payment Link mode cannot be combined with Cheque mode");
				$scope.showModes = false;
				$scope.SPLtermFlag = true;
			}
			/* CR_NP_779 End*/
			 else {
				 /*Added for CR_MOBL_0066 start */
				if ($scope.collectionFormData.cashFormData.length > 0 || $scope.collectionFormData.demandDraftFormData.length>0 || $scope.collectionFormData.postalFormData.length>0) 
				$scope.multiple = true;		
			/*Added for CR_MOBL_0066 end  */
				$scope.collectionFormData.chequeFormData
					.unshift({
						draweeBankCode: '',
						chequeType: '',
						chequeNo: '',
						chequeDate: '',
						draweeBankName: '',
						draweeBankBranch: '',
						collectionAmount: '',
						excessAmount: '',
						instrumentAmount: ''
					});
				$scope.showModes = false;
				$scope.collectionFormData.chequeFormData[0].instrumentAmount = $scope.netPreAmt;
			}
		}
		if (data === "DRF") {
			if ($scope.collectionFormData.demandDraftFormData.length > 0) {
				CommonServices.showAlert("Demand Draft mode has already been added");
				$scope.showModes = false;
			} else if ($scope.collectionFormData.apdFormData.length > 0) {
				CommonServices.showAlert("APD cannot be combined with cheque mode");
				$scope.showModes = false;
			} else if ($scope.collectionFormData.netBankingFormData.length > 0) {
				CommonServices.showAlert("Net Banking cannot be combined with Draft mode");
				$scope.showModes = false;
			}
			else if ($scope.collectionFormData.ezetapFormData.length > 0) {
				CommonServices.showAlert("Ezetap mode cannot be combined with Draft mode");
				$scope.showModes = false;
			}
			/* CR_NP_779 Start*/
			else if ($scope.collectionFormData.SendPaymentLinkFormData.length > 0) {
				CommonServices.showAlert("Send Payment Link mode cannot be combined with Draft mode");
				$scope.showModes = false;
				$scope.SPLtermFlag = true;
			}
			 /* CR_NP_779 End*/
			 else {
				 /*Added for CR_MOBL_0066 start */
				 if ($scope.collectionFormData.cashFormData.length > 0 || $scope.collectionFormData.chequeFormData.length>0 || $scope.collectionFormData.postalFormData.length>0) 
				$scope.multiple = true;	
				 /*Added for CR_MOBL_0066 end */
				$scope.collectionFormData.demandDraftFormData
					.unshift({
						draweeBankCode: '',
						chequeType: '',
						chequeNo: '',
						chequeDate: '',
						draweeBankName: '',
						draweeBankBranch: '',
						collectionAmount: '',
						excessAmount: '',
						instrumentAmount: ''
					});
				$scope.showModes = false;
				$scope.collectionFormData.demandDraftFormData[0].instrumentAmount = $scope.netPreAmt;
			}
		}
		if (data === "PO") {
			if ($scope.collectionFormData.postalFormData.length > 0) {
				CommonServices.showAlert("Postal Order mode has already been added");
				$scope.showModes = false;
			} else if ($scope.collectionFormData.apdFormData.length > 0) {
				CommonServices.showAlert("APD cannot be combined with cheque mode");
				$scope.showModes = false;
			} else if ($scope.collectionFormData.netBankingFormData.length > 0) {
				CommonServices.showAlert("Net Banking cannot be combined with Postal Order mode");
				$scope.showModes = false;
			}
			else if ($scope.collectionFormData.ezetapFormData.length > 0) {
				CommonServices.showAlert("Ezetap mode cannot be combined with Postal Order mode");
				$scope.showModes = false;
			}
			/* CR_NP_779 Start*/
			else if ($scope.collectionFormData.SendPaymentLinkFormData.length > 0) {
				CommonServices.showAlert("Send Payment Link mode cannot be combined with Postal Order mode");
				$scope.showModes = false;
				$scope.SPLtermFlag = true;
			}
			/* CR_NP_779 End*/
			 else {
				 /*Added for CR_MOBL_0066 start */
				 if($scope.collectionFormData.chequeFormData.length > 0 || $scope.collectionFormData.demandDraftFormData.length > 0)
					 $scope.multiple = true;
				 /*Added for CR_MOBL_0066 end */
				$scope.collectionFormData.postalFormData
					.unshift({
						draweeBankCode: '',
						chequeType: '',
						chequeNo: '',
						chequeDate: '',
						draweeBankName: '',
						draweeBankBranch: '',
						collectionAmount: '',
						excessAmount: '',
						instrumentAmount: ''
					});
				$scope.showModes = false;
				$scope.collectionFormData.postalFormData[0].instrumentAmount = $scope.netPreAmt;
			}
		}
	/* CR_NP_779 Start */
		if (data === "SPL") {			
			$scope.FetchEmailIDMobileNoDetails();			
			if ($scope.collectionFormData.cashFormData.length > 0) {
				CommonServices.showAlert("Send Payment Link cannot be combined with cash mode");
				$scope.showModes = false;
			} else if ($scope.collectionFormData.chequeFormData.length > 0) {
				CommonServices.showAlert("Send Payment Link cannot be combined with cheque mode");
				$scope.showModes = false;
			} else if ($scope.collectionFormData.apdFormData.length > 0) {
				CommonServices.showAlert("Send Payment Link cannot be combined with APD mode");
				$scope.showModes = false;
			} else if ($scope.collectionFormData.demandDraftFormData.length > 0) {
				CommonServices.showAlert("Send Payment Link cannot be combined with Demand Draft mode");
				$scope.showModes = false;
			} else if ($scope.collectionFormData.postalFormData.length > 0) {
				CommonServices.showAlert("Send Payment Link cannot be combined with Postal Order mode");
				$scope.showModes = false;
			} else if ($scope.collectionFormData.netBankingFormData.length > 0) {
				CommonServices.showAlert("Send Payment Link cannot be combined with Net Banking mode");
				$scope.showModes = false;
			} else if ($scope.collectionFormData.ezetapFormData.length > 0) {
				CommonServices.showAlert("Send Payment Link cannot be combined with Ezetap mode");
				$scope.showModes = false;	
			} else if ($scope.collectionFormData.SendPaymentLinkFormData.length > 0) {
				CommonServices.showAlert("Send Payment Link has already been added");
				$scope.SPLtermFlag = true;	
				$scope.showModes = false;
			} else if (($scope.SPLAgentEmalid == undefined || $scope.SPLAgentEmalid == "") && ($scope.SPLAgentMobileNo == undefined 
			|| $scope.SPLAgentMobileNo == ""))  {
				CommonServices.showAlert("The email ID and mobile number of the policyholder is not available");
				$scope.SPLtermFlag = true;
				$scope.showModes = false;
			} else {
				$scope.collectionFormData.SendPaymentLinkFormData
					.unshift({
						collectionMode: 'SPL',
						collectionAmount: ''
					});
				$scope.showModes = false;									
				$scope.collectionFormData.SendPaymentLinkFormData[0].collectionAmount = $scope.netPreAmt;
				$scope.SPLtermFlag = true;
				$scope.FetchPaymentLinkDeatils();				
		}
	 }
		/* CR_NP_779 End */
		
		if ($scope.isCartPaymenEnabled) { // CR3546
			if (data === "CSH") $scope.collectionFormData.cashFormData[0].cashAmount = parseInt($scope.netPremium);
			else if (data === "CHQ") {
				$scope.collectionFormData.chequeFormData[0].collectionAmount = parseInt($scope.netPremium);
				$scope.collectionFormData.chequeFormData[0].instrumentAmount = parseInt($scope.netPremium);
			}
			else if (data === "APD") $scope.collectionFormData.apdFormData[0].collectionAmount = parseInt($scope.netPremium);
			else if (data === "NB") $scope.collectionFormData.netBankingFormData[0].collectionAmount = parseInt($scope.netPremium);
		}
	};

	$scope.removeCashRow = function (index) {
		$scope.count = 0;
		$scope.showModes = false;
		$scope.multiple = false; /*CR_MOBL_0066*/
		$scope.collectionFormData.cashFormData.splice(index, 1);
	};

	//Cheque Excess Amount Start
	$scope.checkCollecAmt = function (data) {
		if (data === "cheque") {
			/*changes for CR_MOBL_0066 start*/
		
			$scope.collectCheck = false;
			if (parseFloat($scope.collectionFormData.chequeFormData[0].collectionAmount) > parseFloat($scope.netPremium))
			{
			$scope.collectCheck = true;
			}
			else if (angular.isUndefined($scope.collectionFormData.chequeFormData[0].collectionAmount))
			{
			$scope.collectionFormData.chequeFormData[0].instrumentAmount='';
			}
			
			else if (parseFloat($scope.collectionFormData.chequeFormData[0].collectionAmount) < parseFloat($scope.netPremium) || parseFloat($scope.collectionFormData.chequeFormData[0].collectionAmount) === parseFloat($scope.netPremium)) {
				$scope.excessAmountDraft = false;  
				$scope.collectionFormData.chequeFormData[0].instrumentAmount = parseFloat($scope.collectionFormData.chequeFormData[0].collectionAmount);
			}
		}
		if (data === "draft") {
			$scope.collectCheck = false;
			if (parseFloat($scope.collectionFormData.demandDraftFormData[0].collectionAmount) > parseFloat($scope.netPremium))
			{
			$scope.collectCheck = true;
			}
			else if (angular.isUndefined($scope.collectionFormData.demandDraftFormData[0].collectionAmount))
			{
				$scope.collectionFormData.demandDraftFormData[0].instrumentAmount='';
			}
			else if (parseFloat($scope.collectionFormData.demandDraftFormData[0].collectionAmount) < parseFloat($scope.netPremium) || parseFloat($scope.collectionFormData.demandDraftFormData[0].collectionAmount) === parseFloat($scope.netPremium)) {
				$scope.excessAmountDraft = false;  
				$scope.collectionFormData.demandDraftFormData[0].instrumentAmount = parseFloat($scope.collectionFormData.demandDraftFormData[0].collectionAmount);
			}
		}
					/*changes for CR_MOBL_0066 end*/

	};
	$scope.checkInstAmt = function (data) {
		if (data === "cheque") {
			/*changes for CR_MOBL_0066 start*/
			$scope.instcheck = false;
			$scope.collectCheck = false;
			if (parseFloat($scope.collectionFormData.chequeFormData[0].instrumentAmount) > parseFloat($scope.collectionFormData.chequeFormData[0].collectionAmount) && parseFloat($scope.collectionFormData.chequeFormData[0].collectionAmount) === parseFloat($scope.netPremium)) {
				if($scope.multiple==false){
				$scope.collectionFormData.chequeFormData[0].excessAmount = 0;
				$scope.excessAmountDraft = true;
				$scope.collectionFormData.chequeFormData[0].excessAmount = $scope.collectionFormData.chequeFormData[0].instrumentAmount - $scope.netPremium;
			}
				else
			{
				$scope.excessAmountDraft = false; 
					$scope.collectionFormData.chequeFormData[0].instrumentAmount = parseFloat($scope.collectionFormData.chequeFormData[0].collectionAmount);
					
				}
			}
			
			else if(parseFloat($scope.collectionFormData.chequeFormData[0].instrumentAmount) < parseFloat($scope.collectionFormData.chequeFormData[0].collectionAmount) && parseFloat($scope.collectionFormData.chequeFormData[0].collectionAmount) === parseFloat($scope.netPremium) )
			{
				$scope.instcheck = true;
			}
			else if (parseFloat($scope.collectionFormData.chequeFormData[0].instrumentAmount) === parseFloat($scope.collectionFormData.chequeFormData[0].collectionAmount) || angular.isUndefined($scope.collectionFormData.chequeFormData[0].instrumentAmount)) {
				$scope.excessAmountDraft = false;    
			}
			else if (parseFloat($scope.collectionFormData.chequeFormData[0].collectionAmount) < parseFloat($scope.netPremium) || parseFloat($scope.collectionFormData.chequeFormData[0].collectionAmount) === parseFloat($scope.netPremium)) {
				$scope.excessAmountDraft = false;  
				$scope.collectionFormData.chequeFormData[0].instrumentAmount = parseFloat($scope.collectionFormData.chequeFormData[0].collectionAmount);
			}
		}
		if (data === "draft") {
			
			$scope.instcheck = false;
			$scope.collectCheck = false;
			if (parseFloat($scope.collectionFormData.demandDraftFormData[0].instrumentAmount) > parseFloat($scope.collectionFormData.demandDraftFormData[0].collectionAmount) && parseFloat($scope.collectionFormData.demandDraftFormData[0].collectionAmount) === parseFloat($scope.netPremium)) {
				if($scope.multiple==false){
				$scope.collectionFormData.demandDraftFormData[0].excessAmount = 0;
				$scope.excessAmountDraft = true;
				$scope.collectionFormData.demandDraftFormData[0].excessAmount =$scope.collectionFormData.demandDraftFormData[0].excessAmount+( $scope.collectionFormData.demandDraftFormData[0].instrumentAmount - $scope.netPremium);
			}
				else
			{
				$scope.excessAmountDraft = false; 
					$scope.collectionFormData.demandDraftFormData[0].instrumentAmount = parseFloat($scope.collectionFormData.demandDraftFormData[0].collectionAmount);
					
				}

			}
			else if(parseFloat($scope.collectionFormData.demandDraftFormData[0].instrumentAmount) < parseFloat($scope.collectionFormData.demandDraftFormData[0].collectionAmount) && parseFloat($scope.collectionFormData.demandDraftFormData[0].collectionAmount) === parseFloat($scope.netPremium))
			{
				$scope.instcheck = true;
			}
		else if (parseFloat($scope.collectionFormData.demandDraftFormData[0].instrumentAmount) === parseFloat($scope.collectionFormData.demandDraftFormData[0].collectionAmount) || angular.isUndefined($scope.collectionFormData.demandDraftFormData[0].instrumentAmount)) {
				$scope.excessAmountDraft = false;    
				}
				else if (parseFloat($scope.collectionFormData.demandDraftFormData[0].collectionAmount) < parseFloat($scope.netPremium) || parseFloat($scope.collectionFormData.demandDraftFormData[0].collectionAmount) === parseFloat($scope.netPremium)) {
				$scope.excessAmountDraft = false;    
				$scope.collectionFormData.demandDraftFormData[0].instrumentAmount = parseFloat($scope.collectionFormData.demandDraftFormData[0].collectionAmount);
				}
			
	}
					/*changes for CR_MOBL_0066 end*/

	};
	/***********cr_mob_0061 start ****/
	//Cheque Excess Amount End

	//Cash Functionality End
	var totalPremium = 0;
	var chequeIdDuplicate = false;

	$scope.compareChequeID = function (chequArr) {
		chequeIdDuplicate = false;
		if (chequArr.length > 1) {
			for (var i = 0; i < chequArr.length; i++) {
				for (var j = 0; j < i; j++) {
					if (chequArr[i].chequeNo == chequArr[j].chequeNo) {
						chequeIdDuplicate = true;
					}
				}
			}
		}
	};
	/*Added for CR_MOBL_0066 start*/
	$scope.Confirm=function(msg, $true, $false) { 
		var $content =   "<div class='excessAmount'>" +
		"<div class='contactModalCont'>" + "<div class='dialog-msg'>" +
		" <p> " + msg + " </p> " +
		"</div>" +
		"<footer>" +
		"<div class='controls'>" +
		" <button class='button button-danger doAction'>" + $true + "</button> " +
		" <button class='button button-default cancelAction'>" + $false + "</button> " +
		"</div>" +
		"</footer>" +
		"</div>" +
		"</div>";
		$('body').prepend($content);
		$('.doAction').click(function () {
			$scope.collectionPostData();
			$(this).parents('.excessAmount').fadeOut(500, function () {
				$(this).remove();
			});
		});
		$('.cancelAction, .fa-close').click(function () {
			$(this).parents('.excessAmount').fadeOut(500, function () {
				$(this).remove();
			});
		});

	};
	/*Added for CR_MOBL_0066 end*/

	$scope.addCollAmount = function () {
		var i = "";
		var chequetotalPremium = 0;
		totalPremium = 0;
		//Amount Calculation for APD
		if ($scope.collectionFormData.apdFormData.length > 0) {
			var subCodeArr = $scope.collectionFormData.apdFormData;
			for (i = 0; i < $scope.collectionFormData.apdFormData.length; i++) {
				totalPremium = parseFloat($scope.collectionFormData.apdFormData[i].collectionAmount) + totalPremium;
				delete $scope.collectionFormData.apdFormData[i].$$hashKey;
			}

		}
		//Amount Calculation
		else if ($scope.collectionFormData.cashFormData.length > 0 || $scope.collectionFormData.chequeFormData.length > 0 || $scope.collectionFormData.postalFormData.length > 0 || $scope.collectionFormData.demandDraftFormData.length > 0) {

			//Cash
			if ($scope.collectionFormData.cashFormData.length > 0) {
				chequetotalPremium = parseFloat($scope.collectionFormData.cashFormData[0].cashAmount) + chequetotalPremium;
				delete $scope.collectionFormData.cashFormData[0].$$hashKey;
			}
			//Cheque
			if ($scope.collectionFormData.chequeFormData.length > 0) {
				for (i = 0; i < $scope.collectionFormData.chequeFormData.length; i++) {
					chequetotalPremium = parseFloat($scope.collectionFormData.chequeFormData[i].instrumentAmount) + chequetotalPremium;
					delete $scope.collectionFormData.chequeFormData[i].$$hashKey;
				}
			}
			//Postal Order
			if ($scope.collectionFormData.postalFormData.length > 0) {
				for (i = 0; i < $scope.collectionFormData.postalFormData.length; i++) {
					chequetotalPremium = parseFloat($scope.collectionFormData.postalFormData[i].collectionAmount) + chequetotalPremium;
					delete $scope.collectionFormData.postalFormData[i].$$hashKey;
				}
			}
			//Demand Draft
			if ($scope.collectionFormData.demandDraftFormData.length > 0) {
				for (i = 0; i < $scope.collectionFormData.demandDraftFormData.length; i++) {
					chequetotalPremium = parseFloat($scope.collectionFormData.demandDraftFormData[i].instrumentAmount) + chequetotalPremium;
					delete $scope.collectionFormData.demandDraftFormData[i].$$hashKey;
				}
			}
			totalPremium = chequetotalPremium;
		}
		//Amount Calculation for Net Banking
		else if ($scope.collectionFormData.netBankingFormData.length > 0) {
			var subCodeArr = $scope.collectionFormData.netBankingFormData;
			for (i = 0; i < $scope.collectionFormData.netBankingFormData.length; i++) {
				totalPremium = parseFloat($scope.collectionFormData.netBankingFormData[i].collectionAmount) + totalPremium;
				delete $scope.collectionFormData.netBankingFormData[i].$$hashKey;
			}

		}
		/*start changes for CR867*/
		else if ($scope.collectionFormData.ezetapFormData.length > 0) {
			for (i = 0; i < $scope.collectionFormData.ezetapFormData.length; i++) {
				totalPremium = parseFloat($scope.collectionFormData.ezetapFormData[i].collectionAmount) + totalPremium;
				delete $scope.collectionFormData.ezetapFormData[i].$$hashKey;
			}

		}
		/*end changes for CR867*/

		/* Amount Calculation for SPL CR_NP_779 Start */
		else if ($scope.collectionFormData.SendPaymentLinkFormData.length > 0) {
			var subCodeArr = $scope.collectionFormData.SendPaymentLinkFormData;
			for (i = 0; i < $scope.collectionFormData.SendPaymentLinkFormData.length; i++) {
				totalPremium = parseFloat($scope.collectionFormData.SendPaymentLinkFormData[i].collectionAmount) + totalPremium;
				delete $scope.collectionFormData.SendPaymentLinkFormData[i].$$hashKey;
			}

		}
		/* Amount Calculation for SPL CR_NP_779 End */

	};

	$scope.termFlag = false;
	$scope.collectionPaymentFlag = false;
	$scope.termFlagEze = false;/*changes for CR867*/
	$scope.SPLtermFlag = false; /* CR_NP_779 */
	
	var userID = {
		"stakemode": ""
	};
	var stakevalue = CommonServices.getCommonData("stakeCode");
    var chnl=CommonServices.getCommonData("channel");//changes for 754
	if (stakevalue == "AGENT") {
		userID.stakemode = "AG";
	}
	else if (stakevalue == "DEALER") {
	//changes for 754
		//userID.stakemode = "DL";
		if(chnl=="MISP")
        		{
        			userID.stakemode = "MS";
        		}
                else
                {
		userID.stakemode = "DL";
	}
        //end changes for 754
	}
	else if (stakevalue == "DEVLP-OFF") {
		userID.stakemode = "DO";
	}
	else {
		userID.stakemode = "";
	}

	if (CommonServices.deviceType == "I") {
		$scope.sourceTransaction = "MOB/AP" + userID.stakemode + "_NB";
	}
	else {
		$scope.sourceTransaction = "MOB/AN" + userID.stakemode + "_NB";
	}

	$scope.checkInstrumentName = function (i) { // CR 3546
		var isValid = false;
		$scope.instrumentNameCheck = false;
		var a = ($scope.collectionFormData.chequeFormData[i].instrumentName).toLowerCase();
		angular.forEach(CartServices.cartPaymentListing, function(cart, j) {
			var b = cart.policyHolderName.replace(/\s\s+/g, ' ').toLowerCase();
			if (a == b) {
				isValid = true;
				return;
			}
		});
		if (!isValid) {
			$scope.collectionForm.$invalid = true;
			$scope.instrumentNameCheck = true;
			// var msg = 'Instrument name on the cheque and policy holder name for one or more quotes are not same. Please check and retry again.';
			// CommonServices.showAlert(msg);
			// var instName = "instrumentName_"+i;
			// $scope.collectionForm[instName].$invalid = true;
		}
	}

	//MOB/ANAG_NB for Agent for Android agentApp
	//MOB/ANDL_NB for Dealer for Android agentApp
	//MOB/ANDO_NB for DO for Android agentApp
	//MOB/APAG_NB for Agent for Apple agentApp
	//MOB/APDL_NB for Dealer for Apple agentApp
	//MOB/APDO_NB for DO for Apple agentApp

	$scope.collectionPostData = function () {
        $scope.termsConditions= false;
		collectionNotDone = false;
		var stakevalue = CommonServices.getCommonData("stakeCode");
		var CollectionData = {
			"userProfile": {
				"userId": CommonServices.getCommonData("userCode").toUpperCase(),
				"loggedInRole": CommonServices.getCommonData("loggedInRole")
			},
			"quote": {
				"payment": {
					"totalAmount": $scope.netPremium,
					"paymentDetailsList": []
				}
			/*, // CR 3546
				"quoteNumber": $scope.quoteNumber,
				"productCode": CommonServices.getCommonData("productCode"),
				"mobPolicySource": $scope.sourceTransaction*/
			}
		};

		if (!$scope.isCartPaymenEnabled) {
			var pCode = (CommonServices.getCommonData("productCode") == undefined) ? $rootScope.productName : CommonServices.getCommonData("productCode");
			CollectionData.quote.quoteNumber = $scope.quoteNumber;
			CollectionData.quote.productCode = pCode;
			CollectionData.quote.mobPolicySource = $scope.sourceTransaction;

		} else { // CR 3546
			CollectionData.quote.bulkFlag = "Y";
		}

		if (extension === "esExtension") {
			CollectionData.quote.policyNumber = CommonServices.getCommonData("esPolicyNum");
			CollectionData.quote.currentStatus = CommonServices.getCommonData("validateStatus");
		}

		//only apd
		if ($scope.collectionFormData.apdFormData.length > 0) {
			if ($scope.isCartPaymenEnabled) { // CR 3546
				angular.forEach(CartServices.cartPaymentListing, function(cart, i) {
					var collectData = {
						'collectionMode': "APD",
						"collectionAmount": cart.netPremium,
						"quoteNumber": cart.quoteNo,
						'subCode': $scope.collectionFormData.apdFormData[0].subCode,
						'referenceNumber': $scope.collectionFormData.apdFormData[0].referenceNumber
					};
					CollectionData.quote.payment.paymentDetailsList.push(collectData);
				});

			} else {
			for (var i = 0; i < $scope.collectionFormData.apdFormData.length; i++) {
				var collectData = {
					'collectionMode': "APD",
					'collectionAmount': $scope.collectionFormData.apdFormData[i].collectionAmount,
					'subCode': $scope.collectionFormData.apdFormData[i].subCode,
					'referenceNumber': $scope.collectionFormData.apdFormData[i].referenceNumber
				};
				CollectionData.quote.payment.paymentDetailsList.push(collectData);
			}
		}
	}
		//cheque
		if ($scope.collectionFormData.chequeFormData.length > 0) {
			if ($scope.isCartPaymenEnabled) { // CR 3546
				angular.forEach(CartServices.cartPaymentListing, function(cart, i) {
					var data = $scope.collectionFormData.chequeFormData[0];
					var collectData = {
						"bankBranch":data.draweeBankBranch,
						"bankName":data.draweeBankName.bankName,
						"chequeOrDraftOrPODate":data.chequeDate,
						"chequeOrDraftOrPONumber":data.chequeNo,
						"chequeOrDraftOrPOType":data.chequeType.substring(0, 1),
						"collectionAmount":cart.netPremium,
						"quoteNumber":cart.quoteNo,
						"instrumentAmount":data.instrumentAmount,
						"instrumentName":data.instrumentName,
						"collectionMode":"CHQ"
					};
					CollectionData.quote.payment.paymentDetailsList.push(collectData);
				});
			} else {
				var data = $scope.collectionFormData.chequeFormData;
				for (var i = 0; i < data.length; i++) {
					var collectData = {
						'collectionAmount': data[i].collectionAmount,
						"instrumentAmount": data[i].instrumentAmount,
						"chequeOrDraftOrPODate": data[i].chequeDate,
						"chequeOrDraftOrPOType": data[i].chequeType.substring(0, 1),
						"chequeOrDraftOrPONumber": data[i].chequeNo,
						"bankName": data[i].draweeBankName.bankName,
						"bankBranch": data[i].draweeBankBranch,
						"excessAmount": data[i].excessAmount !== undefined && data[i].excessAmount !== "" ? data[i].excessAmount : 0,
						"collectionMode": "CHQ"
					};
					/*Added for CR_MOBL_0066 start*/

					var excesAmount= {
							"bankBranch": $scope.collectionFormData.chequeFormData[i].draweeBankBranch,
							"bankName": $scope.collectionFormData.chequeFormData[i].draweeBankName.bankName,
							"chequeOrDraftOrPODate": $scope.collectionFormData.chequeFormData[i].chequeDate,
							"chequeOrDraftOrPONumber": $scope.collectionFormData.chequeFormData[i].chequeNo,
							"chequeOrDraftOrPOType": data[i].chequeType.substring(0, 1),
							"collectionMode": "EXSC",
							"excessAmount": $scope.collectionFormData.chequeFormData[i].excessAmount
					};

					if($scope.excessAmountDraft){
					CollectionData.quote.payment.paymentDetailsList.push(collectData);
						CollectionData.quote.payment.paymentDetailsList.push(excesAmount);
					}

					else{
						CollectionData.quote.payment.paymentDetailsList.push(collectData);

					}
					/*Added for CR_MOBL_0066 end*/

				}
			}
		}
		//Cash
		if ($scope.collectionFormData.cashFormData.length > 0) {
			if ($scope.isCartPaymenEnabled) { // CR 3546
				angular.forEach(CartServices.cartPaymentListing, function(cart, i) {
					var collectData = {
						"collectionMode": "CSH",
						"quoteNumber": cart.quoteNo,
						"collectionAmount": cart.netPremium
					};
					CollectionData.quote.payment.paymentDetailsList.push(collectData);
				});

			} else {
				var collectData = {
					'collectionMode': "CSH",
					'collectionAmount': $scope.collectionFormData.cashFormData[0].cashAmount
				};
				CollectionData.quote.payment.paymentDetailsList.push(collectData);
			}
		}
		//NB
		if ($scope.collectionFormData.netBankingFormData.length > 0) {
			$scope.termFlag = true;
			return false;
		}

		//DD
		if ($scope.collectionFormData.demandDraftFormData.length > 0) {
			var data = $scope.collectionFormData.demandDraftFormData;
			for (var i = 0; i < data.length; i++) {
				var collectData = {
					'collectionAmount': data[i].collectionAmount,
					"instrumentAmount": data[i].instrumentAmount,
					"chequeOrDraftOrPODate": data[i].ddDate,
					"chequeOrDraftOrPOType": data[i].chequeType.substring(0, 1),
					"chequeOrDraftOrPONumber": data[i].chequeNo,
					"bankName": data[i].draweeBankName.bankName,
					"bankBranch": data[i].draweeBankBranch,
					"excessAmount": data[i].excessAmount !== undefined && data[i].excessAmount !== "" ? data[i].excessAmount : 0,
					"collectionMode": "DRF"
				};
				/*Added for CR_MOBL_0066 start*/

				var excesAmount= {
						"bankBranch": $scope.collectionFormData.demandDraftFormData[i].draweeBankBranch,
						"bankName": $scope.collectionFormData.demandDraftFormData[i].draweeBankName.bankName,
						"chequeOrDraftOrPODate": $scope.collectionFormData.demandDraftFormData[i].chequeDate,
						"chequeOrDraftOrPONumber": $scope.collectionFormData.demandDraftFormData[i].chequeNo,
						"chequeOrDraftOrPOType": data[i].chequeType.substring(0, 1),
						"collectionMode": "EXSC",
						"excessAmount": $scope.collectionFormData.demandDraftFormData[i].excessAmount
				};
				if($scope.excessAmountDraft){
				CollectionData.quote.payment.paymentDetailsList.push(collectData);
					CollectionData.quote.payment.paymentDetailsList.push(excesAmount);
				}

				else{
				CollectionData.quote.payment.paymentDetailsList.push(collectData);

				}
				/*Added for CR_MOBL_0066 end*/

			}
		}
		//PO
		if ($scope.collectionFormData.postalFormData.length > 0) {
			var data = $scope.collectionFormData.postalFormData;
			for (var i = 0; i < data.length; i++) {
				var collectData = {
					'collectionAmount': data[i].collectionAmount,
					"instrumentAmount": data[i].collectionAmount,
					"chequeOrDraftOrPODate": data[i].poDate,
					"chequeOrDraftOrPOType": data[i].chequeType.substring(0, 1),
					"chequeOrDraftOrPONumber": data[i].chequeNo,
					"bankName": data[i].draweeBankName.bankName,
					"bankBranch": data[i].draweeBankBranch,
					"collectionMode": "PO"
				};
				CollectionData.quote.payment.paymentDetailsList.push(collectData);
			}
		}

		/*Start changes for CR867*/
		if ($scope.collectionFormData.ezetapFormData.length > 0) {//chnages for CR867
			$scope.termFlagEze = true;
			return false;
		}
		/*end changes for CR867*/
		
		/* SPL CR_NP_779 Start */
		if ($scope.collectionFormData.SendPaymentLinkFormData.length > 0) {
			$scope.SPLtermFlag = true;
			return false;
		}
		/* SPL CR_NP_779 End */

		// CR 3546
		CommonServices.setCommonData("cartPaymentDetails", {
			'quoteNumberArr': $scope.quoteNumberArr,
			'netPremium': $scope.netPremium
		});
		
		var collectionResponse = RestServices.postService(RestServices.urlPathsNewPortal.collection, CollectionData);
		collectionResponse.then(
			function (response) {
				CommonServices.showLoading(false);
				if (response.data.userProfile !== undefined && response.data.userProfile !== "") {
					if (response.data.userProfile.footer.errorCode !== "1") {
						CommonServices.showLoading(false);
						/**CR690 Start**/
						if (response.data.userProfile.footer.errorCode === "35145") {
							$rootScope.panmodalOpen = true;
							CommonServices.setCommonData("setPanMsg", response.data.userProfile.footer.errorDescription);
						}
						/**CR690 End**/

						/*** CR_3773 Start ***/
						// if(response.data.userProfile.footer.errorCode === "0002") {
						// 	CommonServices.messageModal('info', msg, false, 'Retry', 'Cancel', function () { 
						// 		$scope.redirectToCollectionPage();
						// 	}, function () { 
						// 		$scope.abortTransactionAndGoToDashboard(); 
						// 	}, 'Alert', true);
						// }
						/*** CR_3773 End ***/
						else {
							var msg = response.data.userProfile.footer.errorDescription;
							CommonServices.messageModal('info', msg, false, '', 'Ok', function(){}, function(){
								if ($scope.isCartPaymenEnabled) { // CR 3546
									$state.go("home");
								}
							}, 'Alert');
							// CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
						}

					} else {
						var msg = response.data.userProfile.footer.errorDescription;
						if ($scope.isCartPaymenEnabled) { // CR 3546
							msg = 'Premium collection is successful. Policy for all quotes will be generated within 30 minutes. Once the policies are issued you can search the same on your dashboard by the collection number.';
						}
		       			CommonServices.messageModal('info', msg, false, '', 'Ok', function () {}, function () { collectExitFunction(1);}, 'Alert');


						// if (CommonServices.deviceType !== "NA")
						// 	navigator.notification.confirm(response.data.userProfile.footer.errorDescription, collectExitFunction, "Alert", ["Ok"]);
						// else {
						// 	var approvePayment;
						// 	$scope.collectionPaymentFlag = false;
						// 	CommonServices.setCommonData("collectionPaymentFlag", $scope.collectionPaymentFlag);
						// 	approvePayment = confirm(response.data.userProfile.footer.errorDescription);
						// 	if (approvePayment === true) {
						// 		collectExitFunction(1);
						// 	}
						// }

						var paymentConfirmation = { "paymentConfirmation": response.data };
						CommonServices.setCommonData("paymentConfirmation", paymentConfirmation);

					}
				}
				else {
					CommonServices.showAlert(response.data.errorMessage);
				}


			},
			function (error) { // failure 
				CommonServices.showLoading(false);
				RestServices.handleWebServiceError(error);
			});
	};

	function collectExitFunction(button) {
		$state.go("acknowledgement");
	}

	//Payment by BillDesk
	$scope.payNow = function () {
		$scope.billDesk(CommonServices.getCommonData("CollectionPaymentDetails"));
		return;
	}
	/*start chnages for CR867*/
	//Payment by Ezetap
	$scope.payEze = function () {
        $("#payEze").attr('disabled','disabled');
        //$scope.termsConditions= false;
        $scope.fetchPolicyHolderDetails($scope.policyHolderCode);
		$scope.ezeTap(CommonServices.getCommonData("CollectionPaymentDetails"));
		return;
	}
	/*end chnages for CR867*/
	$scope.collectionFormSubmit = function () {
		if ($scope.collectionFormData.chequeFormData.length > 0 || $scope.collectionFormData.cashFormData.length > 0 || $scope.collectionFormData.apdFormData.length > 0 || $scope.collectionFormData.netBankingFormData.length > 0 || $scope.collectionFormData.postalFormData.length > 0 || $scope.collectionFormData.demandDraftFormData.length > 0 || $scope.collectionFormData.ezetapFormData.length > 0 || $scope.collectionFormData.SendPaymentLinkFormData.length > 0 ) {//changes for CR867 // CR_NP_779
			$scope.addCollAmount();
			var netpremium = parseFloat($scope.netPremium);
			$scope.excessAmount=totalPremium -netpremium;     /*Added for CR_MOBL_0066 */

			if (totalPremium == netpremium && chequeIdDuplicate != true) {

				$scope.collectionPostData();
			}
			else if (chequeIdDuplicate == true) {
				CommonServices.showAlert("Cheque number cannot be same for multiple cheques");
			}
			else if (totalPremium > netpremium) {
			/*Added for CR_MOBL_0066 start*/
				if($scope.excessAmountDraft)
				{
				var msg = "There is an excess of <span class='RupeeSymbol'>₹</span><b><strong>"+$scope.excessAmount+"</b></strong> in the instrument amount.Would you like to proceed with Policy issuance?";

				// $scope.Confirm(msg, 'Yes', 'No');   
				CommonServices.messageModal('info', msg, false, 'No', 'Yes', function () {}, function () { 					$scope.collectionPostData();
                }, 'Alert');

				// CommonServices.showAlert("Total collection amount is exceeding quote amount. Please review");
			}
			/*Added for CR_MOBL_0066 end*/
				else{
                CommonServices.showAlert("Total collection amount is exceeding quote amount. Please review");}
			}
			else if (totalPremium < netpremium) {
				CommonServices.showAlert("Total collection amount is less than quote amount. Please review");
			}
		}
		else {
			if (submitCollection == true) {
				CommonServices.showAlert("Please add collection mode(s)");
			} else {
				CommonServices.showAlert("We are unable to process your request, as there is no collection modes available for this user.");
			}
		}

	};

	$scope.billDesk = function (fetchQuoteDetails) {

		var refBillDesk = "";
		var refhref = (CommonServices.getCommonData(refhref) != undefined)? CommonServices.getCommonData(refhref): "";  //changed for CR_3773
		if(refhref == ""){		//changed for CR_3773
			if ($scope.isCartPaymenEnabled) {
				refhref = RestServices.urlBillDesk + '?quoteNo=' + $scope.quoteNumberArr.join(',') +
					'&productCode=' + fetchQuoteDetails[0].productCode +
					'&netPremium=' + $scope.netPremium +
					'&userCode=' + CommonServices.getCommonData("userCode").toUpperCase() +
					'&partyCode=' + CommonServices.getCommonData("partyCode") +
					'&phoneNo=' + CommonServices.getCommonData("collectionDetails").mobileNum +
					'&emailId=' + CommonServices.getCommonData("collectionDetails").emailID +
					'&isOMPExtn=' + $scope.ompextn + 
					'&sourceTransaction=' + $scope.sourceTransaction +
					'&isRenewal=N' +
					'&oldPolicyNum=' + $scope.oldPolicy + 
					'&userType=' + stakevalue + 
					'&policyType=NB&channel=' + stakevalue + 
					'&language=English&bulkFlag=Y';
			}
			else {//CommonServices.getCommonData("productCode") //going null value in url
				refhref = RestServices.urlBillDesk + '?quoteNo=' + fetchQuoteDetails.quoteNumber +
					'&productCode=' + $rootScope.productName +
					'&netPremium=' + $scope.netPremium +
					'&userCode=' + CommonServices.getCommonData("userCode").toUpperCase() +
					'&partyCode=' + CommonServices.getCommonData("partyCode") +
					'&phoneNo=' + CommonServices.getCommonData("collectionDetails").mobileNum +
					'&emailId=' + CommonServices.getCommonData("collectionDetails").emailID +
					'&isOMPExtn=' + $scope.ompextn + '&sourceTransaction=' + $scope.sourceTransaction +
					'&isRenewal=N&oldPolicyNum=' + $scope.oldPolicy + 
					'&userType=' + stakevalue + 
					'&policyType=NB&channel=' + stakevalue + 
					'&language=English';
			}
			// CommonServices.setCommonData("refhref", refhref);		//CR_3773
		}
		var dsdasd = $rootScope.partyCode;

		var billdeskServer = RestServices.urlBillDeskServer;
		var billDeskFingerPrint = RestServices.urlBillDeskFingerPrint;
		// window.plugins.sslCertificateChecker.check(billdeskSuccessCallback, billdeskErrorCallback, billdeskServer, billDeskFingerPrint);
	//	billdeskSuccessCallback("CONNECTION_SECURE"); // by passing ssl check - Subhapam
		if($rootScope.environment == 'p')
		{
			window.plugins.sslCertificateChecker.check(billdeskSuccessCallback, billdeskErrorCallback, billdeskServer, billDeskFingerPrint);
		}
		else 
		{
			billdeskSuccessCallback("CONNECTION_SECURE"); // by passing ssl check - Subhapam
		}

		function billdeskSuccessCallback(message) {

			// Message is always: CONNECTION_SECURE.
			// Now do something with the trusted server.

			CommonServices.showLoading(false);
			//refBillDesk = cordova.InAppBrowser.open(refhref, '_blank'); //, 'location=no,hidden=yes,EnableViewPortScale=yes,disallowoverscroll=yes');
			refBillDesk = cordova.InAppBrowser.open(refhref, '_blank', 'location=no,hidden=yes,EnableViewPortScale=yes,disallowoverscroll=yes');
			// refBillDesk = window.open(refhref, '_blank', 'location=no,hidden=yes,EnableViewPortScale=yes,disallowoverscroll=yes'); // by passing cordova plugin for payment - Subhapam

			refBillDesk.addEventListener('loadstart', inAppBrowserbLoadStart);
			refBillDesk.addEventListener('loadstop', inAppBrowserbLoadStop);
			refBillDesk.addEventListener('exit', inAppBrowserClose);

		}

		function billdeskErrorCallback(message) {

			if (message == "CONNECTION_NOT_SECURE") {
				CommonServices.showAlert("Could not connect to server. Suspicious connection detected", 'Error');
				//navigator.app.exitApp();

				// There is likely a man in the middle attack going on, be careful!
			} else if (message.indexOf("CONNECTION_FAILED") > -1) {

				// There was no connection (yet). Internet may be down. Try again (a few times) after a little timeout.
				if (!navigator.onLine) {
					CommonServices.showAlert("Error Message : No internet connection available. Please check your network and try again.", 'No Network');
					return;
				} else
					CommonServices.showAlert("Could not connect to server. Please try again later or check your network settings", 'Error');
			}
		}

		/* Bill Desk code opens in inappbrowser */

		function inAppBrowserbLoadStart(event) {

			if ((event.url).indexOf("middleDemo.jsp") > -1) {
				refBillDesk.show();
			}
		}

		function inAppBrowserbLoadStop(event) {

			var getPaymentDetailsInputData = {
				"quote": {
					"quoteNumber": $scope.quoteNumber
				},
				"paymentGateway": "BILLDESK"
			};

			var storeEvent = event;

			if ((event.url).indexOf("middleDemo.jsp") > -1) {
				refBillDesk.show();
			}

			if ((event.url).indexOf("PaymentResponse") > -1) {
				setTimeout(function () {

					var getPaymentDetailsResp = RestServices.postService(RestServices.urlPathsNewPortal.getPaymentDetails, getPaymentDetailsInputData);
					getPaymentDetailsResp.then(function (response) {

						$scope.collectionPaymentFlag = true;
						CommonServices.setCommonData("collectionPaymentFlag", $scope.collectionPaymentFlag);
						if (response.data.errorCode === "0") {
							CommonServices.setCommonData("billdeskQuote", $scope.quoteNumber);
							CommonServices.setCommonData("billdeskResponse", response.data);
							//angular.extend($rootScope.travelData,{"paymentConfirmation":response.data});
							CommonServices.setCommonData("paymentMode", "billdesk");
							if (response.data.authId === "0300" && response.data.policyNo === undefined) {

								// Payment success and Policy Issuance failure
								refBillDesk.close();
								CommonServices.showLoading(false);

								$scope.showViewPolDetailsBtn = false;
								CommonServices.setCommonData("responseFlag", $scope.showViewPolDetailsBtn);
								CommonServices.setCommonData("refhref", undefined);		//CR_3773
								$state.go("acknowledgement");

							} else if (response.data.authId === "0300" && response.data.policyNo != undefined) {

								// Payment success and Policy Issuance success
								refBillDesk.close();
								CommonServices.showLoading(false);
								$scope.showViewPolDetailsBtn = true;
								CommonServices.setCommonData("responseFlag", $scope.showViewPolDetailsBtn);
								CommonServices.setCommonData("refhref", undefined);		//CR_3773
								$state.go("acknowledgement");
							} 
							// else if(response.data.authId === "0002") { /*** CR_3773 Start ***/
							// 	refBillDesk.close();
							// 	CommonServices.showLoading(false);
							// 	let msg = "Your transaction has not been successful. If the amount has been debited, it will be auto-refunded. Do you want to retry the transaction?";
							// 	CommonServices.messageModal('info', msg, false, 'Yes', 'No', function () { 
							// 		$state.go("collectionPage");
							// 	}, function () { 
							// 		CommonServices.setCommonData("refhref", undefined);
							// 		$state.go("home");
							// 	}, 'Alert', true);
							// } /*** CR_3773 End ***/

							 else {
								// Payment failure
								refBillDesk.close();
								CommonServices.showLoading(false);
								$scope.showViewPolDetailsBtn = false;
								CommonServices.setCommonData("responseFlag", $scope.showViewPolDetailsBtn);
								CommonServices.setCommonData("refhref", undefined);		//CR_3773
								$state.go("acknowledgement");
							}
						}
						else {
							refBillDesk.close();
							CommonServices.showLoading(false);
							CommonServices.showAlert("Could not connect to server, please try again after some time");
							CommonServices.setCommonData("refhref", undefined);		//CR_3773
							$state.go('home');
						}

					}, function (error) { // failure 
						CommonServices.showLoading(false);
						RestServices.handleWebServiceError(error);
						refBillDesk.close();
						CommonServices.setCommonData("refhref", undefined);		//CR_3773
						/*$location.href("/buyRenewPolicy/collectData");*/
						$state.go('home');
					});

				}, 2000);
			}
		}


		function inAppBrowserClose(event) {
			CommonServices.showLoading(false);
		}

	}

	/* bill desk ends here */

	/*start changes for CR867*/

	$scope.fetchPolicyHolderDetails=function(policyHolderCode)
    	{

    		var policyHolderData = {
    					"userProfile": {
    						"userId": CommonServices.getCommonData("userId"),
    						"loggedInRole": "SUPERUSER"
    					}, "partyDetails": { "partyCode": policyHolderCode}
    				};
    	    var policyHolderResponse = RestServices.postService(RestServices.urlPathsNewPortal.getPolicyHolderDetail, policyHolderData);
    			policyHolderResponse.then(
    				function (response) { // success

    					CommonServices.showLoading(false);

    					if (response.data.partyDetails !== undefined) {

    						//console.log("policy holder details::"+JSON.stringify(response.data));
    						$scope.customerData=response.data.partyDetails.individualDetails;
    						//console.log("policy holder details::"+JSON.stringify($scope.customerData));

    					} else {

    						CommonServices.showLoading(false);
                            RestServices.handleWebServiceError("Customer Data not found");
    					}
    				},
    				function (error) { // failure
    					CommonServices.showLoading(false);
    					RestServices.handleWebServiceError(error);
    				});


    	}


	 $scope.quoteNo="";
	  $scope.txnId="";
	$scope.ezeTap = function (fetchQuoteDetails) {
		//alert('take it eze!!!!')
		//middle ware caled before ezetap initialize.
		//console.log("Initialize. cardPayment"+JSON.stringify(fetchQuoteDetails));
        $scope.quoteNo=fetchQuoteDetails.quoteNumber;
		var paymentGatewayInput = {
            "quoteNo": fetchQuoteDetails.quoteNumber,
            "premAmount": $scope.netPremium,
            "productCode": CommonServices.getCommonData("productCode"),
            "productName": fetchQuoteDetails.productName,
            "isRenewal":"N",
            "oldPolicyNo": $scope.oldPolicy,
            "isOMPExtn": $scope.ompextn,
            "quoteCreatedBy": null,
            "roleCode": CommonServices.getCommonData("loggedInRole"),
            "emailId": CommonServices.getCommonData("collectionDetails").emailID,
            "phoneNo": CommonServices.getCommonData("collectionDetails").mobileNum,
            "channel": CommonServices.getCommonData("stakeCode"),
            "policyType":"NB",
            "userId": CommonServices.getCommonData("userCode").toUpperCase(),
            "userType": CommonServices.getCommonData("stakeCode"),
		};
        var paymentGatewayInputResp = RestServices.postService(RestServices.urlPathsNewPortal.paymentGatewayInput, paymentGatewayInput);

        paymentGatewayInputResp.then(
            function (response){
                        //alert("success");
                        //console.log("getPaymentDetailsEasyTab responsedata: "+JSON.stringify(response));
                        if(response.data.errCode==="0")
                        {
                        $scope.txnId=response.data.msg;
                        //console.log("getPaymentDetailsEasyTab responsedata: "+JSON.stringify(response));

                        $scope.initEzetap();
                        }
                        else
                        {
                        //CommonServices.showLoading(false);
                        $('#loader').hide();
                        RestServices.handleWebServiceError(response.data.msg);
                        }
            },
            function (error)
            { // failure

                //alert("error");
                //console.log("getPaymentDetailsEasyTab errordata: "+JSON.stringify(error));
                //CommonServices.showLoading(false);
                 $('#loader').hide();
                 $("#payEze").removeAttr('disabled');
            	RestServices.handleWebServiceError(error);

            });

		//$scope.initEzetap();
        //$scope.prepEzetap();
        //$scope.cardPayment(fetchQuoteDetails);

	}
	$scope.initEzetap = function(){
	        var EzetapConfig = {
              		   "demoAppKey": "33fae79c-d2cf-4823-a01e-521c90072e64",
              		   "prodAppKey": "33fae79c-d2cf-4823-a01e-521c90072e64",
              		   "merchantName": "THE_NEW_INDIA_ASSURANCE",
              		   "userName": "7506375958",
              		   "currencyCode": "INR",
              		   "appMode": "DEMO",
              		   "captureSignature": "false",
              		   "prepareDevice": "true"
              	};

              cordova.exec(ezeTapSuccessCallBack,ezeTapFailureCallBack,"EzeAPIPlugin","initialize",
                			[EzetapConfig]);
    		  function ezeTapSuccessCallBack(response){
            		//CommonServices.showAlert("Transaction successful. initEzetap"+JSON.stringify(response));
            		//$scope.prepEzetap();
            		$scope.cardPayment();
            	};
              function ezeTapFailureCallBack(response){
            		$scope.closeEzetap();
                    //console.log("Transaction failed. cardPayment"+JSON.parse(response));
                    $scope.errorResponsedata=JSON.parse(response);
                    //console.log("Transaction failed. cardPayment"+JSON.stringify($scope.errorResponsedata));
                    //CommonServices.showLoading(false);
                    $('#loader').hide();
                     $("#payEze").removeAttr('disabled');
                     //alert("ezeTapFailureCallBack");
                    CommonServices.showAlert($scope.errorResponsedata.error.message);
            	};
	}
	$scope.prepEzetap = function(){
                  cordova.exec(ezeTapSuccessCallBack,ezeTapFailureCallBack,"EzeAPIPlugin","prepareDevice",[]);
        		  function ezeTapSuccessCallBack(response){
                		//CommonServices.showAlert("Transaction successful. prepEzetap"+JSON.stringify(response));
                		$scope.cardPayment();
                	};
                  function ezeTapFailureCallBack(response){
                		$scope.closeEzetap();
                        //console.log("Transaction failed. cardPayment"+JSON.parse(response));
                        $scope.errorResponsedata=JSON.parse(response);
                        //console.log("Transaction failed. cardPayment"+JSON.stringify($scope.errorResponsedata));
                        //CommonServices.showLoading(false);
                        $('#loader').hide();
                         //alert("shhhhh");
                        CommonServices.showAlert($scope.errorResponsedata.error.message);
                	};
    	}
    $scope.cardPayment = function(){
                    var Request = {
                                    "amount": $scope.netPremium, //jsonRequest.put("amount", 0.00);
                                    "mode": "SALE", //jsonRequest.put("mode", "SALE | CASHBACK | CASH@POS");

                                    "options": {//jsonRequest.put("options", jsonOptionalParams);
                                        "amountCashback": 0.0,//jsonOptionalParams.put("amountCashback",0.00);
                                        "amountTip": 0.0,//jsonOptionalParams.put("amountTip",0.00);
                                        "references": { //jsonOptionalParams.put("references",jsonReferences);
                                            //Building References Object
                                            "reference1":$scope.quoteNo,
                                            "reference2":$scope.txnId
                                        },
                                        "customer": {//jsonOptionalParams.put("customer",jsonCustomer);
                                        //Building Customer Object
                                            "name":$scope.customerData.firstName+" "+$scope.customerData.lastName,
                                            "mobileNo":$scope.customerData.mobileNo,
                                            "email":$scope.customerData.emailId
                                        }
                                    },
                            };


                      console.log("Ezetap request json::"+JSON.stringify(Request));
                      cordova.exec(ezeTapSuccessCallBack,ezeTapFailureCallBack,"EzeAPIPlugin","cardTransaction",[Request]);
            		  function ezeTapSuccessCallBack(response){
                    		//CommonServices.showAlert("Transaction successful. cardPayment"+JSON.stringify(response));

                    		$scope.inputResponsedata=JSON.parse(response);
                    		//console.log("Transaction successful. cardPayment"+$scope.inputResponsedata);
                    		$scope.inputResponsedata.userType=CommonServices.getCommonData("stakeCode");
                    		//console.log("policy source "+ $scope.sourceTransaction);
                    		$scope.inputResponsedata.policySource=$scope.sourceTransaction;
                    		$scope.inputResponsedata.userId=CommonServices.getCommonData("userCode").toUpperCase();

                    		//console.log("Transaction successful. cardPayment"+JSON.stringify($scope.inputResponsedata));
                    		//middleware called for response update.
                    		 $scope.issuePolicy($scope.inputResponsedata);
                    		 $scope.closeEzetap();
                    	};
                      function ezeTapFailureCallBack(response){
                            $scope.closeEzetap();
                    		//console.log("Transaction failed. cardPayment"+JSON.parse(response));
                            $scope.errorResponsedata=JSON.parse(response);
                            //console.log("Transaction failed. cardPayment"+JSON.stringify($scope.errorResponsedata));
                            //CommonServices.showLoading(false);
                            $('#loader').hide();
                             $("#payEze").removeAttr('disabled');
                            //alert("shhhhh");
                            CommonServices.showAlert($scope.errorResponsedata.error.message);

                    	};
        	}
       $scope.closeEzetap = function(){
                      cordova.exec(ezeTapSuccessCallBack,ezeTapFailureCallBack,"EzeAPIPlugin","close",[]);
               		  function ezeTapSuccessCallBack(response){
                       		//CommonServices.showAlert("Transaction successful."+JSON.stringify(response));
                            //CommonServices.showLoading(false);
                             //$('#loader').hide();
                       	};
                         function ezeTapFailureCallBack(response){
                         $scope.errorResponsedata=JSON.parse(response);
                         //console.log("Transaction failed. cardPayment"+JSON.stringify($scope.errorResponsedata));
                         //CommonServices.showLoading(false);
                         $('#loader').hide();
                         CommonServices.showAlert($scope.errorResponsedata.error.message);
                       	};
           	}


          /****adeed by kausik****/
          $scope.issuePolicy=function(ezeTapResponse)
          {

              //var localMiddleWareUrl="http://01hw363146:7777/BaNCSIntegrationWebComp/rest/mobPaymentGateway/processEzetapResponse"
             // RestServices.urlPathsNewPortal.getPaymentGatewayURL
             //console.log("input issuepolicy"+JSON.stringify(ezeTapResponse));
              var paymentGatewayInputResp = RestServices.postService(RestServices.urlPathsNewPortal.processEzetapResponse,ezeTapResponse);
                     paymentGatewayInputResp.then(function (response){
                                            //console.log("Success reponse from processEzetapResponse: "+JSON.stringify(response));
                                            $scope.collectionPaymentFlag = true;
                     						CommonServices.setCommonData("ezetapCollectionPaymentFlag", $scope.collectionPaymentFlag);
                     						//console.log("error code::"+response.data.userProfile.footer.errorCode);
                     						var vErrorCode=response.data.userProfile.footer.errorCode;
                     						//console.log("vErrorCode code::"+vErrorCode);
                     						//alert(vErrorCode);
                     						if (vErrorCode == "0") {
                     							CommonServices.setCommonData("ezetapQuote", response.data.quote.quoteNumber);
                     							CommonServices.setCommonData("ezetapResponse", response.data);
                     							//angular.extend($rootScope.travelData,{"paymentConfirmation":response.data});
                     							CommonServices.setCommonData("paymentMode", "ezetap");
                     							//if (response.data.authId === "0300" && response.data.quote.policyNumber === undefined) {
                     							//console.log("inside 0");
                     							//console.log("policy number::"+response.data.quote.policyNumber);
                                                  if (response.data.quote.policyNumber === undefined) {
                     								// Payment success and Policy Issuance failure
                     								//refBillDesk.close();
                     								//CommonServices.showLoading(false);
                                                    $('#loader').hide();
                     								//console.log("inside first condition");

                     								$scope.showViewPolDetailsBtn = false;
                     								CommonServices.setCommonData("ezetapResponseFlag", $scope.showViewPolDetailsBtn);
                     								$state.go("acknowledgement");

                     							} else if (response.data.quote.policyNumber != undefined) {

                     								// Payment success and Policy Issuance success
                     								//refBillDesk.close();
                                                    //CommonServices.showLoading(false);
                                                     $('#loader').hide();
                     								//console.log("inside second condition");
                     								$scope.showViewPolDetailsBtn = true;
                     								CommonServices.setCommonData("ezetapResponseFlag", $scope.showViewPolDetailsBtn);
                     								$state.go("acknowledgement");
                     							} else {
                     								// Payment failure
                     								//refBillDesk.close();
                     								//console.log("inside third condition");
                                                    //CommonServices.showLoading(false);
                                                     $('#loader').hide();
                     								$scope.showViewPolDetailsBtn = false;
                     								CommonServices.setCommonData("ezetapResponseFlag", $scope.showViewPolDetailsBtn);
                     								$state.go("acknowledgement");
                     							}
                     						} else {

                     						    //console.log("inside third condition");
                     							//refBillDesk.close();
                                                //CommonServices.showLoading(false);

                                                console.log("error code::"+response.data.userProfile.footer.errorCode);
                                                CommonServices.setCommonData("ezetapQuote", response.data.quote.quoteNumber);
                                                CommonServices.setCommonData("ezetapResponse", response.data);
                                                //angular.extend($rootScope.travelData,{"paymentConfirmation":response.data});
                                                CommonServices.setCommonData("paymentMode", "ezetap");

                                                 $('#loader').hide();
                     							CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
                     							$scope.showViewPolDetailsBtn = false;
                                                CommonServices.setCommonData("ezetapResponseFlag", $scope.showViewPolDetailsBtn);
                                                $state.go("acknowledgement");
                     							//$state.go('home');
                     						}




                     }, function (error)
                     {
                          //console.log("Error reponse from processEzetapResponse "+JSON.stringify(error));
                         //RestServices.handleWebServiceError(error);
                         //CommonServices.showLoading(false);
                          $('#loader').hide();
                         RestServices.handleWebServiceError(error);

                     });

          }

          /*****added by kausik end***
	/*end changes for CR867*/

    /* CR_NP_779 Start */	
	
  $scope.FetchEmailIDMobileNoDetails = function() {
        $scope.SPLProductCode = $rootScope.productName;
        /* Two Wheeler	 */
        if ($scope.SPLProductCode === 'TW') {
                $scope.SPLProductName = "Two Wheeler";
                $scope.AgentInsuredDetails = $scope.buyNow.twoWheeler.insuredDetails;
                if ($scope.AgentInsuredDetails.individualDetails !== undefined) {
                        $scope.SPLAgentEmalid = $scope.AgentInsuredDetails.individualDetails.emailId;
                        $scope.SPLAgentMobileNo = $scope.AgentInsuredDetails.individualDetails.mobileNo;
                        $scope.SPLAgentFirstName = $scope.AgentInsuredDetails.individualDetails.firstName !== undefined ? $scope.AgentInsuredDetails.individualDetails.firstName.toUpperCase() : "";
                        $scope.SPLAgentMiddleName = $scope.AgentInsuredDetails.individualDetails.middleName !== undefined ? $scope.AgentInsuredDetails.individualDetails.middleName.toUpperCase() : "";
                        $scope.SPLAgentLastName = $scope.AgentInsuredDetails.individualDetails.lastName !== undefined ? $scope.AgentInsuredDetails.individualDetails.lastName.toUpperCase() : "";
                        $scope.SPLAgentFullName = $scope.SPLAgentFirstName + ' ' + $scope.SPLAgentMiddleName + ' ' + $scope.SPLAgentLastName;
                } else if ($scope.AgentInsuredDetails.organizationDetails !== undefined) {
                        $scope.SPLAgentEmalid = $scope.AgentInsuredDetails.organizationDetails.emailId;
                        $scope.SPLAgentMobileNo = $scope.AgentInsuredDetails.organizationDetails.mobileNo;
                        $scope.SPLAgentFirstName = $scope.AgentInsuredDetails.organizationDetails.firstName !== undefined ? $scope.AgentInsuredDetails.organizationDetails.firstName.toUpperCase() : "";
                        $scope.SPLAgentMiddleName = $scope.AgentInsuredDetails.organizationDetails.middleName !== undefined ? $scope.AgentInsuredDetails.organizationDetails.middleName.toUpperCase() : "";
                        $scope.SPLAgentLastName = $scope.AgentInsuredDetails.organizationDetails.lastName !== undefined ? $scope.AgentInsuredDetails.organizationDetails.lastName.toUpperCase() : "";
                        $scope.SPLAgentFullName = $scope.SPLAgentFirstName + ' ' + $scope.SPLAgentMiddleName + ' ' + $scope.SPLAgentLastName;
                }
        }
        /* Personal Accident */
        else if ($scope.SPLProductCode === 'PU') {
                $scope.SPLProductName = "Personal Accident";
                $scope.SPLAgentEmalid = $scope.buyNow.personalAccident.insuredDetails.mailId;
                $scope.SPLAgentMobileNo = $scope.buyNow.personalAccident.insuredDetails.mobileNo;
                $scope.SPLAgentFirstName = $scope.buyNow.personalAccident.insuredDetails.fName !== undefined ? $scope.buyNow.personalAccident.insuredDetails.fName.toUpperCase() : "";
                $scope.SPLAgentMiddleName = $scope.buyNow.personalAccident.insuredDetails.mName !== undefined ? $scope.buyNow.personalAccident.insuredDetails.mName.toUpperCase() : "";
                $scope.SPLAgentLastName = $scope.buyNow.personalAccident.insuredDetails.lName !== undefined ? $scope.buyNow.personalAccident.insuredDetails.lName.toUpperCase() : "";
                $scope.SPLAgentFullName = $scope.SPLAgentFirstName + ' ' + $scope.SPLAgentMiddleName + ' ' + $scope.SPLAgentLastName;
        }
        /* Griha Suvidha */
        else if ($scope.SPLProductCode === 'GS') {
                $scope.SPLProductName = "New India Griha Suvidha Policy";
                $scope.SPLAgentEmalid = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.emailId;
                $scope.SPLAgentMobileNo = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.mobileNo;
                $scope.SPLAgentFirstName = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.firstName !== undefined ? $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.firstName.toUpperCase() : "";
                $scope.SPLAgentMiddleName = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.middleName !== undefined ? $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.middleName.toUpperCase() : "";
                $scope.SPLAgentLastName = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.lastName !== undefined ? $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.lastName.toUpperCase() : "";
                $scope.SPLAgentFullName = $scope.SPLAgentFirstName + ' ' + $scope.SPLAgentMiddleName + ' ' + $scope.SPLAgentLastName;
        }
        /* Business & Holidays */
        else if ($scope.SPLProductCode === 'BH') {
                $scope.SPLProductName = "Business & Holidays"
                $scope.SPLAgentEmalid = $rootScope.travelData.savedPartyDetails.partyDetails.individualDetails.emailId;
                $scope.SPLAgentMobileNo = $rootScope.travelData.savedPartyDetails.partyDetails.individualDetails.mobileNo;
                $scope.SPLAgentFirstName = $rootScope.travelData.savedPartyDetails.partyDetails.individualDetails.firstName !== undefined ? $rootScope.travelData.savedPartyDetails.partyDetails.individualDetails.firstName.toUpperCase() : "";
                $scope.SPLAgentMiddleName = $rootScope.travelData.savedPartyDetails.partyDetails.individualDetails.middleName !== undefined ? $rootScope.travelData.savedPartyDetails.partyDetails.individualDetails.middleName.toUpperCase() : "";
                $scope.SPLAgentLastName = $rootScope.travelData.savedPartyDetails.partyDetails.individualDetails.lastName !== undefined ? $rootScope.travelData.savedPartyDetails.partyDetails.individualDetails.lastName.toUpperCase() : "";
                $scope.SPLAgentFullName = $scope.SPLAgentFirstName + ' ' + $scope.SPLAgentMiddleName + ' ' + $scope.SPLAgentLastName;
        }
        /* Top Up */
        else if ($scope.SPLProductCode === 'TU') {
                $scope.SPLProductName = "New India Top Up Mediclaim";
                $scope.SPLAgentEmalid = CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.emailId;
                $scope.SPLAgentMobileNo = CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.mobileNo;
                $scope.SPLAgentFirstName = CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.firstName !== undefined ? CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.firstName.toUpperCase() : "";
                $scope.SPLAgentMiddleName = CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.middleName !== undefined ? CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.middleName.toUpperCase() : "";
                $scope.SPLAgentLastName = CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.lastName !== undefined ? CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.lastName.toUpperCase() : "";
                $scope.SPLAgentFullName = $scope.SPLAgentFirstName + ' ' + $scope.SPLAgentMiddleName + ' ' + $scope.SPLAgentLastName;
        }
        /* Premier Mediclaim */
        else if ($scope.SPLProductCode === 'HN') {
                $scope.SPLProductName = "New India Premier Mediclaim Policy";
                $scope.SPLAgentEmalid = CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.emailId;
                $scope.SPLAgentMobileNo = CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.mobileNo;
                $scope.SPLAgentFirstName = CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.firstName !== undefined ? CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.firstName.toUpperCase() : "";
                $scope.SPLAgentMiddleName = CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.middleName !== undefined ? CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.middleName.toUpperCase() : "";
                $scope.SPLAgentLastName = CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.lastName !== undefined ? CommonServices.topUpObj.getPolicyholderDetails.partyDetails.individualDetails.lastName.toUpperCase() : "";
                $scope.SPLAgentFullName = $scope.SPLAgentFirstName + ' ' + $scope.SPLAgentMiddleName + ' ' + $scope.SPLAgentLastName;
        }
        /* Floter */
        else if ($scope.SPLProductCode === 'NP') {
                $scope.SPLProductName = "New India Floater Mediclaim";
                $scope.SPLAgentEmalid = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.emailId;
                $scope.SPLAgentMobileNo = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.mobileNo;
                $scope.SPLAgentFirstName = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.firstName !== undefined ? CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.firstName.toUpperCase() : "";
                $scope.SPLAgentMiddleName = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.middleName !== undefined ? CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.middleName.toUpperCase() : "";
                $scope.SPLAgentLastName = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.lastName !== undefined ? CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.lastName.toUpperCase() : "";
                $scope.SPLAgentFullName = $scope.SPLAgentFirstName + ' ' + $scope.SPLAgentMiddleName + ' ' + $scope.SPLAgentLastName;
        }
		/* Stand Alone OD For Motor TW */ /* Start CR_3621 */
		else if ($scope.SPLProductCode === 'SQ') {
                $scope.SPLProductName = "Stand Alone OD For Motor TW";
                $scope.AgentInsuredDetails = $scope.buyNow.twoWheeler.insuredDetails;
                if ($scope.AgentInsuredDetails.individualDetails !== undefined) {
                        $scope.SPLAgentEmalid = $scope.AgentInsuredDetails.individualDetails.emailId;
                        $scope.SPLAgentMobileNo = $scope.AgentInsuredDetails.individualDetails.mobileNo;
                        $scope.SPLAgentFirstName = $scope.AgentInsuredDetails.individualDetails.firstName !== undefined ? $scope.AgentInsuredDetails.individualDetails.firstName.toUpperCase() : "";
                        $scope.SPLAgentMiddleName = $scope.AgentInsuredDetails.individualDetails.middleName !== undefined ? $scope.AgentInsuredDetails.individualDetails.middleName.toUpperCase() : "";
                        $scope.SPLAgentLastName = $scope.AgentInsuredDetails.individualDetails.lastName !== undefined ? $scope.AgentInsuredDetails.individualDetails.lastName.toUpperCase() : "";
                        $scope.SPLAgentFullName = $scope.SPLAgentFirstName + ' ' + $scope.SPLAgentMiddleName + ' ' + $scope.SPLAgentLastName;
                } else if ($scope.AgentInsuredDetails.organizationDetails !== undefined) {
                        $scope.SPLAgentEmalid = $scope.AgentInsuredDetails.organizationDetails.emailId;
                        $scope.SPLAgentMobileNo = $scope.AgentInsuredDetails.organizationDetails.mobileNo;
                        $scope.SPLAgentFirstName = $scope.AgentInsuredDetails.organizationDetails.firstName !== undefined ? $scope.AgentInsuredDetails.organizationDetails.firstName.toUpperCase() : "";
                        $scope.SPLAgentMiddleName = $scope.AgentInsuredDetails.organizationDetails.middleName !== undefined ? $scope.AgentInsuredDetails.organizationDetails.middleName.toUpperCase() : "";
                        $scope.SPLAgentLastName = $scope.AgentInsuredDetails.organizationDetails.lastName !== undefined ? $scope.AgentInsuredDetails.organizationDetails.lastName.toUpperCase() : "";
                        $scope.SPLAgentFullName = $scope.SPLAgentFirstName + ' ' + $scope.SPLAgentMiddleName + ' ' + $scope.SPLAgentLastName;
                }
		} /* End CR_3621 */
		/* Top Up */
        else if ($scope.SPLProductCode === 'CJ') {
			$scope.SPLProductName = "New India Cancer Guard Policy";
			$scope.SPLAgentEmalid = CommonServices.floaterObj.getPolicyholderDetails.partyDetails.individualDetails.emailId;
			$scope.SPLAgentMobileNo = CommonServices.floaterObj.getPolicyholderDetails.partyDetails.individualDetails.mobileNo;
			$scope.SPLAgentFirstName = CommonServices.floaterObj.getPolicyholderDetails.partyDetails.individualDetails.firstName !== undefined ? CommonServices.floaterObj.getPolicyholderDetails.partyDetails.individualDetails.firstName.toUpperCase() : "";
			$scope.SPLAgentMiddleName = CommonServices.floaterObj.getPolicyholderDetails.partyDetails.individualDetails.middleName !== undefined ? CommonServices.floaterObj.getPolicyholderDetails.partyDetails.individualDetails.middleName.toUpperCase() : "";
			$scope.SPLAgentLastName = CommonServices.floaterObj.getPolicyholderDetails.partyDetails.individualDetails.lastName !== undefined ? CommonServices.floaterObj.getPolicyholderDetails.partyDetails.individualDetails.lastName.toUpperCase() : "";
			$scope.SPLAgentFullName = $scope.SPLAgentFirstName + ' ' + $scope.SPLAgentMiddleName + ' ' + $scope.SPLAgentLastName;
	}
  }	
		
  $scope.FetchPaymentLinkDeatils = function() {
        var SendPaymentLinkDataDeatils = {
                "productCode": $scope.SPLProductCode,
                "polHolName": $scope.SPLAgentFullName,
                "quoteNo": $scope.quoteNumber,
                "paymentAmount": $scope.netPreAmt,
                "mobileNo": $scope.SPLAgentMobileNo,
                "emailId": $scope.SPLAgentEmalid,
                "splLink": "",
                "product": $scope.SPLProductName,
                "onloadFlag": "Y",
				'policyHolderCode' : CommonServices.getCommonData("partyCode")
        }
        var SendPaymentLinkDataCountResponse = RestServices.postService(RestServices.urlPathsNewPortal.sendPaymentLinkCount, SendPaymentLinkDataDeatils);
        SendPaymentLinkDataCountResponse.then(function(response) {
                CommonServices.showLoading(false);
                if (response.data !== "") {
                        if (response.data.statusMSg !== 'Successfull') {
                                CommonServices.showAlert(response.data.errorMessage);
                                return;
                        } else {
                                if (response.data.statusMSg == 'Successfull') {
                                        if (response.data.createdDate !== undefined) {
                                                $scope.SPLcreatedDate = response.data.createdDate;
                                        }
                                        if (response.data.linkSend !== undefined) {
                                                $scope.SPLLinkSend = response.data.linkSend;
                                        }
                                        if (response.data.sendCount !== undefined) {
                                                $scope.CountReSendPaymntLink = response.data.sendCount;
                                        }
                                        if ($scope.CountReSendPaymntLink >= 1) {
                                                $scope.buttonText = "Re-Send Payment Link"
                                        }
                                }
                        }
                } else {
                        CommonServices.showAlert("Not able to load data of PaymentLinkCount");
                }
        }, function(error) { // failure 
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
        });
}

 $scope.SendPaymentLink = function() {
        if ($scope.collectionFormData.SendPaymentLinkFormData.length > 0) {
                if ($scope.CountReSendPaymntLink >= 4) {
                        CommonServices.showAlert("You are allowed to re-send the payment link for a maximum of 3 times");
                        return;
                }
                var SendPaymentLinkData = {
                        "productCode": $scope.SPLProductCode,
                        "polHolName": $scope.SPLAgentFullName,
                        "quoteNo": $scope.quoteNumber,
                        "paymentAmount": $scope.netPreAmt,
                        "mobileNo": $scope.SPLAgentMobileNo,
                        "emailId": $scope.SPLAgentEmalid,
                        "splLink": "",
                        "product": $scope.SPLProductName,
                        "onloadFlag": "N",
						'policyHolderCode' : CommonServices.getCommonData("partyCode")
                }
                if ($scope.buttonText == 'Send Payment Link') {
                        var SendPaymentLinkDataResponse = RestServices.postService(RestServices.urlPathsNewPortal.sendPaymentLink, SendPaymentLinkData);
                        SendPaymentLinkDataResponse.then(function(response) {
                                CommonServices.showLoading(false);
                                if (response.data !== "") {
									if(response.data.statusMSgEmail == 'Successfull' && response.data.statusMSgSMS == 'Successfull'){
										CommonServices.showAlert("The payment link has successfully been sent to the policyholder\'s email ID and mobile number. ");
										$scope.buttonText = "Re-Send Payment Link";
										$scope.CountReSendPaymntLink = response.data.sendCount;
									} else if(response.data.statusMSgEmail == 'Successfull'){
										CommonServices.showAlert("The payment link has successfully been sent to the policyholder\'s email ID ");
										$scope.buttonText = "Re-Send Payment Link";
										$scope.CountReSendPaymntLink = response.data.sendCount;
									} else if(response.data.statusMSgSMS == 'Successfull'){
										CommonServices.showAlert("The payment link has successfully been sent to the policyholder\'s mobile number ");
										$scope.buttonText = "Re-Send Payment Link";
										$scope.CountReSendPaymntLink = response.data.sendCount;
									} else{
										CommonServices.showAlert(response.data.errorMessage);
										return;
									}
                                } else {
                                        CommonServices.showAlert("Not able to load send Payment Link data");
                                }
                        }, function(error) { // failure 
                                CommonServices.showLoading(false);
                                RestServices.handleWebServiceError(error);
                        });
                }
                if ($scope.buttonText == 'Re-Send Payment Link') {
					var msg = "The Payment Link has already been sent to the policyholder. Would you like to Re-Send?";
		       		CommonServices.messageModal('info', msg, false, 'No', 'Yes', function () {}, function () { ReSendPaymentLink(1);}, 'Confirm');	
					
					
					// if (CommonServices.deviceType !== "NA") {
                    //             navigator.notification.confirm("The Payment Link has already been sent to the policyholder. Would you like to Re-Send?", ReSendPaymentLink, "Confirm",
                    //                     ["YES", "NO"]);
                    //     } else {
                    //             var ReSendPaymentLinkConfirm;
                    //             ReSendPaymentLinkConfirm = confirm("The Payment Link has already been sent to the policyholder. Would you like to Re-Send?");
                    //             if (ReSendPaymentLinkConfirm) {
                    //                     ReSendPaymentLink(1);
                    //             }
                    //     }
                }
        }
}

  function ReSendPaymentLink(button) {
        if (button == 1) {
                if ($scope.collectionFormData.SendPaymentLinkFormData.length > 0) {
                        if ($scope.CountReSendPaymntLink >= 4) {
                                CommonServices.showAlert("You are allowed to re-send the payment link for a maximum of 3 times");
                                return;
                        }
                        var ReSendPaymentLinkData = {
                                "productCode": $scope.SPLProductCode,
                                "polHolName": $scope.SPLAgentFullName,
                                "quoteNo": $scope.quoteNumber,
                                "paymentAmount": $scope.netPreAmt,
                                "mobileNo": $scope.SPLAgentMobileNo,
                                "emailId": $scope.SPLAgentEmalid,
                                "splLink": "",
                                "product": $scope.SPLProductName,
                                "onloadFlag": "N",
								'policyHolderCode' : CommonServices.getCommonData("partyCode")
                        }
                        var SendPaymentLinkDataResponse = RestServices.postService(RestServices.urlPathsNewPortal.sendPaymentLink, ReSendPaymentLinkData);
                        SendPaymentLinkDataResponse.then(function(response) {
                                CommonServices.showLoading(false);
                                if (response.data !== "") {
                                   if(response.data.statusMSgEmail == 'Successfull' && response.data.statusMSgSMS == 'Successfull'){
										CommonServices.showAlert("The payment link has successfully been sent to the policyholder\'s email ID and mobile number. ");
										$scope.buttonText = "Re-Send Payment Link";
										$scope.CountReSendPaymntLink = response.data.sendCount;
									} else if(response.data.statusMSgEmail == 'Successfull'){
										CommonServices.showAlert("The payment link has successfully been sent to the policyholder\'s email ID ");
										$scope.buttonText = "Re-Send Payment Link";
										$scope.CountReSendPaymntLink = response.data.sendCount;
									} else if(response.data.statusMSgSMS == 'Successfull'){
										CommonServices.showAlert("The payment link has successfully been sent to the policyholder\'s mobile number ");
										$scope.buttonText = "Re-Send Payment Link";
										$scope.CountReSendPaymntLink = response.data.sendCount;
									} else {
										CommonServices.showAlert(response.data.errorMessage);
										return;
									}
                                } else {
                                        CommonServices.showAlert("Not able to load Re-Send Payment Link data");
                                }
                        }, function(error) { // failure 
                                CommonServices.showLoading(false);
                                RestServices.handleWebServiceError(error);
                        });
                }
        }
}
		  				
	/* CR_NP_779 End */	

}]);
