agentApp.controller('raastaAapattiKavachPremiumCalcCtrl', ['$scope', '$rootScope', 'RestServices', 'CommonServices', '$state', 'GetSetResponseService', '$modal', function ($scope, $rootScope, RestServices, CommonServices, $state, GetSetResponseService, $modal) {

	CommonServices.floaterObj.goToNomineeInfoEdit ="premiumCalculate";
	CommonServices.floaterObj.goToMemeberInfoEdit ="premiumCalculate";
	CommonServices.floaterObj.serviceCall="";
	CommonServices.floaterObj.ageSonYrs = [];
	CommonServices.floaterObj.ageDaughterYrs = [];
	$rootScope.policyDetailsObj = {};
	$scope.sumInsuredPanel = true;
	$scope.thirdPartyPanel = false;
	$scope.policyPanel = false;
	$scope.termsAndCondition = function(){
		$rootScope.termsCondOpen= true;
	}
	/** Calender Icon click **/
	$scope.calIconClick= function(event) {
			angular.element("#"+ event.currentTarget.children[0].id).focus(); 
	}; 
	
	var mydateStr = new Date(CommonServices.getCommonData("serverDate"));
	var mynewdateFrom = "";
	if(mydateStr != undefined){
		mynewdateFrom = new Date(mydateStr);
	} else {
		mynewdateFrom = new Date();
	}

	/** Set Proposer, Spouse min DOB**/
	var enableProposerDOBCalMin = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 18));
    enableProposerDOBCalMin = new Date(enableProposerDOBCalMin.setDate(enableProposerDOBCalMin.getDate()));
	enableProposerDOBCalMin = getFormattedDate(enableProposerDOBCalMin);
	var TodyasDateFormatToCal = CommonServices.getCommonData("serverDate");
	
	/** Set Calender range for proposer, spouse, child max date **/
	var enableProposerDOBCalfrom = getFormattedDate(mynewdateFrom);
	var enableProposerDOBCalTo = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 81));

	//5 years
	var enableChildDOBCalMin = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 5));
	enableChildDOBCalMin = new Date(enableChildDOBCalMin.setDate(enableChildDOBCalMin.getDate()));
	enableChildDOBCalMin = getFormattedDate(enableChildDOBCalMin); 


	/** Policy Start date set to current date**/
	var policyStartDate = angular.copy(mynewdateFrom);
	var policyStartDateEnable = angular.copy(mynewdateFrom);
	policyStartDateEnable = policyStartDateEnable.setDate(policyStartDateEnable.getDate()+10);
	policyStartDateEnable = getFormattedDate(new Date(policyStartDateEnable));
	
	$scope.calPolicyEndDate = function(){
		
		if(($scope.memberInfo.policyDetails.policyDuration && $scope.memberInfo.policyDetails.policyDuration!=="") && ($scope.memberInfo.policyDetails.policyStartDate && $scope.memberInfo.policyDetails.policyStartDate!=="")){
			let dateStr = $scope.memberInfo.policyDetails.policyStartDate.split("/");
			let policyEnd = new Date(+dateStr[2],dateStr[1]-1,+dateStr[0]);
			policyEnd.setFullYear(policyEnd.getFullYear() + (+$scope.memberInfo.policyDetails.policyDuration));
			policyEnd.setDate(policyEnd.getDate() - 1);

			let dd = policyEnd.getDate();
			let mm = policyEnd.getMonth() + 1;
			let yyyy = policyEnd.getFullYear();

			if (dd < 10) {
				dd = "0" + dd;
			}

			if (mm < 10) {
				mm = "0" + mm;
			}
			policyEnd = dd + "/" +mm + "/" + yyyy;//policy end date
			
			$scope.memberInfo.policyDetails.policyEndDate = policyEnd;
		}else{
			$scope.memberInfo.policyDetails.policyEndDate = "";
		}
	}

	/**Policy start date**/
	$('#policyStartDate').loadCalendar({
		'enableDateRange': true,
		'enableCalendarFrom': policyStartDate,
		'enableCalendarTo': policyStartDateEnable
	});

	/**Proposer DOB**/
	$('#proposerDateOfBirth').loadCalendar({
		'enableDateRange': true,
		'enableCalendarFrom': enableProposerDOBCalTo,
		'enableCalendarTo': enableProposerDOBCalfrom
	});

	/**Son DOB**/
	$scope.sonDateOfBirth = function(index){
	  $("#sonDateOfBirth"+index).loadCalendar({
		   'enableDateRange': true,
		   'enableCalendarFrom': enableProposerDOBCalTo,
		   'enableCalendarTo': enableProposerDOBCalfrom
	   });
       return true;
    }; 
	/**Daughter DOB**/
	$scope.daughterDateOfBirth = function(index){    
		$("#daughterDateOfBirth"+index).loadCalendar({
		   'enableDateRange': true,
		   'enableCalendarFrom': enableProposerDOBCalTo,
		   'enableCalendarTo': enableProposerDOBCalfrom
		});
        return true;
    };
	$scope.sumInsuredData=[{
			"name":"25000",
			"value": 25000
		},{
			"name":"50000",
			"value": 50000
		},{
			"name":"75000",
			"value": 75000
		},{
			"name":"100000",
			"value": 100000
		},{
			"name":"200000",
			"value": 200000
		},{
			"name":"300000",
			"value": 300000
		},{
			"name":"400000",
			"value": 400000
		},{
			"name":"500000",
			"value": 500000
		},{
			"name":"600000",
			"value": 600000
		},{
			"name":"700000",
			"value": 700000
		},{
			"name":"800000",
			"value": 800000
		},{
			"name":"900000",
			"value": 900000
		},{
			"name":"1000000",
			"value": 1000000
		}

	];

	$scope.goBack = function () {
		if(CommonServices.editQuoteFlag === true){//CR_0054
			$state.go("managePolicies.managePolicies");
		}else
			$state.go('buyNowSubLandingScreen');
	}
	
	$scope.thirdPartyReqChange = function(){

		if($scope.memberInfo.thirdPartyDetails.noOfPersonsThirdParty || $scope.memberInfo.thirdPartyDetails.sumInsuredThirdParty){
			$scope.memberInfo.thirdPartyReq = true;
		}else{
			$scope.memberInfo.thirdPartyReq = false;
		}
		$scope.memberInfo.selectedSumInsured();
	}
		
		
	$scope.memberInfo = {
		showProposer: true,
		showSpouse: false,
		addDaughterDisable: false,
		addSonDisable: false,
		daughterReq: false,
		sonReq: false,
		disableCountBtn: 1,
		selfDetails: {
			name:"",
			occupation:"",
			dateOfBirth : "",
			sumInsuredRoadAccident: "",
			sumInsuredHospExpenses: "",
			sumInsuredHospEmpExt: "",
			hospExpensesOtherAcdnt: ""
		},
		spouseDetails: {
			name:"",
			occupation:"",
			dateOfBirth : "",
			sumInsuredRoadAccident: "",
			sumInsuredHospExpenses: "",
			sumInsuredHospEmpExt: "",
			hospExpensesOtherAcdnt: ""
		},
		thirdPartyDetails: {
			noOfPersonsThirdParty: "",
			sumInsuredThirdParty: "",
		},
		policyDetails: {
			policyStartDate: getCurrentDate(),
			policyDuration: "",
			policyEndDate: ""

		},
		coveredDaughterDetails: [],
		coveredSonDetails: [],
		riskPremiumDetails : [],
		disableAddSonBtn: 0,
		disableAddDaughterBtn: 0,
		thirdPartyReq: false,
		minAmtAlert: false,
		addMember: function(member) {
			this.disableCountBtn = this.disableCountBtn + 1;
			if(member === "SPOUSE") {
				$scope.memberInfo.spouseIsAdded = true;
				if($scope.memberInfo.spouseDetails.sumInsuredRoadAccident==""){
					$scope.memberInfo.spouseDetails.sumInsuredRoadAccident = $scope.memberInfo.selfDetails.sumInsuredRoadAccident;
					$scope.memberInfo.spouseDetails.sumInsuredHospExpenses = $scope.memberInfo.selfDetails.sumInsuredRoadAccident;
					$scope.memberInfo.spouseDetails.sumInsuredHospEmpExt = $scope.memberInfo.selfDetails.sumInsuredRoadAccident;
					$scope.memberInfo.spouseDetails.hospExpensesOtherAcdnt = $scope.memberInfo.selfDetails.sumInsuredRoadAccident;
				}
				this.showSpouse=true;
				setTimeout(function(){
					$('#spouseDateOfBirth').loadCalendar({
						'enableDateRange': true,
						'enableCalendarFrom': enableProposerDOBCalTo,
						'enableCalendarTo': enableProposerDOBCalfrom
					});
				}, 100);
			} else if(member === "SON") {
				$scope.memberInfo.sonReq = true;
				if($scope.memberInfo.coveredSonDetails.length <= 1){
					this.addSonFunc();					
					this.disableAddSonBtn = this.disableAddSonBtn + 1;
					if(this.disableAddSonBtn===2) $scope.memberInfo.addSonDisable=true;
				} else {
					return false;
				}							
			} else if(member === "PROPOSER") {
				$scope.memberInfo.addProposerDisable = true;
				$scope.memberInfo.showProposer = true;				
			} else if(member === "DAUGHTER") {
				$scope.memberInfo.daughterReq = true;
				if($scope.memberInfo.coveredDaughterDetails.length <= 1){									
					this.addDaughterFunc();
					this.disableAddDaughterBtn = this.disableAddDaughterBtn + 1;
					if(this.disableAddDaughterBtn===2) $scope.memberInfo.addDaughterDisable=true;
				} else {
					return false;
				}				
			}
		},
		addSonFunc: function(){
			$scope.memberInfo.coveredSonDetails
			.push({
				name:'',
				occupation:'',
				dateOfBirth:'',
				sumInsuredRoadAccident: $scope.memberInfo.selfDetails.sumInsuredRoadAccident,
				sumInsuredHospExpenses: $scope.memberInfo.selfDetails.sumInsuredRoadAccident,
				sumInsuredHospEmpExt: "",
				hospExpensesOtherAcdnt: $scope.memberInfo.selfDetails.sumInsuredRoadAccident
			});				
		},
		addDaughterFunc: function(){
			$scope.memberInfo.coveredDaughterDetails
				.push({
				name:'',
				occupation:'',
				dateOfBirth:'',
				sumInsuredRoadAccident: $scope.memberInfo.selfDetails.sumInsuredRoadAccident,
				sumInsuredHospExpenses: $scope.memberInfo.selfDetails.sumInsuredRoadAccident,
				sumInsuredHospEmpExt: "",
				hospExpensesOtherAcdnt: $scope.memberInfo.selfDetails.sumInsuredRoadAccident
				});
		},
		closeMember :function(member,index) {
			this.disableCountBtn = this.disableCountBtn - 1;
			if(member === 'SPOUSE'){
				$scope.memberInfo.showSpouse = false;
				$scope.memberInfo.spouseDetails = {
					name:"",
					occupation:"",
					dateOfBirth : "",
					sumInsuredRoadAccident: "",
					sumInsuredHospExpenses: "",
					sumInsuredHospEmpExt: "",
					hospExpensesOtherAcdnt: ""
				};
			} else if(member === 'SON'){
				this.disableAddSonBtn = this.disableAddSonBtn - 1;
				this.coveredSonDetails.splice(this.coveredSonDetails.indexOf(index), 1);
				if(this.disableAddSonBtn < 2){
					$scope.memberInfo.addSonDisable=false;
				} 
				if(this.disableAddSonBtn === 0){
					$scope.memberInfo.sonReq = false;
				}
			}  else if(member === 'DAUGHTER'){
				this.disableAddDaughterBtn = this.disableAddDaughterBtn - 1;
				$scope.memberInfo.addDaughterDisable = false;
				this.coveredDaughterDetails.splice(this.coveredDaughterDetails.indexOf(index), 1);
				if(this.disableAddDaughterBtn < 2){
					$scope.memberInfo.addDaughterDisable=false;
				}
				if(this.disableAddDaughterBtn === 0){
					$scope.memberInfo.daughterReq = false;
				}
			}
		},
		dateOfBirthFunc: function(member,index){
			enableProposerDOBCalComp = new Date(enableProposerDOBCalMin);
			enableChildDOBCalComp = new Date(enableChildDOBCalMin);
			if(member === "PROPOSER"){
				var dt1 = this.selfDetails.dateOfBirth.split('/'),
				proposerbirthDateComp = dt1[1] + '/' + dt1[0] + '/' + dt1[2], //mm/dd/yyyy
				proposerbirthDateComp = new Date(proposerbirthDateComp);
				if(proposerbirthDateComp > enableProposerDOBCalComp){				
					$scope.memberInfo.selfDetails.dateOfBirth = "";
					CommonServices.showAlert("Age of the Proposer should be between 18 years to 80 Years"); 				
					return false;	
				} else {					
					if($scope.memberInfo.coveredSonDetails.length > 0 || $scope.memberInfo.coveredDaughterDetails.length > 0){
						var childDobCheck = false;
						for(var i=0; i< $scope.memberInfo.coveredSonDetails.length; i++){
							if($scope.memberInfo.coveredSonDetails[i].dateOfBirth!==undefined && this.childParentsAgeCheck($scope.memberInfo.coveredSonDetails[i].dateOfBirth, this.selfDetails.dateOfBirth)){
								$scope.memberInfo.coveredSonDetails[i].dateOfBirth = "";
								childDobCheck = true;
							}
						}

						for(var i=0; i< $scope.memberInfo.coveredDaughterDetails.length; i++){
							if($scope.memberInfo.coveredDaughterDetails[i].dateOfBirth!==undefined && this.childParentsAgeCheck($scope.memberInfo.coveredDaughterDetails[i].dateOfBirth, this.selfDetails.dateOfBirth)){
								$scope.memberInfo.coveredDaughterDetails[i].dateOfBirth = "";
								childDobCheck = true;
							}
						}
						if(childDobCheck){
							CommonServices.showAlert("Children Age cannot be more than that of Parents");
						}
					} 
					var date = new Date(proposerbirthDateComp);
					var ageDifMs = Date.now() - date.getTime();
					var ageProposerYrs = new Date(ageDifMs); // miliseconds from epoch
					ageProposerYrs = Math.abs(ageProposerYrs.getUTCFullYear() - 1970);
					ageProposerYrs =ageProposerYrs.toString();
					CommonServices.floaterObj.ageProposerYrs=ageProposerYrs;	
					
				}
			} else if(member === "SPOUSE"){
				var dt1 = this.spouseDetails.dateOfBirth.split('/'),
				spouseDateOfBirthComp = dt1[1] + '/' + dt1[0] + '/' + dt1[2], //mm/dd/yyyy
				spouseDateOfBirthComp = new Date(spouseDateOfBirthComp);
				if(spouseDateOfBirthComp > enableProposerDOBCalComp){
					$scope.memberInfo.spouseDetails.dateOfBirth = "";
					CommonServices.showAlert("Age of the Spouse should be between 18 years to 80 Years");
					return false;
				} else{
					if($scope.memberInfo.coveredSonDetails.length > 0 || $scope.memberInfo.coveredDaughterDetails.length > 0){
						var childDobCheck = false;
						for(var i=0; i< $scope.memberInfo.coveredSonDetails.length; i++){
							if($scope.memberInfo.coveredSonDetails[i].dateOfBirth!==undefined && this.childParentsAgeCheck($scope.memberInfo.coveredSonDetails[i].dateOfBirth, this.spouseDetails.dateOfBirth)){
								$scope.memberInfo.coveredSonDetails[i].dateOfBirth = "";
								childDobCheck = true;
							}
						}

						for(var i=0; i< $scope.memberInfo.coveredDaughterDetails.length; i++){
							if($scope.memberInfo.coveredDaughterDetails[i].dateOfBirth!==undefined && this.childParentsAgeCheck($scope.memberInfo.coveredDaughterDetails[i].dateOfBirth, this.spouseDetails.dateOfBirth)){
								$scope.memberInfo.coveredDaughterDetails[i].dateOfBirth = "";
								childDobCheck = true;
							}
						}
						if(childDobCheck){
							CommonServices.showAlert("Children Age cannot be more than that of Parents");
						}
					} 
					var date = new Date(spouseDateOfBirthComp);
					var ageDifMs = Date.now() - date.getTime();
					var ageSpouseYrs = new Date(ageDifMs); // miliseconds from epoch
					ageSpouseYrs = Math.abs(ageSpouseYrs.getUTCFullYear() - 1970);
					ageSpouseYrs =ageSpouseYrs.toString();
					CommonServices.floaterObj.ageSpouseYrs=ageSpouseYrs;					
					
				}				
			} else if(member === "SON"){
				for(var i =0; i< $scope.memberInfo.coveredSonDetails.length; i++){   
					if(index == i){
						dt1 = $scope.memberInfo.coveredSonDetails[i].dateOfBirth.split('/'),
						sonDateOfBirthComp = dt1[1] + '/' + dt1[0] + '/' + dt1[2], //mm/dd/yyyy
						sonDateOfBirthComp = new Date(sonDateOfBirthComp);
						if(sonDateOfBirthComp > enableChildDOBCalComp){
							$scope.memberInfo.coveredSonDetails[i].dateOfBirth = "";
							CommonServices.showAlert("Age of the child should be between 5 years to 80 Years");
							return false;
						}else{
							var childDobCheck = false;
							
							if($scope.memberInfo.coveredSonDetails[i].dateOfBirth!==undefined && (this.childParentsAgeCheck($scope.memberInfo.coveredSonDetails[i].dateOfBirth, this.selfDetails.dateOfBirth) || this.childParentsAgeCheck($scope.memberInfo.coveredSonDetails[i].dateOfBirth, this.spouseDetails.dateOfBirth))){
								$scope.memberInfo.coveredSonDetails[i].dateOfBirth = "";
								childDobCheck = true;
							}
							

							if(childDobCheck){
								CommonServices.showAlert("Children Age cannot be more than that of Parents");
								return false;
							}
							var date = new Date(sonDateOfBirthComp);
							var ageDifMs = Date.now() - date.getTime();
							var ageSonYrs = new Date(ageDifMs); // miliseconds from epoch
							ageSonYrs = Math.abs(ageSonYrs.getUTCFullYear() - 1970);
							ageSonYrs =ageSonYrs.toString();
							CommonServices.floaterObj.ageSonYrs.push(ageSonYrs);
						}
					}				
				}				
			}else if(member === "DAUGHTER"){
				for(var i =0; i< $scope.memberInfo.coveredDaughterDetails.length; i++){   
					if(index == i){
						dt1 = $scope.memberInfo.coveredDaughterDetails[i].dateOfBirth.split('/'),
						daughterDateOfBirthComp = dt1[1] + '/' + dt1[0] + '/' + dt1[2], //mm/dd/yyyy
						daughterDateOfBirthComp = new Date(daughterDateOfBirthComp);
						if(daughterDateOfBirthComp > enableChildDOBCalComp){
							$scope.memberInfo.coveredDaughterDetails[i].dateOfBirth = "";
							CommonServices.showAlert("Age of the Child should be between 5 years to 80 Years");
							return false;
						}else{
							var childDobCheck = false;
							
							if($scope.memberInfo.coveredDaughterDetails[i].dateOfBirth!==undefined && (this.childParentsAgeCheck($scope.memberInfo.coveredDaughterDetails[i].dateOfBirth, this.selfDetails.dateOfBirth) || this.childParentsAgeCheck($scope.memberInfo.coveredDaughterDetails[i].dateOfBirth, this.spouseDetails.dateOfBirth))){
								$scope.memberInfo.coveredDaughterDetails[i].dateOfBirth = "";
								childDobCheck = true;
							}
							

							if(childDobCheck){
								CommonServices.showAlert("Children Age cannot be more than that of Parents");
								return false;
							}
							var date = new Date(daughterDateOfBirthComp);
							var ageDifMs = Date.now() - date.getTime();
							var ageDaughterYrs = new Date(ageDifMs); // miliseconds from epoch
							ageDaughterYrs = Math.abs(ageDaughterYrs.getUTCFullYear() - 1970);
							ageDaughterYrs =ageDaughterYrs.toString();
							CommonServices.floaterObj.ageDaughterYrs.push(ageDaughterYrs);
						}
					}				
				}	

			}
			return true;
							
		},
		selectedSumInsured:function(member, field){
			var minAmtAlert = false;

			//$scope.memberInfo.sumInsuredEmpty=false;			
			if($scope.memberInfo.selfDetails.sumInsuredRoadAccident === "" || $scope.memberInfo.selfDetails.sumInsuredRoadAccident === undefined){
			} else {
				//Proposer's selected SumInsured values validity check
				if($scope.memberInfo.selfDetails.sumInsuredHospExpenses !== undefined){
					if($scope.memberInfo.selfDetails.sumInsuredHospExpenses !== ""){
						if(eval($scope.memberInfo.selfDetails.sumInsuredHospExpenses + ">" + $scope.memberInfo.selfDetails.sumInsuredRoadAccident)){
							minAmtAlert = true;
						}
					}else{
						$scope.memberInfo.selfDetails.sumInsuredHospExpenses = $scope.memberInfo.selfDetails.sumInsuredRoadAccident;
					}
				}
				if($scope.memberInfo.selfDetails.sumInsuredHospEmpExt !== undefined){
					if($scope.memberInfo.selfDetails.sumInsuredHospEmpExt !== ""){
						if(eval($scope.memberInfo.selfDetails.sumInsuredHospEmpExt + ">" + $scope.memberInfo.selfDetails.sumInsuredRoadAccident)){
							minAmtAlert = true;
						}
					}else if($scope.memberInfo.selfDetails.sumInsuredHospEmpExt == "" && member==1 && field=='sumInsuredRoadAccident'){
						$scope.memberInfo.selfDetails.sumInsuredHospEmpExt = $scope.memberInfo.selfDetails.sumInsuredRoadAccident;
					}
				}
				if($scope.memberInfo.selfDetails.hospExpensesOtherAcdnt !== undefined){
					if($scope.memberInfo.selfDetails.hospExpensesOtherAcdnt !== ""){
						if(eval($scope.memberInfo.selfDetails.hospExpensesOtherAcdnt + ">" + $scope.memberInfo.selfDetails.sumInsuredRoadAccident)){
							minAmtAlert = true;
						}
					}else if($scope.memberInfo.selfDetails.hospExpensesOtherAcdnt == "" && member==1 && field=='sumInsuredRoadAccident'){
						$scope.memberInfo.selfDetails.hospExpensesOtherAcdnt = $scope.memberInfo.selfDetails.sumInsuredRoadAccident;
					}
				}

				//Spouse's selected SumInsured values validity check
				if($scope.memberInfo.spouseDetails.sumInsuredRoadAccident !== undefined){ 
					if($scope.memberInfo.spouseDetails.sumInsuredRoadAccident !== ""){
						if(eval($scope.memberInfo.spouseDetails.sumInsuredRoadAccident + ">" + $scope.memberInfo.selfDetails.sumInsuredRoadAccident)){
							minAmtAlert = true;
						}
						if($scope.memberInfo.spouseDetails.sumInsuredHospExpenses !== undefined){
							if($scope.memberInfo.spouseDetails.sumInsuredHospExpenses !== ""){
								if(eval($scope.memberInfo.spouseDetails.sumInsuredHospExpenses + ">" + $scope.memberInfo.spouseDetails.sumInsuredRoadAccident)){
									minAmtAlert = true;
								}
							}
						}
						if($scope.memberInfo.spouseDetails.sumInsuredHospEmpExt !== undefined){
							if($scope.memberInfo.spouseDetails.sumInsuredHospEmpExt !== ""){
								if(eval($scope.memberInfo.spouseDetails.sumInsuredHospEmpExt + ">" + $scope.memberInfo.spouseDetails.sumInsuredRoadAccident)){
									minAmtAlert = true;
								}
							}
						}
						if($scope.memberInfo.spouseDetails.hospExpensesOtherAcdnt !== undefined){
							if($scope.memberInfo.spouseDetails.hospExpensesOtherAcdnt !== ""){
								if(eval($scope.memberInfo.spouseDetails.hospExpensesOtherAcdnt + ">" + $scope.memberInfo.spouseDetails.sumInsuredRoadAccident)){
									minAmtAlert = true;
								}
							}
						}
					}	
				}
				//Son's selected SumInsured values validity check
				for(var i=0; i< $scope.memberInfo.coveredSonDetails.length; i++){
					if($scope.memberInfo.coveredSonDetails[i].sumInsuredRoadAccident !== undefined){ 
						if($scope.memberInfo.coveredSonDetails[i].sumInsuredRoadAccident !== ""){
							if(eval($scope.memberInfo.coveredSonDetails[i].sumInsuredRoadAccident + ">" + $scope.memberInfo.selfDetails.sumInsuredRoadAccident)){
								minAmtAlert = true;
							}
							if($scope.memberInfo.coveredSonDetails[i].sumInsuredHospExpenses !== undefined){
								if($scope.memberInfo.coveredSonDetails[i].sumInsuredHospExpenses !== ""){
									if(eval($scope.memberInfo.coveredSonDetails[i].sumInsuredHospExpenses + ">" + $scope.memberInfo.coveredSonDetails[i].sumInsuredRoadAccident)){
										minAmtAlert = true;
									}
								}
							}
							if($scope.memberInfo.coveredSonDetails[i].sumInsuredHospEmpExt !== undefined){
								if($scope.memberInfo.coveredSonDetails[i].sumInsuredHospEmpExt !== ""){
									if(eval($scope.memberInfo.coveredSonDetails[i].sumInsuredHospEmpExt + ">" + $scope.memberInfo.coveredSonDetails[i].sumInsuredRoadAccident)){
										minAmtAlert = true;
									}
								}
							}
							if($scope.memberInfo.coveredSonDetails[i].hospExpensesOtherAcdnt !== undefined){
								if($scope.memberInfo.coveredSonDetails[i].hospExpensesOtherAcdnt !== ""){
									if(eval($scope.memberInfo.coveredSonDetails[i].hospExpensesOtherAcdnt + ">" + $scope.memberInfo.coveredSonDetails[i].sumInsuredRoadAccident)){
										minAmtAlert = true;
									}
								}
							}
						}	
					}
				}
				//Daughter's selected SumInsured values validity check
				for(var i=0; i< $scope.memberInfo.coveredDaughterDetails.length; i++){
					if($scope.memberInfo.coveredDaughterDetails[i].sumInsuredRoadAccident !== undefined){ 
						if($scope.memberInfo.coveredDaughterDetails[i].sumInsuredRoadAccident !== ""){
							if(eval($scope.memberInfo.coveredDaughterDetails[i].sumInsuredRoadAccident + ">" + $scope.memberInfo.selfDetails.sumInsuredRoadAccident)){
								minAmtAlert = true;
							}
							if($scope.memberInfo.coveredDaughterDetails[i].sumInsuredHospExpenses !== undefined){
								if($scope.memberInfo.coveredDaughterDetails[i].sumInsuredHospExpenses !== ""){
									if(eval($scope.memberInfo.coveredDaughterDetails[i].sumInsuredHospExpenses + ">" + $scope.memberInfo.coveredDaughterDetails[i].sumInsuredRoadAccident)){
										minAmtAlert = true;
									}
								}
							}
							if($scope.memberInfo.coveredDaughterDetails[i].sumInsuredHospEmpExt !== undefined){
								if($scope.memberInfo.coveredDaughterDetails[i].sumInsuredHospEmpExt !== ""){
									if(eval($scope.memberInfo.coveredDaughterDetails[i].sumInsuredHospEmpExt + ">" + $scope.memberInfo.coveredDaughterDetails[i].sumInsuredRoadAccident)){
										minAmtAlert = true;
									}
								}
							}
							if($scope.memberInfo.coveredDaughterDetails[i].hospExpensesOtherAcdnt !== undefined){
								if($scope.memberInfo.coveredDaughterDetails[i].hospExpensesOtherAcdnt !== ""){
									if(eval($scope.memberInfo.coveredDaughterDetails[i].hospExpensesOtherAcdnt + ">" + $scope.memberInfo.coveredDaughterDetails[i].sumInsuredRoadAccident)){
										minAmtAlert = true;
									}
								}
							}
						}	
					}
				}
				//Third Party's selected SumInsured values validity check
				if($scope.memberInfo.thirdPartyDetails.sumInsuredThirdParty !== undefined){ 
					if($scope.memberInfo.thirdPartyDetails.sumInsuredThirdParty !== ""){
						if(eval($scope.memberInfo.thirdPartyDetails.sumInsuredThirdParty + ">" + $scope.memberInfo.selfDetails.sumInsuredRoadAccident))
							minAmtAlert = true;
					}	
				}
				
			}
			this.minAmtAlert = minAmtAlert;
			
				
		},
		childParentsAgeCheck:function(childAge, parentAge){
			var arr = childAge.split('/'); 
			childAge = arr[1] + '/' + arr[0] + '/' + arr[2]; //mm/dd/yyyy 
			childAge = new Date(childAge); 
			var dt1 = parentAge.split('/'),
			parentAge = dt1[1] + '/' + dt1[0] + '/' + dt1[2], //mm/dd/yyyy
			parentAge = new Date(parentAge);
			if(childAge < parentAge){								
				return true;				
			} else {
				return false;				
			}			
		},
		calcPremium: function(){
			
			this.riskPremiumDetails =[];
			let additionalMemberArr = [];
			var totalSumInsured = 0;
			if (CommonServices.editQuoteFlag !== true) {
				CommonServices.floaterObj.addedMemberDetails = [];
			}
			if($scope.memberInfo.showProposer === false && $scope.memberInfo.showSpouse === false && 
			$scope.memberInfo.disableAddSonBtn === 0 && $scope.memberInfo.disableAddDaughterBtn === 0){
				CommonServices.showAlert("Atleast one member is required to take the policy");
			} else {
				
				if($scope.memberInfo.showProposer === true){
					$scope.proposerRiskDetails={

						"riskdetails":{					
							"relationPolicyHolder":"SELF",
							"dateOfBirth":$scope.memberInfo.selfDetails.dateOfBirth,
							"ageOfMember":CommonServices.floaterObj.ageProposerYrs,
							"anyPhysicalDefects":"N"
						},
						"cover":[{
							"sumInsuredRoadAccident":$scope.memberInfo.selfDetails.sumInsuredRoadAccident,
							"sumInsuredHospExpenses":$scope.memberInfo.selfDetails.sumInsuredHospExpenses,
							"sumInsuredHospEmpExt": $scope.memberInfo.selfDetails.sumInsuredHospEmpExt,
							"sumInsuredExtForAccdnt": $scope.memberInfo.selfDetails.sumInsuredHospEmpExt>0 ? "YES":"NO",
							"hospExpensesOtherAcdnt": $scope.memberInfo.selfDetails.hospExpensesOtherAcdnt,
							"hospExpensesOtherAcdntRqrd": $scope.memberInfo.selfDetails.hospExpensesOtherAcdnt>0 ? "Yes":"No",
							"totalAccdntSumInsured":(parseInt($scope.memberInfo.selfDetails.sumInsuredRoadAccident) + parseInt($scope.memberInfo.selfDetails.sumInsuredHospExpenses))
						}]
					};
					
					totalSumInsured = totalSumInsured + parseInt($scope.memberInfo.selfDetails.sumInsuredRoadAccident) + parseInt($scope.memberInfo.selfDetails.sumInsuredHospExpenses);

					this.riskPremiumDetails.push(JSON.parse(JSON.stringify($scope.proposerRiskDetails)));
					if($scope.memberInfo.selfDetails.edit)
					Object.assign($scope.proposerRiskDetails.riskdetails,{
						edit: true,
						nameOfInsured: $scope.memberInfo.selfDetails.nameOfInsured,
						relationshipWith: $scope.memberInfo.selfDetails.relationshipWith,
						riskEmployed: $scope.memberInfo.selfDetails.riskEmployed,
						occupationOfMember: $scope.memberInfo.selfDetails.occupationOfMember,
						anyOther: $scope.memberInfo.selfDetails.anyOther,
						nomineeName: $scope.memberInfo.selfDetails.nomineeName,
						relationWithNominee: $scope.memberInfo.selfDetails.relationWithNominee,
						anyPhysicalDefects: $scope.memberInfo.selfDetails.anyPhysicalDefects,
						physicalDefect: $scope.memberInfo.selfDetails.physicalDefect,
						insuredPerEmpNo: $scope.memberInfo.selfDetails.insuredPerEmpNo
						
					});
					additionalMemberArr.push($scope.proposerRiskDetails);
				}
			
				if($scope.memberInfo.showSpouse === true){
					$scope.spouseRiskDetails={

						"riskdetails":{
							"relationPolicyHolder":"SPOUSE", 
							"dateOfBirth":$scope.memberInfo.spouseDetails.dateOfBirth,
							"ageOfMember":CommonServices.floaterObj.ageSpouseYrs,
							"anyPhysicalDefects":"N"
						},
						"cover":[{
							"sumInsuredRoadAccident":$scope.memberInfo.spouseDetails.sumInsuredRoadAccident,
							"sumInsuredHospExpenses":$scope.memberInfo.spouseDetails.sumInsuredHospExpenses,
							"sumInsuredHospEmpExt": $scope.memberInfo.spouseDetails.sumInsuredHospEmpExt,
							"sumInsuredExtForAccdnt": $scope.memberInfo.spouseDetails.sumInsuredHospEmpExt>0? "YES":"NO",
							"hospExpensesOtherAcdnt": $scope.memberInfo.spouseDetails.hospExpensesOtherAcdnt,
							"hospExpensesOtherAcdntRqrd": $scope.memberInfo.spouseDetails.hospExpensesOtherAcdnt>0 ?  "Yes":"No",
							"totalAccdntSumInsured":(parseInt($scope.memberInfo.spouseDetails.sumInsuredRoadAccident) + parseInt($scope.memberInfo.spouseDetails.sumInsuredHospExpenses))
						}]
					};
					totalSumInsured = totalSumInsured + parseInt($scope.memberInfo.spouseDetails.sumInsuredRoadAccident) + parseInt($scope.memberInfo.spouseDetails.sumInsuredHospExpenses);
					
					this.riskPremiumDetails.push(JSON.parse(JSON.stringify($scope.spouseRiskDetails)));
					if($scope.memberInfo.spouseDetails.edit)
					Object.assign($scope.spouseRiskDetails.riskdetails,{
						edit: true,
						nameOfInsured: $scope.memberInfo.spouseDetails.nameOfInsured,
						relationshipWith: $scope.memberInfo.spouseDetails.relationshipWith,
						riskEmployed: $scope.memberInfo.spouseDetails.riskEmployed,
						occupationOfMember: $scope.memberInfo.spouseDetails.occupationOfMember,
						anyOther: $scope.memberInfo.spouseDetails.anyOther,
						nomineeName: $scope.memberInfo.spouseDetails.nomineeName,
						relationWithNominee: $scope.memberInfo.spouseDetails.relationWithNominee,
						anyPhysicalDefects: $scope.memberInfo.spouseDetails.anyPhysicalDefects,
						physicalDefect: $scope.memberInfo.spouseDetails.physicalDefect,
						insuredPerEmpNo: $scope.memberInfo.spouseDetails.insuredPerEmpNo
					});
					additionalMemberArr.push($scope.spouseRiskDetails);
				}
				
				
				if($scope.memberInfo.disableAddSonBtn > 0){
					for(var i =0; i< $scope.memberInfo.coveredSonDetails.length; i++){
						var sonAgeCal = $scope.memberInfo.coveredSonDetails[i].dateOfBirth;
						var Arr = sonAgeCal.split('/');
						sonAgeCal = Arr[2] + '/' + Arr[1] + '/' + Arr[0]; //mm/dd/yyyy
						var date = new Date(sonAgeCal);
						var ageDifMs = Date.now() - date.getTime();
						var ageDinYrs = new Date(ageDifMs); // miliseconds from epoch
						ageDinYrs = Math.abs(ageDinYrs.getUTCFullYear() - 1970);
						ageDinYrs =ageDinYrs.toString();
						$scope.sonRiskDetails = {
							"riskdetails":{
								"relationPolicyHolder":"SON",
								"dateOfBirth":$scope.memberInfo.coveredSonDetails[i].dateOfBirth,
								"ageOfMember":CommonServices.floaterObj.ageSonYrs[i],
								"anyPhysicalDefects":"N"
							},
							"cover":[{
								"sumInsuredRoadAccident":$scope.memberInfo.coveredSonDetails[i].sumInsuredRoadAccident,
								"sumInsuredHospExpenses":$scope.memberInfo.coveredSonDetails[i].sumInsuredHospExpenses,
								"sumInsuredHospEmpExt": $scope.memberInfo.coveredSonDetails[i].sumInsuredHospEmpExt,
								"sumInsuredExtForAccdnt": $scope.memberInfo.coveredSonDetails[i].sumInsuredHospEmpExt>0 ? "YES":"NO",
								"hospExpensesOtherAcdnt": $scope.memberInfo.coveredSonDetails[i].hospExpensesOtherAcdnt,
								"hospExpensesOtherAcdntRqrd": $scope.memberInfo.coveredSonDetails[i].hospExpensesOtherAcdnt>0 ? "Yes":"No",
								"totalAccdntSumInsured":(parseInt($scope.memberInfo.coveredSonDetails[i].sumInsuredRoadAccident) + parseInt($scope.memberInfo.coveredSonDetails[i].sumInsuredHospExpenses))
							}]
						};
						totalSumInsured = totalSumInsured + parseInt($scope.memberInfo.coveredSonDetails[i].sumInsuredRoadAccident) + parseInt($scope.memberInfo.coveredSonDetails[i].sumInsuredHospExpenses);
						
						this.riskPremiumDetails.push(JSON.parse(JSON.stringify($scope.sonRiskDetails)));
						if($scope.memberInfo.coveredSonDetails[i].edit)
						Object.assign($scope.sonRiskDetails.riskdetails,{
							edit: true,
							nameOfInsured: $scope.memberInfo.coveredSonDetails[i].nameOfInsured,
							relationshipWith: $scope.memberInfo.coveredSonDetails[i].relationshipWith,
							riskEmployed: $scope.memberInfo.coveredSonDetails[i].riskEmployed,
							occupationOfMember: $scope.memberInfo.coveredSonDetails[i].occupationOfMember,
							anyOther: $scope.memberInfo.coveredSonDetails[i].anyOther,
							nomineeName: $scope.memberInfo.coveredSonDetails[i].nomineeName,
							relationWithNominee: $scope.memberInfo.coveredSonDetails[i].relationWithNominee,
							anyPhysicalDefects: $scope.memberInfo.coveredSonDetails[i].anyPhysicalDefects,
							physicalDefect: $scope.memberInfo.coveredSonDetails[i].physicalDefect,
							insuredPerEmpNo: $scope.memberInfo.coveredSonDetails[i].insuredPerEmpNo
						});
						additionalMemberArr.push($scope.sonRiskDetails);
					}					
				}
				
				if($scope.memberInfo.disableAddDaughterBtn > 0){
					for(var i =0; i< $scope.memberInfo.coveredDaughterDetails.length; i++){
						var sonAgeCal = $scope.memberInfo.coveredDaughterDetails[i].dateOfBirth;
						var Arr = sonAgeCal.split('/');
						sonAgeCal = Arr[2] + '/' + Arr[1] + '/' + Arr[0]; //mm/dd/yyyy
						var date = new Date(sonAgeCal);
						var ageDifMs = Date.now() - date.getTime();
						var ageDinYrs = new Date(ageDifMs); // miliseconds from epoch
						ageDinYrs = Math.abs(ageDinYrs.getUTCFullYear() - 1970);
						ageDinYrs =ageDinYrs.toString();
						$scope.daughterRiskDetails = {
							"riskdetails":{					
								"relationPolicyHolder":"DAUGHTER",
								"dateOfBirth":$scope.memberInfo.coveredDaughterDetails[i].dateOfBirth,
								"ageOfMember":CommonServices.floaterObj.ageDaughterYrs[i],
								"anyPhysicalDefects":"N"
							},
							"cover":[{
								"sumInsuredRoadAccident":$scope.memberInfo.coveredDaughterDetails[i].sumInsuredRoadAccident,
								"sumInsuredHospExpenses":$scope.memberInfo.coveredDaughterDetails[i].sumInsuredHospExpenses,
								"sumInsuredHospEmpExt": $scope.memberInfo.coveredDaughterDetails[i].sumInsuredHospEmpExt,
								"sumInsuredExtForAccdnt": $scope.memberInfo.coveredDaughterDetails[i].sumInsuredHospEmpExt>0 ? "YES":"NO",
								"hospExpensesOtherAcdnt": $scope.memberInfo.coveredDaughterDetails[i].hospExpensesOtherAcdnt,
								"hospExpensesOtherAcdntRqrd": $scope.memberInfo.coveredDaughterDetails[i].hospExpensesOtherAcdnt>0 ? "Yes":"No",
								"totalAccdntSumInsured":(parseInt($scope.memberInfo.coveredDaughterDetails[i].sumInsuredRoadAccident) + parseInt($scope.memberInfo.coveredDaughterDetails[i].sumInsuredHospExpenses))
							}]
						};
						totalSumInsured = totalSumInsured + parseInt($scope.memberInfo.coveredDaughterDetails[i].sumInsuredRoadAccident) + parseInt($scope.memberInfo.coveredDaughterDetails[i].sumInsuredHospExpenses);
						
						this.riskPremiumDetails.push(JSON.parse(JSON.stringify($scope.daughterRiskDetails)));
						if($scope.memberInfo.coveredDaughterDetails[i].edit)
						Object.assign($scope.daughterRiskDetails.riskdetails,{
							edit: true,
							nameOfInsured: $scope.memberInfo.coveredDaughterDetails[i].nameOfInsured,
							relationshipWith: $scope.memberInfo.coveredDaughterDetails[i].relationshipWith,
							riskEmployed: $scope.memberInfo.coveredDaughterDetails[i].riskEmployed,
							occupationOfMember: $scope.memberInfo.coveredDaughterDetails[i].occupationOfMember,
							anyOther: $scope.memberInfo.coveredDaughterDetails[i].anyOther,
							nomineeName: $scope.memberInfo.coveredDaughterDetails[i].nomineeName,
							relationWithNominee: $scope.memberInfo.coveredDaughterDetails[i].relationWithNominee,
							anyPhysicalDefects: $scope.memberInfo.coveredDaughterDetails[i].anyPhysicalDefects,
							physicalDefect: $scope.memberInfo.coveredDaughterDetails[i].physicalDefect,
							insuredPerEmpNo: $scope.memberInfo.coveredDaughterDetails[i].insuredPerEmpNo
						});
						additionalMemberArr.push($scope.daughterRiskDetails);
					}					
				}
				
				CommonServices.floaterObj.numberOfMembers = this.disableCountBtn;
				CommonServices.floaterObj.addedMemberDetails = additionalMemberArr;
				CommonServices.floaterObj.selfDetails = $scope.memberInfo.selfDetails;
				CommonServices.floaterObj.spouseDetails = $scope.memberInfo.spouseDetails;
				CommonServices.floaterObj.coveredSonDetails = $scope.memberInfo.coveredSonDetails;
				CommonServices.floaterObj.coveredDaughterDetails = $scope.memberInfo.coveredDaughterDetails;
				CommonServices.floaterObj.policyDetails = $scope.memberInfo.policyDetails;
				CommonServices.floaterObj.thirdPartyDetails = $scope.memberInfo.thirdPartyDetails;
				CommonServices.floaterObj.addProposerDisable = $scope.memberInfo.showProposer;
				CommonServices.floaterObj.addSpouseDisable = $scope.memberInfo.showSpouse;
				CommonServices.floaterObj.disableAddDaughterBtn = $scope.memberInfo.disableAddDaughterBtn;
				CommonServices.floaterObj.disableAddSonBtn = $scope.memberInfo.disableAddSonBtn;
				CommonServices.addProposerDisable = $scope.memberInfo.showProposer;
				CommonServices.addSpouseDisable = $scope.memberInfo.showSpouse;
				CommonServices.disableAddDaughterBtn = $scope.memberInfo.disableAddDaughterBtn;
				CommonServices.disableAddSonBtn = $scope.memberInfo.disableAddSonBtn;
				
				let quoteNumber =  (CommonServices.floaterObj.quoteNumber!=="" && CommonServices.floaterObj.quoteNumber!==null)?CommonServices.floaterObj.quoteNumber:null;

				var riskPremiumDetailsData = {
					"quote":{
						"risks":$scope.memberInfo.riskPremiumDetails,
						"quoteNumber": quoteNumber,
						"productCode":"RK",
						"policyStartDate":$scope.memberInfo.policyDetails.policyStartDate,
						"policyExpiryDate":$scope.memberInfo.policyDetails.policyEndDate,
						"term":$scope.memberInfo.policyDetails.policyDuration,
						"mobileNo":null,
						"emailId":null,
						"progressLevel":null,
						"thirdPartyDetails": (!!$scope.memberInfo.thirdPartyDetails.noOfPersonsThirdParty) ?
						{
							"numOfPersons":$scope.memberInfo.thirdPartyDetails.noOfPersonsThirdParty.toString(),
							"sumInsuredForThirdParty":$scope.memberInfo.thirdPartyDetails.sumInsuredThirdParty,
							"totalSIForThirdParty":((+$scope.memberInfo.thirdPartyDetails.sumInsuredThirdParty) * (+$scope.memberInfo.thirdPartyDetails.noOfPersonsThirdParty))
						} : undefined
					},
					"userProfile":{
						"userId":CommonServices.getCommonData("userId"),
						"loggedInRole":CommonServices.getCommonData("loggedInRole")
					}
				};
				var premCalcResponse = RestServices.postService(RestServices.urlPathsNewPortal.calcPremium, riskPremiumDetailsData);
				premCalcResponse.then(
					function(response) { // success 				
					CommonServices.showLoading(false);
					if(response.data !== undefined && response.data !== ""){
						if(response.data.hasOwnProperty('errorMessage')){
							CommonServices.showAlert(response.data.errorMessage);	
						}else{
							CommonServices.floaterObj.quoteNumber = response.data.quote.quoteNumber;
							CommonServices.floaterObj.premiumDetails = response.data.quote.premiumDetails;
							CommonServices.floaterObj.policyStartDate = $scope.memberInfo.policyDetails.policyStartDate;
							CommonServices.floaterObj.policyExpiryDate = $scope.memberInfo.policyDetails.policyEndDate; 
							CommonServices.floaterObj.premiumDetails.sumInsured = totalSumInsured + ((+$scope.memberInfo.thirdPartyDetails.sumInsuredThirdParty) * (+$scope.memberInfo.thirdPartyDetails.noOfPersonsThirdParty));
							$state.go("rakViewBreakup");
						}
					} else {
						CommonServices.showAlert("Something went wrong. Please try after some time");
					}	                  
				},
				function(error) { // failure
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
				});
			}
		},
		initModel: function(){

			$scope.memberInfo.toupTermsAndCondition = true;
			//form Prepopulation starts when coming from Edit Quote 
			if(CommonServices.editQuoteFlag && $rootScope.backFlag!=='premCal'){
				
				this.selfDetails = Object.assign({edit: true},CommonServices.floaterObj.risks[0].riskdetails,CommonServices.floaterObj.risks[0].cover[0]);
				CommonServices.floaterObj.ageProposerYrs = CommonServices.floaterObj.risks[0].riskdetails.ageOfMember;
				this.showProposer = true;

				let sonCount=0, daughterCount=0;
				for(var i=1; i< CommonServices.floaterObj.risks.length; i++){
					if(CommonServices.floaterObj.risks[i].riskdetails.relationPolicyHolder==="SPOUSE"){

						this.spouseDetails = Object.assign({edit: true}, CommonServices.floaterObj.risks[i].riskdetails,CommonServices.floaterObj.risks[i].cover[0]);
						CommonServices.floaterObj.ageSpouseYrs = CommonServices.floaterObj.risks[i].riskdetails.ageOfMember;
						this.showSpouse = true;
					}
					else if(CommonServices.floaterObj.risks[i].riskdetails.relationPolicyHolder==="SON"){
						
						this.addSonFunc();	
						
						this.coveredSonDetails[sonCount] = Object.assign({edit: true}, CommonServices.floaterObj.risks[i].riskdetails,CommonServices.floaterObj.risks[i].cover[0]);
						CommonServices.floaterObj.ageSonYrs[sonCount] = CommonServices.floaterObj.risks[i].riskdetails.ageOfMember;
						sonCount++;
						
					}
					else if(CommonServices.floaterObj.risks[i].riskdetails.relationPolicyHolder==="DAUGHTER"){
						
						this.addDaughterFunc();

						this.coveredDaughterDetails[daughterCount] = Object.assign({edit: true}, CommonServices.floaterObj.risks[i].riskdetails,CommonServices.floaterObj.risks[i].cover[0]);
						CommonServices.floaterObj.ageDaughterYrs[daughterCount] = CommonServices.floaterObj.risks[i].riskdetails.ageOfMember;
						daughterCount++;
					}
					
				}
				this.policyDetails.policyStartDate = CommonServices.floaterObj.policyStartDate;
				this.policyDetails.policyDuration = CommonServices.floaterObj.policyDuration;
				this.policyDetails.policyEndDate = CommonServices.floaterObj.policyExpiryDate;
				if(CommonServices.floaterObj.hasOwnProperty('thirdPartyDetails')){
					this.thirdPartyDetails.noOfPersonsThirdParty = parseInt(CommonServices.floaterObj.thirdPartyDetails.numOfPersons);
					this.thirdPartyDetails.sumInsuredThirdParty = CommonServices.floaterObj.thirdPartyDetails.sumInsuredForThirdParty;
				}
			
				this.disableAddDaughterBtn = daughterCount;
				this.disableAddSonBtn = sonCount;
				this.disableCountBtn = CommonServices.floaterObj.risks.length;
			}
			//form Prepopulation ends coming from Edit Quote 
			
			//form Prepopulation when coming from view breakup page, by pressing the back button	
			else{
				this.selfDetails = CommonServices.floaterObj.selfDetails;
				this.spouseDetails = CommonServices.floaterObj.spouseDetails;
				this.policyDetails = CommonServices.floaterObj.policyDetails;
				this.thirdPartyDetails = CommonServices.floaterObj.thirdPartyDetails;
				this.coveredSonDetails = CommonServices.floaterObj.coveredSonDetails;
				this.coveredDaughterDetails = CommonServices.floaterObj.coveredDaughterDetails;

				this.showProposer = CommonServices.floaterObj.addProposerDisable;
				this.showSpouse = CommonServices.floaterObj.addSpouseDisable;
				this.disableAddDaughterBtn = CommonServices.floaterObj.disableAddDaughterBtn;
				this.disableAddSonBtn = CommonServices.floaterObj.disableAddSonBtn;
				this.disableCountBtn = CommonServices.floaterObj.numberOfMembers;
			}
			if(this.disableAddSonBtn===2) this.addSonDisable=true;
			if(this.disableAddDaughterBtn===2) this.addDaughterDisable=true;

			console.log(CommonServices.floaterObj);
			
		}			
	};

	if(CommonServices.editQuoteFlag || (CommonServices.floaterObj.quoteNumber && CommonServices.floaterObj.quoteNumber!=="" && CommonServices.floaterObj.quoteNumber!==null && CommonServices.floaterObj.quoteNumber!== undefined)){
		$scope.memberInfo.initModel();
	}

	/**************************************************************************************************
	 								START::CR_3562 - Previous Policy search
	 ***************************************************************************************************/
	$scope.showMobileOptn = false;
	$scope.proposerSearchResult = false;
	$scope.searchObj = {};
	
	$scope.getProposerDerails = function (type) {

		if (type === 'policyNumber' && ($scope.searchFromList.prevPolicyNumber.$invalid || $scope.searchObj.prevPolicyNumber === undefined || $scope.searchObj.prevPolicyNumber.trim() === '')) return;
		if (type === 'mobileNumber' && ($scope.searchFromList.mobileNumber.$invalid || $scope.searchObj.prevPolicyMobileNumber === undefined || $scope.searchObj.prevPolicyMobileNumber.trim() === '')) return;
		var domainInputValues = {
			"quote": {
				"policyNumber":$scope.searchObj.prevPolicyNumber.trim()
			},
			"userProfile":{
				"userId": CommonServices.getCommonData("userId"),
				"loggedInRole": "SUPERUSER"
			}
		};
		var comparedMobileNumber = $scope.searchObj.prevPolicyMobileNumber;

		RestServices.postService(RestServices.urlPathsNewPortal.fetchHealthMemberDetail, domainInputValues).then(function (response) {
            CommonServices.showLoading(false);
            
            $scope.proposerSearchResult = false;
			if (response.data.errorCode === 959) {
				CommonServices.showAlert(response.data.errorMessage);
				return;

			} else if (response.data.quote.flagPrevPortal === 1 && type === 'policyNumber') {
				var msg = "As this policy is not attached to you, in order to proceed further please enter the customer's mobile number and search again";
				CommonServices.messageModal('info', msg, false, '', 'Ok', function() {}, function() {
					$scope.showMobileOptn = true;
				}, 'Alert');

			} else if (response.data.quote.contactno != undefined && response.data.quote.contactno != comparedMobileNumber && type === 'mobileNumber') {
				var msg = "Mobile number entered does not match with Mobile number in policy holder details of previous health policy. Please enter correct mobile number";
					CommonServices.messageModal('info', msg, false, '', 'Ok', function() {}, function() {
						$scope.showMobileOptn = false;
                        //$scope.searchObj.prevPolicyNumber = ''; //To fix the issue for CR_3562 - Sudip
                        $scope.searchObj.prevPolicyMobileNumber = ''; //To fix the issue for CR_3562 - sudip
					}, 'Alert');

			} else if (response.data.quote.memberDetails === undefined) {
                var msg = "No data found";
					CommonServices.messageModal('info', msg, false, '', 'Ok', function() {}, function() {
						$scope.showMobileOptn = false;
                    }, 'Alert');
                    
            } else {
				$scope.prevNomineeDetailObj = response.data.quote.memberDetails;
				angular.forEach($scope.prevNomineeDetailObj, function (value, key) {
					value.isSelected = false;
				});
				CommonServices.counts = ($scope.memberInfo.coveredSonDetails.length>0)? $scope.memberInfo.coveredSonDetails.length : 0;
				CommonServices.countd = ($scope.memberInfo.coveredDaughterDetails.length>0)? $scope.memberInfo.coveredDaughterDetails.length : 0;
				CommonServices.noOfMembers = CommonServices.counts + CommonServices.countd + 1 + (($scope.memberInfo.showSpouse)?1:0);
                $scope.proposerSearchResult = true; 
				var obj = {
					page: 'RAK_policyAutoPopulate', 
					title: 'Proposer Search Result', 
					footer: true, 
					bodyMsg: 'Test',
					dataSet: $scope.prevNomineeDetailObj,
					noBtnText: 'Cancel',
					noButtonAction: $scope.searchSelectionAction,
					yesBtnText: 'Ok',
					yesButtonAction: $scope.searchSelectionAction,
				};
				openRelationalModal(obj, 'lg');
			}

		},
		function (error) {    // failure 
			CommonServices.showLoading(false);
			RestServices.handleWebServiceError(error);
		});
	}

	openRelationalModal = function (modalObj = {}, modalSize = 'lg') {
		var modalInstance = $modal.open({
			animation: false,
			templateUrl: 'partials/general/generalModal.html',
			controller: 'generalModalController',
			windowClass: 'general-modal',
			size: modalSize,
			resolve: {
				modalData: function() {
					return modalObj
				}
			}
		});
		modalInstance.result.then(function(result) {
			//backdropClass: ".modal-backdrop .fade";
			// console.log(result);
		});
	}

	$scope.searchObj.validatePolicyNumber = function (data, maxLen) {
		if (data !== undefined) {
			var len = data.toString().length;
			if (len > maxLen) {
				$scope.searchObj.prevPolicyNumber = tempPolicyMaxLen;
			} else {
				var result = /^\d*$/.test(data);
				if (result) {
					tempPolicyMaxLen = $scope.searchObj.prevPolicyNumber;
				}
				if (len === maxLen) {
					$scope.searchFromList.prevPolicyNumber.$invalid = false;
				} else {
					$scope.searchFromList.prevPolicyNumber.$invalid = true;
				}
			}
		}
	}

	$scope.searchSelectionAction = function (isConfirm) {
        if (isConfirm){ 
            angular.forEach($scope.prevNomineeDetailObj, function (obj, i) {
                if (obj.relation.toLowerCase() === 'self' || obj.relation.toLowerCase() === 'proposer') {
                    if (obj.isSelected) {
						$scope.memberInfo.selfDetails.dateOfBirth = obj.dob;
						$scope.memberInfo.dateOfBirthFunc('PROPOSER');
						$scope.memberInfo.selfDetails.name = obj.name;
						$scope.memberInfo.selfDetails.occupation = obj.occupation;
                    } 
				} 
				else if (obj.relation.toLowerCase() === 'spouse') {
                    if (obj.isSelected) {
						if(!$scope.memberInfo.showSpouse)
							$scope.memberInfo.addMember('SPOUSE');
                        $scope.memberInfo.spouseDetails.dateOfBirth = obj.dob;
						$scope.memberInfo.dateOfBirthFunc('SPOUSE')
						$scope.memberInfo.spouseDetails.name = obj.name;
						$scope.memberInfo.spouseDetails.occupation = obj.occupation;
                    } 
				} 
				else if (obj.relation.toLowerCase() === 'children' || obj.relation.toLowerCase() === 'son' || obj.relation.toLowerCase() === 'daughter'){
                    if (obj.isSelected) {
						if(obj.sex == 'M' || obj.relation.toLowerCase() === 'son'){
							var len = ($scope.memberInfo.coveredSonDetails.length>0)? $scope.memberInfo.coveredSonDetails.length : 0;
							// if(len==2){
							// 	CommonServices.showAlert("For Raasta apatti kavach, maximum 2 sons and 2 daughters can be added.");
							// }
							// else
							$scope.memberInfo.addMember('SON');
							$scope.memberInfo.coveredSonDetails[len].dateOfBirth = obj.dob;
							if(!$scope.memberInfo.dateOfBirthFunc('SON', len)){
								$scope.memberInfo.closeMember('SON', len);
								CommonServices.showAlert("Age of the Child should be between 5 years to 80 Years");
							}
							else{
								$scope.memberInfo.coveredSonDetails[len].name = obj.name;
								$scope.memberInfo.coveredSonDetails[len].occupation = obj.occupation;
							}
						}
						else if(obj.sex == 'F' || obj.relation.toLowerCase() === 'daughter'){
							var len = ($scope.memberInfo.coveredDaughterDetails.length>0)? $scope.memberInfo.coveredDaughterDetails.length : 0;
							// if(len==2){
							// 	CommonServices.showAlert("For Raasta apatti kavach, maximum 2 sons and 2 daughters can be added.");
							// }
							// else
							$scope.memberInfo.addMember('DAUGHTER');
							$scope.memberInfo.coveredDaughterDetails[len].dateOfBirth = obj.dob;
							if(!$scope.memberInfo.dateOfBirthFunc('DAUGHTER', len)){
								$scope.memberInfo.closeMember('DAUGHTER', len);
								CommonServices.showAlert("Age of the Child should be between 5 years to 80 Years");
							}
							else{
								$scope.memberInfo.coveredDaughterDetails[len].name = obj.name;
								$scope.memberInfo.coveredDaughterDetails[len].occupation = obj.occupation;
							}
						}
                    }
				}
            });
        }
		$scope.proposerSearchResult = false;
		$scope.showMobileOptn = false;
		// $scope.searchObj.prevPolicyNumber = '';
		$scope.searchObj.prevPolicyMobileNumber = '';
	}

	// function resetProposerDetail () {
    //     $scope.closeMember('Proposer');
    //     $scope.closeMember('Spouse');
    //     //$scope.childrenDetails = []; //to fix the issue - Sudip
    //     $scope.addSpouseBtnDisable = false;
    //     $scope.addChildDisable = false;
    //     $scope.addProposerBtnDisable = false;
    //     $scope.numberOfmembers = 0;

    //     // angular.forEach($scope.childrenDetails, function (value, i) {
    //     //     $scope.closeMember('Child', i);
    //     // });
    //     $scope.premiumCalcModels.proposerDateOfBirth = '';
    //     $scope.premiumCalcModels.spouseDateOfBith = '';
    //    // $scope.premiumCalcModels.thresholdLimit = ''; //to fix the issue - Sudip
    //    // $scope.premiumCalcModels.sumInsured = ''; //to fix the issue - Sudip
    // }
	/***************************************************************************************************
	 								END::CR_3562 - Previous Policy search 
	 ****************************************************************************************************/
}]);
agentApp.controller('rakViewBreakupCtrl', ['$scope', 'RestServices', 'CommonServices', '$state', '$rootScope', function ($scope, RestServices, CommonServices, $state, $rootScope) {
    $rootScope.backFlag = "premCal";
    $scope.goBack = function () {     
            $state.go("rakPremiumCalculator");
    };
	console.log(CommonServices.floaterObj);
	$scope.basicPremium = CommonServices.floaterObj;
	$scope.totalSumInsured = CommonServices.floaterObj.premiumDetails.sumInsured;
	$scope.totalPremium = CommonServices.floaterObj.premiumDetails.grossPremium?CommonServices.floaterObj.premiumDetails.grossPremium:CommonServices.floaterObj.premiumDetails.totalPremium;
	$scope.policyStartDate = CommonServices.floaterObj.policyStartDate;
	$scope.policyExpiryDate = CommonServices.floaterObj.policyExpiryDate;

	$scope.viewBreakupResult = [];

    $scope.topUpBreakupClick = function () {
		
		var viewBreakUpInput = {
			"header": null,
			"quote": {
				"quoteNumber": $scope.basicPremium.quoteNumber,
				"policyHolderCode": "",
				"productCode": "RK"
			}
		};
        var viewBreakUpResponse = RestServices.postService(RestServices.urlPathsNewPortal.eProdViewBreakup, viewBreakUpInput);
        viewBreakUpResponse.then(
            function (response) { // success 

                CommonServices.showLoading(false);
				if (response.data !== undefined && response.data !== "") {
                    if (response.data.userProfile.footer.errorCode === "0") {
						$scope.viewBreakupShow = true;
                        CommonServices.floaterObj.viewBreakUpResponse = response.data.quote;
						$scope.premiumDetails = response.data.quote.premiumDetails;
                        $scope.viewBreakupResult = response.data.quote.risks;
						
                    } else {
                        CommonServices.showAlert(response.data.userProfile.footer.status);
                    }
                } else {
                    CommonServices.showAlert("Please try after some time");
                }
            },
            function (error) { // failure
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            });

    };

	$scope.closePopup = function(){
		$scope.viewBreakupShow = false;
	}

    $scope.viewBreakCntBtn = function () {
        CommonServices.policyDetailsObj.enableEditModels = "";
        $rootScope.searchLength = 0;
        $state.go("policyHolderInformation");
    };
}]);

agentApp.controller('rakPolicyHolderDetailCtrl', ['$scope', '$rootScope', 'RestServices', 'CommonServices', '$state', function ($scope, $rootScope, RestServices, CommonServices, $state) {
    
	$scope.isDev = CommonServices.getCommonData("stakeCode") === 'DEVLP-OFF' ? true : false;
	
	$rootScope.backFlag = "policyHolder";
	$scope.countOfMembers = CommonServices.floaterObj.numberOfMembers;
	$scope.basicPremium = CommonServices.floaterObj;
	$scope.totalSumInsured = CommonServices.floaterObj.premiumDetails.sumInsured;
	$scope.additionalDetailsArray = [];

    var sonCount = 0, daughterCount = 0;
	var varForLoopgen = 0;
	var memberDetails = {};

    varForLoopgen = varForLoopgen + CommonServices.floaterObj.numberOfMembers;
	

    for (var i = 0; i < varForLoopgen; i++) {

		if (CommonServices.floaterObj.addedMemberDetails[i].riskdetails.relationPolicyHolder === "SON") {
			memberDetails = {
				//headerName = `Son${sonCount+1}`,
				nameOfInsured: CommonServices.floaterObj.coveredSonDetails[sonCount].name?CommonServices.floaterObj.coveredSonDetails[sonCount].name:"",
				occupationOfMember: CommonServices.floaterObj.coveredSonDetails[sonCount].occupation?CommonServices.floaterObj.coveredSonDetails[sonCount].occupation:"",
			};
			sonCount = sonCount + 1;
		}
		
		else if (CommonServices.floaterObj.addedMemberDetails[i].riskdetails.relationPolicyHolder === "DAUGHTER") {
			memberDetails = {
				//headerName = `Daughter${daughterCount}`,
				nameOfInsured: CommonServices.floaterObj.coveredDaughterDetails[daughterCount].name? CommonServices.floaterObj.coveredDaughterDetails[daughterCount].name:"",
				occupationOfMember: CommonServices.floaterObj.coveredDaughterDetails[daughterCount].occupation?CommonServices.floaterObj.coveredDaughterDetails[daughterCount].occupation:"",
			};
			daughterCount = daughterCount + 1;
		}

		else if (CommonServices.floaterObj.addedMemberDetails[i].riskdetails.relationPolicyHolder === "SELF"){
			memberDetails = {
				//headerName = "Self",
				nameOfInsured: CommonServices.floaterObj.selfDetails.name? CommonServices.floaterObj.selfDetails.name:CommonServices.floaterObj.policyHolderName,
				occupationOfMember: CommonServices.floaterObj.selfDetails.occupation? CommonServices.floaterObj.selfDetails.occupation:"",
			}

		}
		else if(CommonServices.floaterObj.addedMemberDetails[i].riskdetails.relationPolicyHolder === "SPOUSE"){
			memberDetails = {
				//headerName = "Spouse",
				nameOfInsured: CommonServices.floaterObj.spouseDetails.name? CommonServices.floaterObj.spouseDetails.name:"",
				occupationOfMember: CommonServices.floaterObj.spouseDetails.occupation? CommonServices.floaterObj.spouseDetails.occupation:"",
			}
		}
	/***************************************************************************************************
	 								START::CR_3562 - Previous Policy search 
	 ****************************************************************************************************/
		$scope.additionalDetailsArray.push({
			headerName: (CommonServices.floaterObj.addedMemberDetails[i].riskdetails.relationPolicyHolder === 'SELF' ? "Self" :  (CommonServices.floaterObj.addedMemberDetails[i].riskdetails.relationPolicyHolder === 'SPOUSE' ? "Spouse" : (CommonServices.floaterObj.addedMemberDetails[i].riskdetails.relationPolicyHolder === "SON" ? `Son ${sonCount}` : `Daughter ${daughterCount}`))),
			
			nameOfInsured: (memberDetails.nameOfInsured)? memberDetails.nameOfInsured : ((CommonServices.floaterObj.addedMemberDetails[i].riskdetails.relationPolicyHolder == 'SELF')?CommonServices.policyHolderName:(CommonServices.floaterObj.addedMemberDetails[i].riskdetails.nameOfInsured)?CommonServices.floaterObj.addedMemberDetails[i].riskdetails.nameOfInsured:''),

			relationshipWith: CommonServices.floaterObj.addedMemberDetails[i].riskdetails.relationPolicyHolder,
			ageOfMember: CommonServices.floaterObj.addedMemberDetails[i].riskdetails.ageOfMember,
			riskEmployed: CommonServices.floaterObj.addedMemberDetails[i].riskdetails.relationPolicyHolder !== 'SELF'? ( CommonServices.floaterObj.addedMemberDetails[i].riskdetails.riskEmployed?CommonServices.floaterObj.addedMemberDetails[i].riskdetails.riskEmployed:'NO') :'NO',
			occupationOfMember: (CommonServices.floaterObj.addedMemberDetails[i].riskdetails.occupationOfMember)? CommonServices.floaterObj.addedMemberDetails[i].riskdetails.occupationOfMember :(memberDetails.occupationOfMember?memberDetails.occupationOfMember:''),
			anyOther: (CommonServices.floaterObj.addedMemberDetails[i].riskdetails.anyOther && CommonServices.floaterObj.addedMemberDetails[i].riskdetails.occupationOfMember=='OTHERS'?CommonServices.floaterObj.addedMemberDetails[i].riskdetails.anyOther:''),
			nomineeName: (CommonServices.floaterObj.addedMemberDetails[i].riskdetails.nomineeName?CommonServices.floaterObj.addedMemberDetails[i].riskdetails.nomineeName:''),
			relationWithNominee: (CommonServices.floaterObj.addedMemberDetails[i].riskdetails.relationWithNominee?CommonServices.floaterObj.addedMemberDetails[i].riskdetails.relationWithNominee:''),
			anyPhysicalDefects: (CommonServices.floaterObj.addedMemberDetails[i].riskdetails.anyPhysicalDefects?CommonServices.floaterObj.addedMemberDetails[i].riskdetails.anyPhysicalDefects:''),
			physicalDefect: (CommonServices.floaterObj.addedMemberDetails[i].riskdetails.physicalDefect && CommonServices.floaterObj.addedMemberDetails[i].riskdetails.anyPhysicalDefects==='Y'?CommonServices.floaterObj.addedMemberDetails[i].riskdetails.physicalDefect:''),
			insuredPerEmpNo: (CommonServices.floaterObj.addedMemberDetails[i].riskdetails.insuredPerEmpNo?CommonServices.floaterObj.addedMemberDetails[i].riskdetails.insuredPerEmpNo:'')
		});

		switch($scope.additionalDetailsArray[i].occupationOfMember.toUpperCase()){
			case 'ACCOUNTANTS':  
				$scope.additionalDetailsArray[i].occupationOfMember = 'ACC'; 
				break;			
			case 'ARCHITECTS':  
				$scope.additionalDetailsArray[i].occupationOfMember = 'ARCH';
				break;			
			case 'BANKERS':   
				$scope.additionalDetailsArray[i].occupationOfMember= 'BANK';
				break;			
			case 'BUILDERS':    
				$scope.additionalDetailsArray[i].occupationOfMember= 'BUILD';
				break;			
			case 'BUSINESS':   
				$scope.additionalDetailsArray[i].occupationOfMember = 'BIZ';
				break;			
			case 'CASH CARRYING EMPLOYEES':  
				$scope.additionalDetailsArray[i].occupationOfMember = 'CASH';
				break;			
			case 'CONSULTING ENGINEERS':  
				$scope.additionalDetailsArray[i].occupationOfMember = 'CONENG';
				break;			
			case 'CONTRACTS AND ENGINEERS ENGAGED IN SUPERINTENDING FUNCTIONS ONLY':  
				$scope.additionalDetailsArray[i].occupationOfMember = 'SUPER';
				break;			
			case 'DOCTORS':  
				$scope.additionalDetailsArray[i].occupationOfMember = 'DOC';
				break;		
			case 'DRIVERS OF TRUCKS OF LORRIES AND OTHER HEAVY VEHICLES':  
				$scope.additionalDetailsArray[i].occupationOfMember = 'DRIH';
				break;										
			case 'GARAGE AND MOTOR MECHANICS':  
				$scope.additionalDetailsArray[i].occupationOfMember = 'MECH';
				break;			
			case 'HOUSEWIFE':  
				$scope.additionalDetailsArray[i].occupationOfMember = 'HW';
				break;			
			case 'LAWYERS':  
				$scope.additionalDetailsArray[i].occupationOfMember = 'LAW';
				break;			
			case 'MACHINE OPERATORS':  
				$scope.additionalDetailsArray[i].occupationOfMember = 'MACH';
				break;			
			case 'PAID DRIVERS OF MOTOR CARS AND LIGHT MOTOR VEHICLES':  
				$scope.additionalDetailsArray[i].occupationOfMember = 'DRI';
				break;			
			case 'PERSON ENGAGED IN ADMININISTRATIVE FUNCTIONS':  
				$scope.additionalDetailsArray[i].occupationOfMember = 'ADMIN';
				break;			
			case 'PROFESSIONAL ATHELETS AND SPORTSMEN WORLD WORKING MECHANISTS':  
				$scope.additionalDetailsArray[i].occupationOfMember = 'SPORT';
				break;			
			case 'STUDENT':  
				$scope.additionalDetailsArray[i].occupationOfMember = 'STU';
				break;			
			case 'TEACHERS':  
				$scope.additionalDetailsArray[i].occupationOfMember = 'TEA';
				break;			
			case 'VETERINARY DOCTORS':  
				$scope.additionalDetailsArray[i].occupationOfMember = 'VETDOC';
				break;			
			case 'WOODWORKING MACHINISTS':  
				$scope.additionalDetailsArray[i].occupationOfMember = 'WOOD';
				break;			
			case 'SOFTWARE/BPO/IT/CONSULTANTS/HR PROFESSIONALS':  
				$scope.additionalDetailsArray[i].occupationOfMember = 'SBICH';
				break;
	
		}
		//console.log(CommonServices.floaterObj);

	}
	/***************************************************************************************************
	 								END::CR_3562 - Previous Policy search 
	 ****************************************************************************************************/

    CommonServices.floaterObj.additionalArray = $scope.additionalDetailsArray;

    $scope.direction = 'right';
    $scope.currentIndex = 0;

    $scope.setCurrentSlideIndex = function (index) {
        $scope.direction = (index > $scope.currentIndex) ? 'left' : 'right';
        $scope.currentIndex = index;
    };

    $scope.isCurrentSlideIndex = function (index) {
        return $scope.currentIndex === index;
    };

    $scope.prevSlide = function (index) {
        $scope.direction = 'left';
        if (index > 0) {
            $scope.currentIndex = index - 1;
        } else {
			$state.go("policyHolderInformation");
        }
    };

    $scope.nextSlide = function (index) {
		
		$scope.direction = 'right';
		if($scope.currentIndex < ($scope.additionalDetailsArray.length-1))
        $scope.currentIndex = index + 1;
    
		CommonServices.floaterObj.addedMemberDetails[index].riskdetails.nameOfInsured = $scope.additionalDetailsArray[index].nameOfInsured.toUpperCase();
		CommonServices.floaterObj.addedMemberDetails[index].riskdetails.riskEmployed = $scope.additionalDetailsArray[index].riskEmployed;
		CommonServices.floaterObj.addedMemberDetails[index].riskdetails.occupationOfMember = $scope.additionalDetailsArray[index].occupationOfMember;
		CommonServices.floaterObj.addedMemberDetails[index].riskdetails.anyOther = $scope.additionalDetailsArray[index].anyOther;
		CommonServices.floaterObj.addedMemberDetails[index].riskdetails.nomineeName = $scope.additionalDetailsArray[index].nomineeName;
		CommonServices.floaterObj.addedMemberDetails[index].riskdetails.relationWithNominee = $scope.additionalDetailsArray[index].relationWithNominee;
		CommonServices.floaterObj.addedMemberDetails[index].riskdetails.anyPhysicalDefects = $scope.additionalDetailsArray[index].anyPhysicalDefects;
		CommonServices.floaterObj.addedMemberDetails[index].riskdetails.physicalDefect = $scope.additionalDetailsArray[index].physicalDefect;
		CommonServices.floaterObj.addedMemberDetails[index].riskdetails.insuredPerEmpNo = $scope.additionalDetailsArray[index].insuredPerEmpNo;
		
		if(index===$scope.additionalDetailsArray.length-1){ //checking last  index

			if(!$scope.isDev) $scope.saveQuotes();
			else $state.go("relationDetails");
		}
    };

	$scope.saveQuotes = function(){

		saveQuoteInput ={
          "quote": {
            "quoteNumber":CommonServices.floaterObj.quoteNumber,
            "productCode": "RK",
            "policyHolderCode": CommonServices.floaterObj.policyHolderCode,
            "policyHolderName":CommonServices.floaterObj.policyHolderName,
            "policyStartDate": CommonServices.floaterObj.policyDetails.policyStartDate,
            "policyExpiryDate": CommonServices.floaterObj.policyDetails.policyEndDate,
			"term": CommonServices.floaterObj.policyDetails.policyDuration,
            "mobileNo": null,
            "emailId": null,
            "progressLevel": null,
            "risks":CommonServices.floaterObj.addedMemberDetails
          },
          "userProfile": {
            "userId": CommonServices.getCommonData("userId"),
            "loggedInRole": "SUPERUSER"
          }
     	};

		CommonServices.showLoading(true);
		var saveQuoteResponse = RestServices.postService(RestServices.urlPathsNewPortal.cpSaveQuote, saveQuoteInput);
		saveQuoteResponse.then(
			function(response) { // success	
				CommonServices.showLoading(false);
					if(response.data.hasOwnProperty('errorMessage')){
						CommonServices.showAlert(response.data.errorMessage);
					}else{
						CommonServices.floaterObj.saveQuoteResponse = response.data.quote;
						CommonServices.floaterObj.premiumDetails = response.data.quote.premiumDetails;
						CommonServices.floaterObj.premiumDetails.sumInsured = $scope.totalSumInsured;
						$state.go("rakReviewSummary");
					}
					
			},
			function(error) { // failure
				CommonServices.showLoading(false);
				RestServices.handleWebServiceError(error);
			});

	};

	if($scope.isDev){ /**Domain Values Service Call**/
		CommonServices.getDomainValues();
	}

}]);


agentApp.controller('rakReviewSummaryCtrl', ['$scope', 'RestServices', 'CommonServices', '$state', '$rootScope','CartServices', function ($scope, RestServices, CommonServices, $state, $rootScope,CartServices) {
    
	CommonServices.floaterObj.reviewSummary = true;
    $rootScope.backFlag = "reviewSummary";
    CommonServices.policyDetailsObj.policyHolderCreateText = "reviewSummaryEdit";
    $scope.typeOfLogin = CommonServices.getCommonData("stakeCode");
    $scope.reviewSummaryObj = CommonServices.floaterObj;
	$scope.reviewSummaryObj.getPolicyholderDetails = CommonServices.policyDetailsObj.getPolicyholderDetails;
	
    /* 3712 Starts
    $scope.reviewSummaryObj.getPolicyholderDetails.partyDetails.individualDetails.clientNationality = 'NonIndian'; //3712
    $scope.reviewSummaryObj.getPolicyholderDetails.partyDetails.individualDetails.clientCountry = 'Australia'; //3712
    // 3712 Ends */
    /* Starts 3712 
    for (var i = 0; i < $scope.reviewSummaryObj.addedMemberDetails.length; i++) {
        $scope.reviewSummaryObj.addedMemberDetails[i].riskdetails.clientNationality = 'NonIndian'+i;
        $scope.reviewSummaryObj.addedMemberDetails[i].riskdetails.clientCountry = 'Australia'+i;
    }
    // Ends 3712 */
    
    if (CommonServices.policyDetailsObj.state === undefined) {
        if(CommonServices.policyDetailsObj.navigationFrom == "existing" && CommonServices.userClickedOnDivFunc != true){
            $scope.reviewSummaryObj.state = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.stateName.state;
            $scope.reviewSummaryObj.city = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.cityName.city;
        }else{
            $scope.reviewSummaryObj.state = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.state;
            $scope.reviewSummaryObj.city = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.city;
        }
        $scope.reviewSummaryObj.pinCode = CommonServices.policyDetailsObj.getPolicyholderDetails.partyDetails.individualDetails.pinCode;
    } else {
        $scope.reviewSummaryObj.state = CommonServices.policyDetailsObj.state;
        $scope.reviewSummaryObj.city = CommonServices.policyDetailsObj.city;
        $scope.reviewSummaryObj.pinCode = CommonServices.policyDetailsObj.pinCode;

    }

    $scope.goBack = function () {
        $state.go("rakProposerDetails");
        return;
    }
    
    var daughterCount = 0,sonCount = 0;  

	for (var i = 0; i < $scope.reviewSummaryObj.addedMemberDetails.length; i++) {
		if ($scope.reviewSummaryObj.addedMemberDetails[i].riskdetails.relationPolicyHolder.toUpperCase() === "DAUGHTER") {
			daughterCount = daughterCount + 1;
		} else if ($scope.reviewSummaryObj.addedMemberDetails[i].riskdetails.relationPolicyHolder.toUpperCase() === "SON") {
			sonCount = sonCount + 1;
		}
		
		
		if ($scope.reviewSummaryObj.addedMemberDetails[i].riskdetails.relationPolicyHolder.toUpperCase() === 'SELF') {
			$scope.reviewSummaryObj.addedMemberDetails[i].riskdetails.policyHolder = "Proposer";
		} else if ($scope.reviewSummaryObj.addedMemberDetails[i].riskdetails.relationPolicyHolder.toUpperCase() === 'SPOUSE') {
			$scope.reviewSummaryObj.addedMemberDetails[i].riskdetails.policyHolder = "Spouse";
		} else if ($scope.reviewSummaryObj.addedMemberDetails[i].riskdetails.relationPolicyHolder.toUpperCase() === 'SON') {
			$scope.reviewSummaryObj.addedMemberDetails[i].riskdetails.policyHolder = "Son "+sonCount;
		} else if ($scope.reviewSummaryObj.addedMemberDetails[i].riskdetails.relationPolicyHolder.toUpperCase() === 'DAUGHTER') {
			$scope.reviewSummaryObj.addedMemberDetails[i].riskdetails.policyHolder = "Daughter "+daughterCount;
		} 
	}
    
    $scope.breakupClickSummary = function () {

        let viewBreakUpInput = {};
        viewBreakUpInput = {
			"header": null,
			"quote": {
				"quoteNumber": CommonServices.floaterObj.quoteNumber,
				"policyHolderCode": CommonServices.floaterObj.policyHolderCode,
				"productCode": 'RK'
			}
		};
        
        let viewBreakUpResponse = RestServices.postService(RestServices.urlPathsNewPortal.eProdViewBreakup, viewBreakUpInput);
        viewBreakUpResponse.then(
            function (response) { // success 

                CommonServices.showLoading(false);
				if (response.data !== undefined && response.data !== "") {
                    if (response.data.userProfile.footer.errorCode === "0") {
						$scope.viewBreakupShow = true;
                        CommonServices.floaterObj.viewBreakUpResponse = response.data.quote;
					} else {
                        CommonServices.showAlert(response.data.userProfile.footer.status);
                    }
                } else {
                    CommonServices.showAlert("Please try after some time");
                }
            },
            function (error) { // failure
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            });
    };

	$scope.closePopup = function(){
		$scope.viewBreakupShow = false;
	}

    /**CR690 Start**/
    $rootScope.panmodalOpen = false;

    var panCardDetails = {
        "quoteNumber": CommonServices.floaterObj.quoteNumber,
        "policyHolderCode": CommonServices.floaterObj.policyHolderCode
    }
    CommonServices.setCommonData("panCardData", panCardDetails);
    /**CR690 End**/

    $scope.approvePay = function (type = '') {
        var messageSystemDate = CommonServices.getCommonData("serverDate");
        var arr = messageSystemDate.split('/');
        messageSystemDate = arr[1] + '/' + arr[0] + '/' + arr[2]; //mm/dd/yyyy  
        CommonServices.setCommonData("addToCart", type); // CR3546

        var msg = "Do you wish to proceed with approval of quotation? Once Approved, no more changes will be made available on your quotation. Your payment should be made by " + messageSystemDate + " 23:59:59. Please confirm";
		CommonServices.messageModal('info', msg, false, 'Cancel', 'Confirm', function () {
			paymentExitFunction(2);
		}, function () {
			paymentExitFunction(1);
		}, 'Alert');
		
    };

    function paymentExitFunction(button) {
        if (button == 1) {
            approvePolicy();
        } else {
            CommonServices.showLoading(false);
            // $state.go("reviewSummaryScreen");
        }
    }

    function approvePolicy() {
        var approveQuoteInput = {
            "userProfile": {
                "userId": CommonServices.getCommonData("userId"),
                "loggedInRole": "SUPERUSER",
                "uiFlow": "NON_CUSTOMER"
            },
            "quote": {
                "quoteNumber": $scope.reviewSummaryObj.quoteNumber,
                "policyType": null,
                "productCode": $rootScope.productName
            }
        };

        if (CommonServices.getCommonData("addToCart")==='cart') { // CR3546
            CartServices.approveAndAddToCart(approveQuoteInput, $rootScope.productName);
            return;
        }
        var TopUpapproveQuoteGen = RestServices.postService(RestServices.urlPathsNewPortal.approveRenewedQuote, approveQuoteInput);
        TopUpapproveQuoteGen.then(
            function (response) { // success 

                CommonServices.showLoading(false);

                CommonServices.floaterObj.TopUpapproveQuoteRes = response.data.quote;
                CommonServices.setCommonData("CollectionPaymentDetails", CommonServices.floaterObj.saveQuoteResponse);
                if (response.data.userProfile.footer.errorDescription.trim() === "Proposal Approved") {
                    $state.go("collectionForm");
                }
                else {
                    /**CR690 Start**/
                    if (response.data.userProfile.footer.errorCode === "224541") {
                        $rootScope.panmodalOpen = true;
                        CommonServices.setCommonData("setPanMsg", response.data.userProfile.footer.errorDescription);
                    }
                    /**CR690 End**/
                    else {
                        CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
                    }

                }

            },
            function (error) { // failure
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            });

    };


    $scope.goToPolicyHolderInfoEdit = function () {
        CommonServices.policyDetailsObj.enableEditModels = "MODELSEDIT";
        CommonServices.floaterObj.goToNomineeInfoEdit = "policyHolderInformation";
        $state.go("policyHolderInformation");

    };

    $scope.goToMemeberInfoEdit = function () {

        CommonServices.floaterObj.goToNomineeInfoEdit = "proposerDetailsEdit";
        $state.go("rakProposerDetails");

    };

    $scope.goToRelationInfoEdit = function () {
        CommonServices.floaterObj.goToRelationInfoEdit = "relationInfoEdit";
        $state.go("relationDetails");
    };

}]);
