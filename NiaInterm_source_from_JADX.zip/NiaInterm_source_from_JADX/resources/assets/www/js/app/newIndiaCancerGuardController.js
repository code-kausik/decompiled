	agentApp.controller('newIndiaCancerGuardController', ['$scope','$rootScope','RestServices','CommonServices','$state','$rootScope', function ($scope,$rootScope, RestServices,CommonServices,$state,$rootScope) {
		
		CommonServices.floaterObj.goToNomineeInfoEdit ="premiumCalculate";
		CommonServices.floaterObj.goToMemeberInfoEdit ="premiumCalculate";
		const maxSumInsuredValue = 5000000;
		CommonServices.checkMaxInsuredAmount = false;
		//$scope.memberInfo.isSmoker = "N";
		$scope.isvalidDOB = true;
		$rootScope.policyDetailsObj = {};//sourav 02.11.2019
		CommonServices.floaterObj.serviceCall="";
		$scope.termsAndCondition = function(){
			$rootScope.termsCondOpen= true;
		}
		//sourav try to solve editquote feature
		// if(CommonServices.editQuoteFlag === true){
		// 	console.log("in edit quote for cancer add member" +CommonServices.floaterObj.proposerDateOfBirth);
		// 	$scope.memberInfo.proposerDateOfBirth=CommonServices.floaterObj.dateOfBirth;
		// }
		/** Members Sum Insured **/
		$scope.sumInsuredData=[{
			"name":"500000",
			"value": "500000"
		}];
		// sourav CR_3725
		// $scope.gender=[{
		// 	"name":"Male",
		// 	"value":"Male"
		// },
		// {
		// 	"name":"Female",
		// 	"value":"Female"
		// },
		// {
		// 	"name":"Third Gender",
		// 	"value":"Third Gender"
		// }
		// ];
		$scope.sumInsuredDataArray=
			{
				65:[{"name":"500000","value": "500000"}],
				60:[{"name":"500000","value": "500000"},{"name":"1000000","value": "1000000"}],
				55:[{"name":"500000","value": "500000"},{"name":"1000000","value": "1000000"},{"name":"1500000","value": "1500000"}],
				50:[{"name":"500000","value": "500000"},{"name":"1000000","value": "1000000"},{"name":"1500000","value": "1500000"},{"name":"2500000","value": "2500000"},{"name":"5000000","value": "5000000"}]	
			};
		$scope.sumInsuredProposerArray = [];
		$scope.sumInsuredSpouseArray = [];
		$scope.sumInsuredParentArray = [[]];
		$scope.sumInsuredWardArray = [[]];
		$scope.sumInsuredChildArray = [[]];
		// sourav CR_3725

		/** Calender Icon click **/
		$scope.calIconClick= function(event) {
				angular.element("#"+ event.currentTarget.children[0].id).focus(); 
		}; 
		var mydateStr = new Date(CommonServices.getCommonData("serverDate"));
		var mynewdateFrom = "";
		if(mydateStr != undefined){
			mynewdateFrom = new Date(mydateStr);
		} else {
			mynewdateFrom = new Date();
		}
		/** Set Proposer, Spouse, Parent DOB**/
		var enableProposerDOBCalMin = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 18));
		enableProposerDOBCalMin = new Date(enableProposerDOBCalMin.setDate(enableProposerDOBCalMin.getDate()));
		enableProposerDOBCalMin = getFormattedDate(enableProposerDOBCalMin);
		var TodyasDateFormatToCal = CommonServices.getCommonData("serverDate");
		
		/** Set Calender range for proposer, spouse, child and parent **/
		var enableProposerDOBCalfrom = getFormattedDate(mynewdateFrom);
		var enableProposerDOBCalTo =new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 66));
		/**Proposer DOB**/
		$('#proposerDateOfBirth').loadCalendar({
			'enableDateRange': true,
			'enableCalendarFrom': enableProposerDOBCalTo,
			'enableCalendarTo': enableProposerDOBCalfrom
		});
		/**Spouse DOB**/
		$('#spouseDateOfBirth').loadCalendar({
			'enableDateRange': true,
			'enableCalendarFrom': enableProposerDOBCalTo,
			'enableCalendarTo': enableProposerDOBCalfrom
		});
		/**Child DOB**/
		$scope.childDateOfBirth = function(index){
		$("#idDocNoProposer"+index).loadCalendar({
			'enableDateRange': true,
			'enableCalendarFrom': enableProposerDOBCalTo,
			'enableCalendarTo': enableProposerDOBCalfrom
		});
		return true;
		}; 
		/**Ward DOB**///sourav CR_3725
		$scope.wardDateOfBirth = function(index){
			$("#idDocNoProposerWard"+index).loadCalendar({
				'enableDateRange': true,
				'enableCalendarFrom': enableProposerDOBCalTo,
				'enableCalendarTo': enableProposerDOBCalfrom
			});
			return true;
		};
		/**Parent DOB**/
		$scope.parentDateOfBirth = function(index){    
			$("#idDocNoParent"+index).loadCalendar({
			'enableDateRange': true,
			'enableCalendarFrom': enableProposerDOBCalTo,
			'enableCalendarTo': enableProposerDOBCalfrom
			});
			return true;
		};
		
		//3 months
		var childAgeEnableFrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 66));
		var wardAgeEnableFrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 66));

		
		/** Policy Start date set to current date**/
		//some kind of duplicated part is there. need to validate
		var policyStartDate = enableProposerDOBCalfrom;
		var arr = policyStartDate.split('/');
		policyStartDate =arr[1] + '/' + arr[0] + '/' + arr[2]; //dd/mm/yyyy
		CommonServices.floaterObj.policyStartDate = policyStartDate;
		
		/** Policy End date set to policyStartDate + 1 year **/
		var policyEndDate =new Date(mydateStr);
		policyEndDate.setFullYear(policyEndDate.getFullYear() +1);
		policyEndDate.setDate(policyEndDate.getDate() - 1);
		var dd = policyEndDate.getDate();
		var mm = policyEndDate.getMonth() + 1;
		var yyyy = policyEndDate.getFullYear();
		if (dd < 10) {
			dd = "0" + dd;
		}
		if (mm < 10) {
			mm = "0" + mm;
		}
		policyEndDate = dd + "/" +mm + "/" + yyyy;//policy end date
		CommonServices.floaterObj.policyExpiryDate = policyEndDate;
		CommonServices.floaterObj.genderArray = $scope.gender;
		$scope.memberInfo = {
			showProposer: true,
			showSpouse: false,
			addChildDisable: false,
			addParentDisable: false,
			childReq: false,
			wardReq:false,//sourav CR_3725
			parentReq: false,
			disableCountBtn: CommonServices.editQuoteFlag?0:1,
			coveredChildDetails: [],
			coveredWardDetails:[],//sourav CR_3725
			coveredParentDetails: [],
			riskPremiumDetails : [],
			disableAddChildBtn: 0,
			disableAddWardBtn: 0,
			disableAddParentBtn: 0,
			
			/** Add member to CP Product **/
			addMember:function(member) {
				this.disableCountBtn = this.disableCountBtn + 1;
				if(member === "SPOUSE") {
					$scope.memberInfo.spouseIsAdded = true;
					// if(this.disableAddChildBtn === 4){
						// $scope.memberInfo.addChildDisable=true;
					// }
					this.showSpouse=true;
					//$scope.memberInfo.addSpouseDisable=true; 
					console.log("new sum insured data array logic try" +$scope.sumInsuredDataArray[50].value);
					//console.log("new sum insured data array logic 50" +sumInsuredDataArray[65]);            
				} else if(member === "CHILD") {
					//$scope.memberInfo.addChildDisable = true;
					//$scope.memberInfo.showChildDOB=true;
					$scope.memberInfo.childReq = true;
					if($scope.memberInfo.coveredChildDetails.length <= 18){
						this.addChildFunc();					
						this.disableAddChildBtn = this.disableAddChildBtn + 1;
					} 
					else if($scope.memberInfo.coveredChildDetails.length <= 19){
						$scope.memberInfo.addChildDisable=true;
						this.addChildFunc();				
						this.disableAddChildBtn = this.disableAddChildBtn + 1;					
					} 
					else if($scope.memberInfo.coveredChildDetails.length  === 20){
						$scope.memberInfo.addChildDisable=true;
						this.addChildFunc();
						this.disableAddChildBtn = this.disableAddChildBtn + 1;
					} 
					else {
						return false;
					}							
				} else if(member === "WARD") { //sourav CR_3725
					//$scope.memberInfo.addChildDisable = true;
					//$scope.memberInfo.showChildDOB=true;
					$scope.memberInfo.wardReq = true;
					if($scope.memberInfo.coveredWardDetails.length <= 18){
						this.addWardFunc();					
						this.disableAddWardBtn = this.disableAddWardBtn + 1;
					}
					else if($scope.memberInfo.coveredWardDetails.length <= 19){
						$scope.memberInfo.addWardDisable=true;
						this.addWardFunc();				
						this.disableAddWardBtn = this.disableAddWardBtn + 1;					
					} 
					else if($scope.memberInfo.coveredWardDetails.length  === 20){
						$scope.memberInfo.addWardDisable=true;
						this.addWardFunc();
						this.disableAddWardBtn = this.disableAddWardBtn + 1;
					} else {
						return false;
					}							
				}
				else if(member === "PROPOSER") {
					$scope.memberInfo.addProposerDisable = true;
					$scope.memberInfo.showProposer = true;	
								
				} else if(member === "PARENT") {
					$scope.memberInfo.parentReq = true;
					if($scope.memberInfo.coveredParentDetails.length < 1){									
						this.addParentFunc();
						this.disableAddParentBtn = this.disableAddParentBtn + 1;
					} else if($scope.memberInfo.coveredParentDetails.length === 1){
						$scope.memberInfo.addParentDisable = true;
						this.addParentFunc();
						this.disableAddParentBtn = this.disableAddParentBtn + 1;
					} else {
						return false;
					}				
				}
			},
			addChildFunc: function(){
				$scope.memberInfo.coveredChildDetails
				.push({
					childDateOfBirth:'',
					sumInsuredAmountChild:'',
					cancerChildGender:'', //Sudip CR_3725
					childSmoker:'',
					childHabbitChewing:''
				});				
			},
			addWardFunc: function(){//sourav CR_3725
				$scope.memberInfo.coveredWardDetails
				.push({
					wardDateOfBirth:'',
					sumInsuredAmountWard:'',
					//dependentType:'',
					cancerWardGender: '', //Sudip CR_3725
					wardSmoker:'',
					wardHabbitChewing:''
				});				
			},
			addParentFunc: function(){
				$scope.memberInfo.coveredParentDetails
					.push({
						parentDateOfBirth:'',
						sumInsuredAmountParent:'',
						cancerParentsGender: '', //Sudip CR_3725
						parentSmoker:'',
						parentHabbitChewing:''
					});
			},
			/** Delete member from CP Product **/
			closeMember :function(member,index) {
				this.disableCountBtn = this.disableCountBtn - 1;
				if(member === 'SPOUSE'){
					//$scope.memberInfo.spouseIsAdded = false;
					$scope.memberInfo.showSpouse = false;
					$scope.memberInfo.spouseDateOfBirth = "";
					$scope.memberInfo.cancerSpouseGender = ""; //CR_3725
					$scope.memberInfo.spouseSmoker = "";//CR_3725
					$scope.memberInfo.spouseHabbitChewing = "";//CR_3725
					$scope.memberInfo.sumInsuredAmountSpouse = "";
					$scope.sumInsuredSpouseArray = [];
					//$scope.memberInfo.dateOfBirthSpouseErr = false;
				} else if(member === 'CHILD'){
					this.disableAddChildBtn = this.disableAddChildBtn - 1;
					$scope.memberInfo.showChildDOB = false;
					$scope.memberInfo.childDateOfBirth ="";
					$scope.memberInfo.childSmoker = ""; //CR_3725
					$scope.memberInfo.childHabbitChewing = "";//CR_3725
					//$scope.memberInfo.dateOfBirthChildErr = false;
					this.coveredChildDetails.splice(this.coveredChildDetails.indexOf(index), 1);
					if(this.disableAddChildBtn < 20){
						$scope.memberInfo.addChildDisable=false;
					} 
					if(this.disableAddChildBtn === 0){
						$scope.memberInfo.childReq = false;
					}
				} else if(member === 'WARD'){ //sourav CR_3725
					this.disableAddWardBtn = this.disableAddWardBtn - 1;
					$scope.memberInfo.showWardDOB = false;
					$scope.memberInfo.wardDateOfBirth ="";
					this.coveredWardDetails.splice(this.coveredWardDetails.indexOf(index), 1);
					if(this.disableAddWardBtn < 20){
						$scope.memberInfo.addWardDisable=false;
					} 
					if(this.disableAddWardBtn === 0){
						$scope.memberInfo.wardReq = false;
					}
				}
				else if(member === 'PROPOSER'){
					$scope.memberInfo.showProposer = false;
					$scope.memberInfo.addProposerDisable = false;
					$scope.memberInfo.proposerDateOfBirth = "";
					$scope.memberInfo.cancerProposerGender = ""; //CR_3725
					$scope.memberInfo.proposerSmoker = "";//CR_3725
					$scope.memberInfo.proposerHabbitChewing = "";//CR_3725
					$scope.memberInfo.sumInsuredAmountProposer = "";
					$scope.sumInsuredProposerArray = [];
					
				}  else if(member === 'PARENT'){
					this.disableAddParentBtn = this.disableAddParentBtn - 1;
					$scope.memberInfo.addParentDisable = false;
					$scope.memberInfo.parentDateOfBirth ="";
					$scope.memberInfo.cancerParentsGender = ""; //CR_3725
					this.coveredParentDetails.splice(this.coveredParentDetails.indexOf(index), 1);
					if(this.disableAddParentBtn < 2){
						$scope.memberInfo.addParentDisable=false;
					}
					if(this.disableAddParentBtn === 0){
						$scope.memberInfo.parentReq = false;
					}
				}
			},
			dateOfBirthFunc: function(member,index){
				enableProposerDOBCalComp = new Date(enableProposerDOBCalMin);
				if(member === "PROPOSER"){
					var dt1 = this.proposerDateOfBirth.split('/'),
					proposerbirthDateComp = dt1[1] + '/' + dt1[0] + '/' + dt1[2], //mm/dd/yyyy
					proposerbirthDateComp = new Date(proposerbirthDateComp);
					var ageDifMs = Date.now() - proposerbirthDateComp.getTime();
						var ageProposerYrs = new Date(ageDifMs); // miliseconds from epoch
						ageProposerYrs = Math.abs(ageProposerYrs.getUTCFullYear() - 1970);
					// sourav CR_3725
					console.log("proposer age in cancer "+ ageProposerYrs);
					console.log("proposer date of birth year in cancer "+ dt1[2]);

					$scope.isvalidDOB = false; //sudip CR_3725

					if(ageProposerYrs < 51) {
						$scope.sumInsuredProposerArray = $scope.sumInsuredDataArray[50];
						console.log("proposer insured array is "+$scope.sumInsuredProposerArray);
					}
					else if(ageProposerYrs > 50 && ageProposerYrs <56) {
						$scope.sumInsuredProposerArray = $scope.sumInsuredDataArray[55];
						console.log("proposer insured array is "+$scope.sumInsuredProposerArray);
					}
					else if(ageProposerYrs > 55 && ageProposerYrs < 61) {
						$scope.sumInsuredProposerArray = $scope.sumInsuredDataArray[60];
						console.log("proposer insured array is "+$scope.sumInsuredProposerArray);
					}
					else {
						$scope.sumInsuredProposerArray = $scope.sumInsuredDataArray[65];
						console.log("proposer insured array is "+$scope.sumInsuredProposerArray);
					}
					CommonServices.floaterObj.sumInsuredProposerArray = $scope.sumInsuredProposerArray;
					console.log("sumInsuredProposerArray while selection is done"+CommonServices.floaterObj.sumInsuredProposerArray);
					if(proposerbirthDateComp > enableProposerDOBCalComp){				
						$scope.memberInfo.proposerDateOfBirth = "";
						CommonServices.showAlert("Age of the Proposer should be between 18 years to 65 Years");
						$scope.isvalidDOB = true;
						
					} else {	//sourav CR_3725 not sure whehter this logic will be for Ward too				
						if($scope.memberInfo.coveredChildDetails.length > 0){
							var childDobCheck = false;
							
							for(var i=0; i< $scope.memberInfo.coveredChildDetails.length; i++){
								if(this.childParentsAgeCheck($scope.memberInfo.coveredChildDetails[i].childDateOfBirth, this.proposerDateOfBirth)){
									//	$scope.memberInfo.coveredChildDetails[i].childDateOfBirth = "";
									childDobCheck = true;
								}
							}		
							// if(childDobCheck){
							// 	CommonServices.showAlert("Children Age cannot be more than that of Parents");
							// }
						}else if($scope.memberInfo.coveredWardDetails.length > 0){
							var wardDobCheck = false;
							for(var i=0; i< $scope.memberInfo.coveredWardDetails.length; i++){
								if(this.childParentsAgeCheck($scope.memberInfo.coveredWardDetails[i].wardDateOfBirth, this.proposerDateOfBirth)){
									//$scope.memberInfo.coveredWardDetails[i].wardDateOfBirth = "";
									wardDobCheck = true;
								}
							}
							// if(wardDobCheck){
							// 	CommonServices.showAlert("Ward Age cannot be more than that of Parents");
							// }
						} 		
						else {
							//$scope.memberInfo.dateOfBirthProposerErr = false;
							var date = new Date(proposerbirthDateComp);
							var ageDifMs = Date.now() - date.getTime();
							var ageProposerYrs = new Date(ageDifMs); // miliseconds from epoch
							ageProposerYrs = Math.abs(ageProposerYrs.getUTCFullYear() - 1970);
							ageProposerYrs =ageProposerYrs.toString();
							CommonServices.floaterObj.ageProposerYrs=ageProposerYrs;	
						}
					}
				} else if(member === "SPOUSE"){
					var dt1 = this.spouseDateOfBirth.split('/'),
					spouseDateOfBirthComp = dt1[1] + '/' + dt1[0] + '/' + dt1[2], //mm/dd/yyyy
					spouseDateOfBirthComp = new Date(spouseDateOfBirthComp);

					// CR_3725 - Sudip start
					var ageDifMs = Date.now() - spouseDateOfBirthComp.getTime();
						var ageSpouseYrs = new Date(ageDifMs); // miliseconds from epoch
						ageSpouseYrs = Math.abs(ageSpouseYrs.getUTCFullYear() - 1970);

					console.log("SPOUSE age in cancer "+ ageSpouseYrs);
					console.log("SPOUSE date of birth year in cancer "+ dt1[2]);

					$scope.isvalidDOB = false; //sudip CR_3725

					if(ageSpouseYrs < 51) {
						$scope.sumInsuredSpouseArray = $scope.sumInsuredDataArray[50];
					}
					else if(ageSpouseYrs > 50 && ageSpouseYrs <56) {
						$scope.sumInsuredSpouseArray = $scope.sumInsuredDataArray[55];
					}
					else if(ageSpouseYrs > 55 && ageSpouseYrs < 61) {
						$scope.sumInsuredSpouseArray = $scope.sumInsuredDataArray[60];
					}
					else {
						$scope.sumInsuredSpouseArray = $scope.sumInsuredDataArray[65];
					}
					CommonServices.floaterObj.sumInsuredSpouseArray = $scope.sumInsuredSpouseArray;
					console.log("sumInsuredProposerArray while selection is done"+CommonServices.floaterObj.sumInsuredSpouseArray);
					// CR_3725 - Sudip End


					if(spouseDateOfBirthComp > enableProposerDOBCalComp){
						$scope.memberInfo.spouseDateOfBirth = "";
						CommonServices.showAlert("Age of the Spouse should be between 18 years to 65 Years");
						$scope.isvalidDOB = true;
					} else{ //sourav CR_3725 not sure whehter this logic will be for Ward too
						if($scope.memberInfo.coveredChildDetails.length > 0){
							var childDobCheck = false;
							
							for(var i=0; i< $scope.memberInfo.coveredChildDetails.length; i++){
								if(this.childParentsAgeCheck($scope.memberInfo.coveredChildDetails[i].childDateOfBirth, this.spouseDateOfBirth)){
									//	$scope.memberInfo.coveredChildDetails[i].childDateOfBirth = "";
									childDobCheck = true;
								}
							}
							
							// if(childDobCheck){
							// 	CommonServices.showAlert("Children Age cannot be more than that of Parents");
							// }
						} else if($scope.memberInfo.coveredWardDetails.length > 0){
							var wardDobCheck = false;
							for(var i=0; i< $scope.memberInfo.coveredWardDetails.length; i++){
								if(this.childParentsAgeCheck($scope.memberInfo.coveredWardDetails[i].wardDateOfBirth, this.spouseDateOfBirth)){
									//$scope.memberInfo.coveredWardDetails[i].childDateOfBirth = "";
									childDobCheck = true;
								}
							}
							// if(wardDobCheck){
							// 	CommonServices.showAlert("Ward Age cannot be more than that of Parents");
							// }
						}
						else{
							var date = new Date(spouseDateOfBirthComp);
							var ageDifMs = Date.now() - date.getTime();
							var ageSpouseYrs = new Date(ageDifMs); // miliseconds from epoch
							ageSpouseYrs = Math.abs(ageSpouseYrs.getUTCFullYear() - 1970);
							ageSpouseYrs =ageSpouseYrs.toString();
							CommonServices.floaterObj.ageSpouseYrs=ageSpouseYrs;					
						}
					}				
				} else if(member === "PARENT"){
					for(var i =0; i< $scope.memberInfo.coveredParentDetails.length; i++){   
						if($scope.memberInfo.coveredParentDetails[index].memberInfo !== undefined){ //Sudip CR-3725
							dt1 = $scope.memberInfo.coveredParentDetails[index].memberInfo.parentDateOfBirth.split('/'),
							parentDateOfBirthComp = dt1[1] + '/' + dt1[0] + '/' + dt1[2], //mm/dd/yyyy
							parentDateOfBirthComp = new Date(parentDateOfBirthComp);
						
						// CR_3725 - Sudip start
						var ageDifMs = Date.now() - parentDateOfBirthComp.getTime();
						var ageParentYrs = new Date(ageDifMs); // miliseconds from epoch
						ageParentYrs = Math.abs(ageParentYrs.getUTCFullYear() - 1970);
						
					console.log("Parent age in cancer "+ ageParentYrs);
					console.log("Parent date of birth year in cancer "+ dt1[2]);
					if(ageParentYrs < 51) {
						$scope.sumInsuredParentArray[index] = $scope.sumInsuredDataArray[50];
						console.log("parent insured array is " + $scope.sumInsuredParentArray[index]);
					}
					else if(ageParentYrs > 50 && ageParentYrs <56) {
						$scope.sumInsuredParentArray[index] = $scope.sumInsuredDataArray[55];
					}
					else if(ageParentYrs > 55 && ageParentYrs < 61) {
						$scope.sumInsuredParentArray[index] = $scope.sumInsuredDataArray[60];
					}
					else {
						$scope.sumInsuredParentArray[index] = $scope.sumInsuredDataArray[65];
					}
					//30.09.2019
					//console.log("$scope.sumInsuredParentArray[index]"+$scope.sumInsuredParentArray[index]);
					//CommonServices.floaterObj.sumInsuredParentArray[index] = $scope.sumInsuredParentArray[index];
					//console.log("CommonServices.floaterObj.sumInsuredParentArray[index]"+CommonServices.floaterObj.sumInsuredParentArray[index]);
					// CR_3725 - Sudip End

							if(parentDateOfBirthComp > enableProposerDOBCalComp){
								$scope.memberInfo.coveredParentDetails[index].memberInfo.parentDateOfBirth = "";
								CommonServices.showAlert("Age of the Insured should be between 18 years to 65 Years");
								$scope.isvalidDOB = true;
							}
						}
						break; //Sudip CR-3725				
					}
					CommonServices.floaterObj.coveredParentDetails = $scope.memberInfo.coveredParentDetails;				
				}
				if(CommonServices.editQuoteFlag === true){				
					console.log(CommonServices.floaterObj);
					// for(var i=0; i < CommonServices.floaterObj.addedMemberDetails.length ; i++){
					// 	if(CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "SELF"){
					// 		if(ageProposerYrs !== undefined && ageProposerYrs !== ""){
					// 			CommonServices.floaterObj.addedMemberDetails[i].riskDetails.ageInYrs = ageProposerYrs;
					// 			CommonServices.floaterObj.addedMemberDetails[i].riskDetails.dateOfBirth = $scope.memberInfo.proposerDateOfBirth;
					// 		}						
					// 	}
					// 	else if(CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "SPOUSE"){
					// 		if(ageSpouseYrs !== undefined && ageSpouseYrs !== ""){
					// 			CommonServices.floaterObj.addedMemberDetails[i].riskDetails.ageInYrs = ageSpouseYrs;
					// 			CommonServices.floaterObj.addedMemberDetails[i].riskDetails.dateOfBirth = $scope.memberInfo.spouseDateOfBirth;
					// 		}
					// 	}					
					// }
				}				
			},

			validateDOB: function(dateOfBirthId){
				console.log("parent date of birth id"+dateOfBirthId);
				console.log("parent date of birth"+dateOfBirthId.value);
				if(dateOfBirthId.value !== undefined){
					return false;
				}
				else{
					return true;
				}

			},
			 selectedSumInsured:function(insuredValue){ /* commented out to removed proposers sum alert*/
				console.log("suminsured value is "+insuredValue);
				// if(insuredValue == maxSumInsuredValue){
				// 	CommonServices.showAlert("Please note that up to 25 lacs sum insured can be issued through online channel. However you can check premium for 50 lacs sum insured and connect with New India Assurance Branch for policy issuance");
				// }	
	 		},

			childParentsAgeCheck:function(childAge, parentAge){
				var arr = childAge.split('/'); 
				childAge = arr[1] + '/' + arr[0] + '/' + arr[2]; //mm/dd/yyyy 
				childAge = new Date(childAge); 
				var dt1 = parentAge.split('/'),
				parentAge = dt1[1] + '/' + dt1[0] + '/' + dt1[2], //mm/dd/yyyy
				parentAge = new Date(parentAge);
				if(childAge < parentAge){								
					return true;				
				} else {
					return false;				
				}			
			},
			dependentTypeChanged:function(member,index){ // CR_3725 age logic based on child/ward dob present here
				if(member === "CHILD"){
					var AgeInMonths = new Date(new Date().setMonth(mynewdateFrom.getMonth() -3));     
					console.log("AgeInMonths"+AgeInMonths);   
					console.log("childAgeEnableFrom"+childAgeEnableFrom);
					for(var i =0; i< $scope.memberInfo.coveredChildDetails.length; i++){
						console.log("$scope.memberInfo.coveredChildDetails.length"+$scope.memberInfo.coveredChildDetails.length);
						// if($scope.memberInfo.coveredChildDetails[i].memberInfo !== undefined){
							// console.log("$scope.memberInfo.coveredChildDetails[i].memberInfo"+$scope.memberInfo.coveredChildDetails[i].memberInfo);

							if($scope.memberInfo.coveredChildDetails[index].childDateOfBirth !== undefined){
								var childAge = $scope.memberInfo.coveredChildDetails[index].childDateOfBirth;
								var arr = childAge.split('/'); 
								childAge = arr[1] + '/' + arr[0] + '/' + arr[2]; //mm/dd/yyyy 
								childAge = new Date(childAge);
								console.log("childAge..."+childAge);

							//	$scope.isvalidDOB = false;

							
							var ageDifMs = Date.now() - childAge.getTime();
							var agechildYrs = new Date(ageDifMs); // miliseconds from epoch
							agechildYrs = Math.abs(agechildYrs.getUTCFullYear() - 1970);
							console.log("ageChildYrs age in cancer "+ ageWardYrs);

							if(childAge > AgeInMonths|| childAge < childAgeEnableFrom){
								$scope.memberInfo.coveredChildDetails[index].childDateOfBirth = "";
								CommonServices.showAlert("Age of the child should be between 3 Months to 65 Years");
							//	$scope.isvalidDOB = true;
							}
							
							else if(agechildYrs < 51) {
								$scope.sumInsuredChildArray[index] = $scope.sumInsuredDataArray[50];
								console.log("parent insured array is " + $scope.sumInsuredChildArray[index]);
							}
							else if(agechildYrs > 50 && agechildYrs <56) {
								$scope.sumInsuredChildArray[index] = $scope.sumInsuredDataArray[55];
							}
							else if(agechildYrs > 55 && agechildYrs < 61) {
								$scope.sumInsuredChildArray[index] = $scope.sumInsuredDataArray[60];
							}
							else {
								$scope.sumInsuredChildArray[index] = $scope.sumInsuredDataArray[65];
							}
	
							}					
							// if(this.proposerDateOfBirth !== undefined && this.childParentsAgeCheck($scope.memberInfo.coveredChildDetails[index].childDateOfBirth, this.proposerDateOfBirth)){ //sudip CR_3725 fixed child alert issue 
							// 	$scope.memberInfo.coveredChildDetails[index].childDateOfBirth = "";
							// 	CommonServices.showAlert("Children Age cannot be more than that of Parents");
							// } else if(this.spouseDateOfBirth !== undefined && this.childParentsAgeCheck($scope.memberInfo.coveredChildDetails[index].childDateOfBirth, this.spouseDateOfBirth)){
							// 	$scope.memberInfo.coveredChildDetails[index].childDateOfBirth = "";
							// 	CommonServices.showAlert("Children Age cannot be more than that of Parents");
							// } else {
							// 	console.log("childAgeEnableFrom"+childAgeEnableFrom);
							// }					
						// } 
						break;                  
					}
				}
				else {
					var AgeInMonths = new Date(new Date().setMonth(mynewdateFrom.getMonth() -3));        
					for(var i =0; i< $scope.memberInfo.coveredWardDetails.length; i++){
						// if($scope.memberInfo.coveredWardDetails[i].memberInfo !== undefined){
							if($scope.memberInfo.coveredWardDetails[index].wardDateOfBirth !== undefined){
								var wardAge = $scope.memberInfo.coveredWardDetails[index].wardDateOfBirth;
								var arr = wardAge.split('/'); 
								wardAge = arr[1] + '/' + arr[0] + '/' + arr[2]; //mm/dd/yyyy 
								wardAge = new Date(wardAge); 
							//	$scope.isvalidDOB = false; 
							var ageDifMs = Date.now() - wardAge.getTime();
							var ageWardYrs = new Date(ageDifMs); // miliseconds from epoch
							ageWardYrs = Math.abs(ageWardYrs.getUTCFullYear() - 1970);
							console.log("ageWardYrs age in cancer "+ ageWardYrs);

							if(wardAge > AgeInMonths|| wardAge < wardAgeEnableFrom){
								$scope.memberInfo.coveredWardDetails[index].wardDateOfBirth = "";
								CommonServices.showAlert("Age of the ward should be between 3 Months to 65 Years");
							//	$scope.isvalidDOB = true;
							}
							
							else if(ageWardYrs < 51) {
								$scope.sumInsuredWardArray[index] = $scope.sumInsuredDataArray[50];
								console.log("parent insured array is " + $scope.sumInsuredWardArray[index]);
							}
							else if(ageWardYrs > 50 && ageWardYrs <56) {
								$scope.sumInsuredWardArray[index] = $scope.sumInsuredDataArray[55];
							}
							else if(ageWardYrs > 55 && ageWardYrs < 61) {
								$scope.sumInsuredWardArray[index] = $scope.sumInsuredDataArray[60];
							}
							else {
								$scope.sumInsuredWardArray[index] = $scope.sumInsuredDataArray[65];
							}
								// CR_3725 - Sudip start

							}					
							// if(this.proposerDateOfBirth !== undefined && this.childParentsAgeCheck($scope.memberInfo.coveredWardDetails[index].wardDateOfBirth, this.proposerDateOfBirth)){ // Sudip CR_3725 alert issue fixed for ward alert
							// 	$scope.memberInfo.coveredWardDetails[index].wardDateOfBirth = "";
							// 	CommonServices.showAlert("Ward Age cannot be more than that of Parents");
							// } else if(this.spouseDateOfBirth !== undefined && this.childParentsAgeCheck($scope.memberInfo.coveredWardDetails[index].wardDateOfBirth, this.spouseDateOfBirth)){
							// 	$scope.memberInfo.coveredWardDetails[index].wardDateOfBirth = "";
							// 	CommonServices.showAlert("Ward Age cannot be more than that of Parents");
							// } else { 
							// 	console.log("In else");
							// }
							break;				
						// }                   
					}
					//CommonServices.floaterObj.coveredwardDetails = $scope.memberInfo.coveredWardDetails;
				}

			//	CommonServices.floaterObj.coveredChildDetails = $scope.memberInfo.coveredChildDetails;
			},
			calcPremium: function(){
			
				this.riskPremiumDetails =[];
				let additionalMemberArr = [];
				var totalSumInsured = "0";
				if (CommonServices.editQuoteFlag !== true) {
					CommonServices.floaterObj.addedMemberDetails = [];
				}
				if($scope.memberInfo.showProposer === false && $scope.memberInfo.showSpouse === false && 
				$scope.memberInfo.disableAddChildBtn === 0 && $scope.memberInfo.disableAddWardBtn === 0 && 
				$scope.memberInfo.coveredParentDetails.length === 0){ //sourav ward added but not sure
					CommonServices.showAlert("Atleast one member is required to take the policy");
				} else {
					if($scope.memberInfo.coveredChildDetails !== "undefined"){
							CommonServices.floaterObj.coveredChildDetails = $scope.memberInfo.coveredChildDetails;
					} else {
						CommonServices.floaterObj.coveredChildDetails = 0;
					}

					//sourav CR_3725
					if($scope.memberInfo.coveredWardDetails !== "undefined"){
							CommonServices.floaterObj.coveredWardDetails = $scope.memberInfo.coveredWardDetails;
					} else {
						CommonServices.floaterObj.coveredWardDetails = 0;
					}

					console.log(CommonServices.floaterObj);
					if($scope.memberInfo.showProposer === true){
						var dt1 = this.proposerDateOfBirth.split('/'),
						proposerbirthDateComp = dt1[1] + '/' + dt1[0] + '/' + dt1[2], //mm/dd/yyyy
						proposerbirthDateComp = new Date(proposerbirthDateComp);
						var ageDifMs = Date.now() - proposerbirthDateComp.getTime();
							var ageProposerYrs = new Date(ageDifMs); // miliseconds from epoch
							ageProposerYrs = Math.abs(ageProposerYrs.getUTCFullYear() - 1970);
							CommonServices.floaterObj.ageProposerYrs = ageProposerYrs;
						var proposerGender = $scope.memberInfo.cancerProposerGender;//'';
						// if ($scope.memberInfo.cancerProposerGender == 'M'){
						// 	proposerGender = 'M';
						// }
						// else if ($scope.memberInfo.cancerProposerGender == 'F'){
						// 	proposerGender = 'F';
						// }
						// else{
						// 	proposerGender = 'T';
						// }

						$scope.proposerRiskDetails={
							// "riskSumInsured": $scope.memberInfo.sumInsuredAmountProposer,
							"riskDetails": {
							"relationWithPolicyHolder": "Self",
							"dateOfBirth": $scope.memberInfo.proposerDateOfBirth,
							"ageInYrs": ageProposerYrs,//CommonServices.floaterObj.ageProposerYrs,
							"sex" :proposerGender, //CR_3725 - sudip
							"areUaSmoker" : $scope.memberInfo.proposerSmoker,//CR_3725 - sudip
							"areUchewingTobacco" : $scope.memberInfo.proposerHabbitChewing, //CR_3725 - sudip
							"sumInsured": $scope.memberInfo.sumInsuredAmountProposer
							}
						};
						//console.log("proposerRiskDetails..." +proposerRiskDetails);
						totalSumInsured = eval(totalSumInsured + "+" + $scope.memberInfo.sumInsuredAmountProposer);

						this.riskPremiumDetails.push(angular.copy($scope.proposerRiskDetails));
						if(CommonServices.editQuoteFlag){
							Object.assign($scope.proposerRiskDetails.riskDetails,{edit: true},$scope.memberInfo.coveredProposerDetails[0].riskDetails);
						}
						
						additionalMemberArr.push($scope.proposerRiskDetails);
					}
					CommonServices.floaterObj.addProposerDisable = $scope.memberInfo.showProposer;
					if($scope.memberInfo.showSpouse === true){
						var dt1 = this.spouseDateOfBirth.split('/'),
						spouseDateOfBirthComp = dt1[1] + '/' + dt1[0] + '/' + dt1[2], //mm/dd/yyyy
						spouseDateOfBirthComp = new Date(spouseDateOfBirthComp);
		
						// CR_3725 - Sudip start
						var ageDifMs = Date.now() - spouseDateOfBirthComp.getTime();
							var ageSpouseYrs = new Date(ageDifMs); // miliseconds from epoch
							ageSpouseYrs = Math.abs(ageSpouseYrs.getUTCFullYear() - 1970);
							CommonServices.floaterObj.ageSpouseYrs = ageSpouseYrs;
							var spouseGender = $scope.memberInfo.cancerSpouseGender;//'';
						// if ($scope.memberInfo.cancerSpouseGender == 'M'){
						// 	spouseGender = 'M';
						// }
						// else if ($scope.memberInfo.cancerSpouseGender == 'F'){
						// 	spouseGender = 'F';
						// }
						// else{
						// 	spouseGender = 'T';
						// }
						$scope.spouseRiskDetails= {
							// "riskSumInsured": $scope.memberInfo.sumInsuredAmountSpouse,
							"riskDetails": {
							"relationWithPolicyHolder": "Spouse",
							"dateOfBirth": $scope.memberInfo.spouseDateOfBirth,
							"ageInYrs": ageSpouseYrs,//CommonServices.floaterObj.ageSpouseYrs,
							"sex" : spouseGender, //CR_3725 - sudip
							"areUaSmoker" : $scope.memberInfo.spouseSmoker,
							"areUchewingTobacco" : $scope.memberInfo.spouseHabbitChewing, //CR_3725 - sudip
							"sumInsured": $scope.memberInfo.sumInsuredAmountSpouse
							}
						};
						totalSumInsured = eval(totalSumInsured + "+" + $scope.memberInfo.sumInsuredAmountSpouse);
						
						this.riskPremiumDetails.push(angular.copy($scope.spouseRiskDetails));
						if(CommonServices.editQuoteFlag){
							Object.assign($scope.spouseRiskDetails.riskDetails,{edit: true},$scope.memberInfo.coveredSpouseDetails[0].riskDetails);
						}
						additionalMemberArr.push($scope.spouseRiskDetails);
					}
					CommonServices.floaterObj.addSpouseDisable = $scope.memberInfo.showSpouse;
					if($scope.memberInfo.disableAddChildBtn > 0){
						for(var i =0; i< $scope.memberInfo.coveredChildDetails.length; i++){
							var childAgeCal = $scope.memberInfo.coveredChildDetails[i].childDateOfBirth;
							var childGender = $scope.memberInfo.coveredChildDetails[i].memberInfo.cancerChildGender; //Sudip CR_3725

							var Arr = childAgeCal.split('/');
							childAgeCal = Arr[2] + '/' + Arr[1] + '/' + Arr[0]; //mm/dd/yyyy
							var date = new Date(childAgeCal);
							var ageDifMs = Date.now() - date.getTime();
							var ageDinYrs = new Date(ageDifMs); // miliseconds from epoch
							ageDinYrs = Math.abs(ageDinYrs.getUTCFullYear() - 1970);
							ageDinYrs =ageDinYrs.toString();
							
							$scope.childRiskDetails = {
							//	"riskSumInsured": $scope.memberInfo.coveredChildDetails[i].memberInfo.sumInsuredAmountChild,
								"riskDetails": {
									"relationWithPolicyHolder": "Children",
									"dateOfBirth": $scope.memberInfo.coveredChildDetails[i].childDateOfBirth,
									"ageInYrs": ageDinYrs,
									"sex": childGender, //Sudip CR_3725
									"areUaSmoker" : $scope.memberInfo.coveredChildDetails[i].memberInfo.childSmoker,//CR_3725 - sudip
									"areUchewingTobacco" : $scope.memberInfo.coveredChildDetails[i].memberInfo.childHabbitChewing, //CR_3725 - sudip
									"sumInsured": $scope.memberInfo.coveredChildDetails[i].memberInfo.sumInsuredAmountChild
								}
							};
							totalSumInsured = eval(totalSumInsured + "+" + $scope.memberInfo.coveredChildDetails[i].memberInfo.sumInsuredAmountChild);
							this.riskPremiumDetails.push(angular.copy($scope.childRiskDetails));
							if(CommonServices.editQuoteFlag){
								Object.assign($scope.childRiskDetails.riskDetails,{edit: $scope.memberInfo.coveredChildDetails[i].edit},$scope.memberInfo.coveredChildDetails[i].riskDetails);
							}
							additionalMemberArr.push($scope.childRiskDetails);
						}					
					}
					//sourav CR_3725
					if($scope.memberInfo.disableAddWardBtn > 0){
						for(var i =0; i< $scope.memberInfo.coveredWardDetails.length; i++){
							var wardAgeCal = $scope.memberInfo.coveredWardDetails[i].wardDateOfBirth;
							var wardGender = $scope.memberInfo.coveredWardDetails[i].memberInfo.cancerWardGender; //Sudip CR_3725
							var Arr = wardAgeCal.split('/');
							wardAgeCal = Arr[2] + '/' + Arr[1] + '/' + Arr[0]; //mm/dd/yyyy
							var date = new Date(wardAgeCal);
							var ageDifMs = Date.now() - date.getTime();
							var ageDinYrs = new Date(ageDifMs); // miliseconds from epoch
							ageDinYrs = Math.abs(ageDinYrs.getUTCFullYear() - 1970);
							ageDinYrs =ageDinYrs.toString();
							
							$scope.wardRiskDetails = {
							//	"riskSumInsured": $scope.memberInfo.coveredWardDetails[i].memberInfo.sumInsuredAmountChild,
								"riskDetails": {
									"relationWithPolicyHolder": "Ward",
									"dateOfBirth": $scope.memberInfo.coveredWardDetails[i].wardDateOfBirth,
									"ageInYrs": ageDinYrs,
									"sex": wardGender, //Sudip CR_3725
									"areUaSmoker" : $scope.memberInfo.coveredWardDetails[i].memberInfo.wardSmoker,//CR_3725 - sudip
									"areUchewingTobacco" : $scope.memberInfo.coveredWardDetails[i].memberInfo.wardHabbitChewing, //CR_3725 - sudip
									"sumInsured": $scope.memberInfo.coveredWardDetails[i].memberInfo.sumInsuredAmountWard
								}
							};
							totalSumInsured = eval(totalSumInsured + "+" + $scope.memberInfo.coveredWardDetails[i].memberInfo.sumInsuredAmountWard);

							this.riskPremiumDetails.push(angular.copy($scope.wardRiskDetails));
							if(CommonServices.editQuoteFlag){
								Object.assign($scope.wardRiskDetails.riskDetails,{edit: true},$scope.memberInfo.coveredWardDetails[i].riskDetails);
							}
							additionalMemberArr.push($scope.wardRiskDetails);
						}					
					}
					CommonServices.floaterObj.addChildDisable = $scope.memberInfo.addChildDisable;
					CommonServices.floaterObj.coveredChildDetails = $scope.memberInfo.coveredChildDetails;
					CommonServices.floaterObj.coveredWardDetails = $scope.memberInfo.coveredWardDetails;//sourav CR_3725
					CommonServices.floaterObj.countOfChild = $scope.memberInfo.disableAddChildBtn;
					CommonServices.floaterObj.countOfWard = $scope.memberInfo.disableAddWardBtn;//sourav CR_3725
					if($scope.memberInfo.coveredParentDetails.length > 0){
						for(var i =0; i< $scope.memberInfo.coveredParentDetails.length; i++) {
							var parentAgeCal = $scope.memberInfo.coveredParentDetails[i].memberInfo.parentDateOfBirth;
							var parentGender = $scope.memberInfo.coveredParentDetails[i].memberInfo.cancerParentsGender;//sudip CR_3725
							var Arr = parentAgeCal.split('/');
							parentAgeCal = Arr[2] + '/' + Arr[1] + '/' + Arr[0]; //mm/dd/yyyy
							var date = new Date(parentAgeCal);
							var ageDifMs = Date.now() - date.getTime();
							var ageDinYrs = new Date(ageDifMs); // miliseconds from epoch
							ageDinYrs = Math.abs(ageDinYrs.getUTCFullYear() - 1970);
							ageDinYrs =ageDinYrs.toString();
							
							$scope.parentRiskDetails = {
								// "riskSumInsured": $scope.memberInfo.coveredParentDetails[i].memberInfo.sumInsuredAmountParent,
								"riskDetails": {
								"relationWithPolicyHolder": "Parents",
								"dateOfBirth": $scope.memberInfo.coveredParentDetails[i].memberInfo.parentDateOfBirth,
								"ageInYrs": ageDinYrs,
								"sex" : parentGender, //sudip CR_3725
								"areUaSmoker" : $scope.memberInfo.coveredParentDetails[i].memberInfo.parentSmoker,//CR_3725 - sudip
								"areUchewingTobacco" : $scope.memberInfo.coveredParentDetails[i].memberInfo.parentHabbitChewing, //CR_3725 - sudip
								"sumInsured": $scope.memberInfo.coveredParentDetails[i].memberInfo.sumInsuredAmountParent
								}
							};
							totalSumInsured = eval(totalSumInsured + "+" + $scope.memberInfo.coveredParentDetails[i].memberInfo.sumInsuredAmountParent);
						//	totalSumInsured = totalSumInsured + $scope.memberInfo.coveredParentDetails[i].memberInfo.sumInsuredAmountParent;

						this.riskPremiumDetails.push(angular.copy($scope.parentRiskDetails));
						if(CommonServices.editQuoteFlag){
							Object.assign($scope.parentRiskDetails.riskDetails,{edit: true},$scope.memberInfo.coveredParentDetails[i].riskDetails);
						}
						additionalMemberArr.push($scope.parentRiskDetails);
						}
					}
					CommonServices.floaterObj.coveredProposerDetails = $scope.memberInfo.coveredProposerDetails;
					CommonServices.floaterObj.coveredSpouseDetails = $scope.memberInfo.coveredSpouseDetails;
					CommonServices.floaterObj.coveredParentDetails = $scope.memberInfo.coveredParentDetails;
					CommonServices.floaterObj.addParentDisable = $scope.memberInfo.addParentDisable;
					CommonServices.floaterObj.numberOfMembers = this.disableCountBtn;
					// CommonServices.floaterObj.addedMemberDetails = this.riskPremiumDetails;
					CommonServices.floaterObj.addedMemberDetails = [...additionalMemberArr];
					console.log(CommonServices.floaterObj.addedMemberDetails);
					var riskPremiumDetailsData = {
						"quote": {
							"risks": this.riskPremiumDetails,
							"productCode": 'CJ',
							"policyStartDate": policyStartDate,
							"policyExpiryDate": policyEndDate,
							"mobileNo": null,
							"emailId": null,
							"progressLevel": null,
							"typeOfCover": null
							// "optionalCoverINoProportionateDeduction":"NO",
							// "optionalCoverIIIRevisioninCataractLimit":"NO",
							// "optionalCoverIVVoluntaryCopay":"NO" 
						},
						"userProfile": {
							"userId": CommonServices.getCommonData("userId"),
							"loggedInRole": "SUPERUSER"
						}
					};
					//50 lacs can't be assured through mobile app logic
					// for(var i =0; i< $scope.memberInfo.coveredChildDetails.length; i++){
					// 	if( $scope.memberInfo.coveredChildDetails[i].memberInfo.sumInsuredAmountChild == maxSumInsuredValue){
					// 		CommonServices.checkMaxInsuredAmount = true;
					// 	}
					// }
					// for(var i =0; i< $scope.memberInfo.coveredWardDetails.length; i++) {
					// 	if($scope.memberInfo.coveredWardDetails[i].memberInfo.sumInsuredAmountWard == maxSumInsuredValue){
					// 		CommonServices.checkMaxInsuredAmount = true;
					// 	}

					// }

					// for(var i =0; i< $scope.memberInfo.coveredParentDetails.length; i++) {
					// 	if($scope.memberInfo.coveredParentDetails[i].memberInfo.sumInsuredAmountParent == maxSumInsuredValue){
					// 		CommonServices.checkMaxInsuredAmount = true;
					// 	}

					// }

					// if($scope.memberInfo.sumInsuredAmountProposer == maxSumInsuredValue || $scope.memberInfo.sumInsuredAmountSpouse == maxSumInsuredValue){
					// 	CommonServices.checkMaxInsuredAmount = true;
					// }
					// if(CommonServices.checkMaxInsuredAmount){
					// 	CommonServices.showAlert("Please note that up to 25 lacs sum insured can be issued through online channel. However you can check premium for 50 lacs sum insured and connect with New India Assurance Branch for policy issuance");

					// }

					var premCalcResponse = RestServices.postService(RestServices.urlPathsNewPortal.topUpCalcPremium, riskPremiumDetailsData);
					premCalcResponse.then(
					function(response) { // success 				
						CommonServices.showLoading(false);	
						if(response.data !== undefined && response.data !== ""){
							if(response.data.hasOwnProperty('errorMessage')){
								CommonServices.showAlert(response.data.errorMessage);	
							}else{
							//	CommonServices.floaterObj.premiumCalResponse = response.data.quote;	
								CommonServices.floaterObj.quoteNumber = response.data.quote.quoteNumber;
								CommonServices.floaterObj.premiumDetails = response.data.quote.premiumDetails;
								CommonServices.floaterObj.premiumDetails.sumInsured = totalSumInsured;

								$state.go("floaterBasicPremium");
							}
						} else {
							//CommonServices.showAlert("Something went wrong. Please try after some time"); //sourav CR_3725 commentedout to handle service change related error
							console.log("$scope.memberInfo.sumInsuredAmountProposer"+$scope.memberInfo.sumInsuredAmountProposer);
							// return false; //need to add once service response is proper
							$state.go("floaterBasicPremium");//need to remove once service response is proper
						}	                  
					},
					function(error) { // failure
						CommonServices.showLoading(false);
						RestServices.handleWebServiceError(error);
					});
				}
			},		
			initModel: function(){
				//form Prepopulation starts when coming from Edit Quote 
				console.log($rootScope.productName);
				if(CommonServices.editQuoteFlag){
					let childCount=0, wardCount=0, parentCount=0;
					this.coveredSpouseDetails=[{}];
					this.coveredProposerDetails=[{}];
					//this.disableCountBtn = CommonServices.cancerGuardObj.risks.length;
					for(var i=0; i< CommonServices.floaterObj.risks.length; i++){
						if(CommonServices.floaterObj.risks[i].riskDetails.relationWithPolicyHolder.toUpperCase()==="SPOUSE"){

							var ageProposerYrs = CommonServices.floaterObj.risks[i].riskDetails.ageInYrs;
							if(ageProposerYrs < 51) {
								$scope.sumInsuredSpouseArray = $scope.sumInsuredDataArray[50];
							}
							else if(ageProposerYrs > 50 && ageProposerYrs <56) {
								$scope.sumInsuredSpouseArray = $scope.sumInsuredDataArray[55];
							}
							else if(ageProposerYrs > 55 && ageProposerYrs < 61) {
								$scope.sumInsuredSpouseArray = $scope.sumInsuredDataArray[60];
							}
							else {
								$scope.sumInsuredSpouseArray = $scope.sumInsuredDataArray[65];
							}

							this.addMember("SPOUSE");
							this.spouseDateOfBirth = CommonServices.floaterObj.risks[i].riskDetails.dateOfBirth;
							this.sumInsuredAmountSpouse = CommonServices.floaterObj.risks[i].riskDetails.sumInsured;
							if(CommonServices.floaterObj.risks[i].riskDetails.sex == 'M'){
								this.cancerSpouseGender = "M";
							}
							else if(CommonServices.floaterObj.risks[i].riskDetails.sex == 'F'){
								this.cancerSpouseGender = "F";
							}
							// else {
							// 	this.cancerSpouseGender = "Third Gender";
							// }
							this.spouseSmoker = CommonServices.floaterObj.risks[i].riskDetails.areUaSmoker;
							this.spouseHabbitChewing = CommonServices.floaterObj.risks[i].riskDetails.areUchewingTobacco;
							
							this.coveredSpouseDetails[0]['riskDetails'] = CommonServices.floaterObj.risks[i].riskDetails;
						}
						else if(CommonServices.floaterObj.risks[i].riskDetails.relationWithPolicyHolder.toUpperCase()==="CHILDREN"){
							
							var ageYrs = CommonServices.floaterObj.risks[i].riskDetails.ageInYrs;
							if(ageYrs < 51) {
								$scope.sumInsuredChildArray[childCount] = $scope.sumInsuredDataArray[50];
							}
							else if(ageYrs > 50 && ageYrs <56) {
								$scope.sumInsuredChildArray[childCount] = $scope.sumInsuredDataArray[55];
							}
							else if(ageYrs > 55 && ageYrs < 61) {
								$scope.sumInsuredChildArray[childCount] = $scope.sumInsuredDataArray[60];
							}
							else {
								$scope.sumInsuredChildArray[childCount] = $scope.sumInsuredDataArray[65];
							}

							this.addMember("CHILD");

							this.coveredChildDetails[childCount].memberInfo = {};
							this.coveredChildDetails[childCount].childDateOfBirth = CommonServices.floaterObj.risks[i].riskDetails.dateOfBirth;
							this.coveredChildDetails[childCount].memberInfo.sumInsuredAmountChild = CommonServices.floaterObj.risks[i].riskDetails.sumInsured;
							if(CommonServices.floaterObj.risks[i].riskDetails.sex == 'M'){
								this.coveredChildDetails[childCount].memberInfo.cancerChildGender = "M";
							}
							else if(CommonServices.floaterObj.risks[i].riskDetails.sex == 'F'){
								this.coveredChildDetails[childCount].memberInfo.cancerChildGender = "F";
							}
							// else {
							// 	this.coveredChildDetails[childCount].memberInfo.cancerChildGender = "Third Gender";
							// }
							this.coveredChildDetails[childCount].memberInfo.childSmoker = CommonServices.floaterObj.risks[i].riskDetails.areUaSmoker;
							this.coveredChildDetails[childCount].memberInfo.childHabbitChewing = CommonServices.floaterObj.risks[i].riskDetails.areUchewingTobacco;
							this.coveredChildDetails[childCount]['edit'] = true;
							this.coveredChildDetails[childCount]['riskDetails'] = CommonServices.floaterObj.risks[i].riskDetails;
							childCount++;
						}
						else if(CommonServices.floaterObj.risks[i].riskDetails.relationWithPolicyHolder.toUpperCase()==="PARENTS"){
							var ageYrs = CommonServices.floaterObj.risks[i].riskDetails.ageInYrs;
							if(ageYrs < 51) {
								$scope.sumInsuredParentArray[parentCount] = $scope.sumInsuredDataArray[50];
							}
							else if(ageYrs > 50 && ageYrs <56) {
								$scope.sumInsuredParentArray[parentCount] = $scope.sumInsuredDataArray[55];
							}
							else if(ageYrs > 55 && ageYrs < 61) {
								$scope.sumInsuredParentArray[parentCount] = $scope.sumInsuredDataArray[60];
							}
							else {
								$scope.sumInsuredParentArray[parentCount] = $scope.sumInsuredDataArray[65];
							}

							this.addMember("PARENT");

							this.coveredParentDetails[parentCount].memberInfo = {};
							this.coveredParentDetails[parentCount].memberInfo.parentDateOfBirth = CommonServices.floaterObj.risks[i].riskDetails.dateOfBirth;
							this.coveredParentDetails[parentCount].memberInfo.sumInsuredAmountParent = CommonServices.floaterObj.risks[i].riskDetails.sumInsured;
							if(CommonServices.floaterObj.risks[i].riskDetails.sex == 'M'){
								this.coveredParentDetails[parentCount].memberInfo.cancerParentsGender = "M";
							}
							else if(CommonServices.floaterObj.risks[i].riskDetails.sex == 'F'){
								this.coveredParentDetails[parentCount].memberInfo.cancerParentsGender = "F";
							}
							// else {
							// 	this.coveredParentDetails[parentCount].memberInfo.cancerParentsGender = "Third Gender";
							// }
							this.coveredParentDetails[parentCount].memberInfo.parentSmoker = CommonServices.floaterObj.risks[i].riskDetails.areUaSmoker;
							this.coveredParentDetails[parentCount].memberInfo.parentHabbitChewing = CommonServices.floaterObj.risks[i].riskDetails.areUchewingTobacco;
							this.coveredParentDetails[parentCount]['edit'] = true;
							this.coveredParentDetails[parentCount]['riskDetails'] = CommonServices.floaterObj.risks[i].riskDetails;
							parentCount++;
						}
						else if(CommonServices.floaterObj.risks[i].riskDetails.relationWithPolicyHolder.toUpperCase()==="WARD"){
							var ageYrs = CommonServices.floaterObj.risks[i].riskDetails.ageInYrs;
							if(ageYrs < 51) {
								$scope.sumInsuredWardArray[wardCount] = $scope.sumInsuredDataArray[50];
							}
							else if(ageYrs > 50 && ageYrs <56) {
								$scope.sumInsuredWardArray[wardCount] = $scope.sumInsuredDataArray[55];
							}
							else if(ageYrs > 55 && ageYrs < 61) {
								$scope.sumInsuredWardArray[wardCount] = $scope.sumInsuredDataArray[60];
							}
							else {
								$scope.sumInsuredWardArray[wardCount] = $scope.sumInsuredDataArray[65];
							}

							this.addMember("WARD");

							this.coveredWardDetails[wardCount].memberInfo = {};
							this.coveredWardDetails[wardCount].wardDateOfBirth = CommonServices.floaterObj.risks[i].riskDetails.dateOfBirth;
							this.coveredWardDetails[wardCount].memberInfo.sumInsuredAmountWard = CommonServices.floaterObj.risks[i].riskDetails.sumInsured;
							if(CommonServices.floaterObj.risks[i].riskDetails.sex == 'M'){
								this.coveredWardDetails[wardCount].memberInfo.cancerWardGender = "M";
							}
							else if(CommonServices.floaterObj.risks[i].riskDetails.sex == 'F'){
								this.coveredWardDetails[wardCount].memberInfo.cancerWardGender = "F";
							}
							// else {
							// 	this.coveredWardDetails[wardCount].memberInfo.cancerWardGender = "Third Gender";
							// }
							this.coveredWardDetails[wardCount].memberInfo.wardSmoker = CommonServices.floaterObj.risks[i].riskDetails.areUaSmoker;
							this.coveredWardDetails[wardCount].memberInfo.wardHabbitChewing = CommonServices.floaterObj.risks[i].riskDetails.areUchewingTobacco;
							this.coveredWardDetails[wardCount]['edit'] = true;
							this.coveredWardDetails[wardCount]['riskDetails'] = CommonServices.floaterObj.risks[i].riskDetails;
							wardCount++;
						}
						else if(CommonServices.floaterObj.risks[i].riskDetails.relationWithPolicyHolder.toUpperCase()==="PROPOSER" || CommonServices.floaterObj.risks[i].riskDetails.relationWithPolicyHolder.toUpperCase()==="SELF"){

							var ageProposerYrs = CommonServices.floaterObj.risks[i].riskDetails.ageInYrs;
							if(ageProposerYrs < 51) {
								$scope.sumInsuredProposerArray = $scope.sumInsuredDataArray[50];
							}
							else if(ageProposerYrs > 50 && ageProposerYrs <56) {
								$scope.sumInsuredProposerArray = $scope.sumInsuredDataArray[55];
							}
							else if(ageProposerYrs > 55 && ageProposerYrs < 61) {
								$scope.sumInsuredProposerArray = $scope.sumInsuredDataArray[60];
							}
							else {
								$scope.sumInsuredProposerArray = $scope.sumInsuredDataArray[65];
							}
							this.addMember("PROPOSER");
							this.proposerDateOfBirth = CommonServices.floaterObj.risks[i].riskDetails.dateOfBirth;
							this.sumInsuredAmountProposer = CommonServices.floaterObj.risks[i].riskDetails.sumInsured;
							if(CommonServices.floaterObj.risks[i].riskDetails.sex == 'M'){
								this.cancerProposerGender = "M";
							}
							else if(CommonServices.floaterObj.risks[i].riskDetails.sex == 'F'){
								this.cancerProposerGender = "F";
							}
							// else {
							// 	this.cancerProposerGender = "Third Gender";
							// }
						//	this.cancerProposerGender = CommonServices.floaterObj.risks[i].riskDetails.sex;
							this.proposerSmoker = CommonServices.floaterObj.risks[i].riskDetails.areUaSmoker;
							this.proposerHabbitChewing = CommonServices.floaterObj.risks[i].riskDetails.areUchewingTobacco;

							this.coveredProposerDetails[0]['riskDetails'] = CommonServices.floaterObj.risks[i].riskDetails;
						}
						
					}
				}
				//form Prepopulation ends coming from Edit Quote 
				
			}
		};
		$scope.goBack = function() {
			//sourav change 13.10.2019 to handle back button action when going through manage policies
			if (CommonServices.editQuoteFlag === true) {
				$rootScope.backFlag = "";
				CommonServices.editQuoteFlag = false;
				$state.go('managePolicies.managePolicies');
			}
			else {
				$rootScope.backFlag = "";
				//$state.go("topUpMediclaimLandingScreen");
				//New implementation of checkbox CR_3725 Sudip-->
				$state.go("buyNowSubLandingScreen");
			}	
		};
		

		/*$scope.next = function(){
			//if ($rootScope.currentIndex === $rootScope.additionalDetailsArray.length) {
		$rootScope.dataforSaveQuote();
		CommonServices.floaterObj.localStorageVAlues = $rootScope.additionalDetailsArray;
		$state.go("policyPeriodAndNomineeDetailsHealth");
		// }
	};
		*/
		var policyStartDate = TodyasDateFormatToCal;
		var arr = policyStartDate.split('/');
			policyStartDate =arr[1] + '/' + arr[0] + '/' + arr[2]; //dd/mm/yyyy

			CommonServices.floaterObj.policyStartDate = policyStartDate;
			$scope.policyStartDate = policyStartDate;

			var policyEndDate =new Date(mydateStr);
			policyEndDate.setFullYear(policyEndDate.getFullYear() +1);
			policyEndDate.setDate(policyEndDate.getDate() - 1);
			var dd = policyEndDate.getDate();
			var mm = policyEndDate.getMonth() + 1;
			var yyyy = policyEndDate.getFullYear();

			if (dd < 10) {
			dd = "0" + dd;
			}

			if (mm < 10) {
			mm = "0" + mm;
			}
			policyEndDate = dd + "/" +mm + "/" + yyyy;//policy end date
			CommonServices.floaterObj.policyExpiryDate = policyEndDate;
			$scope.policyEndDate = policyEndDate;
			
		$scope.approvePay = function() { 
			$state.go("docUpload");
		};
		
		if ($rootScope.backFlag === "premCal") {
			$(".form-group").addClass('focused');
			$scope.memberInfo.showProposer = CommonServices.floaterObj.addProposerDisable;
			$scope.memberInfo.showSpouse = CommonServices.floaterObj.addSpouseDisable;
			$scope.memberInfo.addChildDisable = CommonServices.floaterObj.addChildDisable;
			$scope.memberInfo.addWardDisable = CommonServices.floaterObj.addWardDisable;
			$scope.memberInfo.addParentDisable = CommonServices.floaterObj.addParentDisable;
			
			$scope.memberInfo.coveredChildDetails = CommonServices.floaterObj.coveredChildDetails;
			$scope.memberInfo.coveredWardDetails = CommonServices.floaterObj.coveredWardDetails;
			$scope.memberInfo.coveredParentDetails = CommonServices.floaterObj.coveredParentDetails;
			$scope.memberInfo.coveredSpouseDetails = CommonServices.floaterObj.coveredSpouseDetails;
			$scope.memberInfo.coveredProposerDetails = CommonServices.floaterObj.coveredProposerDetails;
			
			
			$scope.memberInfo.disableAddChildBtn = CommonServices.floaterObj.countOfChild;
			$scope.memberInfo.disableAddWardBtn = CommonServices.floaterObj.countOfWard;
			$scope.memberInfo.toupTermsAndCondition = true;
			//New implementation of checkbox CR_3725 Sudip
			//$scope.memberInfo.cancerGuardPolicyInfo = true;
			$scope.memberInfo.disableCountBtn = CommonServices.floaterObj.numberOfMembers;
		
			for( j = 0; j< CommonServices.floaterObj.coveredParentDetails.length; j++){
				var dataAmt = CommonServices.floaterObj.coveredParentDetails[j].memberInfo.sumInsuredAmountParent;
					$scope.memberInfo.dateOfBirthFunc('PARENT',j);
					$scope.memberInfo.coveredParentDetails[j].memberInfo.sumInsuredAmountParent = dataAmt;
					$scope.memberInfo.parentDateOfBirth = CommonServices.floaterObj.coveredParentDetails[j].memberInfo.dateOfBirth;

			}

			for( j = 0; j< CommonServices.floaterObj.coveredChildDetails.length; j++){
				var dataAmt = CommonServices.floaterObj.coveredChildDetails[j].memberInfo.sumInsuredAmountChild;
					$scope.memberInfo.dependentTypeChanged('CHILD',j);
					$scope.memberInfo.coveredChildDetails[j].memberInfo.sumInsuredAmountChild = dataAmt;
					$scope.memberInfo.childDateOfBirth = CommonServices.floaterObj.coveredChildDetails[j].memberInfo.dateOfBirth;

			}

			for( j = 0; j< CommonServices.floaterObj.coveredWardDetails.length; j++){
				var dataAmt = CommonServices.floaterObj.coveredWardDetails[j].memberInfo.sumInsuredAmountWard;
					$scope.memberInfo.dependentTypeChanged('WARD',j);
					$scope.memberInfo.coveredWardDetails[j].memberInfo.sumInsuredAmountWard = dataAmt;
					$scope.memberInfo.wardDateOfBirth = CommonServices.floaterObj.coveredWardDetails[j].memberInfo.dateOfBirth;

			}


			for (i = 0; i < CommonServices.floaterObj.addedMemberDetails.length; i++) {

				if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "PROPOSER" || CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "SELF") {
					//$scope.sumInsuredProposerArray = CommonServices.floaterObj.sumInsuredProposerArray;
					//console.log("suminsuredamountarray"+$scope.sumInsuredProposerArray);
					var ageProposerYrs = CommonServices.floaterObj.addedMemberDetails[i].riskDetails.ageInYrs;
					if(ageProposerYrs < 51) {
						$scope.sumInsuredProposerArray = $scope.sumInsuredDataArray[50];
					}
					else if(ageProposerYrs > 50 && ageProposerYrs <56) {
						$scope.sumInsuredProposerArray = $scope.sumInsuredDataArray[55];
					}
					else if(ageProposerYrs > 55 && ageProposerYrs < 61) {
						$scope.sumInsuredProposerArray = $scope.sumInsuredDataArray[60];
					}
					else {
						$scope.sumInsuredProposerArray = $scope.sumInsuredDataArray[65];
					}

					$scope.memberInfo.proposerDateOfBirth = CommonServices.floaterObj.addedMemberDetails[i].riskDetails.dateOfBirth;
					//$scope.sumInsuredProposer = CommonServices.floaterObj.addedMemberDetails[i].riskSumInsured;
					$scope.memberInfo.sumInsuredAmountProposer = CommonServices.floaterObj.addedMemberDetails[i].riskDetails.sumInsured;
				//	console.log("$rootScope.backFlag === premCal"+$scope.memberInfo.sumInsuredAmountProposer);
					$scope.memberInfo.proposerSmoker = CommonServices.floaterObj.addedMemberDetails[i].riskDetails.areUaSmoker;
					$scope.memberInfo.proposerHabbitChewing = CommonServices.floaterObj.addedMemberDetails[i].riskDetails.areUchewingTobacco;
					console.log("proposer sex value is "+CommonServices.floaterObj.addedMemberDetails[i].riskDetails.sex);
					if(CommonServices.floaterObj.addedMemberDetails[i].riskDetails.sex == 'M'){
						$scope.memberInfo.cancerProposerGender = "M";
					}
					else if(CommonServices.floaterObj.addedMemberDetails[i].riskDetails.sex == 'F'){
						$scope.memberInfo.cancerProposerGender = "F";
					}
					else {
						$scope.memberInfo.cancerProposerGender = "T";
					}
					console.log("proposer sex value after "+$scope.memberInfo.cancerProposerGender);
					//$scope.memberInfo.cancerProposerGender = CommonServices.floaterObj.addedMemberDetails[i].riskDetails.sex;


				}

				else if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "SPOUSE") {
					//$scope.memberInfo.showSpouseDOB = true;
					var ageProposerYrs = CommonServices.floaterObj.addedMemberDetails[i].riskDetails.ageInYrs;
					if(ageProposerYrs < 51) {
						$scope.sumInsuredSpouseArray = $scope.sumInsuredDataArray[50];
					}
					else if(ageProposerYrs > 50 && ageProposerYrs <56) {
						$scope.sumInsuredSpouseArray = $scope.sumInsuredDataArray[55];
					}
					else if(ageProposerYrs > 55 && ageProposerYrs < 61) {
						$scope.sumInsuredSpouseArray = $scope.sumInsuredDataArray[60];
					}
					else {
						$scope.sumInsuredSpouseArray = $scope.sumInsuredDataArray[65];
					}

					$scope.memberInfo.spouseDateOfBirth = CommonServices.floaterObj.addedMemberDetails[i].riskDetails.dateOfBirth;
					//$scope.sumInsuredSpouse = CommonServices.floaterObj.addedMemberDetails[i].riskSumInsured;
					$scope.memberInfo.spouseSmoker = CommonServices.floaterObj.addedMemberDetails[i].riskDetails.areUaSmoker;
					$scope.memberInfo.spouseHabbitChewing = CommonServices.floaterObj.addedMemberDetails[i].riskDetails.areUchewingTobacco;
					$scope.memberInfo.sumInsuredAmountSpouse = CommonServices.floaterObj.addedMemberDetails[i].riskDetails.sumInsured;
					//$scope.memberInfo.cancerSpouseGender = CommonServices.floaterObj.addedMemberDetails[i].riskDetails.sex;
					if(CommonServices.floaterObj.addedMemberDetails[i].riskDetails.sex == 'M'){
						$scope.memberInfo.cancerSpouseGender = "M";
					}
					else if(CommonServices.floaterObj.addedMemberDetails[i].riskDetails.sex == 'F'){
						$scope.memberInfo.cancerSpouseGender = "F";
					}
					// else {
					// 	$scope.memberInfo.cancerSpouseGender = "Third Gender";
					// }
					console.log("proposer sex value after "+$scope.memberInfo.cancerSpouseGender);

				}
				else if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "PARENTS") { //CR_3725- Sudip
					//$scope.memberInfo.showSpouseDOB = true;
				//	$scope.sumInsuredParentArray[i] = CommonServices.floaterObj.addedMemberDetails[i].riskDetails.sumInsured;
					// var dataAmt = CommonServices.floaterObj.addedMemberDetails[i].riskDetails.sumInsured;
					// $scope.memberInfo.dateOfBirthFunc('PARENT',i);
					// $scope.memberInfo.coveredParentDetails[i].memberInfo.sumInsuredAmountParent = dataAmt;
					// $scope.memberInfo.parentDateOfBirth = CommonServices.floaterObj.addedMemberDetails[i].riskDetails.dateOfBirth;
					//$scope.sumInsuredParent = CommonServices.floaterObj.addedMemberDetails[i].riskSumInsured;
				}
				else if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "WARD") { //CR_3725- Sudip
					//$scope.memberInfo.showSpouseDOB = true;
					// var dataAmt = CommonServices.floaterObj.addedMemberDetails[i].riskDetails.sumInsured;
					// $scope.memberInfo.dependentTypeChanged('WARD',i);
					// $scope.memberInfo.coveredWardDetails[i].memberInfo.sumInsuredAmountWard = dataAmt;
					// $scope.memberInfo.wardDateOfBirth = CommonServices.floaterObj.addedMemberDetails[i].riskDetails.dateOfBirth;
					//$scope.sumInsuredWard = CommonServices.floaterObj.addedMemberDetails[i].riskSumInsured;
					
				}
				else if (CommonServices.floaterObj.addedMemberDetails[i].riskDetails.relationWithPolicyHolder.toUpperCase() === "CHILD") { //CR_3725- Sudip
					//$scope.memberInfo.showSpouseDOB = true;
					// var dataAmt = CommonServices.floaterObj.addedMemberDetails[i].riskDetails.sumInsured;
					// $scope.memberInfo.dependentTypeChanged('CHILD',i);
					// $scope.memberInfo.coveredChildDetails[i].memberInfo.sumInsuredAmountChild = dataAmt;
					// $scope.memberInfo.childDateOfBirth = CommonServices.floaterObj.addedMemberDetails[i].riskDetails.dateOfBirth;
					//$scope.sumInsuredWard = CommonServices.floaterObj.addedMemberDetails[i].riskSumInsured;
					
				}

			}
		}	

		if(CommonServices.editQuoteFlag && $rootScope.backFlag !== "premCal"){
			$scope.memberInfo.initModel();
		}

		CommonServices.getDomainValues();
		
	}]);
