var agentApp = angular.module('agentApp', [
  'ui.router','appCalendar','ngSanitize','ngTouch','ui.bootstrap','ngFileUpload'
]);
//CR3746
// var regexPanNoGlobal =  /^(?:([A-Za-z])(?!(?:[A-Za-z]*?\1){4})){5}(?:([0-9])(?!(?:[0-9]*?\2){3})){4}[A-Za-z]{1}$/;
// Actual 3746 regex ->  var regexPanNoGlobal =  /^(?:([A-Za-z])(?!(?:\1){4})){3}(?:([ABCEFGHJLPTabcefghjlpt])(?!(?:\1){4})){1}(?:([A-Za-z])(?!(?:\1){4})){1}(?:([0-9])(?!(?:\4){3})){4}[A-Za-z]$/;
var regexPanNoGlobal = /^[A-Za-z]{5}[0-9]{4}[A-Za-z]{1}$/;
var iDDocNoRegexGlobal = /^[a-zA-Z0-9!@#$%^&*()_+\-=\[\]{};':\\|,.<>\/?~` ]*$/;
var NIAPanNo = "AAACN4165C";
 //CR3746
var regexGSTidGlobal = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[A-Z0-9]{2}[^\s]$/;
//  //CR_3749
// var regexGSTidGlobal =  /^[0-9]{2}(?:([A-Z])(?!(?:\1){4})){3}(?:([ATCPFHBLJGEatcpfhbljge])(?!(?:\1){4})){1}(?:([A-Z])(?!(?:\1){4})){1}(?:([0-9])(?!(?:\4){3})){4}[A-Z][a-zA-Z0-9][A-Z][a-zA-Z0-9]$/;

agentApp.config(['$stateProvider','$urlRouterProvider',function($stateProvider, $urlRouterProvider) {

  $urlRouterProvider.otherwise('/login');
    
    $stateProvider
    .state('login', {
        url: '/login',
        templateUrl: 'partials/login.html'
    })
    .state('home', {
        url: '/home',
        templateUrl: 'partials/home.html'
    })
    .state('ecover', {
        url: '/ecover',
        templateUrl: 'partials/ecover/ecover.html'
    })
    .state('newRenewPolicy', {
        url: '/newRenewPolicy',
        template: '<section class="agentPage" id="newRenewPolicyModule-screen" data-ui-view ></section>',
        controller: 'NewRenewPolicyCtrl'
    })
    .state('newRenewPolicy.getNewRenewPolicy', {
        url: '/getNewRenewPolicy',
        templateUrl: 'partials/newRenewPolicy/getNewRenewPolicy.html',
        controller: 'GetNewRenewPolicyCtrl'
    })
    /* 3712 Starts  
    .state('newRenewPolicy.nationalityCapture', {
        url: '/nationalityCapture',
        templateUrl: 'partials/newRenewPolicy/nationalityCapture.html',
        controller: 'NationalityCaptureCtrl'
    })
    //   3712 Ends  */
    .state('newRenewPolicy.vehicleReg', {
        url: '/vehicleReg',
        templateUrl: 'partials/newRenewPolicy/vehicleReg.html',
        controller: 'VehicleRegCtrl'
    })
	.state('newRenewPolicy.NmMcToUkMigration', {
        url: '/NmMcToUkMigration',
        templateUrl: 'partials/newRenewPolicy/NmMcToUkMigration.html',
        controller: 'NmMcToUkMigrationCtrl'
    })
    .state('newRenewPolicy.policyDetails', {
        url: '/policyDetails',
        templateUrl: 'partials/newRenewPolicy/policyDetails.html',
        controller: 'PolicyDetailsCtrl'
    })
    .state('newRenewPolicy.migrationDocUpload', {
        url: '/migrationDocUpload',
        templateUrl: 'partials/newRenewPolicy/migrationDocUpload.html',
        controller: 'migrationDocUploadCtrl'
    })
    .state('newRenewPolicy.collectionForm', {
        url: '/collectionForm',
        templateUrl: 'partials/newRenewPolicy/collectionForm.html',
        controller: 'CollectionCtrl'
    })
    .state('newRenewPolicy.acknowledgement', {
        url: '/acknowledgement',
        templateUrl: 'partials/newRenewPolicy/acknowledgement.html',
        controller: 'AcknowledgementCtrl'
    })
	.state('profileUpdate', {
        url: '/profileUpdate',
        template: '<section class="agentPage" id="updateProfile-screen" data-ui-view ></section>',
        controller: 'profileUpdateController'
    })
	.state('profileUpdate.forgotPass', {
        url: '/forgotPass',
        templateUrl: 'partials/profileUpdate/forgotPass.html',
        controller: 'ForgotPassCtrl'
    })
	.state('profileUpdate.changePassword', {
        url: '/changePassword',
        templateUrl: 'partials/profileUpdate/changePassword.html',
        controller: 'changePasswordCtrl'
    })
	.state('profileUpdate.updateProfile', {
        url: '/updateProfile',
        templateUrl: 'partials/profileUpdate/updateProfile.html',
        controller: 'profileUpdateCtrl'
    })
	.state('managePolicies', {
        url: '/managePolicies',
        template: '<section class="agentPage" id="policyClaim-screen" data-ui-view ></section>',
        controller: 'policyClaimController'
    })
	.state('managePolicies.managePolicies', {
        url: '/managePolicies',
        templateUrl: 'partials/managePolicies/managePolicies.html',
		controller: 'managePolicyController'
    })
	.state('managePolicies.viewPolicyDetails', {
        url: '/viewPolicyDetails',
        templateUrl: 'partials/managePolicies/viewPolicyDetails.html',
		controller: 'viewPolicyController'
    })	
	.state('managePolicies.claims', {
        url: '/claims',
        templateUrl: 'partials/managePolicies/claims.html',
		controller: "claimListController"
    })
	.state('managePolicies.claimSearchDetails', {
        url: '/claimSearchDetails',
        templateUrl: 'partials/managePolicies/claimSearchDetails.html',
		controller: "claimDetailsController"
    })
	.state('managePolicies.intimateClaimForm', {
        url: '/intimateClaimForm',
        templateUrl: 'partials/managePolicies/intimateClaimForm.html',
		controller: "intimateClaimFormController"
    })
	.state('managePolicies.docUpload', {
        url: '/docUpload',
        templateUrl: 'partials/managePolicies/docUpload.html',
		controller: "docUploadController"
    })
	.state('managePolicies.viewUploadedDoc', {
        url: '/viewUploadedDoc',
        templateUrl: 'partials/managePolicies/viewUploadedDoc.html',
		controller: "viewUploadedDocController"
    })
	.state('contactDetails', {
        url: '/locator',
        template: '<section class="agentPage" id="locator-screen" data-ui-view ></section>',
        controller: 'contactDetailsController'
    })
	.state('contactDetails.locator', {
        url: '/locator',
        templateUrl: 'partials/contactDetails/locator.html',
		controller: "locatorController"
    })
	.state('contactDetails.contactUs', {
        url: '/contactUs',
        templateUrl: 'partials/contactDetails/contactUs.html',
		controller: "contactUsController"
    })
	.state('contactDetails.contactDetailsForm', {
        url: '/contactDetailsForm',
        templateUrl: 'partials/contactDetails/contactDetailsForm.html',
		controller: "contactDetailsFormController"
    })
	.state('contactDetails.locatorList', {
        url: '/locatorList',
        templateUrl: 'partials/contactDetails/locatorList.html',
		controller: "locatorListController"
    })
	.state('clients', {
        url: '/clients',
        template: '<section class="agentPage" id="clientsModule-screen" data-ui-view ></section>',
        controller: 'clientsController'
    })
	.state('clients.myClients', {
        url: '/myClients',
        templateUrl: 'partials/clients/myClients.html',
        controller: 'myClientsController'
    })
	.state('clients.addClient', {
        url: '/addClient',
        templateUrl: 'partials/clients/addClient.html',
        controller: 'addClientController'
    })
    .state('personalAccident', {
        url: '/personalAccident',
        templateUrl: 'partials/productList/personalAccident/personalAccident.html',
        controller: 'personalAccidentCtrl'
    })
	.state('premiumCalculator', {
        url: '/premiumCalculator',
        templateUrl: 'partials/productList/personalAccident/premiumCalculator.html'
    })
	.state('premiumResult', {
        url: '/premiumResult',
        templateUrl: 'partials/productList/personalAccident/premiumResult.html'
    })
	.state('InsuredDetails', {
        url: '/InsuredDetails',
        templateUrl: 'partials/productList/personalAccident/InsuredDetails.html'
    })
	.state('SpouseDetails', {
        url: '/SpouseDetails',
        templateUrl: 'partials/productList/personalAccident/SpouseDetails.html'
    })
	.state('DaughterDetails', {
        url: '/DaughterDetails',
        templateUrl: 'partials/productList/personalAccident/DaughterDetails.html'
    })
	.state('SonDetails', {
        url: '/SonDetails',
        templateUrl: 'partials/productList/personalAccident/SonDetails.html'
    })
	.state('PaymentDetails', {
        url: '/PaymentDetails',
        templateUrl: 'partials/productList/personalAccident/PaymentDetails.html'
    })
	.state('clients.viewClients', {
        url: '/viewClients',
        templateUrl: 'partials/clients/viewClients.html',
        controller: 'viewClientsController'
    })	
	.state('manageRenewals', {
	  url: '/manageRenewals',
	  template: '<section class="agentPage" id="manageRenewalsModule-screen" data-ui-view ></section>',
	  controller: 'ManageRenewalsCtrl'
	})
	.state('manageRenewals.manageRenewalsCalendar', {
	  url: '/manageRenewalsCalendar',
	  templateUrl: 'partials/manageRenewals/manageRenewalsCalendar.html',
	  controller: 'ManageRenewalsCalendarCtrl'
	})
/*added for CR_NP_0675*/
	.state('renewalNotices', {
	  url: '/renewalNotices',
	  templateUrl: 'partials/manageRenewals/renewalNotices.html',
	  controller: 'renewalNoticesController'
	})
	.state('renewalNoticesPolicyList', {
	  url: '/renewalNoticesPolicyList',
	  templateUrl: 'partials/manageRenewals/renewalNoticesPolicyList.html',
	  controller: 'renewalNoticesController'
	})
	.state('renewalNoticesPolicyDetail', {
	  url: '/renewalNoticesPolicyDetail',
	  templateUrl: 'partials/manageRenewals/renewalNoticesPolicyDetail.html',
	  controller: 'renewalNoticesController'
	})
	/*added end for CR_NP_0675*/
	.state('manageRenewals.renewalProductsList', {
	  url: '/renewalProductsList',
	  templateUrl: 'partials/manageRenewals/renewalProductsList.html',
	  controller: 'renewalProductsListCtrl'
	})
	.state('manageRenewals.renewalProductsPolicyList', {
	  url: '/renewalProductsPolicyList',
	  templateUrl: 'partials/manageRenewals/renewalProductsPolicyList.html',
	  controller: 'renewalProductsPolicyListCtrl'
	})
	.state('manageRenewals.renewalPolicyDetails', {
	  url: '/renewalPolicyDetails',
	  templateUrl: 'partials/manageRenewals/renewalPolicyDetails.html',
	  controller: 'renewalPolicyDetailsCtrl'
	})
	.state('appointments', {
          url: '/appointments',
          template: '<section class="agentPage" id="appointmentsModule-screen" data-ui-view ></section>',
          controller: 'AppointmentsCtrl'
      })
      .state('appointments.appointmentsCalendar', {
          url: '/appointmentsCalendar',
          templateUrl: 'partials/appointments/appointmentsCalendar.html',
          controller: 'AppointmentsCalendarCtrl'
      })
      .state('appointments.createAppointment', {
          url: '/createAppointment',
          templateUrl: 'partials/appointments/createAppointment.html',
          controller: 'CreateAppointmentCtrl'
      })	
	  .state('appointments.appointmentsList', {
	  url: '/appointmentsList',
	  templateUrl: 'partials/appointments/appointmentsList.html',
	  controller: 'appointmentListController'
	})
	.state('appointments.appointmentsDetails', {
	  url: '/appointmentsDetails',
	  templateUrl: 'partials/appointments/appointmentsDetails.html',
	  controller: 'appointmentsDetailsCtrl'
	})
	.state('products', {
        url: '/products',
        template: '<section class="agentPage" id="product-list" data-ui-view ></section>',
        controller: 'productController'
    })
	.state('products.productList', {
        url: '/productList',
        templateUrl: 'partials/productList/productList.html',
		controller: "productListController"
    })
	.state('products.productSubList', {
        url: '/subProduct/:id',
        templateUrl: 'partials/productList/productSubList.html',
		controller: "productSubListController"
    })
	.state('businessHolidays', {
        url: '/businessHolidays',
        template: '<section class="agentPage" id="businessHolidays" data-ui-view ></section>',
        controller: 'businessHolidaysCtrl'
    })
	.state('businessHolidays.travelDetails', {
        url: '/travelDetails',
        templateUrl: 'partials/productList/businessHolidays/travelDetails.html',
		controller: "travelDetailsCtrl"
    })
	.state('businessHolidays.travelSummary', {
        url: '/travelSummary',
        templateUrl: 'partials/productList/businessHolidays/travelSummary.html',
		controller: "travelSummaryCtrl"
    })
	.state('businessHolidays.policyHolderInfo', {
        url: '/policyHolderInfo',
        templateUrl: 'partials/productList/businessHolidays/policyHolderInfo.html',
		controller: "policyHolderInfoCtrl"
    })
	.state('businessHolidays.travellerDetails', {
        url: '/travellerDetails',
        templateUrl: 'partials/productList/businessHolidays/travellerDetails.html',
		controller: "travellerDetailsCtrl"
    })
	.state('businessHolidays.paymentDetails', {
        url: '/paymentDetails',
        templateUrl: 'partials/productList/businessHolidays/paymentDetails.html',
		controller: "paymentDetailsCtrl"
    })
	.state('collectionForm', {
        url: '/collectionForm',
        templateUrl: 'partials/productList/businessHolidays/collectionForm.html',
        controller: 'commonCollectionCtrl'
    })
	.state('acknowledgement', {
        url: '/acknowledgement',
        templateUrl: 'partials/productList/businessHolidays/acknowledgement.html',
        controller: 'acknowledgementCtrl'
    })
	.state('businessHolidays.overseasMediclaim', {
        url: '/overseasMediclaim',
        templateUrl: 'partials/productList/esExtension/overseasMediclaim.html',
		controller: "mediClaimCtrl"
    })
	.state('buyNowLandingScreen', {
        url: '/buyNowLandingScreen',
        templateUrl: 'partials/productList/buyNowLandingScreen.html',
		controller:'buyNowLandingCntrl'
    })
	.state('vehicleRegistrationScreen', {
        url: '/vehicleRegistrationScreen',
        templateUrl: 'partials/vehicleRegistrationScreen/vehicleRegistrationScreen.html',
		controller:'vehicleRegistrationScreenCtrl'
    })
	.state('buyNowSubLandingScreen', {
        url: '/buyNowSubLandingScreen',
        templateUrl: 'partials/productList/buyNowSubLandingScreen.html',
		controller:'buyNowSubLandingScreenCtrl'
    })
	.state('uploadPhoto', {
          url: '/uploadPhoto',
          template: '<section class="agentPage" id="uploadPhotoModule-screen" data-ui-view ></section>',
          controller: 'breakInPhotoUploadCntl'
	})
	.state('uploadPhoto.breakInQuotesList', {
	  url: '/breakInQuotesList',
	  templateUrl: 'partials/uploadPhoto/breakInQuotesList.html',
	  controller: 'breakInQuotesCntl'
	})
	/******* for video inspection***/
	.state('uploadVideo', {
	  url: '/uploadVideo',
	  templateUrl: 'partials/uploadPhoto/videoRecording.html',
	  controller: 'videoRecordingCntrl'
	})
	.state('uploadPhoto.uploadPhoto', {
	  url: '/uploadPhoto',
	  templateUrl: 'partials/uploadPhoto/uploadPhoto.html',
	  controller: 'uploadPhotoCntl'
    })
    .state('uploadPhoto.placeOfInspection', { //CR 0944
        url: '/placeOfInspection',
        templateUrl: 'partials/uploadPhoto/placeOfInspection.html',
        controller: 'placeOfInspectionCntl'
    })
	.state('uploadPhoto.breakInQuoteSearch', {
	  url: '/breakInQuoteSearch',
	  templateUrl: 'partials/uploadPhoto/breakInQuoteSearch.html',
	  controller: 'breakInQuoteSearchCntl'
	})
	.state('uploadPhoto.viewUploadedPhoto', {
	  url: '/viewUploadedPhoto',
	  templateUrl: 'partials/uploadPhoto/viewUploadedPhoto.html',
	  controller: 'viewUploadedPhotoCntl'
	})

    .state('linkYourAadharGetDetails',{
        url:'/linkYourAadharGetDetails',
        templateUrl:'partials/linkAadhar/linkYourAadharGetDetails.html'
    })

    .state('linkYourAadharGetUserData',{
        url:'/linkYourAadharGetUserData',
        templateUrl:'partials/linkAadhar/linkYourAadharGetUserData.html'
    })   
	/*********** CR37A - Griha Suvidha product starts ************/
	.state('gsLandingScreen', {
        url: '/gsLandingScreen',
        templateUrl: 'partials/productList/grihaSuvidha/gsLandingScreen.html',
		controller:'landingScreenCtrlGS'		
    })
	.state('gsPremiumCalculator', {
        url: '/gsPremiumCalculator',
        templateUrl: 'partials/productList/grihaSuvidha/gsPremiumCalculator.html',
		controller:'premiumCalculatorScreenCtrlGS'		
    })
	.state('gsPremiumResult', {
        url: '/gsPremiumResult',
        templateUrl: 'partials/productList/grihaSuvidha/gsPremiumResult.html',
		controller:'premiumResultScreenCtrlGS'
    })
	.state('gsAdditionalDetails', {
        url: '/gsAdditionalDetails',
        templateUrl: 'partials/productList/grihaSuvidha/gsAdditionalDetails.html',
		controller:'additionalDetailsCtrlGS'
    })
	.state('gsSummaryDetails', {
        url: '/gsSummaryDetails',
        templateUrl: 'partials/productList/grihaSuvidha/gsSummaryDetails.html',
		controller:'summaryDetailsCtrlGS'
    })
    /*********** CR37A - Griha Suvidha product ends ************/

        /*********** CR_3547 - Raasta Aapatti Kavach product starts ************/

    .state('rakPremiumCalculator', {
        url: '/rakPremiumCalculator',
        templateUrl: 'partials/productList/raastaAapattiKavachPolicy/rakPremiumCalculator.html',
		controller:'raastaAapattiKavachPremiumCalcCtrl'		
    }) 
    .state('rakViewBreakup', {
        url: '/rakViewBreakup',
        templateUrl: 'partials/productList/raastaAapattiKavachPolicy/rakViewBreakup.html',
		controller:'rakViewBreakupCtrl'		
    }) 
    .state('rakProposerDetails', {
        url: '/rakProposerDetails',
        templateUrl: 'partials/productList/raastaAapattiKavachPolicy/rakProposerDetails.html',
		controller:'rakPolicyHolderDetailCtrl'		
    })   
	.state('rakReviewSummary', {
        url: '/rakReviewSummary',
        templateUrl: 'partials/productList/raastaAapattiKavachPolicy/rakReviewSummary.html',
		controller:'rakReviewSummaryCtrl'
    })    

    /*********** CR_3547 - Raasta Aapatti Kavach product ends ************/
	
    /********** CR_41 New india top up mediclaim starts ********/
    .state('topUpMediclaimLandingScreen', {
        url: '/topUpMediclaimLandingScreen',
        templateUrl: 'partials/productList/newIndiaTopUpMediclaim/topUpMediclaimLanding.html',
		controller:'toUpMediClaimLandingCtrl'
    })
    .state('topUpPremiumCalcScreen', {
        url: '/topUpPremiumCalcScreen',
        templateUrl: 'partials/productList/newIndiaTopUpMediclaim/topUpPremiumCalc.html',
		controller:'topUpPremiumCalcCtrl'
    })
     .state('topUpBasicPremiumScreen', {
        url: '/topUpBasicPremiumScreen',
        templateUrl: 'partials/productList/newIndiaTopUpMediclaim/toUpBasicPremium.html',
		controller:'topUpBasicPremiumCtrl'
    })
     .state('topUpViewBreakupScreen', {
        url: '/topUpViewBreakupScreen',
        templateUrl: 'partials/productList/newIndiaTopUpMediclaim/topUpViewBreakup.html',
		controller:'topUpViewBreakupCtrl'
    })
	.state('policyHolderDetails', {
        url: '/policyHolderDetails',
        templateUrl: 'partials/productList/newIndiaTopUpMediclaim/policyHolderDetails.html',
        controller:'policyHolderDetailsCtrl'
    }) 
     .state('policyHolderDetailsScreen', {
        url: '/policyHolderDetailsScreen',
        templateUrl: 'partials/productList/newIndiaTopUpMediclaim/policyHolderDetails.html',
		controller:'policyHolderDetailsCtrl'
    })
     .state('searchPolicyHolderScreen', {
        url: '/searchPolicyHolderScreen',
        templateUrl: 'partials/productList/newIndiaTopUpMediclaim/policyHolderSearch.html',
		controller:'policyHolderSearchCtrl'
    })
    .state('toUpReviewSummaryScreen', {
        url: '/toUpReviewSummaryScreen',
        templateUrl: 'partials/productList/newIndiaTopUpMediclaim/reviewSummaryPayment.html',
		controller:'reviewSummaryCtrl'
    })
	.state('proposerDetails', {
        url: '/proposerDetails',
        templateUrl: 'partials/productList/newIndiaTopUpMediclaim/proposerDetails.html',
		controller:'proposerDetailsCtrl'
    })
	.state('policyPeriodAndNomineeDetails', {
        url: '/policyPeriodAndNomineeDetails',
        templateUrl: 'partials/productList/newIndiaTopUpMediclaim/policyPeriodAndNomineeDetails.html',
		controller:'policyPeriodAndNomineeDetailsCtrl'
    })
	
    .state('topUpRelationalDetails',{
		url:'/topUpRelationalDetails',
		templateUrl: 'partials/productList/newIndiaTopUpMediclaim/topUpRelationalDetails.html',
		controller:'topUpRelationDetailsCtrl'
    })
    /********** CR_41 New india top up mediclaim ends ********/

    /***************** Corona Rakshak Policy starts ***** */
    
    .state('coronaKavachPremiumCalc', {
        url: '/coronaKavachPremiumCalc',
        templateUrl: 'partials/productList/coronaKavachPolicy/coronaKavachPremiumCalc.html',
		controller:'coronaKavachPremiumCalcCtrl'
    })
    .state('coronaKavachViewBreakup', {
        url: '/coronaKavachViewBreakup',
        templateUrl: 'partials/productList/coronaKavachPolicy/coronaKavachViewBreakup.html',
		controller:'coronaKavachViewBreakupCtrl'
    })

        /***********CR_0052 starts****************/
    .state('newIndiaPremierMediclaim', {
        url: '/newIndiaPremierMediclaim',
        templateUrl: 'partials/productList/newIndiaPremierMediclaim/premiumCalculator.html',
		controller:'newIndiaPremierMediclaimCtrl'
    })
    /***********CR_0052 ends**********/
    
	.state('quickQuoteTW', {
        url: '/newBusinessLandingScreenTW',
        templateUrl: 'partials/productList/tw/newBusinessLandingScreenTW.html',
		controller:'newBusinessLandingCtrlTW'
    })
	.state('twQuickQuote', {
        url: '/twQuickQuote',
        templateUrl: 'partials/productList/tw/twQuickQuote.html',
		controller:'twoQuickQuoteCtrl'
    })
    .state('twBasicPremiumCal', {
        url: '/twBasicPremiumCal',
        templateUrl: 'partials/productList/tw/twBasicPremiumCal.html'
    })
    .state('twDetailQuote', {
        url: '/twDetailQuote',
        templateUrl: 'partials/productList/tw/twDetailQuote.html'
    })	
	 .state('createPolicyHolder', {
        url: '/createPolicyHolder',
        templateUrl: 'partials/productList/tw/createPolicyHolder.html',
		controller:'twcreatePolicyHolderCtrl'
    })	
    .state('twSummaryDetails', {
        url: '/twSummaryDetails',
        templateUrl: 'partials/productList/tw/twSummaryDetails.html',
		controller:'twSummaryDetailsCtrl'
    })
	
	/*Start CR_3621*/
	.state('StandaloneODMotorTW', {
        url: '/newBusinessLandingScreenSQ',
        templateUrl: 'partials/productList/sq/newBusinessLandingScreenSQ.html',
		controller:'newBusinessLandingCtrlSQ'
    })
	
	.state('sqQuickQuote', {
        url: '/sqQuickQuote',
        templateUrl: 'partials/productList/sq/sqQuickQuote.html',
		controller:'sqQuickQuoteCtrl'
    })
	
	  .state('sqBasicPremiumCal', {
        url: '/sqBasicPremiumCal',
        templateUrl: 'partials/productList/sq/sqBasicPremiumCal.html'
    })
	
	.state('sqDetailQuote', {
        url: '/sqDetailQuote',
        templateUrl: 'partials/productList/sq/sqDetailQuote.html'
    })
	
	.state('sqcreatePolicyHolder', {
        url: '/sqcreatePolicyHolder',
        templateUrl: 'partials/productList/sq/sqcreatePolicyHolder.html',
		controller:'sqcreatePolicyHolderCtrl'
    })
	
	.state('sqSummaryDetails', {
        url: '/sqSummaryDetails',
        templateUrl: 'partials/productList/sq/sqSummaryDetails.html',
		controller:'sqSummaryDetailsCtrl'
    })
	
	.state('standaloneODDetails', {
        url: '/standaloneODDetails',
        templateUrl: 'partials/productList/sq/standaloneODDetails.html',
		controller:'standaloneODDetailsCtrl'
    })
	
	/*end CR_3621*/
	
	/**CR44, CR43 and CR45 Starts **/
	.state('newIndiaFloaterMediclaim', {
        url: '/newIndiaFloaterMediclaim',
        templateUrl: 'partials/productList/newIndiaFloater/newIndiaFloaterMediclaim.html',
		controller:'productCntrl'
    })
	.state('premiumCalculatorHealth', {
        url: '/premiumCalculatorHealth',
        templateUrl: 'partials/productList/commonTemplate/premiumCalculatorHealth.html',
		controller:'premCalCntrl'
    })
	.state('floaterBasicPremium', {
        url: '/floaterBasicPremium',
        templateUrl: 'partials/productList/newIndiaFloater/floaterBasicPremium.html',
		controller:'floaterBasicPremiumCtrl'
    })
	.state('floaterViewBreakUp', {
        url: '/healthViewBreakUpScreen',
        templateUrl: 'partials/productList/newIndiaFloater/floaterViewBreakUp.html',
		controller:'healthViewbreakUpCtrl'
    })
	.state('policyHolderInformation', {
        url: '/policyHolderInformation',
        templateUrl: 'partials/productList/commonTemplate/policyHolderInformation.html',
		controller:'policyHolderCtrl'
    })
	.state('proposerDetailsHealth', {
        url: '/proposerDetailsHealth',
        templateUrl: 'partials/productList/commonTemplate/proposerDetailsHealth.html',
		controller:'proposerDetailsHealthCtrl'
    })
	.state('policyPeriodAndNomineeDetailsHealth', {
        url: '/policyPeriodAndNomineeDetailsHealth',
        templateUrl: 'partials/productList/commonTemplate/policyPeriodAndNomineeDetailsHealth.html',
		controller:'nomineeAndRelationDetailsCtrl'
    })
    .state('policyPeriodAndNomineeDetailsHealthCancer', {   // CR_3725
        url: '/policyPeriodAndNomineeDetailsHealthCancer',
        templateUrl: 'partials/productList/newIndiaCancerGuardPolicy/policyPeriodAndNomineeDetailsHealthCancer.html',
		controller:'nomineeAndRelationDetailsCtrl'
    })
	.state('relationDetails', {
        url: '/relationDetails',
        templateUrl: 'partials/productList/commonTemplate/relationDetails.html',
		controller:'nomineeAndRelationDetailsCtrl'
    })
	.state('reviewSummaryScreen', {
        url: '/reviewSummaryScreen',
        templateUrl: 'partials/productList/commonTemplate/reviewSummaryScreen.html',
		controller:'reviewSummaryHealthCtrl'
    })
	.state('premiumCalculatorUK', {
        url: '/premiumCalculatorUK',
        templateUrl: 'partials/productList/newIndiaMediclaim/premiumCalculator.html',
		controller:'newIndiaMediclaimController'
    })
    //CR_3725 start
    .state('premiumCalculatorCJ', {
        url: '/premiumCalculatorCJ',
        templateUrl: 'partials/productList/newIndiaCancerGuardPolicy/cancerGuardPremiumCalculator.html',
		controller:'newIndiaCancerGuardController'
    })
    //CR_3725 End
    //CR_0044 start
	.state('additionalCovers', {
        url: '/additionalCovers',
        templateUrl: 'partials/productList/newIndiaMediclaim/additionalCovers.html',
		controller:'proposerDetailsHealthCtrl'
    })
    //CR_0044 End
    .state('PolicyPeriodNomineeDetails', {
        url: '/PolicyPeriodNomineeDetails',
        templateUrl: 'partials/productList/newIndiaMediclaim/PolicyPeriodNomineeDetails.html',
		controller:'nomineeAndRelationDetailsCtrl'
    })
	.state('docUpload', {
        url: '/docUpload',
        templateUrl: 'partials/productList/newIndiaMediclaim/docUpload.html',
		controller:'docUploadCtrl'
    })
	/******CR_3626*********/
	.state('newEndorsementRequest', {
    	 url: '/newEndorsementRequest',  
         templateUrl: 'partials/managePolicies/newEndroseMntReq.html',
 		controller:'endorsementRequestController'
    })
	
    /*start CR_3439*/
    .state('standaloneCPAProduct', {
    	 url: '/SOProduct',  
         templateUrl: 'partials/productList/so/SOProduct.html',
 		controller:'newSOProductCtrl'
    })
    .state('soDetailQuote', {
        url: '/soDetailQuote',
        templateUrl: 'partials/productList/so/soDetailQuote.html',
		controller:'soDetailQuoteCtrl'
    })
	.state('basicPremiumSO', {
        url: '/basicPremiumSO',
        templateUrl: 'partials/productList/so/basicPremiumSO.html',
		controller:'basicPremiumSOCtrl'
    })
	.state('soAdditionalDetails', {
        url: '/soAdditionalDetails',
        templateUrl: 'partials/productList/so/soAdditionalDetails.html',
		controller:'soAdditionalDetailsCtrl'
    })	
	.state('soSummaryDetails', {
        url: '/soSummaryDetails',
        templateUrl: 'partials/productList/so/soSummaryDetails.html',
		controller:'soSummaryDetailsCtrl'
    })
    /*end CR_3439*/
    /* CR NP_CR_3546 starts */
    .state('showCart', {
        url: '/showCart',
        templateUrl: 'partials/showCart.html',
		controller:'showCartCtrl'
    });
    /* CR NP_CR_3546 end */
}]);



agentApp.run(['RestServices','CommonServices','$rootScope', function(RestServices,CommonServices,$rootScope) {
    // $rootScope.$on('$stateChangeStart', function(e, toState, toParams, fromState, fromParams) {
    //     console.log(toState);
    //     console.log(toParams);
    //     console.log(fromState);
    //     console.log(fromParams);
    // });

    window.appRootDirName = "NIAAgentDoc";
	if (!(navigator.userAgent.match(/(iPad)|(iPhone)|(android)/i))) {
        if (navigator.onLine) {
            RestServices.checkVersion();  
        }
	}
	else{
		document.addEventListener("deviceready", onDeviceReady, true);

    }          
     function onDeviceReady() {
  
          /*Implement for CR_3693*/
  
          device.getInfo(function(details){
              //CommonServices.fcmRefreshToken = details.fcmToken;
              CommonServices.versionNo = details.appVersion;
              RestServices.checkVersion();
          },function(err){
              console.log(err);
          })
  
          CommonServices.setCommonData("vesionCheck",false);
          document.addEventListener("resume", callCheckVersion, false);
          document.addEventListener("online", callCheckVersion, false); 
          document.addEventListener("backbutton", backKeyDown, false);
          window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, gotFS, fail);
          if (navigator.onLine) {
              RestServices.checkVersion();  
          }
  
      }
	function callCheckVersion() {

            if(!CommonServices.getCommonData("vesionCheck")){

                RestServices.checkVersion();
            }
        }



		  
	function backKeyDown(e) {

		var screen= $(".agentPage").attr("id");

		if($("#cal-screen-overlay").is(":visible")){
			$("#cal-screen-overlay").trigger("click");
			return;
		}
		if( $("#loader").is(":visible") ){
			return;
		}
		if( $(".modal").is(":visible") ){
		    if(screen === "newRenewPolicyModule-screen"){
		        $(".overlay").trigger("click");
		    } else{
		         $(".overlay").trigger("click");
                 $(".close_icon").trigger("click");
		    }
        	return;
        }
		if( $(".contactModal").is(":visible") ){
		    $(".overlay").trigger("click");
		    $(".close_icon").trigger("click");
        	return;
        }
		
		if(screen=="login-screen"){
			navigator.notification.confirm("Are you sure you want to exit?", exitFunction, "Confirm", ["OK", "Cancel"]);
			
		}
		else if(screen=="landing-screen"){
			$(".logout").trigger("click");
		}
		else{
		    $(".back").attr("data-click","back");
			$(".back").trigger("click");
		}
	}
	
	function fail() {
        console.log("failed to get filesystem");
    }

    function gotFS(fileSystem) {
        window.fileSystem = fileSystem;
        fileSystem.root.getDirectory(window.appRootDirName, {
            create: true,
            exclusive: false
        }, dirReady, fail);
    }

    function dirReady(entry) {
        window.appRootDir = entry;

    }
	
	function exitFunction(button) {
		if (button == 1) {
			navigator.app.exitApp();
		}
	}
}]);

function getFormattedDate(date) {
    var year = date.getFullYear();
    var month = (1 + date.getMonth()).toString();
    month = month.length > 1 ? month : '0' + month;
    var day = date.getDate().toString();
    day = day.length > 1 ? day : '0' + day;
    return month + '/' + day + '/' + year;
}

function getCurrentDate() {
    var date = new Date();
    var year = date.getFullYear();
    var month = (1 + date.getMonth()).toString();
    month = month.length > 1 ? month : '0' + month;
    var day = date.getDate().toString();
    day = day.length > 1 ? day : '0' + day;
    return day + '/' + month + '/' + year;
}

/** Output date string in dd/mm/yyyy format */
function convertDateToText(date) {
    var year = date.getFullYear();
    var month = (1 + date.getMonth()).toString();
    month = month.length > 1 ? month : '0' + month;
    var day = date.getDate().toString();
    day = day.length > 1 ? day : '0' + day;
    return day + '/' + month + '/' + year;
}

/** Output date object by converting date string in dd/mm/yyyy format */
function convertTextToDate(dateStr) {
    if (!dateStr) return null;
    var tokens = dateStr.split('/');
    if (tokens.length != 3) return null;
    return new Date(parseInt(tokens[2]), parseInt(tokens[1]) - 1, parseInt(tokens[0]), 0, 0, 0, 0);
}

/** Reset time (Hours, Minutes, Seconds) of date object and return a new date object */
function resetTime(date) {
    return new Date(date.setHours(0, 0, 0, 0));
}

/** Calculates age from date of birth */
function calculateAge(dateOfBirthStr) {
    var dateOfBirth = convertTextToDate(dateOfBirthStr);
    if (!dateOfBirth) { return 0; }
    var today = new Date();
    var age = today.getFullYear() - dateOfBirth.getFullYear();
    if (today.getMonth() < dateOfBirth.getMonth() || (today.getMonth() == dateOfBirth.getMonth() && today.getDate() < dateOfBirth.getDate())) {
      age--;
    }
    return age;
}

        
    //CR3746
    function isNIAPANNo(panNo) {
        var isNIAPAN = false;
        // if(panNo.length==10){                Removal of CR_3746
        //     if(regexPanNoGlobal.test(panNo.toUpperCase())){
        //         if(panNo.toUpperCase() == NIAPanNo)
        //             isNIAPAN = true;
        //         else
        //             isNIAPAN = false;
        // }
        // }else
        //     isNIAPAN = false;
            
            return isNIAPAN;
    };
     //CR3746


     agentApp.filter('titleCase', [function () {
        return function (input) {
      
          if (typeof input !== "string") {
            return input;
          }
      
          return input.split(/(?=[A-Z])/).map(inp => inp.charAt(0).toUpperCase() + inp.slice(1)).join(' ');
        };
    }])