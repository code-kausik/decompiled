

agentApp.controller('newSOProductCtrl', ['$scope', '$rootScope', 'CommonServices', 'RestServices', '$location', '$state', function ($scope, $rootScope, CommonServices, RestServices, $location, $state) {

	$scope.goBack = function () {
		
		if (CommonServices.isLoggedIn === true) {
			//$state.go('newBusinessMotorLandingScreen');
		}
		else {
			CommonServices.setCommonData("selectedProduct", 'motor');
			$state.go('buyNowSubLandingScreen');
		}
	}
	CommonServices.getDomainValues();
	// CommonServices.getStateDomainValues();

	$scope.getDefaultRelation = function () {
    	var getDefaultRelationInput;
		if (CommonServices.getCommonData("channel") === "MISP") {
			getDefaultRelationInput = { "partyDetails": { "partyCode": "" }, "userProfile": { "userId": CommonServices.getCommonData("userId"), "loggedInRole": CommonServices.getCommonData("loggedInRole"), "channel": CommonServices.getCommonData("channel") } };
		}
		else {
			getDefaultRelationInput = { "userProfile": { "userId": CommonServices.getCommonData("userId"), "loggedInRole": "SUPERUSER", "stakeCode": CommonServices.getCommonData("stakeCode") } };
		}
		var getDefaultRelationResponse;
		if (CommonServices.getCommonData("channel") === "MISP") {
			getDefaultRelationResponse = RestServices.postService(RestServices.urlPathsNewPortal.getMISPRelations, getDefaultRelationInput);
		} else {
			getDefaultRelationResponse = RestServices.postService(RestServices.urlPathsNewPortal.getDefaultRelation, getDefaultRelationInput);
		}
getDefaultRelationResponse.then(
			function (response) {
				CommonServices.showLoading(false);
				if (response.data.partyDetailsList !== undefined && response.data.partyDetailsList !== "") {
					CommonServices.setCommonData("defaultRelationResponse", response.data.partyDetailsList);
				}
				else {
					CommonServices.showAlert(response.data.userProfile.footer.errorMessage);
				}


			}, function (error) {
				CommonServices.showLoading(false);
				RestServices.handleWebServiceError(error);
			});
	}

	$scope.buyInsuranceSO = function () {

		$rootScope.buyNow.twoWheeler.newVehicle = "";
		$rootScope.buyNow.twoWheeler.quickQuote = {};
		$rootScope.buyNow.twoWheeler.basicPremium = {};
		$rootScope.buyNow.twoWheeler.additionalDetails = {};
		$rootScope.buyNow.twoWheeler.ncbDetails = {};
		$rootScope.buyNow.twoWheeler.addCovers = {};
		$rootScope.buyNow.twoWheeler.prevPolicyDetails = {};
		$rootScope.buyNow.twoWheeler.financierDetails = {};
		$rootScope.buyNow.twoWheeler.insuredDetails = {};
		$rootScope.buyNow.twoWheeler.summaryDetails = {};
		$rootScope.buyNow.twoWheeler.isAgentRequired = "";
		$rootScope.buyNow.twoWheeler.relationDetails = {};

		$rootScope.buyNow.twoWheeler.newVehicle = true;
		if (CommonServices.getCommonData("stakeCode") === "DEALER") {
			$scope.getDefaultRelation();
		}

		$state.go('soDetailQuote');
	}

	$scope.renewInsuranceSO = function () {

		$rootScope.buyNow.twoWheeler.newVehicle = "";
		$rootScope.buyNow.twoWheeler.quickQuote = {};
		$rootScope.buyNow.twoWheeler.basicPremium = {};
		$rootScope.buyNow.twoWheeler.additionalDetails = {};
		$rootScope.buyNow.twoWheeler.ncbDetails = {};
		$rootScope.buyNow.twoWheeler.addCovers = {};
		$rootScope.buyNow.twoWheeler.prevPolicyDetails = {};
		$rootScope.buyNow.twoWheeler.financierDetails = {};
		$rootScope.buyNow.twoWheeler.insuredDetails = {};
		$rootScope.buyNow.twoWheeler.summaryDetails = {};

		$rootScope.buyNow.twoWheeler.newVehicle = false;
		if (CommonServices.getCommonData("stakeCode") === "DEALER") {
			$scope.getDefaultRelation();
		}
		$state.go('soDetailQuote');

	}

	//Product Domain Values Service Call Start
	var inputTWData = {
		"productCode": "TW", "lngCode": "EN", "keys": ["VEHICLE_COLOR", "FUEL_TYPE", "COVERAGE_TYPE",
			"COVERAGE_TYPE_SECOND_YEAR", "COVERAGE_TYPE_THIRD_YEAR", "COVERAGE_TYPE_SECOND_YEAR_CSC", "COVERAGE_TYPE_THIRD_YEAR_CSC",
			"OWN_DRIVER_LICENSE_TYPE", "VOLUNTARY_EXCESS", "LIABILITY_DURATION", "COVERAGE_TYPE_CSC"]
	};

	CommonServices.getProductDomainValues(inputTWData);
	//Product Domain Values Service Call End

}]);




agentApp.controller('soDetailQuoteCtrl', ['$scope', '$rootScope', 'CommonServices', 'RestServices', 'GetSetResponseService', '$location', '$state', '$timeout', function ($scope, $rootScope, CommonServices, RestServices, GetSetResponseService, $location, $state, $timeout) {
	var mydateStr = CommonServices.getCommonData("serverDate");
	var mynewdateFrom = "";
	
		$scope.goBack = function () {
		
		if (CommonServices.isLoggedIn === true) {
			//$state.go('newBusinessMotorLandingScreen');
		}
		else {
			CommonServices.setCommonData("selectedProduct", 'motor');
			$state.go('standaloneCPAProduct');
		}
	}
 
	
	
	if (mydateStr != undefined) {
		mynewdateFrom = new Date(mydateStr);
	}
	else {
		mynewdateFrom = new Date();
	}
	/****for loading calender*****/
	/** Set Proposer, Spouse, Parent DOB**/
	var enableProposerDOBCalMin = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 18));
    enableProposerDOBCalMin = new Date(enableProposerDOBCalMin.setDate(enableProposerDOBCalMin.getDate()));
	enableProposerDOBCalMin = getFormattedDate(enableProposerDOBCalMin);
	
	
	/** Set Calender range for proposer, spouse, child and parent **/
	var enableProposerDOBCalfrom = getFormattedDate(mynewdateFrom);
	var enableProposerDOBCalTo =new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 70));
	/**Proposer DOB**/
	$('#proposerDateOfBirth').loadCalendar({
		'enableDateRange': true,
		'enableCalendarFrom': enableProposerDOBCalTo,
		'enableCalendarTo': enableProposerDOBCalMin
	});

	/******loading calender end********/

	var dd = mynewdateFrom.getDate();
	var mm = mynewdateFrom.getMonth() + 1;
	var yyyy = mynewdateFrom.getFullYear();
	
	var futureDate = new Date(yyyy+1,mm-1,dd-1);
	
	if (dd < 10) {
		dd = "0" + dd;
	}
	if (mm < 10) {
		mm = "0" + mm;
	}
	$scope.startDate=dd + "/" + mm + "/" + yyyy;
	
	
	//var futureDate = new Date(new Date().setDate(mynewdateFrom.getFullYear() +1));
	var dd = futureDate.getDate();
	var mm = futureDate.getMonth() + 1;
	var yyyy = futureDate.getFullYear();

	if (dd < 10) {
		dd = "0" + dd;
	}
	if (mm < 10) {
		mm = "0" + mm;
	}
	$scope.endDate = dd + "/" + mm + "/" + yyyy;//mm/dd/yyyy date till yesterday
    $scope.proposerDateOfBirth="";
	
	$scope.sumInsured=1500000;
	$scope.disabilityYes="N";
	
	
    
	
	$scope.calculateAge= function(){
			    
		var dt1 = $scope.proposerDateOfBirth.split('/');
			
		var birthDateComp = dt1[1] + '/' + dt1[0] + '/' + dt1[2]; //mm/dd/yyyy
		$scope.dateOfBirth=dt1[0] + '/' + dt1[1] + '/' + dt1[2];
		birthDate = new Date(birthDateComp);
		otherDate = mynewdateFrom;
		var years = (otherDate.getFullYear() - birthDate.getFullYear());
		/*if (otherDate.getMonth() == birthDate.getMonth() && birthDate.getDate() < otherDate.getDate()) {
			 years--;

		}*/
	
		if(years<18)
		{
			alert("Age cann't be less than 18")
			$scope.proposerDateOfBirth="";
		}
		else if(years>70)
		{
			alert("Age cann't be more than 70")
			$scope.proposerDateOfBirth="";
		}
		else
		{
		  $scope.age=years;
		}
		
		
	};
	 $scope.showadd = function() {
	 var selectedRadioBotton=$scope.disabilityYes;
			if(selectedRadioBotton==='Y'){
			//alert('Cover in respect of physically challenged / Differently Abled individuals is not provided online. Please contact Nearest New India Assurance office for more details');
			var msg = 'Cover in respect of physically challenged / Differently Abled individuals is not provided online. Please contact Nearest New India Assurance office for more details'
			CommonServices.messageModal('info', msg, false, '', 'Ok',function () {}, function () {}, 'Alert');
		}
           
		  
        };	
		
		$scope.ageCalculation=function(){
		
		}
		
	
	
	$scope.calCulatePremium=function ()
	{
		//alert("calculate premium called");
		
    $rootScope.age=$scope.age;
	$rootScope.startDate=$scope.startDate;
	$rootScope.endDate=$scope.endDate;
	$rootScope.dateOfBirth=$scope.dateOfBirth;
	$rootScope.sumInsured=$scope.sumInsured;
	
		
		 var data={  
				   "quote":{  
					  "risks":[  
						 {  
							"riskdetails":{  
							   "dateOfBirth":$scope.dateOfBirth,
							   "ageOfMember":$scope.age,
							   "physicalDefects":"N",
							   "relationPolicyHolder":"Proposer"
							},
							"cover":[  
							   {  
								  "si":$scope.sumInsured
							   }
							]
						 }
					  ],
					  "quoteNumber":null,
					  "productCode":"SO",
					  "policyStartDate":$scope.startDate,
					  "policyExpiryDate":$scope.endDate,
					  "mobileNo":null,
					  "emailId":null,
					  "progressLevel":null
				   },
				   "userProfile":{  
					  "userId":CommonServices.getCommonData("userId"),
					  "loggedInRole":"SUPERUSER"
				   }
				}
				
				var calculatePremiumResponse = RestServices.postService(RestServices.urlPathsNewPortal.cpaCalculatePremium,data);

		calculatePremiumResponse.then(
			function (response) {

				if (response.data.userProfile.footer.errorCode == 960) {
					CommonServices.showAlert(response.data.errorMessage);
					CommonServices.showLoading(false);
				}
				if (response.data.userProfile.footer.errorCode == 959) {
					CommonServices.showAlert("Could not connect to server.Please try after some time", "Alert");
					CommonServices.showLoading(false);
				} else if (response.data.userProfile.footer.errorCode == 0) {
					//GetSetResponseService.addQuickQuoteDetailResponseData(response.data);
					CommonServices.setCommonData("quickQuoteNumber", response.data);
					
					$state.go('basicPremiumSO');
				} else {
					CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
				}
				CommonServices.showLoading(false);
			}, function (error) {
				CommonServices.showLoading(false);
				RestServices.handleWebServiceError(error);
			});
				
				

		
	};
	
}]);


agentApp.controller('basicPremiumSOCtrl', ['$scope', '$rootScope', 'CommonServices', 'RestServices', '$location', '$state', function ($scope, $rootScope, CommonServices, RestServices, $location, $state) {
var basicPremium=CommonServices.getCommonData('quickQuoteNumber');
console.log("basicPremium"+JSON.stringify(basicPremium));
$scope.basicPremium=basicPremium;
$scope.totalSI=$rootScope.sumInsured;



$scope.topUpViewBreakCntBtn = function () {

$state.go('soAdditionalDetails');
}

	$scope.goBack = function () {
		
		if (CommonServices.isLoggedIn === true) {
			//$state.go('newBusinessMotorLandingScreen');
		}
		else {
			CommonServices.setCommonData("selectedProduct", 'motor');
			$state.go('soDetailQuote');
		}
	}
	
	/****************added for view breakup*****************/
$scope.viewBreakupShow = false;
	$scope.closePopup = function () {
		$scope.viewBreakupShow = false;
	};
	$scope.hideModal = function () {
		$scope.viewBreakupShow = false;
	};
	$scope.viewBreakup = function () {
		var viewBreakupData =
			{
				"quote": { "quoteNumber": $scope.basicPremium.quote.quoteNumber, "policyHolderCode":"" },
				"userProfile": { "userId": CommonServices.getCommonData("userId"), "loggedInRole": "SUPERUSER" }
			};

		var viewBreakupResponse = RestServices.postService(RestServices.urlPathsNewPortal.getPremiumDistribution, viewBreakupData);
		viewBreakupResponse.then(
			function (response) { // success 
				CommonServices.showLoading(false);
				if (response.data.quote !== undefined && response.data.quote !== "") {
					//Will navigate to billdesk page.

					if (response.data.quote.premiumDetails !== undefined && response.data.quote.premiumDetails !== "") {
						$scope.viewBreakupShow = true;
						$scope.premiumDetails = response.data.quote.premiumDetails;
					}

				} else {
					CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
				}
			},
			function (error) { // failure
				CommonServices.showLoading(false);
				RestServices.handleWebServiceError(error);
			});
	}
	









/************ end of view breakup*****************/
	
	
	




}]);


agentApp.controller('soSummaryDetailsCtrl', ['$scope', '$rootScope', 'CommonServices', 'RestServices', 'GetSetResponseService','$location', '$state','CartServices', function ($scope, $rootScope, CommonServices, RestServices,GetSetResponseService, $location, $state, CartServices) {

//alert("summaryDeatilsController called");
$scope.onload = function () {
		$scope.saveQuoteResponseGS = GetSetResponseService.getsaveQuoteResponseDataGS();
		console.log("saveQuoteResponseGS"+JSON.stringify($scope.saveQuoteResponseGS));
		$scope.selectedOptionDomainvalue = $rootScope.selectedOptionDomainValuesGs;
		$scope.enteredData = CommonServices.getCommonData("saveQuoteInput");
		$scope.agentRequiredValueInSummary = CommonServices.getCommonData("agentRequiredValueGs");
		//$scope.selectedOptionIndex = CommonServices.selectedOptionIndex;
		//console.log(JSON.stringify($scope.enteredData));

		// To get the data in Summary Screen
		//$scope.selectedJewelleryDetailsForSummary = $scope.saveQuoteResponseGS[0].quote.risks[0].coverage.jewelleryCover.coverDetails[0];

		if ($scope.saveQuoteResponseGS[0].quote.premiumDetails.serviceTax === undefined || $scope.saveQuoteResponseGS[0].quote.premiumDetails.serviceTax === "") {
			$scope.saveQuoteResponseGS[0].quote.premiumDetails.serviceTax = $scope.saveQuoteResponseGS[0].quote.premiumDetails.netPremium - $scope.saveQuoteResponseGS[0].quote.premiumDetails.grossPremium;
		}
	}

	$scope.goBack = function () {
		$rootScope.backNavigationFromSummaryGs = true;
		$state.go('soAdditionalDetails');
	}

	/* for accordian ----------------------*/
	var acc = document.getElementsByClassName("accordion");
	var i;

	for (i = 0; i < acc.length; i++) {
		acc[i].onclick = function () {
			this.classList.toggle("active");
			var panel = this.nextElementSibling;
			if (panel.style.display === "block") {
				panel.style.display = "none";
			} else {
				panel.style.display = "block";
			}

		}
	}
	/* accordian ends ----------------------*/

	$scope.onload();
	
	/****************added for view breakup*****************/
$scope.viewBreakupShow = false;
	$scope.closePopup = function () {
		$scope.viewBreakupShow = false;
	};
	$scope.hideModal = function () {
		$scope.viewBreakupShow = false;
	};
	$scope.viewBreakup = function () {
		var viewBreakupData =
			{
				"quote": { "quoteNumber":$scope.saveQuoteResponseGS[0].quote.quoteNumber, "policyHolderCode":"" },
				"userProfile": { "userId": CommonServices.getCommonData("userId"), "loggedInRole": "SUPERUSER" }
			};

		var viewBreakupResponse = RestServices.postService(RestServices.urlPathsNewPortal.getPremiumDistribution, viewBreakupData);
		viewBreakupResponse.then(
			function (response) { // success 
				CommonServices.showLoading(false);
				if (response.data.quote !== undefined && response.data.quote !== "") {
					//Will navigate to billdesk page.

					if (response.data.quote.premiumDetails !== undefined && response.data.quote.premiumDetails !== "") {
						$scope.viewBreakupShow = true;
						$scope.premiumDetails = response.data.quote.premiumDetails;
					}

				} else {
					CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
				}
			},
			function (error) { // failure
				CommonServices.showLoading(false);
				RestServices.handleWebServiceError(error);
			});
	}
	









/************ end of view breakup*****************/
	
	
	
	
	
	
	
	
	

	$scope.approveQuoteGS = function (type = '') {

		var msg = "Do you wish to proceed with approval of quotation? Once Approved, no more changes will be made available on your quotation. Your payment should be made by " + $rootScope.policyStartDateGs + " 23:59:59. Please confirm";
			CommonServices.messageModal('info', msg, false, 'Cancel', 'Ok', function () {
				// $scope.exitFunction(2);
			}, function () {
				$scope.exitFunction(1);
			}, 'Alert');
			CommonServices.setCommonData("addToCart", type); // CR3546



		// CommonServices.deviceType = "NA";
		// if (CommonServices.deviceType !== "NA")
		// 	navigator.notification.confirm("Do you wish to proceed with approval of quotation? Once Approved, no more changes will be made available on your quotation. Your payment should be made by " + $rootScope.policyStartDateGs + " 23:59:59. Please confirm.", $scope.exitFunction, "Alert", ["Confirm", "Cancel"]);
		// else {
		// 	var approvePayment;
		// 	approvePayment = confirm("Do you wish to proceed with approval of quotation? Once Approved, no more changes will be made available on your quotation. Your payment should be made by " + $rootScope.policyStartDateGs + " 23:59:59. Please confirm.");
		// 	if (approvePayment === true) {
		// 		$scope.exitFunction(1);
		// 	}
		// }
	}

	$scope.exitFunction = function (button) {
		if (button == 1) {

			var approvePayData = {
				"userProfile": { "userId": CommonServices.getCommonData("userId"), "loggedInRole": "SUPERUSER", "uiFlow": "NON_CUSTOMER" },
				"quote": { "quoteNumber": $scope.saveQuoteResponseGS[0].quote.quoteNumber, "policyType": null, "productCode": "SO" }
			};
				
			if (CommonServices.getCommonData("addToCart")==='cart') { // CR3546
				CartServices.approveAndAddToCart(approvePayData, "SO");
				return;
			}

			var approvePayResponse = RestServices.postService(RestServices.urlPathsNewPortal.approveRenewedQuote, approvePayData);
			approvePayResponse.then(
				function (response) { // success 
					CommonServices.setCommonData("productCode", "SO");
					CommonServices.showLoading(false);
					// if (response.data.userProfile.footer.errorDescription.trim() === "Proposal Approved") {
					// 	//Will navigate to billdesk page.
					// 	var msg = response.data.userProfile.footer.errorDescription;
					// 		CommonServices.messageModal('info', msg, false, 'Cancel', 'Confirm', function () {
					// 			approvePayExitFunction(2);
					// 		}, function () {
					// 			approvePayExitFunction(1);
					// 		}, 'Alert');
					// 	}
						if (response.data.userProfile.footer.errorDescription.trim() === "Proposal Approved") {
							//Will navigate to billdesk page.
							var msg = response.data.userProfile.footer.errorDescription;
								CommonServices.messageModal('info', msg, false, '', 'Ok', function () {}, function () {
									approvePayExitFunction(1);
								}, 'Alert');
							// if (CommonServices.deviceType !== "NA")
							// 	navigator.notification.confirm(response.data.userProfile.footer.errorDescription, approvePayExitFunction, "Alert", ["Ok"]);
							// else {
							// 	var approvePayment;
							// 	approvePayment = confirm(response.data.userProfile.footer.errorDescription);
							// 	if (approvePayment === true) {
							// 		approvePayExitFunction(1);
							// 	}
							// }
							}
					 else {
						CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
					}
				},
				
				function (error) { // failure
					CommonServices.showLoading(false);
					RestServices.handleWebServiceError(error);
				});
		}
	}
	function approvePayExitFunction(button) {
	CommonServices.setCommonData("CollectionPaymentDetails", $scope.saveQuoteResponseGS[0].quote);
		$state.go("collectionForm");
		};

}]);


agentApp.controller('soAdditionalDetailsCtrl', ['$scope', '$rootScope', 'CommonServices', 'RestServices','GetSetResponseService', '$location', '$state', function ($scope, $rootScope, CommonServices, RestServices,GetSetResponseService, $location, $state) {

$scope.showPolicyHolder = true;

//$scope.discountAmount=0;
//$scope.loadingAmount=0;
$scope.isVisibleDiscAmt=true;
$scope.isVisibleLoadAmt=true;
/*$scope.countryErr = false;//3712*/
/*$scope.nationalityEmpty = true;  //CR 3712*/

$scope.amount= function(){
	if($scope.policyHolderCreate.discountAmount!=0 && $scope.policyHolderCreate.discountAmount>0){
	$scope.isVisibleLoadAmt=false;	
	}else {$scope.isVisibleLoadAmt=true;}
	
	if($scope.policyHolderCreate.loadingAmount!=0 && $scope.policyHolderCreate.loadingAmount>0){
	$scope.isVisibleDiscAmt=false;	
	}else {$scope.isVisibleDiscAmt=true;}
}
    $scope.licenseIssueDateData="";
	$scope.licenseExpiryDateData="";
	$scope.disabilityYesNo="Y";
	
	/*****calender initialization*******/
	
	var mydateStr = CommonServices.getCommonData("serverDate");
	var mynewdateFrom = "";
	if (mydateStr != undefined) {
		mynewdateFrom = new Date(mydateStr);
	}
	else {
		mynewdateFrom = new Date();
	}


	if(CommonServices.gstIdStateCode == '' || CommonServices.gstIdStateCode == undefined){
		CommonServices.getStateDomainValues();
	}
	/*CR 3712 starts
	$scope.isNonIndia = false;
	// $scope.policyDetailsObj.clientNationality ="";
	$scope.onNationalityChange = function(){
		$scope.policyDetailsObj.clientCountry = '';
		if($scope.policyDetailsObj.clientNationality == "NonIndian"){
			$scope.isNonIndia = true;
		}
		else{
			$scope.isNonIndia = false;
		}
	}
	// CR_3712 ends*/
	
	var licenseIssueDatefrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 100));
	licenseIssueDatefrom = new Date(licenseIssueDatefrom.setDate(licenseIssueDatefrom.getDate() + 1));
	licenseIssueDatefrom = getFormattedDate(licenseIssueDatefrom);

	var licenseIssueDateTo = new Date(new Date().setMonth(mynewdateFrom.getMonth()));
	licenseIssueDateTo = new Date(licenseIssueDateTo.setDate(licenseIssueDateTo.getDate()));
	licenseIssueDateTo = getFormattedDate(licenseIssueDateTo);
	/**Date of Birth**/


	$('#licenseIssueDate').loadCalendar({
		'enableDateRange': true,
		'enableCalendarFrom': licenseIssueDatefrom,
		'enableCalendarTo': licenseIssueDateTo
	});
	
	var licenseExpiryDatefrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 100));
	licenseExpiryDatefrom = new Date(licenseExpiryDatefrom.setDate(licenseExpiryDatefrom.getDate() + 1));
	licenseExpiryDatefrom = getFormattedDate(licenseExpiryDatefrom);

	var licenseExpiryDateTo = new Date(new Date().setFullYear(mynewdateFrom.getFullYear()+50));//cr_3439_issue_fix
	licenseExpiryDateTo = new Date(licenseExpiryDateTo.setDate(licenseExpiryDateTo.getDate()));
	licenseExpiryDateTo = getFormattedDate(licenseExpiryDateTo);
	
	/**Date of Birth**/


	$('#licenseExpiryDate').loadCalendar({
		'enableDateRange': true,
		'enableCalendarFrom': mynewdateFrom,
		'enableCalendarTo': licenseExpiryDateTo
	});
	
	
	
	/******end calender initialization******/
		$scope.validDrivingLicense =function(){
	var selectvalidDrivingBotton=$scope.disabilityYesNo;
	if(selectvalidDrivingBotton==='N'){
		var msg = 'Do you hold valid Driving License? can not be selected as No. Please select Yes';
		CommonServices.messageModal('info', msg, false, '', 'Ok', function () {}, function () {}, 'Alert');
		// alert('Do you hold valid Driving License? can not be selected as No. Please select Yes');
			}
	
	};
	
	$scope.validateDateDiff=function()
{
	if($scope.policyHolderCreate.licenseIssueDateData==$scope.policyHolderCreate.licenseExpiryDateData)
	{
		 //alert("License issue and expiry date cann't be same");
		 CommonServices.showAlert("License issue and expiry date can't be same");
		 $scope.policyHolderCreate.licenseIssueDateData="";
	     $scope.policyHolderCreate.licenseExpiryDateData="";
		 return;
	}
};
	
	
	
	
	
         $scope.saveAddditionalDetails=function()
		 {
					  
				/*	if ($scope.policyHolderCreate.loadingAmount === undefined || $scope.policyHolderCreate.loadingAmount === "") {
			$rootScope.policyHolderCreate.loadingAmount = 0;
		}else {
			$rootScope.policyHolderCreate.loadingAmount = $scope.policyHolderCreate.loadingAmount;
		}
		if ($scope.policyHolderCreate.discountAmount === undefined || $scope.policyHolderCreate.discountAmount === "") {
			$rootScope.policyHolderCreate.discountAmount = 0;
		}
		else {
			$rootScope.policyHolderCreate.discountAmount = $scope.policyHolderCreate.discountAmount;
		}*/
	
						  // console.log("json data"+JSON.stringify($rootScope.policyHolderDataGs));
						   //console.log("json data"+$rootScope.dateOfBirth);
						   //console.log("json data"+$rootScope.age);
						   
							var SaveQuoteData={
									   "quote":{
										  "risks":[
											 {
												"riskdetails":{
												   "dateOfBirth":$rootScope.dateOfBirth,
												   "ageOfMember":$rootScope.age,
												   "physicalDefects":"N",
												   "relationPolicyHolder":"Proposer",
												   "nameOfInsured":$scope.policyHolderCreate.sumInsuredName,
												   "validLicense":"Y",
												   "licenseType": $scope.policyHolderCreate.licenseOwnerDriver,
												   "licenseNo": $scope.policyHolderCreate.ownerLicenseNo,
												   "licenseIssueDate": $scope.policyHolderCreate.licenseIssueDateData,
												   "licenseExpiryDate": $scope.policyHolderCreate.licenseExpiryDateData,
												   "licenseAuth":   $scope.policyHolderCreate.licenseIssuingAuthority,
												   "occupationOfMember":$scope.policyHolderCreate.selectOccupation,
												   "relationWithNominee":$scope.policyHolderCreate.relationshipWithInsured,
												   "nomineeName":$scope.policyHolderCreate.nomineeName,
												   "manualDisc": $scope.policyHolderCreate.discountAmount,
												   "manualLoad":$scope.policyHolderCreate.loadingAmount
												},
												"cover":[
												   {
													  "si":$rootScope.sumInsured
												   }
												]
											 }
										  ],
										  "quoteNumber":CommonServices.getCommonData('quickQuoteNumber').quote.quoteNumber,
										  "productCode":"SO",
										  "policyHolderCode":$rootScope.policyHolderDataGs.partyCode,
										  "policyHolderName":$rootScope.policyHolderDataGs.individualDetails.firstName+" "+$rootScope.policyHolderDataGs.individualDetails.lastName,
										  "policyStartDate":$rootScope.startDate,
										  "policyExpiryDate":$rootScope.endDate,
										  "mobileNo":null,
										  "emailId":null,
										  "progressLevel":null
									   },
									   "userProfile":{
										  "userId":CommonServices.getCommonData("userId"),
										  "loggedInRole":"SUPERUSER"
									   }
									}
									
									
		var cpSaveQuoteResponse = RestServices.postService(RestServices.urlPathsNewPortal.cpSaveQuote,SaveQuoteData);

		cpSaveQuoteResponse.then(
			function (response) {

				if (response.data.userProfile.footer.errorCode == 960) {
					CommonServices.showAlert(response.data.errorMessage);
					CommonServices.showLoading(false);
				}
				if (response.data.userProfile.footer.errorCode == 959) {
					CommonServices.showAlert("Could not connect to server.Please try after some time", "Alert");
					CommonServices.showLoading(false);
				} else if (response.data.userProfile.footer.errorCode == 0) {
					//GetSetResponseService.addQuickQuoteDetailResponseData(response.data);
					 GetSetResponseService.addsaveQuoteResponseDataGS(response.data);
					//CommonServices.setCommonData("saveQuoteData", response.data);
					CommonServices.setCommonData("saveQuoteInput", SaveQuoteData);
					//CommonServices.setCommonData("agentRequiredValueGs", $scope.agentRequiredObj.agentRequired);
					CommonServices.setCommonData("CollectionPaymentDetails", response.data.userProfile.footer.quote);
					//alert("quotation saved");
					$state.go('soSummaryDetails');
				} else {
					CommonServices.showAlert(response.data.userProfile.footer.errorDescription);
				}
				CommonServices.showLoading(false);
			}, function (error) {
				CommonServices.showLoading(false);
				RestServices.handleWebServiceError(error);
			});				
									
									
					

						
		 }
		
		var jewellaryMaxLength = 5;
		var jewellaryCount = 1;
		$scope.closeIcon = false;
		var applianceCount = 1;
		var applianceMaxLength = 10;
		$scope.closeApplianceIcon = false;
		var televisionCount = 1;
		var televisionMaxLength = 10;
		$scope.closeTelevisionIcon = false;
		var bankandBranchName;
		$scope.agentRequiredObj = {};
		$scope.date = new Date();
		$scope.agentRequiredObj.agentRequired === false;
		//$scope.jewellery = true;
		/*CR_NP_0880 starts */
		$scope.disablePinCode = true;
		$scope.disableCity = true;
		$scope.stateErr = false;
		$scope.pinCodeErr = false;
		$scope.cityErr = false;
		$scope.gstinMsg = "GSTIN";
		/*CR_MOBL_0054-GS Start */
		$rootScope.polHolRadioClick = false;
		/*CR_MOBL_0054-GS Start */
		if ($rootScope.backNavigationFromSummaryGs == true) {
			$scope.disablePinCode = false;
			// $scope.disableCity = true;
		}
		
		
		
// setTimeout(function () {
			// 	var $carousel = $('.gallery').flickity({
			// 		cellAlign: 'left',
			// 		contain: true,
			// 		draggable: false,
			// 		prevNextButtons: false,
			// 		pageDots: false
			// 	});
				
			// 	// next
			// 	// $('.button--next').on( 'click', function() {
			// 	// 	$carousel.flickity('next');
			// 	// });
			// 	$scope.sliderNext = function () {
			// 		$carousel.flickity('next');
			// 	}

			// }, 5);

			$scope.sliderNext = function () {
				$scope.showPolicyHolder = !$scope.showPolicyHolder;
			}

// $scope.goBack = function () {
// 			$state.go('basicPremiumSO');
// 		};


$scope.goBack = function () {
	// $scope.showFirstSlider = false;
	// 		$scope.showSecondSlider = false;
			
	// if (type == 'backToPolicyHolder') {
	// 	$scope.showFirstSlider = true;
	// } else {
	// 	if (CommonServices.fromRAForEditQuote === true) {
	// 		//navigator.notification.confirm("Are you sure you want to navigate back to premiums screen ? All the saved data will be lost", navigateBack, "Alert", ["Ok", "Cancel"]); 
	// 		navigateBack(1);
	// 	} else {
	if($scope.showPolicyHolder){
			$state.go('basicPremiumSO');
	}
	else{
		$scope.showPolicyHolder = !$scope.showPolicyHolder;
	}
		};
/*
$scope.validateDateDiff=function()
{
   
	if($scope.policyHolderCreate.licenseIssueDateData==$scope.policyHolderCreate.licenseExpiryDateData)
	{
		 alert("License issue and expiry date cann't be same");
		 $scope.policyHolderCreate.licenseIssueDateData="";
	     $scope.policyHolderCreate.licenseExpiryDateData="";
		 return;
	}
	
	policyHolderCreate.licenseExpiryDateData

var licenseIssueDate =$scope.policyHolderCreate.licenseIssueDateData;
var dt1 = this.licenseIssueDate.split('/');

				birthDateComp = dt1[1] + '/' + dt1[0] + '/' + dt1[2]; //mm/dd/yyyy
				alert('dt1[1]'+dt1[1]);
				alert('dt1[0]'+dt1[0]);
				alert('dt1[2]'+dt1[2]);
				birthDateComp = new Date(birthDateComp);
				//Current date
				//var dateOfBirthfrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 18));


$scope.policyHolderCreate.licenseExpiryDateData=$scope.policyHolderCreate.licenseIssueDateData;


}
*/
		

$scope.pinCodeModal = false;
$scope.isNIAPAN = false;//CR3746

//CR3746
$scope.onPANNoChange = function () {
	if($scope.policyDetailsObj.panNo != undefined){
		$scope.policyDetailsObj.panNo = $scope.policyDetailsObj.panNo.toUpperCase();
		$scope.isNIAPAN = isNIAPANNo($scope.policyDetailsObj.panNo);
	}
	else
		$scope.isNIAPAN = false;
};
//CR3746

		/*Added for CR_NP_0744*/
		$scope.regexPanNo = regexPanNoGlobal// /^[A-Za-z]{5}[0-9]{4}[A-Za-z]{1}$/;
		$scope.regexAadhaarInput = /^(?!\1+$)\d{4}$/;
		$scope.regexAadhaarNumber = /^(?!\1+$)\d{12}$/;
		/*CR_NP_0744 ends*/
		var mydateStr = new Date();
		var mynewdateFrom = "";
		if (mydateStr != undefined) {
			mynewdateFrom = new Date(mydateStr);
		}
		else {
			mynewdateFrom = new Date();
		}

		/*Added for CR_NP_0744*/
		var configurationData = CommonServices.getCommonData("ConfigurationData");
		if (configurationData != undefined && configurationData != '') {
			if (configurationData[0].value == "Y") {
				$scope.isPanNumberMandatory = false;
			} else {
				$scope.isPanNumberMandatory = false;
			}
		}
		/*CR_NP_0744 Changes ends*/


		/**Date of Birth**/
		var dateOfBirthfrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 70));
		dateOfBirthfrom = new Date(dateOfBirthfrom.setDate(dateOfBirthfrom.getDate() + 1));
		dateOfBirthfrom = getFormattedDate(dateOfBirthfrom);

		//var dateOfBirthTo = new Date(new Date().setMonth(mynewdateFrom.getMonth()));
		var dateOfBirthTo = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 18));
		dateOfBirthTo = new Date(dateOfBirthTo.setDate(dateOfBirthTo.getDate()));
		dateOfBirthTo = getFormattedDate(dateOfBirthTo);
		/**Date of Birth**/


		setTimeout(function(){ 
			$('#dateOfBirth').loadCalendar({
				'enableDateRange': true,
				'enableCalendarFrom': dateOfBirthfrom,
				'enableCalendarTo': dateOfBirthTo
			});
		 }, 1000);

		 $scope.dateOfBirth = function () {
			$("#dateOfBirth").loadCalendar({
				'enableDateRange': true,
				'enableCalendarFrom': dateOfBirthfrom,
				'enableCalendarTo': dateOfBirthTo
			});
			return true;
		};

		$scope.policyDetailsObj = {
			newcustomerFlag: true,
			existingCustomerFlag: false,
			policyHolder: "newPolicyHolder",
			category: "I",
			showSearchResTbl: false,
			noRecords: null,
			showSmallTbl: false,
			fieldDisable: false,
			existingCustomerBtn: true,
			dateOfBirthErr: false,
			gstRegTypeVal: [{
				id: "NCC",
				name: "Normal,Composite,Casual"
			}, {
				id: "NRI",
				name: "NRI"
			}, {
				id: "UNB",
				name: "UN Bodies/Embassy"
			}],
			dateOfBirthFunc: function () {
				//Entered DOB
				var dt1 = this.dateOfBirth.split('/');
				birthDateComp = dt1[1] + '/' + dt1[0] + '/' + dt1[2]; //mm/dd/yyyy
				birthDateComp = new Date(birthDateComp);
				//Current date
				var dateOfBirthfrom = new Date(new Date().setFullYear(mynewdateFrom.getFullYear() - 18));

				if (birthDateComp > dateOfBirthfrom) {
					this.dateOfBirthErr = true;
					$scope.policyDetailsObj.dateOfBirth = "";
				}
				else {
					this.dateOfBirthErr = false;
				}
			},

			policyHolderFunc: function (data) {
				this.fieldDisable = false;
				this.existingCustomerBtn = true;
				this.showSmallTbl = false;
				this.showSearchResTbl = false;
				/*CR_MOBL_0054-GS Start */
				$rootScope.polHolRadioClick = true;
				/*CR_MOBL_0054-GS Ends*/
				$scope.invalidPolicyHolderForm = false;
				if ($scope.gsCoveredBuildingAddress === true) {
					$scope.gsCoveredBuildingAddress = false;
					$scope.gsBuildingNo = "";
					$scope.gsBuildingLocality = "";
					$scope.gsBuildingPinCode = "";
				}
				if (data === "existingPolicyHolder") {
					this.existingCustomerFlag = true;
					this.newcustomerFlag = false;
					this.partyCode = "";
					this.EfirstName = "";
					this.ElastName = "";
					this.EmobileNumber = "";
					this.EemailID = "";
					// Added as Form is getting valid on select of existingPolicyHolder button
					$scope.invalidPolicyHolderForm = true;
				}
				else if (data === "newPolicyHolder") {
					$scope.partyCode = "";
					/*Added for CR_NP_0744, aadhaar commented for CR_NP_0744E*/
					this.panNoInputDisable = false;
					CommonServices.panNoInputDisable = false;
					/*CR_NP_0744 and CR_NP_0744E Ends*/
					this.newcustomerFlag = true;
					this.existingCustomerFlag = false;
					this.productTitle = "";
					this.firstName = "";
					this.middleName = "";
					this.lastName = "";
					this.gender = "";
					this.dateOfBirth = "";
					/*
					this.clientNationality = ""; //3712
					this.clientCountry = "";//3712
					*/
					this.street = "";
					this.locality = "";
					this.placeOfLoss = "";
					this.mobileNumber = "";
					this.landlineNumber = "";
					this.emailID = "";
					this.panNo = "";
					/*Added for CR_NP_0744*/
					this.aadhaarNumber1 = "";
					this.aadhaarNumber2 = "";
					this.aadhaarNumber3 = "";
					/*CR_NP_0744 Ends*/
					this.accountNo = "";
					this.gstRegID = "";
					this.gstINModel = "";
					this.uinModel = "";
					this.contState = "";
					this.countryCity = "";
				}
			},

			gstIDInputChangeFunc: function () { // Onchange of GSTIN input field
				if (this.gstRegID !== undefined && this.gstRegID !== "") {

					var reg = "";

					if (this.gstINModel != undefined && this.gstINModel === 15) {
						$scope.policyHolderForm.gstIN.$invalid = false;
						$scope.policyHolderForm.$invalid = false;
					}
					else {
						$scope.policyHolderForm.gstIN.$invalid = true;
						$scope.policyHolderForm.$invalid = true;
					}

					if (this.gstRegID === "NCC") {
						reg = regexGSTidGlobal;///^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[A-Z0-9]{2}[^\s]$/;
						//UC for 3749
						// if(CommonServices.gstIdStateCode[this.gstINModel.slice(0,2)] != undefined){
						// 	if($scope.policyDetailsObj.contState.state == CommonServices.gstIdStateCode[this.gstINModel.slice(0,2)]){
						// 		// $scope.policyHolderForm.gstIN.$setValidity("gstStateCode", true);//UC for 3749
						// 		console.log("state code valid");
						// 	}
						// 	else{
						// 		// $scope.policyHolderForm.gstIN.$setValidity("gstStateCode", false);//UC for 3749
						// 		$scope.gstErrorMsg = "Please enter valid GSTIN. State code of GSTIN and the state mentioned in address should match.";	
						// 	}
						// }
						// else{
						// 	$scope.policyHolderForm.gstIN.$setValidity("gstStateCode", false);
						// 	$scope.gstErrorMsg = "Please enter GSTIN with a valid state code";
						// }

					}


					if (this.gstRegID === "NRI") {
						reg = /^[0-9]{12}N[A-Z0-9]{1}T$/;
					}
					if (this.gstRegID === "UNB") {
						reg = /^[0-9]{12}U[A-Z0-9]{1}N$/;
					}

					if (this.gstINModel !== "" || this.gstINModel !== undefined) {
						if (reg === "")
							valid = false;
						else
							valid = reg.test(this.gstINModel.toUpperCase());
					}

					if (this.gstRegID !== undefined && this.gstRegID !== "") {
						$scope.policyHolderForm.$invalid = false;
					}
					else {
						$scope.policyHolderForm.$invalid = true;
					}

					if (valid) {
						$scope.policyHolderForm.gstIN.$setValidity("gstinPattern", true);
						$scope.policyHolderForm.gstIN.$invalid = false;
						$scope.policyHolderForm.$invalid = false;
						$scope.policyHolderForm.gstIN.$setValidity("gstIN", true);
					} else {
						$scope.policyHolderForm.gstIN.$setValidity("gstinPattern", false);
						$scope.policyHolderForm.gstIN.$invalid = true;
						$scope.policyHolderForm.$invalid = true;
						$scope.policyHolderForm.gstIN.$setValidity("gstIN", false);
					}

					// ADDED BY HIMANSHU FOR CR_875
					if (this.gstRegID != undefined && this.gstRegID != '') {
						if (this.gstINModel != undefined) {
							this.gstINModel = this.gstINModel.toUpperCase();
							if (this.gstINModel.includes("AAACN4165C")) {
								$scope.policyHolderForm.gstIN.$setValidity("validateNIAPAN", false);
								$scope.policyHolderForm.$invalid = true;
							} else {
								$scope.policyHolderForm.gstIN.$setValidity("validateNIAPAN", true);
								$scope.policyHolderForm.$invalid = false;

							}
						}
					}

				}

			},
			uinInputChangeFunc: function () { // Onchange of UIN input field
				if (this.uinModel.length === 15) {
					$scope.policyHolderForm.UIN.$invalid = false;
				}
				else {
					$scope.policyHolderForm.UIN.$invalid = true;
				}
			},
			stateServiceCall: function () {// this function is service call for getting state 
				this.stateResponse = RestServices.postService(RestServices.urlPathsNewPortal.getStateList, $scope.stateData);
				return this.stateResponse.then(
					function (response) { // success

						CommonServices.showLoading(false);
						if (response.data.states !== undefined && response.data.states !== "") {
							/*CR_NP_0880 and CR_MOBL_0054-GS Starts */
							if (CommonServices.editQuoteFlag === true && ($rootScope.backNavigationFromSummaryGs == false || $rootScope.backNavigationFromSummaryGs === undefined) && $rootScope.polHolRadioClick === false) {

								console.log($rootScope.policyHolderDataGs);

								for (var i = 0; i < response.data.states.length; i++) {
									if ($rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.state === response.data.states[i].stateCode) {
										$scope.policyDetailsObj.contState = response.data.states[i];
										$rootScope.policyHolderStateIs = response.data.states[i];

										$scope.stateObj = {
											"stateObj": response.data.states[i]
										}
										angular.extend($rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails, $scope.stateObj);

										$scope.searchPincode = { "state": $scope.policyDetailsObj.contState.state, "zipCode": "" };
										$scope.policyDetailsObj.pinCodeServiceCall();
										
										$rootScope.invalidSPCErr = false;
										$scope.policyHolderForm.$invalid = false;
										// $scope.policyHolderForm.$setValidity("$invalid", false);
										return;
									} else {
										$rootScope.invalidSPCErr = true;
										$scope.policyHolderForm.$invalid = true;
										// $scope.policyHolderForm.$setValidity("$invalid", true);
									}
								}
								$scope.stateList = response.data.states;
							} /*CR_MOBL_0054-GS Ends */
							else if ($scope.partyCode !== "" && $scope.partyCode !== undefined) {// if the customer is existing customer																
								response.data.states.filter(function (b) {//this filter will compare the responseState with the response data
									if ($scope.responseState !== "" && $scope.responseState !== undefined && b.stateCode === $scope.responseState) {
										$scope.policyDetailsObj.contState = b;
										$rootScope.policyHolderStateIs = b;
										$scope.responseState = "";
										$scope.searchPincode = { "state": $scope.policyDetailsObj.contState.state, "zipCode": "" };
										$scope.policyDetailsObj.pinCodeServiceCall();
										
										$rootScope.invalidSPCErr = false;
										$scope.policyHolderForm.$invalid = false;
										// $scope.policyHolderForm.$setValidity("$invalid", false);
										return;
									} else {
										$rootScope.invalidSPCErr = true;
										$scope.policyHolderForm.$invalid = true;
										// $scope.policyHolderForm.$setValidity("$invalid", true);
									}

								});
								$scope.stateList = response.data.states;
							}
							else {// if the customer is new customer
								if ($scope.continueState !== "" && $scope.continueState !== undefined) {
									response.data.states.filter(function (b) {
										if (b.stateCode === $scope.continueState) {
											$scope.stateObj = {
												"stateObj": b
											}
										}
									});

									angular.extend($rootScope.policyHolderDataGs.savedPartyDetails.partyDetails, $scope.stateObj);
									if ($scope.stateObj !== undefined && $scope.stateObj !== "") {
										$scope.continueState = "";
										$scope.cityData = { "state": $scope.stateObj.stateObj.state, "zipCode": $scope.continuepinCode, "city": "" };
										$scope.policyDetailsObj.cityServiceCall();
									}
									else {
										CommonServices.showAlert("Please change the state you have entered.");
									}

								}
								$scope.stateData = "";
								$scope.stateList = response.data.states;
							}
							return $scope.stateList;
						} else {
							if (response.data.errorMessage !== undefined && response.data.errorMessage !== "")
								CommonServices.showAlert(response.data.errorMessage);
							else
								// CommonServices.showAlert("No Record Found");
								CommonServices.showAlert("Error Occured. Please try again later");
						}
					},
					function (error) { // failure
						CommonServices.showLoading(false);
						RestServices.handleWebServiceError(error);
					});
				/* CR_NP_0880 ends*/

			},
			pinCodeServiceCall: function () { // this function is service call for getting pincodes
				this.getZipcodeDetailResponse = RestServices.postService(RestServices.urlPathsNewPortal.getZipCodesbyState, $scope.searchPincode);
				return this.getZipcodeDetailResponse.then(
					function (response) { // success 
						/* CR_NP_0880 Starts*/
						CommonServices.showLoading(false);
						if (response.data.pincodes !== undefined && response.data.pincodes !== "") {
							/*CR_MOBL_0054-GS Starts */
							if (CommonServices.editQuoteFlag === true && ($rootScope.backNavigationFromSummaryGs == false || $rootScope.backNavigationFromSummaryGs === undefined) && $rootScope.polHolRadioClick === false) {

								console.log($rootScope.policyHolderDataGs);

								for (var i = 0; i < response.data.pincodes.length; i++) {
									if ($rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.pinCode === response.data.pincodes[i]) {
										$scope.policyDetailsObj.placeOfLoss = response.data.pincodes[i];
										$scope.cityData = { "state": ($scope.policyDetailsObj.contState.state === undefined) ? $scope.policyDetailsObj.contState : $scope.policyDetailsObj.contState.state, "zipCode": $scope.policyDetailsObj.placeOfLoss, "city": "" };
										$scope.policyDetailsObj.cityServiceCall();

										$rootScope.invalidSPCErr = false;
										$scope.policyHolderForm.$invalid = false;
										$scope.disablePinCode = true;
										// $scope.policyHolderForm.$setValidity("$invalid", false);
										return;
									} else {
										$rootScope.invalidSPCErr = true;
										$scope.policyHolderForm.$invalid = true;
										$scope.disablePinCode = false;
										// $scope.policyHolderForm.$setValidity("$invalid", true);
									}
								}
								$scope.pinCodesList = response.data.pincodes;
							} /*CR_MOBL_0054-GS Ends */

							else if ($scope.partyCode !== "" && $scope.partyCode !== undefined) { // if the cutomer is existing customer

								response.data.pincodes.filter(function (b) {//this filter will compare the responsepinCode with the response data
									if ($scope.responsepinCode !== "" && $scope.responsepinCode !== undefined && b === $scope.responsepinCode) {
										$scope.policyDetailsObj.placeOfLoss = b;
										$scope.responsepinCode = "";
										$scope.cityData = { "state": ($scope.policyDetailsObj.contState.state === undefined) ? $scope.policyDetailsObj.contState : $scope.policyDetailsObj.contState.state, "zipCode": $scope.policyDetailsObj.placeOfLoss, "city": "" };
										$scope.policyDetailsObj.cityServiceCall();

										$rootScope.invalidSPCErr = false;
										$scope.policyHolderForm.$invalid = false;
										$scope.disablePinCode = true;
										// $scope.policyHolderForm.$setValidity("$invalid", false);
										return;
									} else {
										$rootScope.invalidSPCErr = true;
										$scope.policyHolderForm.$invalid = true;
										$scope.disablePinCode = false;
										// $scope.policyHolderForm.$setValidity("$invalid", true);
									}
								});
								$scope.pinCodesList = response.data.pincodes;
								$scope.pinCodeResponseArray = response.data.pincodes;

								var pincodeMatchList = [];
								for (var i = 0; i < $scope.pinCodesList.length; i++) {
									if ($scope.pinCodesList[i].match($scope.searchPincode.zipCode)) {
										pincodeMatchList.push($scope.pinCodesList[i]);
									}
								}
								return $scope.pinCodesList = pincodeMatchList;
							} else {// if the customer is new customer
								$scope.searchPincode = "";
								$scope.pinCodesList = response.data.pincodes;
								$scope.pinCodeResponseArray = response.data.pincodes;
							}
							return $scope.pinCodesList;

						} else {
							if (response.data.errorMessage !== undefined && response.data.errorMessage !== "")
								CommonServices.showAlert(response.data.errorMessage);
							else
								// CommonServices.showAlert("Presently our services are not available. Please try after some time");
								CommonServices.showAlert("Error Occured. Please try again later");
						}
					},
					function (error) { // failure
						CommonServices.showLoading(false);
						RestServices.handleWebServiceError(error);
					});
				/* CR_NP_0880 ends*/
			},
			cityServiceCall: function () {// this function is service call for getting city
				this.cityResponse = RestServices.postService(RestServices.urlPathsNewPortal.getCitiesList, $scope.cityData);
				return this.cityResponse.then(
					function (response) { // success 

						CommonServices.showLoading(false);
						if (response.data.cities !== undefined && response.data.cities !== "") {

							/*CR_NP_0880 and CR_MOBL_0054-GS Starts */
							if (CommonServices.editQuoteFlag === true && ($rootScope.backNavigationFromSummaryGs == false || $rootScope.backNavigationFromSummaryGs === undefined) && $rootScope.polHolRadioClick === false) {

								console.log($rootScope.policyHolderDataGs);
								$scope.cityObj = { "cityObj": response.data.cities[0] }
								angular.extend($rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails, $scope.cityObj);

								$scope.policyDetailsObj.countryCity = response.data.cities[0];
								$rootScope.policyHolderCityIs = response.data.cities[0];
								$scope.cityList = response.data.cities;
								
								$rootScope.invalidSPCErr = false;
								$scope.policyHolderForm.$invalid = false;
                return;
							} /*CR_MOBL_0054-GS Ends */

							else if ($scope.partyCode !== "" && $scope.partyCode !== undefined) {// if the customer is existing customer

								response.data.cities.filter(function (b) { //this filter will compare the responseCity with the response data
									if ($scope.responseCity !== "" && $scope.responseCity !== undefined && b.cityCode === $scope.responseCity) {
										$scope.policyDetailsObj.countryCity = b;
										$rootScope.policyHolderCityIs = b;
										$scope.responseCity = "";
			
										// $scope.searchPincode = {"state":$scope.policyDetailsObj.contState.state,"city":$scope.policyDetailsObj.countryCity.city,"zipCode":""};
										// $scope.policyDetailsObj.pinCodeServiceCall();
									}
								});
								$scope.policyDetailsObj.countryCity = response.data.cities[0];
								$scope.cityList = response.data.cities;
								$rootScope.invalidSPCErr = false;
								$scope.policyHolderForm.$invalid = false;
								return;
							}
							else {// if the customer is new customer
								if ($scope.continueCity !== "" && $scope.continueCity !== undefined) {
									response.data.cities.filter(function (b) { //this filter will compare the responseCity with the response data
										if (b.cityCode === $scope.continueCity) {
											$scope.cityObj = {
												"cityObj": b
											}
										}
										angular.extend($rootScope.policyHolderDataGs.savedPartyDetails.partyDetails, $scope.cityObj);
									});
									if ($rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.stateObj !== undefined && $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.stateObj !== "" && $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.cityObj !== undefined && $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.cityObj !== "") {
										$scope.continueCity = "";
										//$state.go("businessHolidays.travellerDetails");
									}

								}
								$scope.cityData = "";
								$scope.policyDetailsObj.countryCity = response.data.cities[0];
								$scope.cityList = response.data.cities;
							}
							return $scope.cityList;
						} else {
							if (response.data.errorMessage !== undefined && response.data.errorMessage !== "")
								CommonServices.showAlert(response.data.errorMessage);
							else
								CommonServices.showAlert("Error Occured. Please try again later");
						}
					},
					function (error) { // failure
						CommonServices.showLoading(false);
						RestServices.handleWebServiceError(error);
					});
				/* CR_NP_0880 ends*/
			},

			gstFunc: function (obj, data) { // This function has the service call for getting StateList and CityList
				/*CR_NP_0880 starts */
				// $scope.policyHolderForm.$invalid = true;
				if (data === "state") { // This will give list of states
					this.placeOfLoss = "";
					this.countryCity = "";
					$scope.disablePinCode = true;
					// $scope.disableCity = true;
					$scope.stateErr = true;
					$scope.pinCodeErr = false;
					$scope.cityErr = false;

					// $scope.policyHolderForm.countryState.$invalid = true; // Commented during CR_NP_0880
					if (obj.length === 3) { // When entered value is of 3 digit
						$scope.stateData = { "state": obj.toUpperCase() };
						return this.stateServiceCall();
					} else {  // When entered value is more than 3 digit 
						if (obj.length > 3) {
							return ($filter('filter')($scope.stateList, { state: obj }));
						} else {
							$scope.stateList = {};
							return $scope.stateList;
						}

					}
				}

				if (data === 'pinCode') {
					$scope.pinCodeErr = true;
					$scope.cityErr = false;
					// $scope.disableCity = true;
					this.countryCity = "";

					if ($scope.pinCodeResponseArray != undefined && $scope.pinCodeResponseArray != "") {
						var matchList = [];
						$scope.pinCodesList = $scope.pinCodeResponseArray;
						for (var i = 0; i < $scope.pinCodesList.length; i++) {
							if ($scope.pinCodesList[i].match(obj)) {
								matchList.push($scope.pinCodesList[i]);
							}
						}
						return $scope.pinCodesList = matchList;
					} else {
						$scope.searchPincode = { "state": this.contState.state === undefined ? this.contState.toUpperCase() : this.contState.state.toUpperCase(), "zipCode": obj };
						return this.pinCodeServiceCall();
					}
				}

				if (data === "city") { // This will give list of cities
					$scope.cityErr = true;
					if (obj.length === 1) { // When entered value is of 1 digit
						$scope.cityData = { "state": this.contState.state === undefined ? this.contState.toUpperCase() : this.contState.state.toUpperCase(), "zipCode": this.placeOfLoss, "city": obj.toUpperCase() };
						return this.cityServiceCall();
					}
					else { // When entered value is more than 1 digit
						if ($scope.cityList != undefined && $scope.cityList != "") { // if cities list is available
							return ($filter('filter')($scope.cityList, { city: obj }));
						} else {
							$scope.cityData = { "state": this.contState.state === undefined ? this.contState.toUpperCase() : this.contState.state.toUpperCase(), "zipCode": this.placeOfLoss, "city": obj.toUpperCase() };
							return this.cityServiceCall();
						}
					}
				}
				/*CR_NP_0880 Ends */
				/* // 3712 Starts ///
				if (data === "country"){
					$scope.countryErr = true;
					if (obj.length === 3) { // When entered value is of 3 digit
						$scope.stateData = { "state": obj.toUpperCase() };
						return this.stateServiceCall();
					} else {  // When entered value is more than 3 digit 
						if (obj.length > 3) {
							return ($filter('filter')($scope.stateList, { state: obj }));
						} else {
							$scope.stateList = {};
							return $scope.stateList;
						}
					}
				}
				// 3712 ends //*/
			},
			/* // 3712 starts //
			onSelectCountry: function ($item, $model, $label) {// onchange of state input field//3712
				console.log($item);
				$scope.countryErr = false;
			},
			//  3712 ends //*/

			onSelectState: function ($item, $model, $label) {// onchange of state input field
				/*CR_NP_0880 starts */
				$scope.stateErr = false;
				$scope.pinCodeErr = true;
				$scope.cityErr = false;
				$scope.disablePinCode = false;
				// $scope.disableCity = true;

				$scope.policyDetailsObj.placeOfLoss = "";
				$scope.policyDetailsObj.countryCity = "";
				$scope.pinCodeResponseArray = ""; // To make Pincode response list empty

				//UC for 3749
				// angular.forEach(CommonServices.gstIdStateCode,function(value,key){
				// 	if($scope.policyDetailsObj.contState.state == value){
				// 		$scope.gstinMsg = "GSTIN should start with "+key;
				// 	}

				// });
				
				// $scope.policyDetailsObj.gstIDInputChangeFunc();
			},
			onSelectPinCode: function ($item, $model, $label) {// onchange of pincode input field
				$scope.pinCodeErr = false;
				$scope.cityErr = false;
				// $scope.disableCity = true;

				$scope.cityData = { "state": ($scope.policyDetailsObj.contState.state === undefined) ? $scope.policyDetailsObj.contState.toUpperCase() : $scope.policyDetailsObj.contState.state.toUpperCase(), "zipCode": $scope.policyDetailsObj.placeOfLoss, "city": "" };
				return this.cityServiceCall();
			},
			onSelectCity: function ($item, $model, $label) {// onchange of city input field
				$scope.policyHolderForm.$invalid = false;
				$scope.cityErr = false;
			},
			/*CR_NP_0880 Ends */

			selectGstIDFunct: function (data) { // This function will validate the GSTIN values according to the changes in GSTID Type values


				if (this.gstRegID == '' || this.gstRegID == undefined) {
					this.gstINModel = "";
					$scope.policyHolderForm.gstIN.$setValidity("validateNIAPAN", true);
					$scope.policyHolderForm.gstIN.$setValidity("gstinPattern", true);
					$scope.policyHolderForm.gstIN.$invalid = false;
					$scope.policyHolderForm.$invalid = false;
					$scope.policyDetailsObj.uinModel = '';

				}

				var reg = "";

				if (this.gstINModel !== "" && this.gstINModel !== undefined) {
					if (this.gstINModel.length === 15) {
						$scope.policyHolderForm.gstIN.$invalid = false;
						$scope.policyHolderForm.$invalid = false;
					}
				}
				else {
					$scope.policyHolderForm.gstIN.$invalid = true;
					$scope.policyHolderForm.$invalid = true;
				}
				if (this.gstRegID === "NCC") {
					reg = regexGSTidGlobal;///^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[A-Z0-9]{2}[^\s]$/;
				}
				if (this.gstRegID === "NRI") {
					reg = /^[0-9]{12}N[A-Z0-9]{1}T$/;
					// $scope.policyHolderForm.gstIN.$setValidity("gstStateCode", true);//UC for 3749
				}
				if (this.gstRegID === "UNB") {
					reg = /^[0-9]{12}U[A-Z0-9]{1}N$/;
					// $scope.policyHolderForm.gstIN.$setValidity("gstStateCode", true);//UC for 3749
				}

				var valid = "";

				if (this.gstINModel !== "" || this.gstINModel !== undefined) {
					if (reg === "") {
						valid = true;
					}
					else {
						if (this.gstINModel !== undefined && this.gstINModel !== "") {
							valid = reg.test(this.gstINModel.toUpperCase());
						}
					}

				}

				if (!valid) {
					$scope.policyHolderForm.gstIN.$setValidity("gstIN", false);
					$scope.policyHolderForm.$invalid = true;
					$scope.policyHolderForm.gstIN.$invalid = true;
				}
				else {
					$scope.policyHolderForm.gstIN.$setValidity("gstIN", true);
					$scope.policyHolderForm.$invalid = false;
					$scope.policyHolderForm.gstIN.$invalid = false;
				}

			},
			saveDetails: function (data) { // On click of Create in Policy Holder Information screen

				/*Added for CR_NP_0744*/
				if (this.aadhaarNumber1 != undefined && this.aadhaarNumber1 != '' && this.aadhaarNumber2 != undefined && this.aadhaarNumber2 != '' && this.aadhaarNumber3 != undefined && this.aadhaarNumber3 != '') {
					$scope.policyDetailsObj.aadhaarNumber = this.aadhaarNumber1 + this.aadhaarNumber2 + this.aadhaarNumber3;
				} else {
					$scope.policyDetailsObj.aadhaarNumber = "";
				}

				var policyHolderDataGs = {
					"userProfile": { "userId": CommonServices.getCommonData("userId"), "loggedInRole": "SUPERUSER" },
					"partyDetails": {
						"individualDetails": {
							"firstName": this.firstName !== undefined ? this.firstName.toUpperCase() : "",
							"lastName": this.lastName !== undefined ? this.lastName.toUpperCase() : "",
							"middleName": this.middleName !== undefined ? this.middleName.toUpperCase() : "",
							"gender": this.gender,
							"dateOfBirth": this.dateOfBirth,
							/*
							"clientNationality": this.clientNationality,//3712
							"clientCountryObj": this.clientCountry,//3712
							"clientCountry": this.clientCountry.stateCode,//3712
							*/
							"buildingNoStreet": this.street !== undefined ? this.street.toUpperCase() : "",
							"pinCode": this.placeOfLoss, //CR_NP_0880
							"mobileNo": this.mobileNumber,
							"emailId": this.emailID,
							"panNumber": this.panNo !== undefined ? this.panNo.toUpperCase() : "",
							"aadhaarNo": $scope.policyDetailsObj.aadhaarNumber,
							"gstRegIdType": this.gstRegID,
							"gstin": this.gstINModel !== undefined ? this.gstINModel.toUpperCase() : "",
							"uin": this.uinModel !== undefined ? this.uinModel.toUpperCase() : "",
							"cityObj": this.countryCity,
							"stateObj": this.contState,
							"state": this.contState.stateCode,
							"city": this.countryCity.cityCode,
							"eInsuranceAccountNo": this.accountNo
						},
						"partyType": this.category
					}
				};
				/*Changes for CR_NP_0744 ends*/

				var policyHolderResponse = RestServices.postService(RestServices.urlPathsNewPortal.createPolicyHolderTW, policyHolderDataGs);
				policyHolderResponse.then(
					function (response) { // success 

						CommonServices.showLoading(false);
						if (response.data.partyDetails !== undefined) {
							CommonServices.showAlert("Policy details has been successfully submitted. Your Party Code is #" + response.data.partyDetails.partyCode);
							//alert("Policy details has been successfully submitted. Your Party Code is #" + response.data.partyDetails.partyCode);
							var otherData = {
								policyHolder: this.policyHolder
							};
							/*CR_MOBL_0054-GS Starts */
							if (CommonServices.editQuoteFlag === true && $rootScope.backNavigationFromSummaryGs === false) {
								$rootScope.policyHolderDataGs = {};
							}
							/*CR_MOBL_0054-GS Ends*/
							var partyDetails = { "savedPartyDetails": { "partyDetails": policyHolderDataGs.partyDetails } };
							partyDetails.savedPartyDetails.partyDetails.locality = otherData.locality;
							partyDetails.savedPartyDetails.partyDetails.policyHolder = otherData.policyHolder;
							partyDetails.savedPartyDetails.partyDetails.partyCode = response.data.partyDetails.partyCode;
							$rootScope.policyHolderDataGs={};
							
							/*********SETTING INSURER NAME IN ADDITIONAL DEAILS******/
									$scope.policyHolderCreate={};
									$scope.policyHolderCreate.sumInsuredName=partyDetails.savedPartyDetails.partyDetails.individualDetails.firstName+" "+partyDetails.savedPartyDetails.partyDetails.individualDetails.lastName
								    
							/*********SETTING INSURER NAME IN ADDITIONAL DEAILS******/
							
							angular.extend($rootScope.policyHolderDataGs, partyDetails);
							/*CR_MOBL_0054-GS Start */
							if (CommonServices.editQuoteFlag === true && $rootScope.backNavigationFromSummaryGs === false) {
								$scope.policyDetailsObj.createdParty($rootScope.policyHolderDataGs);
								
							} else {
								$scope.policyDetailsObj.createdParty();
							}
							/*CR_MOBL_0054-GS Ends */

						} else {
							CommonServices.showAlert(response.data.errorMessage);
							//alert(response.data.errorMessage);
						}
					},
					function (error) { // failure
						CommonServices.showLoading(false);
						RestServices.handleWebServiceError(error);
					});
			},
			createdParty: function (item) { //This is to get policy holder details
				/* CR_NP_594A starts*/
				$scope.dateOfBirthEmpty = false;
				/* CR_NP_594A ends*/
				/*$scope.nationalityEmpty = false;  //CR 3712*/
				/*CR_MOBL_0054-GS Starts */
				// if(CommonServices.editQuoteFlag === true && $rootScope.backNavigationFromSummaryGs == undefined){ // Edit Quote New flow
				// 	$scope.policyHolderDataGs = {
				// 			"userProfile": {
				// 				"userId": CommonServices.getCommonData("userId"),
				// 				"loggedInRole": "SUPERUSER"
				// 			}, "partyDetails": { "partyCode": item.savedPartyDetails.partyDetails.partyCode }
				// 		};
				// 		$scope.partyCode = item.quote.policyHolderCode;
				// }
				if (CommonServices.editQuoteFlag === true && ($rootScope.backNavigationFromSummaryGs === false || $rootScope.backNavigationFromSummaryGs === undefined) && $rootScope.polHolRadioClick === false) { // Edit Quote from Summary
					$scope.policyHolderDataGs = {
						"userProfile": {
							"userId": CommonServices.getCommonData("userId"),
							"loggedInRole": "SUPERUSER"
						}, "partyDetails": { "partyCode": item.quote.policyHolderCode }
					};
					$scope.partyCode = item.quote.policyHolderCode;
				} else {
					if (this.policyHolder === "existingPolicyHolder") {
						$scope.policyHolderDataGs = {
							"userProfile": {
								"userId": CommonServices.getCommonData("userId"),
								"loggedInRole": "SUPERUSER"
							}, "partyDetails": { "partyCode": item.partyCode }
						};
						$scope.partyCode = item.partyCode;
					}
					else {
						$rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.policyHolder = this.policyHolder;
						$scope.policyHolderDataGs = {
							"userProfile": {
								"userId": CommonServices.getCommonData("userId"),
								"loggedInRole": "SUPERUSER"
							}, "partyDetails": { "partyCode": $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.partyCode }
						};
					}
				}
				/*CR_MOBL_0054-GS Ends*/


				var policyHolderResponse = RestServices.postService(RestServices.urlPathsNewPortal.getPolicyHolderDetail, $scope.policyHolderDataGs);
				policyHolderResponse.then(
					function (response) { // success 
						/* //3712 starts ///
						//3712
						// if (response.data.partyDetails.individualDetails.clientCountry === undefined) {
						// 	response.data.partyDetails.individualDetails.clientCountry = 'GA';
						// }
						// if (response.data.partyDetails.individualDetails.clientNationality === undefined) {
						// 	response.data.partyDetails.individualDetails.clientNationality = 'NonIndian';
						// }
						// 3712 ends /// */
						$scope.partyresponse = '';
						CommonServices.showLoading(false);
						$scope.policyDetailsObj.showSearchResTbl = true;
						if (response.data.partyDetails !== undefined) {
							/*Added for CR_NP_0744, CR_NP_0744E starts*/
							if ($scope.policyDetailsObj.policyHolder === "existingPolicyHolder") {
								//To set the initial value of PAN and Aadhaar Numbers
								if (CommonServices.initialPartyCode != item.partyCode) { //If party code is changed
									CommonServices.initialPanNumberIsEmpty = false;
								}
								CommonServices.initialPartyCode = item.partyCode;
								//For PAN Number
								if (response.data.partyDetails.individualDetails.panNumber != undefined && response.data.partyDetails.individualDetails.panNumber != "" && $scope.regexPanNo.test(response.data.partyDetails.individualDetails.panNumber)) {
									$scope.policyDetailsObj.panNoInputDisable = true;
									if (CommonServices.initialPanNumberIsEmpty == true) {
										$scope.policyDetailsObj.panNoInputDisable = false;
									}
								} else {
									$scope.policyDetailsObj.panNoInputDisable = false;
									CommonServices.initialPanNumberIsEmpty = true;
								}
							} else {
								$scope.policyDetailsObj.panNoInputDisable = false;
								//   $scope.policyDetailsObj.aadhaarInputDisable = false;
							}
							/* CR_NP_594A starts*/
							if (response.data.partyDetails.individualDetails.dateOfBirth === undefined) {
								$scope.dateOfBirthEmpty = true;
							}
							/* CR_NP_594A ends*/
							
							/* ////  3712 starts 
							response.data.partyDetails.individualDetails.clientNationality = 'NonIndian';
							response.data.partyDetails.individualDetails.clientCountry = 'Bangladesh';
							if(response.data.partyDetails.individualDetails.clientNationality !== 'Indian')
								$scope.isNonIndia = true;
							if (response.data.partyDetails.individualDetails.clientNationality === undefined || response.data.partyDetails.individualDetails.clientNationality === '') {
								$scope.nationalityEmpty = true;
							}
							//// 3712 ends /// */
							/*CR_NP_0744 and CR_NP_0744E ends*/
							$scope.policyDetailsObj.showSmallTblFunc();
							$scope.showSmallData = response.data.partyDetails;

							// Added as Form is made Invalid on change of existingPolicyHolder button & on tap on delete Icon in small details
							$scope.invalidPolicyHolderForm = false;

							/*CR_MOBL_0054-GS Starts */
							// if (CommonServices.editQuoteFlag === true && $rootScope.backNavigationFromSummaryGs === false) {
							if (CommonServices.editQuoteFlag === true && ($rootScope.backNavigationFromSummaryGs === false || $rootScope.backNavigationFromSummaryGs === undefined) && $rootScope.polHolRadioClick === false) {
								$rootScope.policyHolderDataGs = {};
								var partyDetails = { "savedPartyDetails": { "partyDetails": response.data.partyDetails } };
								angular.extend($rootScope.policyHolderDataGs, partyDetails);
								$scope.showSmallData.partyCode = item.quote.policyHolderCode;
								$rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.policyHolder = $scope.policyDetailsObj.policyHolder;

								CommonServices.setCommonData("partyCode", $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.partyCode);

								$scope.stateData = { "state": "" };
								$scope.policyDetailsObj.stateServiceCall();

								if (CommonServices.grihaSuvidhaObj.quote.addressOfProperty.buildingNoStreet == response.data.partyDetails.individualDetails.buildingNoStreet && CommonServices.grihaSuvidhaObj.quote.addressOfProperty.pinCode == response.data.partyDetails.individualDetails.pinCode) {
									$scope.gsCoveredBuildingAddress = true;
								} else {
									$scope.gsCoveredBuildingAddress = false;
								}

							} else {
								if ($scope.policyDetailsObj.policyHolder === "existingPolicyHolder") {
									var partyDetails = { "savedPartyDetails": { "partyDetails": response.data.partyDetails } };
									console.log("line no 1239"+ JSON.stringify(partyDetails));
									console.log("docs"+$rootScope.policyHolderDataGs);
									/*********SETTING INSURER NAME IN ADDITIONAL DEAILS******/
									$scope.policyHolderCreate={};
									$scope.policyHolderCreate.sumInsuredName=partyDetails.savedPartyDetails.partyDetails.individualDetails.firstName+" "+partyDetails.savedPartyDetails.partyDetails.individualDetails.lastName
								    
									/*********SETTING INSURER NAME IN ADDITIONAL DEAILS******/
									$rootScope.policyHolderDataGs={};
									angular.extend($rootScope.policyHolderDataGs, partyDetails);
									$scope.showSmallData.partyCode = item.partyCode;
									$rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.policyHolder = $scope.policyDetailsObj.policyHolder;

									//Continue button functions, to call State,City & Pincode service
									CommonServices.setCommonData("partyCode", $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.partyCode);
									if ($rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.state !== undefined && $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.state !== "") {
										$scope.continueState = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.state;
										$scope.continueCity = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.city;
										$scope.continuepinCode = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.pinCode;
										$scope.responseState = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.state;
										$scope.responseCity = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.city;
										$scope.responsepinCode = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.pinCode;
										if ($scope.continueState !== undefined && $scope.continueState !== "") {
											$scope.stateData = { "state": "" };
											$scope.policyDetailsObj.stateServiceCall();
										}

									} else {
										CommonServices.showAlert("Please enter State");
									}
								}
								else {
									$scope.showSmallData.partyCode = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.partyCode;
								}
							}
							angular.extend($rootScope.policyHolderDataGs, $scope.showSmallData);
						} else {
							$scope.policyDetailsObj.noRecords = "No records found";
							//CommonServices.showAlert("Please try again after some time.");
						}
						/*CR_MOBL_0054-GS Ends*/
					},
					function (error) { // failure
						CommonServices.showLoading(false);
						RestServices.handleWebServiceError(error);
					});
			},
			showSmallTblFunc: function () {
				$scope.policyDetailsObj.showSmallTbl = true;
				$scope.policyDetailsObj.showSearchResTbl = false;
				$scope.policyDetailsObj.existingCustomerFlag = false;
				$scope.policyDetailsObj.newcustomerFlag = false;
				//$scope.policyDetailsObj.existingCustomerFlag = false;
				//$scope.policyDetailsObj.policyHolder = "existingPolicyHolder";
			},
			searchDetails: function () {
				if (this.partyCode === '' && this.EfirstName === '' && this.ElastName === '' && this.EmobileNumber === '' && this.EemailID === '') {
					CommonServices.showAlert("Enter atleast 1 input parameters to proceed with the Policy Holder search.");
					return;
				}

				$scope.searchData = {
					"userProfile": { "userId": CommonServices.getCommonData("userId"), "loggedInRole": "SUPERUSER" },
					"partyDetails": {
						"individualDetails": { "firstName": "", "lastName": "", "emailId": "", "mobileNo": "" }, "organizationDetails": {},
						"partyCode": "", "productCode": "GS", "partyType": "I"
					}, "productCode": "GS"
				};


				if (this.partyCode !== undefined) {
					if (this.partyCode !== '') {
						$scope.searchData.partyDetails.partyCode = this.partyCode.toUpperCase();
					}
				}
				if (this.EfirstName !== undefined) {
					if (this.EfirstName !== '') {
						$scope.searchData.partyDetails.individualDetails.firstName = this.EfirstName.toUpperCase();
					}
				}
				if (this.ElastName !== undefined) {
					if (this.ElastName !== '') {
						$scope.searchData.partyDetails.individualDetails.lastName = this.ElastName.toUpperCase();
					}
				}
				if (this.EmobileNumber !== undefined) {
					if (this.EmobileNumber !== '') {
						$scope.searchData.partyDetails.individualDetails.mobileNo = this.EmobileNumber;
					}
				}
				if (this.EemailID !== undefined) {
					if (this.EmobileNumber !== '') {
						$scope.searchData.partyDetails.individualDetails.emailId = this.EemailID;
					}
				}


				var policyHolderResponse = RestServices.postService(RestServices.urlPathsNewPortal.searchPolicyHolderDetails, $scope.searchData);
				policyHolderResponse.then(
					function (response) { // success 

						$scope.partyresponse = '';
						CommonServices.showLoading(false);
						$scope.policyDetailsObj.showSearchResTbl = true;
						if (response.data.partyDetailsList !== undefined) {
							$scope.partyresponse = response.data.partyDetailsList;
							$scope.policyDetailsObj.noRecords = null;
							// angular.extend($rootScope.policyHolderDataGs, partyDetails);
						} else {
							$scope.policyDetailsObj.noRecords = "No records found";
							//CommonServices.showAlert("Please try again after some time.");
						}
					},
					function (error) { // failure
						CommonServices.showLoading(false);
						RestServices.handleWebServiceError(error);
					});

			},
			closePopup: function () {
				$scope.pinCodeModal = false;
			},
			setValue: function (data) { // this is to set values to the input fields at the time of edit 
				/*Added for CR_NP_0744, CR_NP_0744E start*/
				// To set the values on load of the page
				if ($scope.policyDetailsObj.panNoInputDisable == undefined || $scope.policyDetailsObj.panNoInputDisable == "") {
					$scope.policyDetailsObj.panNoInputDisable = CommonServices.panNoInputDisable;
				}
				/*CR_NP_0744 and CR_NP_0744E ends*/
				//sourav try
				//$scope.policyHolderForm.gstIN.$invalid = false;
				//$scope.policyHolderForm.gstIN.$valid = true;

				var partyDetails = { "savedPartyDetails": { "partyDetails": { "individualDetails": data.individualDetails } } };
				partyDetails.savedPartyDetails.partyDetails.partyCode = data.partyCode;
				partyDetails.savedPartyDetails.partyDetails.policyHolder = this.policyHolder;
				console.log("line no 1365"+partyDetails);
				angular.extend($rootScope.policyHolderDataGs, partyDetails);

				if (data.individualDetails.firstName !== undefined && data.individualDetails.firstName !== "")
					this.firstName = data.individualDetails.firstName;
				if (data.individualDetails.middleName !== undefined && data.individualDetails.middleName !== "")
					this.middleName = data.individualDetails.middleName;
				if (data.individualDetails.lastName !== undefined && data.individualDetails.lastName !== "")
					this.lastName = data.individualDetails.lastName;
				if (data.individualDetails.gender !== undefined && data.individualDetails.gender !== "")
					this.gender = data.individualDetails.gender;
				if (data.individualDetails.dateOfBirth !== undefined && data.individualDetails.dateOfBirth !== "")
					this.dateOfBirth = data.individualDetails.dateOfBirth;
				if (data.individualDetails.buildingNoStreet !== undefined && data.individualDetails.buildingNoStreet !== "")
					this.street = data.individualDetails.buildingNoStreet;
				if (data.individualDetails.mobileNo !== undefined && data.individualDetails.mobileNo !== "")
					this.mobileNumber = data.individualDetails.mobileNo;
				if (data.individualDetails.emailId !== undefined && data.individualDetails.emailId !== "")
					this.emailID = data.individualDetails.emailId;
				/*Changed for CR_NP_0744*/
				if (data.individualDetails.panNumber !== undefined && data.individualDetails.panNumber !== "" && $scope.regexPanNo.test(data.individualDetails.panNumber)) {
					this.panNo = data.individualDetails.panNumber;
				} else {
					this.panNo = "";
				}

				if (data.individualDetails.aadhaarNo !== undefined && data.individualDetails.aadhaarNo !== "" && $scope.regexAadhaarNumber.test(data.individualDetails.aadhaarNo)) {
					this.aadhaarNumber1 = data.individualDetails.aadhaarNo.substr(0, 4);
					this.aadhaarNumber2 = data.individualDetails.aadhaarNo.substr(4, 4);
					this.aadhaarNumber3 = data.individualDetails.aadhaarNo.substr(8, 4);
				} else {
					this.aadhaarNumber1 = "";
					this.aadhaarNumber2 = "";
					this.aadhaarNumber3 = "";
				}
				/* CR_NP_0744 ends*/
				if (data.individualDetails.eInsuranceAccountNo !== undefined && data.individualDetails.eInsuranceAccountNo !== "")
					this.accountNo = data.individualDetails.eInsuranceAccountNo;
				if (data.individualDetails.gstRegIdType !== undefined && data.individualDetails.gstRegIdType !== "") {
					this.gstRegID = data.individualDetails.gstRegIdType;
				}

				if (data.individualDetails.gstin !== undefined && data.individualDetails.gstin !== "")
					this.gstINModel = data.individualDetails.gstin;
				if (data.individualDetails.uin !== undefined && data.individualDetails.uin !== "")
					this.uinModel = data.individualDetails.uin;
				/* //// 3712 starts /////
				data.individualDetails.clientNationality = 'NonIndian'; //remove after API given
				data.individualDetails.clientCountry = 'Pakistan';		//remove after API given
				if(data.individualDetails.clientNationality !== undefined && data.individualDetails.clientNationality !== ""){
					$scope.policyDetailsObj.clientNationality = data.individualDetails.clientNationality;
					$scope.policyDetailsObj.clientCountry = data.individualDetails.clientCountry;
				}
				// 3712 ends ///*/
				if (data.individualDetails.state !== undefined && data.individualDetails.state !== "") {
					$scope.partyCode = data.partyCode;
					$scope.responseState = data.individualDetails.state;
					$scope.responseCity = data.individualDetails.city;
					$scope.responsepinCode = data.individualDetails.pinCode;
					$scope.stateData = { "state": "" };
					return $scope.policyDetailsObj.stateServiceCall();
				}

			},
			selectPolHolId: function (data) {
				this.showSmallTbl = true;
				this.showSearchResTbl = false;
				this.existingCustomerFlag = false;
				$scope.showSmallData = data;
				this.setValue(data);
			},
			viewDetails: function (data) {
				this.newcustomerFlag = true;
				this.fieldDisable = true;
				this.showSmallTbl = false;
				this.existingCustomerBtn = false;
				this.setValue(data);
			},
			minimizeForm: function (data) {
				if (data === true) {
					CommonServices.showAlert("Age cannot be less than 18 years");
				} else {
					this.showSmallTbl = true;
					this.newcustomerFlag = false;
					this.fieldDisable = false;
					this.existingCustomerBtn = true;
					$scope.partyCode = "";
				}
			},
			deleteRow: function () {

				this.showSmallTbl = false;
				// Added as Form is made Invalid on change of existingPolicyHolder button
				$scope.invalidPolicyHolderForm = true;
				/*Added for CR_NP_0744, CR_NP_0744E starts*/
				CommonServices.panNoInputDisable = false;
				// CommonServices.aadhaarInputDisable = false;
				/*CR_NP_0744 and CR_NP_0744E ends*/
				if ($scope.gsCoveredBuildingAddress === true) {
					$scope.gsCoveredBuildingAddress = false;
					$scope.gsBuildingNo = "";
					$scope.gsBuildingLocality = "";
					$scope.gsBuildingPinCode = "";
				}

				if (this.policyHolder === "newPolicyHolder") {
					/*Added for CR_NP_0744, commented for CR_NP_0744E start*/
					this.panNoInputDisable = false;
					// this.aadhaarInputDisable = false;
					/*CR_NP_0744 and CR_NP_0744E ends*/
					this.newcustomerFlag = true;
					this.existingCustomerFlag = false;
					$scope.partyCode = "";
					this.productTitle = "";
					this.firstName = "";
					this.middleName = "";
					this.lastName = "";
					this.gender = "";
					this.dateOfBirth = "";
					this.street = "";
					this.locality = "";
					this.placeOfLoss = "";
					this.mobileNumber = "";
					this.landlineNumber = "";
					this.emailID = "";
					this.panNo = "";
					/*Added for CR_NP_0744*/
					this.aadhaarNumber1 = "";
					this.aadhaarNumber2 = "";
					this.aadhaarNumber3 = "";
					/*CR_NP_0744 ends*/
					this.accountNo = "";
					this.gstRegID = "";
					this.gstINModel = "";
					this.uinModel = "";
					this.contState = "";
					this.countryCity = "";
				}
				else {
					this.existingCustomerFlag = true;
					this.newcustomerFlag = false;
				}

			},
			updateDetails: function () { // this is to update policy holder detail
				/*Changed for CR_NP_0744, commented for CR_NP_0744E start*/
				if (this.aadhaarNumber1 != undefined && this.aadhaarNumber1 != '' && this.aadhaarNumber2 != undefined && this.aadhaarNumber2 != '' && this.aadhaarNumber3 != undefined && this.aadhaarNumber3 != '') {
					$scope.policyDetailsObj.aadhaarNumber = this.aadhaarNumber1 + this.aadhaarNumber2 + this.aadhaarNumber3;
				} else {
					$scope.policyDetailsObj.aadhaarNumber = "";
				}

				if ($rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.mobileNo === this.mobileNumber
					&& $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.emailId === this.emailID
					&& $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.panNumber === this.panNo
					&& $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.gstRegIdType === this.gstRegID
					&& $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.gstin === this.gstINModel
					&& $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.uin === this.uinModel
					&& $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.city === this.countryCity.cityCode
					&& $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.state === this.contState.stateCode
					&& $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.pinCode === this.placeOfLoss
					&& $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.dateOfBirth === this.dateOfBirth
					&& $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.buildingNoStreet === this.street
					/* // 3712 starts //
					&& $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.clientNationality === this.clientNationality 
					&& $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.clientCountry === this.clientCountry.stateCode
					/// 3712 ends // */
					) {// If nothing has changed
				
					$scope.partyCode = "";
					this.fieldDisable = false;
					$scope.policyDetailsObj.showSmallTblFunc();
				}
				else {// if there are changes in values
					var updatepolicyHolderDataGs =
						{
							"userCode": CommonServices.getCommonData("userId"),
							"rolecode": "SUPERUSER",
							"policyHolderCode": $scope.showSmallData.partyCode,
							"mobileNo": this.mobileNumber,
							"gstRegIdType": this.gstRegID,
							"gstin": this.gstINModel,
							"dateOfBirth": $scope.policyDetailsObj.dateOfBirth,
							/*
							"clientNationality": $scope.policyDetailsObj.clientNationality,//3712
							"clientCountry": $scope.policyDetailsObj.clientCountry,//3712
							*/
							"uin": (this.gstRegID === "UNB") ? (this.uinModel !== undefined ? this.uinModel : "") : "",
							"city": this.countryCity.cityCode,
							"state": this.contState.stateCode,
							"buildingNoStreet": this.street !== undefined ? this.street.toUpperCase() : "",
							"pinCode": this.placeOfLoss, //CR_NP_0880
							"addressLine1": this.street,
							"emailId": this.emailID !== undefined ? this.emailID : "",
							/*Added for CR_NP_0744*/
							"panNumber": this.panNo,
							"aadhaarNo": $scope.policyDetailsObj.aadhaarNumber
							/*CR_NP_0744 ends*/
						};

					var updatePolicyHolderContact = RestServices.postService(RestServices.urlPathsNewPortal.updatePolicyHolderContact, updatepolicyHolderDataGs);
					updatePolicyHolderContact.then(
						function (response) { // success 

							CommonServices.showLoading(false);
							if (response.data.errorCode === undefined) {
								if (response.data.pRetCode === "0") {

									var updatePolicyData = {
										"savedPartyDetails": {
											"partyDetails": {
												"individualDetails": {
													"firstName": $scope.policyDetailsObj.firstName,
													"lastName": $scope.policyDetailsObj.lastName,
													"middleName": $scope.policyDetailsObj.middleName,
													"gender": $scope.policyDetailsObj.gender,
													"dateOfBirth": $scope.policyDetailsObj.dateOfBirth,
													/*
													"clientNationality" : $scope.policyDetailsObj.clientNationality,	//3712
													"clientCountry" : $scope.policyDetailsObj.clientCountry,		//3712
													*/
													"buildingNoStreet": $scope.policyDetailsObj.street,
													"pinCode": $scope.policyDetailsObj.placeOfLoss,//CR_NP_0880
													"mobileNo": $scope.policyDetailsObj.mobileNumber,
													"emailId": $scope.policyDetailsObj.emailID,
													"panNumber": $scope.policyDetailsObj.panNo,
													"aadhaarNo": $scope.policyDetailsObj.aadhaarNumber,
													"eInsuranceAccountNo": $scope.policyDetailsObj.accountNo,
													"gstRegIdType": $scope.policyDetailsObj.gstRegID,
													"gstin": $scope.policyDetailsObj.gstINModel,
													"uin": $scope.policyDetailsObj.uinModel,
													"cityObj": $scope.policyDetailsObj.countryCity,
													"stateObj": $scope.policyDetailsObj.contState,
													"city": $scope.policyDetailsObj.countryCity.cityCode,
													"state": $scope.policyDetailsObj.contState.stateCode
												},
												"policyHolder": $scope.policyDetailsObj.policyHolder,
												"partyType": $scope.policyDetailsObj.category
											}
										}
									};
									/*CR_NP_0744 and CR_NP_0744E changes ends*/
									$rootScope.invalidSPCErr = false;
									$scope.partyCode = "";
									angular.extend($rootScope.policyHolderDataGs, updatePolicyData);
									CommonServices.showAlert(response.data.pRetErr);
									//alert(response.data.pRetErr);
									/*Below added during UAT */
									$rootScope.policyHolderStateIs = updatePolicyData.savedPartyDetails.partyDetails.individualDetails.stateObj;
									$rootScope.policyHolderCityIs = updatePolicyData.savedPartyDetails.partyDetails.individualDetails.cityObj;
									/*UAT changes ends */
									$scope.policyDetailsObj.fieldDisable = false;
									$scope.showSmallData = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails;
									/* CR_NP_594A starts*/
									$scope.dateOfBirthEmpty = false;
									/* CR_NP_594A ends*/
									$scope.policyDetailsObj.showSmallTblFunc();
									updatePolicyData.savedPartyDetails.partyDetails.partyCode = response.data.policyHolderCode;
									angular.extend($rootScope.policyHolderDataGs, updatePolicyData);
								} else {
									CommonServices.showAlert("Please try again after some time.");
								}
							}
							else {
								CommonServices.showAlert(response.data.errorMessage);
							}

						},
						function (error) { // failure
							CommonServices.showLoading(false);
							RestServices.handleWebServiceError(error);
						});
				}

			}
		};


		$scope.calIconClick = function (event) {
			angular.element("#" + event.currentTarget.children[0].id).focus();
		};


		/*CR_MOBL_0054-GS Starts */
		if (CommonServices.editQuoteFlag === true && ($rootScope.backNavigationFromSummaryGs === false || $rootScope.backNavigationFromSummaryGs === undefined)) {
			// Risks
			if (CommonServices.grihaSuvidhaObj.quote.risks[0].coverage.jewelleryCover.coverDetails != undefined && CommonServices.grihaSuvidhaObj.quote.risks[0].coverage.jewelleryCover.coverDetails != "") {
				$scope.items = CommonServices.grihaSuvidhaObj.quote.risks[0].coverage.jewelleryCover.coverDetails;
			}
			if (CommonServices.grihaSuvidhaObj.quote.risks[0].coverage.applianceCovers[0].coverDetails != undefined && CommonServices.grihaSuvidhaObj.quote.risks[0].coverage.applianceCovers[0].coverDetails != "") {
				$scope.applianceItems = CommonServices.grihaSuvidhaObj.quote.risks[0].coverage.applianceCovers[0].coverDetails;
			}
			if (CommonServices.grihaSuvidhaObj.quote.risks[0].coverage.applianceCovers[1].coverDetails != undefined && CommonServices.grihaSuvidhaObj.quote.risks[0].coverage.applianceCovers[1].coverDetails != "") {
				$scope.televisionItems = CommonServices.grihaSuvidhaObj.quote.risks[0].coverage.applianceCovers[1].coverDetails;
			}

			// Added to get Policyholder details and then call state,pincode and city service

			$scope.policyDetailsObj.policyHolder = "existingPolicyHolder";
			console.log(JSON.stringify(CommonServices.grihaSuvidhaObj));
			$scope.policyDetailsObj.createdParty(CommonServices.grihaSuvidhaObj);

			//building Address Details
			if (CommonServices.grihaSuvidhaObj.quote.sameAddrAsBuilding !== undefined && CommonServices.grihaSuvidhaObj.quote.sameAddrAsBuilding !== "") {
				$scope.gsCoveredBuildingAddress = CommonServices.grihaSuvidhaObj.quote.sameAddrAsBuilding;
				if ($scope.gsCoveredBuildingAddress === "Y") {
					$scope.gsCoveredBuildingAddress = true;
				}
			}
			if (CommonServices.grihaSuvidhaObj.quote.addressOfProperty.buildingNoStreet !== undefined && CommonServices.grihaSuvidhaObj.quote.addressOfProperty.buildingNoStreet !== "") {
				$scope.gsBuildingNo = CommonServices.grihaSuvidhaObj.quote.addressOfProperty.buildingNoStreet;
			}
			if (CommonServices.grihaSuvidhaObj.quote.addressOfProperty.locality !== undefined && CommonServices.grihaSuvidhaObj.quote.addressOfProperty.locality !== "") {
				$scope.gsBuildingLocality = CommonServices.grihaSuvidhaObj.quote.addressOfProperty.locality;
			}
			if (CommonServices.grihaSuvidhaObj.quote.addressOfProperty.pinCode !== undefined && CommonServices.grihaSuvidhaObj.quote.addressOfProperty.pinCode !== "") {
				$scope.gsBuildingPinCode = CommonServices.grihaSuvidhaObj.quote.addressOfProperty.pinCode;
			}
			// Financier Details
			if (CommonServices.grihaSuvidhaObj.quote.financierDetails.whetherPremiseHypothecatedToBank !== undefined && CommonServices.grihaSuvidhaObj.quote.financierDetails.whetherPremiseHypothecatedToBank !== "") {
				$scope.premiseIsOfBank = CommonServices.grihaSuvidhaObj.quote.financierDetails.whetherPremiseHypothecatedToBank;
				if ($scope.premiseIsOfBank === 'Yes') {
					$scope.premiseIsOfBank = true;
				}
			}
			if (CommonServices.grihaSuvidhaObj.quote.financierDetails.nameOfBankNBranch !== undefined && CommonServices.grihaSuvidhaObj.quote.financierDetails.nameOfBankNBranch !== "") {
				$scope.bankAndBranch.bankAndBranchName = CommonServices.grihaSuvidhaObj.quote.financierDetails.nameOfBankNBranch;
			}
			if ($scope.premiseIsOfBank !== true) {
				$scope.bankAndBranch.bankAndBranchName = "";
			}

			// Only for Development Officer login
			if ($rootScope.stakeCode === "DEVLP-OFF") {
				for(var i=0; i<CommonServices.grihaSuvidhaObj.quote.partyDetailsList.length; i++){
					if(CommonServices.grihaSuvidhaObj.quote.partyDetailsList[i].stakeCode === "AGENT"){
						$scope.agentRequiredObj.agentRequired = true;
						$scope.showRelatedAgents = true;
						// To get the  related Development Officer list
						var relatedDevOff = CommonServices.getCommonData("relationDetailsOfDevOff");
						for(var j=0; j< relatedDevOff.length; j++){
							if(CommonServices.grihaSuvidhaObj.quote.partyDetailsList[i].partyCode == relatedDevOff[j].partyCode){
								// $scope.agentRequiredObj.selectedAgentGs = CommonServices.getCommonData("selectedAgentIndex");
								$scope.agentRequiredObj.selectedAgentGs = j;
								// $scope.agentRequiredObj.selectedAgentGs = $rootScope.relationDetailsOfLoggedInDevOff[j];
							}
						}
					}
				}
			}
		}
		/*CR_MOBL_0054-GS Ends*/


		/*CR_MOBL_0054-GS */ //Added temporarely remove this block after coding for policy holder details
		if ($rootScope.policyHolderDataGs !== "" && $rootScope.policyHolderDataGs != undefined) {
			if ($rootScope.backFlag === "travellerDetails" || $rootScope.policyHolderDataGs.savedPartyDetails !== undefined) {
				$scope.policyDetailsObj.showSmallTblFunc();
				$scope.showSmallData = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails;
				$scope.policyDetailsObj.policyHolder = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.policyHolder;
			}
		}


		// if ($rootScope.backFlag === "travellerDetails" || $rootScope.policyHolderDataGs.savedPartyDetails !== undefined) {
		// 	$scope.policyDetailsObj.showSmallTblFunc();
		// 	$scope.showSmallData = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails;
		// 	$scope.policyDetailsObj.policyHolder = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.policyHolder;
		// }

		//CR_MOBL_0054-GS Ends here

		//Financier Details - Building Address same as Insured
		$scope.buildingAddSame = function () {
			if ($scope.gsCoveredBuildingAddress === false) {
				$scope.gsBuildingNoReadOnly = false;
				$scope.gsBuildingLocalityReadOnly = false;
				$scope.gsBuildingPinCodeReadOnly = false;
				$scope.gsBuildingNo = "";
				$scope.gsBuildingLocality = "";
				$scope.gsBuildingPinCode = "";
			} else {
				if ($rootScope.policyHolderDataGs.savedPartyDetails === undefined) {
					CommonServices.showAlert("Please create or select the policy holder in policy Holder Information screen");
					//alert("Please create or select the policy holder in policy Holder Information screen");
					$scope.gsCoveredBuildingAddress = false;
				} else {
					$scope.gsBuildingNo = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.buildingNoStreet;
					$scope.gsBuildingLocality = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.locality;
					$scope.gsBuildingPinCode = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.pinCode;

					if ($scope.gsBuildingNo !== undefined && $scope.gsBuildingNo !== '') {
						$scope.gsBuildingNoReadOnly = true;
					}
					if ($scope.gsBuildingLocality !== undefined && $scope.gsBuildingLocality !== '') {
						$scope.gsBuildingLocalityReadOnly = true;
					}
					if ($scope.gsBuildingPinCode !== undefined && $scope.gsBuildingPinCode !== '') {
						$scope.gsBuildingPinCodeReadOnly = true;
					}

				}
			}

		};

		//Relations Details - for Development Officer Login
		$scope.showAgents = function () {

			if ($scope.agentRequiredObj.agentRequired === false) {
				$scope.showRelatedAgents = false;
				$scope.agentRequiredObj.agentRequired = false;
			} else {
				$scope.showRelatedAgents = true;
				$scope.agentRequiredObj.agentRequired = true;
			}

		};

		// Service call saveAndCalculatePremium
		$scope.saveAndCalculatePremium = function () {
			/*Added for CR_NP_0744, aadhaar commented for CR_NP_0744E*/
			if ($scope.policyDetailsObj.panNoInputDisable === true) {
				CommonServices.panNoInputDisable = true;
			}


			$scope.policyHolderName = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.firstName + " " + $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.middleName + " " + $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.lastName;

			//$scope.bankAndBranchName = $("#bankAndBranchName").val();
			if ($scope.premiseIsOfBank === true) {
				bankandBranchName = $scope.bankAndBranch.bankAndBranchName;
			} else {
				bankandBranchName = "";
			}

			var stateOfPolHolder;
			var cityOfPolHolder;
			/*CR_MOBL_0054-GS Starts */
			// if (CommonServices.editQuoteFlag === true && $rootScope.backNavigationFromSummaryGs == false) {
			if (CommonServices.editQuoteFlag === true && ($rootScope.backNavigationFromSummaryGs === false || $rootScope.backNavigationFromSummaryGs === undefined) && $rootScope.polHolRadioClick === false) {
				stateOfPolHolder = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.stateObj.state;
				cityOfPolHolder = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.cityObj.city;
				/*CR_MOBL_0054-GS Ends*/
			} else if ($rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.policyHolder === "newPolicyHolder") {
				stateOfPolHolder = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.stateObj.state;
				cityOfPolHolder = $rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.cityObj.city;
			} else {
				stateOfPolHolder = $rootScope.policyHolderStateIs.state;
				cityOfPolHolder = $rootScope.policyHolderCityIs.city;
			}
			$rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.policyHolderStateGs = stateOfPolHolder;
			$rootScope.policyHolderDataGs.savedPartyDetails.partyDetails.individualDetails.policyHolderCityGs = cityOfPolHolder;

}


}]);


