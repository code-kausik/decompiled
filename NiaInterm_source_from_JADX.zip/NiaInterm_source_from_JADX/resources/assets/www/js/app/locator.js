agentApp.controller('locatorHomeScreenCtrl', ['$scope', '$rootScope', 'CommonServices', 'RestServices', 'GetSetResponseService', '$location', '$state', function($scope, $rootScope, CommonServices, RestServices, GetSetResponseService, $location, $state) {

    $scope.goBack = function() {
      history.go(-1);
    }

    $scope.locatorMap = {};

    $scope.locatorHomeScreenCtrl = {
        onload: function(){

           $scope.input = document.getElementById('locatorSearchBoxInput');  
           $scope.autocomplete = new google.maps.places.Autocomplete($scope.input);

          $scope.showMap = false;
          //$scope.locatorMap.locatorListDiv = false; 
          initMap();
            
    }};
  // CR 0756A starts here
  $scope.locatorSearchTPASelectedOnChange = function(){
      
    $scope.locatorMap.enableSearch = ($scope.locatorMap.locatorSearchTpaSelected!="");
    if($scope.locatorMap.locatorSearchTpaSelected==""){
      $scope.locatorMap.locatorList = "";
      $scope.locatorMap.currentLocationlat = "";
      $scope.locatorMap.currentLocationlong = "";
      $scope.locatorMap.noMapDataFound = true;
      $("#locatorSearchBoxInput").val("");
      initMap(); 
    }
    
    setMumbaiHQ();
    if ($scope.locatorMap.currentLocationlat != "undefined") {
        if ($scope.locatorMap.locatorSearchTpaSelected!="" && $scope.locatorSearchBoxInput != "" && $scope.locatorSearchBoxInput != undefined) {
          $scope.getGeoLocations()
        }
    }
  }  

  $scope.showTPAErr = function(){

    CommonServices.showAlert('Please select TPA as mentioned in the policy document');
  }
  // CR 0756A ends here

    

    var markers =[];
    var map;
    var infowindow;
    var circle;
    $scope.locatorMap.radius = 2000;
    $scope.locatorMap.noMapDataFound = false;
    $scope.locatorMap.locatorSelectedLocationForDirection = false;
    var travelMode,originField, autocompleteOrigin;
    var currentLat, currentLng, currentPos, currentAddress, currentLatLng;
    var service = new google.maps.DirectionsService;
    $scope.destinationLocation='';
    var geocoder = new google.maps.Geocoder;

    circle = new google.maps.Circle({
      strokeColor: '#a5236f',
      strokeOpacity: 0.5,
      strokeWeight: 2,
      fillColor: '#a5236f',
      fillOpacity: 0.35,
      /*map: map,
      center: place.geometry.location,*/
      radius: $scope.locatorMap.radius,
      draggable: false,
      editable: true
      //geodesic: true
    });

    $scope.locatorHomeScreenCtrl.onload();

    function initMap(){

          map = new google.maps.Map(document.getElementById('map'), {
            center: {lat: 20.5937, lng: 78.9629},
            mapTypeControl:false,
            zoom: 4
          });
          //var card = document.getElementById('pac-card');
          var input = document.getElementById('locatorSearchBoxInput');
          //var types = document.getElementById('type-selector');
          //var strictBounds = document.getElementById('strict-bounds-selector');

          //map.controls[google.maps.ControlPosition.TOP_RIGHT].push(card);

          var autocomplete = new google.maps.places.Autocomplete(input);

          // Bind the map's bounds (viewport) property to the autocomplete object,
          // so that the autocomplete requests use the current map bounds for the
          // bounds option in the request.
          autocomplete.bindTo('bounds', map);

          infowindow = new google.maps.InfoWindow();
          
          var infopopContent = document.getElementById('infowindow-content');
          var infowindowContent = infopopContent.cloneNode(true);
          
          infowindow.setContent(infowindowContent);
          var marker = new google.maps.Marker({
            map: map,
            icon: 'images/location_pointer.svg',
            anchorPoint: new google.maps.Point(0, -29)
          });


          autocomplete.addListener('place_changed', function() {
  // CR 0756A starts here
  if($scope.locatorMap.locatorSearchBySelected == "HOSPITAL"){
    if($scope.locatorMap.locatorSearchTpaSelected == "" || $scope.locatorMap.locatorSearchTpaSelected == undefined){

      CommonServices.showAlert('Please select TPA as mentioned in the policy document');
      return;
    }
  } 
  // CR 0756A ends here

            setMumbaiHQ();
            
            //$scope.locatorMap.radius = 2000;  

            if(markers){
              for (var i = 0; i < markers.length; i++) {
                markers[i].setMap(null);
              }
             }

             if(infowindow){
              infowindow.close();
             }
    
            var place = autocomplete.getPlace();
            if (!place.geometry) {
              // User entered the name of a Place that was not suggested and
              // pressed the Enter key, or the Place Details request failed.
              CommonServices.showAlert("No details available for input: '" + place.name + "'");
              return;
            }

            //$scope.locatorSearchBoxInput = place.formatted_address;

            // If the place has a geometry, then present it on a map.
            if (place.geometry.viewport) {
              map.fitBounds(place.geometry.viewport);
            } else {
              map.setCenter(place.geometry.location);
              map.setZoom(17);  // Why 17? Because it looks good.
            }
            //marker.setPosition(place.geometry.location);
            //marker.setVisible(true);

            circle.setCenter(place.geometry.location);
            circle.setMap(map);
              setTimeout(function(){
              map.fitBounds(circle.getBounds());
            },2000);

            /*var address = '';
            if (place.address_components) {
              address = [
                (place.address_components[0] && place.address_components[0].short_name || ''),
                (place.address_components[1] && place.address_components[1].short_name || ''),
                (place.address_components[2] && place.address_components[2].short_name || '')
              ].join(' ');
            }*/

            /*infowindowContent.children['place-icon'].src = place.icon;
            infowindowContent.children['place-name'].textContent = place.name;
            infowindowContent.children['place-address'].textContent = address;
            infowindow.open(map, marker);*/

            $scope.locatorMap.currentLocationlat = place.geometry.location.lat(); 
            $scope.locatorMap.currentLocationlong = place.geometry.location.lng();

            $scope.getGeoLocations();

          });

          $scope.showMap = true;
          $scope.locatorMap.locatorSelectedLocationForDirection = false;          
        };


              // Sets a listner for circle drag
          google.maps.event.addListener(circle, 'radius_changed', function() {
              if (this.getRadius() > 20000) {
                this.setRadius(20000);
              }else{
                $scope.locatorMap.radius = this.getRadius();
                //db Service call
                for (var i = 0; i < markers.length; i++) {
                  markers[i].setMap(null);
                }
                 $scope.getGeoLocations();
              }
              map.fitBounds(this.getBounds());
          });

          //circle point changed
          google.maps.event.addListener(circle, 'center_changed', function() {
            var latlng = new google.maps.LatLng(this.getCenter().lat(),this.getCenter().lng());
            //marker.setPosition(latlng);

            for (var i = 0; i < markers.length; i++) {
              markers[i].setMap(null);
            }

            var pos = {
              lat:this.getCenter().lat(),
              lng:this.getCenter().lng()
            };    

            geocoder.geocode({'location': pos}, function(results, status) {
              if (status === 'OK') {
                if (results[0]) {
                /*var marker = new google.maps.Marker({
                position: pos,
                map: map
                });*/
                /*for (var i = 0; i < markers.length; i++) {
                  markers[i].setMap(null);
                }  
                */
                /*$scope.$apply(function() {
                  $("#locatorSearchBoxInput").val(results[0].formatted_address);
                });*/

                //inputField.value = results[0].formatted_address;
              } else {
                console.log('No results found');
                }
              } else {
                console.log('Geocoder failed due to: ' + status);
              }
            });    

            $scope.locatorMap.currentLocationlat = this.getCenter().lat();
            $scope.locatorMap.currentLocationlong = this.getCenter().lng();
            $scope.getGeoLocations();
          }); 

    $('.locatorSearchList li').on('click', function() {
        $(this).addClass('locatorSelected').siblings().removeClass('locatorSelected');
    });

    $scope.locatorMap.locatorSearchBySelected = "OFFICE";
    $scope.locatorMap.locatorSearchListDdown = true;
    $scope.locatorMap.locatorListDiv = false;

    var normalMapHeight = ($(window).height() - 270)+"px";
    var newMapHeight = ($(window).height() - 220)+"px";

    $scope.locatorMap.enableSearch = true; // added for CR 0756A
    $scope.locatorSearchBy = function(searchBy) {
        $scope.locatorMap.locatorSearchBySelected = searchBy;
        if (searchBy == "CASHLESSGARAGE") { // added for CR 0756A
            $scope.locatorMap.locatorSearchListDdown = false;
            $("#map").css('height', newMapHeight);
            $("#mySidenav").css('height',newMapHeight);
            $("#mySidenav").css('top','190px');
        } else {
          $scope.locatorMap.locatorSearchListDdown = (searchBy == "OFFICE")?true:false;
            $("#map").css('height', normalMapHeight);
            $("#mySidenav").css('height',normalMapHeight);
            $("#mySidenav").css('top','240px');
        }

        $scope.locatorMap.locatorList = "";
        $scope.locatorMap.currentLocationlat = ""; // added for CR 0756A
        $scope.locatorMap.currentLocationlong = ""; // added for CR 0756A
        $scope.locatorMap.noMapDataFound = true;
        $("#locatorSearchBoxInput").val("");

        if ($scope.locatorMap.locatorListDiv === true) {
          $scope.closeNav();  
        }
        $scope.locatorMap.enableSearch = (searchBy=='HOSPITAL' && ($scope.locatorMap.locatorSearchTpaSelected=="" || $scope.locatorMap.locatorSearchTpaSelected==undefined))?false:true; // added for CR 0756A
         initMap();
      
    }
    $scope.locatorSearchBy($scope.locatorMap.locatorSearchBySelected);
    $scope.locatorSearchListDdownSelectedOnChange = function(){
      setMumbaiHQ();
      if ($scope.locatorMap.currentLocationlat != "undefined") {
          if ($scope.locatorSearchBoxInput != "" && $scope.locatorSearchBoxInput != undefined) {
            
            $scope.getGeoLocations()
          }
      }
    }


    $scope.getCurrentLocation = function() {
      
      // CR 0756A starts here
      if($scope.locatorMap.locatorSearchBySelected == "HOSPITAL"){
        if($scope.locatorMap.locatorSearchTpaSelected == "" || $scope.locatorMap.locatorSearchTpaSelected == undefined){

          CommonServices.showAlert('Please select TPA as mentioned in the policy document');
          return;
        }
      }    
      // CR 0756A ends here

        var options = {
          enableHighAccuracy: true,
          timeout: 5000,
          maximumAge: 0
        };

        CommonServices.showLoading(true);
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition($scope.showPosition, $scope.showError,options);

        } else {
            alert("Geolocation is not supported.");
        }
        CommonServices.showLoading(false);
    }

    $scope.showPosition = function(position) {
        CommonServices.showLoading(false);
        var latlon = position.coords.latitude + "," + position.coords.longitude;
        //console.log(latlon);

        $scope.locatorMap.currentLocationlat = position.coords.latitude;
        $scope.locatorMap.currentLocationlong = position.coords.longitude;

        var pos = {
            lat:position.coords.latitude,
            lng:position.coords.longitude
        };

        
        geocoder.geocode({'location': pos}, function(results, status) {
            if (status === 'OK') {
              if (results[0]) {
                /*var marker = new google.maps.Marker({
                position: pos,
                map: map
                });*/
              for (var i = 0; i < markers.length; i++) {
                  markers[i].setMap(null);
              }  
                
              $scope.$apply(function() {
                $("#locatorSearchBoxInput").val(results[0].formatted_address);
                $scope.locatorSearchBoxInput = results[0].formatted_address ;

                circle.setCenter(pos);
                circle.setMap(map);
                  setTimeout(function(){
                   map.fitBounds(circle.getBounds());
                },2000);

                $scope.getGeoLocations();
               });

                //inputField.value = results[0].formatted_address;
              } else {
                CommonServices.showAlert('No results found');
              }
            } else {
              CommonServices.showAlert('Geocoder failed due to: ' + status);
            }
        });
    };

    $scope.getGeoLocations = function() {

      if ($scope.locatorSearchBoxInput === "" || $scope.locatorSearchBoxInput === undefined || $scope.locatorMap.currentLocationlat == "") { // modified for CR 0756A
          return;
        } 

        var officeType="";

        if ($scope.locatorMap.locatorSearchBySelected == "OFFICE") {
          if ($scope.locatorMap.locatorSearchListDdownSelected == "" || $scope.locatorMap.locatorSearchListDdownSelected == undefined ) {
              officeType = "BRANCH OFFICE";
            }else{
              officeType = $scope.locatorMap.locatorSearchListDdownSelected;
            }
            }else if($scope.locatorMap.locatorSearchBySelected == "HOSPITAL"){ // CR 0756A starts here
              if($scope.locatorMap.locatorSearchTpaSelected == "" || $scope.locatorMap.locatorSearchTpaSelected == undefined){
    
                CommonServices.showAlert('Please select TPA as mentioned in the policy document');
                return;
              }else{
    
                officeType = $scope.locatorMap.locatorSearchTpaSelected;
              } 
            } // CR 0756A ends here

        var getGeoLocationsInput = {
            "locatorType": $scope.locatorMap.locatorSearchBySelected,
            "officeType": officeType,
            "lattitude": $scope.locatorMap.currentLocationlat,
            "longitude": $scope.locatorMap.currentLocationlong,
            "radius": $scope.locatorMap.radius
        }

        CommonServices.showLoading(true);
        //var url = RestServices.urlConstantPortal + RestServices.urlPaths.getGeoLocations;
        //var url = "https://sitweb.newindia.co.in/BaNCSIntegrationWebComp/rest/commoncomponent/getGeoLocations";

        var getGeoLocationsResponse = RestServices.postService(RestServices.urlPathsNewPortal.getGeoLocations, getGeoLocationsInput);
        getGeoLocationsResponse.then(
            function(response) { // success 
                CommonServices.showLoading(false);
                if (response.data === undefined) {
                    CommonServices.showAlert("Something went wrong. Please try after some time");
                    return;
                }
                if (response.data) {
                    $scope.locatorMap.locatorList = response.data.listLocatorResponse;
                    //$scope.locatorMap.locatorListDiv = true;

                    if ( response.data.footer != undefined) {
                      //CommonServices.showAlert(response.data.footer.status);
                      $scope.locatorMap.noMapDataFound = true;
                      pointMarkers(response.data.listLocatorResponse);
                    }else{
                      $scope.locatorMap.noMapDataFound = false;
                      pointMarkers(response.data.listLocatorResponse);  
                    }
                    
                } else {
                    CommonServices.showAlert(response.data.footer.status);
                    // CommonServices.showAlert("No data found");
                }

            },
            function(error) { // failure
                CommonServices.showLoading(false);
                RestServices.handleWebServiceError(error);
            });

    }

    $scope.showError = function(error) {
        CommonServices.showLoading(false);
        switch (error.code) {
            case error.PERMISSION_DENIED:
                CommonServices.showAlert("User denied the request for Geolocation.");
                break;
            case error.POSITION_UNAVAILABLE:
                CommonServices.showAlert("Location information is unavailable.");
                break;
            case error.TIMEOUT:
                CommonServices.showAlert("Location information is unavailable. Please check your device location setting.");
                break;
            case error.UNKNOWN_ERROR:
                CommonServices.showAlert("An unknown error occurred.");
                break;
        }
        CommonServices.showLoading(false);
    }

    
    var pointMarkers = function(locations){

    $scope.showMap = true;  
    if(locations){
      try{
        var prev_infowindow = false; 
        //var infowindow = new google.maps.InfoWindow();

        var infowindow = new google.maps.InfoWindow({
          maxWidth:200
        })

        //var infowindowContent = document.getElementById('infowindow-content');
        //var infowindowContent = infopopContent.cloneNode(true);

        var infopopContent = document.getElementById('infowindow-content');
        var infowindowContent = infopopContent.cloneNode(true);
 //added in CR 0756A. solve issue with map marker - previously plotted markers were not removing.
        // Deletes all markers in the array by removing references to them
        if (markers) {
          for (i in markers) {
            markers[i].setMap(null);
          }
          markers.length = 0;
        }
        // CR 0756A ends here

        for (var index = 0; index < locations.length; index++) {
          var myLatLng = new google.maps.LatLng(locations[index].lattitude, locations[index].longitude);
          var marker;

          marker = new google.maps.Marker({
            position: myLatLng,
            icon: 'images/location_pointer.svg',
            map: map,
            // label:(index+1).toString(),
            title: locations[index].address
          });



          // Allow each marker to have an info window
          google.maps.event.addListener(marker, 'click', (function(marker, index) {
            return function() {
              var place = locations[index];
              //added for CR_0756A starts here
              if($scope.locatorMap.locatorSearchBySelected=='OFFICE' && $scope.locatorMap.locatorSearchListDdownSelected=='ALL OFFICE'){
                infowindowContent.children['place-name'].textContent = `${index+1}. ${place.officeType} - ${place.name}`;  
              }else{
                infowindowContent.children['place-name'].textContent = `${index+1}. ${place.name}`;
              }
              //added for CR_0756A end here
             infowindowContent.children['place-address'].textContent = place.address;
              //infowindowContent.children['place-email'].textContent = place.emailid;
              //infowindowContent.children['place-telephone'].textContent = place.telephoneNo;
              infowindow.setContent(infowindowContent);
              if( prev_infowindow ) {
                prev_infowindow.close();
              }
              prev_infowindow = infowindow;
              infowindow.open(map, marker);
            };
          })(marker, index));

          $scope.locatorMap.locatorListDiv = true;

          // Automatically center the map fitting all markers on the screen
          //map.fitBounds(bounds);

        }
      }catch (e) {
        $scope.locatorMap.locatorListDiv = true;
        $scope.locatorMap.noMapDataFound = true;
        console.log(e);
      }
    }
  };


  $scope.openNav = function() {
    document.getElementById("mySidenav").style.width = "100%";
  }

  $scope.closeNav = function() {
    document.getElementById("mySidenav").style.width = "0";
  }

  $('.drivingDirectionOption div').on('click', function() {
        $(this).addClass('drivingDirectionOptionSelected').siblings().removeClass('drivingDirectionOptionSelected');
    });

  $scope.getDirection = function(data){


    $scope.locatorMap.selectedLocationForDirection =  $scope.locatorMap.locatorList[data];
    CommonServices.selectedLocationForDirection='';
    CommonServices.selectedLocationForDirection = $scope.locatorMap.selectedLocationForDirection;

    $scope.viewDirectionOnMap();

    //$state.go("locatorList");  
/*    $scope.showMap = false;
    $scope.locatorMap.locatorListDiv = false;
    $scope.locatorMap.locatorSelectedLocationForDirection = true;

    $scope.drawMap();*/

  }

  $scope.drawMap = function(){

      //CommonServices.showLoading(true);

      if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition($scope.showCurrentPosition, $scope.showError);

        } else {
            alert("Geolocation is not supported.");
      }
  };

  $scope.showCurrentPosition = function(position){

        var currentLat = position.coords.latitude;
        var currentLng = position.coords.longitude;
        var currentPos = {
            lat: currentLat,
            lng: currentLng
        };
        var currentLatLng = new google.maps.LatLng(currentLat, currentLng);

        /*var geocoder = new google.maps.Geocoder;
        geocoder.geocode({'location': currentPos}, function(results, status) {
          if (status === 'OK') {
            if (results[0]) {
              currentAddress = results[0].formatted_address;
              originField.value = currentAddress;
            }
          }
        });*/

        var data = CommonServices.selectedLocationForDirection;
        $scope.selectedDestination = data.formattedAddress||data.address||data.name;
        $scope.destinationLocation = new google.maps.LatLng(data.lattitude,data.longitude);
    
        /*var mapOptions = {
          zoom : 16,
          center : $scope.destinationLocation,
          mapTypeId : google.maps.MapTypeId.ROADMAP
        };*/

        setTimeout(function(){

            $("#locatorDirectionInputTo").val($scope.selectedDestination);
              
            var rendererOptions = {
                panel: document.getElementById('locateUs-directions-bottom')
            };  

            directionsDisplay = new google.maps.DirectionsRenderer(rendererOptions);

            $scope.drivingDirections(currentLatLng,$scope.destinationLocation,directionsDisplay); 

        },500);


  }

  $scope.drivingDirections = function(origin,destinationLocation,display){

    var travelMode = 'WALKING';

    var request = {
      origin : origin,
      destination : destinationLocation,
      travelMode : travelMode
    };
    service.route(request,function(response, status) {
      if (status == google.maps.DirectionsStatus.OK) {
      display.setDirections(response);
      } else
      alert('failed to get directions');
    });


  };  


  $scope.viewDirectionOnMap = function(){
      /* if we're on iOS, open in Apple Maps */


      /* else use Google */
      //http://maps.google.com/maps?saddr=New+York&daddr=San+Francisco
      //https://www.google.com/maps/dir/?daddr=12.9559853,77.5870451&amp;ll
      //google.navigation:q=San+Francisco  

      /*if ((navigator.platform.indexOf("iPhone") != -1) || (navigator.platform.indexOf("iPad") != -1) || (navigator.platform.indexOf("iPod") != -1)){
        window.open("maps://maps.google.com/maps?daddr=<lat>,<long>&amp;ll="); 
        var googleMapsUrl = "https://maps.google.com/maps?daddr=" + CommonServices.selectedLocationForDirection.lattitude +"," + CommonServices.selectedLocationForDirection.longitude +"&amp;ll="; 
      }
      else {
        var googleMapsUrl = "https://maps.google.com/maps?daddr=" + CommonServices.selectedLocationForDirection.lattitude +"," + CommonServices.selectedLocationForDirection.longitude +"&amp;ll=";
      }*/


     var googleMapsUrl = "https://maps.google.com/maps?daddr=" + CommonServices.selectedLocationForDirection.formattedAddress||CommonServices.selectedLocationForDirection.address||CommonServices.selectedLocationForDirection.name +"&amp;ll=";
     window.open(googleMapsUrl,'_system');

  }

  $scope.goBackToList = function(){
        $scope.showMap = true;
        $scope.locatorMap.locatorListDiv = true;
        $scope.locatorMap.locatorSelectedLocationForDirection = false;

  }

function setMumbaiHQ(){

    var inputField = document.getElementById('locatorSearchBoxInput');
    if(inputField.value){
        if(inputField.value.toLowerCase().indexOf('mumbai')!==-1 && $scope.locatorMap.locatorSearchListDdownSelected==='HEAD OFFICE'){
          circle.setRadius(20000);
          $scope.locatorMap.radius=20000;
        }else{
          circle.setRadius(2000)
          $scope.locatorMap.radius=2000;
        }
      }; 
    }
}]);


/*customerApp.controller('locatorListScreenCtrl', ['$scope', '$rootScope', 'CommonServices', 'RestServices', '$location', '$state', function($scope, $rootScope, CommonServices, RestServices, $location, $state) {

    $scope.goBack = function() {
        CommonServices.goBack();
    }

    console.log(CommonServices.selectedLocationForDirection);

 }]);*/

