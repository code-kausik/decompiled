var gulp = require('gulp'),
    minifycss = require('gulp-minify-css'),
    jshint = require('gulp-jshint'),
    stylish = require('jshint-stylish'),
    uglify = require('gulp-uglify'),
    usemin = require('gulp-usemin'),
    imagemin = require('gulp-imagemin'),
    rename = require('gulp-rename'),
    concat = require('gulp-concat'),
    notify = require('gulp-notify'),
    cache = require('gulp-cache'),
    changed = require('gulp-changed'),
    rev = require('gulp-rev'),
    browserSync = require('browser-sync'),
    del = require('del'),
    minifyHtml = require('gulp-minify-html');
	
gulp.task('jshint', function() {
  return gulp.src('www/js/app/**/*.js')
  .pipe(jshint())
  .pipe(jshint.reporter(stylish));
});

// Clean
gulp.task('clean', function() {
    return del(['dist']);
});

// Default task
gulp.task('default', ['clean'], function() {
     gulp.start('usemin','imagemin','copyJson','copyCordova','minifyHtml');
});

gulp.task('usemin',['jshint'], function () {
  return gulp.src('./www/index.html')
      .pipe(usemin({
        css:[minifycss(),rev()],
        js: [uglify(),rev()],
        html: [minifyHtml({ empty: true })]
      }))
      .pipe(gulp.dest('dist/'));
});

// Images
gulp.task('imagemin', function() {
  return del(['dist/images']), gulp.src('www/images/**/*')
    .pipe(cache(imagemin({ optimizationLevel: 3, progressive: true, interlaced: true })))
    .pipe(gulp.dest('dist/images'))
    .pipe(notify({ message: 'Images task complete' }));
});

gulp.task('copyJson', ['clean'], function() {
   gulp.src('www/json/home.json')
   .pipe(gulp.dest('./dist/json'));
});

gulp.task('copyCordova', ['clean'], function() {
  //  gulp.src('www/js/lib/**/*')
//    .pipe(gulp.dest('./dist/js/lib'));
   gulp.src('www/js/lib/cordova/**/*')
   .pipe(gulp.dest('./dist/js/lib/cordova'));
});

gulp.task('minifyHtml', function() {
  gulp.src('www/**/*.html')
    .pipe(minifyHtml({ empty: true }))
    .pipe(gulp.dest('./dist'))
});
