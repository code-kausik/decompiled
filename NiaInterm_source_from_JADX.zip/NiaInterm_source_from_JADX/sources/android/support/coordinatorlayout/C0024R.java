package android.support.coordinatorlayout;

import com.tcs.nia.C0313R;

/* renamed from: android.support.coordinatorlayout.R */
public final class C0024R {

    /* renamed from: android.support.coordinatorlayout.R$attr */
    public static final class attr {
        public static final int alpha = 2130837504;
        public static final int coordinatorLayoutStyle = 2130837505;
        public static final int font = 2130837506;
        public static final int fontProviderAuthority = 2130837507;
        public static final int fontProviderCerts = 2130837508;
        public static final int fontProviderFetchStrategy = 2130837509;
        public static final int fontProviderFetchTimeout = 2130837510;
        public static final int fontProviderPackage = 2130837511;
        public static final int fontProviderQuery = 2130837512;
        public static final int fontStyle = 2130837513;
        public static final int fontVariationSettings = 2130837514;
        public static final int fontWeight = 2130837515;
        public static final int keylines = 2130837516;
        public static final int layout_anchor = 2130837517;
        public static final int layout_anchorGravity = 2130837518;
        public static final int layout_behavior = 2130837519;
        public static final int layout_dodgeInsetEdges = 2130837520;
        public static final int layout_insetEdge = 2130837521;
        public static final int layout_keyline = 2130837522;
        public static final int statusBarBackground = 2130837523;
        public static final int ttcIndex = 2130837524;
    }

    /* renamed from: android.support.coordinatorlayout.R$color */
    public static final class color {
        public static final int notification_action_color_filter = 2130903042;
        public static final int notification_icon_bg_color = 2130903043;
        public static final int ripple_material_light = 2130903051;
        public static final int secondary_text_default_material_light = 2130903053;
    }

    /* renamed from: android.support.coordinatorlayout.R$dimen */
    public static final class dimen {
        public static final int compat_button_inset_horizontal_material = 2130968576;
        public static final int compat_button_inset_vertical_material = 2130968577;
        public static final int compat_button_padding_horizontal_material = 2130968578;
        public static final int compat_button_padding_vertical_material = 2130968579;
        public static final int compat_control_corner_material = 2130968580;
        public static final int compat_notification_large_icon_max_height = 2130968581;
        public static final int compat_notification_large_icon_max_width = 2130968582;
        public static final int notification_action_icon_size = 2130968584;
        public static final int notification_action_text_size = 2130968585;
        public static final int notification_big_circle_margin = 2130968586;
        public static final int notification_content_margin_start = 2130968587;
        public static final int notification_large_icon_height = 2130968588;
        public static final int notification_large_icon_width = 2130968589;
        public static final int notification_main_column_padding_top = 2130968590;
        public static final int notification_media_narrow_margin = 2130968591;
        public static final int notification_right_icon_size = 2130968592;
        public static final int notification_right_side_padding_top = 2130968593;
        public static final int notification_small_icon_background_padding = 2130968594;
        public static final int notification_small_icon_size_as_large = 2130968595;
        public static final int notification_subtext_size = 2130968596;
        public static final int notification_top_pad = 2130968597;
        public static final int notification_top_pad_large_text = 2130968598;
    }

    /* renamed from: android.support.coordinatorlayout.R$drawable */
    public static final class C0025drawable {
        public static final int notification_action_background = 2131034118;
        public static final int notification_bg = 2131034119;
        public static final int notification_bg_low = 2131034120;
        public static final int notification_bg_low_normal = 2131034121;
        public static final int notification_bg_low_pressed = 2131034122;
        public static final int notification_bg_normal = 2131034123;
        public static final int notification_bg_normal_pressed = 2131034124;
        public static final int notification_icon_background = 2131034125;
        public static final int notification_template_icon_bg = 2131034126;
        public static final int notification_template_icon_low_bg = 2131034127;
        public static final int notification_tile_bg = 2131034128;
        public static final int notify_panel_notification_icon_bg = 2131034129;
    }

    /* renamed from: android.support.coordinatorlayout.R$id */
    public static final class C0026id {
        public static final int action_container = 2131099649;
        public static final int action_divider = 2131099650;
        public static final int action_image = 2131099651;
        public static final int action_text = 2131099652;
        public static final int actions = 2131099653;
        public static final int async = 2131099655;
        public static final int blocking = 2131099658;
        public static final int bottom = 2131099661;
        public static final int chronometer = 2131099666;
        public static final int end = 2131099675;
        public static final int forever = 2131099680;
        public static final int icon = 2131099685;
        public static final int icon_group = 2131099686;
        public static final int info = 2131099688;
        public static final int italic = 2131099689;
        public static final int left = 2131099691;
        public static final int line1 = 2131099692;
        public static final int line3 = 2131099693;
        public static final int none = 2131099699;
        public static final int normal = 2131099700;
        public static final int notification_background = 2131099701;
        public static final int notification_main_column = 2131099702;
        public static final int notification_main_column_container = 2131099703;
        public static final int right = 2131099714;
        public static final int right_icon = 2131099715;
        public static final int right_side = 2131099716;
        public static final int start = 2131099724;
        public static final int tag_transition_group = 2131099727;
        public static final int tag_unhandled_key_event_manager = 2131099728;
        public static final int tag_unhandled_key_listeners = 2131099729;
        public static final int text = 2131099730;
        public static final int text2 = 2131099731;
        public static final int time = 2131099732;
        public static final int title = 2131099734;
        public static final int top = 2131099735;
    }

    /* renamed from: android.support.coordinatorlayout.R$integer */
    public static final class integer {
        public static final int status_bar_notification_info_maxnum = 2131165186;
    }

    /* renamed from: android.support.coordinatorlayout.R$layout */
    public static final class layout {
        public static final int notification_action = 2131230725;
        public static final int notification_action_tombstone = 2131230726;
        public static final int notification_template_custom_big = 2131230733;
        public static final int notification_template_icon_group = 2131230734;
        public static final int notification_template_part_chronometer = 2131230738;
        public static final int notification_template_part_time = 2131230739;
    }

    /* renamed from: android.support.coordinatorlayout.R$string */
    public static final class string {
        public static final int status_bar_notification_info_overflow = 2131427459;
    }

    /* renamed from: android.support.coordinatorlayout.R$style */
    public static final class style {
        public static final int TextAppearance_Compat_Notification = 2131492865;
        public static final int TextAppearance_Compat_Notification_Info = 2131492866;
        public static final int TextAppearance_Compat_Notification_Line2 = 2131492868;
        public static final int TextAppearance_Compat_Notification_Time = 2131492871;
        public static final int TextAppearance_Compat_Notification_Title = 2131492873;
        public static final int Widget_Compat_NotificationActionContainer = 2131492875;
        public static final int Widget_Compat_NotificationActionText = 2131492876;
        public static final int Widget_Support_CoordinatorLayout = 2131492877;
    }

    /* renamed from: android.support.coordinatorlayout.R$styleable */
    public static final class styleable {
        public static final int[] ColorStateListItem = {16843173, 16843551, C0313R.attr.alpha};
        public static final int ColorStateListItem_alpha = 2;
        public static final int ColorStateListItem_android_alpha = 1;
        public static final int ColorStateListItem_android_color = 0;
        public static final int[] CoordinatorLayout = {C0313R.attr.keylines, C0313R.attr.statusBarBackground};
        public static final int[] CoordinatorLayout_Layout = {16842931, C0313R.attr.layout_anchor, C0313R.attr.layout_anchorGravity, C0313R.attr.layout_behavior, C0313R.attr.layout_dodgeInsetEdges, C0313R.attr.layout_insetEdge, C0313R.attr.layout_keyline};
        public static final int CoordinatorLayout_Layout_android_layout_gravity = 0;
        public static final int CoordinatorLayout_Layout_layout_anchor = 1;
        public static final int CoordinatorLayout_Layout_layout_anchorGravity = 2;
        public static final int CoordinatorLayout_Layout_layout_behavior = 3;
        public static final int CoordinatorLayout_Layout_layout_dodgeInsetEdges = 4;
        public static final int CoordinatorLayout_Layout_layout_insetEdge = 5;
        public static final int CoordinatorLayout_Layout_layout_keyline = 6;
        public static final int CoordinatorLayout_keylines = 0;
        public static final int CoordinatorLayout_statusBarBackground = 1;
        public static final int[] FontFamily = {C0313R.attr.fontProviderAuthority, C0313R.attr.fontProviderCerts, C0313R.attr.fontProviderFetchStrategy, C0313R.attr.fontProviderFetchTimeout, C0313R.attr.fontProviderPackage, C0313R.attr.fontProviderQuery};
        public static final int[] FontFamilyFont = {16844082, 16844083, 16844095, 16844143, 16844144, C0313R.attr.font, C0313R.attr.fontStyle, C0313R.attr.fontVariationSettings, C0313R.attr.fontWeight, C0313R.attr.ttcIndex};
        public static final int FontFamilyFont_android_font = 0;
        public static final int FontFamilyFont_android_fontStyle = 2;
        public static final int FontFamilyFont_android_fontVariationSettings = 4;
        public static final int FontFamilyFont_android_fontWeight = 1;
        public static final int FontFamilyFont_android_ttcIndex = 3;
        public static final int FontFamilyFont_font = 5;
        public static final int FontFamilyFont_fontStyle = 6;
        public static final int FontFamilyFont_fontVariationSettings = 7;
        public static final int FontFamilyFont_fontWeight = 8;
        public static final int FontFamilyFont_ttcIndex = 9;
        public static final int FontFamily_fontProviderAuthority = 0;
        public static final int FontFamily_fontProviderCerts = 1;
        public static final int FontFamily_fontProviderFetchStrategy = 2;
        public static final int FontFamily_fontProviderFetchTimeout = 3;
        public static final int FontFamily_fontProviderPackage = 4;
        public static final int FontFamily_fontProviderQuery = 5;
        public static final int[] GradientColor = {16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 16844050, 16844051};
        public static final int[] GradientColorItem = {16843173, 16844052};
        public static final int GradientColorItem_android_color = 0;
        public static final int GradientColorItem_android_offset = 1;
        public static final int GradientColor_android_centerColor = 7;
        public static final int GradientColor_android_centerX = 3;
        public static final int GradientColor_android_centerY = 4;
        public static final int GradientColor_android_endColor = 1;
        public static final int GradientColor_android_endX = 10;
        public static final int GradientColor_android_endY = 11;
        public static final int GradientColor_android_gradientRadius = 5;
        public static final int GradientColor_android_startColor = 0;
        public static final int GradientColor_android_startX = 8;
        public static final int GradientColor_android_startY = 9;
        public static final int GradientColor_android_tileMode = 6;
        public static final int GradientColor_android_type = 2;
    }
}
